@extends('layouts/layoutMaster')

@section('title', 'Branch Holiday')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 300px;
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Branch Holiday</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_add_branch_holiday">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Branch Holiday
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Holiday Date</th>
                            <th class="min-w-200px">Branch / Franchise</th>
                            <th class="min-w-250px">Holiday Reason</th>
                            <th class="min-w-150px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @foreach ($lists as $list)
                            <tr>
                                <td>
                                    <label class="bg-label-info px-2 py-1 rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Holiday Date">{{ date('d-M-Y', strtotime($list->hol_date)) }}</label>
                                </td>
                                <td><label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Branch / Franchise">{{ $list->branch_name }}</label></td>
                                <td><label class="fs-7 text-black fw-semibold text-truncate">{{ $list->hol_reason ?? '-' }}</label></td>
                                <td>
                                    <span class="text-end">
                                        <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_branch_holiday"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" onclick="openEditModal('{{ $list->sno }}')"
                                            title="Edit">
                                            <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                        </a>
                                    </span>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Add Branch Holiday-->
<div class="modal fade" id="kt_modal_add_branch_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Create Branch Holiday</h3>
                </div>
                <form method="POST" id="add_holiday_form" action="{{ route('create_branch_holiday') }}" >
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span class="text-danger">*</span></label>
                            <select class="select3 form-select" id="branch_id" name="branch_id[]" multiple data-placeholder="Select Branch / Franchise">
                                <option value="">Select Branch / Franchise</option>
                            </select>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="branch_id_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" name="holiday_date" readonly id="holiday_date"
                                    class="form-control area_andarkottaram" />
                            </div>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="holiday_date_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Holiday Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="holiday_reason" name="holiday_reason"
                                placeholder="Enter Holiday Reason"></textarea>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="holiday_reason_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Create Branch Holiday</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Branch Holiday-->

<!--begin::Modal - Edit Branch Holiday-->
<div class="modal fade" id="kt_modal_edit_branch_holiday" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Branch Holiday</h3>
                </div>
                <form method="POST" id="edit_holiday_form" action="{{ route('update_branch_holiday') }}">
                    @csrf
                    <div class="row">
                        <input type="hidden" name="edit_id" id="edit_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch / Franchise<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="branch_id_edit" name="branch_id_edit[]" multiple
                                data-placeholder="Select Branch / Franchise">
                                <option value="">Select Branch / Franchise</option>
                            </select>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="branch_id_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" placeholder="Select Date" name="holiday_date_edit" readonly
                                    id="holiday_date_edit" class="form-control area_andarkottaram" />
                            </div>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="holiday_date_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Holiday Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="2" id="holiday_reason_edit" name="holiday_reason_edit"
                                placeholder="Enter Holiday Reason"></textarea>
                            <div class="text-danger mt-2 fs-7 fw-semibold" id="holiday_reason_edit_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update Branch Holiday</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Branch Holiday-->

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .toast-info {
            background-color: #7239ea;
        }
    </style>
    <script>
        @if (Session::has('toastr'))
                    var type = "{{ Session::get('toastr')['type'] }}";
                    var message = "{{ Session::get('toastr')['message'] }}";
                    toastr[type](message);
                @endif
    </script>
<!-- Toastr Ends -->

<!-- Branch / Franchise Data Fetch Add -->
<script>
    $(document).ready(function () {
        $.ajax({
            url: "{{ route('bran_drop_down') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var BranchDropdown = $('#branch_id');
                    BranchDropdown.empty();

                    var branchGroup = $('<optgroup label="Branch"></optgroup>');
                    var franchiseGroup = $('<optgroup label="Franchise"></optgroup>');

                    // Append options to the appropriate group
                    response.data.forEach(function(branch) {
                        if (branch.branch_type == 1) {
                            branchGroup.append($('<option></option>').attr('value', branch.sno).text(branch.branch_name));
                        } else if (branch.branch_type == 2) {
                            franchiseGroup.append($('<option></option>').attr('value', branch.sno).text(branch.franchise_name));
                        }
                    });

                    // Append the groups to the dropdown
                    BranchDropdown.append(branchGroup);
                    BranchDropdown.append(franchiseGroup);
                }
            },
            error: function(error) {
                console.error('Error fetching branches:', error);
            }
        });
    });
</script>

<!-- Date Picker -->
<script>
    $(document).ready(function() {
        var isRtl = false; // Define this as needed
        if ($('.area_andarkottaram').length) {
            $('.area_andarkottaram').datepicker({
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: isRtl ? 'auto right' : 'auto left'
            });
        }
    });
</script>

<!-- Add Validation -->
<script>
    $('#add_holiday_form').on('submit', (e) => {
        var isValid = true;
        const branchId = $('#branch_id').val();
        const holidayDate = $('#holiday_date').val();
        const holidayReason = $('#holiday_reason').val();

        $('#branch_id_err', '#holiday_date_err', '#holiday_reason_err').text('');

        if(!branchId || branchId.length === 0) {
            $('#branch_id_err').text('Branch / Franchise is required.');
            isValid = false;
        }

        if(holidayDate === '') {
            $('#holiday_date_err').text('Holiday Date is required.');
            isValid = false;
        }

        if(holidayReason === '') {
            $('#holiday_reason_err').text('Holiday Reason is required.');
            isValid = false;
        }

        if(!isValid) {
            e.preventDefault();
        }
    });
</script>

<!-- Edit Validation -->
<script>
    function openEditModal(sno) {
        $.ajax({
            url: `/edit_branch_holiday/${sno}`,
            type: "GET",
            success: function(response) {
                if(response.status === 200) {
                    const edit = response.data;
                    $('#edit_id').val(sno);

                    // Edit Branch / Franchise Data Fetch
                    $.ajax({
                        url: "{{ route('bran_drop_down') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var BranchDropdown = $('#branch_id_edit');
                                BranchDropdown.empty();

                                var branchGroup = $('<optgroup label="Branch"></optgroup>');
                                var franchiseGroup = $('<optgroup label="Franchise"></optgroup>');

                                // Append options to the appropriate group
                                response.data.forEach(function(branch) {
                                    if (branch.branch_type == 1) {
                                        branchGroup.append($('<option></option>').attr('value', branch.sno).text(branch.branch_name));
                                    } else if (branch.branch_type == 2) {
                                        franchiseGroup.append($('<option></option>').attr('value', branch.sno).text(branch.franchise_name));
                                    }
                                });

                                // Append the groups to the dropdown
                                BranchDropdown.append(branchGroup);
                                BranchDropdown.append(franchiseGroup);
                                var editBranchId = JSON.parse(edit.branch_id);
                                $('#branch_id_edit').val(editBranchId).trigger('change');
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching branches:', error);
                        }
                    });
                    $('#holiday_date_edit').datepicker('setDate', new Date(edit.hol_date));
                    $('#holiday_reason_edit').val(edit.hol_reason);
                }
            },
            error: function(error) {
                console.error('Error fetching branches:', error);
            }
        });
    }
</script>

@endsection