@extends('layouts/layoutMaster')

@section('title', 'Cronjob Monitor')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/nouislider/nouislider.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/nouislider/nouislider.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 300px;
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Cronjob Monitor</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Monitoring Tools</a>
                    </li>
                </ol>
            </nav>
        </div>
         <!-- Right: Count + Button in same row -->
        <div class="d-flex align-items-center gap-3">
            <div class="col-md-12">
              <button id="clearLog" class="btn btn-danger w-100">Clear</button>
            </div>
        </div>
    </div>
    <div class="card-body">
        
        <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/Cronjob_Monitor">
                        @csrf
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div>
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="0">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                        <input
                            type="text"
                            class="form-control"
                            id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                            placeholder="Enter Search"
                        />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12" id="ajax-table-container">
                    @include('content.branch_management.cronjob_monitor_table')
                </div>
            </div>
    </div>
</div>


<div class="modal fade" id="clearLogModal" tabindex="-1" aria-labelledby="clearLogModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="clearLogModalLabel">Clear Cronjob Old Logs</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      
      <div class="modal-body">
        <label for="monthSelect" class="text-dark mb-1 fs-6 fw-semibold">Select Log Duration to Clear:</label>
        <select id="monthSelect" class="select3 form-select">
          <option value="">-- Choose --</option>
          <option value="1">1 Month</option>
          <option value="2">2 Months</option>
          <option value="3">3 Months</option>
          <option value="6">6 Months</option>
          <option value="9">9 Months</option>
        </select>
      </div>
      
      <div class="text-center mt-2 mb-2">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" id="confirmClear" class="btn btn-danger">Clear Logs</button>
      </div>
      
    </div>
  </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
    .lds-ring {
      display: inline-block;
      position: relative;
      width: 64px;
      height: 64px;
    }
    .lds-ring div {
      box-sizing: border-box;
      display: block;
      position: absolute;
      width: 48px;
      height: 48px;
      margin: 8px;
      border: 6px solid #0d6efd;
      border-radius: 50%;
      animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
      border-color: #0d6efd transparent transparent transparent;
    }
    .lds-ring div:nth-child(1) { animation-delay: -0.45s; }
    .lds-ring div:nth-child(2) { animation-delay: -0.3s; }
    .lds-ring div:nth-child(3) { animation-delay: -0.15s; }
    @keyframes lds-ring {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

</style>

<script>
    // Display Toastr messages
       @if (Session::has('toastr'))
           var type = "{{ Session::get('toastr')['type'] }}";
           var message = "{{ Session::get('toastr')['message'] }}";
           toastr[type](message);
       @endif
</script>

<script>
$(document).ready(function () {

    // 🧩 Open Modal
    $('#clearLog').on('click', function () {
        $('#monthSelect').val('');
        $('#clearLogModal').modal('show');
    });

    // 🗑 Confirm Clear
    $('#confirmClear').on('click', function () {
        const months = $('#monthSelect').val();

        if (!months) {
            alert('Please select how many months to clear.');
            return;
        }

        if (!confirm(`Are you sure you want to delete logs older than ${months} month(s)?`)) {
            return;
        }

        $.ajax({
            url: '/cron-log-clear',
            type: 'POST',
            data: {
                months: months,
                _token: '{{ csrf_token() }}'
            },
            beforeSend: function () {
                $('#confirmClear').prop('disabled', true).text('Clearing...');
            },
            success: function (response) {
                $('#clearLogModal').modal('hide');
                toastr.success(response.message);

                // ✅ Refresh the table after deletion
                if (typeof loadLogs === 'function') {
                    loadLogs();
                } else {
                    console.warn('⚠️ loadLogs() function not found.');
                }
            },
            error: function (xhr) {
                alert('Error clearing logs: ' + (xhr.responseJSON?.message || 'Unknown error'));
            },
            complete: function () {
                $('#confirmClear').prop('disabled', false).text('Clear Logs');
            }
        });
    });
});
</script>

<script>
$(document).ready(function(){

    function fetch_data(page = 1) {
        // destroy existing tooltips before AJAX update
        $('[data-bs-toggle="tooltip"]').tooltip('dispose');
    
        var search_fill = $('#search_fill').val() || '';
        var perpage = $('#sorting_filter').val() || 25;
    
        $.ajax({
            url: "{{ route('tools_manage-cronjob') }}?page=" + page,
            method: 'GET',
            data: { search_fill: search_fill, sorting_filter: perpage },
            success: function (data) {
                $('#ajax-table-container').html(data);
    
                // re-initialize tooltips after DOM update
                $('[data-bs-toggle="tooltip"]').tooltip();
            }
        });
    }

    // Initial load
    fetch_data();

    // Auto-refresh every 10 seconds
    setInterval(function(){
        fetch_data($('#ajax-table-container').find('.pagination .active a').text() || 1);
    }, 10000);

    // Pagination click
    $(document).on('click', '.pagination a', function(event){
        event.preventDefault();
        var page = $(this).attr('href').split('page=')[1];
        fetch_data(page);
    });

    // Search input
    $('#search_fill').on('keyup', function(){
        fetch_data(1);
    });

    // Per-page change
    $('#sorting_filter').on('change', function(){
        fetch_data(1);
    });

});
</script>

<!--begin::Modal - View history-->
<div class="modal fade" id="kt_modal_view_branch" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="row" id="view_history"> 
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View history-->


<script>
$(document).ready(function(){

    // open modal + load history
    $(document).on('click', '.btn-history', function(e){
        e.preventDefault();
        let cronjobId = $(this).data('id');
        fetchHistory(cronjobId, 1);
        $('#kt_modal_view_branch').modal('show');
    });

    // handle pagination clicks inside modal
    $(document).on('click', '#view_history .pagination a', function(e){
        e.preventDefault();
        let page = $(this).attr('href').split('page=')[1];
        let cronjobId = $('#view_history').data('cronjob-id');
        fetchHistory(cronjobId, page);
    });

    function fetchHistory(cronjobId, page) {
        // Show loader while fetching
        $('#view_history').html(`
            <div class="d-flex flex-column justify-content-center align-items-center p-5">
                <div class="lds-ring mb-3"><div></div><div></div><div></div><div></div></div>
                <div class="fw-semibold text-primary">Loading History...</div>
            </div>
        `).data('cronjob-id', cronjobId);

    
        $.ajax({
            url: "{{ url('/branch-manage/cronjob-history') }}/" + cronjobId + "?page=" + page,
            type: "GET",
            success: function(res){
                $('#view_history').html(res).data('cronjob-id', cronjobId);
                $('[data-bs-toggle="tooltip"]').tooltip();
            },
            error: function() {
                $('#view_history').html('<div class="alert alert-danger text-center">Failed to load history. Please try again.</div>');
            }
        });
    }

});
</script>



<!-- Status Change -->
<script>
    function SwitchStatus(UniversityId, isChecked) {
      const status = isChecked ? 0 : 1; // Set status based on checkbox state

      fetch(`/CronjobStatusChange/${UniversityId}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
              },
              body: JSON.stringify({
                  status: status
              })
          })
          .then(response => response.json())
          .then(data => {
              if (data.status === 200) {
                  console.log('Cronjob Status updated successfully:', data.message);
                  toastr.success('Cronjob Status Updated successfully!');
              } else {
                  console.error('Error updating Cronjob Status:', data.message);
                  toastr.error('Error updating Cronjob Status');
              }
          })
          .catch(error => {
              console.error('Error updating Cronjob status:', error);
          });
    }
</script>

<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>

@endsection