<table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
    <thead>
        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
            <th class="min-w-50px">Sno</th>
            <th class="min-w-150px">CronJob</th>
            <th class="min-w-100px">Cronjob Duration</th>
            <th class="min-w-100px">Cronjob Status</th>
            <th class="min-w-100px">Last Run Duration</th>
            <th class="min-w-100px">Status</th>
            <th class="min-w-100px">Action</th>
        </tr>
    </thead>
    <tbody class="text-black fw-semibold fs-7">
        @if (isset($ListTable))
            @foreach ($ListTable as $i => $list)
                <tr>
                    <td>{{ $i + 1 }}</td>
                    <td>
                        <label class="fs-5 fw-bold text-black">{{$list->cronjob_name}}</label>
                        <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="{!! $list->cronjob_desc !!}">
                            <i class="mdi mdi-help-circle text-dark"></i>
                        </a>
                    </td>
                    <td>{{ $list->cronjob_run_duration }}</td>
                    <td>
                        @if($list->running_status == 1)
                            <label class="bg-label-success fs-4 fw-semibold px-2 py-1 animation-blink rounded">Running</label>
                        @else
                            <label class="bg-label-danger fs-4 fw-semibold px-2 py-1 rounded">Stopped</label>
                        @endif
                        <span 
                            class="mdi mdi-clipboard-text-clock-outline fs-4 text-primary" 
                            data-bs-toggle="tooltip" 
                            data-bs-placement="bottom" 
                            data-bs-html="true"
                            data-bs-custom-class="tooltip-secondary"
                            title="
                                <div>
                                    <strong>Start Time:</strong> {{ \Carbon\Carbon::parse($list->sync_start_date_time)->format('d-M-Y h:i A') }}
                                </div>
                                <div>
                                    <strong>End Time:</strong> {{ $list->sync_end_date_time ? \Carbon\Carbon::parse($list->sync_end_date_time)->format('d-M-Y h:i A') : '-' }}
                                </div>
                            ">
                        </span>

                       
                    </td>
                    <td>
                        @php
                            [$hours, $minutes, $seconds] = explode(':', $list->sync_duration);
                        @endphp
                        <label class="bg-info text-white fs-5 fw-semibold px-2 py-1 rounded">
                            @if ((int)$hours > 0) {{ (int)$hours }} hr @endif
                            @if ((int)$minutes > 0) {{ (int)$minutes }} min @endif
                            @if ((int)$seconds > 0 || ((int)$hours == 0 && (int)$minutes == 0)) {{ (int)$seconds }} sec @endif
                        </label>
                    </td>
                    <td>
                        <label class="switch switch-square">
                            <input type="checkbox" class="switch-input" {{ $list->status == 0 ? 'checked' : '' }} onchange="SwitchStatus('{{ $list->sno }}', this.checked)" />
                            <span class="switch-toggle-slider">
                                <span class="switch-on"></span>
                                <span class="switch-off"></span>
                            </span>
                        </label>
                    </td>
                    <td>
                        <a href="{{$list->cronjb_link ?? 'javascript:;'}}" target="_blank" class="btn btn-sm fw-bold btn-secondary text-white waves-effect waves-light">Run Now</a>
                        <a href="javascript:;" class="btn-history" data-id="{{ $list->sno }}">
                            <i class="mdi mdi-history ms-2 fs-4 fw-bold"></i>
                        </a>
                    </td>
                </tr>
            @endforeach
        @endif
    </tbody>
</table>

<div class="mt-4">
    {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
</div>




