@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Manage Incentive')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <style>
        .reward-card {
            background: linear-gradient(145deg, #fdfdff, #f4f6fb);
            border: 1px solid #ced6e0;
            border-radius: 1.25rem;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.07);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .badge-gradient-rich {
            background: linear-gradient(90deg, #f59e0b, #f97316);
            color: #fff;
            box-shadow: 0 2px 10px rgba(249, 115, 22, 0.3);
            font-weight: 600;
            border: none;
        }

        .text-gold {
            color: #facc15 !important;
            /* gold-yellow */
        }

        .reward-card:hover {
            transform: scale(1.02);
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.1);
        }

        .reward-header .badge {
            background: linear-gradient(to right, #3b82f6, #6366f1);
            animation: pulse 2s infinite ease-in-out;
            font-weight: 600;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
                opacity: 1;
            }

            50% {
                transform: scale(1.05);
                opacity: 0.9;
            }
        }

        .reward-input-container {
            position: relative;
            display: block;
        }

        .reward-input {
            padding-left: 2.75rem;
            font-size: 1.2rem;
            font-weight: 600;
            color: #111827;
            background-color: #ffffff;
            border-radius: 0.75rem;
            border: none;
            box-shadow: inset 0 0 0 2px #d1d5db;
            transition: box-shadow 0.3s ease, background-color 0.3s ease;
        }

        .reward-input:focus {
            background-color: #ffffff;
            box-shadow: inset 0 0 0 2px #3b82f6, 0 0 12px rgba(59, 130, 246, 0.25);
            outline: none;
        }

        .table-responsive {
            overflow-x: auto;
            margin-bottom: 1.5rem;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem;
        }

        .table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 0.5rem;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .table thead th {
            background: linear-gradient(to right, #3b82f6, #6366f1) !important;
            /* nice blue */
            color: #fff;
            font-weight: 600;
            padding: 0.75rem 1rem;
            border-radius: 8px 8px 0 0;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.05em;
        }

        .table tbody tr {
            background: #f9fafb;
            border-radius: 8px;
            transition: background-color 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: #e3e7ff;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            font-weight: 500;
            color: #333;
            text-align: center;
            vertical-align: middle;
            border: none;
        }

        .table tbody td:first-child {
            font-weight: 600;
            color: #3f51b5;
        }

        .form-control-sm {
            border: 1.5px solid #ccc;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.35rem 0.75rem;
            text-align: center;
            background: #fff;
            color: #222;
            transition: border-color 0.3s ease;
        }

        .form-control-sm::placeholder {
            color: #999;
            font-weight: 400;
        }

        .form-control-sm:focus {
            border-color: #3f51b5;
            outline: none;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(63, 81, 181, 0.4);
        }

        /* Container */
        .luxury-incentive-container {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 480px;
            margin: 2rem auto;
        }

        .luxury-incentive-container>label {
            font-weight: 700;
            font-size: 1.15rem;
            color: #222;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .luxury-incentive-container label i.mdi-help-circle-outline {
            color: #888;
            cursor: pointer;
            font-size: 1.3rem;
            transition: color 0.3s ease;
        }

        .luxury-incentive-container label i.mdi-help-circle-outline:hover {
            color: #3b82f6;
            /* Tailwind blue-500 */
        }

        .luxury-content {
            background: #fff;
            border-radius: 14px;
            padding: 2rem 2rem 2.5rem 2rem;
            box-shadow: 0 8px 20px rgb(59 130 246 / 0.15);
            transition: box-shadow 0.4s ease, transform 0.4s ease;
        }

        .luxury-content:hover {
            box-shadow: 0 16px 40px rgb(59 130 246 / 0.3);
            transform: translateY(-5px);
        }

        .form-check {
            margin-bottom: 1.2rem;
        }

        .form-check-input {
            width: 1.25rem;
            height: 1.25rem;
            cursor: pointer;
            accent-color: #3b82f6;
            border-radius: 0.3rem;
            transition: transform 0.2s ease;
        }

        .form-check-input:hover {
            transform: scale(1.1);
        }

        .form-check-label {
            font-weight: 600;
            font-size: 1rem;
            color: #333;
            cursor: pointer;
        }

        .form-floating {
            margin-top: 2rem;
        }

        .form-control {
            border-radius: 12px;
            padding: 0.75rem 1.25rem;
            font-weight: 600;
            font-size: 1.05rem;
            border: 1.6px solid #d1d5db;
            color: #111827;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            background-color: #f9fafb;
        }

        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 10px rgb(59 130 246 / 0.35);
            background-color: #fff;
            outline: none;
        }

        .form-floating>label {
            color: #6b7280;
            font-weight: 600;
            font-size: 1rem;
        }

        .month-display {
            background: linear-gradient(to right, #f9fafb, #eef2ff);
            border: 1.5px dashed #60a5fa;
            /* Tailwind blue-400 */
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            transition: background 0.3s ease;
        }

        .icon-nav-btn {
            width: 42px;
            height: 42px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .icon-nav-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 0 8px rgba(99, 102, 241, 0.25);
            /* soft indigo glow */
        }
    </style>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Manage Incentive</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard/crm') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="row">
                    <div class="col-lg-3 mb-3">
                        <label class="text-dark mb-1 fs-5 fw-semibold">Branch<span class="text-danger">*</span></label>
                        @php
                            $helper = new \App\Helpers\Helpers();
                            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id; // Get branch_id from query or user session
                        @endphp

                        @if (isset($role_permission->manage_branch))
                            @if ($role_permission->manage_branch == 2)
                                @php
                                    // Get the logged-in user_id
                                    $user_id = auth()->user()->user_id;

                                    // Get the filtered branch and franchise list based on user's multi_branch_access
                                    $branch_data = $helper->get_branch_control_list($user_id);

                                    $branches = $branch_data['branches'];
                                    $franchises = $branch_data['franchises'];
                                @endphp
                                <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                                    @if ($user_id == 0)
                                        <option value="0" selected>All Branches</option>
                                    @endif
                                    @if ($branches->isNotEmpty())
                                        <optgroup label="Branches">
                                            @foreach ($branches as $branch)
                                                <option value="{{ $branch->sno }}"
                                                    {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                    {{ $branch->branch_name }}
                                                </option>
                                            @endforeach
                                        </optgroup>
                                    @endif


                                    @if ($franchises->isNotEmpty())
                                        <optgroup label="Franchises">
                                            @foreach ($franchises as $franchise)
                                                <option value="{{ $franchise->sno }}"
                                                    {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                                    {{ $franchise->franchise_name }}
                                                </option>
                                            @endforeach
                                        </optgroup>
                                    @endif
                                </select>
                            @elseif($role_permission->manage_branch == 1)
                                @if ($branch_common)
                                    <div class="d-flex align-items-center mt-2">
                                        <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                        <div>
                                            <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                            <small class="text-truncate max-w-10px text-muted"
                                                title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                                        </div>
                                    </div>
                                @else
                                @endif
                            @endif

                        @endif
                    </div>
                    <div class="col-lg-3 mb-3">
                        <label class="text-dark mb-1 fs-5 fw-semibold">Role<span class="text-danger">*</span></label>
                        <select id="role_filter" name="role_id" class="select3 form-select">
                            <!-- Options will be dynamically populated -->
                        </select>
                    </div>
                    <div class="col-lg-3 mb-4">
                        <div
                            class="reward-card px-4 py-3 text-center position-relative d-flex justify-content-between align-items-center">

                            <!-- Previous Month Button -->
                            <button type="button" id="prevMonthBtn"
                                class="btn btn-light shadow-sm d-flex align-items-center justify-content-center rounded-circle icon-nav-btn">
                                <i class="mdi mdi-arrow-left-circle-outline fs-3 text-secondary"></i>
                            </button>

                            <!-- Current Month Display -->
                            <div class="month-display px-4 py-2 mx-3 rounded-3">
                                <div class="fw-bold fs-5 text-dark text-capitalize" id="selectedMonth">
                                    {{ \Carbon\Carbon::now()->format('F') }}
                                </div>
                                <div class="small fw-semibold text-muted" id="selectedYear">
                                    ({{ \Carbon\Carbon::now()->year }})
                                </div>
                            </div>

                            <!-- Next Month Button -->
                            <button type="button" id="nextMonthBtn"
                                class="btn btn-light shadow-sm d-flex align-items-center justify-content-center rounded-circle icon-nav-btn">
                                <i class="mdi mdi-arrow-right-circle-outline fs-3 text-secondary"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-6">
                        <span id="incentiveStatusLabel" class="mt-1 fs-3 text-white px-2 py-5 rounded  fw-bold"
                            style="display: none;"></span>
                    </div>
                </div>



                <div class="row g-3 mt-3">

                    <!-- Improved 10x Award Section -->
                    <div class="col-lg-4 mb-4" data-role-visible="11,12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 10x Award
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="CR, BV and CV" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="award10x" class="form-label fw-semibold mb-2 text-muted">
                                    Enter Reward Amount
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="award10x" class="form-control reward-input" name="award10x"
                                        placeholder="0" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- 10X Warrior --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-shield-star-outline me-2 text-gold fs-5"></i> 10x Warrior
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="10X for target consecutive months, they will be recognized as a 10X warrior"
                                    class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="warriorCount" class="form-label fw-semibold mb-2 text-muted">
                                    Enter Warrior Count
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="warriorCount" class="form-control reward-input"
                                        name="warriorCount" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Early Cash Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,16">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-fast me-2 text-gold fs-5"></i> ECI (Early Cash Incentive)
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="70% of their target by 15th of each month" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Percentage -->
                                <div class="col-6">
                                    <label for="eciCount" class="form-label fw-semibold text-muted">ECI %</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="eci_count"
                                            id="eciCount" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                <!-- ECI Reward -->
                                <div class="col-6">
                                    <label for="eciRewards" class="form-label fw-semibold text-muted">ECI Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="eci_reward"
                                            id="eciRewards" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Bonus Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,16">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5"></i> BI (Bonus Incentive)
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Per additional Customer Convert above the set target" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="biAmount" class="form-label fw-semibold mb-2 text-muted">
                                    BI Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="biAmount" class="form-control reward-input"
                                        name="bi_amount" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Spot Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,16">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-target-variant me-2 text-gold fs-5"></i> Spot Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="On Month Converted customer, On Day Converted customer" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- Month Reward -->
                                <div class="col-6">
                                    <label for="spotMonth" class="form-label fw-semibold text-muted">Month Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spotMonth" class="form-control reward-input"
                                            name="spot_incentive_month" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                <!-- Day Reward -->
                                <div class="col-6">
                                    <label for="spotDay" class="form-label fw-semibold text-muted">Day Reward (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spotDay" class="form-control reward-input"
                                            name="spot_incentive_day" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Performance Incentive Section -->
                    <div class="col-lg-4 mb-4" data-role-visible="11,12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                            <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                <i class="fa-solid fa-chart-line me-2 text-gold fs-5"></i> Performance Incentive
                            </span>
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Metrics for missed calls, outgoing calls & reward" class="ms-2">
                                <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                            </a>
                            </div>

                            <div class="row g-3 text-start">
                            <div class="col-4">
                                <label for="missedCallRate" class="form-label fw-semibold mb-2 text-muted">Missed Call Rate</label>
                                <input type="text" id="missedCallRate" class="form-control reward-input" name="missedCallRate" placeholder="0"
                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                            </div>
                            <div class="col-8">
                                <label for="outgoingCalls" class="form-label fw-semibold mb-2 text-muted">Outgoing Calls Per Day</label>
                                <div class="row">
                                    <div class="col-6">
                                        <input type="text" id="outgoingCalls" class="form-control reward-input" name="outgoingCalls" placeholder="Count"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                    <div class="col-6">
                                        <input type="text" id="performanceReward" class="form-control reward-input" name="performanceReward" placeholder="Amount"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6" data-role-visible="11,12">
                        <label class="form-label fs-6 fw-bold">
                            PI (Profitable Incentive)
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="If they exceed their Business value (BV) target by a certain percentage, they receive an additional PI reward.">
                                <i class="mdi mdi-help-circle text-dark"></i>
                            </a>
                        </label>

                        <div class="table-responsive mb-2">
                            <table class="table table-bordered table-sm text-center">
                                <thead class="table-light">
                                    <tr>
                                        <th class="bg-secondary text-white">From (%)</th>
                                        <th class="bg-secondary text-white">Receive (%)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1 to 10%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_1" id="pi_receive_1" value="" min="0"
                                                max="100"></td>
                                    </tr>
                                    <tr>
                                        <td>11 to 20%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_2" id="pi_receive_2" value="" min="0"
                                                max="100"></td>
                                    </tr>
                                    <tr>
                                        <td>21 to 30%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_3" id="pi_receive_3" min="0" max="100">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>



                    <div class="col-lg-6 mb-4" data-role-visible="11,12,16">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-start position-relative">
                            <div class="reward-header d-flex justify-content-between align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-diamond-stone-outline me-2 text-gold fs-5"></i> Luxury Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Includes all major monthly incentives totaling ₹10,000 or more.">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-3">
                                <label class="form-label fw-semibold mb-2 text-muted d-block">Select Applicable
                                    Incentives</label>

                                <div class="form-check mb-2" data-role-visible="11,12">
                                    <input class="form-check-input" type="checkbox" name="tenx_award" id="tenx_award"
                                        value="1">
                                    <label class="form-check-label" for="tenx_award">10x Award</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,16">
                                    <input class="form-check-input" type="checkbox" name="early_cash_incentive"
                                        id="early_cash_incentive" value="1">
                                    <label class="form-check-label" for="early_cash_incentive">Early Cash
                                        Incentive</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,16">
                                    <input class="form-check-input" type="checkbox" name="bonus_incentive"
                                        id="bonus_incentive" value="1">
                                    <label class="form-check-label" for="bonus_incentive">Bonus Incentive</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12">
                                    <input class="form-check-input" type="checkbox" name="profitable_incentive"
                                        id="profitable_incentive" value="1">
                                    <label class="form-check-label" for="profitable_incentive">Profitable
                                        Incentive</label>
                                </div>
                                <div class="form-check mb-4" data-role-visible="11,12,16"> 
                                    <input class="form-check-input" type="checkbox" name="spot_incentive"
                                        id="spot_incentive" value="1">
                                    <label class="form-check-label" for="spot_incentive">Spot Incentive</label>
                                </div>
                                <div class="form-check mb-4" data-role-visible="11,12">
                                    <input class="form-check-input" type="checkbox" name="spot_incentive"
                                        id="performance_incentive" value="1">
                                    <label class="form-check-label" for="performance_incentive">Performance Incentive</label>
                                </div>
                            </div>

                            <div class="reward-input-group">
                                <label for="luxuryRewardInput" class="form-label fw-semibold text-muted">Reward
                                    (₹)</label>
                                <div class="reward-input-container">
                                    <input type="text" id="luxuryRewardInput" class="form-control reward-input"
                                        name="luxury_reward" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="d-flex justify-content-end align-items-center mt-1">
                <button type="button" class="btn btn-primary" id="updateincentiveButton">Update</button>
            </div>
        </div>
    </div>



    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .goal-label {
            min-width: 200px;
            /* Ensures all labels are of equal width */
            text-align: left;
            /* Aligns text to the left for consistency */
        }
    </style>
    <script>
        var currentMonth = new Date().getMonth() + 1; // Get current mont (1-12)
        var currentYear = new Date().getFullYear();

        function updateMonthDisplay() {
            let monthNames = [
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ];
            $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
            document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
            document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

            document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
            document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

            fetchIncentiveData();
        }

        document.getElementById("prevMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 1) {
                currentMonth = 12;
                currentYear--;
            } else {
                currentMonth--;
            }
            updateMonthDisplay();
        });

        document.getElementById("nextMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 12) {
                currentMonth = 1;
                currentYear++;
            } else {
                currentMonth++;
            }
            updateMonthDisplay();
        });

        function showFieldsForRole(roleId) {

            $('[data-role-visible]').each(function() {
                let rolesAttr = $(this).data('role-visible');
                console.log("Checking element with data-role-visible:", rolesAttr);

                if (!rolesAttr) return;

                const roles = rolesAttr.toString().split(',').map(r => r.trim());

                const shouldShow = roles.includes(roleId.toString());
                console.log("Should show:", shouldShow);

                $(this).toggle(shouldShow);
            });
        }

        // DOM ready
        $(document).ready(function() {
            $('#role_filter').on('change', function() {
                const roleId = $(this).val();
                console.log('Changed role (fallback event):', roleId);
                showFieldsForRole(roleId);
            });

            // Trigger initial display logic
            const initialRoleId = $('#role_filter').val();
            showFieldsForRole(initialRoleId);
        });

        function fetchIncentiveData() {
            let branch_id = $('#branchSelectsgoal').val();
            let role_id = $('#role_filter').val();
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            if (branch_id && role_id) {
                $.ajax({
                    url: '/get-role-incentive-data',
                    type: 'GET',
                    data: {
                        branch_id: branch_id,
                        role_id: role_id,
                        month: month,
                        year: year
                    },
                    success: function(response) {
                        let data = response.data;
                        const statusLabel = $('#incentiveStatusLabel');
                        const updateButton = $('#updateincentiveButton');
                        if (response.status === 200 && data) {
                            statusLabel
                                .text('Incentive already set ✅')
                                .removeClass('bg-danger')
                                .addClass('bg-success')
                                .show();
                            updateButton.text('Incentive Update').removeClass('btn-danger').addClass(
                                'btn-primary');
                            // Set simple input values
                            $('input[name="award10x"]').val(data.tenx_award);
                            $('input[name="warriorCount"]').val(data.tenx_warrior);
                            $('input[name="eci_count"]').val(data.eci_count);
                            $('input[name="eci_reward"]').val(data.eci_reward);
                            $('input[name="bi_amount"]').val(data.bi_amount);
                            $('input[name="si_crash_course"]').val(data.si_crash_course);
                            $('input[name="si_profession_course"]').val(data.si_profession_course);
                            $('input[name="si_tesbo_course"]').val(data.si_tesbo_course);
                            $('input[name="pi_percentage"]').val(data.pi_percentage);
                            $('input[name="spot_incentive_month"]').val(data.spot_incentive_month);
                            $('input[name="spot_incentive_day"]').val(data.spot_incentive_day);
                            $('input[name="missedCallRate"]').val(data.performance_incentive_missed_call);
                            $('input[name="outgoingCalls"]').val(data.performance_incentive_outgoing_call_count);
                            $('input[name="performanceReward"]').val(data.performance_incentive_reward);

                            // -----------------------------
                            // 🎯 Fetch and fill LI (Luxury Incentive) JSON
                            // -----------------------------
                            let incentives = JSON.parse(data.luxury_incentive || '{}');
                            $('#tenx_award').prop('checked', incentives.tenx_award == 1);
                            $('#early_cash_incentive').prop('checked', incentives.early_cash_incentive == 1);
                            $('#bonus_incentive').prop('checked', incentives.bonus_incentive == 1);
                            $('#strategy_incentive').prop('checked', incentives.strategy_incentive == 1);
                            $('#profitable_incentive').prop('checked', incentives.profitable_incentive == 1);
                            $('#spot_incentive').prop('checked', incentives.spot_incentive == 1);
                            $('#performance_incentive').prop('checked', incentives.performance_incentive == 1);

                            // New: set reward value (if present)
                            if (incentives.reward !== undefined) {
                                $('input[name="luxury_reward"]').val(incentives.reward);
                            } else {
                                $('input[name="luxury_reward"]').val('');
                            }

                            // -----------------------------
                            // 🎯 Fetch and fill PI Slab JSON
                            // -----------------------------
                            let pi_slab = JSON.parse(data.pi_slab_json || '[]');
                            // Loop and set if available (max 3 slabs)
                            for (let i = 0; i < 3; i++) {
                                let slab = pi_slab[i] || {};
                                $(`input[name="pi_from_${i + 1}"]`).val(slab.from || '');
                                $(`input[name="pi_to_${i + 1}"]`).val(slab.to || '');
                                $(`input[name="pi_receive_${i + 1}"]`).val(slab.percentage || '');
                            }

                        } else {
                            statusLabel
                                .text('Incentive not set ⚠️')
                                .removeClass('bg-success')
                                .addClass('bg-danger')
                                .show();
                            console.log('No data found. Resetting fields to default.');
                            updateButton.text('Incentive Add').removeClass('btn-primary').addClass(
                                'btn-primary');
                            // Reset text/number fields
                            $('input[type="text"], input[type="number"]').val('');
                            // Uncheck checkboxes
                            $('input[type="checkbox"]').prop('checked', false);
                        }
                    },
                    error: function(xhr) {
                        console.error('Error fetching incentive data:', xhr.responseJSON?.message || xhr
                            .statusText);
                    }
                });
            }
        }

        // Trigger fetch on dropdown change
        $(document).ready(function() {
            $('#branchSelectsgoal, #role_filter').change(fetchIncentiveData);
            fetchIncentiveData(); // Fetch on load
        });




        fetchRoles();

        function fetchRoles() {
            $.ajax({
                url: "{{ route('incentive_role') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $("#role_filter");
                        selectDropdown.empty().append('<option value="">Select Role</option>');

                        // Filter departments with sno 11, 12, 13, 14, 17, 22
                        let filteredData = response.data.filter(dept => [11, 12, 16].includes(dept.sno));

                        filteredData.forEach(function(dept) {
                            selectDropdown.append($('<option></option>')
                                .attr('value', dept.sno)
                                .text(dept.role_name));
                        });

                        // Set default selected value to 12
                        selectDropdown.val(11).trigger('change');
                    }
                },
                error: function(error) {
                    console.error('Error fetching departments:', error);
                }
            });
        }


        $('#updateincentiveButton').click(function() {

            const valuesToCheck = [
                $('#award10x').val(),
                $('#warriorCount').val(),
                $('#eciCount').val(),
                $('#eciRewards').val(),
                $('#biAmount').val(),
                $('#spotMonth').val(),
                $('#spotDay').val(),
                $('#missedCallRate').val(),
                $('#outgoingCalls').val(),
                $('#performanceReward').val(),
                $('#pi_receive_1').val(),
                $('#pi_receive_2').val(),
                $('#pi_receive_3').val(),
                $('#luxuryRewardInput').val()
            ];

            // Convert to numbers and check if at least one is greater than 0
            const hasAtLeastOneValue = valuesToCheck.some(val => parseFloat(val) > 0);

            if (!hasAtLeastOneValue) {
                toastr.error('Enter atleast one field.');
                return; // Stop submission
            }


            let incentives = {
                tenx_award: $('#tenx_award').prop('checked') ? 1 : 0,
                early_cash_incentive: $('#early_cash_incentive').prop('checked') ? 1 : 0,
                bonus_incentive: $('#bonus_incentive').prop('checked') ? 1 : 0,
                strategy_incentive: $('#strategy_incentive').prop('checked') ? 1 : 0,
                profitable_incentive: $('#profitable_incentive').prop('checked') ? 1 : 0,
                spot_incentive: $('#spot_incentive').prop('checked') ? 1 : 0,
                performance_incentive: $('#performance_incentive').prop('checked') ? 1 : 0, 
                reward: $('input[name="luxury_reward"]').val() || 0
            };

            let pi_slab = [{
                    min: 1,
                    max: 10,
                    percentage: parseFloat($('input[name="pi_receive_1"]').val()) || 0
                },
                {
                    min: 11,
                    max: 20,
                    percentage: parseFloat($('input[name="pi_receive_2"]').val()) || 0
                },
                {
                    min: 21,
                    max: 30,
                    percentage: parseFloat($('input[name="pi_receive_3"]').val()) || 0
                }
            ];

            let data = {
                month: $("#selectedMonth").text().trim(),
                year: $("#selectedYear").text().trim().replace(/[()]/g, ''),
                branch_id: $('#branchSelectsgoal').val(),
                role_id: $('#role_filter').val(),
                tenx_award: $('input[name="award10x"]').val(),
                tenx_warrior: $('input[name="warriorCount"]').val(),
                eci_count: $('input[name="eci_count"]').val(),
                eci_reward: $('input[name="eci_reward"]').val(),
                bi_amount: $('input[name="bi_amount"]').val(),
                si_crash_course: $('input[name="si_crash_course"]').val(),
                si_profession_course: $('input[name="si_profession_course"]').val(),
                si_tesbo_course: $('input[name="si_tesbo_course"]').val(),
                pi_percentage: $('input[name="pi_percentage"]').val(),
                spot_incentive_month: $('input[name="spot_incentive_month"]').val(),
                spot_incentive_day: $('input[name="spot_incentive_day"]').val(),
                performance_incentive_missed_call: $('input[name="missedCallRate"]').val(),
                performance_incentive_outgoing_call_count: $('input[name="outgoingCalls"]').val(),
                performance_incentive_reward: $('input[name="performanceReward"]').val(),
                luxury_incentive: JSON.stringify(incentives),
                pi_slab_json: JSON.stringify(pi_slab) // ✅ new field
            };

            $.ajax({
                url: '/incentive-create-update',
                type: 'POST',
                data: data,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success('Incentive Updated Successfully!');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    alert('Error: ' + xhr.responseJSON.message);
                }
            });
        });
    </script>
@endsection
