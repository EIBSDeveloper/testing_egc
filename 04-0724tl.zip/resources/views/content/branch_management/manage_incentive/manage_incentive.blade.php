@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Manage Incentive')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <style>
        .reward-card {
            background: linear-gradient(145deg, #fdfdff, #f4f6fb);
            border: 1px solid #ced6e0;
            border-radius: 1.25rem;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.07);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .badge-gradient-rich {
            background: linear-gradient(90deg, #f59e0b, #f97316);
            color: #fff;
            box-shadow: 0 2px 10px rgba(249, 115, 22, 0.3);
            font-weight: 600;
            border: none;
        }

        .text-gold {
            color: #facc15 !important;
            /* gold-yellow */
        }

        .reward-card:hover {
            transform: scale(1.02);
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.1);
        }

        .reward-header .badge {
            background: linear-gradient(to right, #3b82f6, #6366f1);
            animation: pulse 2s infinite ease-in-out;
            font-weight: 600;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
                opacity: 1;
            }

            50% {
                transform: scale(1.05);
                opacity: 0.9;
            }
        }

        .reward-input-container {
            position: relative;
            display: block;
        }

        .reward-input {
            padding-left: 2.75rem;
            font-size: 1.2rem;
            font-weight: 600;
            color: #111827;
            background-color: #ffffff;
            border-radius: 0.75rem;
            border: none;
            box-shadow: inset 0 0 0 2px #d1d5db;
            transition: box-shadow 0.3s ease, background-color 0.3s ease;
        }

        .reward-input:focus {
            background-color: #ffffff;
            box-shadow: inset 0 0 0 2px #3b82f6, 0 0 12px rgba(59, 130, 246, 0.25);
            outline: none;
        }

        .table-responsive {
            overflow-x: auto;
            margin-bottom: 1.5rem;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            padding: 1rem;
        }

        .table {
            width: 100%;
            border-collapse: separate !important;
            border-spacing: 0 0.5rem;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .table thead th {
            background: linear-gradient(to right, #3b82f6, #6366f1) !important;
            /* nice blue */
            color: #fff;
            font-weight: 600;
            padding: 0.75rem 1rem;
            border-radius: 8px 8px 0 0;
            text-transform: uppercase;
            font-size: 0.85rem;
            letter-spacing: 0.05em;
        }

        .table tbody tr {
            background: #f9fafb;
            border-radius: 8px;
            transition: background-color 0.2s ease;
        }

        .table tbody tr:hover {
            background-color: #e3e7ff;
        }

        .table tbody td {
            padding: 0.75rem 1rem;
            font-weight: 500;
            color: #333;
            text-align: center;
            vertical-align: middle;
            border: none;
        }

        .table tbody td:first-child {
            font-weight: 600;
            color: #3f51b5;
        }

        .form-control-sm {
            border: 1.5px solid #ccc;
            border-radius: 6px;
            font-weight: 500;
            font-size: 0.9rem;
            padding: 0.35rem 0.75rem;
            text-align: center;
            background: #fff;
            color: #222;
            transition: border-color 0.3s ease;
        }

        .form-control-sm::placeholder {
            color: #999;
            font-weight: 400;
        }

        .form-control-sm:focus {
            border-color: #3f51b5;
            outline: none;
            background-color: #fff;
            box-shadow: 0 0 5px rgba(63, 81, 181, 0.4);
        }

        /* Container */
        .luxury-incentive-container {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 480px;
            margin: 2rem auto;
        }

        .luxury-incentive-container>label {
            font-weight: 700;
            font-size: 1.15rem;
            color: #222;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .luxury-incentive-container label i.mdi-help-circle-outline {
            color: #888;
            cursor: pointer;
            font-size: 1.3rem;
            transition: color 0.3s ease;
        }

        .luxury-incentive-container label i.mdi-help-circle-outline:hover {
            color: #3b82f6;
            /* Tailwind blue-500 */
        }

        .luxury-content {
            background: #fff;
            border-radius: 14px;
            padding: 2rem 2rem 2.5rem 2rem;
            box-shadow: 0 8px 20px rgb(59 130 246 / 0.15);
            transition: box-shadow 0.4s ease, transform 0.4s ease;
        }

        .luxury-content:hover {
            box-shadow: 0 16px 40px rgb(59 130 246 / 0.3);
            transform: translateY(-5px);
        }

        .form-check {
            margin-bottom: 1.2rem;
        }

        .form-check-input {
            width: 1.25rem;
            height: 1.25rem;
            cursor: pointer;
            accent-color: #3b82f6;
            border-radius: 0.3rem;
            transition: transform 0.2s ease;
        }

        .form-check-input:hover {
            transform: scale(1.1);
        }

        .form-check-label {
            font-weight: 600;
            font-size: 1rem;
            color: #333;
            cursor: pointer;
        }

        .form-floating {
            margin-top: 2rem;
        }

        .form-control {
            border-radius: 12px;
            padding: 0.75rem 1.25rem;
            font-weight: 600;
            font-size: 1.05rem;
            border: 1.6px solid #d1d5db;
            color: #111827;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
            background-color: #f9fafb;
        }

        .form-control:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 10px rgb(59 130 246 / 0.35);
            background-color: #fff;
            outline: none;
        }

        .form-floating>label {
            color: #6b7280;
            font-weight: 600;
            font-size: 1rem;
        }

        .month-display {
            background: linear-gradient(to right, #f9fafb, #eef2ff);
            border: 1.5px dashed #60a5fa;
            /* Tailwind blue-400 */
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
            transition: background 0.3s ease;
        }

        .icon-nav-btn {
            width: 42px;
            height: 42px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .icon-nav-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 0 8px rgba(99, 102, 241, 0.25);
            /* soft indigo glow */
        }
    </style>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Manage Incentive</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard/crm') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Branch Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="row">
                    <div class="col-lg-3 mb-3">
                        <label class="text-dark mb-1 fs-5 fw-semibold">Branch<span class="text-danger">*</span></label>
                        @php
                            $helper = new \App\Helpers\Helpers();
                            $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id; // Get branch_id from query or user session
                        @endphp

                        @if (isset($role_permission->manage_branch))
                            @if ($role_permission->manage_branch == 2)
                                @php
                                    // Get the logged-in user_id
                                    $user_id = auth()->user()->user_id;

                                    // Get the filtered branch and franchise list based on user's multi_branch_access
                                    $branch_data = $helper->get_branch_control_list($user_id);

                                    $branches = $branch_data['branches'];
                                    $franchises = $branch_data['franchises'];
                                @endphp
                                <select name="branch_id" class="select3 form-select" id="branchSelectsgoal">
                                    @if ($user_id == 0)
                                        <option value="0" selected>All Branches</option>
                                    @endif
                                    @if ($branches->isNotEmpty())
                                        <optgroup label="Branches">
                                            @foreach ($branches as $branch)
                                                <option value="{{ $branch->sno }}"
                                                    {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                    {{ $branch->branch_name }}
                                                </option>
                                            @endforeach
                                        </optgroup>
                                    @endif


                                    @if ($franchises->isNotEmpty())
                                        <optgroup label="Franchises">
                                            @foreach ($franchises as $franchise)
                                                <option value="{{ $franchise->sno }}"
                                                    {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                                    {{ $franchise->franchise_name }}
                                                </option>
                                            @endforeach
                                        </optgroup>
                                    @endif
                                </select>
                            @elseif($role_permission->manage_branch == 1)
                                @if ($branch_common)
                                    <div class="d-flex align-items-center mt-2">
                                        <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                        <div>
                                            <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                            <small class="text-truncate max-w-10px text-muted"
                                                title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                                        </div>
                                    </div>
                                @else
                                @endif
                            @endif

                        @endif
                    </div>
                    <div class="col-lg-3 mb-3">
                        <label class="text-dark mb-1 fs-5 fw-semibold">Role<span class="text-danger">*</span></label>
                        <select id="role_filter" name="role_id" class="select3 form-select">
                            <!-- Options will be dynamically populated -->
                        </select>
                    </div>
                    <div class="col-lg-3 mb-4">
                        <div
                            class="reward-card px-4 py-3 text-center position-relative d-flex justify-content-between align-items-center">

                            <!-- Previous Month Button -->
                            <button type="button" id="prevMonthBtn"
                                class="btn btn-light shadow-sm d-flex align-items-center justify-content-center rounded-circle icon-nav-btn">
                                <i class="mdi mdi-arrow-left-circle-outline fs-3 text-secondary"></i>
                            </button>

                            <!-- Current Month Display -->
                            <div class="month-display px-4 py-2 mx-3 rounded-3">
                                <div class="fw-bold fs-5 text-dark text-capitalize" id="selectedMonth">
                                    {{ \Carbon\Carbon::now()->format('F') }}
                                </div>
                                <div class="small fw-semibold text-muted" id="selectedYear">
                                    ({{ \Carbon\Carbon::now()->year }})
                                </div>
                            </div>

                            <!-- Next Month Button -->
                            <button type="button" id="nextMonthBtn"
                                class="btn btn-light shadow-sm d-flex align-items-center justify-content-center rounded-circle icon-nav-btn">
                                <i class="mdi mdi-arrow-right-circle-outline fs-3 text-secondary"></i>
                            </button>
                        </div>
                    </div>
                    <div class="col-lg-3 mt-6">
                        <span id="incentiveStatusLabel" class="mt-1 fs-3 text-white px-2 py-5 rounded  fw-bold"
                            style="display: none;"></span>
                    </div>
                </div>



                <div class="row g-3 mt-3">

                    <!-- Improved 10x Award Section sales-->
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,35,16,33,34,32,36,20,41,42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 10x Award
                                </span>
                                <div>
                                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" 
                                        title="CR, BV and CV" class="ms-2 open-criteria-modal" data-role-visible="11,12,35,16,33,34,32,36,20,42" data-incentive="10x_award" data-title="10X Award Criteria">
                                        <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                    </a>
                                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Pre & Post Sale" class="ms-2 open-criteria-modal" data-role-visible="41" data-incentive="10x_award" data-title="10X Award Criteria">
                                        <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                    </a>
                                </div>
                                
                                <div class="position-absolute end-0 me-4" data-role-visible="11,35" data-bs-toggle="tooltip" data-bs-placement="right" title="Target Achieve date">
                                    <select id="daySelector" name="target_day" class="form-select form-select-sm w-auto select3" data-role-visible="11,35"></select>
                                </div>
                                <div class="position-absolute end-0" data-role-visible="11,12,35" data-bs-toggle="tooltip" data-bs-placement="right" title="Second Payment Check Include in 10X">
                                    <input class="form-check-input" type="checkbox" name="second_payment_check" id="second_payment_check" value="1">
                                </div>
                                <div class="position-absolute end-0" data-role-visible="33,34" data-bs-toggle="tooltip" data-bs-placement="right" title="Check Accepted Paper">
                                    <input class="form-check-input" type="checkbox" name="check_accepted_paper" id="check_accepted_paper" value="1">
                                </div>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="award10x" class="form-label fw-semibold mb-2 text-muted">
                                    Enter Reward Amount
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="award10x" class="form-control reward-input" name="award10x"
                                        placeholder="0" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                     {{-- Team 10x Incentive--}}
                    <div class="col-lg-4 mb-4" data-role-visible="41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-fast me-2 text-gold fs-5"></i> Team Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="All Pre & Post Sale Team Members Achieve in 10x Award" class="ms-2  open-criteria-modal" data-incentive="team_achievement_incentive" data-title="Team Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Reward -->
                                <div class="col-12">
                                    <label for="team_target" class="form-label fw-semibold text-muted">Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="team_target"
                                            id="team_target" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                     {{-- ABV Incentive--}}
                    <div class="col-lg-4 mb-4" data-role-visible="41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-fast me-2 text-gold fs-5"></i> ABV Achieve Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Achieve in Average Business Valuse Target" class="ms-2 open-criteria-modal" data-incentive="abv_incentive" data-title="ABV Achieve Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Reward -->
                                <div class="col-12">
                                    <label for="abv_achieved_reward" class="form-label fw-semibold text-muted">Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="abv_achieved_reward"
                                            id="abv_achieved_reward" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    

                    {{-- 10X Warrior --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,35">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-shield-star-outline me-2 text-gold fs-5"></i> 10x Warrior
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="10X for target consecutive months, they will be recognized as a 10X warrior"
                                    class="ms-2 open-criteria-modal" data-incentive="tenx_warrior" data-title="10x Warrior Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Percentage -->
                                <div class="col-6">
                                    <label for="warriorCount" class="form-label fw-semibold mb-2 text-muted">
                                        Enter Warrior Count
                                    </label>
                                    <div class="reward-input-container">
                                        <input type="text" id="warriorCount" class="form-control reward-input"
                                            name="warriorCount" placeholder="0" 
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                <!-- ECI Reward -->
                                <div class="col-6">
                                    <label for="eciRewards" class="form-label fw-semibold text-muted">Warrior Reward
                                        (%)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="warrior_reward"
                                            id="warrior_reward" placeholder="0" 
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>

                    {{-- Extra Achievement Award Journal--}}
                    <div class="col-lg-4 mb-4" data-role-visible="34">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-fast me-2 text-gold fs-5"></i> Extra Acheivement Award
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Morethan Goalset Target published per month Reward 1000 Per paper beyond 15th" class="ms-2 open-criteria-modal" data-incentive="exi" data-title="Extra Acheivement Award Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Percentage -->
                                <!-- <div class="col-6">
                                    <label for="journal_extra_count" class="form-label fw-semibold text-muted">Paper Count</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="journal_extra_count"
                                            id="journal_extra_count" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div> -->

                                <!-- ECI Reward -->
                                <div class="col-12">
                                    <label for="journal_extra_count" class="form-label fw-semibold text-muted">Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="journal_extra_reward"
                                            id="journal_extra_reward" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Double X Incentive Journal--}}
                    <div class="col-lg-4 mb-4" data-role-visible="34,33,41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5"></i> Double X Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="2X target papers published in amonth" class="ms-2 open-criteria-modal" data-incentive="doublex" data-title="Double X Incentive Criteria" data-role-visible="34,33">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="2X target in Pre & Post " class="ms-2 open-criteria-modal" data-incentive="doublex" data-title="Double X Incentive Criteria"  data-role-visible="41">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="double_x_reward" class="form-label fw-semibold mb-2 text-muted">
                                    2X Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="double_x_reward" class="form-control reward-input"
                                        name="double_x_reward" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Journal Performance Incentive -->
                     <div class="col-lg-4 mb-4" data-role-visible="34">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                            <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                <i class="fa-solid fa-chart-line me-2 text-gold fs-5"></i> Performance Incentive
                            </span>
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Metrics for Attendance, Consistent performance & reward" class="ms-2 open-criteria-modal" data-incentive="perform_incent" data-title="Performance Incentive Criteria" >
                                <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                            </a>
                            </div>

                            <div class="row g-3 text-start">
                                <div class="col-6">
                                    <label for="perform_incent_attend" class="form-label fw-semibold mb-2 text-muted">Attendance Percentage</label>
                                    <input type="text" id="perform_incent_attend" class="form-control reward-input" name="perform_incent_attend" placeholder="0"
                                    oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                </div>
                                <div class="col-6">
                                    <label for="outgoingCalls" class="form-label fw-semibold mb-2 text-muted">Reward</label>
                                            <input type="text" id="performanceReward" class="form-control reward-input" name="performanceReward" placeholder="Amount"
                                                oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                   

                    {{-- Early Cash Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,35,41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-fast me-2 text-gold fs-5"></i> ECI (Early Cash Incentive)
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="70% of their target by 15th of each month" class="ms-2 open-criteria-modal" data-incentive="eci" data-title="Early Cash Criteria" data-role-visible="11,12,16,35">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                                 <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="70% of their target by 15th or 20th of each month" class="ms-2 open-criteria-modal" data-incentive="eci" data-title="Early Cash Criteria" data-role-visible="41">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- ECI Percentage -->
                                <div class="col-4">
                                    <label for="eciCount" class="form-label fw-semibold text-muted">ECI %</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="eci_count"
                                            id="eciCount" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                <!-- ECI Reward -->
                                <div class="col-4" data-role-visible="11,12,16,35,41">
                                    <label for="eciRewards"data-role-visible="11,12,16,35" class="form-label fw-semibold text-muted">ECI Reward(₹)</label>
                                    <label for="eciRewards"  data-role-visible="41" class="form-label fw-semibold text-muted">15th Reward (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="eci_reward"
                                            id="eciRewards" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                 
                                <!-- ECI 20th Reward -->
                                <div class="col-4" data-role-visible="41">
                                    <label for="eci25thRewards" class="form-label fw-semibold text-muted">20th Reward(₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" class="form-control reward-input" name="eci25thRewards"
                                            id="eci25thRewards" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                 

                    {{-- Bonus Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11,12,35,41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5"></i> BI (Bonus Incentive)
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" data-role-visible="11,12,35"
                                    title="Per additional Customer Convert above the set target" class="ms-2 open-criteria-modal" data-incentive="bi" data-title="Bouns Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" data-role-visible="41"
                                    title="Per additional Customer Convert above the set target & Reward is Half of Sales BI" class="ms-2  open-criteria-modal" data-incentive="bi" data-title="Bouns Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="biAmount" class="form-label fw-semibold mb-2 text-muted">
                                    BI Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="biAmount" class="form-control reward-input"
                                        name="bi_amount" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Old Collection Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-target-variant me-2 text-gold fs-5"></i> Old Collection Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Reward for achieving 0% previous month's pending balance by successfully collecting all outstanding dues."  class="ms-2 open-criteria-modal" data-incentive="old_collection" data-title="Old Collection Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                              
                                <div class="col-6">
                                    <label for="old_month_collection_reward" class="form-label fw-semibold text-muted">Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="old_month_collection_reward" class="form-control reward-input"
                                            name="old_month_collection_reward" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                               
                                <div class="col-6">
                                    <label for="old_month_per" class="form-label fw-semibold text-muted">collection (%)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="old_month_per" class="form-control reward-input"
                                            name="old_month_per" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- OnDate Incentive Collection --}}
                    <div class="col-lg-4 mb-4" data-role-visible="42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-target-variant me-2 text-gold fs-5"></i> Ondate Collection Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="For Collecting 70% of bill before due date"  class="ms-2 open-criteria-modal" data-incentive="sp" data-title="Ondate Collection Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                              
                                <div class="col-6">
                                    <label for="spotMonthCre" class="form-label fw-semibold text-muted">Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spotMonthCre" class="form-control reward-input"
                                            name="spot_incentive_month_cre" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                               
                                <div class="col-6">
                                    <label for="spot_incentive_percent" class="form-label fw-semibold text-muted">collection (%)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spot_incentive_percent" class="form-control reward-input"
                                            name="spot_incentive_percent" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- 150% Incentive Collection--}}
                    <div class="col-lg-4 mb-4" data-role-visible="42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5"></i> 150% Collection
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Reward for successfully exceeding and achieving 150% of the assigned collection target." class="ms-2 open-criteria-modal" data-incentive="collection_150_percent" data-title="150% Collection Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="bi_collection_reward" class="form-label fw-semibold mb-2 text-muted">
                                    150% Collection Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="bi_collection_reward" class="form-control reward-input"
                                        name="bi_collection_reward" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div> 

                    <div class="col-lg-4 mb-4" data-role-visible="41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5"></i> ABV 150% Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" data-role-visible="41"
                                    title="Average Business Value Greater than Equal to 150%" class="ms-2 open-criteria-modal" data-incentive="abv_150_incentive" data-title="Bouns Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="abv_reward" class="form-label fw-semibold mb-2 text-muted">
                                    ABV Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="abv_reward" class="form-control reward-input"
                                        name="abv_reward" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                  
                    

                    {{-- Spot Incentive --}}
                    <div class="col-lg-4 mb-4" data-role-visible="11">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-target-variant me-2 text-gold fs-5"></i> Spot Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="On Month Converted customer, On Day Converted customer" class="ms-2 open-criteria-modal" data-incentive="sp" data-title="Spot Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- Month Reward -->
                                <div class="col-6">
                                    <label for="spotMonth" class="form-label fw-semibold text-muted">Month Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spotMonth" class="form-control reward-input"
                                            name="spot_incentive_month" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>

                                <!-- Day Reward -->
                                <div class="col-6">
                                    <label for="spotDay" class="form-label fw-semibold text-muted">Day Reward (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="spotDay" class="form-control reward-input"
                                            name="spot_incentive_day" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    
                    {{-- Issue Free Incentive Cre--}}
                    <div class="col-lg-4 mb-4" data-role-visible="16">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5" ></i> Issue Free Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Per Referral Successful upsell/Cross-sell" class="ms-2 open-criteria-modal" data-incentive="issue_free" data-title="Issue Free Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="issue_free" class="form-label fw-semibold mb-2 text-muted">
                                    Issue Free Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="issue_free" class="form-control reward-input"
                                        name="issue_free" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- Referral Incentive Cre--}}
                    <div class="col-lg-4 mb-4" data-role-visible="16,42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5" ></i> Referral Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Per Referral Successful upsell/Cross-sell" class="ms-2 open-criteria-modal" data-incentive="ri" data-title="Referral Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="riAmount" class="form-label fw-semibold mb-2 text-muted">
                                    RI Reward (₹)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="riAmount" class="form-control reward-input"
                                        name="ri_amount" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    {{-- Drop Incentive Cre--}}
                    <div class="col-lg-4 mb-4" data-role-visible="16,42">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-gift-outline me-2 text-gold fs-5" ></i> Drop Collection
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="5% reward for successful payment collected from drop customers." class="ms-2 open-criteria-modal" data-incentive="drop_collection" data-title="Drop Collection Criteria">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2 text-start">
                                <label for="drop_collection_reward" class="form-label fw-semibold mb-2 text-muted">
                                    RI Reward (%)
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="drop_collection_reward" class="form-control reward-input"
                                        name="drop_collection_reward" placeholder="0"  oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {{-- Strategy Incentive Lead--}}
                    <div class="col-lg-4 mb-4" data-role-visible="12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-target-variant me-2 text-gold fs-5"></i> Strategy Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Strategy Incentive: Flat ₹3,000 reward on achieving 100% team target" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">
                                <!-- Month Reward -->
                                <div class="col-12">
                                    <label for="si_lead_reward" class="form-label fw-semibold text-muted">SI Reward
                                        (₹) (100% target)</label> 
                                    <div class="reward-input-container">
                                        <input type="text" id="si_lead_reward" class="form-control reward-input"
                                            name="si_lead_reward" placeholder="0"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Profitable Incentive Lead--}}
                    <div class="col-lg-4 mb-4" data-role-visible="12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">

                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-success text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-cash-plus me-2 fs-5 text-gold"></i> Profitable Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="1.5% on excess value above ₹75,000" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">

                                <!-- Base Amount -->
                                <div class="col-6">
                                    <label for="pi_lead_base" class="form-label fw-semibold text-muted">Base Amount (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="pi_lead_base" class="form-control reward-input"
                                            name="pi_lead_base" placeholder="0" value="75000"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                    </div>
                                </div>
                                <!-- Percentage -->
                                <div class="col-6">
                                    <label for="pi_lead_percent" class="form-label fw-semibold text-muted">Percentage (%)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="pi_lead_percent" class="form-control reward-input"
                                            name="pi_lead_percent" placeholder="0" value="1.5"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                    </div>
                                </div>
                                <!-- Max Reward -->
                                <!-- <div class="col-4">
                                    <label for="pi_lead_reward" class="form-label fw-semibold text-muted">Max Reward
                                        (₹)</label>
                                    <div class="reward-input-container">
                                        <input type="text" id="pi_lead_reward" class="form-control reward-input"
                                            name="pi_lead_reward" placeholder="0" value="3000"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                    </div>
                                </div> -->

                            </div>
                        </div>
                    </div>


                    {{-- Spot Incentive Sales Lead--}}
                    <div class="col-lg-8 mb-4" data-role-visible="12">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">

                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="mdi mdi-target-variant me-2 text-gold"></i> Spot Incentive 
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="Flat ₹3,000 when Same-Day ≥ 20% and Same-Month ≥ 30%">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5 ms-2"></i>
                                </a>
                            </div>

                            <div class="row g-3 text-start">

                                <!-- Incentive Amount -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold text-muted">Incentive Reward (₹)</label>
                                        <input type="text" id="spotReward" class="form-control reward-input"
                                            name="spotReward" placeholder="0" value="3000"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                </div>

                                <!-- Same Day % -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold text-muted">Required Same-Day (%)</label>
                                        <input type="text" id="spotSameDay" class="form-control reward-input"
                                            name="spotSameDay" placeholder="0" value="20"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                </div>

                                <!-- Same Month % -->
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold text-muted">Required Same-Month (%)</label>    
                                        <input type="text" id="spotSameMonth" class="form-control reward-input"
                                            name="spotSameMonth" placeholder="0" value="30"
                                            oninput="this.value = this.value.replace(/[^0-9.]/g, '');">
                                </div>

                            </div>
                        </div>
                    </div>


                    <!-- Performance Incentive Section -->
                    <div class="col-lg-4 mb-4" data-role-visible="11,35">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3">
                            <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                <i class="fa-solid fa-chart-line me-2 text-gold fs-5"></i> Performance Incentive
                            </span>
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="Metrics for missed calls, outgoing calls & reward" class="ms-2 open-criteria-modal" data-incentive="perform_incent" data-title="Performance Incentive Criteria">
                                <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                            </a>
                            </div>

                            <div class="row g-3 text-start">
                            <div class="col-4">
                                <label for="missedCallRate" class="form-label fw-semibold mb-2 text-muted">Missed Call Rate</label>
                                <input type="text" id="missedCallRate" class="form-control reward-input" name="missedCallRate" placeholder="0"
                                oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                            </div>
                            <div class="col-8">
                                <label for="outgoingCalls" class="form-label fw-semibold mb-2 text-muted">Outgoing Calls Per Day</label>
                                <div class="row">
                                    <div class="col-6">
                                        <input type="text" id="outgoingCalls" class="form-control reward-input" name="outgoingCalls" placeholder="Count"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                    <div class="col-6">
                                        <input type="text" id="performanceReward" class="form-control reward-input" name="performanceReward" placeholder="Amount"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                    </div>
                                </div>
                            </div>
                            </div>
                        </div>
                    </div>

                    <!-- Strategy Incentive Section -->
                    <div class="col-lg-6" data-role-visible="11,35">
                        <label class="form-label fs-6 fw-bold">
                            SI (Strategy Incentive)
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" class="open-criteria-modal" data-incentive="si" data-title="Strategy Incentive"
                                title="If they exceed their Business value (BV) target by a certain percentage, they receive an additional PI reward.">
                                <i class="mdi mdi-help-circle text-dark"></i>
                            </a>
                        </label>

                        <div class="table-responsive mb-2">
                            <table class="table table-bordered table-sm text-center">
                                <thead class="table-light">
                                    <tr>
                                        <th class="bg-secondary text-white">From (%)</th>
                                        <th class="bg-secondary text-white">Receive (%)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1 to 10%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_1" id="pi_receive_1" value="" min="0"
                                                max="100"></td>
                                    </tr>
                                    <tr>
                                        <td>11 to 20%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_2" id="pi_receive_2" value="" min="0"
                                                max="100"></td>
                                    </tr>
                                    <tr>
                                        <td>21 to 30%</td>
                                        <td><input type="text" class="form-control form-control-sm text-center"
                                                name="pi_receive_3" id="pi_receive_3" min="0" max="100">
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- PI (Profitable Incentive) -->
                    <div class="col-lg-6" data-role-visible="11,35">
                        <label class="form-label fs-6 fw-bold">
                            PI (Profitable Incentive)
                            <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                title="Based on Minimum collection Value." class="open-criteria-modal" data-incentive="pi" data-title="Profitable Incentive">
                                <i class="mdi mdi-help-circle text-dark"></i>
                            </a>
                        </label>

                        <div class="table-responsive mb-2">
                            <table class="table table-bordered table-sm text-center">
                                <thead class="table-light">
                                    <tr>
                                        <th class="bg-secondary text-white">Min Amount (₹)</th>
                                        <th class="bg-secondary text-white">Max Amount (₹)</th>
                                        <th class="bg-secondary text-white">Reward (₹)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="min1" value="80000"></td>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="max1" value="100000"></td>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="reward1" value="1000"></td>
                                    </tr>

                                    <tr>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="min2" value="100001"></td>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="max2" value="150000"></td>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="reward2" value="2000"></td>
                                    </tr>

                                    <tr>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="min3" value="150001"></td>
                                        <td>
                                            <input type="text" class="form-control form-control-sm text-center" id="max3" value="" placeholder="No Limit" disabled>
                                        </td>
                                        <td><input type="text" class="form-control form-control-sm text-center" id="reward3" value="5000"></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>



                    <div class="col-lg-6 mb-4" data-role-visible="11,35">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-start position-relative">
                            <div class="reward-header d-flex justify-content-between align-items-center mb-3">
                                <span
                                    class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill d-flex align-items-center">
                                    <i class="mdi mdi-diamond-stone-outline me-2 text-gold fs-5"></i> Luxury Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" class="open-criteria-modal" data-incentive="li" data-title="Luxury Incentive"
                                    title="Includes all major monthly incentives totaling ₹10,000 or more.">
                                    <i class="mdi mdi-help-circle-outline text-secondary fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-3">
                                <label class="form-label fw-semibold mb-2 text-muted d-block">Select Applicable
                                    Incentives</label>

                                <div class="form-check mb-2" data-role-visible="11,12,35,16">
                                    <input class="form-check-input" type="checkbox" name="tenx_award" id="tenx_award"
                                        value="1">
                                    <label class="form-check-label" for="tenx_award">10x Award</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,16,35">
                                    <input class="form-check-input" type="checkbox" name="early_cash_incentive"
                                        id="early_cash_incentive" value="1">
                                    <label class="form-check-label" for="early_cash_incentive">Early Cash
                                        Incentive</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,16,35">
                                    <input class="form-check-input" type="checkbox" name="bonus_incentive"
                                        id="bonus_incentive" value="1">
                                    <label class="form-check-label" for="bonus_incentive">Bonus Incentive</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,35">
                                    <input class="form-check-input" type="checkbox" name="strategy_incentive"
                                        id="strategy_incentive" value="1">
                                    <label class="form-check-label" for="strategy_incentive">Strategy Incentive</label>
                                </div>
                                <div class="form-check mb-2" data-role-visible="11,12,35">
                                    <input class="form-check-input" type="checkbox" name="profitable_incentive"
                                        id="profitable_incentive" value="1">
                                    <label class="form-check-label" for="profitable_incentive">Profitable
                                        Incentive</label>
                                </div>
                                <div class="form-check mb-4" data-role-visible="11,12,16"> 
                                    <input class="form-check-input" type="checkbox" name="spot_incentive"
                                        id="spot_incentive" value="1">
                                    <label class="form-check-label" for="spot_incentive">Spot Incentive</label>
                                </div>
                                <div class="form-check mb-4" data-role-visible="11,12,35">
                                    <input class="form-check-input" type="checkbox" name="performance_incentive"
                                        id="performance_incentive" value="1">
                                    <label class="form-check-label" for="performance_incentive">Performance Incentive</label>
                                </div>
                                <div class="form-check mb-4" data-role-visible="16">
                                    <input class="form-check-input" type="checkbox" name="referral_incentive"
                                        id="referral_incentive" value="1">
                                    <label class="form-check-label" for="referral_incentive">Referral Incentive</label>
                                </div>
                                
                            </div>

                            <div class="reward-input-group">
                                <label for="luxuryRewardInput" class="form-label fw-semibold text-muted">Reward
                                    (₹)</label>
                                <div class="reward-input-container">
                                    <input type="text" id="luxuryRewardInput" class="form-control reward-input"
                                        name="luxury_reward" placeholder="0"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BH Incentive -->
                     <!-- ceiling -->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Ceiling Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Target < Actual" class="ms-2 open-criteria-modal" data-incentive="ceiling" data-title="Ceiling Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="ceiling" class="form-label fw-semibold mb-2 text-muted">
                                    Enter Reward %
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="ceiling" class="form-control reward-input" name="ceiling"
                                        placeholder="Enter %" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Quartaly -->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Quarterly Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Quarterly Bonus" class="ms-2 open-criteria-modal" data-incentive="quarterly" data-title="Quarterly Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="quarterly" class="form-label fw-semibold mb-2 text-muted">
                                    Enter Bonus Amount
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="quarterly" class="form-control reward-input" name="quarterly"
                                        placeholder="Enter Bonus" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 25% Incentiv -->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 25% Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="25%" class="ms-2 open-criteria-modal" data-incentive="twenty_five_percentage" data-title="25% Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="25percentage" class="form-label fw-semibold mb-2 text-muted">
                                    Percentage
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="25percentage" class="form-control reward-input" name="25percentage"
                                        placeholder="Enter %" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 50% Incentive -->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 50% Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="50%" class="ms-2 open-criteria-modal" data-incentive="fifty_percentage" data-title="50% Incentive Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="50percentage" class="form-label fw-semibold mb-2 text-muted">
                                    Percentage
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="50percentage" class="form-control reward-input" name="50percentage"
                                        placeholder="Enter %" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--6 Month-->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 6 Months
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="6 Months" class="ms-2 open-criteria-modal" data-incentive="six_month" data-title="6 Month Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="6month" class="form-label fw-semibold mb-2 text-muted">
                                    Reward
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="6month" class="form-control reward-input" name="6month"
                                        placeholder="Enter Reward" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- 12 Month-->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 12 Months
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="12 Months" class="ms-2 open-criteria-modal" data-incentive="twelve_month" data-title="12 Month Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="12month" class="form-label fw-semibold mb-2 text-muted">
                                    Reward
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="12month" class="form-control reward-input" name="12month"
                                        placeholder="Enter Reward" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Additionally 9 Month-->
                    <div class="col-lg-4 mb-4" data-role-visible="20, 41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill"  data-role-visible="20">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Additionally 9 Month
                                </span>
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill"  data-role-visible="41">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> 9 Month Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Achieve 10x Any 9 Month in A Financial Year" class="ms-2 open-criteria-modal" data-incentive="nine_monthadd" data-title="Additionally 9 Month Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="9monthadd" class="form-label fw-semibold mb-2 text-muted">
                                    Reward
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="9monthadd" class="form-control reward-input" name="9monthadd"
                                        placeholder="Enter Reward" >
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Additionally 12 Month-->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Additionally 12 Month
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Additionally 12 Month" class="ms-2 open-criteria-modal" data-incentive="twelve_monthadd" data-title="Additionally 12 Month Criteria">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="12monthadd" class="form-label fw-semibold mb-2 text-muted">
                                    Reward
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="12monthadd" class="form-control reward-input" name="12monthadd"
                                        placeholder="Enter Reward" >
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Overall Year-->
                    <div class="col-lg-4 mb-4" data-role-visible="20,41">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Overall Year
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Overall Year 150%" class="ms-2 open-criteria-modal" data-incentive="overall_year" data-title="Overall Year Criteria" data-role-visible="20">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Overall Year 150% Achieve Pre & Post Sale Count" class="ms-2 open-criteria-modal" data-incentive="yearly_150_incentive" data-title="Overall Year Criteria" data-role-visible="41">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="overall_year" class="form-label fw-semibold mb-2 text-muted">
                                    Reward
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="overall_year" class="form-control reward-input" name="overall_year"
                                        placeholder="Enter Reward" >
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Dynamic Incentive-->
             
                    <!-- Pre Sale Incentive-->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Pre Sale Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Presale 150%" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="presale" class="form-label fw-semibold mb-2 text-muted">
                                    Coin Gram
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="presale" class="form-control reward-input" name="presale"
                                        placeholder="Enter GMS" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Luxury Incentive-->
                    <div class="col-lg-4 mb-4" data-role-visible="20">
                        <div class="reward-card p-4 rounded-4 shadow-sm text-center position-relative">
                            <div class="reward-header d-flex justify-content-center align-items-center mb-3 position-relative">
                                <span class="badge badge-gradient-rich text-white fs-6 px-3 py-2 rounded-pill">
                                    <i class="fa-solid fa-trophy me-2 text-gold"></i> Luxury Incentive
                                </span>
                                <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right"
                                    title="Presale 150%" class="ms-2">
                                    <i class="mdi mdi-help-circle-outline text-muted fs-5"></i>
                                </a>
                            </div>

                            <div class="reward-input-group mt-2">
                                <label for="megabonus" class="form-label fw-semibold mb-2 text-muted">
                                    Bonus
                                </label>
                                <div class="reward-input-container">
                                    <input type="text" id="megabonus" class="form-control reward-input" name="megabonus"
                                        placeholder="Enter Bonus" oninput="this.value = this.value.replace(/[^0-9]/g, '');">
                                </div>
                            </div>
                        </div>
                    </div>

                   

                    
                </div>

            </div>

            <div class="d-flex justify-content-end align-items-center mt-1">
                <button type="button" class="btn btn-primary" id="updateincentiveButton">Update</button>
            </div>
        </div>
    </div>
    


    <div class="modal fade" id="criteriaModal" tabindex="-1" aria-labelledby="criteriaModalLabel" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title text-white" id="criteriaModalLabel">Incentive Criteria</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Hidden fields for context -->
                <input type="hidden" id="criteria_incentive_key" value="">
                <input type="hidden" id="criteria_role_id" value="">

                <!-- Add Criteria Form -->
                <div class="row g-3 mb-4">
                    <div class="col-md-8">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="criteria_point" placeholder="Enter criteria point">
                            <label for="criteria_point">Criteria Point</label>
                        </div>
                    </div>
                    <div class="col-md-4 d-flex align-items-end gap-2">
                        <button type="button" class="btn btn-success w-100" id="addCriteriaBtn">
                            <i class="mdi mdi-plus me-1"></i> Add To List
                        </button>
                    </div>
                </div>

                <!-- Criteria Table -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="criteriaTable">
                        <thead class="table bg-primary">
                            <tr>
                                <th width="5%">S.No</th>
                                <th width="75%">Criteria Points</th>
                                <th width="20%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="criteriaTableBody">
                            <!-- Rows will be dynamically added here -->
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="saveCriteriaBtn">Save</button>
            </div>
        </div>
    </div>
</div>


    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .goal-label {
            min-width: 200px;
            /* Ensures all labels are of equal width */
            text-align: left;
            /* Aligns text to the left for consistency */
        }
    </style> -->
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }
    
        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .goal-label {
                min-width: 200px; /* Ensures all labels are of equal width */
                text-align: left; /* Aligns text to the left for consistency */
            }
        .criteria-row {
            transition: all 0.3s ease;
        }
        .criteria-row:hover {
            background-color: #f8f9fa;
        }
        .criteria-row .form-control {
            border: 1px solid #ced4da;
            transition: border-color 0.15s ease-in-out;
        }
        .criteria-row .form-control:focus {
            border-color: #86b7fe;
            box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.25);
        }
        .remove-criteria {
            cursor: pointer;
            transition: all 0.2s;
        }
        .remove-criteria:hover {
            transform: scale(1.2);
            color: #dc3545 !important;
        }
    </style>
    <script>
        var currentMonth = new Date().getMonth() + 1; // Get current mont (1-12)
        var currentYear = new Date().getFullYear();

        function updateMonthDisplay() {
            let monthNames = [
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            ];
            $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
            document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
            document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

            document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
            document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

            fetchIncentiveData();
        }

        document.getElementById("prevMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 1) {
                currentMonth = 12;
                currentYear--;
            } else {
                currentMonth--;
            }
            updateMonthDisplay();
        });

        document.getElementById("nextMonthBtn").addEventListener("click", function(e) {
            e.preventDefault();
            if (currentMonth === 12) {
                currentMonth = 1;
                currentYear++;
            } else {
                currentMonth++;
            }
            updateMonthDisplay();
        });

        function showFieldsForRole(roleId) {

            $('[data-role-visible]').each(function() {
                let rolesAttr = $(this).data('role-visible');
                console.log("Checking element with data-role-visible:", rolesAttr);

                if (!rolesAttr) return;

                const roles = rolesAttr.toString().split(',').map(r => r.trim());

                const shouldShow = roles.includes(roleId.toString());
                console.log("Should show:", shouldShow);

                $(this).toggle(shouldShow);
            });
        }

        // DOM ready
        $(document).ready(function() {
            $('#role_filter').on('change', function() {
                const roleId = $(this).val();
                console.log('Changed role (fallback event):', roleId);
                showFieldsForRole(roleId);
            });

            // Trigger initial display logic
            const initialRoleId = $('#role_filter').val();
            showFieldsForRole(initialRoleId);
        });

        function fetchIncentiveData() {
            let branch_id = $('#branchSelectsgoal').val();
            let role_id = $('#role_filter').val();
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            if (branch_id && role_id) {
                $.ajax({
                    url: '/get-role-incentive-data',
                    type: 'GET',
                    data: {
                        branch_id: branch_id,
                        role_id: role_id,
                        month: month,
                        year: year
                    },
                    success: function(response) {
                        let data = response.data;
                        const statusLabel = $('#incentiveStatusLabel');
                        const updateButton = $('#updateincentiveButton');
                        if (response.status === 200 && data && data.previousMonth !=1) {
                            statusLabel
                                .text('Incentive already set ✅')
                                .removeClass('bg-danger')
                                .addClass('bg-success')
                                .show();
                            updateButton.text('Incentive Update').removeClass('btn-danger').addClass(
                                'btn-primary');
                            // Set simple input values
                            $('input[name="second_payment_check"]').val(data.second_payment_check);
                            $('input[name="check_accepted_paper"]').val(data.check_accepted_paper);
                            $('input[name="award10x"]').val(data.tenx_award);
                            $('input[name="team_target"]').val(data.team_target);
                            $('input[name="issue_free"]').val(data.issue_free);
                            $('input[name="drop_collection_reward"]').val(data.drop_collection_reward);
                            $('input[name="old_month_collection_reward"]').val(data.old_month_collection_reward);
                            $('input[name="old_month_per"]').val(data.old_month_per);
                            $('input[name="abv_achieved_reward"]').val(data.abv_achieved_reward);
                            $('input[name="warriorCount"]').val(data.tenx_warrior);
                            $('input[name="eci_count"]').val(data.eci_count);
                            $('input[name="warrior_reward"]').val(data.warrior_reward);
                            $('input[name="eci_reward"]').val(data.eci_reward);
                            $('input[name="bi_amount"]').val(data.bi_amount);
                            $('input[name="ri_amount"]').val(data.ri_amount);
                             $('input[name="double_x_reward"]').val(data.double_x_reward);
                             $('input[name="perform_incent_attend"]').val(data.perform_incent_attend);
                             $('input[name="journal_extra_reward"]').val(data.journal_extra_reward);
                             $('input[name="journal_extra_count"]').val(data.journal_extra_count);
                             $('input[name="spot_incentive_month_cre"]').val(data.spot_incentive_month);
                             $('input[name="bi_collection_reward"]').val(data.bi_collection_reward);
                            $('input[name="spot_incentive_percent"]').val(data.spot_incentive_percent);
                            $('input[name="spot_same_month_percent"]').val(data.spot_same_month_percent);
                            $('input[name="spot_same_day_percent"]').val(data.spot_same_day_percent);
                            $('input[name="si_lead_reward"]').val(data.si_lead_reward);
                            $('input[name="pi_lead_base"]').val(data.pi_lead_base);
                            // $('input[name="pi_lead_reward"]').val(data.pi_lead_reward);
                            $('input[name="pi_lead_percent"]').val(data.pi_lead_percent);
                            $('input[name="spot_incentive_month"]').val(data.spot_incentive_month);
                            $('input[name="spot_incentive_day"]').val(data.spot_incentive_day);
                            $('input[name="missedCallRate"]').val(data.performance_incentive_missed_call);
                            $('input[name="outgoingCalls"]').val(data.performance_incentive_outgoing_call_count);
                            $('input[name="performanceReward"]').val(data.performance_incentive_reward);
                            $('#second_payment_check').prop('checked', data.second_payment_check == 1);
                            $('#check_accepted_paper').prop('checked', data.check_accepted_paper == 1);

                            $('input[name="ceiling"]').val(data.ceiling);
                            $('input[name="quarterly"]').val(data.quarterly);
                            $('input[name="25percentage"]').val(data.twenty_five_percentage);
                            $('input[name="50percentage"]').val(data.fifty_percentage);
                            $('input[name="6month"]').val(data.six_month);
                            $('input[name="12month"]').val(data.twelve_month);
                            $('input[name="9monthadd"]').val(data.nine_monthadd);
                            $('input[name="12monthadd"]').val(data.twelve_monthadd);
                            $('input[name="overall_year"]').val(data.overall_year);
                            $('input[name="dynamic"]').val(data.dynamic);
                            $('input[name="presale"]').val(data.presale);
                            $('input[name="megabonus"]').val(data.megabonus);

                            // bdm
                              $('input[name="eci25thRewards"]').val(data.eci_second_reward);
                              $('input[name="abv_reward"]').val(data.abv_reward);
                              $('select[name="target_day"]').val(data.target_day).change();
                                
                            // -----------------------------
                            // 🎯 Fetch and fill LI (Luxury Incentive) JSON
                            // -----------------------------
                            let incentives = JSON.parse(data.luxury_incentive || '{}');
                            
                            $('#tenx_award').prop('checked', incentives.tenx_award == 1);
                            $('#early_cash_incentive').prop('checked', incentives.early_cash_incentive == 1);
                            $('#bonus_incentive').prop('checked', incentives.bonus_incentive == 1);
                            $('#strategy_incentive').prop('checked', incentives.strategy_incentive == 1);
                            $('#profitable_incentive').prop('checked', incentives.profitable_incentive == 1);
                            $('#spot_incentive').prop('checked', incentives.spot_incentive == 1);
                            $('#performance_incentive').prop('checked', incentives.performance_incentive == 1);
                            $('#referral_incentive').prop('checked', incentives.referral_incentive == 1);
                            $('#doublex_incentive').prop('checked', incentives.doublex_incentive == 1);
                            $('#abv_incentive').prop('checked', incentives.abv_incentive == 1);

                            // New: set reward value (if present)
                            if (incentives.reward !== undefined) {
                                $('input[name="luxury_reward"]').val(incentives.reward);
                            } else {
                                $('input[name="luxury_reward"]').val('');
                            }

                            // -----------------------------
                            // 🎯 Fetch and fill PI Slab JSON
                            // -----------------------------
                          
                            let si_slab = JSON.parse(data.si_incentive_json || '[]');
                            // Loop and set if available (max 3 slabs)
                            for (let i = 0; i < 3; i++) {
                                let slab = si_slab[i] || {};
                                $(`input[name="pi_from_${i + 1}"]`).val(slab.from || '');
                                $(`input[name="pi_to_${i + 1}"]`).val(slab.to || '');
                                $(`input[name="pi_receive_${i + 1}"]`).val(slab.percentage || '');
                            }

                            let pi_slab = JSON.parse(data.pi_slab_json || '[]');
                            // Loop and set if available (max 3 slabs)
                            for (let i = 0; i < 4; i++) {
                                let slab = pi_slab[i] || {};

                                $(`#min${i + 1}`).val(slab.min ?? '');
                                $(`#max${i + 1}`).val(slab.max ?? '');
                                $(`#reward${i + 1}`).val(slab.reward ?? '');
                            }

                            let spot_lead_incentive = JSON.parse(data.spot_incentive_lead || '{}');
                            
                            $('#spotReward').val(spot_lead_incentive.reward || 0);
                            $('#spotSameDay').val(spot_lead_incentive.same_day_percent || 0);
                            $('#spotSameMonth').val(spot_lead_incentive.same_month_percent || 0);

                        }else if (response.status === 200 && data && data.previousMonth ==1) {
                             statusLabel
                                .text('Incentive not set ⚠️')
                                .removeClass('bg-success')
                                .addClass('bg-danger')
                                .show();
                            updateButton.text('Incentive Add').removeClass('btn-primary').addClass(
                                'btn-primary');
                            // Set simple input values
                            $('input[name="second_payment_check"]').val(data.second_payment_check);
                            $('input[name="check_accepted_paper"]').val(data.check_accepted_paper);
                            $('input[name="award10x"]').val(data.tenx_award);
                            $('input[name="team_target"]').val(data.team_target);
                            $('input[name="issue_free"]').val(data.issue_free);
                            $('input[name="old_month_per"]').val(data.old_month_per);
                            $('input[name="old_month_collection_reward"]').val(data.old_month_collection_reward);
                            $('input[name="drop_collection_reward"]').val(data.drop_collection_reward);
                            $('input[name="abv_achieved_reward"]').val(data.abv_achieved_reward);
                            $('input[name="warriorCount"]').val(data.tenx_warrior);
                            $('input[name="eci_count"]').val(data.eci_count);
                            $('input[name="warrior_reward"]').val(data.warrior_reward);
                            $('input[name="eci_reward"]').val(data.eci_reward);
                            $('input[name="bi_amount"]').val(data.bi_amount);
                             $('input[name="ri_amount"]').val(data.ri_amount);
                            $('input[name="double_x_reward"]').val(data.double_x_reward);
                            $('input[name="perform_incent_attend"]').val(data.perform_incent_attend);
                             $('input[name="journal_extra_reward"]').val(data.journal_extra_reward);
                             $('input[name="journal_extra_count"]').val(data.journal_extra_count);
                             $('input[name="spot_incentive_month_cre"]').val(data.spot_incentive_month);
                             $('input[name="bi_collection_reward"]').val(data.bi_collection_reward);
                            $('input[name="spot_incentive_percent"]').val(data.spot_incentive_percent);
                            $('input[name="spot_same_month_percent"]').val(data.spot_same_month_percent);
                            $('input[name="spot_same_day_percent"]').val(data.spot_same_day_percent);
                            $('input[name="si_lead_reward"]').val(data.si_lead_reward);
                            $('input[name="pi_lead_base"]').val(data.pi_lead_base);
                            // $('input[name="pi_lead_reward"]').val(data.pi_lead_reward);
                            $('input[name="pi_lead_percent"]').val(data.pi_lead_percent);
                            $('input[name="spot_incentive_month"]').val(data.spot_incentive_month);
                            $('input[name="spot_incentive_day"]').val(data.spot_incentive_day);
                            $('input[name="missedCallRate"]').val(data.performance_incentive_missed_call);
                            $('input[name="outgoingCalls"]').val(data.performance_incentive_outgoing_call_count);
                            $('input[name="performanceReward"]').val(data.performance_incentive_reward);
                            $('#second_payment_check').prop('checked', data.second_payment_check == 1);
                            $('#check_accepted_paper').prop('checked', data.check_accepted_paper == 1);

                            $('input[name="ceiling"]').val(data.ceiling);
                            $('input[name="quarterly"]').val(data.quarterly);
                            $('input[name="25percentage"]').val(data.twenty_five_percentage);
                            $('input[name="50percentage"]').val(data.fifty_percentage);
                            $('input[name="6month"]').val(data.six_month);
                            $('input[name="12month"]').val(data.twelve_month);
                            $('input[name="9monthadd"]').val(data.nine_monthadd);
                            $('input[name="12monthadd"]').val(data.twelve_monthadd);
                            $('input[name="overall_year"]').val(data.overall_year);
                            $('input[name="dynamic"]').val(data.dynamic);
                            $('input[name="presale"]').val(data.presale);
                            $('input[name="megabonus"]').val(data.megabonus);

                            $('input[name="eci25thRewards"]').val(data.eci_second_reward);
                            $('input[name="abv_reward"]').val(data.abv_reward);
                            $('select[name="target_day"]').val(data.target_day).change();
                            $('#daySelector').val(data.target_day);
                            // -----------------------------
                            // 🎯 Fetch and fill LI (Luxury Incentive) JSON
                            // -----------------------------
                            let incentives = JSON.parse(data.luxury_incentive || '{}');
                            
                            $('#tenx_award').prop('checked', incentives.tenx_award == 1);
                            $('#early_cash_incentive').prop('checked', incentives.early_cash_incentive == 1);
                            $('#bonus_incentive').prop('checked', incentives.bonus_incentive == 1);
                            $('#strategy_incentive').prop('checked', incentives.strategy_incentive == 1);
                            $('#profitable_incentive').prop('checked', incentives.profitable_incentive == 1);
                            $('#spot_incentive').prop('checked', incentives.spot_incentive == 1);
                            $('#performance_incentive').prop('checked', incentives.performance_incentive == 1);
                            $('#referral_incentive').prop('checked', incentives.referral_incentive == 1);
                            $('#doublex_incentive').prop('checked', incentives.doublex_incentive == 1);
                            $('#abv_incentive').prop('checked', incentives.abv_incentive == 1);

                            // New: set reward value (if present)
                            if (incentives.reward !== undefined) {
                                $('input[name="luxury_reward"]').val(incentives.reward);
                            } else {
                                $('input[name="luxury_reward"]').val('');
                            }

                            // -----------------------------
                            // 🎯 Fetch and fill PI Slab JSON
                            // -----------------------------
                            
                            let si_slab = JSON.parse(data.si_incentive_json || '[]');
                            // Loop and set if available (max 3 slabs)
                            for (let i = 0; i < 3; i++) {
                                let slab = si_slab[i] || {};
                                $(`input[name="pi_from_${i + 1}"]`).val(slab.from || '');
                                $(`input[name="pi_to_${i + 1}"]`).val(slab.to || '');
                                $(`input[name="pi_receive_${i + 1}"]`).val(slab.percentage || '');
                            }

                            let pi_slab = JSON.parse(data.pi_slab_json || '[]');
                            // Loop and set if available (max 3 slabs)
                            for (let i = 0; i < 4; i++) {
                                let slab = pi_slab[i] || {};

                                $(`#min${i + 1}`).val(slab.min ?? '');
                                $(`#max${i + 1}`).val(slab.max ?? '');
                                $(`#reward${i + 1}`).val(slab.reward ?? '');
                            }

                            let spot_lead_incentive = JSON.parse(data.spot_incentive_lead || '{}');
                            
                            $('#spotReward').val(spot_lead_incentive.reward || 0);
                            $('#spotSameDay').val(spot_lead_incentive.same_day_percent || 0);
                            $('#spotSameMonth').val(spot_lead_incentive.same_month_percent || 0);
                            

                        }else {
                            statusLabel
                                .text('Incentive not set ⚠️')
                                .removeClass('bg-success')
                                .addClass('bg-danger')
                                .show();
                            console.log('No data found. Resetting fields to default.');
                            updateButton.text('Incentive Add').removeClass('btn-primary').addClass(
                                'btn-primary');
                            // Reset text/number fields
                            $('input[type="text"], input[type="number"]').val('');
                            // Uncheck checkboxes
                            $('input[type="checkbox"]').prop('checked', false);
                        }
                    },
                    error: function(xhr) {
                        console.error('Error fetching incentive data:', xhr.responseJSON?.message || xhr
                            .statusText);
                    }
                });
            }
        }

        // Trigger fetch on dropdown change
        $(document).ready(function() {
            $('#branchSelectsgoal, #role_filter').change(fetchIncentiveData);
            fetchIncentiveData(); // Fetch on load
        });




        fetchRoles();

        function fetchRoles() {
            $.ajax({
                url: "{{ route('incentive_role') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $("#role_filter");
                        selectDropdown.empty().append('<option value="">Select Role</option>');

                        // Filter departments with sno 11, 12, 13, 14, 17, 22
                        let filteredData = response.data.filter(dept => [20,11, 12,35,16,33,34,36,32,41,42].includes(dept.sno));

                        filteredData.forEach(function(dept) {
                            selectDropdown.append($('<option></option>')
                                .attr('value', dept.sno)
                                .text(dept.role_name));
                        });

                        // Set default selected value to 12
                        selectDropdown.val(11).trigger('change');
                    }
                },
                error: function(error) {
                    console.error('Error fetching departments:', error);
                }
            });
        }


        $('#updateincentiveButton').click(function() {

            const valuesToCheck = [
                $('#award10x').val(),
                $('#abv_achieved_reward').val(),
                $('#team_target').val(),
                $('#issue_free').val(),
                $('#drop_collection_reward').val(),
                $('#old_month_per').val(),
                $('#old_month_collection_reward').val(),
                $('#second_payment_check').val(),
                $('#check_accepted_paper').val(),
                $('#warriorCount').val(),
                $('#eciCount').val(),
                $('#eciRewards').val(),
                $('#biAmount').val(),
                $('#bi_collection_reward').val(),
                $('#riAmount').val(),
                $('#spotMonth').val(),
                $('#spotMonthCre').val(),
                $('#spotDay').val(),
                $('#spot_incentive_percent').val(),
                $('#missedCallRate').val(),
                $('#outgoingCalls').val(),
                $('#performanceReward').val(),
                $('#pi_receive_1').val(),
                $('#pi_receive_2').val(),
                $('#pi_receive_3').val(),
                $('#luxuryRewardInput').val()
            ];

            // Convert to numbers and check if at least one is greater than 0
            const hasAtLeastOneValue = valuesToCheck.some(val => parseFloat(val) > 0);

            if (!hasAtLeastOneValue) {
                toastr.error('Enter atleast one field.');
                return; // Stop submission
            }


            let incentives = {
                tenx_award: $('#tenx_award').prop('checked') ? 1 : 0,
                early_cash_incentive: $('#early_cash_incentive').prop('checked') ? 1 : 0,
                bonus_incentive: $('#bonus_incentive').prop('checked') ? 1 : 0,
                strategy_incentive: $('#strategy_incentive').prop('checked') ? 1 : 0,
                profitable_incentive: $('#profitable_incentive').prop('checked') ? 1 : 0,
                spot_incentive: $('#spot_incentive').prop('checked') ? 1 : 0,
                performance_incentive: $('#performance_incentive').prop('checked') ? 1 : 0, 
                referral_incentive: $('#referral_incentive').prop('checked') ? 1 : 0, 
                doublex_incentive: $('#doublex_incentive').prop('checked') ? 1 : 0, 
                abv_incentive: $('#abv_incentive').prop('checked') ? 1 : 0, 
                reward: $('input[name="luxury_reward"]').val() || 0
            };
            let spot_incentive_lead = {
                reward: $('#spotReward').val() || 0,
                same_day_percent: $('#spotSameDay').val() || 0,
                same_month_percent: $('#spotSameMonth').val() || 0,
            };

            let si_incentive_json  = [{
                    min: 1,
                    max: 10,
                    percentage: parseFloat($('input[name="pi_receive_1"]').val()) || 0
                },
                {
                    min: 11,
                    max: 20,
                    percentage: parseFloat($('input[name="pi_receive_2"]').val()) || 0
                },
                {
                    min: 21,
                    max: 30,
                    percentage: parseFloat($('input[name="pi_receive_3"]').val()) || 0
                }
            ];

            let pi_slab = getSIIncentiveJSON();

            let data = {
                month: $("#selectedMonth").text().trim(),
                year: $("#selectedYear").text().trim().replace(/[()]/g, ''),
                branch_id: $('#branchSelectsgoal').val(),
                role_id: $('#role_filter').val(),
                second_payment_check: $('#second_payment_check').prop('checked') ? 1 : 0,
                check_accepted_paper: $('#check_accepted_paper').prop('checked') ? 1 : 0,
                tenx_award: $('input[name="award10x"]').val(),
                team_target: $('input[name="team_target"]').val(),
                issue_free: $('input[name="issue_free"]').val(),
                old_month_per: $('input[name="old_month_per"]').val(),
                old_month_collection_reward: $('input[name="old_month_collection_reward"]').val(),
                drop_collection_reward: $('input[name="drop_collection_reward"]').val(),
                abv_achieved_reward: $('input[name="abv_achieved_reward"]').val(),
                tenx_warrior: $('input[name="warriorCount"]').val(),
                eci_count: $('input[name="eci_count"]').val(),
                warrior_reward: $('input[name="warrior_reward"]').val(),
                eci_reward: $('input[name="eci_reward"]').val(),
                bi_amount: $('input[name="bi_amount"]').val() ,
                bi_collection_reward: $('input[name="bi_collection_reward"]').val() ,
                si_lead_reward: $('input[name="si_lead_reward"]').val(),
                spot_incentive_percent: $('input[name="spot_incentive_percent"]').val(),
                ri_amount: $('input[name="ri_amount"]').val(),
                pi_lead_base: $('input[name="pi_lead_base"]').val(),
                pi_lead_percent: $('input[name="pi_lead_percent"]').val(),
                spot_incentive_month: $('input[name="spot_incentive_month"]').val() || $('input[name="spot_incentive_month_cre"]').val() ,
                spot_incentive_day: $('input[name="spot_incentive_day"]').val(),
                performance_incentive_missed_call: $('input[name="missedCallRate"]').val(),
                performance_incentive_outgoing_call_count: $('input[name="outgoingCalls"]').val(),
                performance_incentive_reward: $('input[name="performanceReward"]').val(),
                journal_extra_reward: $('input[name="journal_extra_reward"]').val(),
                journal_extra_count: $('input[name="journal_extra_count"]').val(),
                double_x_reward: $('input[name="double_x_reward"]').val(),
                perform_incent_attend: $('input[name="perform_incent_attend"]').val(),
                luxury_incentive: JSON.stringify(incentives),
                spot_incentive_lead: JSON.stringify(spot_incentive_lead),
                si_incentive_json:  JSON.stringify(si_incentive_json),
                pi_slab_json: pi_slab, // ✅ new field
                // bh roles
                ceiling: $('input[name="ceiling"]').val(),
                quarterly: $('input[name="quarterly"]').val(),
                twenty_five_percentage: $('input[name="25percentage"]').val(),
                fifty_percentage: $('input[name="50percentage"]').val(),
                six_month: $('input[name="6month"]').val(),
                twelve_month: $('input[name="12month"]').val(),
                nine_monthadd: $('input[name="9monthadd"]').val(),
                twelve_monthadd: $('input[name="12monthadd"]').val(),
                overall_year: $('input[name="overall_year"]').val(),
                dynamic: $('input[name="dynamic"]').val(),
                presale: $('input[name="presale"]').val(),
                megabonus: $('input[name="megabonus"]').val(),
                eci_second_reward: $('input[name="eci25thRewards"]').val(),
                abv_reward: $('input[name="abv_reward"]').val(),
                target_day: $('select[name="target_day"]').val(),
            };

            $.ajax({
                url: '/incentive-create-update',
                type: 'POST',
                data: data,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success('Incentive Updated Successfully!');
                    } else {
                        toastr.error(response.message);
                    }
                },
                error: function(xhr) {
                    alert('Error: ' + xhr.responseJSON.message);
                }
            });
        });
    </script>

    <script>
        function getSIIncentiveJSON() {
            var min1 =document.getElementById('min1');
            var max1 =document.getElementById('max1');
            var reward1 =document.getElementById('reward1');

            var min2 =document.getElementById('min2');
            var max2 =document.getElementById('max2');
            var reward2 =document.getElementById('reward2');

            var min3 =document.getElementById('min3');
            var max3 =document.getElementById('max3');
            var reward3 =document.getElementById('reward3');

            return JSON.stringify([
                {
                    min: parseInt(min1.value),
                    max: parseInt(max1.value),
                    reward: parseInt(reward1.value)
                },
                {
                    min: parseInt(min2.value),
                    max: parseInt(max2.value),
                    reward: parseInt(reward2.value)
                },
                {
                    min: parseInt(min3.value),
                    max: null,
                    reward: parseInt(reward3.value)
                }
            ]);
        }

    </script>
    <script>
            generateDays();
        function generateDays(selectedDay = null) {
            let totalDays = new Date(currentYear, currentMonth, 0).getDate();
    
            let dropdown = $("#daySelector");
            dropdown.empty();
    
            for (let i = 1; i <= totalDays; i++) {
                dropdown.append(`<option value="${i}">${i}</option>`);
            }
    
            // restore saved value OR default last day
            if (selectedDay) {
                dropdown.val(selectedDay);
            } else {
                dropdown.val(totalDays);
            }
        }
    </script>
    <script>
        
  // Criteria Modal Functions
  let criteriaCounter = 0;

  // Open modal when clicking help icon
  $(document).on('click', '.open-criteria-modal', function(e) {
      e.preventDefault();
      const incentiveKey = $(this).data('incentive');
      const title = $(this).data('title') || 'Criteria Details';
      const roleId = $('#role_filter').val();

      if (!roleId) {
          toastr.warning('Please select a role first');
          return;
      }

      $('#criteriaModalLabel').text(title);
      $('#criteria_incentive_key').val(incentiveKey);
      $('#criteria_role_id').val(roleId);

      criteriaCounter = 0;
      $('#criteriaTableBody').empty();

      // Fetch existing criteria
      fetchCriteriaData(incentiveKey, roleId);

      const modal = new bootstrap.Modal(document.getElementById('criteriaModal'));
      modal.show();
  });

  // Add criteria point
  $('#addCriteriaBtn').on('click', function() {
      addCriteriaRow();
  });

  // Add on Enter key
  $('#criteria_point').on('keypress', function(e) {
      if (e.which === 13) {
          e.preventDefault();
          addCriteriaRow();
      }
  });

  // Remove criteria row
  $(document).on('click', '.remove-criteria', function() {
      $(this).closest('tr').remove();
      renumberRows();
  });

  // Save criteria
  $('#saveCriteriaBtn').on('click', function() {
      saveCriteria();
  });

  function addCriteriaRow() {
      const point = $('#criteria_point').val().trim();
      if (!point) {
          toastr.warning('Please enter a criteria point');
          return;
      }

      criteriaCounter++;
      const newRow = `
          <tr class="criteria-row">
              <td class="text-center">${criteriaCounter}</td>
              <td>
                  <input type="text" class="form-control form-control-sm criteria-input" value="${escapeHtml(point)}" placeholder="Enter criteria point">
              </td>
              <td class="text-center">
                  <i class="mdi mdi-trash-can-outline text-danger remove-criteria" style="cursor:pointer;" title="Remove"></i>
              </td>
          </tr>
      `;

      $('#criteriaTableBody').append(newRow);
      $('#criteria_point').val('').focus();
  }

  function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
  }

  function renumberRows() {
      $('#criteriaTableBody tr').each(function(index) {
          $(this).find('td:first').text(index + 1);
      });
      criteriaCounter = $('#criteriaTableBody tr').length;
  }

  function fetchCriteriaData(incentiveKey, roleId) {
      const branchId = $('#branchSelectsgoal').val();
      const month = $("#selectedMonth").text().trim();
      const year = $("#selectedYear").text().trim().replace(/[()]/g, '');

      $.ajax({
          url: '/get-incentive-criteria',
          type: 'GET',
          data: {
              incentive_key: incentiveKey,
              role_id: roleId,
              branch_id: branchId,
              month: month,
              year: year
          },
          success: function(response) {
              if (response.status === 200 && response.data) {
                  const criteria = response.data;
                  if (criteria && criteria.criteria_points) {
                      try {
                          const points = JSON.parse(criteria.criteria_points);
                          if (Array.isArray(points) && points.length > 0) {
                              points.forEach(function(point, index) {
                                  criteriaCounter++;
                                  const row = `
                                      <tr class="criteria-row">
                                          <td class="text-center">${index + 1}</td>
                                          <td>
                                              <input type="text" class="form-control form-control-sm criteria-input" value="${escapeHtml(point)}" placeholder="Enter criteria point">
                                          </td>
                                          <td class="text-center">
                                              <i class="mdi mdi-trash-can-outline text-danger remove-criteria" style="cursor:pointer;" title="Remove"></i>
                                          </td>
                                      </tr>
                                  `;
                                  $('#criteriaTableBody').append(row);
                              });
                              criteriaCounter = points.length;
                          }
                      } catch (e) {
                          console.error('Error parsing criteria points:', e);
                      }
                  }
              }
          },
          error: function(xhr) {
              console.error('Error fetching criteria:', xhr);
          }
      });
  }

  function saveCriteria() {
      const incentiveKey = $('#criteria_incentive_key').val();
      const roleId = $('#criteria_role_id').val();
      const branchId = $('#branchSelectsgoal').val();
      const month = $("#selectedMonth").text().trim();
      const year = $("#selectedYear").text().trim().replace(/[()]/g, '');

      // Collect all criteria points
      const points = [];
      $('#criteriaTableBody tr').each(function() {
          const input = $(this).find('.criteria-input');
          if (input.length) {
              const val = input.val().trim();
              if (val) {
                  points.push(val);
              }
          }
      });

      if (points.length === 0) {
          toastr.warning('Please add at least one criteria point');
          return;
      }

      const data = {
          incentive_key: incentiveKey,
          role_id: roleId,
          branch_id: branchId,
          month: month,
          year: year,
          criteria_points: JSON.stringify(points)
      };

      const saveBtn = $('#saveCriteriaBtn');
      saveBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2"></span> Saving...');

      $.ajax({
          url: '/save-incentive-criteria',
          type: 'POST',
          data: data,
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function(response) {
              if (response.status === 200) {
                  toastr.success('Criteria saved successfully!');
                  setTimeout(function() {
                      const modal = bootstrap.Modal.getInstance(document.getElementById('criteriaModal'));
                      if (modal) modal.hide();
                  }, 1000);
              } else {
                  toastr.error(response.message || 'Failed to save criteria');
              }
          },
          error: function(xhr) {
              toastr.error('Error saving criteria: ' + (xhr.responseJSON?.message || xhr.statusText));
          },
          complete: function() {
              saveBtn.prop('disabled', false).text('Save');
          }
      });
  }

  // Reset modal when closed
  $('#criteriaModal').on('hidden.bs.modal', function() {
      $('#criteria_point').val('');
  });
    </script>
@endsection
