@extends('layouts/blankLayout')

@section('title', 'Razorpay Payment')
@section('content')

<div></div>
<div id="loader" style="display:block; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:9999;">
<div class="spinner"></div>
    <p>Please Wait...</p> 
</div>

<style>
.spinner {
  border: 8px solid #f3f3f3;
  border-top: 8px solid #099dd9;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
    
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
     var page_encrypt_id = "{{ $page_id }}";
           window.onload = function () {
                document.body.style.zoom = "110%"; // Works in most browsers
            }
        var options = {
            "key": "{{ $razorpay_key }}",
            "amount": "{{ $amount  }} ",
            "currency": "INR",
            "name": "Elysium Technologies",
           "image": "https://erp.elysiumtechnologies.com/logos/etpl_logo.png",
            "description": "Software Consulting",
            "order_id": "{{ $order_id }}",
            "handler": function (response) {
                 response.slot_id = "{{ $slot_id }}";
                 response.prps_id = "{{ $prps_id }}";
                      // ✅ Show loader before request
                     document.getElementById("loader").style.display = "block";
                fetch("{{ route('pay_success') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: JSON.stringify(response)
                })
                .then(res => res.json())
                .then(data => {
                    // ✅ Hide loader after response
                    document.getElementById("loader").style.display = "none";
                    if(data.status === 'success') {
                        if(data.lead_status !=4){
                            window.location.href = '/manage_nda/nda_message/' + data.encrypt_id;
                        }else{
                             window.location.href = '/manage_proposal/payments/' + page_encrypt_id;
                        // window.close();
                        }
                        
                    }else {
                          window.location.href = '/manage_proposal/payments/' + page_encrypt_id;
                        //  window.close();
                    }
                });
            },
            "theme": {
                "color": "#099dd9",
                "image_padding": false
            },
            "modal": {
                "ondismiss": function() {
                       window.location.href = '/manage_proposal/payments/' + page_encrypt_id;
                    // window.close();
                },
                "escape": true,
                "backdropclose": false
            }
        };
        var rzp = new Razorpay(options);
        rzp.open();
    </script>
@endsection
