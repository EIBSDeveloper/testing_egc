@extends('layouts/blankLayout')

@section('title', 'Proposal Confirmation')
@section('content')

<style>
    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }

    @media (max-width: 576px) {
        .min-w-xs-320px {
            width: 320px !important;
        }

        .max-w-xs-576px {
            width: 576px !important;
        }

        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-39 {
            width: 39% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-39 {
            width: 39% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-14 {
            width: 14% !important;
        }

        .w-md-49 {
            width: 49% !important;
        }

        .w-md-50 {
            width: 59% !important;
        }

        .w-md-74 {
            width: 74% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {
        .w-lg-210mm {
            width: 210mm !important;
        }

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
</style>
<center>
    <div class="w-lg-210mm w-xs-100 w-sm-100 w-md-100 ">
        <div style="font-size:30px; font-weight:bold;color:black;text-align:center !important;padding:20px 0px 15px 0px;">
            <label>Payment Details</label>
        </div>
        <div style='display:flex;align-items:start !important;flex-wrap:wrap;padding-left:10px;padding-right:10px;padding-top:10px;'>
            <div class="table-responsive" style="width:100% !important;padding-left: 10px !important;padding-right: 10px !important;">
                <table style='width:100% !important;'>
                    <thead>
                        <tr>
                            <th rowspan="2" style="width: 10% !important;">
                                <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" style="height: 80px;width: 180px;">
                            </th>
                            <th style="text-align: center; width: 90% !important;" colspan="2">
                                <label style="font-size:16px;font-weight:700;margin-left:50px;color:black;"># PRO-003669/03/2025</label>
                            </th>
                        </tr>
                        <tr>
                            <th style="text-align: center !important;width: 20% !important;">
                                <label style="font-size:14px;font-weight:500;color:black;">Estimated Date</label>
                                <div style="display: block !important;">
                                    <label style="font-size:13px;font-weight:700;color:black;"><?php echo date("d-M-Y"); ?></label>
                                </div>
                            </th>
                            <th style="text-align: center !important;width: 20% !important;">
                                <label style="font-size:14px;font-weight:500;color:black;">Due Date</label>
                                <div style="display: block !important;">
                                    <label style="font-size:13px;font-weight:700;color:red;"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                                </div>
                            </th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
        <div class="d-flex align-items-start flex-wrap justify-content-between" style='text-align:left;margin-top:10px;padding-left:20px;padding-right:20px;width:100%;'>
            <div class="w-xs-100 w-sm-100 w-md-49" style="border: 1px solid #ccc; border-radius: 4px; padding: 20px;margin-bottom:10px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Company Details</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:600;color:black;">PhDiZone</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Church Road , Annanagar,</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai, Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">presale@phdizone.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%;">
                        9944049888</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">GST Number</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">33AACCE2334E1ZA</label>
                </div>
            </div>
            <div class="w-xs-100 w-sm-100 w-md-49" style="border: 1px solid #ccc; border-radius: 4px; padding: 20px;margin-bottom:10px;background-color:#e0f3f9;">
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Customer Details</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:16px;font-weight:700;color:black;">Priya</label>
                </div>
                <div style="margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">1, Bharathiyar Street, Avaniyapuram,</label>
                </div>
                <div style=" margin-bottom:4px;">
                    <label style="font-size:13px;font-weight:600;color:black;">Madurai ,Tamilnadu, India</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Email ID</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">priya@gmail.com</label>
                </div>
                <div style="margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Phone No</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">
                        9876543210</label>
                </div>
                <div style=" margin-bottom:4px;display:flex;">
                    <label style="font-size:14px;font-weight:700;color:black;width:40%">Currency Format</label>
                    <label style="font-size:13px;font-weight:600;color:black;width:60%">INR - ₹</label>
                </div>
            </div>
        </div>
        <div style="padding:20px 20px 10px 30px;">
            <div class="d-flex align-items-center justify-content-center flex-column">
                <div class="badge bg-danger rounded px-3 py-2">
                    <div class="text-white fw-semibold fs-2 mb-2">Payable Amount</div>
                    <div class="text-white fw-semibold fs-1">&#8377; 55,000</div>
                </div>
            </div>
            <div class="row text-start" style="margin-bottom:15px;">
                <div class="col-lg-6 mb-3">
                    <label class="text-black mb-3 fs-4 fw-semibold d-block">Payment Mode</label>
                    <div class="d-flex align-items-center gap-5">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fs-5" type="radio" name="paymt_md" onchange="payment_mode_func('online');" />
                            <label class="text-black fs-5 fw-semibold">Online</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input fs-5" type="radio" name="paymt_md" onchange="payment_mode_func('offline');" checked />
                            <label class="text-black fs-5 fw-semibold">Offline</label>
                        </div>
                    </div>
                </div>
            </div>

            <div id="offline_tbox" style="font-size:14px; font-weight:500;color:black;text-align:left;margin-bottom:20px;">
                <div style="font-size:18px; font-weight:700;color:black;margin-bottom:5px;">ELYSIUM TECHNOLOGIES PRIVATE LIMITED</div>
                <div style="display: flex;align-items:center;margin-bottom:5px;flex-wrap:wrap !important;">
                    <div class="w-xs-39 w-sm-39 w-md-14" style="font-size:16px;">Bank</div>
                    <div style="width:10% !important;text-align:center !important;font-size:16px;">:</div>
                    <div class="w-xs-39 w-sm-39 w-md-74" style="font-weight:700;color:black;font-size:18px;">TMB</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;flex-wrap:wrap !important;">
                    <div class="w-xs-39 w-sm-39 w-md-14" style="font-size:16px;">Account No</div>
                    <div style="width:10% !important;text-align:center !important;font-size:16px;">:</div>
                    <div class="w-xs-39 w-sm-39 w-md-74" style="font-weight:700;color:black;font-size:18px;">2027256000004</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;flex-wrap:wrap !important;">
                    <div class="w-xs-39 w-sm-39 w-md-14" style="font-size:16px;">Branch</div>
                    <div style="width:10% !important;text-align:center !important;font-size:16px;">:</div>
                    <div class="w-xs-39 w-sm-39 w-md-74" style="font-weight:700;color:black;font-size:18px;">Anna Nagar, Madurai, Tamilnadu, India</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;flex-wrap:wrap !important;">
                    <div class="w-xs-39 w-sm-39 w-md-14" style="font-size:16px;">IFSC Code</div>
                    <div style="width:10% !important;text-align:center !important;font-size:16px;">:</div>
                    <div class="w-xs-39 w-sm-39 w-md-74" style="font-weight:700;color:black;font-size:18px;">HDFC0002027</div>
                </div>
                <div style="display: flex;align-items:center;margin-bottom:5px;flex-wrap:wrap !important;">
                    <div class="w-xs-39 w-sm-39 w-md-14" style="font-size:16px;">MICR</div>
                    <div style="width:10% !important;text-align:center !important;font-size:16px;">:</div>
                    <div class="w-xs-39 w-sm-39 w-md-74" style="font-weight:700;color:black;font-size:18px;">625240005</div>
                </div>
            </div>

            <div class="d-flex align-items-center justify-content-start" id="offline_tbox_1">
                <div class="text-start w-xs-100 w-sm-100 w-md-49">
                    <label class="text-black mb-1 fs-5 fw-semibold">Transaction ID<span class="text-danger">*</span></label>
                    <input type="text" class="form-control fs-5" placeholder="Enter Transaction ID" />
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-center align-items-center flex-wrap" style="margin:20px 0px 25px 0px;">
            <a href="{{url('/manage_payment')}}" class="btn btn-label-warning border border-gray-400i bg-transparent flex-column px-2 pt-0">
                <img src="{{asset('assets/phdizone_images/pay.png')}}" style="height: 100px;width: 200px;">
            </a>
        </div>
    </div>
</center>


<script>
    function payment_mode_func(val) {
        if (val == 'online') {
            document.getElementById("offline_tbox").style.display = "none";
            $('#offline_tbox_1').attr('style', 'display: none !important');
        } else {
            document.getElementById("offline_tbox").style.display = "block";
            $('#offline_tbox_1').attr('style', 'display: block !important');
        }
    }


    function close_tab() {
        window.close();
    }
</script>
@endsection