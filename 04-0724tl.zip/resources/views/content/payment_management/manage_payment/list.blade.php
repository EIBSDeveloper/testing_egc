@extends('layouts/layoutMaster')

@section('title', 'Manage Payment')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<style>
              .nav-pills .nav-link {
                  border-radius: 10px;
                  padding: 12px 20px;
                  font-weight: bold;
                  color: #020202;
                  transition: all 0.3s ease;
                  /* background-color: #2c3e50; Uniform background color for all tabs */
                  opacity: 0.9; /* Slightly faded for non-active tabs */
              }

              .nav-pills .nav-link.active {
                  background-color: #f39c12; /* Active tab with distinct golden background */
                  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow to make active tab stand out */
                  opacity: 1; /* Active tab is fully opaque */
              }

              .nav-pills .nav-link:hover {
                  background-color: #f1c40f;
                  transform: scale(1.05);
                  opacity: 1; /* Non-active tabs become fully opaque on hover */
              }

              .badges {
                  font-size: 14px;
                  font-weight: 600;
                  transition: all 0.3s ease;
              }

              .badges:hover {
                  background-color: #d35400;
                  transform: scale(1.2);
              }

              .nav-item {
                  margin-right: 10px;
              }

              .nav-item .nav-link i {
                  font-size: 18px;
              }

              /* Hover effect for non-active tabs to enhance interactivity */
              .nav-pills .nav-link:not(.active):hover {
                  /* background-color: #d2d5d8; Darker hover effect for non-active tabs */
                  opacity: 1;
                  transform: scale(1.05);
              }
            </style>

   @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
    @endphp
<!-- Payment List Table -->
<div class="card ">
    <div class="card-header border-bottom pb-1 ">
        <h5 class="card-title mb-1">Manage Payment</h5>
         <div class="row">
            <div class="col-xl-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Payment</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="">
           <div class="nav-align-top mb-4 ">
            <ul class="nav nav-pills" role="tablist">
                
                 <li class="nav-item">
                      <a href="{{url('/payment_history')}}" type="button" class="nav-link text-capitalize " >
                          <i class="mdi mdi-account-check me-2"></i>Transactions
                      </a>
                  </li>
                  <!-- Today Tab -->
                  <!--<li class="nav-item">-->
                  <!--    <a href="{{url('/today_payment')}}" type="button" style="background-color: #ffef0e; color: #0e0d0d;" class="nav-link text-capitalize" >-->
                  <!--        <i class="mdi mdi-calendar-today me-2"></i>Today-->
                  <!--        <span class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">@if($TodayPaymentCount>0){{ $TodayPaymentCount }}@endif</span>-->
                  <!--    </a>-->
                  <!--</li>-->
    
                  <!-- Low Paid Tab -->
                  <li class="nav-item">
                      <a href="{{url('/low_mpc_payment')}}" type="button" class="nav-link text-capitalize" >
                          <i class="mdi mdi-account-arrow-down me-2"></i>Low Paid (MPC)
                      </a>
                  </li>
             
              <!-- Outstanding Tab -->
                 <li class="nav-item">
                      <a href="{{url('/manage_payment')}}" type="button" class="nav-link text-capitalize active" >
                          <i class="mdi mdi-account-alert me-2"></i>Manage Payment
                      </a>
                  </li>
              

            </ul>
          </div>
        </div>
    </div>
      
      
        
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                    <input type="text" class="form-control" placeholder="Enter Customer Name" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service Title</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Priya Work 1</option>
                        <option value="2">Priya Work 2</option>
                        <option value="3">Selvin R Work 1</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Partially Paid</option>
                        <option value="2">Paid</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="d-flex justify-content-between align-items-center">
            <div class="mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
            </div>
            <div class="">
                <form id="search_form" method="POST" action="/manage_payment">
                @csrf
                <div class="d-flex align-items-center gap-2">
                    <div class="mb-1">
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Customer - Name/Mob/Email/INV"
                    />
                    </div>
                    
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1" onclick="search_filter_func()">Search</button>
                    <a href="{{ url('/manage_payment') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                        </a>
                </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-center table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Customer</th>
                            <th class="min-w-100px">Service Title</th>
                            <th class="min-w-125px">Total Amount</th>
                            <th class="min-w-125px">Paid Amount</th>
                            <th class="min-w-125px">Balance Amount</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7 align-center"">
                         @if(isset($customers))
                           @foreach($customers as $i => $list)
                           @php
                                $encryptedValue = $helper->encrypt_decrypt($list->proposal_id,'encrypt',);
                                $create_invoice_url = url('/cus_invoice/' . $encryptedValue,);
                                $percentage = $helper->completed_service_percentage($list->sno);
                                $balance_amount = $list->pay_total_amount > 0 ? $list->pay_total_amount - $list->paid_amount : 0 ;
                                
                                 
                            @endphp
                          
                        <tr>
                            <td>
                                <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->cus_name}}">{{$list->cus_name }}</label>
                                <div class="d-block">
                                    <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{$list->customer_id}}</div>
                                </div>
                            </td>
                            <td>
                                <div class="fw-semibold text-black fs-7 text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->service_title}}">{{$list->service_title}}</div>
                                <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-175px h-15px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Progress : {{$percentage}}%">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$percentage}}%" aria-valuenow="{{$percentage}}" aria-valuemin="0" aria-valuemax="100">{{$percentage}}%</div>
                                </div>
                            </td>
                            <td align="right">
                                <label class="badge  fw-semibold fs-6 mb-2 bg-secondary">{{$list->currency_symbol}} {{number_format($list->pay_total_amount,2)}}</label>
                               
                                
                            </td>
                            <td align="right">
                                <label class="badge  fw-semibold fs-6 mb-2  bg-info">{{$list->currency_symbol}} {{number_format($list->paid_amount,2)}}</label>
                              
                                <div><label class="badge bg-success fw-semibold fs-6">&#8377; {{number_format($list->paid_amount,2)}}</label></div>
                       
                            </td>
                            @php
                            $paidBalance=$list->pay_total_amount > 0 ? $list->pay_total_amount -$list->paid_amount : 0;
                            @endphp
                            <td align="right">
                                <label class="badge  fw-semibold fs-6 mb-2 bg-danger">{{$list->currency_symbol}} {{number_format($paidBalance,2) }} </label>
                               
                               
                            </td>
                           
                            <td>
                                
                                <span class=""> 
                                    @if($list->pay_total_amount <= $list->paid_amount)
                                   <div class="badge bg-success fs-6 fw-semibold">Fully Paid</div>
                                    @else
                                     <a href="{{$create_invoice_url}}" class="btn btn-primary fs-6 py-1">Pay</a>
                                    @endif
                                </span>
                            </td>
                        </tr>
                          @endforeach
                         @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $customers->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Add Manage Payment-->
<div class="modal fade" id="kt_modal_add_journal_booklet" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Create Manage Payment</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Payment Name" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Link<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Payment Link" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input w-20px h-20px" type="checkbox">
                            <label class="text-black mb-1 fs-6 fw-semibold">S - Index</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input w-20px h-20px" type="checkbox">
                            <label class="text-black mb-1 fs-6 fw-semibold">S1 - Index</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
                        <select class="select3 form-select" data-placeholder="Select Domain" multiple>
                            <option value="1">Thesis and Dissertation Writing</option>
                            <option value="2">AI/ML & Data Engineering</option>
                            <option value="3">Statistical Analysis (SPSS, R, Stata, etc.)</option>
                            <option value="4">Educational Research</option>
                            <option value="5">Business Analysis</option>
                        </select>
                    </div>
                </div>
                <div class="form-repeater_jorn_bklt_create">
                    <div data-repeater-list="group-a_jorn_bklt">
                        <div data-repeater-item>
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Contact No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Contact No" />
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Email ID" />
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_create_del" id="jorn_bklt_create_del" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-4 mt-1">
                    <button class="btn btn-sm btn-primary jorn_bklt_create_add fs-8 px-2 py-1" data-repeater-create id="jorn_bklt_create_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="2" placeholder="Enter Description"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Create Manage Payment</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Manage Payment-->


<!--begin::Modal - Update Manage Payment-->
<div class="modal fade" id="kt_modal_edit_journal_booklet" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Manage Payment</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Payment Name" value="IEEE Internet of Things Payment" />
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Payment Link<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Payment Link" value="https://ieee-iotj.org/" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input w-20px h-20px" type="checkbox" checked>
                            <label class="text-black mb-1 fs-6 fw-semibold">S - Index</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="form-check form-check-inline mt-4">
                            <input class="form-check-input w-20px h-20px" type="checkbox">
                            <label class="text-black mb-1 fs-6 fw-semibold">S1 - Index</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Domain<span class="text-danger">*</span></label>
                        <select class="select3 form-select" data-placeholder="Select Domain" multiple>
                            <option value="1">Thesis and Dissertation Writing</option>
                            <option value="2">AI/ML & Data Engineering</option>
                            <option value="3">Statistical Analysis (SPSS, R, Stata, etc.)</option>
                            <option value="4">Educational Research</option>
                            <option value="5">Business Analysis</option>
                            <option value="6" selected>Internet of Things</option>
                            <option value="7" selected>Communications</option>
                            <option value="8" selected>Computer Science</option>
                        </select>
                    </div>
                </div>
                <div class="form-repeater_jorn_bklt_update">
                    <div data-repeater-list="group-a_jorn_bklt">
                        <div data-repeater-item>
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Contact No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Contact No" value="+1 (732) 562-3900" />
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Email ID" value="ieeejournals@ieee.org" />
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_update_del" id="jorn_bklt_update_del" style="display: block !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Contact No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Contact No" value="+1 (732) 981-0060" />
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Email ID" value="editor.iotj@ieee.org" />
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_update_del" id="jorn_bklt_update_del" style="display: block !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Contact No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Contact No" value="+1 (732) 562-3773" />
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Email ID" value="t.ii.eic@ieee.org" />
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_update_del" id="jorn_bklt_update_del" style="display: block !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-12">
                                    <div class="row">
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Contact No<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Contact No" value="+1 (855) 433-3636" />
                                        </div>
                                        <div class="col-lg-5 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Email ID" value="ieeeaccess@ieee.org" />
                                        </div>
                                        <div class="col-lg-2 mb-1">
                                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 jorn_bklt_update_del" id="jorn_bklt_update_del" style="display: block !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-4 mt-1">
                    <button class="btn btn-sm btn-primary jorn_bklt_update_add fs-8 px-2 py-1" data-repeater-create id="jorn_bklt_update_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="5" placeholder="Enter Description">The IEEE Internet of Things Payment publishes peer-reviewed articles on the latest advances in IoT theory, technologies, and applications. It serves as a leading platform for researchers, engineers, and practitioners to share innovations in IoT systems, architecture, and services.</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Update Manage Payment</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Manage Payment-->

<!--begin::Modal - View Manage Payment-->
<div class="modal fade" id="kt_modal_view_journal_booklet" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8">
                    <h3 class="text-center text-black">View Manage Payment Details</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Payment</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-semibold">
                        <span>IEEE Internet of Things Payment</span>
                        <a href="https://ieee-iotj.org/" class="ms-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Link"><i class="mdi mdi-link-variant text-info fs-4"></i></a>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Index</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">S - Index</label>
                </div>
                <div class="row mb-6">
                    <div class="col-lg-12 mb-3">
                        <div class="border border-gray-800 rounded pb-2">
                            <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-warning">
                                <div class="mb-0 ps-3 py-2">
                                    <label class="text-black fw-semibold fs-6">Domain</label>
                                </div>
                            </div>
                            <div class="scroll-y max-h-200px px-3 py-2">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#127775;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">Internet of Things</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#127775;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">Communications</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#127775;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">Computer Science</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="border border-gray-800 rounded pb-2">
                            <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-warning">
                                <div class="mb-0 ps-3 py-2">
                                    <label class="text-black fw-semibold fs-6">Contact No & Email ID</label>
                                </div>
                            </div>
                            <div class="scroll-y max-h-200px px-3 py-2">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#128222;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">+1 (732) 562-3900, ieeejournals@ieee.org</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#128222;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">+1 (732) 981-0060, editor.iotj@ieee.org</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#128222;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">+1 (732) 562-3773, t.ii.eic@ieee.org</div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="d-flex align-items-start border-bottom border-top-0 border-start-0 border-end-0 border-gray-300i px-2 py-1 mb-2 pb-2">
                                            <div class="fs-6 text-warning me-1">&#128222;</div>
                                            <div class="text-black fs-7 fw-semibold text-justify text-wrap">+1 (855) 433-3636, ieeeaccess@ieee.org</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <label class="col-12 text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <label class="col-12 text-black fs-7 fw-semibold">&emsp;&emsp; The IEEE Internet of Things Payment publishes peer-reviewed articles on the latest advances in IoT theory, technologies, and applications. It serves as a leading platform for researchers, engineers, and practitioners to share innovations in IoT systems, architecture, and services.</label>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Manage Payment-->

<!--begin::Modal - Delete Manage Payment-->
<div class="modal fade" id="kt_modal_delete_journal_booklet" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Manage Payment ?
                <div class="d-block fw-bold fs-5 mt-3 py-2">
                    <label class="mb-1">IEEE Internet of Things Payment</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Manage Payment-->



<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
    }
  }
</script>


<script>
    $('.jorn_bklt_create_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_jorn_bklt_create').length);
        let $clone = $('.form-repeater_jorn_bklt_create').first().clone().hide();
        $clone.insertBefore('.form-repeater_jorn_bklt_create:first').slideDown();
        if (bt == 1) {
            $('.jorn_bklt_create_del').attr('style', 'display: block !important');
        } else {
            $('.jorn_bklt_create_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_jorn_bklt_create .jorn_bklt_create_del', e => {
        var bt = parseFloat($('.jorn_bklt_create_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_jorn_bklt_create').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.jorn_bklt_create_del').attr('style', 'display: none !important');
        } else {}
    });
</script>

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection