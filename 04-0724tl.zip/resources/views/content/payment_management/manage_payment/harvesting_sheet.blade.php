@extends('layouts/layoutMaster')

@section('title', 'Manage Harvesting')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->


<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
        
         <div class="row">
          
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Manage Harvesting</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Payments</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-pills justify-content-end" role="tablist">
                  @php
                      $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
                      $currentYear = request()->get('year', date('Y')); // Default to current year if not provided
    
                      // Calculate previous month and year
                      $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
                      $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January
    
                      // Calculate next month and year
                      $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
                      $nextYear = $currentMonth == 12 ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December payment-management-manage-harvesting
                      
                  @endphp
    
                <div class="me-2 mb-2 w-60">
                    <div class="cursor-pointer input-group input-group-merge">
                        <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="ovr_month_fill" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo $month_filter ?? date("M-Y"); ?>" readonly onchange="month_filter(this.value)">
                        <!--<span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>-->
                    </div>
                </div>
              </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
         <div class="col-lg-12 d-flex flex-wrap align-items-center mb-2 gap-2">
            <a href="#" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Amount</div>
                <div ><svg fill="#0e0ca4" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
                <div class="d-block">
                    <div class="badge bg-info rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($totalscheduleamount, 2) }}  </div>
                </div>
            </a>
            <a href="#" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Paid Amount</div>
                <div ><svg fill="#1eb588" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
                <div class="d-block">
                    <div class="badge bg-success rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($totalPaidAmount, 2) }}  </div>
                </div>
            </a>
            <a href="{{ url('payment_harvesting/' . $currentMonth . '/' . $currentYear) }}?balance_payment=1" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Balance Amount</div>
                <div ><svg fill="#bb1d1d" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
                <div class="d-block">
                <div class="badge bg-danger rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($outstandingAmount, 2) }}  </div>
                </div>
            </a>
             <a href="#" class="text-center border border-2 p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Balance Percentage</div>
                <div ><svg fill="#bb1d1d" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
                <div class="d-block">
                <div class="badge bg-danger rounded fw-bold fs-6">{{ number_format($outstandingPercentage, 2) . "%" }}  </div>
                </div>
            </a>
            
             <span class="text-center border border-2 p-2 mb-2 cursor-pointer" onclick="pendingOutstanding('<?php echo $month_filter ?? date("M-Y"); ?>')">
                <div class="fw-semibold fs-6 text-black text-center">Previous Month </br>
                      Pending </div>
                <div class="p-2">
                  <svg height="25px" width="25px" xmlns="http://www.w3.org/2000/svg" enable-background="new 0 0 512 512" viewBox="0 0 512 512" id="RupeePendingPayment">
                    <path d="M42.6 348.8c-2-5.5-3.8-11.2-5.3-16.8-1.1-4.3-5.5-6.8-9.8-5.7-4.3 1.1-6.8 5.5-5.7 9.8 1.6 6.1 3.5 12.3 5.7 18.2 1.2 3.2 4.3 5.3 7.5 5.3.9 0 1.8-.2 2.7-.5C42 357.6 44.1 353 42.6 348.8zM57.7 380.7c-2.3-3.8-7.2-5.1-11-2.8-3.8 2.3-5.1 7.2-2.8 11 3.2 5.4 6.7 10.8 10.5 16 1.6 2.2 4 3.3 6.5 3.3 1.6 0 3.3-.5 4.7-1.5 3.6-2.6 4.4-7.6 1.8-11.2C63.9 390.7 60.7 385.7 57.7 380.7zM103.7 433.8c-4.6-3.7-9-7.6-13.2-11.7-3.2-3.1-8.2-3-11.3.2-3.1 3.2-3 8.2.2 11.3 4.6 4.4 9.4 8.6 14.3 12.6 1.5 1.2 3.3 1.8 5 1.8 2.3 0 4.6-1 6.2-3C107.7 441.6 107.2 436.6 103.7 433.8zM148.8 461.5c-5.4-2.4-10.7-5.1-15.8-7.9-3.9-2.2-8.7-.8-10.9 3.1-2.2 3.9-.8 8.7 3.1 10.9 5.5 3.1 11.3 6 17 8.6 1.1.5 2.2.7 3.3.7 3.1 0 6-1.8 7.3-4.7C154.7 468.1 152.9 463.4 148.8 461.5zM24.2 305.8c4.4-.3 7.7-4.1 7.4-8.5-.3-4.4-.5-8.9-.5-13.3 0-1.5 0-2.9 0-4.3.1-4.4-3.4-8.1-7.8-8.2-4.5-.1-8.1 3.4-8.2 7.8 0 1.6-.1 3.1-.1 4.7 0 4.8.2 9.6.5 14.4.3 4.2 3.8 7.4 8 7.4C23.8 305.8 24 305.8 24.2 305.8zM78.4 154.8c2.1 0 4.2-.8 5.8-2.5 4-4.3 8.3-8.4 12.7-12.3 3.3-2.9 3.6-8 .7-11.3-2.9-3.3-8-3.6-11.3-.7-4.8 4.2-9.4 8.7-13.7 13.3-3 3.2-2.9 8.3.3 11.3C74.4 154 76.4 154.8 78.4 154.8zM225.4 88.2c.1 0 .2 0 .4 0 5.9-.3 11.8-.3 17.7-.1 4.4.2 8.1-3.3 8.3-7.7.2-4.4-3.3-8.1-7.7-8.3-6.3-.2-12.7-.2-19 .1-4.4.2-7.8 3.9-7.6 8.4C217.6 84.9 221.2 88.2 225.4 88.2zM25.8 250.8c.6.1 1.1.2 1.7.2 3.7 0 7-2.6 7.8-6.3 1.2-5.7 2.7-11.5 4.5-17 1.3-4.2-1-8.7-5.2-10-4.2-1.3-8.7 1-10 5.2-1.9 6.1-3.5 12.3-4.8 18.5C18.7 245.7 21.4 249.9 25.8 250.8zM171.2 97.5c.8 0 1.6-.1 2.3-.3 5.6-1.7 11.4-3.2 17.1-4.4 4.3-.9 7.1-5.2 6.1-9.5-.9-4.3-5.2-7.1-9.5-6.1-6.2 1.3-12.4 2.9-18.4 4.8-4.2 1.3-6.6 5.8-5.3 10C164.6 95.3 167.8 97.5 171.2 97.5zM121.1 120.1c1.4 0 2.9-.4 4.2-1.2 5-3.1 10.2-6 15.4-8.6 3.9-2 5.5-6.8 3.6-10.7-2-3.9-6.8-5.5-10.7-3.6-5.7 2.8-11.3 6-16.6 9.3-3.8 2.3-4.9 7.2-2.6 11C115.8 118.8 118.4 120.1 121.1 120.1zM42.5 198.4c1.2.6 2.5.9 3.7.9 2.9 0 5.6-1.5 7.1-4.2 2.7-5.2 5.8-10.3 9-15.2 2.4-3.7 1.4-8.7-2.3-11.1-3.7-2.4-8.7-1.4-11.1 2.3-3.5 5.3-6.8 10.9-9.7 16.4C37.1 191.5 38.6 196.4 42.5 198.4zM199.5 477c-5.8-1-11.6-2.2-17.3-3.7-4.3-1.1-8.6 1.5-9.7 5.7-1.1 4.3 1.5 8.6 5.7 9.7 6.1 1.6 12.4 2.9 18.6 4 .5.1.9.1 1.4.1 3.8 0 7.2-2.8 7.9-6.7C206.8 481.8 203.9 477.7 199.5 477zM446.5 309.8c-4.4-.8-8.5 2.2-9.2 6.5-1 5.8-2.3 11.6-3.8 17.2-1.2 4.3 1.4 8.7 5.6 9.8.7.2 1.4.3 2.1.3 3.5 0 6.7-2.3 7.7-5.9 1.7-6.1 3.1-12.4 4.1-18.7C453.7 314.7 450.8 310.5 446.5 309.8zM446 254.8c-4.4.5-7.6 4.4-7.1 8.8.6 5.8 1 11.7 1.1 17.6.1 4.4 3.6 7.9 8 7.9 0 0 .1 0 .1 0 4.4-.1 7.9-3.7 7.9-8.1-.1-6.4-.5-12.8-1.2-19.1C454.3 257.5 450.4 254.3 446 254.8zM431.7 362.8c-4-1.9-8.8-.3-10.7 3.7-2.5 5.3-5.4 10.5-8.4 15.5-2.3 3.8-1.1 8.7 2.7 11 1.3.8 2.7 1.2 4.1 1.2 2.7 0 5.4-1.4 6.9-3.9 3.3-5.4 6.4-11.1 9.1-16.8C437.4 369.5 435.7 364.7 431.7 362.8zM403 409.7c-3.3-2.9-8.4-2.6-11.3.7-3.9 4.4-8 8.7-12.3 12.7-3.2 3-3.3 8.1-.3 11.3 1.6 1.7 3.7 2.5 5.8 2.5 2 0 4-.7 5.5-2.2 4.6-4.4 9.1-9 13.2-13.7C406.7 417.7 406.4 412.7 403 409.7zM304.4 468.6c-5.6 1.9-11.3 3.6-17 5-4.3 1.1-6.9 5.4-5.8 9.7.9 3.6 4.2 6.1 7.8 6.1.6 0 1.3-.1 2-.2 6.1-1.5 12.3-3.4 18.3-5.4 4.2-1.4 6.4-6 5-10.2C313.1 469.4 308.6 467.2 304.4 468.6zM351.9 445.2c-4.9 3.2-10 6.3-15.1 9.1-3.9 2.1-5.3 7-3.2 10.9 1.5 2.7 4.2 4.2 7 4.2 1.3 0 2.6-.3 3.8-1 5.6-3 11-6.4 16.3-9.9 3.7-2.4 4.7-7.4 2.2-11.1C360.5 443.7 355.6 442.7 351.9 445.2zM252.5 479.3c-5.6.4-11.3.7-16.9.7l-.8 0c0 0 0 0 0 0-4.4 0-8 3.6-8 8 0 4.4 3.6 8 8 8l.8 0c6.1 0 12.2-.2 18.2-.7 4.4-.3 7.7-4.2 7.3-8.6S256.9 479 252.5 479.3zM426.5 103.5V74.8h7.3c4.4 0 8-3.6 8-8s-3.6-8-8-8h-15.3-67.3-15.3c-4.4 0-8 3.6-8 8s3.6 8 8 8h7.3v28.7c0 2.6 1.2 5 3.3 6.5l24.8 18-24.8 18c-2.1 1.5-3.3 3.9-3.3 6.5v28.7h-7.3c-4.4 0-8 3.6-8 8s3.6 8 8 8h15.3 67.3 15.3c4.4 0 8-3.6 8-8s-3.6-8-8-8h-7.3v-28.7c0-2.6-1.2-5-3.3-6.5l-24.8-18 24.8-18C425.3 108.5 426.5 106.1 426.5 103.5zM359.2 181.2v-8.5h51.3v8.5H359.2zM410.5 156.7h-51.3v-.2l25.6-18.7 25.6 18.7V156.7zM410.5 99.5l-25.6 18.7-25.6-18.7V74.8h51.3V99.5z" fill="#e7383e" class="color000000 svgShape"></path>
                    <path d="M384.9,16c-43.5,0-81.4,25-99.9,61.4c-0.9-0.2-1.8-0.4-2.7-0.6c-4.3-0.9-8.6,1.9-9.5,6.2c-0.9,4.2,1.7,8.3,5.9,9.4
                      c-3.1,9.2-5,18.8-5.6,28.9c-12.3-2.6-24.8-3.9-37.5-3.9C140,117.3,62.3,192.1,62.3,284S140,450.7,235.5,450.7
                      c95.5,0,173.3-74.8,173.3-166.7c0-15.4-2.2-30.7-6.5-45.4c10.5-1.6,20.4-4.7,29.7-9.1c1.2,3.2,4.2,5.2,7.5,5.2
                      c0.8,0,1.6-0.1,2.3-0.3c4.2-1.3,6.6-5.8,5.3-10c-0.3-0.9-0.6-1.9-0.9-2.8c30.5-20,50.6-54.5,50.6-93.6
                      C496.9,66.2,446.6,16,384.9,16z M392.8,284c0,83.1-70.5,150.7-157.3,150.7c-86.7,0-157.3-67.6-157.3-150.7s70.5-150.7,157.3-150.7
                      c12.8,0,25.5,1.5,37.7,4.4c4.9,57.2,53.1,102.3,111.6,102.3c0.4,0,0.7,0,1.1,0C390.5,254.2,392.8,269,392.8,284z M384.9,224
                      c-52.9,0-96-43.1-96-96s43.1-96,96-96s96,43.1,96,96S437.8,224,384.9,224z" fill="#e7383e" class="color000000 svgShape"></path>
                    <path d="M298.8,216c0-4.4-3.6-8-8-8H180.4c-4.4,0-8,3.6-8,8s3.6,8,8,8h18.4c15.5,0,30.1,4.3,40.9,12c3.7,2.7,6.9,5.6,9.3,8.8h-68.6
                      c-4.4,0-8,3.6-8,8s3.6,8,8,8h74.8c0,0.4,0,0.8,0,1.2c0,9.6-5.5,18.9-15.5,26c-10.8,7.7-25.3,12-40.9,12c-3.1,0-5.9,1.8-7.2,4.5
                      c-1.3,2.8-1,6.1,1,8.5l73.6,92c1.6,2,3.9,3,6.3,3c1.8,0,3.5-0.6,5-1.8c3.5-2.8,4-7.8,1.2-11.2l-64.2-80.3
                      c12.9-2.1,24.8-6.8,34.5-13.7c14.3-10.2,22.2-24.1,22.2-39c0-0.4,0-0.8,0-1.2h19.6c4.4,0,8-3.6,8-8s-3.6-8-8-8h-23.3
                      c-3.4-7.8-9.2-14.9-17.1-20.8h40.4C295.2,224,298.8,220.4,298.8,216z" fill="#e7383e" class="color000000 svgShape"></path>
                  </svg>
                </div>
                <div class="d-block">
                <div class="badge bg-danger rounded fw-bold fs-6"> {{ sprintf("%02d",$previousCount) ?? "00" }} </div>
                </div>
            </span>
        </div> 
        
        <div class="row">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
                <!-- Per Page Dropdown -->
                <div>
                    <!-- @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <label class="mb-1 fw-semibold">Show</label>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-75px" onchange="sort_filter(this.value);">
                            @php $options = [10, 25, 100, 500]; @endphp
                            @foreach ($options as $option)
                                <option value="{{ $option }}" {{ $perpage_count == $option ? 'selected' : '' }}>
                                    {{ $option }}
                                </option>
                            @endforeach
                        </select>
                    </div> -->
                </div>
            
                <!-- Search Form -->
                <div class="mb-2">
                    <form id="search_form" method="POST" action="/payment_harvesting">
                        @csrf
                        <div class="d-flex align-items-end gap-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="{{ $perpage ?? 10 }}" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control form-control-sm" id="cus_fill" name="cus_fill" value="{{ $cus_fill ?? '' }}" placeholder="Customer ID / Name / Mobile No."/>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
            <thead>
                <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="min-w-100px">Customer</th>
                    <th class="min-w-80px text-start">Service</th>
                    <th class="min-w-50px text-center">Schedule<br>Date</th>
                    <th class="min-w-50px">Paid&nbsp;Date</th>
                    <th class="min-w-50px">Currency</th>
                    <th class="min-w-100px">Payment</th>
                    <th class="min-w-50px">GST</th>
                    <th class="min-w-50px">Payment <br> (without GST)</th>
                </tr>                
            </thead>
            <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                @if (isset($HistoryPayment))
                        @php
                            $total_gst_curr = 0;
                            $total_paid_curr = 0;
                        @endphp
                     @foreach ($HistoryPayment as $i=> $pay)
                     @php
                      $currentdate = date('Y-m-d'); // Gets the current date in 'YYYY-MM-DD' format
                      $nextPayDate = \Carbon\Carbon::parse($pay->nextPayDate); // Convert nextPayDate to Carbon instance
                      $extendays = $nextPayDate->diffInDays($currentdate, false); // Get the difference in days
                      
                       $registeredDate = $nextPayDate;
                        $diff = $registeredDate->diff($currentdate); // Use diff() instead of diffInDays()
                        
                        $months = $diff->m;
                        $days = $diff->d;
                        
                        // If the difference in months is 0, just show the days count.
                        if ($months == 0) {
                            $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
                        } else {
                            $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') .  " and {$days} day" . ($days != 1 ? 's' : '');
                        }



                      $color = ''; 
                      // echo "Payment extended by $days days.";

                      if ($pay->payment_status == 0) {
                          // If payment status is 0, set initial color
                          $color = '';
                          // If next payment date is in the future, override color to red
                          if ($nextPayDate < $currentdate) {
                              $color = '#e64a4a';
                          }
                      } else {
                          // If status is not 0, check payment amount conditions
                          if ($pay->payment_paid_amt < $pay->payment_amount) {
                              $color = '#ffff8f'; // Partial payment
                          } elseif ($pay->payment_paid_amt >= $pay->payment_amount) {
                              $color = '#abe8ab'; // Fully paid
                          }
                          if($pay->nextPayDate > $pay->initialPayDate){
                            $color = '#f5ab16' ;
                          }
                      }
                      
                      //  $color = ''; 
                      //  $currentdate = date('Y-m-d'); // Gets the current date in 'YYYY-MM-DD' format
                      //   if ($pay->payment_status == 0) {
                      //       // If payment status is 0, set initial color
                      //       $color = '';
                      //       // If next payment date is greater than the current date, override color to red
                      //       if ($pay->nextPayDate < $currentdate) {
                      //           $color = '#e84848';
                      //       }
                      //   } else {
                      //       // If status is not 0, check payment amount conditions
                      //       if ($pay->payment_paid_amt < $pay->payment_amount) {
                      //           $color = '#ffff8f'; // Partial payment
                      //       } elseif ($pay->payment_paid_amt >= $pay->payment_amount) {
                      //           $color = '#abe8ab'; // Fully paid
                      //       }
                      //   }
                      
                              if($pay->payment_status == 0){
                                $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
                                $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
                                $gstAmount = $pay->payment_amount - $baseAmount; 
                                
                                    if ($pay->currency_id != 70) {
                                        $total_paid_curr += $helper->ConvertedAmountInr($pay->currency_code, $pay->payment_amount);
                                        $total_gst_curr  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
                                    } else {
                                        $total_paid_curr += $pay->payment_amount;
                                        $total_gst_curr  += $gstAmount;
                                    }
                              }else{
                                $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
                                $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
                                $gstAmount = $pay->payment_paid_amt - $baseAmount; 
                                
                                if ($pay->currency_id != 70) {
                                    $total_paid_curr += $helper->ConvertedAmountInr($pay->currency_code, $pay->payment_paid_amt);
                                    $total_gst_curr  += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
                                } else {
                                    $total_paid_curr += $pay->payment_paid_amt;
                                    $total_gst_curr  += $gstAmount;
                                }
                              }
                      
                      
                           
                     @endphp
                     <tr style="background-color: {{ $color }};">                            
                            <td>
                                <div class="d-flex align-items-center px-1">
                               
                                <div class="mb-0 align-items-center">
                                    <span>
                                    <!--<span class="fs-6 me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_cus_view" onclick="viewCustomerDetails({{ $pay->customer_sno }})">-->
                                    <span class="fs-6 me-1" >
                                        {{ $pay->cus_name }}
                                    </span>
                                    </span>
                                    <div class="d-block text-dark fs-8" title="Mobile NO">{{ $pay->cus_mobile }}</div>
                                    <span class="d-block text-dark text-nowrap fs-8" title="Customer ID">{{ $pay->customer_id }}</span>
                                    @if($pay->is_previous ==1)
                                    <span class="badge bg-warning text-black">Previous Month</span>
                                    @endif
                                </div>
                                </div>
                            </td>
                            <td class="text-start">
                                <div class="d-block mt-1">
                                  <span class="badge bg-label-dark fs-7 fw-semibold"
                                          data-bs-toggle="tooltip"
                                          data-bs-placement="bottom"
                                          title="{{ $pay->service_title }}"
                                          style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"
                                          class="text-truncate">
                                      {{ $pay->service_title }}
                                  </span>
                                  <div class="d-block text-dark fs-8" title="Milestone ID">{{ $pay->propo_pay_slot_id }}</div>
                                  
                                  <div class="d-block text-dark fs-6" >
                                    @if($pay->payment_status == 0)
                                      
                                        @if($extendays > 1 ) 
                                        <span class="badge bg-danger animation-blink" title="Days Extended">
                                          {{ $formattedDifference }} 
                                          @else
                                        </span>
                                        @endif 
                                    @endif
                                  </div>
                                  
                                  
                                </div>
                            </td>
                            <!-- Paid Fees Section -->
                           
                             <td class="text-center"> 
                                <span class="fs-7 fw-bold text-nowrap">{{ date($common_date_format,strtotime(date($pay->nextPayDate))) }}</span>
                            </td>
                             <td class="text-center"> 
                              @if($pay->payment_status == 1)
                                <span class="fs-7 fw-bold text-nowrap">{{ date($common_date_format,strtotime(date($pay->initialPayDate))) }}</span>
                             @else
                                <span class="fs-7 fw-bold">-</span>
                            @endif
                            </td>
                            <td class="text-center">
                                 <span class="badge {{$pay->currency_id ==70 ? 'bg-secondary text-white': 'bg-warning text-black'}} rounded fs-6 px-2">   
                                {{$pay->currency_code}}
                                </span>
                                </td>
                            <td class="text-end">
                                <div class="d-flex no-wrap align-items-center">
                              @if($pay->payment_status == 0)
                              <span class="bg-label-warning rounded fs-6 px-2 text-nowrap">       
                               @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">&#8377; {{number_format($helper->ConvertedAmountInr($pay->currency_code,$pay->payment_amount),2)}}</span>
                                @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">&#8377;{{ number_format($pay->payment_amount, 2) }}</span>
                                @endif
                              </span>
                             
                               <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($pay->payment_amount, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                            
                              @else
                              <span class="bg-label-success rounded fs-6 px-2 text-nowrap">
                                 @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377; {{number_format($helper->ConvertedAmountInr($pay->currency_code,$pay->payment_paid_amt),2)}} </span>
                                @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377;{{ number_format($pay->payment_paid_amt, 2) }}</span>
                                 @endif
                              </span>       
                           
                               <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($pay->payment_paid_amt, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                          
                              @endif
                              </div>
                            </td>
                            <td class="text-end">
                                <div class="d-flex no-wrap align-items-center">
                              @if($pay->payment_status == 0)
                              <span class="bg-label-secondary rounded fs-6 px-2 text-nowrap">  
                                @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$gstAmount),2)}}</span>
                                @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">&#8377;{{ number_format($gstAmount, 2) }}</span>
                                 @endif
                                
                              </span>
                              <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($gstAmount, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                              @else
                              <span class="bg-label-secondary rounded fs-6 px-2 text-nowrap">
                                @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid GST Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$gstAmount),2)}}</span>
                                 @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid GST Amount">&#8377;{{ number_format($gstAmount, 2) }}</span>
                                @endif
                                
                              </span>
                              <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($gstAmount, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                              @endif
                              </div>
                            </td>
                            </td>
                            <td class="text-end">
                                <div class="d-flex no-wrap align-items-center">
                              @if($pay->payment_status == 0)
                              <span class="bg-label-warning rounded fs-6 px-2 text-nowrap"> 
                                @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$baseAmount),2)}}</span>
                                 @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">&#8377;{{ number_format($baseAmount, 2) }}</span>
                                @endif
                                
                              </span>
                              <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($baseAmount, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                              @else
                              <span class="bg-label-success rounded fs-6 px-2 text-nowrap">
                                 @if($pay->currency_id !=70)
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$baseAmount),2)}}</span>
                                 @else
                                <span class="fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">&#8377;{{ number_format($baseAmount, 2) }}</span>
                                @endif
                                
                              </span>
                              <span data-bs-toggle="tooltip" data-bs-placement="right" title="{{$pay->currency_symbol .' '. number_format($baseAmount, 2)}}"><i class="mdi mdi mdi-help-circle text-dark"></i></span>
                              @endif
                              </div>
                            </td>
                        </tr>
                    @endforeach
                @endif
            </tbody>
            <tfoot>
              <tr class="text-start align-top fw-bold fs-5 gs-0">
                <th class="min-w-100px text-end text-black fw-bold fs-5" colspan="6">Total</th>
                <th class="min-w-80px text-end">
                  <span class="badge bg-warning text-black">
                    <span class="fs-3"><i class="mdi mdi-currency-rupee fs-6 text-black"></i></span>
                    
                    <span class="fs-3">{{ number_format(round($total_gst ?? 0), 2, '.', ',') }}</span>
                  </span>
                </th>
                <th class="min-w-80px text-end">
                  <span class="badge  text-white" style="background-color: #2832a7;">
                    <span class="fs-3"><i class="mdi mdi-currency-rupee fs-6 text-white"></i></span>
                    <span class="fs-3">{{ number_format($total_paid ?? 0, 2, '.', ',') }}</span>
                  </span>
                </th>
                
              </tr>
            </tfoot>
            </table>

        </div>
        </div>
    </div>
</div>


<!--begin::Modal - View Lead-->
<div class="modal fade" id="kt_modal_cus_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Payment Details</h3>
        </div>
        <form>
          <div class="row">
            <div class="col-lg-12 text-black fs-5 fw-bold"><u>Customer Information</u></div>
            <div class="col-lg-6" id="customer-details">
              <!-- Customer details will be injected here -->
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 text-black fs-5 fw-bold"><u>Total Payments</u></div>
            <div class="col-lg-12" id="customer-payments">
              <!-- Customer details will be injected here -->
            </div>
          </div>
          <div class="row">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page2">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-125px">Date</th>
                  <th class="min-w-125px">MDD</th>
                  <th class="min-w-100px">Schd.Amount</th>
                  <th class="min-w-100px">Paid Amount</th>
                  <th class="min-w-100px">Bal.Amount</th>
                  <th class="min-w-80px">Status</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7" id="payment-table-body-model">
                <!-- Payment details will be injected here -->
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - View Lead-->
<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Profile Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex justify-content-center align-items-center">
        <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
      </div>
    </div>
  </div>
</div>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>

// Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<script>

  function viewCustomerDetails(customerId) {
    // Fetch customer and payment details based on customerId
    $.ajax({
      url: '/get_customer_details/' + customerId,
      method: 'GET',
      success: function(response) {
        // Inject customer details into the modal
        let customerDetails = `
        <div class="customer-info">
          <div class="row">
            <div class="col-12 col-md-6">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-account fs-5"></i> <strong>Name:</strong></span>
                <span class="info-value">${response.customer.cus_name}</span>
              </div>
            </div>
            <div class="col-12">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-phone-in-talk fs-5"></i> <strong>Mobile:</strong></span>
                <span class="info-value">${response.customer.cus_mobile}</span>
              </div>
            </div>
          </div>
        </div>
      `;
      
        // Extract payment details from response.payments array
       let totalFees = parseFloat(response.payments[0]?.total_amount || 0);
        let paidFees = 0;
        
        // Loop through payments array and sum up the total and paid fees
        response.payments.forEach(payment => {
            paidFees += parseFloat(payment.paidAmount || 0);
        });
        
       
        // Calculate balance fees
        let balanceFees = totalFees - paidFees;
        
       let paymentsDetails = `
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex flex-wrap gap-3 mt-2">
                    <span class="badge bg-info rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Total Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${totalFees.toFixed(2)}
                    </span>
                    <span class="badge bg-success rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Paid Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${paidFees.toFixed(2)}
                    </span>
                    <span class="badge bg-danger rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Balance Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${balanceFees.toFixed(2)}
                    </span>
                </div>
            </div>
        </div>
    `;





        $('#customer-details').html(customerDetails);
        $('#customer-payments').html(paymentsDetails);
        let paymentRows = '';
        $.each(response.payments, function(index, payment) {
          const gstPercentage = parseFloat(response.gstPercentage) || 0;  // Ensure valid GST percentage

          // Calculate GST and totals once for reuse
          const courseFeeGST = parseFloat(payment.amount) * gstPercentage;
          const totalCourseFee = parseFloat(payment.amount) + courseFeeGST;

          const paidAmountGST = parseFloat(payment.paidAmount) * gstPercentage;
          const totalPaidAmount = parseFloat(payment.paidAmount) + paidAmountGST;

          const balanceFeeGST = parseFloat(payment.balanceFee) * gstPercentage;
          const totalBalanceFee = parseFloat(payment.balanceFee) + balanceFeeGST;

          // Start building payment row
          paymentRows += '<tr>';

          // Display the initial payment date
          paymentRows += '<td>' + payment.initialPayDate + '</td>';

          // Display next payment date with tooltip for maximum due date
          paymentRows += `<td>
            <div class="d-block mt-1">
              <span class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">
                ${payment.nextPayDate}
              </span>
            </div>
          </td>`;

          // Display scheduled fees with currency and GST
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.amount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 "><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${courseFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalCourseFee.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Display paid fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.paidAmount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${paidAmountGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalPaidAmount.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Display balance fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.balanceFee).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${balanceFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalBalanceFee.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Status column (Paid or Pending)
          paymentRows += `<td>
            ${payment.status == 1 ?
              '<span class="badge bg-success text-black fw-semibold fs-6">Paid</span>' :
              '<span class="badge bg-danger fw-semibold fs-6">Pending</span>'
          }</td>`;

          paymentRows += '</tr>';
        });
        $('#payment-table-body-model').html(paymentRows);
      }
    });
  }

</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
    .txt_vertical {
      writing-mode: vertical-lr;
      transform: rotate(180deg);
    }
</style>
<style>


    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }
    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
     .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite; /* Outer pulse effect */
        border: 2px solid red; /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white; /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%; /* Make the icon circular */
        animation: pulseInner 1.5s infinite; /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }
        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>






<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
  $(".list_page2").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
  </script>
  <script>
    function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/payment_harvesting/?month_filter=' + val;
        
    }

    function pendingOutstanding(val){
       var url = "{{ url('') }}";
        window.location = '/payment_harvesting/?month_filter=' + val
        +'&pending=1';
    }

</script>
@endsection
