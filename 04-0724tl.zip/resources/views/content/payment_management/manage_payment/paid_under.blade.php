@extends('layouts/layoutMaster')

@section('title', 'Manage Low MPC')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->

<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Low MPC</h5>
         <div class="row">
            <div class="col-xl-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Low MPC</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Low Paid (MPC)</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-xl-6">
                <!--<div class="d-flex justify-content-end align-items-center flex-wrap">-->
                <!--     <a href="javascript:;" class="btn btn-primary btn-sm py-1 px-3 mb-2" title="" id="customer">-->
                <!--        <i class="mdi mdi-arrow-expand-vertical fs-5"></i>-->
                <!--    </a>-->
                <!--</div>-->
            </div>
        </div>
        <div class="nav-align-top mb-4">
          <ul class="nav nav-pills" role="tablist">
              <li class="nav-item">
                  <a href="{{url('/payment_history')}}" type="button" class="nav-link text-capitalize " >
                      <i class="mdi mdi-account-check me-2"></i>Transactions
                  </a>
              </li>

          
              <!--<li class="nav-item">-->
              <!--    <a href="{{url('/today_payment')}}" type="button" style="background-color: #ffef0e; color: #0e0d0d;" class="nav-link text-capitalize" >-->
              <!--        <i class="mdi mdi-calendar-today me-2"></i>Today-->
              <!--        <span class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">@if($TodayPaymentCount>0){{ $TodayPaymentCount }}@endif</span>-->
              <!--    </a>-->
              <!--</li>-->

              <li class="nav-item">
                  <a href="{{url('/low_mpc_payment')}}" type="button" class="nav-link text-capitalize active" >
                      <i class="mdi mdi-account-arrow-down me-2"></i>Low Paid (MPC)
                      <span class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">@if($PaidUnderPaymentCount>0){{ $PaidUnderPaymentCount }}@endif</span>
                  </a>
              </li>
              
              <li class="nav-item">
                      <a href="{{url('/manage_payment')}}" type="button" class="nav-link text-capitalize" >
                          <i class="mdi mdi-account-alert me-2"></i>Manage Payment
                      </a>
                  </li>
      

          </ul>
        </div>
    </div>
    <div class="card-body">
      <div class="col-lg-6 d-flex flex-wrap align-items-center mb-2 gap-2">
        <!-- <div class="row"> -->

          <!--<a href="#" class="text-center border border-2 p-2 mb-2">-->
          <!--    <div class="fw-semibold fs-6 text-black text-center">Schedule Amount</div>-->
          <!--    <div ><svg fill="#703aeb" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve" stroke="#703aeb"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>-->
          <!--    <div class="d-block">-->
          <!--      <div class="badge bg-info rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($sumScheduleAmount, 2) }}  </div>-->
          <!--    </div>-->
          <!--</a>-->
          <!-- <a href="{{url('/outstanding_payment')}}" class="text-center border border-2 p-2 mb-2">-->
          <!--  <div class="fw-semibold fs-6 text-black text-center">Outstanding</div>-->
          <!--  <div ><svg fill="#bb1d1d" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>-->
          <!--  <div class="d-block">-->
          <!--    <div class="badge bg-danger rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($outstandingAmount, 2) }}  </div>-->
          <!--  </div>-->
          <!--</a>-->
          <!-- </div> -->
      </div>

            <div class="row">
            {{-- <div class="nav-align-top mb-2">
              <ul class="nav nav-pills " role="tablist">
                  <li class="nav-item">
                      <a href="{{url('/payment_history')}}" type="button" class="nav-link text-capitalize ">
                      History</a>
                  </li>
                  <li class="nav-item">
                    <a href="{{url('/outstanding_payment')}}" type="button" class="nav-link text-capitalize ">
                    Outstanding
                    <span class="badge  bg-danger ms-2">{{ $OutstandingPaymentCount }}</span>
                  </a>
                  </li>
                  <li class="nav-item ">
                    <a  href="{{url('/today_payment')}}" type="button" class="nav-link text-capitalize ">
                        Today
                        <!-- Display badge with the total count -->
                        <span class="badge  bg-danger ms-2">{{ $TodayPaymentCount }}</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="javascript:;" type="button" class="nav-link text-capitalize active">
                    Paid Under (MPC)</a>
                  </li>
              </ul>
            </div> --}}

              <!-- Add this style section in the <head> or as inline style to enhance the look -->
     <style>
              .nav-pills .nav-link {
                  border-radius: 10px;
                  padding: 12px 20px;
                  font-weight: bold;
                  color: #020202;
                  transition: all 0.3s ease;
                  /* background-color: #2c3e50; Uniform background color for all tabs */
                  opacity: 0.9; /* Slightly faded for non-active tabs */
              }

              .nav-pills .nav-link.active {
                  background-color: #f39c12; /* Active tab with distinct golden background */
                  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow to make active tab stand out */
                  opacity: 1; /* Active tab is fully opaque */
              }

              .nav-pills .nav-link:hover {
                  background-color: #f1c40f;
                  transform: scale(1.05);
                  opacity: 1; /* Non-active tabs become fully opaque on hover */
              }

              .badges {
                  font-size: 14px;
                  font-weight: 600;
                  transition: all 0.3s ease;
              }

              .badges:hover {
                  background-color: #d35400;
                  transform: scale(1.2);
              }

              .nav-item {
                  margin-right: 10px;
              }

              .nav-item .nav-link i {
                  font-size: 18px;
              }

              /* Hover effect for non-active tabs to enhance interactivity */
              .nav-pills .nav-link:not(.active):hover {
                  /* background-color: #d2d5d8; Darker hover effect for non-active tabs */
                  opacity: 1;
                  transform: scale(1.05);
              }
            </style>

          
      </div>
        {{-- <div class="d-flex justify-content-end align-items-center gap-2 mt-2">
            <div class="d-flex align-items-center px-1 py-1">
                <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: #ffa5a3 !important;"> </label>
                <label class="fs-7 fw-semibold text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Minimum Product Cost">MPC Value Not Paid</label>
            </div>
            <div class="d-flex align-items-center px-1 py-1">
                <label class="bg-danger rounded border border-dark w-25px h-25px me-1" style="background-color: #cdf3ff !important;"> </label>
                <label class="fs-7 fw-semibold text-black">Batch Not Assigned</label>
            </div>
        </div> --}}
        <div class="d-flex justify-content-between align-items-center">
            <div class="mb-4">
                @php $perpage_count = $perpage ? $perpage : 25; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                      @php
                      $options = [10, 25, 100, 500]; // Define available options
                      @endphp
                      @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                          @php echo $option; @endphp
                        </option>
                      @php endforeach; @endphp
                    </select>
                </div>
            </div>
            <div class="mb-4">
              <form id="search_form" method="POST" action="/low_mpc_payment">
                @csrf
                  <div class="d-flex align-items-center gap-2">
                      <div class="mb-1">
                          <input type="hidden" name="page" value="{{ request('page', 1) }}">
                          <input type="hidden" name="filter_on" value="1">
                          <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                          <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                          <input
                          type="text"
                          class="form-control"
                          id="cus_fill" name="cus_fill" value="{{ $cus_fill ?? "" }}"
                          placeholder="Enter Customer - Name/ Mob. No/ Email Id"
                          />
                      </div>
                      <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                  </div>
              </form>
          </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_old">
                <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="min-w-80px">Customer</th>
                        <th class="min-w-80px">Service</th>
                        <th class="min-w-125px">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Register Date">Register Date</span>
                        </th>
                        <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">Schd.Amount</th>
                        <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">Paid Amount</th>
                        <!--<th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">Bal.Amount</th>-->
                        <th class="min-w-80px">Status</th>
                        <!--<th class="min-w-50px">Actions</th>-->
                    </tr>
                </thead>
                <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                  
                  @if (count($PaidUnderPayment) > 0)
                    @foreach ($PaidUnderPayment as $pay)
                        <!-- Customer Details Row -->
                        
                          <!--<pre>{{ print_r($pay, true) }}</pre>-->
                          <!--<pre>{{ print_r($pay, true) }}</pre>-->

                          <!-- Payment Details -->
                        @foreach ($pay['payments'] as $i => $payment)
                        
                        <!--<pre>{{ print_r($payment, true) }}</pre>-->
                            @php
                                $totalConvertInr= $payment['total_amount_inr'] ?? $helper->ConvertedAmountInr($payment['currency_code'],$payment['paidAmount']);
                            @endphp
                            <tr style="">
                             <td>
                                <div class="d-flex align-items-center px-1">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            @if(!empty($payment['cus_pic'])) 
                                                <!-- If customer has a picture -->
                                                <img src="{{ asset('cus_pics/' . $payment['cus_pic']) }}"
                                                     alt="user-avatar"
                                                     class="image-input-wrapper rounded-circle w-45px h-45px cursor-pointer"
                                                     id="uploadedlogo"
                                                     onclick="showFullImage('{{ asset('cus_pics/' . $payment['cus_pic']) }}')" />
                                            @else
                                                <!-- If no picture, show first letter of name -->
                                                <div class="fallback-avatar w-45px h-45px d-flex align-items-center justify-content-center text-white fw-bold rounded-circle cursor-pointer"
                                                     style="background-color: {{ $payment['cus_gender'] == 1 ? '#007bff' : '#e83e8c' }};"
                                                     onclick="showFullTextAvatar('{{ strtoupper(substr($payment['cus_name'], 0, 1)) }}', '{{ $payment['cus_gender'] == 1 ? '#007bff' : '#e83e8c' }}')">
                                                    {{ strtoupper(substr($payment['cus_name'], 0, 1)) }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-6 me-1">{{ $payment['cus_name'] }}</span>
                                        </label>
                                        <div class="d-block text-primary fs-8" title="Mobile NO">{{ $payment['cus_mobile'] }}</div>
                                        <div class="d-block text-primary fs-8" title="Customer ID">{{ $payment['payment_id'] }}</div>
                                    </div>
                                </div>
                            </td>

                              <td class="text-start">
                                    <label class="badge bg-label-dark fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $payment['service_title'] }}" style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                        {{ $payment['service_title'] }}
                                    </label>
                                     <div class="d-block text-primary fs-8" title="Proposal ID">
                                        {{ isset($payment['auto_proposal_id']) ? $payment['auto_proposal_id'] : '' }}
                                    </div>
                                    <div class="d-block text-primary fs-8" title="Faculty">
                                        <!--<label class="badge text-black rounded fs-8 fw-semibold mt-1" style="background-color: #e780fb;">-->
                                            <!--{{ $payment['staff_name'] ?? ''}}-->
                                        <!--</label>-->
                                    </div>
                                   
                                        
                                </td>
                                <td>
                                    <div class="d-block mt-1">
                                        <label class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Payment Date">
                                            {{ \Carbon\Carbon::parse($payment['initialPayDate'])->format($common_date_format) }}
                                        </label>
                                    </div>
                                        @php
                                          $nextDate = \Carbon\Carbon::parse($payment['initialPayDate']);
                                          $daysDiff = $nextDate->diffInDays(now(), false); // false = signed (negative if in future)
                                        @endphp
                                        
                                        <div class=" text-info fs-6 mt-2">
                                          @if ($daysDiff > 0)
                                            ({{ $daysDiff }} days ago)
                                          @elseif ($daysDiff < 0)
                                            (in {{ abs($daysDiff) }} days)
                                          @else
                                            (Today)
                                          @endif
                                        </div>
                                </td>
                                <td align="right">
                                    <!--<div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">-->
                                    <!--    <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                    <!--    <span class="fs-7">{{ number_format($payment['amount'], 2) }}</span>-->
                                    <!--</div>-->
                                    <!-- GST -->
                                    <!--<div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">-->
                                    <!--    <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                    <!--    <span class="fs-7">{{ number_format($payment['gst_amount'], 2) }}</span>-->
                                    <!--</div>-->
                                    <!-- Total (Fee + GST) -->
                                    <div class="d-block">
                                        <label class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Amount">
                                            <span class="fs-7">{{$payment['currency_symbol']}}</span>
                                            <!--<span class="fs-7">{{ number_format($payment['amount'] + $payment['gst_amount'], 2) }}</span>-->
                                              <span class="fs-7">{{ number_format($payment['amount'], 2) }}</span>
                                        </label>
                                    </div>
                                </td>
                                <td align="right">
                                    <!--<div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">-->
                                    <!--    <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                    <!--    <span class="fs-7">{{ number_format($payment['paidAmount'], 2) }}</span>-->
                                    <!--</div>-->
                                    <!-- GST -->
                                    <!--<div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">-->
                                    <!--    <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                    <!--   <span class="fs-7">{{ number_format($payment['paidAmount'] * 0.18, 2) }}</span>-->
                                    <!--</div>-->
                                    <!-- Total (Fee + GST) -->
                                    <div class="d-block">
                                        <label class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{'₹ '.round($totalConvertInr)}}">
                                            <span class="fs-7">{{$payment['currency_symbol']}}</span>
                                            <!--<span class="fs-7">{{ number_format($payment['paidAmount'] + $payment['paidAmount'] * 0.18, 2) }}</span>-->
                                            <span class="fs-7">{{ number_format($payment['paidAmount'], 2) }}</span>
                                        </label>
                                    </div>
                                </td>
                                <!--<td align="right">-->
                                    <!-- Balance Amount -->
                                <!--    <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">-->
                                <!--        <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                <!--        <span class="fs-7">{{ number_format($payment['balanceFee'], 2) }}</span>-->
                                <!--    </div>-->
                                    <!-- GST on Balance Amount -->
                                <!--    <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST on Balance Amount">-->
                                <!--        <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>-->
                                <!--       <span class="fs-7">-->
                                <!--            {{ number_format($payment['amount'] > 0 ? ($payment['balanceFee'] * ($payment['gst_amount'] / $payment['amount'])) : 0, 2) }}-->
                                <!--        </span>-->
                                <!--    </div>-->
                                    <!-- Total Balance Amount (Balance + GST) -->
                                <!--    <div class="d-block">-->
                                <!--        <label class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Balance Amount">-->
                                <!--            <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>-->
                                <!--           <span class="fs-7">-->
                                <!--                {{ number_format($payment['balanceFee'] + ($payment['amount'] > 0 ? ($payment['balanceFee'] * ($payment['gst_amount'] / $payment['amount'])) : 0), 2) }}-->
                                <!--            </span>-->

                                <!--        </label>-->
                                <!--    </div>-->
                                <!--</td>-->

                                <!-- Status Column -->
                                <td>
                                    @if($pay['total_paid'] >= $pay['min_required'])
                                        <label class="badge bg-success text-black fw-semibold fs-6">Paid</label>
                                    @elseif($payment['amount'] == $payment['paidAmount'])
                                     <label class="badge bg-success text-black fw-semibold fs-6">Paid</label>
                                    @else
                                        <label class="badge bg-danger fw-semibold fs-6">Pending</label>
                                    @endif
                                </td>

                               
                            </tr>
                        @endforeach
                    @endforeach
                  @endif
                </tbody>
            </table>


            </div>
            
            <div class="mt-4">
                @if ($PaidUnderPayment instanceof \Illuminate\Pagination\LengthAwarePaginator)
                    {{ $PaidUnderPayment->appends(request()->except(['page','_token']))->links() }}
                @endif
            </div>
        </div>
    </div>
</div>






<!--begin::Modal - Request For FSC-->
<div class="modal fade" id="kt_modal_request_for_fsc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Requested for Amount Schedule Count</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Previous Allocated Count</label>
                        <div class="d-block">
                            <div class="badge bg-info mb-1 fs-6 fw-semibold" id="previous_allocated_count" >0</div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Extended Count</label>
                        <div class="d-block">
                            <div class="badge bg-warning text-black mb-1 fs-6 fw-semibold" id="extended_count">0</div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                        <div class="d-block">
                            <label class="text-dark mb-1 fs-6 fw-bold" id="request_reason"></label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_acpt" name="fsc_status" onclick="fsc_sts_func('accept');" checked />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Approved</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_rejt" name="fsc_status" onclick="fsc_sts_func('reject');" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3" id="rejct_tbox" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold" >Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="rejection_reason" placeholder="Enter Reason" ></textarea>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" id="smt_butt" onclick="submitForm()">Approved</a>
                    </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Request For FSC-->



<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Profile Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex justify-content-center align-items-center">
        <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
      </div>
    </div>
  </div>
</div>



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
    .txt_vertical {
      writing-mode: vertical-lr;
      transform: rotate(180deg);
    }
</style>
<style>


    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }
    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
     .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite; /* Outer pulse effect */
        border: 2px solid red; /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white; /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%; /* Make the icon circular */
        animation: pulseInner 1.5s infinite; /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }
        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>

// Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>


<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(25);
        $('#search_form').submit();
      }
    }
  </script>

<script>
   $(".list_page").DataTable({
    "ordering": false,
    "pageLength":25,
    "aaSorting":[],
    "language": {
        "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
        "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
        "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
        ">" +

        "<'table-responsive'tr>" +

        "<'row'" +
        "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
        "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
        ">"
});
</script>
@endsection