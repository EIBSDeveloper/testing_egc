@extends('layouts/layoutMaster')

@section('title', 'Manage Outstanding')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->
<style>
      table thead tr th{   
        padding: 5px !important;
    }
    table tbody tr td{
        padding: 5px !important;
    }
</style>
@php
        $module_name = 'Payment Management';
        $menu_name = 'Manage Outstanding';
    @endphp
    
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Outstanding</h5>
         <div class="row">
            <div class="col-xl-6">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Outstanding</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="card-body">
        
      <div class="d-flex align-items-center justify-content-between">
          @if(auth()->user()->role_id!=16)
        <div class="col-lg-6 d-flex flex-wrap align-items-center mb-2 gap-2">
          <a href="#" class="text-center border border-2 p-2 mb-2">
            <div class="fw-semibold fs-6 text-black text-center">This Month</div>
            <div ><svg fill="#50cd89" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve" stroke="#703aeb"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
            <div class="d-block">
              <div class="badge bg-success rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i> {{ number_format($currentMonthAmount) }}  </div>
            </div>
          </a>
          <a href="#" class="text-center border border-2 p-2 mb-2">
              <div class="fw-semibold fs-6 text-black text-center">Next Month</div>
              <div ><svg fill="#703aeb" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve" stroke="#ff4c4c"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
              <div class="d-block">
                <div class="badge bg-info rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i>  {{ number_format($nextMonthAmount) }}  </div>
              </div>
          </a>
          <a href="#" class="text-center border border-2 p-2 mb-2">
              <div class="fw-semibold fs-6 text-black text-center">Upcoming</div>
              <div ><svg fill="#ffc700" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve" stroke="#ff4c4c"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
              <div class="d-block">
                <div class="badge bg-warning rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i>  {{ number_format($greaterThanThreeMonthsAmount) }}  </div>
              </div>
          </a>
          <a href="#" class="text-center border border-2 p-2 mb-2">
              <div class="fw-semibold fs-6 text-black text-center">OverAll</div>
              <div ><svg fill="#ff4d49" height="64px" width="64px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 512.001 512.001" xml:space="preserve" stroke="#ff4c4c"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <path d="M503.524,87.486h-92.897c-4.682,0-8.476,3.795-8.476,8.476c0,4.681,3.794,8.476,8.476,8.476h41.672 c3.604,21.854,20.895,39.144,42.749,42.749v98.963c-21.854,3.604-39.145,20.895-42.749,42.749H142.724 c-3.604-21.854-20.895-39.144-42.749-42.749v-98.963c21.854-3.604,39.144-20.895,42.749-42.749H381.49 c4.682,0,8.476-3.795,8.476-8.476c0-4.681-3.794-8.476-8.476-8.476H91.498c-4.681,0-8.476,3.795-8.476,8.476v201.412 c0,4.681,3.795,8.476,8.476,8.476h233.978v24.863H16.952V237.69c0-9.116,7.417-16.533,16.533-16.533h29.757 c4.681,0,8.476-3.795,8.476-8.476c0-4.681-3.795-8.476-8.476-8.476H33.484C15.022,204.207,0,219.227,0,237.691V391.03 c0,18.463,15.022,33.484,33.484,33.484h275.46c18.464,0,33.484-15.021,33.484-33.484v-85.179h161.096 c4.682,0,8.476-3.795,8.476-8.476V95.962C512,91.281,508.206,87.486,503.524,87.486z M99.974,104.438h25.456 c-3.12,12.488-12.968,22.336-25.456,25.456V104.438z M99.974,288.898v-25.456c12.488,3.12,22.336,12.968,25.456,25.456H99.974z M325.476,363.487H83.754c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h241.723v10.59 c0,9.117-7.416,16.533-16.531,16.533H33.484c-9.116,0-16.533-7.417-16.533-16.533v-10.59H52.11c4.681,0,8.476-3.795,8.476-8.476 s-3.795-8.476-8.476-8.476H16.952v-15.822h308.524V363.487z M495.048,288.898h-25.456c3.12-12.488,12.968-22.336,25.456-25.456 V288.898z M495.048,129.894c-12.488-3.12-22.336-12.968-25.456-25.456h25.456V129.894z"></path> </g> </g> <g> <g> <path d="M297.511,119.181c-34.834,0-63.174,34.762-63.174,77.488c0,42.727,28.34,77.488,63.174,77.488 s63.174-34.762,63.174-77.488C360.685,153.942,332.345,119.181,297.511,119.181z M297.512,257.205 c-25.487,0-46.222-27.157-46.222-60.536s20.736-60.536,46.222-60.536c25.487,0,46.222,27.157,46.222,60.536 C343.734,230.048,322.999,257.205,297.512,257.205z"></path> </g> </g> <g> <g> <path d="M470.807,177.458h-83.836c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h83.836 c4.682,0,8.476-3.795,8.476-8.476S475.489,177.458,470.807,177.458z"></path> </g> </g> <g> <g> <path d="M203.963,177.458h-83.837c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h83.837 c4.681,0,8.476-3.795,8.476-8.476C212.439,181.253,208.644,177.458,203.963,177.458z"></path> </g> </g> <g> <g> <path d="M470.807,206.341h-46.007c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h46.007 c4.682,0,8.476-3.795,8.476-8.476S475.489,206.341,470.807,206.341z"></path> </g> </g> <g> <g> <path d="M166.133,206.341h-46.007c-4.681,0-8.476,3.795-8.476,8.476s3.795,8.476,8.476,8.476h46.007 c4.681,0,8.476-3.795,8.476-8.476S170.814,206.341,166.133,206.341z"></path> </g> </g> <g> <g> <path d="M322.053,188.193h-40.609v-12.812h40.609c4.682,0,8.476-3.795,8.476-8.476s-3.794-8.476-8.476-8.476h-16.066v-8.532 c0-4.681-3.794-8.476-8.476-8.476s-8.476,3.795-8.476,8.476v8.532h-16.067c-4.682,0-8.476,3.795-8.476,8.476v29.764 c0,4.681,3.794,8.476,8.476,8.476h40.609v12.812h-40.609c-4.682,0-8.476,3.795-8.476,8.476s3.794,8.476,8.476,8.476h16.067v8.532 c0,4.681,3.794,8.476,8.476,8.476s8.476-3.795,8.476-8.476v-8.532h16.066c4.682,0,8.476-3.795,8.476-8.476v-29.764 C330.529,191.988,326.735,188.193,322.053,188.193z"></path> </g> </g> </g></svg></div>
              <div class="d-block">
                <div class="badge bg-danger rounded fw-bold fs-6"><i class="mdi mdi-currency-rupee"></i>  {{ number_format($total_base_amount_Inr) }}  </div>
              </div>
          </a>
        </div>
        @endif
        
        
      </div>
      

      <div class="row">
            <style>
              .nav-pills .nav-link {
                  border-radius: 10px;
                  padding: 12px 20px;
                  font-weight: bold;
                  color: #fff;
                  transition: all 0.3s ease;
                  background-color: #2c3e50; /* Uniform background color for all tabs */
                  opacity: 0.9; /* Slightly faded for non-active tabs */
              }

              .nav-pills .nav-link.active {
                  background-color: #f39c12; /* Active tab with distinct golden background */
                  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow to make active tab stand out */
                  opacity: 1; /* Active tab is fully opaque */
              }

              .nav-pills .nav-link:hover {
                  background-color: #f1c40f;
                  transform: scale(1.05);
                  opacity: 1; /* Non-active tabs become fully opaque on hover */
              }

              .badges {
                  font-size: 14px;
                  font-weight: 600;
                  transition: all 0.3s ease;
              }

              .badges:hover {
                  background-color: #d35400;
                  transform: scale(1.2);
              }

              .nav-item {
                  margin-right: 10px;
              }

              .nav-item .nav-link i {
                  font-size: 18px;
              }

              /* Hover effect for non-active tabs to enhance interactivity */
              .nav-pills .nav-link:not(.active):hover {
                  background-color: #d2d5d8; /* Darker hover effect for non-active tabs */
                  opacity: 1;
                  transform: scale(1.05);
              }
            </style>
      </div>
         <div class="d-flex justify-content-between align-items-center">
            <div class="mb-4">
                @php $perpage_count = $perpage ? $perpage : 25; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
            </div>

            <div class="">
              <form id="search_form" method="POST" action="outstanding_payment">
                @csrf
                <div class="d-flex align-items-center gap-2">
                  <div class="mb-2">
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                    <input
                      type="text"
                      class="form-control"
                      id="customer_fill" name="customer_fill" value="{{ $customer_fill ?? "" }}"
                      placeholder="Enter Customer - Name/ Mob. No/ Email Id"
                    />
                  </div>
                  <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        <a href="{{ url('/outstanding_payment') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                        </a>
                </div>
              </form>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
              <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                <thead>
                  <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="min-w-80px">Customer</th>
                    <th class="min-w-80px">Service</th>
                    <th class="min-w-125px">
                      <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">MDD</span>
                    </th>
                    <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">Schd.Amount</th>
                    <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">Bal.Amount</th>
                    <th class="min-w-80px">Status</th>
                    <th class="min-w-50px">Actions</th>
                  </tr>
                </thead>
                @php
                  $firstPendingPaymentFound = false; // Initialize the flag to track the first pending payment
                @endphp
                <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                  @if (count($OutstandingPayment) > 0)
                    @foreach ($OutstandingPayment as $pay)
                    @php
                      $currentdate = date('Y-m-d');
                      $nextPayDate = \Carbon\Carbon::parse($pay->nextPayDate);
                      // If payment status is 0, set initial color
                      $color = '';
                      // If next payment date is in the future, override color to red
                      if ($nextPayDate < $currentdate) {
                          $color = '#ffa3a3';
                      }
                      
                      $gstRate = $gstPercentage; // e.g., 0.18 for 18%
                      $baseAmount = $pay->amount / (1 + $gstRate);
                      $gstAmount = $pay->amount - $baseAmount;
                      
                      $baseAmountBalance = $pay->balanceFee / (1 + $gstRate);
                      $gstAmountBalance = $pay->balanceFee - $baseAmountBalance;
                      
                    @endphp
                      <tr style="background-color: {{ $color }};">
                        <td>
                          <div class="d-flex align-items-center px-1">
                             <div class="symbol symbol-35px me-2">
                              <div class="image-input image-input-circle" data-kt-image-input="true">
                                @if($pay->cus_pic)
                                  <!-- If customer has a picture -->
                                  <img src="{{ asset('cus_pics/' . $pay->cus_pic) }}"
                                       alt="user-avatar"
                                       class="image-input-wrapper rounded-circle w-45px h-45px cursor-pointer"
                                       id="uploadedlogo"
                                       onclick="showFullImage('{{ asset('cus_pics/' . $pay->cus_pic) }}')" />
                                @else
                                  <!-- If no picture, show first letter of name -->
                                  <div class="fallback-avatar w-45px h-45px d-flex align-items-center justify-content-center text-white fw-bold rounded-circle cursor-pointer"
                                       style="background-color: {{ $pay->cus_gender == 1 ? '#007bff' : '#e83e8c' }};"
                                       onclick="showFullTextAvatar('{{ strtoupper(substr($pay->cus_name, 0, 1)) }}', '{{ $pay->cus_gender == 1 ? '#007bff' : '#e83e8c' }}')">
                                    {{ strtoupper(substr($pay->cus_name, 0, 1)) }}
                                  </div>
                                @endif
                              </div>
                            </div>
                            <div class="mb-0 align-items-center">
                                <label>
                                    <span class="fs-6 me-1">{{ $pay->cus_name }}
                                   
                                </label>
                                <div class="d-block text-primary fs-8" title="Mobile NO">
                                  {{ $pay->cus_mobile }}  
                                </div>
                              <div class="d-block text-primary fs-8">{{ $pay->customer_id }}
                               
                              @if($pay->jumper_skiper==1)
                                <div>
                                  <span class="fs-6 badge bg-label-warning animation-blink">Jumper</span>
                                </div>
                              @elseif($pay->jumper_skiper>1)
                                <div>
                                  <span class="fs-6 badge bg-label-danger animation-blink">Skipper</span>
                                </div>
                              @endif
                                
                           
                            </div>
                          </div>
                        </td>
                        <td class="text-start">
                            <label class="badge bg-label-dark fs-7 fw-semibold text-truncate max-w-250px"data-bs-toggle="tooltip" data-bs-placement="bottom"  title="{{ $pay->service_title }}"  class="text-truncate"> {{ $pay->service_title }}</label>
                            <div class="d-block text-primary fs-8" title="Proposal ID">{{ $pay->proposal_id }}</div>
                            <div class="d-block text-primary fs-8" title="Milestone ID">{{ $pay->payment_id }}</div>
                            
                                <!--<div class="d-block text-primary fs-8" title="Faculty">-->
                                <!--    <label class="badge text-black rounded fs-8 fw-semibold mt-1" style="background-color: #e780fb;">-->
                                <!--        {{ $pay->pro_staff_name ?? '' }}-->
                                <!--    </label>-->
                                <!--</div>-->
                          

                        </td>
                        <td>
                          <div class="d-block mt-1">
                            <label class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">{{ \Carbon\Carbon::parse($pay->nextPayDate)->format($common_date_format) }}</label>
                               @php
                                  $nextDate = \Carbon\Carbon::parse($pay->nextPayDate);
                                  $daysDiff = $nextDate->diffInDays(now(), false); // false = signed (negative if in future)
                                @endphp
                            
                            <div class=" text-info fs-6 mt-2">
                              @if ($daysDiff > 0)
                                ({{ $daysDiff }} days ago)
                              @elseif ($daysDiff < 0)
                                (in {{ abs($daysDiff) }} days)
                              @else
                                (Today)
                              @endif
                            </div>
                          </div>
                        </td>
                        <td align="right">
                          <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">
                            <span class="fs-7">{{$pay->currency_symbol}}</span>
                            <span class="fs-7">{{ number_format($baseAmount, 2) }}</span>
                            <span class="fs-7">/</span>
                          </div>
                          <!-- GST calculation -->
                          <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
                            <span class="fs-7">{{$pay->currency_symbol}}</span>
                            <span class="fs-7">{{ number_format($gstAmount, 2) }}</span>
                            <span class="fs-7">/</span>
                          </div>
                          <!-- Total Amount: Course Fee + GST -->
                          <div class="d-block">
                            <label class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                              <span class="fs-7">{{$pay->currency_symbol}}</span>
                              <span class="fs-7">{{ number_format($pay->amount, 2) }}</span>
                            </label>
                          </div>
                        </td>

                        <!-- Paid Amount Section -->
                        {{-- @if($pay->paidAmount > 0)
                          <td align="right">
                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">
                              <span class="fs-7"><{{$pay->currency_symbol}}</span>
                              <span class="fs-7">{{ number_format($pay->paidAmount, 2) }}</span>
                              <span class="fs-7">/</span>
                            </div>
                            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
                              <span class="fs-7"><{{$pay->currency_symbol}}</span>
                              <span class="fs-7">{{ number_format($pay->paidAmount * $gstPercentage, 2) }}</span>
                              <span class="fs-7">/</span>
                            </div>
                            <div class="d-block">
                              <label class="badge bg-success text-black rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Paid Amount">
                                <span class="fs-7">{{$pay->currency_symbol}}</span>
                                <span class="fs-7">{{ number_format($pay->paidAmount + ($pay->paidAmount * $gstPercentage), 2) }}</span>
                              </label>
                            </div>
                          </td>
                        @else
                          <td align="center">-</td>
                        @endif --}}

                        <!-- Balance Amount Section -->
                        <td align="right">
                          <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">
                            <span class="fs-7">{{$pay->currency_symbol}}</span>
                            <span class="fs-7">{{ number_format($baseAmountBalance, 2) }}</span>
                            <span class="fs-7">/</span>
                          </div>
                          <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
                            <span class="fs-7">{{$pay->currency_symbol}}</span>
                            <span class="fs-7">{{ number_format($gstAmountBalance, 2) }}</span>
                            <span class="fs-7">/</span>
                          </div>
                          <div class="d-block">
                            <label class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Balance Amount">
                              <span class="fs-7">{{$pay->currency_symbol}}</span>
                              <span class="fs-7">{{ number_format($pay->balanceFee , 2) }}</span>
                            </label>
                          </div>
                        </td>

                        <!-- Status Column -->
                        <td>
                          @if($pay->payment_status == 1)
                            
                              <div class="text-center mb-1">
                                <span class=" badge {{$pay->currency_id ==70 ? 'bg-secondary text-white': 'bg-warning text-black'}}  fs-8 text-center px-2">   
                                  {{$pay->currency_code}}
                                </span>
                              </div>
                              <label class="badge bg-success text-black fw-semibold fs-6 ">Paid</label>
                          @else
                            
                              <div class="text-center mb-1">
                                <span class="badge {{$pay->currency_id ==70 ? 'bg-secondary text-white': 'bg-warning text-black'}}  fs-8 text-center px-2">   
                                  {{$pay->currency_code}}
                                </span>
                              </div>
                              <label class="badge bg-danger fw-semibold fs-6 ">Pending</label>
                          @endif
                        </td>
                        
                        <td>
                          <div class="d-flex gap-1 align-items-center">
                            @php
                              $encryptedValue = $helper->encrypt_decrypt($pay->proposal_sno, 'encrypt');
                              $payment = url('/cus_invoice/' . $encryptedValue);
                            @endphp

                            <!-- Pay Button: Highlighted with green color and hover effect -->
                              @if (auth()->user()->hasPermission($module_name, 'Pay', $menu_name))
                                <a href="{{ $payment }}" class="btn btn-sm btn-primary" >
                                  Pay
                                </a>
                              @endif
                              @if (auth()->user()->hasPermission($module_name, 'Reschedule', $menu_name))
                                @if($pay->jumper_skiper < 2)
                                  
                                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_reschedule" >
                                            <span class="mdi mdi-cash-sync fs-1 fw-bold" onclick="resch_function({{ json_encode($pay ?? []) }})">
                                        
                                    </span>
                                    </a>
                                
                                @endif
                              @endif
                              @if (auth()->user()->hasPermission($module_name, 'Reschedule Log', $menu_name))
                                @if($pay->jumper_skiper >=1)
                                  @if($pay->log_exist)
                                    <span id="" class=" cursor-pointer rounded-circle badge text-black fs-9" data-bs-toggle="modal" data-bs-target="#kt_modal_reschedule_log" onclick="rescheduleLog('{{ $pay->sno }}')"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reschedule Log" style="background-color: #f0913d !important;border:1px dashed white !important;"> 
                                      <span class="mdi mdi-information-variant fs-6"></span>
                                    </span>
                                  @endif
                                @endif
                              @endif
                            </div>
                        </td>
                     
                      </tr>
                    @endforeach
                  @endif
                </tbody>
              </table>

            </div>
            <div class="mt-4">
                {{ $OutstandingPayment->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>
<!-- Attendance Details Modal -->
<div class="modal fade" id="attendanceModal" tabindex="-1" aria-labelledby="attendanceModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Batch Attendance Details</h5>
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                  <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
      </div>
      <div class="modal-body" id="attendanceModalBody">
        <div class="text-center text-muted">Loading...</div>
      </div>
    </div>
  </div>
</div>
<script>
    function openAttendanceModal(studentId) {
    document.getElementById('attendanceModalBody').innerHTML = '<div class="text-center text-muted">Loading...</div>';

    const modal = new bootstrap.Modal(document.getElementById('attendanceModal'));
    modal.show();

    fetch('{{ route("proposal_details") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        body: JSON.stringify({ student_id: studentId })
    })
    .then(response => response.json())
    .then(data => {
       if (data.status === 'success') {
            const d = data.data;
            document.getElementById('attendanceModalBody').innerHTML = `
                <ul class="list-group">
                    <li class="list-group-item"><strong>Batch:</strong> ${d.batch_name}</li>
                    <li class="list-group-item"><strong>Total Days:</strong> ${d.total_days}</li>
                    <li class="list-group-item"><strong>Last Attendance:</strong> ${d.last_attendance_date ?? 'N/A'}</li>
                    <li class="list-group-item"><strong>Days Since Last:</strong> ${d.days_since_last ?? 'N/A'} day(s)</li>
                    <li class="list-group-item"><strong>Current Date:</strong> ${d.current_date}</li>
                     
                </ul>
            `;
        } else {
            document.getElementById('attendanceModalBody').innerHTML = `<p class="text-danger">${data.message}</p>`;
        }
    })
    .catch(error => {
        console.error(error);
        document.getElementById('attendanceModalBody').innerHTML = '<div class="text-danger">Error loading attendance details.</div>';
    });
}

</script>



<!--begin::Modal - Change Batch-->
<!--<div class="modal fade" id="kt_modal_reschedule" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">-->
  <!--begin::Modal dialog-->
<!--  <div class="modal-dialog modal-lg">-->
      <!--begin::Modal content-->
<!--      <div class="modal-content rounded">-->
          <!--begin::Modal header-->
<!--          <div class="modal-header justify-content-end border-0 pb-0">-->
              <!--begin::Close-->
<!--              <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">-->
                  <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
<!--                  <span class="svg-icon svg-icon-1">-->
<!--                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">-->
<!--                          <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />-->
<!--                          <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />-->
<!--                      </svg>-->
<!--                  </span>-->
                  <!--end::Svg Icon-->
<!--              </div>-->
              <!--end::Close-->
<!--          </div>-->
          <!--end::Modal header-->
          <!--begin::Modal body-->
<!--          <form id="rch_form" method="POST" action="{{ route('payment_reschdule') }}">-->
<!--            @csrf-->
<!--            <div class="modal-body pt-0 pb-6 px-10 px-xl-20">-->
              <!--begin::Heading-->
<!--              <div class="mb-4 text-center">-->
<!--                  <h3 class="text-center mb-4 text-black">Are You Sure Want to Change Schedule ?</h3>-->
<!--              </div>-->
<!--              <div class="row mt-2">-->
<!--                <input type="hidden" name="cus_payment_sno" id="cus_payment_sno">-->
<!--                <div id="cus_resch_pay_div"></div>-->
<!--                <div class="col-lg-12 text-start"></div>-->
<!--              </div>-->
<!--            </div>-->
          <!--end::Modal body-->
<!--          <div class="d-flex justify-content-center align-items-center mb-4">-->
<!--              <button type="submit"  class="btn btn-primary me-3">Yes</button>-->
<!--              <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>-->
<!--          </div>-->
<!--        </form>-->
<!--      </div>-->
      <!--end::Modal content-->
<!--  </div>-->
  <!--end::Modal dialog-->
<!--</div>-->
<!--end::Modal - Change Batch-->



<!--begin::Modal - Change Batch-->
<div class="modal fade" id="kt_modal_reschedule" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
          <!--begin::Modal header-->
          <div class="modal-header justify-content-end border-0 pb-0">
              <!--begin::Close-->
              <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                  <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                  <span class="svg-icon svg-icon-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                          <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                      </svg>
                  </span>
                  <!--end::Svg Icon-->
              </div>
              <!--end::Close-->
          </div>
          <!--end::Modal header-->
          <!--begin::Modal body-->
          <form id="resch_form" method="POST" action="{{ route('payment_reschdule') }}">
            @csrf
            <div class="modal-body pt-0 pb-6 px-10 px-xl-20">
              <!--begin::Heading-->
              <div class="mb-4 text-center">
                  <h3 class="text-center mb-4 text-black">Are You Sure Want to Change Schedule ?</h3>
              </div>
              <div class="row mt-2">
                <input type="hidden" name="cus_payment_sno" id="cus_payment_sno">
                <div id="cus_resch_pay_div"></div>
                <div class="col-lg-12 text-start"></div>
              </div>
            </div>
          <!--end::Modal body-->
          <div class="d-flex justify-content-center align-items-center mb-4">
              <button type="button"  class="btn btn-primary me-3" id="reshedule_submit" onclick="submit_resch_func()">Yes</button>
              <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
          </div>
        </form>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Change Batch-->



  <div class="modal fade" id="kt_modal_reschedule_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content rounded shadow-lg">
            <!-- Modal Header -->
            <div class="modal-header justify-content-end border-0 pb-0">
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="text-center mb-8">
                    <h3 class="text-center mb-4 text-black">Reschedule Log Details</h3>
                </div>

                <div class="row">
                    <!-- Customer Info (Left Section) -->
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer Name</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="customer_name_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Service Title</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="service_title_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Email</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="customer_email_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="customer_mobile_log"></label>
                        </div>
                      
                    </div>

                    <!-- Proposal Info (Right Section) -->
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Proposal Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="proposal_date_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 fs-6 fw-bold text-black" id="amount_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 fs-6 fw-bold text-black" id="total_amount_log"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Converted Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 fs-6 fw-bold text-black" id="customer_date_log"></label>
                        </div>
                    </div>
                </div>

                <!-- Staff Info -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">CRE Staff</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="cre_staff_name_log"></label>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Sales Staff</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" >
                              <span id="sales_staff_name_log"></span> <span id="sale_check" class="fs-8 badge bg-info ">Pre sale</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Reschedule Log Table -->
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Previous Date</th>
                                <th class="min-w-150px">Reschedule Date</th>
                                <th class="min-w-50px">Rescheduled By</th>
                                <th class="min-w-50px">Rescheduled At</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7" id="reschedule_log_div">
                            <tr>
                                <td colspan="4">No reschedule log available</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>









<!--begin::Modal - Request For FSC-->
<div class="modal fade" id="kt_modal_request_for_fsc" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Requested for Amount Schedule Count</h3>
                </div>
                <div class="row mt-4">
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Previous Allocated Count</label>
                        <div class="d-block">
                            <div class="badge bg-info mb-1 fs-6 fw-semibold" id="previous_allocated_count" >0</div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3 text-center">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Extended Count</label>
                        <div class="d-block">
                            <div class="badge bg-warning text-black mb-1 fs-6 fw-semibold" id="extended_count">0</div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Reason</label>
                        <div class="d-block">
                            <label class="text-dark mb-1 fs-6 fw-bold" id="request_reason"></label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_acpt" name="fsc_status" onclick="fsc_sts_func('accept');" checked />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Approved</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="fsc_sts_rejt" name="fsc_status" onclick="fsc_sts_func('reject');" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3" id="rejct_tbox" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold" >Reason<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="rejection_reason" placeholder="Enter Reason" ></textarea>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" id="smt_butt" onclick="submitForm()">Approved</a>
                    </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Request For FSC-->

<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Profile Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex justify-content-center align-items-center">
        <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
      </div>
    </div>
  </div>
</div>





<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>

  function formatCurrency(amount) {
        let formattedAmount = new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR'
        }).format(amount);

        // Insert a space between the ₹ symbol and the amount
        return formattedAmount.replace('₹', '₹ ');
    }
    function formatDate(dateString) {
        const date = new Date(dateString);

        // Extract the day, month, and year
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();  // Full year (e.g., 2024)

        // Return the formatted date string
        return `${day}-${month}-${year}`;
    }

 function resch_function(data) {
      $('#cus_payment_sno').val(data.sno);
      var html = `<div class="ms-2">
                    <div class="row">
                      <div class="col-lg-12 text-start mt-2">
                          <div class="row">
                              <label class="col-5 text-dark fs-6 fw-semibold">Customer</label>
                              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                              <label class="col-6 text-black fs-6 fw-bold">${data.cus_name}</label>
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                          <div class="row">
                              <label class="col-5 text-dark fs-6 fw-semibold">Customer ID</label>
                              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                              <label class="col-6 text-black fs-6 fw-semibold"><span class="badge bg-warning fs-7 fw-bold text-black fw-bold"> ${data.customer_id} </span></label>
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                          <div class="row">
                              <label class="col-5 text-dark fs-6 fw-semibold">Service</label>
                              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                              <label class="col-6 text-black fs-6 fw-bold">${data.service_title ?? "-"}</label>
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                          <div class="row">
                              <label class="col-5 text-dark fs-6 fw-semibold">Payment ID</label>
                              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                              <label class="col-6 text-black fs-6 fw-bold"><span class="badge bg-info fs-7 fw-bold text-white fw-bold"> ${data.payment_id ?? '-'} </span></label>
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                        <div class="row">
                            <label class="col-5 text-dark fs-6 fw-semibold">Schedule Amount</label>
                            <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                            <label class="col-6 text-black fs-6 fw-bold"> ${formatCurrency(data.total_amount ?? '0')} </label>
                        </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                          <div class="row">
                              <label class="col-5 text-dark fs-6 fw-semibold">Maximum Due Date</label>
                              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                              <label class="col-6 text-black fs-6 fw-bold"> <span class="badge bg-success fs-7 fw-bold text-white fw-bold">${formatDate(data.nextPayDate)?? '-'}</span></label>
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                        <div class="row">
                          <label class="col-5 text-dark fs-6 fw-semibold">Maximum Reschedule Date</label>
                          <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                          <?php
                            $currentDate = new DateTime();
                            $days = $helper->general_setting_data()->max_reschedule_date??0;
                            $currentDate->modify('+'.$days.' days');
                            $futureDate = $currentDate->format('d-M-Y');
                          ?>
                          <label class="col-6 text-black fs-6 fw-bold" ><span class="badge bg-danger fs-6 fw-bold text-white fw-bold"><?php echo $futureDate; ?></span></label>
                          <input type="hidden" name="max_reschedule_date" id="max_reschedule_date" value="<?php echo $futureDate; ?>">
                          </div>
                      </div>
                      <div class="col-lg-12 text-start mt-2">
                        <div class="row">
                          <label class="col-5 text-dark fs-6 fw-semibold">Custom Reschedule Date</label>
                          <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                          <label class="col-6 text-black fs-6 fw-bold">
                              <div class="input-group input-group-merge">
                                  <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                  <input type="text" id="custom_reschedule_date" name="custom_reschedule_date" placeholder="Select Date" class="form-control common_date_cus" readonly value="<?php echo $futureDate; ?>" />
                              </div>
                              <div id="custom_reschedule_date_err" class="text-small text-danger"></div>
                          </label>
                          </div>
                      </div>
                    </div>
                  </div>`;

            

      // Assuming you want to append this HTML somewhere
      document.getElementById('cus_resch_pay_div').innerHTML = html; // Replace 'yourContainerId' with the actual ID of your container element

      $(".common_date_cus").datepicker({
          format: "dd-M-yyyy",
          autoclose: true,
          todayHighlight: true,
      }).datepicker("setDate", $("#max_reschedule_date").val());
    }

 function rescheduleLog(id) {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch(`/reschedule_log/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken,
        },
        body: JSON.stringify({})
    })
    .then(response => response.json())
    .then(data => {
        var customer = data.customer;

        // Update customer info
        $('#customer_name_log').text(customer.cus_name || '-');
        $('#customer_mobile_log').text(customer.cus_mobile || '-');
        $('#customer_email_log').text(customer.cus_email_id || '-');
        $('#service_title_log').text(customer.service_title || '-');
        $('#customer_date_log').text(customer.converted_date ? formatDate(customer.converted_date) : '-');
        // $('#gst_amount_log').text(formatCurrency(customer.gst_amount, customer.currency_symbol));
        $('#amount_log').text(formatCurrencyCode(customer.amount, customer.currency_symbol));
        $('#total_amount_log').text(formatCurrencyCode(customer.total_amount, customer.currency_symbol));

        // Proposal Date (First transaction date with status 0)
        $('#proposal_date_log').text(customer.proposal_date || '-');

        // Fetch Staff Info
        let creStaffName = customer.cre_staff_name || '-';
        $('#cre_staff_name_log').text(creStaffName);

        let salesStaffName = customer.post_sale_check == 1 ? customer.post_sale_staff_name : customer.sales_staff_name;
        let pre_sale = customer.post_sale_check == 1 ? 'Post Sale' : 'Pre Sale';
        $('#sales_staff_name_log').text(salesStaffName || '-');
        $('#sale_check').text(pre_sale || '-');

        // Populate the reschedule log table
        const transferLogDiv = document.getElementById('reschedule_log_div');
        transferLogDiv.innerHTML = '';  // Clear existing log

        if (data.data && Array.isArray(data.data) && data.data.length) {
            data.data.forEach(item => {
                let staffName = item.staff_name || '-';
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${formatDate(item.previous_date) || '-'}</td>
                    <td>${formatDate(item.reschedule_date) || '-'}</td>
                    <td>${staffName}</td>
                    <td>${formatDate(item.created_at) || '-'}</td>
                `;
                transferLogDiv.appendChild(row);
            });
        } else {
            transferLogDiv.innerHTML = '<tr><td colspan="4">No reschedule logs available</td></tr>';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        toastr.error('An error occurred: ' + error.message);
    });
}

// Helper function to format currency
function formatCurrencyCode(amount, currencySymbol) {
    if (!amount) return '-';
    return currencySymbol + ' ' + parseFloat(amount).toLocaleString();
}

</script>
<script>
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
    .txt_vertical {
      writing-mode: vertical-lr;
      transform: rotate(180deg);
    }
</style>
<style>


    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }
    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
     .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite; /* Outer pulse effect */
        border: 2px solid red; /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white; /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%; /* Make the icon circular */
        animation: pulseInner 1.5s infinite; /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }
        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>

// Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>

<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
    } else {
      $('.sorting_filter_class').val(25);
      $('#search_form').submit();
    }
  }
</script>






<script>
    $(".list_page").DataTable({
        "ordering": false,
         "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection
