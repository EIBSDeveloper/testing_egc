@extends('layouts/blankLayout')

@section('title', 'ETPL Verified Screen')
@section('vendor-style')
@endsection


@section('content')
<style>
  body {
    background: transparent !important;
    font-size: 14px;
    margin: 0;
    padding: 8px;
  }

  p { margin: 0 !important; }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  table tr, td, th {
    border: 1px solid #acaaaa;
  }

  .invoice-wrapper {
    max-width: 800px;
    margin: auto;
    border: 1px solid #acaaaa;
    border-radius: 10px;
    overflow: hidden;
    background: white;
  }

  .invoice-header {
    background: #3c9540;
    color: white;
    padding: 10px;
    text-align: center;
    font-weight: bold;
  }

  .flex-row {
    display: flex;
    flex-wrap: wrap;
    gap: 1px;
  }

  .block {
    flex: 1 1 250px;
  }

  .info-row {
    display: flex;
    /* flex-wrap: wrap; */
    margin-bottom: 5px;
  }

  .mdi:before, .mdi-set {
      font-size: 14px;
  }

  .label {
    font-weight: medium;
    min-width: 100px;
  }

  .table-responsive {
    overflow-x: auto;
  }

  .terms {
    font-size: 12px;
    font-weight: 600;
  }

  img {
    max-width: 100%;
    height: auto;
  }
  .mobileres{
      display: none;
    }




  /* MOBILE */
  @media (max-width: 425px) {
    body { font-size: 13px; }
    .invoice-header {
      font-size: 16px;
      display: flex;
      flex-direction: column;
     }
    .label { min-width: 105px; }


      .companycenter{
    text-align:center;
    }

    .mobileres{
      display: block;
    }

    .defaultscreen{
      display:none;
    }


  /* .info-row {
    display: flex;
    flex-direction: column;
    margin-bottom: 5px;
  } */
  }
  /* MOBILE */
  @media (max-width: 600px) {
    body { font-size: 13px; }
    .invoice-header {
      font-size: 16px;
      display: flex;
      flex-direction: column;
     }
    .label { min-width: 105px; }

    .companycenter{
    text-align:center;
    }

    .mobileres{
      display: block;
    }

    .defaultscreen{
      display:none;
    }


  }

  /* PRINT */
  @media print {

    body { padding: 0; }

    .invoice-wrapper {
      max-width: 100%;
      border-radius: 0;
    }

    /* hide screen layout */
    .print-hide {
      display: none !important;
    }

    /* print layout as 3 equal columns */
    .print-inline {
      display: grid !important;
      grid-template-columns: 1fr 1fr 1fr;
      column-gap: 20px;
      font-weight: bold;
      margin-bottom: 5px;
    }

    .heading{
      display:inline-flex !important;
    }

  }

</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
@endphp
<div class="invoice-wrapper">

    <!-- HEADER -->
    <div class="invoice-header" style="background: #099DDA;">
      <div style="display: flex; align-items: center; justify-content:center; padding-top:2px;">
        <h2 style="color:white;"> Verified Receipt</h2>
        <img src="{{asset('assets/phdizone_images/tick.png')}}" style="padding-bottom: 12px; width: 40px; height: 40px; object-fit: cover;">
      </div>

      <label>{{$paySlots->invoice_id}}</label>
    </div>


    <div class="flex-row  mobileres" style=" padding:10px; ">

      <div class="block info-row">
        <div class="label"> <span class="mdi mdi-account-circle" style="padding-right: 3px;"></span>Customer</div>
        <div  ><b style="color: black;">{{$proposal->lead_name}}</b></div>
      </div>

      <div class="block info-row">
        <div class="label"><span class="mdi mdi-cellphone" style="padding-right: 3px; color:#4d4d4d;"></span>Mobile</div>
        <div><b style="color: black;">{{$proposal->lead_mobile ?? '-'}}</b></div>
      </div>

      <div class="block info-row">
        <div class="label"><span class="mdi mdi-tag" style="padding-right: 3px; color:#4d4d4d;"></span>ID</div>
        <div><b style="color: black;">{{$proposal->customer_id}}</b></div>
      </div>

      <div class="block info-row">
        <div class="label"><span class="mdi mdi-email" style="padding-right: 3px; color:#4d4d4d;"></span>Email</div>
        <div><b style="color: black;">{{$proposal->lead_email ?? '-'}}</b></div>
      </div>

      <div class="info-row">
        <div class="label"><span class="mdi mdi-note-edit" style="padding-right: 3px; color:#4d4d4d;"></span>Service</div>
        <div style="display:flex; align-items:flex-start; gap:4px;">
          <b style=" display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; color: black;">
            {{$proposal->service_title}}
          </b>

        </div>

      </div>
    </div>

    <div class="row defaultscreen" style=" padding:10px; ">
      <div class="col-lg-6  col-md-6  col-sm-6 mb-4">
        <div class="row">
          <div class="col-5"><div class="label"> <span class="mdi mdi-account-circle" style="padding-right: 3px;"></span>Customer</div></div>
          <div class="col-1">:</div>
          <div class="col-6 ">
          <div  ><b style="color: black;">{{$proposal->lead_name}}</b></div>
          </div>
        </div>
      </div>
      <div class="col-lg-6  col-md-6  col-sm-6 mb-4">
        <div class="row">
          <div class="col-5"><div class="label"><span class="mdi mdi-cellphone" style="padding-right: 3px; color:#4d4d4d;"></span>Mobile</div></div>
          <div class="col-1">:</div>
          <div class="col-6 ">
           <div><b style="color: black;">{{$proposal->lead_mobile ?? '-'}}</b></div>
          </div>
        </div>
      </div>
      <div class="col-lg-6  col-md-6  col-sm-6 mb-4">
        <div class="row">
          <div class="col-5"><div class="label"><span class="mdi mdi-tag" style="padding-right: 3px; color:#4d4d4d;"></span>ID</div></div>
          <div class="col-1">:</div>
          <div class="col-6 ">
           <div><b style="color: black;">{{$proposal->customer_id}}</b></div>
          </div>
        </div>
      </div>
      <div class="col-lg-6  col-md-6  col-sm-6 mb-4">
        <div class="row">
          <div class="col-5"><div class="label"><span class="mdi mdi-email" style="padding-right: 3px; color:#4d4d4d;"></span>Email</div></div>
          <div class="col-1">:</div>
          <div class="col-6 ">
           <div><b style="color: black;">{{$proposal->lead_email ?? '-'}}</b></div>
          </div>
        </div>
      </div>
      <div class="col-lg-12 mb-4">
        <div class="row">
          <div class="col-12"><div class="label"><span class="mdi mdi-note-edit" style="padding-right: 3px; color:#4d4d4d;"></span>Service</div></div>
          {{-- <div class="col-1">:</div> --}}
          <div class="col-12 ">
           <div><b style="color: black;"> {{$proposal->service_title}}</b></div>
          </div>
        </div>
      </div>
    </div>




  <!-- COMPANY -->
  <div style="background:#ddd;padding:10px;" class="mainhead">
    <div class="flex-row heading">
      <div class="block" style="display: flex; align-items: center; justify-content:center;">
        <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" width="325" height="60">
      </div>
      <div class="block">
        <h2 style="margin:0;  " class=" fw-bold companycenter">Elysium Technologies Private Ltd</h2>
        <div style="padding-top:10px;"><span class="mdi mdi-pin" style="padding-right: 3px;"></span>{{ $proposal->door_no ? $proposal->door_no . ', ' : '' }}
                                {{ $proposal->area_street ? $proposal->area_street . ', ' : '' }}
                  {{ $proposal->city_name ? $proposal->city_name . ', ' : '' }}
                                {{ $proposal->state_name ? $proposal->state_name . ', ' : '' }}
                                {{ $proposal->country_name ?? '' }} {{ $proposal->pincode ?? '' }} </div>
        <div><span class="mdi mdi-cellphone" style="padding-right: 3px;"></span>+91 {{$proposal->branch_mobile}}</div>
        <div><span class="mdi mdi-email" style="padding-right: 3px;"></span>{{$proposal->branch_mail}}</div>
        <div><span class="mdi mdi-calendar-blank" style="padding-right: 3px;"></span>{{ $paySlots->transaction_date ? date($common_date_format, strtotime($paySlots->transaction_date)) : '-' }}</div>
      </div>
    </div>
  </div>

  <!-- CUSTOMER -->

  <div style="padding:10px;">

    <!-- PRINT VERSION (single line) -->
    <div class="print-inline" style="display:none;">
      <div>Customer: <b style="margin-left:25px ">{{$proposal->lead_name}}</b></div>
      <div>Mobile: <b style="margin-left:25px ">{{$proposal->lead_mobile ?? '-'}}</b></div>
      <div>ID: <b style="margin-left:25px ">{{$proposal->customer_id}}</b></div>
    </div>


  </div>


  <!-- TABLE -->
  <div class="table-responsive" style="padding-left: 10px ; padding-right: 10px ;">
    <table>
      <thead style="background:#099DDA;color:white;">
        <tr>
          <th>S.No</th>
          <th>Particular</th>
          <th>Gross Amount</th>
        </tr>
      </thead>

      <tbody>
        <tr>
          <td align="center">1</td>
          <td>{{$paySlots->payment_slot_name }}</td>
          <td align="right" style=" color:black; font-weight:500">{{$proposal->currency_symbol}}{{number_format($paySlots->credit)}}</td>
        </tr>

        <tr>
          <td colspan="2" align="right"><b>GST (18%)</b></td>
          <td align="right" style=" color:black; font-weight:500">{{$proposal->currency_symbol}}{{number_format($paySlots->tax)}}</td>
        </tr>

        <tr>
          <td colspan="2" align="right"><b>Grand Total</b></td>
          <td align="right" ><b style=" color:black;">{{$proposal->currency_symbol}}{{number_format($paySlots->grand_total)}}</b></td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- PAYMENT -->
  <div style="padding:10px;" class="flex-row mobileres">

    <div class="block">
      <div>Payment Mode</div>
      <b style=" color:black;">{{$paymentModeText}}</b>
    </div>

    <div class="block">
      <div>Transaction ID</div>
      <b style=" color:black;">{{$transaction_id ?? '-'}}</b>
    </div>

  </div>


  <div class="row defaultscreen px-3 py-3" >
    <div class="col-lg-12 d-flex justify-content-between align-items-center">
      <div class="d-flex flex-column">
        <div>Payment Mode</div>
        <b style=" color:black;">{{$paymentModeText}}</b>
      </div>
      <div class="d-flex flex-column align-items-end justify-content-end">
        <div>Transaction ID</div>
        <b style=" color:black;">{{$transaction_id ?? '-'}}</b>
      </div>
    </div>
  </div>

  <!-- AMOUNT WORDS -->
  <div style="font-weight:bold; color:rgb(204, 68, 68); font-size:17px; text-align:center;">
    {{ ($helper->convertNumberToWords($paySlots->grand_total)) }} Only.
  </div>

  <hr>

  <!-- TERMS + QR -->
  <div class="flex-row" style="padding:10px 10px 0px 10px; ">

    <div class="block terms">
      TERMS & CONDITIONS<br>
      1. The payment is not refundable, Once registered<br>
      2. Only the registered candidates can communicate with the staff. Others should not be involved in the work<br>
      3. Your work is a more confidential one. It won't be shared or discussed anybody else.<br>
      4. The requirements should be submitted as a document. Verbal conversation is not allowed for modification<br>
      5. If your development needs infrastructure means that costing separately added to client end, Like GPU, Core GPU,NVIDIA A100 Tensor,RTX 4090,etc.,<br>
      6. If not, Infrasturctue client end only.
    </div>

    {{-- <div class="block" style="text-align:center;">
      <img src="{{asset('assets/phdizone_images/Qr Catalogue.png')}}" width="150">
    </div> --}}

  </div>

  <div class="" style="padding:5px 10px 5px 10px;">
    <img src="{{asset('terms_condition_signature')}}/{{$signature}}" style="width:100px;" alt="user-avatar" id="uploadedlogo" >
  </div> 

  <div style="padding:0px 10px 10px 10px;font-weight:bold;">
    Authorized Signature
  </div>

</div>


@endsection
