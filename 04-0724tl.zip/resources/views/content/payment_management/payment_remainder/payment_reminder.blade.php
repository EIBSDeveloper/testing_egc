@extends('layouts/layoutMaster')

@section('title', 'Manage Harvesting')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->


<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp

        <div class="row">

            <div class="col-lg-6">
                <h5 class="card-title mb-1">Manage Harvesting</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Manage Payments</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-lg-6">
                <ul class="nav nav-pills justify-content-end" role="tablist">
                    @php
                        $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
                        $currentYear = request()->get('year', date('Y')); // Default to current year if not provided

                        // Calculate previous month and year
                        $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; 
                        $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; 

                        // Calculate next month and year
                        $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
                        $nextYear=$currentMonth==12 ? $currentYear + 1 : $currentYear; 
                    @endphp 
                    <div class="col-lg-3">
                        <form action="{{ url('payment_remainder') }}" method="get">
                            <select class="select3 form-select" name="pay_rem_fill" id="pay_rem_fill"
                                onchange="this.form.submit()">
                                <option value="today" {{ request()->input('pay_rem_fill') == 'today' ? 'selected' : ''
                                    }}>Today</option>
                                <option value="next_day" {{ request()->input('pay_rem_fill') == 'next_day' ? 'selected'
                                    : '' }}>Next Day</option>
                                <option value="3rd_day" {{ request()->input('pay_rem_fill') == '3rd_day' ? 'selected' :
                                    '' }}>3<sup>rd</sup> Day
                                </option>
                                <option value="4th_day" {{ request()->input('pay_rem_fill') == '4th_day' ? 'selected' :
                                    '' }}>4<sup>th</sup> Day
                                </option>
                                <option value="5th_day" {{ request()->input('pay_rem_fill') == '5th_day' ? 'selected' :
                                    '' }}>5<sup>th</sup> Day
                                </option>
                                <option value="6th_day" {{ request()->input('pay_rem_fill') == '6th_day' ? 'selected' :
                                    '' }}>6<sup>th</sup> Day
                                </option>
                                <option value="7th_day" {{ request()->input('pay_rem_fill') == '7th_day' ? 'selected' :
                                    '' }}>7<sup>th</sup> Day
                                </option>
                            </select>
                        </form>
            </div>
            </ul>
        </div>
    </div>
</div>
<div class="card-body">

    <div class="row">
        <div class="d-flex justify-content-between align-items-start flex-wrap gap-3">
            <!-- Per Page Dropdown -->
            <div>
                @php $perpage_count = $perpage ? $perpage : 25; @endphp
                <div>
                    <label class="mb-1 fw-semibold">Show</label>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-75px"
                        onchange="sort_filter(this.value);">
                        @php $options = [10, 25, 100, 500]; @endphp
                        @foreach ($options as $option)
                        <option value="{{ $option }}" {{ $perpage_count==$option ? 'selected' : '' }}>
                            {{ $option }}
                        </option>
                        @endforeach
                    </select>
                </div>
            </div>

            <!-- Search Form -->
            <div class="mb-2">
                <form id="search_form" method="POST" action="/payment_harvesting">
                    @csrf
                    <div class="d-flex align-items-end gap-2">
                        <div>
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                value="{{ $perpage ?? 10 }}" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                            <input type="text" class="form-control form-control-sm" id="cus_fill" name="cus_fill"
                                value="{{ $cus_fill ?? '' }}" placeholder="Customer ID / Name / Mobile No." />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Search</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                <thead>
                    <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="min-w-100px">Customer</th>
                        <th class="min-w-80px text-start">Service</th>
                        <th class="min-w-50px text-center">Schedule<br>Date</th>
                        <th class="min-w-50px">Paid&nbsp;Date</th>
                        <th class="min-w-50px">Currency</th>
                        <th class="min-w-100px">Payment</th>
                        <th class="min-w-50px">GST</th>
                        <th class="min-w-50px">Payment <br> (without GST)</th>
                    </tr>
                </thead>
                <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                    @if (isset($HistoryPayment))
                    @php
                    $total_gst_curr = 0;
                    $total_paid_curr = 0;
                    @endphp
                    @foreach ($HistoryPayment as $i=> $pay)
                    @php
                    $currentdate = date('Y-m-d'); // Gets the current date in 'YYYY-MM-DD' format
                    $nextPayDate = \Carbon\Carbon::parse($pay->nextPayDate); // Convert nextPayDate to Carbon instance
                    $extendays = $nextPayDate->diffInDays($currentdate, false); // Get the difference in days

                    $registeredDate = $nextPayDate;
                    $diff = $registeredDate->diff($currentdate); // Use diff() instead of diffInDays()

                    $months = $diff->m;
                    $days = $diff->d;

                    // If the difference in months is 0, just show the days count.
                    if ($months == 0) {
                    $formattedDifference = "{$days} day" . ($days != 1 ? 's' : '');
                    } else {
                    $formattedDifference = "{$months} month" . ($months != 1 ? 's' : '') . " and {$days} day" . ($days
                    != 1 ? 's'
                    : '');
                    }



                    $color = '';
                    // echo "Payment extended by $days days.";

                    if ($pay->payment_status == 0) {
                        $color = '';
                        if ($nextPayDate < $currentdate) {
                            $color='#e64a4a' ; 
                        } 
                    } else { 
                        if ($pay->payment_paid_amt < $pay-> payment_amount) {
                            $color = '#ffff8f'; // Partial payment
                        } elseif ($pay->payment_paid_amt >= $pay->payment_amount) {
                            $color = '#abe8ab'; // Fully paid
                        }
                    }

                    if($pay->payment_status == 0){
                        $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
                        $baseAmount = $pay->payment_amount / (1 + $gstRate); // amount before GST
                        $gstAmount = $pay->payment_amount - $baseAmount;

                        if ($pay->currency_id != 70) {
                            $total_paid_curr += $helper->ConvertedAmountInr($pay->currency_code,
                            $pay->payment_amount);
                            $total_gst_curr += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
                        } else {
                            $total_paid_curr += $pay->payment_amount;
                            $total_gst_curr += $gstAmount;
                        }
                    }else{
                        $gstRate = $pay->gst_perc > 0 ? $pay->gst_perc/100 : 0 ;
                        $baseAmount = $pay->payment_paid_amt / (1 + $gstRate); // amount before GST
                        $gstAmount = $pay->payment_paid_amt - $baseAmount;

                        if ($pay->currency_id != 70) {
                            $total_paid_curr += $helper->ConvertedAmountInr($pay->currency_code,
                            $pay->payment_paid_amt);
                            $total_gst_curr += $helper->ConvertedAmountInr($pay->currency_code, $gstAmount);
                        } else {
                            $total_paid_curr += $pay->payment_paid_amt;
                            $total_gst_curr += $gstAmount;
                        }
                    }

                                    @endphp
                                    <tr style="background-color: {{ $color }};">
                                        <td>
                                            <div class="d-flex align-items-center px-1">

                                                <div class="mb-0 align-items-center">
                                                    <span>
                                                        <!--<span class="fs-6 me-1" data-bs-toggle="modal" data-bs-target="#kt_modal_cus_view" onclick="viewCustomerDetails({{ $pay->customer_sno }})">-->
                                                        <span class="fs-6 me-1">
                                                            {{ $pay->cus_name }}
                                                        </span>
                                                    </span>
                                                    <div class="d-block text-dark fs-8" title="Mobile NO">{{
                                                        $pay->cus_mobile }}</div>
                                                    <span class="d-block text-dark text-nowrap fs-8"
                                                        title="Customer ID">{{ $pay->customer_id
                                                        }}</span>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-start">
                                            <div class="d-block mt-1">
                                                <span class="badge bg-label-dark fs-7 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="{{ $pay->service_title }}"
                                                    style="max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"
                                                    class="text-truncate">
                                                    {{ $pay->service_title }}
                                                </span>
                                                <div class="d-block text-dark fs-8" title="Milestone ID">{{
                                                    $pay->propo_pay_slot_id }}</div>

                                                <div class="d-block text-dark fs-6">
                                                    @if($pay->payment_status == 0)

                                                    @if($extendays > 1 )
                                                    <span class="badge bg-danger animation-blink" title="Days Extended">
                                                        {{ $formattedDifference }}
                                                        @else
                                                    </span>
                                                    @endif
                                                    @endif
                                                </div>


                                            </div>
                                        </td>
                                        <!-- Paid Fees Section -->

                                        <td class="text-center">
                                            <span class="fs-7 fw-bold text-nowrap">{{
                                                date($common_date_format,strtotime(date($pay->nextPayDate))) }}</span>
                                        </td>
                                        <td class="text-center">
                                            @if($pay->payment_status == 1)
                                            <span class="fs-7 fw-bold text-nowrap">{{
                                                date($common_date_format,strtotime(date($pay->initialPayDate)))
                                                }}</span>
                                            @else
                                            <span class="fs-7 fw-bold">-</span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            <span
                                                class="badge {{$pay->currency_id ==70 ? 'bg-secondary text-white': 'bg-warning text-black'}} rounded fs-6 px-2">
                                                {{$pay->currency_code}}
                                            </span>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-flex no-wrap align-items-center">
                                                @if($pay->payment_status == 0)
                                                <span class="bg-label-warning rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Schedule Amount">&#8377;
                                                        {{number_format($helper->ConvertedAmountInr($pay->currency_code,$pay->payment_amount),2)}}</span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Schedule Amount">&#8377;{{
                                                        number_format($pay->payment_amount, 2) }}</span>
                                                    @endif
                                                </span>

                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($pay->payment_amount, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>

                                                @else
                                                <span class="bg-label-success rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Paid Amount">&#8377;
                                                        {{number_format($helper->ConvertedAmountInr($pay->currency_code,$pay->payment_paid_amt),2)}}
                                                    </span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Paid Amount">&#8377;{{
                                                        number_format($pay->payment_paid_amt, 2) }}</span>
                                                    @endif
                                                </span>

                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($pay->payment_paid_amt, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>

                                                @endif
                                            </div>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-flex no-wrap align-items-center">
                                                @if($pay->payment_status == 0)
                                                <span class="bg-label-secondary rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="GST Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$gstAmount),2)}}</span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="GST Amount">&#8377;{{
                                                        number_format($gstAmount, 2) }}</span>
                                                    @endif

                                                </span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($gstAmount, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>
                                                @else
                                                <span class="bg-label-secondary rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="Paid GST Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$gstAmount),2)}}</span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Paid GST Amount">&#8377;{{
                                                        number_format($gstAmount, 2) }}</span>
                                                    @endif

                                                </span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($gstAmount, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>
                                                @endif
                                            </div>
                                        </td>
                                        </td>
                                        <td class="text-end">
                                            <div class="d-flex no-wrap align-items-center">
                                                @if($pay->payment_status == 0)
                                                <span class="bg-label-warning rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="Schedule Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$baseAmount),2)}}</span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Schedule Amount">&#8377;{{
                                                        number_format($baseAmount, 2) }}</span>
                                                    @endif

                                                </span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($baseAmount, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>
                                                @else
                                                <span class="bg-label-success rounded fs-6 px-2 text-nowrap">
                                                    @if($pay->currency_id !=70)
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="Paid Amount">&#8377;{{number_format($helper->ConvertedAmountInr($pay->currency_code,$baseAmount),2)}}</span>
                                                    @else
                                                    <span class="fw-bold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Paid Amount">&#8377;{{
                                                        number_format($baseAmount, 2) }}</span>
                                                    @endif

                                                </span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="right"
                                                    title="{{$pay->currency_symbol .' '. number_format($baseAmount, 2)}}"><i
                                                        class="mdi mdi mdi-help-circle text-dark"></i></span>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                </tbody>
            </table>

        </div>
        <div class="mt-4">
            {{ $HistoryPayment->appends(request()->except(['page', '_token']))->links() }}
        </div>
    </div>
</div>
</div>


<!--begin::Modal - View Lead-->
<div class="modal fade" id="kt_modal_cus_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-6">
                    <h3 class="text-center text-black">Payment Details</h3>
                </div>
                <form>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold"><u>Customer Information</u></div>
                        <div class="col-lg-6" id="customer-details">
                            <!-- Customer details will be injected here -->
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold"><u>Total Payments</u></div>
                        <div class="col-lg-12" id="customer-payments">
                            <!-- Customer details will be injected here -->
                        </div>
                    </div>
                    <div class="row">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page2">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-125px">Date</th>
                                    <th class="min-w-125px">MDD</th>
                                    <th class="min-w-100px">Schd.Amount</th>
                                    <th class="min-w-100px">Paid Amount</th>
                                    <th class="min-w-100px">Bal.Amount</th>
                                    <th class="min-w-80px">Status</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7" id="payment-table-body-model">
                                <!-- Payment details will be injected here -->
                            </tbody>
                        </table>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!--end::Modal - View Lead-->
<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Profile Image</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body d-flex justify-content-center align-items-center">
                <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
            </div>
        </div>
    </div>
</div>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    // Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
    function fsc_sts_func(val) {

        if (val == "reject") {
            document.getElementById("rejct_tbox").style.display = "block";
            document.getElementById("smt_butt").innerHTML = "Rejected";
        } else if (val == "accept") {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        } else {
            document.getElementById("rejct_tbox").style.display = "none";
            document.getElementById("smt_butt").innerHTML = "Approved";
        }
    }
</script>
<script>
    function viewCustomerDetails(customerId) {
    // Fetch customer and payment details based on customerId
    $.ajax({
      url: '/get_customer_details/' + customerId,
      method: 'GET',
      success: function(response) {
        // Inject customer details into the modal
        let customerDetails = `
        <div class="customer-info">
          <div class="row">
            <div class="col-12 col-md-6">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-account fs-5"></i> <strong>Name:</strong></span>
                <span class="info-value">${response.customer.cus_name}</span>
              </div>
            </div>
            <div class="col-12">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-phone-in-talk fs-5"></i> <strong>Mobile:</strong></span>
                <span class="info-value">${response.customer.cus_mobile}</span>
              </div>
            </div>
          </div>
        </div>
      `;
      
        // Extract payment details from response.payments array
       let totalFees = parseFloat(response.payments[0]?.total_amount || 0);
        let paidFees = 0;
        
        // Loop through payments array and sum up the total and paid fees
        response.payments.forEach(payment => {
            paidFees += parseFloat(payment.paidAmount || 0);
        });
        
       
        // Calculate balance fees
        let balanceFees = totalFees - paidFees;
        
       let paymentsDetails = `
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex flex-wrap gap-3 mt-2">
                    <span class="badge bg-info rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Total Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${totalFees.toFixed(2)}
                    </span>
                    <span class="badge bg-success rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Paid Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${paidFees.toFixed(2)}
                    </span>
                    <span class="badge bg-danger rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Balance Amount:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${balanceFees.toFixed(2)}
                    </span>
                </div>
            </div>
        </div>
    `;





        $('#customer-details').html(customerDetails);
        $('#customer-payments').html(paymentsDetails);
        let paymentRows = '';
        $.each(response.payments, function(index, payment) {
          const gstPercentage = parseFloat(response.gstPercentage) || 0;  // Ensure valid GST percentage

          // Calculate GST and totals once for reuse
          const courseFeeGST = parseFloat(payment.amount) * gstPercentage;
          const totalCourseFee = parseFloat(payment.amount) + courseFeeGST;

          const paidAmountGST = parseFloat(payment.paidAmount) * gstPercentage;
          const totalPaidAmount = parseFloat(payment.paidAmount) + paidAmountGST;

          const balanceFeeGST = parseFloat(payment.balanceFee) * gstPercentage;
          const totalBalanceFee = parseFloat(payment.balanceFee) + balanceFeeGST;

          // Start building payment row
          paymentRows += '<tr>';

          // Display the initial payment date
          paymentRows += '<td>' + payment.initialPayDate + '</td>';

          // Display next payment date with tooltip for maximum due date
          paymentRows += `<td>
            <div class="d-block mt-1">
              <span class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">
                ${payment.nextPayDate}
              </span>
            </div>
          </td>`;

          // Display scheduled fees with currency and GST
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.amount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 "><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${courseFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalCourseFee.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Display paid fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.paidAmount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${paidAmountGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalPaidAmount.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Display balance fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.balanceFee).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${balanceFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <span class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Amount">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalBalanceFee.toFixed(2)}</span>
              </span>
            </div>
          `;
          paymentRows += '</td>';

          // Status column (Paid or Pending)
          paymentRows += `<td>
            ${payment.status == 1 ?
              '<span class="badge bg-success text-black fw-semibold fs-6">Paid</span>' :
              '<span class="badge bg-danger fw-semibold fs-6">Pending</span>'
          }</td>`;

          paymentRows += '</tr>';
        });
        $('#payment-table-body-model').html(paymentRows);
      }
    });
  }

</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }

    .txt_vertical {
        writing-mode: vertical-lr;
        transform: rotate(180deg);
    }
</style>
<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }

    .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite;
        /* Outer pulse effect */
        border: 2px solid red;
        /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white;
        /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%;
        /* Make the icon circular */
        animation: pulseInner 1.5s infinite;
        /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }

        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }

        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }

        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>
    // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>






<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    $(".list_page2").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
</script>
<script>
    function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/payment_harvesting/?month_filter=' + val;
        
    }

</script>
@endsection