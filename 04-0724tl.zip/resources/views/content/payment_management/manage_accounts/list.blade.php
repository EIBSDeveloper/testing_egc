@extends('layouts/layoutMaster')

@section('title', 'Manage Accounts')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
   @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
        $current_page_url = !empty(request()->getRequestUri()) ? ltrim(str_replace(request()->getBaseUrl(), '', request()->getRequestUri()), '/') : '';
    @endphp
<!-- Journal List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Accounts</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Payment Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="text-end">
                 @if(auth()->user()->user_id <= 2)
                <div class="cursor-pointer input-group input-group-merge">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="ovr_month_fill" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo $month_filter ?? date("M-Y"); ?>" readonly onchange="month_filter(this.value)">
                </div>
                @else
                <input type="text" id="ovr_month_fill" class="btn btn w-75 form-control border-0 bg-primary text-white justify-content-start" value="<?php echo date("M-Y"); ?>" readonly>
                @endif
            </div>
        </div>
    </div>
        
    <div class="card-body">
        @if(auth()->user()->user_id==0)
            <div class="col-lg-6 d-flex flex-wrap align-items-center mb-2 gap-2">
                <a href="#" class="text-center border border-2 rounded p-2 mb-2">
                <div class="fw-semibold fs-6 text-black text-center">Total Amount</div>
                   <div class="d-block mb-2">
                       <div class="badge bg-transparent border border-info rounded fw-bold fs-6 text-black">
                          <i class="mdi mdi-currency-rupee"></i><span id="total_collection">{{number_format($total_collection,2) ?? 0}}</span> 
                       </div>
              
                      <div class="badge bg-transparent border border-danger rounded fw-bold fs-6 text-black" > 
                        <i class="mdi mdi-currency-rupee"></i> <span id="total_collection_gst">{{number_format($total_collection_gst,2) ?? 0}}</span>
                      </div>
                  </div>
                  <div class="d-block mb-2">
                  <div class="badge bg-info rounded fw-bold fs-6">
                      <i class="mdi mdi-currency-rupee"></i> <span id="total_collection_net">{{number_format($total_collection_net,2) ?? 0}}</span>
                  </div>
                  </div>
              
              </a>
                <span class="text-center border border-2 rounded p-2 mb-2">
                    <div class="fw-semibold fs-6 text-black text-center">Verified Amount</div>
                    <div class="d-block mb-2">
                        <div class="badge bg-transparent border border-success rounded fw-bold fs-6 text-black">
                            <i class="mdi mdi-currency-rupee"></i><span id="verified_collection">{{number_format($verified_collection,2) ?? 0}}</span>
                        </div>
                        <div class="badge bg-transparent border border-danger rounded fw-bold fs-6 text-black">
                            <i class="mdi mdi-currency-rupee"></i><span id="verified_collection_gst">{{number_format($verified_collection_gst,2) ?? 0}}</span>
                        </div>
                    </div>
                    <div class="d-block mb-2">
                        <div class="badge bg-success rounded fw-bold fs-6">
                            <i class="mdi mdi-currency-rupee"></i><span id="verified_collection_net">{{number_format($verified_collection_net,2) ?? 0}}</span>
                        </div>
                    </div>
                </span>
            </div>
            @endif
        <div class="d-flex justify-content-between align-items-center">
           
            <div class="mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div>
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
            </div>
            <div class="">
                <form id="search_form" method="POST" action="/manage_accounts">
                @csrf
                <div class="d-flex align-items-center gap-2">
                    <div class="mb-1">
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <input
                        type="text"
                        class="form-control"
                        id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                        placeholder="Enter Customer - Name/Mob/Email/INV"
                    />
                    </div>
                    
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1" onclick="search_filter_func()">Search</button>
                    <a href="{{ url('/manage_accounts') }}" type="button"
                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                        </a>
                </div>
                </form>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-center table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-center fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-125px">Customer</th>
                            <th class="min-w-80px text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal ID / Invoice ID / Receipt ID">ID's</th>
                            <th class="min-w-50px">Sub Ledger / Payment Date</th>
                            <th class="min-w-50px">Currency</th>
                            <th class="min-w-80px">Net Amount</th>
                            <th class="min-w-100px">Tax</th>
                            <th class="min-w-100px">Gross Amount</th>
                            <th class="min-w-50px">Status</th>
                            @if(auth()->user()->user_id == 0)
                            <th class="min-w-50px">Action</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                           
                           @if(isset($customers))
                           @foreach($customers as $i => $list)
                           
                           @php
                           $encryptedValue = $helper->encrypt_decrypt($list->pay_slot_id,'encrypt',);
                           $officeEncryptedValue = $helper->encrypt_decrypt($list->trans_sno,'encrypt',);
                           $print_url = url('/receipt_print/' . $encryptedValue,);
                           $office_print_url = url('/office_receipt_print/' . $officeEncryptedValue,);
                           $download_print_url = url('/receipt_print_download/' . $encryptedValue,);
                           $gstRate = $list->gst_perc > 0 ? $list->gst_perc/100 : 0 ;
                           $netAmount = $list->paid_amount / (1 + $gstRate); // amount before GST
                           $gstAmount = $list->paid_amount - $netAmount; 
                           if($list->paid_amount_inr){
                            $convertedPaidAmountInr=$list->paid_amount_inr;
                            $netAmountInr=$convertedPaidAmountInr / (1 + $gstRate);
                            $gstAmountInr=$convertedPaidAmountInr - $netAmountInr; 
                           }else{
                                $convertedPaidAmountInr=$helper->ConvertedAmountInr($list->currency_code,$list->paid_amount);
                                $netAmountInr=$convertedPaidAmountInr / (1 + $gstRate);
                                $gstAmountInr=$convertedPaidAmountInr - $netAmountInr; 
                           }
                           
                                
                           @endphp
                        <tr>
                            <td>
                                <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->cus_name}}">{{$list->cus_name}}</label>
                                <div class="d-block">
                                    @if($list->cus_mobile)
                                    <label class="text-dakr fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile NO">( +{{$list->country_code}} ) {{$list->cus_mobile}}</label>
                                    @endif
                                     @if($list->cus_email_id)
                                    <label class="cursor-pointer ms-1"><i class="mdi mdi-email-outline text-dark fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$list->cus_email_id}}"></i></label>
                                    @endif
                                </div>
                                <div class="d-block">
                                    <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{$list->customer_id}}</div>
                                </div>
                            </td>
                            <td>
                                <div class="badge bg-secondary rounded fw-semibold text-white mb-1 fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal ID">{{$list->proposal_id}}</div>
                                <div class="d-block mb-1">
                                    <label class="badge bg-success rounded fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Receipt ID">{{$list->invoice_id}}</label>
                                </div>
                                <div class="d-block mb-1">
                                    <label class="badge bg-info rounded fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Transaction ID">{{$list->transaction_id}}</label>
                                </div>
                            </td>
                            <td>
                                <div class="fw-semibold text-black fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sub Ledger">{{$list->subledger_name}}</div>
                                <div class="d-block">
                                    <label class="badge bg-warning fw-semibold text-black fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment Date">{{ $list->transaction_date ? date($common_date_format, strtotime($list->transaction_date)) :'-' }}</label>
                                </div>
                            </td>
                            <td class="text-center">
                                 <span class="badge {{$list->currency_code =='INR' ? 'bg-secondary text-white': 'bg-warning text-black'}} rounded fs-6 px-2">   
                                {{$list->currency_code}}
                                </span>
                            </td>
                            <td align="right">
                                 @if($list->currency_code =='INR')
                                  <div class="badge bg-info border border-info rounded fw-semibold text-white fs-6 d-block">&#8377; {{number_format($netAmountInr,2)}}</div>
                                @else
                                <div class="badge bg-transparent border border-info rounded fw-semibold text-black fs-6 d-block mb-2" >{{$list->currency_symbol}} {{number_format($netAmount,2)}}</div>
                                <div class="badge bg-info border border-info rounded fw-semibold text-white fs-6 d-block">&#8377; {{number_format($netAmountInr,2)}}</div>
                                @endif
                            </td>
                            <td align="right">
                                @if($list->currency_code =='INR')
                                    <div class="badge bg-danger border border-danger rounded fw-semibold text-white fs-6 d-block">&#8377; {{number_format($gstAmountInr,2)}} </div>
                                  @else
                                <div class="badge bg-transparent border border-danger rounded fw-semibold text-black fs-6 d-block mb-2">{{$list->currency_symbol}} {{number_format($gstAmount,2)}} </div>
                                <div class="badge bg-danger border border-danger rounded fw-semibold text-white fs-6 d-block">&#8377; {{number_format($gstAmountInr,2)}} </div>
                                  @endif
                                <!--<div>(Inclusive)</div>-->
                            </td>
                            <td align="right">
                                @if($list->currency_code =='INR')
                                    <div class="badge bg-success border border-success rounded fw-semibold text-black fs-6 d-block">&#8377; {{number_format($convertedPaidAmountInr,2)}}</div>
                                  @else
                                <div class="badge bg-transparent border border-success rounded fw-semibold text-black fs-6 d-block mb-2">{{$list->currency_symbol}} {{number_format($list->paid_amount,2)}}</div>
                                <div class="badge bg-success border border-success rounded fw-semibold text-black fs-6 d-block">&#8377; {{number_format($convertedPaidAmountInr,2)}}</div>
                                 @endif
                            </td>
                            <td>
                                 @if ($list->payment_status == 0)
                                <a class="cursor-pointer badge bg-info text-white fs-7 fw-semibold"  style="background-color: #6e788c !important;">
                                    <span>Waiting for BH Approval</span>
                                </a>
                                @elseif ($list->payment_status == 1 && $list->daily_acc_chk == 0)
                                <a class="cursor-pointer badge bg-info text-white fs-7 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color: #6e788c !important;">
                                    <span>Waiting for Verification</span>
                                    <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                                </a>
                                 <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(1 , {{ json_encode($list ?? [])}})"><span>Verified</span></a>
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(2 , {{ json_encode($list ?? [])}})"> <span>On Process</span></a>
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(3 , {{ json_encode($list ?? [])}})"> <span>UnKnown</span></a>
                                    <!-- @if($list->payment_mode == 2)
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_transaction_reject_change" onclick="status_rejected(1 , {{ json_encode($list ?? [])}})"> <span class="text-danger">Rejected</span></a>
                                    @endif -->
                                </div>
                                @elseif ($list->payment_status == 1 && $list->daily_acc_chk == 1)
                                <a href="javascript:;" class="badge bg-success text-white rounded fw-bold fs-8"  id="" aria-haspopup="true" aria-expanded="false">
                                    Verified
                                </a>
                                @elseif ($list->payment_status == 3 && $list->daily_acc_chk == 1)
                                <a href="javascript:;" class="badge  text-white rounded fw-bold fs-8" style="background-color: #f12b2b;" data-bs-toggle="dropdown" id="" aria-haspopup="true" aria-expanded="false">
                                   UnKnown
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(1 , {{ json_encode($list ?? [])}})"><span>Verified</span></a>
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(2 , {{ json_encode($list ?? [])}})"> <span>On Process</span></a>
                                </div>
                                @elseif ($list->payment_status == 2 && $list->daily_acc_chk == 1)
                                 <a href="javascript:;" class="badge  text-white rounded fw-bold fs-8" style="background-color: #2a6eed;" data-bs-toggle="dropdown" id="" aria-haspopup="true" aria-expanded="false">
                                     On Process
                                </a>
                                 <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_old_customer_status_change" onclick="status_change(1 , {{ json_encode($list ?? [])}})"><span>Verified</span></a>
                                </div>
                                @endif
                          
                            </td>
                            @if(auth()->user()->user_id == 0)
                            <td>
                                <span class="text-end">
                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="{{$print_url}}" target="_blank" class="dropdown-item">
                                            <span><i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Print</span>
                                        </a>
                                        <a href="{{$office_print_url}}" target="_blank" class="dropdown-item">
                                            <span><i class="mdi mdi-printer-pos-outline fs-3 text-black me-1"></i>Office Receipt</span>
                                        </a>
                                    </div>
                                </span>
                            </td>
                            @endif
                        </tr>
                         @endforeach
                         @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $customers->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Send Receipt-->
<div class="modal fade" id="kt_modal_send_receipt" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Receipt</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer Id</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_customer_id"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_cus_name">Priya</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Receipt No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_invoice_id">INV-005003/05/2025</label>
                </div>
                <!--<div class="d-flex  gap-2 mt-4 mb-1">-->
                <!--     <label class="text-black mb-1 fs-6 fw-semibold" id="old_cus_check_text">Skip Communication</label>-->
                <!--    <input class="form-check-input" type="checkbox" id="old_cus_check" name="old_cus_check" value="1" checked onclick="old_cus_check_func();">-->
                <!--</div>-->
                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <div class="badge bg-label-primary rounded-pill mb-1">
                            <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                            <span class="align-middle fw-semibold">Receipt Attached</span>
                        </div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="text-danger" id="communication_err"></div>
                    </div>
                    <input type="hidden" name="send_customer_id" id="send_customer_id">
                    <input type="hidden" name="send_proposal_id" id="send_proposal_id">
                    <input type="hidden" name="send_slot_id" id="send_slot_id">
                    <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                    <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                    <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description"></textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Receipt</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Receipt-->

<div class="modal fade" id="kt_modal_transaction_reject_change" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
        <!--begin::Modal header-->
        <div class="modal-header justify-content-end border-0 pb-0">
          <!--begin::Close-->
          <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
            <!--end::Svg Icon-->
          </div>
          <!--end::Close-->
        </div>
        <!--end::Modal header-->
        <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
          <form id="rejectForm" action="{{ route('payment_reject_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off" >
            @csrf
            <!--begin::Heading-->
            <div id="rejectModalContent"></div>
            <div class="d-flex justify-content-center align-items-center mt-6 gap-3">
              <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-sm btn-primary" id="reject_submit_btn" onclick="rejectPaymentTransaction()">Rejected</button>
            </div>
          </form>
        </div>
        <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="kt_modal_old_customer_status_change" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
        <!--begin::Modal header-->
        <div class="modal-header justify-content-end border-0 pb-0">
          <!--begin::Close-->
          <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
            <!--end::Svg Icon-->
          </div>
          <!--end::Close-->
        </div>
        <!--end::Modal header-->
        <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
          <form id="verifyForm" action="{{ route('payment_accounts_status_change') }}" method="POST" enctype="multipart/form-data" autocomplete="off" >
            @csrf
            <!--begin::Heading-->
            <div id="statusModalContent"></div>
            <input type="hidden" name="hidden_request_url" value="{{$current_page_url}}"/>
            <div class="d-flex justify-content-center align-items-center mt-6 gap-3">
              <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-sm btn-primary" id="status_submit_btn" onclick="verifyPaymentTransaction()">Verify</button>
            </div>
          </form>
        </div>
        <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
  </div>
  
  <div class="modal fade" id="kt_modal_transaction_change" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
        <!--begin::Modal header-->
        <div class="modal-header justify-content-end border-0 pb-0">
          <!--begin::Close-->
          <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
            <!--end::Svg Icon-->
          </div>
          <!--end::Close-->
        </div>
        <!--end::Modal header-->
        <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
            <!--begin::Heading-->
            <div id="transactionModalContent"></div>
            <div class="d-flex justify-content-center align-items-center mt-6 gap-3">
              <button type="button" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="button" class="btn btn-sm btn-primary" id="transaction_update_btn" onclick="transaction_update_func()">Update</button>
            </div>
        </div>
        <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
  </div>

<!--begin::Modal - Verified-->
<div class="modal fade" id="kt_modal_verified" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Are you sure you want to Change Status - <span class="badge bg-success fw-semibold fs-4">Verified</span> ?</h3>
                </div>
                <div class="text-black mb-6 fs-4 text-center fw-semibold"><u>Customer Details</u></div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-4 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">2025/MDU01/CUS2334</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sub Ledger</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya - 2025/MDU01/TRA2412</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Transaction Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-warning text-black fw-semibold fs-6">09-Jun-2025</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Credit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-success fw-semibold fs-4">&#8377; 53,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Debit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fw-semibold fs-4">&#8377; 0</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Tax Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-secondary fw-semibold fs-4">&#8377; 2,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-info fw-semibold fs-4">&#8377; 55,000</label>
                    </div>
                </div>
                <div class="row mb-10">
                    <label class="col-3 text-dark fs-6 fw-semibold">Receipt ID<span class="text-danger">*</span></label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-semibold">
                        <input type="text" class="form-control" placeholder="Enter Receipt ID" value="TXN20250526ABC12345" />
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Verified</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Verified-->


<!--begin::Modal - OnProgress-->
<div class="modal fade" id="kt_modal_onprogress" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Are you sure you want to Change Status - <span class="badge bg-info fw-semibold fs-4">On Progress</span> ?</h3>
                </div>
                <div class="text-black mb-6 fs-4 text-center fw-semibold"><u>Customer Details</u></div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-4 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">2025/MDU01/CUS2334</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sub Ledger</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya - 2025/MDU01/TRA2412</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Transaction Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-warning text-black fw-semibold fs-6">09-Jun-2025</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Credit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-success fw-semibold fs-4">&#8377; 53,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Debit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fw-semibold fs-4">&#8377; 0</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Tax Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-secondary fw-semibold fs-4">&#8377; 2,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-info fw-semibold fs-4">&#8377; 55,000</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">On Progress</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - OnProgress-->


<!--begin::Modal - Unkown-->
<div class="modal fade" id="kt_modal_unkown" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Are you sure you want to Change Status - <span class="badge bg-danger fw-semibold fs-4">Unkown</span> ?</h3>
                </div>
                <div class="text-black mb-6 fs-4 text-center fw-semibold"><u>Customer Details</u></div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-4 fw-semibold">Priya</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Customer ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-info fs-6 fw-semibold">2025/MDU01/CUS2334</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sub Ledger</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya - 2025/MDU01/TRA2412</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Transaction Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-warning text-black fw-semibold fs-6">09-Jun-2025</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Credit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-success fw-semibold fs-4">&#8377; 53,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Debit Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-danger fw-semibold fs-4">&#8377; 0</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Tax Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-secondary fw-semibold fs-4">&#8377; 2,000</label>
                    </div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8">
                        <label class="badge bg-info fw-semibold fs-4">&#8377; 55,000</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Unkown</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Unkown-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    
    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
 <script>
     
    function formatcurrency(amt) {
    var formattedAmount = amt.toLocaleString('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 2
    });
    return formattedAmount;
}


    function formatDate(dateString) {
        const date = new Date(dateString);

        // Check if the date is valid
        if (isNaN(date.getTime())) {
            return '-'; // Return '-' if the date is invalid
        }

        // Get the day, month (abbreviated), and year
        const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
        const month = date.toLocaleString('default', { month: 'short' }); // Get abbreviated month
        const year = date.getFullYear(); // Get full year

        // Construct and return the formatted date string
        return `${day}-${month}-${year}`; // Format as DD-MMM-YYYY
    }
    
    function formatDateTime(dateString) {
    const date = new Date(dateString);

    // Check if the date is valid
    if (isNaN(date.getTime())) {
        return '-'; // Return '-' if the date is invalid
    }

    const options = {
        year: 'numeric',
        month: 'short',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };

    return date.toLocaleString('en-GB', options).replace(',', '');
}
    function status_change(type, data) {
      // Determine the status (Accepted/Rejected)
      //   const status = type;
        let status;  // Declare the status variable outside the if-else blocks
        
        // alert(type)
        let receipt_id;
    
        if (type === 1) {
            status = '<label class="badge bg-success text-white fs-6 fw-bold">Verified</label>';
            
            receipt_id = `
                            <div class="row mb-2">
                              
                            </div>
                        
                        `; 
        }else if (type === 2) {
            status = '<label class="badge bg-info text-white fs-6 fw-bold">On Progress</label>';
        }
        else if (type === 3) {
            status = '<label class="badge bg-danger text-white fs-6 fw-bold">UnKnown</label>';
        }
       
        
        
            // <div class="row mb-2">
            //   <label class="col-5 text-dark fs-6 fw-semibold">Course Name</label>
            //   <label class="col-1 text-dark fs-6 fw-semibold">:</label>
            //   <label class="col-6 text-black fs-6 fw-bold">${data.course_name}</label>
            // </div>
      let formattedTransactionDate = formatDate(data.transaction_date);
       console.log(data);
      // Generate dynamic HTML content
      const html = `
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">
            <label>Are you sure you want to Change Status - ${status} ? </label>
          </h3>
          <input type="hidden" id="sts_change_type" name="sts_change_type" value="${type}"/>
          <input type="hidden" id="sts_change_id"   name="sts_change_id" value="${data.trans_sno}"/>
          <input type="hidden" id="proposal_id_hidden"   name="proposal_id_hidden" value="${data.proposal_sno}"/>
          <input type="hidden" id="slot_id_hidden"   name="slot_id_hidden" value="${data.pay_slot_id}"/>
          <input type="hidden" id="customer_id"   name="customer_id_hidden" value="${data.sno}"/>
          <input type="hidden" id="payment_id"   name="payment_id_hidden" value="${data.payment_id}"/>
          <input type="hidden" id="payment_mode"   name="payment_mode" value="${data.payment_mode}"/>
        </div>
    
        <div class="row mb-2">
            <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Customer Details</u></div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Customer Name</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-5 fw-bold">${data.cus_name}</label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Customer ID</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"><span class="badge bg-info text-white fs-7 fw-bold">${data.customer_id}</span></label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Subledger</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold">${data.subledger_name || '-'}</label>
            </div>
            
            <div class="row mb-2">
                <label class="col-5 text-dark fs-6 fw-semibold">Transaction Date</label>
                <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                <label class="col-6 text-black fs-6 fw-bold">
                        <span class="text-black">${formattedTransactionDate}</span>
                 
                </label>
            </div>
            
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Credit Amount (${data.currency_code})</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"> 
                 <span class="text-black">${data.currency_symbol} ${data.paid_amount||0}</span>
              </label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Converted Amount (INR)</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"> 
                 <span class="text-black" id="paid_amount_inr" paid_amount_inr> ${data.paid_amount||0}</span>
              </label>
            </div>
            
            ${data.payment_mode == 2 && type ==1? 
                `
                <div class="row mb-2">
                  <label class="col-5 text-dark fs-6 fw-semibold">Transaction Id <span class="text-danger">*</span></label>
                  <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                  <label class="col-6 text-black fs-6 fw-bold"> 
                     <span class="text-black"  >${data.offline_transaction_id}</span>
                    
                  </label>
                </div>
                <div class="row mb-2">
                  <label class="col-5 text-dark fs-6 fw-semibold">Mode Of Payment</label>
                  <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                  <label class="col-6 text-black fs-6 fw-bold"> 
                     <span class="text-black" >${data.offline_payment_mode}</span>  
                  </label>
                </div>
                
                `:
                ''
            }
          </div>
        </div>
      `;
      
      
    
      // Render the generated HTML into the modal or target container
      document.getElementById('statusModalContent').innerHTML = html;
      var amount_from=data.paid_amount;
      var from_currency=data.currency_code;
      var to_currency='INR';
       $.ajax({
                url: "{{ route('currency.convert') }}", // Define this route in web.php
                type: "POST",
                data: {
                    amount: amount_from,
                    from_currency: from_currency,
                    to_currency: to_currency,
                    _token: "{{ csrf_token() }}"
                },
                success: function (response) {
                    if (response.success) {
                        $("#paid_amount_inr").text(response.amount);
                    } else {
                    }
                }
            });
      
      const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('fileUpload');
        const fileName = document.getElementById('fileName');
        
        if (dropZone) {
            dropZone.addEventListener('click', () => fileInput.click());
        
            dropZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                dropZone.style.backgroundColor = '#e6f2ff';
            });
        
            dropZone.addEventListener('dragleave', () => {
                dropZone.style.backgroundColor = '#f9f9f9';
            });
        
            dropZone.addEventListener('drop', (e) => {
                e.preventDefault();
                fileInput.files = e.dataTransfer.files;
                handleFileSelect(fileInput);
                dropZone.style.backgroundColor = '#f9f9f9';
            });
        }
        
       
       $(".common_date_cus").datepicker({
            format: "dd-M-yyyy", 
            autoclose: true, 
            todayHighlight: true
        }).datepicker("setDate", formattedTransactionDate);
      if (type === 1) {
            status = 'Verified';
        } else if (type === 2) {
            status = 'On Progress';
        }else if (type === 3) {
            status = 'UnKnown';
        }
            
      document.getElementById('status_submit_btn').innerHTML = status;
    }
    
    </script>

<script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
<script>
    function send_proposal_whatsapp_func() {
         const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
         const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }
</script>
<script>
    function send_receipt_func(id,slot_id,email,mobile,customer_id,name,invoice_id,cus_id){
        $('#send_cus_name').text(name);
        $('#send_customer_id').text(customer_id);
        $('#send_invoice_id').text(invoice_id);
        $('#send_proposal_id').val(id);
        $('#send_slot_id').val(slot_id);
        $('#send_customer_id').val(cus_id);
        
        if (mobile && mobile.trim() !== "") {
            $('#sd_prpl_message').removeClass('d-none');
            $('#sd_prpl_whats_app').removeClass('d-none');
        } else {
            $('#sd_prpl_message').addClass('d-none');
            $('#sd_prpl_whats_app').addClass('d-none');
        }
    
        // Email check (show/hide Email button)
        if (email && email.trim() !== "") {
            $('#sd_prpl_email').removeClass('d-none');
        } else {
            $('#sd_prpl_email').addClass('d-none');
        }
    }
     function handleFileSelect(input) {
            if (input.files.length > 0) {
                fileName.textContent = "Selected File: " + input.files[0].name;
            } else {
                fileName.textContent = "";
            }
        }
</script>

<script>
     $('#sendMessageBtn').on('click', function(e) {
        var err =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const proposal_id = $('#send_proposal_id').val();
        const slot_id = $('#send_slot_id').val();
        const customer_id = $('#send_customer_id').val();
        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();

        //  var old_cus_check = document.getElementById("old_cus_check");
            var old_customer_check =  0;
            if (old_customer_check == 1) {
                sms =0;
                email =0;
                whatsapp = 0;
                old_customer_check=1;
            }else{
                 if(sms ==1 || email ==1 || whatsapp == 1){
                    $('#communication_err').text('');
                }else{
                    $('#communication_err').text('Please Select Any One Communication.!');
                    err++;
                }
            }

   

        if(err == 0){
              $('#sendMessageBtn').prop('disabled', true);
               $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/send_receipt_message',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    proposal_id: proposal_id,
                    slot_id: slot_id,
                    customer_id: customer_id,
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                    old_customer_check: old_customer_check,
                    // description: description,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#sendMessageBtn').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#sendMessageBtn').prop('disabled', true);
                      resetButton();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send Receipt');
            }
    });

    // function formatCurrency(amt) {
    //     var roundedAmt = parseFloat(amt);
    //     var isWhole = Number.isInteger(roundedAmt);
    
    //     return roundedAmt.toLocaleString('en-IN', {
    //         minimumFractionDigits: isWhole ? 0 : 2,
    //         maximumFractionDigits: isWhole ? 0 : 2
    //     });
    // }
      function formatDate(dateString) {
            let date = new Date(dateString); 
            let day = String(date.getDate()).padStart(2, '0'); 
            let monthIndex = date.getMonth();
            let year = date.getFullYear(); 

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex]; 

            return `${day}-${month}-${year}`;
        }
</script>
<script>
// old_cus_check_func()
   function old_cus_check_func(){
        var old_cus_check = document.getElementById("old_cus_check");
     
        if (old_cus_check.checked) {
           $('.communication_check').hide();
            
        } else{
            $('.communication_check').show();
        }
    }
</script>
<script>
     function downloadReceipt(id) {
     
 
         // Combine the IDs to be sent for encryption
         var values = id;
 
         // Get the CSRF token from the meta tag
         var csrfToken = $('meta[name="csrf-token"]').attr('content');
 
         // Use AJAX to encrypt the combined values using a PHP route
         $.ajax({
             url: '/receipt/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: values,
                 _token: csrfToken // Include CSRF token here
             },
             success: function(encrypted_receipt_id) {
                 // Redirect to the PDF generation route with the encrypted ID
                     const iframe = document.createElement('iframe');
                    iframe.style.display = 'none';
                    iframe.src = '/receipt_print_download/' + encrypted_receipt_id;
                    document.body.appendChild(iframe);
                
                    // Wait a bit before refreshing the page
                    setTimeout(function () {
                        // location.reload();
                    }, 2000); // Adjust the delay as needed
                 
             },
             error: function(xhr) {
                 console.error("something is wrong , Please try Again Later");
             }
         });
     }
</script>
<script>
    function verifyPaymentTransaction() {
         $('#status_submit_btn').prop('disabled', true);
        var err =0;
        
        if (err === 0) {
                $('#verifyForm').submit();
          } else {
              $('#status_submit_btn').prop('disabled', false);
          }
    }
        
</script>
<script>
     function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#search_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#search_form').submit();
        }
      }
</script>
<script>
    function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/manage_accounts/?month_filter=' + val;
        
    }


</script>
<script>
    function transaction_change_func(data) {
      let formattedTransactionDate = formatDate(data.transaction_date);
      const html = `
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">
            <label>Are you sure you want to Update Transaction ? </label>
          </h3>
          <input type="hidden" id="transaction_id_update"   name="transaction_id_update" value="${data.trans_sno}"/>
        </div>
    
        <div class="row mb-2">
            <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Customer Details</u></div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Customer Name</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-5 fw-bold">${data.cus_name}</label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Customer ID</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"><span class="badge bg-info text-white fs-7 fw-bold">${data.customer_id}</span></label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Subledger</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold">${data.subledger_name || '-'}</label>
            </div>
            
            <div class="row mb-2">
                <label class="col-5 text-dark fs-6 fw-semibold">Transaction Date</label>
                <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                <label class="col-6 text-black fs-6 fw-bold">
                    
                     <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="transaction_date_update" name="transaction_date_update" placeholder="Select Date" class="form-control common_date_transaction" readonly value="${formattedTransactionDate}" />
                    </div>
                    <div class="text-danger" id="transaction_date_update_err"></div>
                </label>
            </div>
            
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Credit Amount (${data.currency_code})</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"> 
                 <input type="text" class="form-control bg-disabled paid_amount " placeholder="Enter Paid Amount " name="paid_amount_update" id="paid_amount_update" value="${data.paid_amount||0}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"  readonly/>
              </label>
            </div>
            <div class="row mb-2">
              <label class="col-5 text-dark fs-6 fw-semibold">Converted Amount (INR)</label>
              <label class="col-1 text-dark fs-6 fw-semibold">:</label>
              <label class="col-6 text-black fs-6 fw-bold"> 
                 <input type="text" class="form-control bg-disabled paid_amount_inr " placeholder="Enter Paid Amount in INR" name="paid_amount_update_inr" id="paid_amount_update_inr" value="${data.paid_amount||0}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" readonly/>
                 <div class="text-danger" id="paid_amount_update_inr_err"></div>
              </label>
            </div>
          </div>
        </div>
      `;
      
      // Render the generated HTML into the modal or target container
      document.getElementById('transactionModalContent').innerHTML = html;
      var amount_from=data.paid_amount;
      var from_currency=data.currency_code;
      var to_currency='INR';
       $.ajax({
                url: "{{ route('currency.convert') }}", // Define this route in web.php
                type: "POST",
                data: {
                    amount: amount_from,
                    from_currency: from_currency,
                    to_currency: to_currency,
                    _token: "{{ csrf_token() }}"
                },
                success: function (response) {
                    if (response.success) {
                        $("#paid_amount_update_inr").val(response.amount);
                    } else {
                    }
                }
            });
            
      $(".common_date_transaction").datepicker({
            format: "dd-M-yyyy",
            autoclose: true,
            todayHighlight: true,
            maxDate: new Date(), // Restrict future dates
        }).datepicker("setDate", formattedTransactionDate);
    
      
    }

    function transaction_update_func(transaction_id) {
        let err = 0;
        var transaction_date = $('#transaction_date_update').val();
        var transaction_id = $('#transaction_id_update').val();
     
               var currentDate = new Date();
                var selectedDate = new Date(transaction_date);
                
                if (transaction_date === '') {
                    $('#transaction_date_update_err').text('Please Select the Transaction Date.');
                    err++;
                } else if (selectedDate > currentDate) {
                    $('#transaction_date_update_err').text('Transaction Date cannot be in the future.');
                    err++;
                } else {
                    $('#transaction_date_update_err').text('');
                }

        // Proceed only if there are no validation errors
        if (err === 0) {
             $('#transaction_update_btn').prop('disabled', true).text('Updating...');
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            $.ajax({
                url: '/transaction_update',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                method: 'POST',
                data: JSON.stringify({
                    transaction_id: transaction_id,
                    transaction_date: transaction_date,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        $('#kt_modal_transaction_change').modal('hide');
                        window.location.href = '/manage_accounts';
                        toastr.success('Transaction Updated Successfully.');
                    } else {
                        toastr.error(response.message || 'Failed to Update Transaction.');
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to Update Transaction.';
                    toastr.error(errorMsg);
                },
                complete: function() {
                    // Re-enable the button after the process is complete
                    $('#transaction_update_btn').prop('disabled', false).text('Update');
                }
            });
        }
    }
</script>

    <script>
        function status_rejected(type, data) {
                // Determine the status (Accepted/Rejected)
                //   const status = type;
                let status;  // Declare the status variable outside the if-else blocks
                
                // alert(type)
                let receipt_id;
            
                if (type === 1) {
                    status = '<label class="badge bg-danger text-white fs-6 fw-bold">Rejected</label>';
                }
            
                
                
                    // <div class="row mb-2">
                    //   <label class="col-5 text-dark fs-6 fw-semibold">Course Name</label>
                    //   <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    //   <label class="col-6 text-black fs-6 fw-bold">${data.course_name}</label>
                    // </div>
            let formattedTransactionDate = formatDate(data.transaction_date);
            console.log(data);
            // Generate dynamic HTML content
            const html = `
                <div class="mb-4 text-center">
                <h3 class="text-center mb-4 text-black">
                    <label>Are you sure you want to Change Status - ${status} ? </label>
                </h3>
                <input type="hidden" id="reject_change_type" name="sts_change_type" value="${type}"/>
                <input type="hidden" id="reject_change_id"   name="sts_change_id" value="${data.trans_sno}"/>
                <input type="hidden" id="proposal_id_reject"   name="proposal_id_hidden" value="${data.proposal_sno}"/>
                <input type="hidden" id="slot_id_reject"   name="slot_id_hidden" value="${data.pay_slot_id}"/>
                <input type="hidden" id="customer_id_reject"   name="customer_id_hidden" value="${data.sno}"/>
                <input type="hidden" id="payment_id-reject"   name="payment_id_hidden" value="${data.payment_id}"/>
                <input type="hidden" id="payment_mode_reject"   name="payment_mode" value="${data.payment_mode}"/>
                </div>
            
                <div class="row mb-2">
                    <div class="text-black text-center mb-3 fs-4 fw-semibold"><u>Customer Details</u></div>
                    <div class="row mb-2">
                    <label class="col-5 text-dark fs-6 fw-semibold">Customer Name</label>
                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    <label class="col-6 text-black fs-5 fw-bold">${data.cus_name}</label>
                    </div>
                    <div class="row mb-2">
                    <label class="col-5 text-dark fs-6 fw-semibold">Customer ID</label>
                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold"><span class="badge bg-info text-white fs-7 fw-bold">${data.customer_id}</span></label>
                    </div>
                    <div class="row mb-2">
                    <label class="col-5 text-dark fs-6 fw-semibold">Subledger</label>
                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold">${data.subledger_name || '-'}</label>
                    </div>
                    
                    <div class="row mb-2">
                        <label class="col-5 text-dark fs-6 fw-semibold">Transaction Date</label>
                        <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                        <label class="col-6 text-black fs-6 fw-bold">
                            
                            <div class="input-group input-group-merge bg-disabled">
                                <span class="input-group-text bg-disabled"><i class="mdi mdi-calendar-month-outline fs-4 bg-disabled"></i></span>
                                <input type="text" id="reject_transaction_date" name="transaction_date" placeholder="Select Date" class="form-control common_date_cus" readonly value="${formattedTransactionDate}" disabled/>
                            </div>
                        </label>
                    </div>
                    
                    <div class="row mb-2">
                    <label class="col-5 text-dark fs-6 fw-semibold">Credit Amount (${data.currency_code})</label>
                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold"> 
                        <input type="text" class="form-control bg-disabled paid_amount " placeholder="Enter Paid Amount " name="paid_amount" id="reject_paid_amount" value="${data.paid_amount||0}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')"  disabled/>
                    </label>
                    </div>
                    <div class="row mb-2">
                    <label class="col-5 text-dark fs-6 fw-semibold">Converted Amount (INR)</label>
                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                    <label class="col-6 text-black fs-6 fw-bold"> 
                        <input type="text" class="form-control bg-disabled reject_paid_amount_inr " placeholder="Enter Paid Amount in INR" name="reject_paid_amount_inr" id="reject_paid_amount_inr" value="${data.paid_amount||0}" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" disabled/>
                        <div class="text-danger" id="reject_paid_amount_inr_err"></div>
                    </label>
                    </div>
                    <div class="alert alert-warning mt-3" role="alert">
                        <i class="mdi mdi-alert fs-4 me-2 text-danger"></i>
                        <input type="checkbox" class="form-check-input me-2" id="confirm_reject" onchange="toggleRejectButton()"/>
                        <strong class="text-danger">Important:</strong>  
                        <span class="text-dark">Once the payment status is changed to </span>
                        <span class="text-danger fw-bold">Rejected</span>,
                        <span class="text-dark">it cannot be reversed.</span>
                    </div>
                </div>
                </div>
            `;
            
            
            
            // Render the generated HTML into the modal or target container
            document.getElementById('rejectModalContent').innerHTML = html;
            var amount_from=data.paid_amount;
            var from_currency=data.currency_code;
            var to_currency='INR';
                    $.ajax({
                        url: "{{ route('currency.convert') }}", // Define this route in web.php
                        type: "POST",
                        data: {
                            amount: amount_from,
                            from_currency: from_currency,
                            to_currency: to_currency,
                            _token: "{{ csrf_token() }}"
                        },
                        success: function (response) {
                            if (response.success) {
                                $("#reject_paid_amount_inr").val(response.amount);
                            } else {
                            }
                        }
                    });
            
            
               $(".common_date_cus").datepicker({
                    format: "dd-M-yyyy", 
                    autoclose: true, 
                    todayHighlight: true
                }).datepicker("setDate", formattedTransactionDate);

                if (type === 1) {
                    status = 'Rejected';
                }
            $('#reject_submit_btn').prop('disabled', true);    
            document.getElementById('reject_submit_btn').innerHTML = status;
        }
    </script>
    <script>
        function toggleRejectButton() {
            const isChecked = document.getElementById("confirm_reject").checked;
            document.getElementById("reject_submit_btn").disabled = !isChecked;
        }
        function rejectPaymentTransaction() {
            $('#reject_submit_btn').prop('disabled', true);
            var err =0;
            var paymode =$('#payment_mode').val();
            var paid_amount_inr =$('#paid_amount_inr').val();
            var offline_transaction_id =$('#offline_transaction_id').val();

            if (err === 0) {
                    $('#rejectForm').submit();
            } else {
                $('#reject_submit_btn').prop('disabled', false);
            }
        }   
    </script>
@endsection