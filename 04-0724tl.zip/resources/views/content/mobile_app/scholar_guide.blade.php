@extends('layouts/layoutMaster')

@section('title', 'Scholar Guide')
@section('vendor-style')
    @vite(['resources/assets/vendor/libs/swiper/swiper.scss', 'resources/assets/vendor/libs/rateyo/rateyo.scss'])
@endsection

@section('page-style')
    <!-- Page -->
    @vite(['resources/assets/vendor/scss/pages/cards-statistics.scss', 'resources/assets/vendor/scss/pages/cards-analytics.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/swiper/swiper.js', 'resources/assets/vendor/libs/rateyo/rateyo.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/dashboards-analytics.js']),
@endsection


<style>
    body {
        font-size: 14px;
    }

    .headingsection {
        text-align: center;
    }

    .btnheadingsection {
        display: flex;
        flex-direction: column;
        /* Mobile (default) */
        justify-content: center;
        gap: 15px;
        align-items: center;
    }


    .navClass {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .hero-section-img {
        width: 440px;
        height: 440px;
        object-fit: cover;
    }




    /* Small devices (≥576px) */
    @media (min-width: 576px) {
        body {
            font-size: 15px;
        }

        .btnheadingsection {
            flex-direction: row;
        }

        .navClass {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        /* .hero-section-img{
            width: 540px; height: 540px; object-fit: cover;
        } */
    }

    /* Medium devices (≥768px) */
    @media (min-width: 768px) {
        body {
            font-size: 16px;
        }

        .btnheadingsection {
            flex-direction: row;
        }

        .navClass {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        .hero-section-img {
            width: 540px;
            height: 540px;
            object-fit: cover;
        }



    }

    /* Large devices (≥992px) */
    @media (min-width: 992px) {
        body {
            font-size: 17px;
        }

        .navClass {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        .hero-section-img {
            width: 540px;
            height: 540px;
            object-fit: cover;
        }
    }

    /* Extra large devices (≥1200px) */
    @media (min-width: 1200px) {
        body {
            font-size: 18px;
        }

        .headingsection {
            text-align: left;
        }

        .btnheadingsection {
            justify-content: flex-start;
        }

        .navClass {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        .hero-section-img {
            width: 540px;
            height: 540px;
            object-fit: cover;
        }
    }

    /* XXL devices (≥1400px) */
    @media (min-width: 1400px) {
        body {
            font-size: 19px;
        }

        .navClass {
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        .hero-section-img {
            width: 540px;
            height: 540px;
            object-fit: cover;
        }
    }
</style>


<style>
    .footer-link {
        color: #6c757d;
        /* Bootstrap text-secondary */
        transition: color 0.3s ease;
        text-decoration: none;
    }

    .footer-link:hover {
        color: #387BC0;
    }
</style>


<style>
    /* Card */
    .feature-card {
        transition: all 0.3s ease;
    }

    /* Icon box transition */
    .icon-box {
        transition: all 0.3s ease;
    }

    /* Icon transition */
    .icon-box span {
        transition: all 0.3s ease;
    }

    /* Hover effects */
    .feature-card:hover {
        /* border: 1px solid #d1d5db; */
        transform: translateY(-5px);
        /* box-shadow: 0 10px 25px rgba(0,0,0,0.08); */
    }

    /* Smooth background change */
    .feature-card:hover .icon-box {
        background: #387BC0 !important;
    }

    /* Smooth icon color change */
    .feature-card:hover .icon-box span {
        color: white !important;
    }
</style>

<style>
    /* Wrapper */
    .img-box {
        position: relative;
        overflow: hidden;
        border-radius: 20px;

    }

    /* Image smooth zoom */
    .img-box img {
        transition: transform 0.4s ease;
    }

    /* Overlay (hidden by default) */
    .img-overlay {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        padding: 15px;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.6), transparent);
        color: white;
        opacity: 0;
        transition: opacity 0.4s ease;
    }

    /* Hover Effects */
    .img-box:hover img {
        transform: scale(1.08);
        /* zoom */
    }

    .img-box:hover .img-overlay {
        opacity: 1;
        /* show text */
    }

    .marquee-track:hover {
        animation-play-state: paused;
    }
</style>

<style>
    .marquee {
        overflow: hidden;
        width: 100%;
    }

    .marquee-track {
        display: flex;
        width: max-content;
        animation: scroll 40s linear infinite;
    }

    .marquee-content {
        display: flex;
        gap: 20px;
    }

    .img {
        width: 340px;
        height: 340px;
        object-fit: cover;
    }

    /* Animation */
    @keyframes scroll {
        from {
            transform: translateX(0);
        }

        to {
            transform: translateX(-50%);
        }
    }
</style>

<style>
    @keyframes floatRotate {
        0% {
            transform: translateY(0px) rotate(0deg);
        }

        50% {
            transform: translateY(-17px) rotate(0deg);
        }

        100% {
            transform: translateY(0px) rotate(0deg);
        }
    }

    .hero-img {
        animation: floatRotate 4s ease-in-out infinite;
    }
</style>

{{--
| Class      | Device Type     | Min Width    |
| ---------- | --------------- | ------------ |
| `col-sm-*` | Small devices   | **≥ 576px**  |
| `col-md-*` | Tablets         | **≥ 768px**  |
| `col-lg-*` | Laptops/Desktop | **≥ 992px**  |
| `col-xl-*` | Large Desktop   | **≥ 1200px** | --}}




@section('content')
    <div class="card rounded">
        <div class="card-body">
            <div class="card rounded p-0" style="box-shadow: none; ">
                <div class="card-body p-0">
                    <div class="row bg-white">
                        <div class="col-lg-12" style="background:#F7F9FC;">
                            <div class=" py-4 m-4 rounded ">
                                <div class="navClass rounded-3 gap-4 px-2 py-3 flex-wrap"
                                    style="gap:10px 10px;background-color: #387BC0 !important;">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;" aria-label="Scholar Guide" class="bg-white p-2 rounded">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/scholar_guide_logo.png') }}"
                                                alt="Scholar Guide Logo" style="width:150px; height:45px;">
                                        </a>
                                    </div>
                                    <ul class="d-flex align-items-center mb-0 list-unstyled">
                                        <li class="me-2">
                                            <a href="#get_the_app_container"
                                                class="btn btn-sm text-white fw-bold py-3 fs-6 waves-effect waves-light"
                                                style="background-color: #1E1C1C;">
                                                Get The App
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 d-flex align-items-center justify-content-center "
                            style="padding-left:30px; padding-right:30px; padding-top:30px; background:#F7F9FC;">

                            <div class="d-flex flex-column ">

                                <div class=" headingsection mb-4" style="width:100%; ">
                                    <label class=" badge px-3 py-2 rounded-pill fs-8 fw-semibold "
                                        style="width:fit-content; color:#387BC0; background:#EEF2FF;">Now available on IOS &
                                        Android</label>
                                </div>

                                <div class=" headingsection" style="width:100%;">
                                    <label class="fs-1 fw-semibold ">Your Research Journey ,</label>
                                    <label class="fs-1 fw-semibold " style="color:#387BC0;">Managed in One Place.</label>
                                </div>

                                <label class="fs-6 fw-semibold text-secondary mt-3 headingsection">Track your service
                                    milestones,
                                    monitor publications, manage payments, and chat directly with your dedicated
                                    executive—all from
                                    the Scholar Guide app.</label>

                                <div class=" mt-4 btnheadingsection ">
                                    <a href="javascript:;" target="_blank">
                                        <img src="{{ asset('assets/phdizone_images/appstorebutton.png') }}" alt="App Store"
                                            style="width:170px;" />
                                    </a>
                                    <a href="https://play.google.com/store/apps/details?id=com.eapl.classmate&hl=en"
                                        target="_blank">
                                        <img src="{{ asset('assets/phdizone_images/playstorebutton.png') }}"
                                            alt="Google Play" style="width:150px;" />
                                    </a>
                                </div>

                            </div>
                        </div>
                        <div class="col-lg-6 d-flex align-items-center justify-content-center py-4"
                            style="background:#F7F9FC; padding-left:30px; padding-right:30px;">
                            <div>
                                <img src="{{ asset('assets/phdizone_images/landing_page/Hero-Section.png') }}"
                                    alt="avatar" class=" hero-img hero-section-img">
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12 "
                            style="margin-bottom: 50px; margin-top: 50px; padding-left:30px; padding-right:30px;">
                            <div class="headingsection" style="width:100%;">
                                <div class="d-flex flex-column">
                                    <label
                                        class="fs-1 d-flex align-items-center text-black justify-content-center fw-semibold">Everything
                                        you need, right in your pocket</label>
                                    <label
                                        class="fs-6 d-flex align-items-center text-secondary justify-content-center fw-semibold">We've
                                        designed the Scholar Guide app to give you complete transparency and control over
                                        your research
                                        services.</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-xl-12 col-md-12 col-sm-12"
                            style="margin-bottom: 50px; padding-left:30px; padding-right:30px;">
                            <div class="row g-3">
                                <div class=" col-lg-3  col-md-6" data-aos="fade-up">
                                    <div class="feature-card  p-4 d-flex flex-column gap-3 align-items-start justify-content-start rounded"
                                        style="background:#F8FAFC; height:233px;">
                                        <label class="icon-box  p-3 rounded" style="background:#E0E7FF;">
                                            <span class="mdi mdi-briefcase-outline fs-2" style="color:#387BC0;"></span>
                                        </label>
                                        <label class="fw-semibold text-black fs-6">My Work & Milestones</label>
                                        <label class="fw-semibold text-secondary fs-7">Track the real-time status of your
                                            services, view
                                            upcoming milestones, and manage assigned tasks effortlessly.</label>
                                    </div>
                                </div>
                                <div class=" col-lg-3  col-md-6" data-aos="fade-up">
                                    <div class="feature-card p-4 d-flex flex-column gap-3 align-items-start justify-content-start rounded"
                                        style="background:#F8FAFC;  height:233px;">
                                        <label class="icon-box p-3 rounded" style="background:#E0E7FF;">
                                            <span class="mdi mdi-book-open-blank-variant-outline fs-2"
                                                style="color:#387BC0;"></span>
                                        </label>
                                        <label class="fw-semibold text-black fs-6">Publications Hub</label>
                                        <label class="fw-semibold text-secondary fs-7">Keep a neat record of all your
                                            published papers,
                                            journal details, and review statuses in one organized place.</label>
                                    </div>
                                </div>
                                <div class=" col-lg-3  col-md-6" data-aos="fade-up">
                                    <div class="feature-card p-4 d-flex flex-column gap-3 align-items-start justify-content-start rounded"
                                        style="background:#F8FAFC;  height:233px;">
                                        <label class="icon-box p-3 rounded" style="background:#E0E7FF;">
                                            <span class="mdi mdi-credit-card-outline fs-2" style="color:#387BC0;"></span>
                                        </label>
                                        <label class="fw-semibold text-black fs-6">Seamless Payments</label>
                                        <label class="fw-semibold text-secondary fs-7">View your payment history, track
                                            upcoming invoices,
                                            and settle overdue balances securely within the app.</label>
                                    </div>
                                </div>
                                <div class=" col-lg-3  col-md-6" data-aos="fade-up">
                                    <div class="feature-card p-4 d-flex flex-column gap-3 align-items-start justify-content-start rounded"
                                        style="background:#F8FAFC;  height:233px;">
                                        <label class="icon-box p-3 rounded" style="background:#E0E7FF;">
                                            <span class="mdi mdi-comment-outline fs-2" style="color:#387BC0;"></span>
                                        </label>
                                        <label class="fw-semibold text-black fs-6">Direct CRE Support</label>
                                        <label class="fw-semibold text-secondary fs-7">Chat instantly with your Customer
                                            Relationship
                                            Executive, raise support tickets, and view query history.</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6"
                            style="background:#0F172B; padding-top:80px; padding-bottom:50px; padding-left:30px; padding-right:30px;">
                            <div class="d-flex flex-column align-items-start justify-content-start">
                                <label class="fs-1 text-white fw-semibold">Why download the Scholar Guide App?</label>
                                <label class="fs-7 text-secondary fw-semibold">Experience a frictionless workflow designed
                                    specifically for researchers and academics.</label>
                                <div class="d-flex flex-column mt-4 gap-4">
                                    <div class="d-flex flex-column align-items-start justify-content-start gap-2">
                                        <div class="d-flex  gap-2 align-items-center justify-content-center">
                                            <span class="mdi mdi-check-decagram text-success"></span>
                                            <label class="fs-5 text-white fw-semibold">Absolute Transparency</label>
                                        </div>
                                        <label class="fs-7 text-secondary fw-semibold">No more guessing where your project
                                            stands.
                                            Get instant push notifications on every milestone and task update.</label>
                                    </div>
                                    <div class="d-flex flex-column align-items-start justify-content-start gap-2">
                                        <div class="d-flex  gap-2 align-items-center justify-content-center">
                                            <span class="mdi mdi-check-decagram text-success"></span>
                                            <label class="fs-5 text-white fw-semibold">Faster Resolutions</label>
                                        </div>
                                        <label class="fs-7 text-secondary fw-semibold">Skip the long email threads. Chat
                                            directly
                                            with your executive and get your queries resolved in minutes, not days.</label>
                                    </div>
                                    <div class="d-flex flex-column align-items-start justify-content-start gap-2">
                                        <div class="d-flex  gap-2 align-items-center justify-content-center">
                                            <span class="mdi mdi-check-decagram text-success"></span>
                                            <label class="fs-5 text-white fw-semibold">All Your Data, Secure</label>
                                        </div>
                                        <label class="fs-7 text-secondary fw-semibold">From sensitive research publications
                                            to
                                            payment invoices, everything is encrypted and safely stored in your
                                            account.</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 d-flex align-items-center justify-content-center "
                            style="background:#0F172B; padding-top:50px; padding-bottom:50px; padding-left:30px; padding-right:30px;">
                            <div class="p-6 d-flex flex-column rounded" style="background:#1B2442;">
                                <div class="d-flex align-items-start justify-content-start mb-4 gap-3">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                        <span class="mdi mdi-star text-warning"></span>
                                    </div>
                                    <label class="fs-7 text-secondary fw-semibold">4.9/5 on App Store</label>
                                </div>
                                <label class="fs-5 text-white fw-semibold mb-4">"The Scholar Guide app completely changed
                                    how I track my
                                    research projects. The direct chat with my CRE is a lifesaver, and seeing my publication
                                    pipeline in one place is incredibly satisfying."</label>

                                <div class="d-flex align-items-center gap-2">
                                    <span
                                        class="badge p-2 fw-semibold fs-4  d-flex align-items-center justify-content-center"
                                        style="background:#387BC0; color:#fff; border-radius:50px; width:40px; height:40px;">JD
                                    </span>
                                    <div class="d-flex flex-column align-items-start justify-content-start">
                                        <label class="fs-7 text-white fw-semibold">Dr. Jane Doe</label>
                                        <label class="fs-8 text-secondary fw-semibold">Lead Researcher, BioTech
                                            Institute</label>
                                    </div>
                                </div>


                            </div>
                        </div>
                        <div class="col-lg-12 "
                            style="background:#0F172B; padding-top:30px; padding-bottom:50px; padding-left:30px; padding-right:30px;">
                            <div class="headingsection" style="width:100%;">
                                <div class="d-flex flex-column">
                                    <label
                                        class="fs-1 d-flex align-items-center text-white justify-content-center fw-semibold">See
                                        Scholar Guide in Action</label>
                                    <label
                                        class="fs-6 d-flex align-items-center text-secondary justify-content-center fw-semibold">A
                                        seamless experience across all your devices, designed for researchers.</label>
                                </div>
                            </div>
                            <div class="marquee" style="padding-top:50px;">
                                <div class="marquee-track d-flex align-items-center gap-4">

                                    <div class="marquee-content d-flex gap-4">


                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/Chat.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Chat</span>
                                            </div>
                                        </div>



                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/Home-2.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Home</span>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/milestone-history.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Milestone History</span>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/My-Profile.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">My Profile</span>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="marquee-content d-flex gap-4">
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/My-Publication.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Activity Log</span>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/My-Publication-1.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">My Publication</span>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="marquee-content d-flex gap-4">
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/Payment.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Payment</span>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/Ticket-history.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Ticket History</span>
                                            </div>
                                        </div>
                                        <div class="img-box">
                                            <img src="{{ asset('assets/phdizone_images/landing_page/Ticket-Raise.png') }}"
                                                class="img " style="width:250px; height:auto; border-radius:20px;" />
                                            <div class="img-overlay bg-primary">
                                                <span class="text-white">Ticket Raise</span>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 d-flex flex-column align-items-center justify-content-center"
                            id="get_the_app_container"
                            style="background:#387BC0; padding-top:100px; padding-bottom:100px; padding-left:30px; padding-right:30px;">
                            <div class="headingsection" style="width:100%;">
                                <div class="d-flex flex-column">
                                    <label
                                        class="fs-1 d-flex align-items-center text-white justify-content-center fw-semibold">Ready
                                        to streamline your research?</label>
                                    <label
                                        class="fs-7 d-flex align-items-center text-white justify-content-center fw-semibold">Download
                                        the Scholar Guide app today and take complete control of your services,
                                        publications, and
                                        payments.</label>
                                </div>
                            </div>
                            <div class="btnheadingsection " style="margin-top:40px;">
                                <a href="javascript:;" target="_blank">
                                    <img src="{{ asset('assets/phdizone_images/appstorebutton.png') }}" alt="App Store"
                                        style="width:170px;" />
                                </a>
                                <a href="https://play.google.com/store/apps/details?id=com.eapl.classmate&hl=en"
                                    target="_blank">
                                    <img src="{{ asset('assets/phdizone_images/playstorebutton.png') }}"
                                        alt="Google Play" style="width:150px;" />
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <link href="https://unpkg.com/aos@2.3.4/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            AOS.init({
                duration: 800,
                once: false
            });
        });
    </script>




@endsection
