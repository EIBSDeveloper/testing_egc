@extends('layouts/layoutMaster')

@section('title', 'Forecast Metrics')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('content')

<style>
  .scroll-x {
    overflow-x: auto;
  }
  .scroll-x::-webkit-scrollbar {
    height: 6px;
  }
  .scroll-x::-webkit-scrollbar-thumb {
    background-color: rgba(0,0,0,0.3);
    border-radius: 3px;
  }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h4 class="card-title mb-1">Forecast Metrics(Predictive Analysis)</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Metrics Management</a>
                    </li>
                </ol>
            </nav>
        </div>

        <div class="d-flex align-items-center justify-content-end gap-4 flex-row mb-1">
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#forecastChartModal">
              Forecast Chart
            </button>
          <!--<div class="d-flex align-items-center justify-content-center flex-column mb-1">-->
          <!--  <label class="fs-4 fw-semibold text-black">Target</label>-->
          <!--  <label class="fs-2 fw-semibold text-white rounded badge bg-info" id="target_value">&#8377;&nbsp;30,00,000</label>-->
          <!--</div>-->
          <!--<div class="d-flex align-items-center justify-content-center flex-column mb-1">-->
          <!--  <label class="fs-4 fw-semibold text-black">MPC</label>-->
          <!--  <label class="fs-2 fw-semibold text-white rounded badge bg-danger" id="mpc_value">&#8377;&nbsp;8,000</label>-->
          <!--</div>-->
            <!--Month Navigation -->
        <ul class="nav nav-pills d-none" role="tablist">
             Previous Month Button 
            <li class="nav-item">
                <a class="nav-link px-2" href="javascript:;" id="prevMonthBtn">
                    <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                </a>
            </li>

             <!--Current Month Display -->
            <li class="nav-item d-none">
                <a class="nav-link active px-3 border border-dashed border-info" href="javascript:;">
                    <div class="text-center">
                        <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                            {{ \Carbon\Carbon::now()->format('F') }}
                        </span>
                        <div class="d-block">
                            <span class="fw-semibold fs-8" id="selectedYear">
                                ({{ \Carbon\Carbon::now()->year }})
                            </span>
                        </div>
                    </div>
                </a>
            </li>

             <!--Next Month Button -->
            <li class="nav-item d-none">
                <a class="nav-link px-2" href="javascript:;" id="nextMonthBtn">
                    <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                </a>
            </li>
        </ul>
        </div>
    </div>

    <div class="card-body">
      <div class="row" id="forecastMetricsContainer">
        <!-- Metrics will be injected here -->
      </div>
    
   
      
    </div>
</div>
<!-- Forecast Chart Modal -->
<div class="modal fade" id="forecastChartModal" tabindex="-1" aria-labelledby="forecastChartModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fw-bold text-primary" id="forecastChartModalLabel">Forecast Chart</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <canvas id="forecastChart" height="200"></canvas>
      </div>
    </div>
  </div>
</div>

<style>
/* Only affects .rule-header inside your rules container */
.rule-header {
  position: relative;
  display: inline-flex;
}

.rule-header::after {
  content: "";
  position: absolute;
  height: 3px;
  width: 100%;
  bottom: -2px; /* space below text */
  left: 0;
  background-color: #ffc107; /* golden color */
  transform: scaleX(0);
  transform-origin: bottom right;
  transition: transform 0.3s ease-out;
}

.rule-header:hover::after {
  transform: scaleX(1);
  transform-origin: bottom left;
}
.card-light {
  border: none;
  border-radius: 12px;
  background: #fafafa;
  box-shadow: 0 2px 5px rgba(0,0,0,0.05);
  transition: all 0.3s ease;
}
.card-light:hover {
  box-shadow: 0 3px 10px rgba(0,0,0,0.1);
}

.card-light-header {
  border-bottom: 1px solid #e6e8eb;
  padding: 0.75rem 1.25rem;
  background: #ffffff;
  border-radius: 12px 12px 0 0;
}

.metric-box, .metric-box-second, .metric-box-green{
  border-radius: 10px;
  padding: 1rem;
  box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  transition: all 0.3s ease;
}

.metric-box {
  background: #ffeaea; /* default red tint */
}
.metric-box-green {
  background: #c6ffa5; /* default green tint */
}
.metric-box.green {
  background: #c6ffa5 !important; /* achieved */
}
.metric-box.red {
  background: #ffdfdf !important; /* not achieved */
}
.metric-box-second {
  background: #e8ecff;
}

.metric-box h1,
.metric-box-second h1,
.metric-box-green h1{
  font-size: 2.4rem;
  font-weight: 700;
  margin: 0;
}

.metric-box small,
.metric-box-second small,
.metric-box-green small{
  font-size: 0.9rem;
  font-weight: 600;
  color: #555;
}

.avg-label {
  font-size: 0.8rem;
  color: #2d2c2c;
  margin-top: 4px;
}

</style>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
var currentMonth = new Date().getMonth() + 1; // 1-12
var currentYear = new Date().getFullYear();

// Update month display and fetch golden rules
function updateMonthDisplay() {
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];

    document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
    document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

    // Enable prev/next buttons
    document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
    document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

    // Fetch data for selected month/year
    loadForecastMetrics(currentMonth, currentYear);
}

// Previous month button
document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
    e.preventDefault();
    if (currentMonth === 1) {
        currentMonth = 12;
        currentYear--;
    } else {
        currentMonth--;
    }
    updateMonthDisplay();
});

// Next month button
document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
    e.preventDefault();
    if (currentMonth === 12) {
        currentMonth = 1;
        currentYear++;
    } else {
        currentMonth++;
    }
    updateMonthDisplay();
});
// Format as Indian Rupee
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', { 
        style: 'currency', 
        currency: 'INR',
        maximumFractionDigits: 0 // remove decimals
    }).format(amount);
}
function padTwoDigits(num) {
    return String(num).padStart(2, '0');
}
function getOrdinalSuffix(day) {
    if (day > 3 && day < 21) return day + 'th'; // 11th–20th always "th"
    switch (day % 10) {
        case 1: return day + 'st';
        case 2: return day + 'nd';
        case 3: return day + 'rd';
        default: return day + 'th';
    }
}

function loadForecastMetrics(month, year) {
  fetch(`/get_forecast_metrics?month=${month}&year=${year}`)
    .then(res => res.json())
    .then(res => {
      if (res.status === 200) {
        const data = res.data;

        const monthlyTargetMoney = parseFloat(data?.monthly_target || 0);
        const monthlyPreSale = parseFloat(data?.no_of_registrations || 0);
        const monthlyPostSale = parseFloat(data?.post_sale || 0);

        const currentDay = res.currentDay;
        const monthEndDay = res.monthEndDay;

        // Actuals
        const currentMoney = parseFloat(res.targetValue || 0);
        const currentPreSale = parseFloat(res.preSaleValue || 0);
        const currentPostSale = parseFloat(res.postSaleValue || 0);

        // Averages
        const avgMoney = formatCurrency(res.daily_avg.money_avg || 0);
        const avgPreSale = padTwoDigits(res.daily_avg.preSale_avg || 0);
        const avgPostSale = padTwoDigits(res.daily_avg.postSale_avg || 0);

        // Predicted
        const predictedMoney = parseFloat(res.predicted.money || 0);
        const predictedPreSale = parseFloat(res.predicted.preSale || 0);
        const predictedPostSale = parseFloat(res.predicted.postSale || 0);

        const monthName = new Date(year, month - 1).toLocaleString('default', { month: 'long' });
        const monthEndDayWithSuffix = getOrdinalSuffix(monthEndDay);

        // Check achievements
        const isTargetAchieved = currentMoney >= monthlyTargetMoney;
        const isPreSaleAchieved = currentPreSale >= monthlyPreSale;
        const isPostSaleAchieved = currentPostSale >= monthlyPostSale;

        const targetColor = isTargetAchieved ? "green" : "red";
        const preColor = isPreSaleAchieved ? "green" : "red";
        const postColor = isPostSaleAchieved ? "green" : "red";
         renderForecastChart(
                    data.monthly_target || 0,   // monthly target
                    res.targetValue || 0,       // current achieved
                    currentDay,                 // today's day
                    monthEndDay                 // month end
                );
        document.getElementById("forecastMetricsContainer").innerHTML = `
          <!-- Target -->
          <div class="col-md-12 mb-3">
            <div class="card card-light">
              <div class="card-light-header">
                <h3 class="fs-4 fw-bold text-primary">Target (${monthName} ${year})</h3>
              </div>
              <div class="card-body">
                <div class="row text-center">
                  <div class="col-lg-4">
                    <div class="metric-box-green">
                      <h1 >${formatCurrency(monthlyTargetMoney)}</h1>
                      <small>Target Value</small>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box-green">
                      <h1 >${padTwoDigits(monthlyPreSale)}</h1>
                      <small>Pre-Sale</small>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box-green">
                      <h1 >${padTwoDigits(monthlyPostSale)}</h1>
                      <small>Post-Sale</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Current -->
          <div class="col-md-12 mb-3">
            <div class="card card-light">
              <div class="card-light-header">
                <h3 class="fs-4 fw-bold text-primary">Current Status (Day ${currentDay} of ${monthEndDay})</h3>
              </div>
              <div class="card-body">
                <div class="row text-center">
                  <div class="col-lg-4">
                    <div class="metric-box-second">
                      <h1 >${formatCurrency(currentMoney)}</h1>
                      <p class="avg-label fs-5 fw-semibold mb-2 mt-2">Avg: ${avgMoney}/day</p>
                      <small>Target Achieved</small>
                      
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box-second">
                      <h1 >${padTwoDigits(currentPreSale)}</h1>
                      <p class="avg-label fs-5 fw-semibold mb-2 mt-2">Avg: ${avgPreSale}/day</p>
                      <small>Pre-Sale</small>
                      
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box-second">
                      <h1 >${padTwoDigits(currentPostSale)}</h1>
                      <p class="avg-label fs-5 fw-semibold mb-2 mt-2">Avg: ${avgPostSale}/day</p>
                      <small>Post-Sale</small>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Predicted -->
          <div class="col-md-12 mb-3">
            <div class="card card-light">
              <div class="card-light-header">
                <h3 class="fs-4 fw-bold text-primary">Expecting (Month End: ${monthEndDayWithSuffix} Day)</h3>
              </div>
              <div class="card-body">
                <div class="row text-center">
                  <div class="col-lg-4">
                    <div class="metric-box ${targetColor}">
                      <h1>${formatCurrency(predictedMoney)}</h1>
                      <small>Expecting Target</small>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box ${preColor}">
                      <h1>${padTwoDigits(predictedPreSale)}</h1>
                      <small>Expecting Pre-Sale</small>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="metric-box ${postColor}">
                      <h1>${padTwoDigits(predictedPostSale)}</h1>
                      <small>Expecting Post-Sale</small>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        `;
      }
    });
}

function renderForecastChart(monthlyTarget, currentValue, currentDay, monthEndDay) {
    const ctx = document.getElementById('forecastChart').getContext('2d');

    // Destroy old chart if modal reopened
    if (window.forecastChartInstance) {
        window.forecastChartInstance.destroy();
    }

    const labels = Array.from({ length: monthEndDay }, (_, i) => i + 1);
    const targetData = labels.map(day => Math.round(monthlyTarget / monthEndDay * day));
    const actualData = labels.map(day =>
        day <= currentDay ? Math.round(currentValue / currentDay * day) : null
    );
    const dailyAvg = currentValue / currentDay;
    const predictedData = labels.map(day =>
        day >= currentDay ? Math.round(dailyAvg * day) : null
    );

    window.forecastChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [
                {
                    label: 'Target Plan',
                    data: targetData,
                    borderColor: '#007bff',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: false
                },
                {
                    label: 'Actual Achieved',
                    data: actualData,
                    borderColor: '#28a745',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: false,
                    pointBackgroundColor: '#28a745'
                },
                {
                    label: 'Predicted Forecast',
                    data: predictedData,
                    borderColor: '#ff9800',
                    borderDash: [5, 5],
                    borderWidth: 2,
                    tension: 0.3,
                    fill: false,
                    pointBackgroundColor: '#ff9800'
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
}


updateMonthDisplay();
</script>

@endsection
