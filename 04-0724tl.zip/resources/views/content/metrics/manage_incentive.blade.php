@extends('layouts/layoutMaster')

@section('title', 'Manage Incentive')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<style>
    .table-rule1 tbody,
    tr,
    td,
    tfoot,
    th,
    thead,
    tr {
        border: 1px solid black !important;
    }

    .table-rule1 thead th {
        background: #333;
        color: #fff;
        position: -webkit-sticky;
        position: sticky;
        top: 0;
    }

    th.sticky,
    tbody td:last-child {
        position: -webkit-sticky;
        position: sticky;
        right: 0;
        z-index: 2;
        background: #ccc;
    }

    th.sticky,
    tbody td:first-child {
        position: -webkit-sticky;
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ccc;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h5 class="mb-1">Manage Incentive</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Metrics Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
           <div class="col-lg-6 text-end">
                <label class="mt-1 fs-3 bg-label-info px-2 py-2 rounded" id="branch_name_lab">{{ $branch_common->branch_name??'' }}</label>
            </div>
        </div>
       
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                @php
                $helper = new \App\Helpers\Helpers();
                $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id; // Get branch_id from query or user session
                @endphp
    
                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            // Get the logged-in user_id
                            $user_id = auth()->user()->user_id;
    
                            // Get the filtered branch and franchise list based on user's multi_branch_access
                            $branch_data = $helper->get_branch_control_list($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal" onchange="branch_change()">
                            @if($user_id == 0)
                            <option value="0" selected>All Branches</option>
                            @endif
                            @if ($branches->isNotEmpty())
                                <optgroup  label="Branches">
                                    @foreach ($branches as $branch)
                                        <!--@ if($branch->sno!=1)-->
                                            <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                {{ $branch->branch_name }}
                                            </option>
                                        <!--@ endif-->
                                    @endforeach
                                </optgroup>
                            @endif
    
    
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                        
                    @elseif($role_permission->manage_branch == 1)
    
    
                    @if($branch_common)
                      <div class="d-flex align-items-center mt-2">
                          <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                          <div>
                              <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                              <small class="text-truncate max-w-10px text-muted" title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                              <input type="hidden" name="branch_id"  id="branchSelectsgoal" value="{{$branch_common->sno}}">
                          </div>
                      </div>
    
                        @else
    
                        @endif
                    @endif
    
                @endif
                
            </div>
            <!--<div class="col-lg-3 mb-3">-->
            <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>-->
            <!--    <select id="department_filter" name="department_id" class="select3 form-select" onchange="deptChange()">-->
                    <!-- Options will be dynamically populated -->
            <!--    </select>-->
            <!--</div>-->
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-5 fw-semibold">Role<span class="text-danger">*</span></label>
                <select id="role_filter" name="role_id" class="select3 form-select" onchange="deptChange()">
                    <!-- Options will be dynamically populated -->
                </select>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="nav-align-top my-4">
                  <ul class="nav nav-pills justify-content-start" role="tablist">
                      <!-- Previous Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="prevMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
    
                      <!-- Current Month Display -->
                      <li class="nav-item me-1">
                          <a class="nav-link active px-3 border border-dashed border-info" href="#">
                              <div class="text-center">
                                  <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                      {{ \Carbon\Carbon::now()->format('F') }}
                                  </span>
                                  <div class="d-block">
                                      <span class="fw-semibold fs-8" id="selectedYear">
                                          ({{ \Carbon\Carbon::now()->year }})
                                      </span>
                                  </div>
                              </div>
                          </a>
                      </li>
    
                      <!-- Next Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="nextMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
                  </ul>
              </div>
            </div>
        </div>
        <div class="row" id="incentiveaccordion"></div>
        <div id="incentiveLoader" class="text-center py-4" style="display: none;">
            <div class="progress" style="height: 20px; width: 50%; margin: auto;">
                <div id="incentiveProgressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-info rounded-pill" 
                    role="progressbar" 
                    style="width: 0%" 
                    aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                    Loading...
                </div>
            </div>
            <div id="incentiveLoadingText" class="mt-2 fw-semibold text-primary">Loading Incentives...</div>
        </div>
    </div>
</div>


<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Converted Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-6" id="previousMonthConvert">
                        <h5 class="text-center bg-light p-2 rounded fw-bold mb-2 "id="previousMonth">Previous Month Converted Customers</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer Name</th>
                                        <th style="min-width: 250px;">Reason</th>
                                    </tr>
                                </thead>
                                <tbody id="actualDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-6" id="currentMonthConvert">
                        <h5 class="text-center bg-light p-2 rounded fw-bold mb-2" id="currentMonth">Current Month Converted Customers</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer Name</th>
                                        <th style="min-width: 250px;">Reason</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row mt-4" id="summarySection" style="display: none;">
                    <!-- Previous Month Summary -->
                    <div class="col-md-6 mb-4 d-none" id="prevsummarySection">
                        <div class="card border border-primary shadow-sm h-100">
                            <div class="card-header bg-primary text-white fw-bold text-center fs-5 rounded-top">
                                Previous Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Converted</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="prevConverted">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Second Payment Pending</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevSecondPay">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Dropouts</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevDrop">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Low MPC</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevLmbc">0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <!-- Current Month Summary -->
                    <div class="col-md-12 mb-4" id="currentsummarySection">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Converted</div>
                                            <div class="d-flex justify-content-center align-items-center gap-3 flex-wrap fs-4 fw-bold">
                                                <span class="badge bg-secondary px-4 py-2" id="currConverted">0</span>
                                                <span class="text-dark">−</span>
                                                <span class="badge bg-danger px-4 py-2" id="minusConverted">0</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalConverted">0</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Low MPC</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="currLmbc">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Dropouts</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="currDrop">0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!--end::Modal body-->
            </div>
        <!--end::Modal content-->
        </div>
    <!--end::Modal dialog-->
    </div>
</div>
<!--end::Actual Details Modal -->
<!--Actual Calculation Modal -->
<div class="modal fade" id="calculationDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                 <div id="piStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="piStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="piStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="callStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">PI Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Month</th>
                                <th style="min-width: 100px;">Course</th>
                                <th style="min-width: 100px;">Actual</th>
                                <th style="min-width: 100px;">Selling Price</th>
                                <th style="min-width: 250px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody id="calculationDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="calculationDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Calculation Modal -->


<!--Actual ECI Modal -->
<div class="modal fade" id="eciDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="eciStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="eciStaffIntialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="eciStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="eciStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">EcI Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Created At</th>
                                <th style="min-width: 100px;">Status</th>
                            </tr>
                        </thead>
                        <tbody id="eciDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="eciDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual ECI Modal -->

<!--Actual Call Modal -->
<div class="modal fade" id="callDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="callStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="callStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="callStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="callStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Call Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Created Date</th>
                                <th style="min-width: 100px;">On day</th>
                                <th style="min-width: 100px;">On Month</th>
                                <th style="min-width: 100px;">Old Month</th>
                                <th style="min-width: 100px;">Rewards</th>
                            </tr>
                        </thead>
                        <tbody id="callDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="callDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Call Modal -->

<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCollectionModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CollectionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                    <!-- Full Width Block -->
                    <div class="w-100">
                        <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                        <div class="d-flex justify-content-between align-items-center">
                            <!-- Left: Staff Info -->
                            <div class="d-flex flex-column">
                            <div id="CollectionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                            <span id="CollectionStaffDept" class="badge bg-info mt-1">Collection</span>
                            </div>
                    
                            <!-- Center: Heading -->
                            <div class="text-center flex-grow-1">
                            <h3 class="mb-0 text-black">Collection Customer Details</h3>
                            </div>
                    
                            <!-- Right: Empty block to balance spacing -->
                            <div style="width: 100px;"></div>
                        </div>
                    </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-danger p-2 rounded fw-bold mb-2 "id="previousMonth">Old Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="OldDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-success p-2 rounded fw-bold mb-2" id="currentMonth">Current Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="CurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-info p-2 rounded fw-bold mb-2" id="currentMonth">Future Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="FutureDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Collection Summary Bar -->
                <div class="bg-white p-3 mb-4 rounded shadow-sm sticky-top border border-primary" style="top: 0; z-index: 1040; border-width: 2px;">
                    <div class="row text-center fw-bold">
                        <div class="col text-danger border-end fs-5">
                            Old Month<br>
                            ₹<span id="oldAmount">0</span>
                            (<span id="oldPercentage">0</span>%)
                        </div>
                        <div class="col text-success border-end fs-5">
                            Current Month<br>
                            ₹<span id="currentAmount">0</span>
                            (<span id="currentPercentage">0</span>%)
                        </div>
                        <div class="col text-info fs-5 bold">
                            Future Month<br>
                            ₹<span id="futureAmount">0</span>
                            (<span id="futurePercentage">0</span>%)
                        </div>
                    </div>
                </div>
               

                <!--end::Modal body-->
            </div>
        <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
</div>
<!--end::Actual Details Modal -->


<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCollectionModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CollectionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="CollectionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="CollectionStaffDept" class="badge bg-info mt-1">Collection</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Collection Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-danger p-2 rounded fw-bold mb-2 "id="previousMonth">Old Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="OldDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-success p-2 rounded fw-bold mb-2" id="currentMonth">Current Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="CurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-info p-2 rounded fw-bold mb-2" id="currentMonth">Future Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="FutureDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Collection Summary Bar -->
                <div class="bg-white p-3 mb-4 rounded shadow-sm sticky-top border border-primary" style="top: 0; z-index: 1040; border-width: 2px;">
                    <div class="row text-center fw-bold">
                        <div class="col text-danger border-end fs-5">
                            Old Month<br>
                            ₹<span id="oldAmount">0</span>
                            (<span id="oldPercentage">0</span>%)
                        </div>
                        <div class="col text-success border-end fs-5">
                            Current Month<br>
                            ₹<span id="currentAmount">0</span>
                            (<span id="currentPercentage">0</span>%)
                        </div>
                        <div class="col text-info fs-5 bold">
                            Future Month<br>
                            ₹<span id="futureAmount">0</span>
                            (<span id="futurePercentage">0</span>%)
                        </div>
                    </div>
                </div>
               
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Details Modal -->

<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCourseModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CourseStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="CourseStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="CourseStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">PI Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-12">
                        <h5 class="text-center  bg-light p-2 rounded fw-bold mb-2 "id="strategic_status">Below 25K</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 150px;">Customer</th>
                                        <th style="min-width: 200px;">service</th>
                                        <th style="min-width: 80px;">Transaction Date</th>
                                        <th style="min-width: 80px;">Amount</th>
                                        <th style="min-width: 80px;">Net Amount</th>
                                    </tr>
                                </thead>
                                <tbody id="CrashDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                                <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                                    <tr id="CrashDetailsFooter">
                                      <td colspan="3" class="text-end">Total</td>
                                      <td id="CrashTotalAmount">₹0</td>
                                      <td id="CrashTotalNetAmount">₹0</td>
                                    </tr>
                                   <tr>
                                        <td colspan="3" class="text-end">Average Net Amount</td>
                                        <td id="AverageNetAmountCalc"></td>
                                        <td  id="AverageNetAmount">₹0</td>
                                    </tr>
                                  </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!--end::Actual Details Modal -->
<div class="modal fade" id="creAwardDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciCreStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="eciCreStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="eciCreStaffIntialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="eciSCRetaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="eciCreStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">10x Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected Date</th>
                                <th style="min-width: 100px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody id="eciCreDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="eciCreDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>

                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Amount</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="creTotalHarvest">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Pending</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="creBalance">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection</div>
                                            <div class="fs-3 fw-bold  badge bg-label-success" id="creCollection">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection Percentage</div>
                                            <div class="d-flex justify-content-center align-items-center gap-2 flex-wrap fs-4 fw-bold">
                                                <span class="text-dark">( </span>
                                                <span class="badge bg-secondary px-4 py-2" id="creCollectionAmount">0</span>
                                                <span class="text-dark">/</span>
                                                <span class="badge bg-danger px-4 py-2" id="creTotalAmount">0</span>
                                                <span class="text-dark"> )</span>
                                                <span class="text-dark"> * 100</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalCreCollectionPercentage">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Details Modal -->

<div class="modal fade" id="oldCollectionDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciCreStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="oldCollectionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="oldCollectionStaffInitial"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="oldCollectionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="oldCollectionStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Old Collection Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected Date</th>
                                <th style="min-width: 100px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody id="oldCollectionDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="oldCollectionDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>

                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Previous Month Target</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="oldTargetAmount">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collected</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="oldCollectedAmount">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Pending</div>
                                            <div class="fs-3 fw-bold  badge bg-label-success" id="oldPendingAmount">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection %</div>
                                            <div class="fs-3 fw-bold  badge bg-label-success" id="oldCollectionPercentage">0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="actualJournalDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournal" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournal" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournal" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournal" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournal">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="actualJournalDetailsModalDoubleX" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournalDoubleX" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournalDoubleX" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournalDoubleX" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournalDoubleX" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournalDoubleX">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="actualJournalExtDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournalExt" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournalExt" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournalExt" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournalExt" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Extra Acheivement Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournalExt">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="performanceJournalExeDetails" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="performJournalExeStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="performJournalExeStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                     <div id="performJournalExeStaffInitialImage" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                  
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="performJournalExeStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="performJournalExeStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Performance Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Attendance</th>
                            </tr>
                        </thead>
                        <tbody id="performJournalExeDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="performJournalExeDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div id="performJournalExeCalculationCard"
                    class="card mt-4 border border-primary shadow-sm rounded ">
                    <div class="card-body d-flex justify-content-end align-items-center flex-wrap gap-3 p-2">

                      

                        <div class="card px-6 py-4 rounded shadow-md">
                            <div class="fw-bold text-muted mb-2">Attendance Percentage</div>
                            <span id="actualAttendanceRate"
                                class="badge bg-danger rounded fs-2 px-4 text-center">
                                0%
                            </span>
                        </div>

                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="performanceSalesDetails" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="performcallStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="performcallStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                     <div id="performcallStaffInitialImage" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                  
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="performcallStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="performcallStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Performance Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Outgoing Calls</th>
                                <th>Incoming Calls</th>
                                <th>Missed Calls</th>
                            </tr>
                        </thead>
                        <tbody id="performcallDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="performcallDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div id="performCallCalculationCard"
                    class="card mt-4 border border-primary shadow-sm rounded ">
                    <div class="card-body d-flex justify-content-end align-items-center flex-wrap gap-3 p-2">

                        <div class="card px-6 py-4 rounded shadow-md">
                            <div class="fw-bold text-muted mb-2">Actual Outgoing / Day</div>
                            <span id="actualOutgoingPerDay"
                                class="badge bg-success fs-2 px-4 text-center rounded">
                                0
                            </span>
                        </div>

                        <div class="card px-6 py-4 rounded shadow-md">
                            <div class="fw-bold text-muted mb-2">Missed Call Rate</div>
                            <span id="actualMissedCallRate"
                                class="badge bg-danger rounded fs-2 px-4 text-center">
                                0%
                            </span>
                        </div>

                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<!--Actual Cre ECI Modal -->
<div class="modal fade" id="eciCreDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="eciStaffImageCre" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="eciStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="eciStaffNameCre" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="eciStaffDeptCre" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">EcI Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected At</th>
                                <th style="min-width: 100px;">Status</th>
                            </tr>
                        </thead>
                        <tbody id="eciDetailsBodyCre">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="eciDetailsFooterCre">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Amount</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="creEciTotalHarvest">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">ECI Amount </div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="creEciBalance">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">ECI Percentage</div>
                                            <div class="d-flex justify-content-center align-items-center gap-2 flex-wrap fs-4 fw-bold">
                                                <span class="text-dark">( </span>
                                                <span class="badge bg-secondary px-4 py-2" id="creEciCollectionAmount">0</span>
                                                <span class="text-dark">/</span>
                                                <span class="badge bg-danger px-4 py-2" id="creEciTotalAmount">0</span>
                                                <span class="text-dark"> )</span>
                                                <span class="text-dark"> * 100</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalCreEciCollectionPercentage">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Cre ECI Modal -->

<!--Actual Cre ECI Modal -->
<div class="modal fade" id="spotCreDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="spotStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="spotStaffImageCre" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="spotStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="spotStaffNameCre" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="spotStaffDeptCre" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Spot Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected At</th>
                                <th style="min-width: 100px;">Status</th>
                            </tr>
                        </thead>
                        <tbody id="spotDetailsBodyCre">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="spotDetailsFooterCre">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Amount</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="crespotTotalHarvest">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">spot Amount </div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="crespotBalance">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-12">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">spot Percentage</div>
                                            <div class="d-flex justify-content-center align-items-center gap-2 flex-wrap fs-4 fw-bold">
                                                <span class="text-dark">( </span>
                                                <span class="badge bg-secondary px-4 py-2" id="crespotCollectionAmount">0</span>
                                                <span class="text-dark">/</span>
                                                <span class="badge bg-danger px-4 py-2" id="crespotTotalAmount">0</span>
                                                <span class="text-dark"> )</span>
                                                <span class="text-dark"> * 100</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalCrespotCollectionPercentage">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Cre ECI Modal -->

<!--Actual Cre ECI Modal -->
<div class="modal fade" id="bonusCreDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="bonusStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="bonusStaffImageCre" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="bonusStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="bonusStaffNameCre" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="bonusStaffDeptCre" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">bonus Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected At</th>
                                <th style="min-width: 100px;">Status</th>
                            </tr>
                        </thead>
                        <tbody id="bonusDetailsBodyCre">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="bonusDetailsFooterCre">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Amount</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="collectionBonusTotalHarvest">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Pending</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="collectionBonusBalance">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection</div>
                                            <div class="fs-3 fw-bold  badge bg-label-success" id="collectionBonusCollected">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection Percentage</div>
                                            <div class="d-flex justify-content-center align-items-center gap-2 flex-wrap fs-4 fw-bold">
                                                <span class="text-dark">( </span>
                                                <span class="badge bg-secondary px-4 py-2" id="collectionBonusAmount">0</span>
                                                <span class="text-dark">/</span>
                                                <span class="badge bg-danger px-4 py-2" id="collectionBonusTotalAmount">0</span>
                                                <span class="text-dark"> )</span>
                                                <span class="text-dark"> * 100</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalcollectionBonusPercentage">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Cre ECI Modal -->

<!--Actual Cre ECI Modal -->
<div class="modal fade" id="referralCreDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="referralStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="referralStaffImageCre" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="referralStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="referralStaffNameCre" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="referralStaffDeptCre" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Referral Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Created Date</th>
                            </tr>
                        </thead>
                        <tbody id="referralDetailsBodyCre">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="referralDetailsFooterCre">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Cre ECI Modal -->
<div class="modal fade" id="referralCollectDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="referralCollectStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="referralStaffImageCollect" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="referralStaffIntialImageCollect"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="referralStaffNameCollect" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="referralStaffDeptCollect" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Referral Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Created Date</th>
                            </tr>
                        </thead>
                        <tbody id="referralDetailsBodyCollect">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="referralDetailsFooterCollect">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<!--Actual Cre ECI Modal -->
<div class="modal fade" id="productionDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="productionStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="productionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="productionStaffIntialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="productionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="productionStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Production Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Task Name</th>
                                <th>Planned</th>
                                <th>Actual</th>
                                <th>Status</th>
                                <th>Saving</th>
                            </tr>
                        </thead>
                        <tbody id="productionDetailsBody">
                        </tbody>   
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="productionDetailsFooter">
                            
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row " id="production_summary">
                                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- <div  id="productionDetailsBody">
                    <div class="text-center p-5">
                        <div class="spinner-border text-primary"></div>
                    </div>
                </div> -->
                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Cre ECI Modal -->

<div class="modal fade" id="piCalculationDetailModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                 <div id="piStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  
                  <div class="flex-shrink-0">
                    <img id="piCalStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="piCalStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="piCalStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="piCalStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Strategic Incentive Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
               <div class="modal-body" id="piDetailModalBody">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="piPostCalculationDetailModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                 <div id="piPostStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  
                  <div class="flex-shrink-0">
                    <img id="piPostStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="piPostStaffIntialImageCre"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="piPostStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="piPostStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Profitable Incentive Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
               <div class="modal-body" id="piPostDetailModalBody">
                    <div class="text-center">
                        <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>



<div class="modal fade" id="teamDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="teamStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="teamStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                     <div id="teamStaffInitialImage" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                  
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="teamStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="teamStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Team 10X Details</h3>
                      </div>
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>

                <div id="teamDetailsBody"></div>
                
                <!-- <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Outgoing Calls</th>
                                <th>Incoming Calls</th>
                                <th>Missed Calls</th>
                            </tr>
                        </thead>
                        <tbody id="performcallDetailsBody">
                            
                        </tbody>
                    </table>
                </div> -->
                
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="rewardInfoModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content reward-modal">
            <div class="reward-top-glow"></div>
            <div class="modal-body p-0">
                <div class="reward-header">
                    <div class="reward-close" data-bs-dismiss="modal">✕</div>
                    <img id="rewardChestImage" src="{{ asset('assets/phdizone_images/incentive/chest.gif') }}" class="reward-chest">
                    <div class="reward-badge">INCENTIVE REWARD</div>
                    <h3 id="rewardTitle" class="reward-title"></h3>
                    <div id="rewardValue" class="reward-amount"></div>
                </div>
                <div class="reward-body">
                    <div class="reward-section-title">
                        🎯 How To Unlock
                    </div>
                    <div id="rewardRules"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .reward-modal{
        border:none;
        border-radius:24px;
        overflow:hidden;
        background:#fff;
        box-shadow:
            0 25px 80px rgba(0,0,0,.18);
    }

    .reward-top-glow{
        height:6px;
        background:
        linear-gradient(
            90deg,
            #ffcc00,
            #ff9800,
            #ffcc00
        );
    }

    .reward-header{
        position:relative;
        text-align:center;
        padding:30px 25px;
        background:linear-gradient(135deg, #07193d, #00246B)
    }

    .reward-close{
        position:absolute;
        right:15px;
        top:15px;
        width:34px;
        height:34px;
        border-radius:50%;
        background:rgba(255,255,255,.15);
        color:#fff;
        cursor:pointer;
        display:flex;
        align-items:center;
        justify-content:center;
    }

    .reward-close:hover{
        background:rgba(255,255,255,.25);
    }

    .reward-chest{
        width:100px;
        margin:auto;
        display:block;
        filter:drop-shadow(
            0 0 20px rgba(255,215,0,.4)
        );

        animation:
            chestFloat 2.5s ease-in-out infinite;
    }

    @keyframes chestFloat{
        0%{
            transform:translateY(0);
        }
        50%{
            transform:translateY(-8px);
        }
        100%{
            transform:translateY(0);
        }
    }

    .reward-badge{
        margin-top:15px;
        display:inline-block;
        padding:6px 14px;
        border-radius:30px;
        background:rgba(255,255,255,.1);
        color:#ffd54f;
        font-size:11px;
        letter-spacing:2px;
        font-weight:700;
    }

    .reward-title{
        color:#fff;
        font-weight:700;
        margin-top:15px;
    }

    .reward-amount{
        margin-top:10px;
        font-size:38px;
        font-weight:800;
        color:#ffcc00;
        text-shadow:
            0 0 15px rgba(255,204,0,.3);
    }

    .reward-body{
        padding:25px;
    }

    .reward-section-title{
        font-size:16px;
        font-weight:700;
        margin-bottom:15px;
    }

    .reward-rule-item{
        display:flex;
        align-items:flex-start;
        gap:12px;
        padding:14px;
        margin-bottom:10px;
        border-radius:14px;
        background:#f8fafc;
        border:1px solid #e5e7eb;
        transition:.25s;
    }

    .reward-rule-item:hover{
        transform:translateX(4px);
        background:#fff8e7;
    }

    .reward-rule-icon{
        width:34px;
        height:34px;
        border-radius:50%;
        background:#fff3cd;
        color:#ff9800;
        display:flex;
        align-items:center;
        justify-content:center;
        font-weight:700;
    }

    .reward-rule-text{
        flex:1;
        font-size:14px;
        color:#374151;
    }
</style>



<div class="modal fade" id="actualJournalTLDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournalTL" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournalTL" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournalTL" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournalTL" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournalTL">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="actualJournalTLDetailsModalDoubleX" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournalDoubleXTL" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournalDoubleXTL" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournalDoubleXTL" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournalDoubleXTL" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournalDoubleXTL">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
 <!--getmetrics-->
<script>
    let incentiveRequest = null;      // jQuery AJAX request tracker
    let incentiveRealController = null; // AbortController for fetch
    let debounceTimer = null;
    const BASE_URL = "{{ url('/') }}/";
    
    function fetchIncentivesList() {
        let departmentId = $("#department_filter").val();
        let role_id = $("#role_filter").val();
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
        
        if (incentiveRequest) {
            incentiveRequest.abort(); // cancel the previous request
        }

    
        // Show loader, hide accordion
        $("#incentiveLoader").show();
        $("#incentiveaccordion").hide();
        
        const progressBar = $("#incentiveProgressBar");
        let startTime = Date.now();
        const duration = 55000; // 55 seconds = realistic max load time
        let timer;
    
        function updateProgress() {
            const elapsed = Date.now() - startTime;
            let progress = Math.min((elapsed / duration) * 100, 98); // up to 98%
            progressBar.css("width", `${progress}%`).attr("aria-valuenow", progress.toFixed(0));
            if (progress < 98) {
                timer = requestAnimationFrame(updateProgress);
            }
        }
    
        updateProgress(); // start animation
    
        incentiveRequest =$.ajax({
            url: "{{ route('get-incentive') }}",
            type: "GET",
            data: {
                branch_id: branch_id,
                month: month,
                year: year,
                department_id: departmentId,
                role_id: role_id
            },
            success: function (response) {
                cancelAnimationFrame(timer);
                progressBar.css("width", "100%").attr("aria-valuenow", 100).text("Loading...");
    
                setTimeout(() => {
                    $("#incentiveLoader").hide();
                    $("#incentiveaccordion").show();
                    // Populate your incentives accordion here
                }, 400); // short delay for smooth UX
                    let rowsHtml = '';
        
                    if (response.status === 200 && response.data.length > 0) {
                        window.incentiveData = response.data;
                       response.data.forEach((staff, index) => {
                        let staffId = `collapseStaff${index}`;
                        let tbody = '';
                        let totalAward = 0;
                        let rewardSummary = '';
                        const incentiveNameMap = {
                            tenx_award: '10x',
                            team: 'Team',
                            eci: 'ECI',
                            bi: 'BI',
                            si: 'SI',
                            pi: 'PI',
                            sp: 'SP',
                            aci: 'ACI',
                            perform_incent: 'PI',
                            exi: 'EXTRA',
                            doublex: '2X',
                            old_collection: 'Old Collection',
                            collection_150_percent: '150% Collection',
                            drop_collection: 'Drop Collection',
                            issue_free: 'Issue Free',
                            abv_incentive: 'ABV',
                            abv_150_incentive: 'ABV 150%',
                            yearly_150_incentive: 'Year 150%',
                            nine_month_consistency_incentive: '9 Month',
                            team_achievement_incentive: 'Team 10x',
                            li: 'LI',
                            ri: 'RI'
                        };
                        const incentiveNameMapInside = {
                            tenx_award: '10x Award',
                            team: 'Team Incentive',
                            eci: 'ECI (Early Cash Incentive)',
                            bi: 'BI (Bonus Incentive)',
                            si: 'SI (Strategy Incentive)',
                            pi: 'PI (Profitable Incentive)',
                            sp: 'SP (Spot Incentive)',
                            aci: 'ACI (Additional Contribution Incentive)',
                            doublex: '2X (Double X Incentive)',
                            abv_incentive: 'ABV Incentive',
                            abv_150_incentive: 'ABV 150% Incentive',
                            old_collection: 'Old Collection',
                            collection_150_percent: '150% Collection',
                            drop_collection: 'Drop Collection',
                             issue_free: 'Issue Free Incentive',
                            team_achievement_incentive: 'Team Incentive',
                            yearly_150_incentive: 'Year 150% Incentive',
                            nine_month_consistency_incentive: '9 Month Incentive',
                            exi: 'EXTRA (Extra Achievement Incentive)',
                            perform_incent: 'PI (Performance Incentive)',
                            li: 'LI (Luxury Incentive)',
                            ri: 'RI (Referral Incentive)'
                        };
                    
                        for (const [key, item] of Object.entries(staff.incentives)) {
                            const rewrdText = key == 'nine_month_consistency_incentive' ? item.reward : '';
                            const rewardValue = key == 'nine_month_consistency_incentive' ? 0 :(Number(item.reward) || 0);
                          
                            totalAward += rewardValue;
                            const valueColor = rewardValue > 0 ? 'bg-success' : 'bg-danger';
                            // Top-level badge summary
                           rewardSummary += `
                                <span class="badge d-inline-flex fw-bold align-items-center ${valueColor} text-white border me-2 mb-1 px-3 py-2 shadow-sm fs-4">
                                    
                                    ${incentiveNameMap[key] || key}: ${rewrdText ? rewrdText : '₹'+rewardValue.toLocaleString('en-IN')}
                                </span>
                            `;
                    
                            // Row-wise detailed view
                            
                             const statusIcon = item.status
                                    ? `<a href="javascript:;" class="btn btn-icon btn-sm">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                            <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                            <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                        </svg>
                                    </a>`
                                    : `<a href="javascript:;" class="btn btn-icon btn-sm">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                            <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                            <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                        </svg>
                                    </a>`;
                    
                            tbody += `
                                <tr>
                                    <td class="text-start fw-bold fs-3">${incentiveNameMapInside[key] || key}</td>
                                    <td class="text-start text-black fs-5">${item.target}</td>
                                    <td class="text-start fw-semibold ${valueColor} fs-5">${item.actual}</td>
                                    <td>${statusIcon}</td>
                                    <td class="fw-bold fs-4 ${valueColor}">
                                        <div class="">
                                        
                                        ${ !item.status ?
                                         `<span class="reward-help-btn cursor-pointer" onclick='openRewardModal(${JSON.stringify(item)})'>
                                             <img src="{{ asset('assets/phdizone_images/incentive/question_mark.gif') }}" alt="emoji" style="max-width: 35px;">
                                         </span>`
                                         :
                                         (rewrdText ?
                                            `<span class="badge bg-label-secondary fw-bold  fs-2 text-wrap">${rewrdText}</span>`:

                                            `<span class="badge bg-label-secondary fw-bold  fs-2">₹${rewardValue.toLocaleString('en-IN')}</span>`)
                                        
                                         }
                                        </div>
                                      
                                    </td>
                                </tr>
                            `;
                        }
                    
                        // Total row
                        tbody += `
                            <tr class="fw-bold bg-light">
                                <td colspan="4" class="text-end fs-5">Total</td>
                                <td class="fs-4 text-white ${totalAward > 0 ? 'bg-success' : 'bg-danger'}">
                                    ₹${totalAward.toLocaleString('en-IN')}
                                </td>
                            </tr>
                        `;
                    
                        let awardBadge = `<span class="badge  ${totalAward > 0 ? 'bg-success' : 'bg-danger'} ms-2 mx-12 fs-3">
                            ₹${totalAward.toLocaleString('en-IN')}
                        </span>`;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                      
                    
                        rowsHtml += `
                            <div class="accordion-item mb-3 shadow-sm border rounded ${totalAward > 0 ? 'border-success' : 'border-danger'}">
                                <h2 class="accordion-header" id="heading${index}">
                                  <button class="accordion-button collapsed py-4 px-3 d-flex flex-column flex-md-row align-items-start align-items-md-center gap-3 text-start" 
                                    type="button" data-bs-toggle="collapse" 
                                    data-bs-target="#${staffId}" aria-expanded="false" 
                                    aria-controls="${staffId}">
                                
                                    <!-- Staff Image -->
                                      <div class="flex-shrink-0">
                                        ${staffImage 
                                            ? `<img src="/staff_images/${staffImage}" alt="user-avatar" class="rounded-circle" style="width: 60px; height: 60px;" />`
                                            : `<div class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;">
                                                  ${staffName.charAt(0).toUpperCase()}
                                              </div>`
                                        }
                                    </div>
                                
                                    <!-- Staff Info & Rewards -->
                                    <div class="w-100">
                                      <!-- Name and Department -->
                                      <div class="d-flex justify-content-between align-items-start flex-column flex-md-row gap-2">
                                        <div class="d-flex flex-column">
                                          <div class="fw-bold fs-5 text-dark">${staff.staff_name}</div>
                                          <span class="badge bg-info mt-1">${staff.department_name}</span>
                                        </div>
                                        <div class="reward-frame mx-2 ${totalAward >= 10000 ? 'gold' : totalAward >= 5000 ? 'silver' : totalAward > 0 ? 'bronze' : 'fail'}">
                                          <i class="mdi mdi-trophy me-1"></i>
                                          ₹${totalAward.toLocaleString('en-IN')}
                                        </div>
                                      </div>
                                
                                      <!-- Incentive Badges -->
                                      <div class="d-flex flex-wrap gap-2 mt-3">
                                        ${rewardSummary}
                                        ${totalAward > 0 ? `
                                            <div class="ms-auto"> <!-- pushes button to the right -->
                                                <a href="javascript:;" class="download-btn" data-staff-id="${staff.staff_id}" data-month="${month}" data-year="${year}">
                                                    <img src="{{ asset('assets/phdizone_images/download_btn.gif') }}" alt="emoji" style="max-width: 135px; height: 40px;">
                                                </a>
                                            </div>
                                            ` : ''}
                                      </div>
                                    </div>
                                
                                    <!-- Accordion Arrow -->
                                    <span class="accordion-arrow position-absolute end-0 me-2 top-50 translate-middle-y">
                                      <i class="fas fa-chevron-down fs-5 rotate-icon"></i>
                                    </span>
                                  </button>
                                </h2>
                                <div id="${staffId}" class="accordion-collapse collapse" aria-labelledby="heading${index}" data-bs-parent="#incentiveaccordion">
                                    <div class="accordion-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered align-middle text-center mb-2">
                                                <thead class="bg-primary text-white fw-semibold">
                                                    <tr>
                                                        <th>Incentive</th>
                                                        <th class="text-start">Target</th>
                                                        <th class="text-start">Actual</th>
                                                        <th>Status</th>
                                                        <th>Award (₹)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    ${tbody}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                     $('#incentiveaccordion').html(rowsHtml);
                    } else {
                        $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
                    }
                },
            error: function (error) {
               cancelAnimationFrame(timer);
               $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
            //   progressBar.removeClass("bg-primary").addClass("bg-danger").text("Failed");
            },
            complete: function () {
                // Hide loader, show accordion
                $("#incentiveLoader").hide();
                $("#incentiveaccordion").show();
                incentiveRequest = null;
            }
        });
    }

     function fetchIncentiveReal() {
          if (incentiveRealController) {
                incentiveRealController.abort(); // cancel the previous fetch
            }
            incentiveRealController = new AbortController();
        document.getElementById('incentiveLoader').style.display = 'block';
    
        let departmentId = $("#department_filter").val();
        let role_id = $("#role_filter").val();
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        fetch('/fetch-incentive', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                branch_id: branch_id,
                month: month,
                year: year,
                department_id: departmentId,
                role_id: role_id
            }),
              signal: incentiveRealController.signal
        })
        .then(response => response.json())
        .then(data => {
            if (data.status) {
                const staffNames = data.staff_names; // array from backend
                const types = data.types;            // array from backend
    
                const queue = [];
    
                // Prepare queue: each staff with each type
                staffNames.forEach((name, i) => {
                    types.forEach((type, j) => {
                        queue.push({ name, type });
                    });
                });
    
                // Display one-by-one with delay
                let i = 0;
                function nextMessage() {
                    if (i < queue.length) {
                        const msg = `${queue[i].name} ${queue[i].type} Calculation...`;
                        document.getElementById('incentiveLoadingText').textContent = msg;
                        i++;
                        setTimeout(nextMessage, 1000); // 1 second delay
                    }
                }
    
                nextMessage(); // Start loop

                $('[data-bs-toggle="tooltip"]').tooltip();
            }
        })
        .catch(error => {
            
            if (error.name !== 'AbortError') {
                console.error('Fetch error:', error);
                 document.getElementById('incentiveLoadingText').textContent = "No data available";
                    $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
                    $("#incentiveLoader").hide();
            }
        });
    }

    var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
    var currentYear = new Date().getFullYear();

    function updateMonthDisplay() {
          clearTimeout(debounceTimer);
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
        document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
        document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

        document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
        document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

        debounceTimer = setTimeout(() => {
            fetchIncentivesList();
            fetchIncentiveReal();
        }, 500); 
    }
    fetchRoles();
    
    function fetchRoles() {
          $.ajax({
              url: "{{ route('incentive_role') }}",
              type: "GET",
              success: function (response) {
                  if (response.status === 200 && response.data) {
                      var selectDropdown = $("#role_filter");
                      selectDropdown.empty().append('<option value="">Select Role</option>');

                      // Filter departments with sno 11, 12, 13, 14, 17, 22,15
                      let filteredData = response.data.filter(dept => [11, 12, 14, 16, 22,15,33,35,34,36,32,41,42].includes(dept.sno));

                      filteredData.forEach(function (dept) {
                          selectDropdown.append($('<option></option>')
                              .attr('value', dept.sno)
                              .text(dept.role_name));
                      });

                      // Set default selected value to 12
                      selectDropdown.val(11).trigger('change');
                  }
              },
              error: function (error) {
                  console.error('Error fetching departments:', error);
              }
          });
      }
      
    function fetchDepartments() {
        $.ajax({
            url: "{{ route('departments_setgoal') }}",
            type: "GET",
            success: function (response) {
                if (response.status === 200 && response.data) {
                    let selectDropdown = $("#department_filter");
                    selectDropdown.empty().append('<option value="">Select Department</option>');
    
                    let filteredData = response.data.filter(dept => [11, 12, 14, 16, 22].includes(dept.sno));
    
                    filteredData.forEach(function (dept) {
                        selectDropdown.append(
                            $('<option></option>').val(dept.sno).text(dept.department_name)
                        );
                    });
                    
                   $("#department_filter").val(1).change();
                   
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
            }
        });
    }
   
    function deptChange() {
          fetchIncentivesList();
          fetchIncentiveReal();
    }
    document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }
        updateMonthDisplay();
    });

    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }
        updateMonthDisplay();
    });
    
    
    window.addEventListener("DOMContentLoaded", function () {
        setTimeout(() => {
            fetchIncentivesList();
            fetchIncentiveReal();
        }, 200); // 200ms delay lets the loader show up before hidin
        fetchDepartments();
    });
    
    $(document).on("click", ".download-btn", function () {
    let staffId = $(this).data("staff-id");
    let currentMonthslct = $(this).data("month");
    let currentYearslct = $(this).data("year");
    let staff = window.incentiveData.find(s => s.staff_id == staffId);

    if (!staff) {
        console.error("Staff not found for staffId:", staffId);
        return;
    }

    // Incentive label mapping
    const incentiveLabels = {
        tenx_award: "10x Award",
        eci: "ECI (Early Cash Incentive)",
        bi: "BI (Bonus Incentive)",
        si: "SI (Strategy Incentive)",
        pi: "PI (Profitable Incentive)",
        sp: "SP (Spot Incentive)",
        li: "LI (Luxury Incentive)"
    };

    let rows = [];
    let total = 0;

    for (const [key, item] of Object.entries(staff.incentives)) {
        let rewardValue = Number(item.reward) || 0;
        total += rewardValue;

        let target = cleanText(item.target).replace(/₹/g, "Rs.");
        let actual = cleanText(item.actual).replace(/₹/g, "Rs.");
        let label = incentiveLabels[key] || key;

        rows.push([
            label,
            target,
            actual,
            item.status ? "Achieved" : "Not Achieved",
            `Rs. ${rewardValue.toLocaleString("en-IN")}`
        ]);
    }

    rows.push(["", "", "", "TOTAL", `Rs. ${total.toLocaleString("en-IN")}`]);

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // ✅ Page dimensions
    let pageWidth = doc.internal.pageSize.getWidth();
    let pageHeight = doc.internal.pageSize.getHeight();

    // ✅ Background image (added first)
    let bgUrl = `${BASE_URL}assets/phdizone_images/bg_image/guide_bg.jpg`; 
    doc.setGState(new doc.GState({ opacity: 0.1 })); // subtle opacity
    doc.addImage(bgUrl, "PNG", 0, 0, pageWidth, pageHeight);
    doc.setGState(new doc.GState({ opacity: 1 })); // reset opacity

    // ✅ Company Logo (top-right)
    let logoUrl = `${BASE_URL}assets/phdizone_images/phdizone_logo.png`;
    doc.addImage(logoUrl, "PNG", 160, 10, 45, 20);

    // ✅ Title
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text(`Incentive Summary - ${currentMonthslct} ${currentYearslct}`, 14, 20);

    // ✅ Profile Image (Rounded)
    let profileImg = staff.profile_url || `${BASE_URL}staff_images/${staff.staff_image}`;
   
    let y = 70;
  
    // ✅ Profile Image (Rounded) + Text on same row
    
    let imgX = 14; // left margin
    let imgY = 35; // move image slightly down from top
    let imgSize = 30;
    
    // Draw circle outline for profile image
    doc.setDrawColor(200);
    doc.circle(imgX + imgSize / 2, imgY + imgSize / 2, imgSize / 2, "S");
    
    // Add profile image
    doc.addImage(profileImg, "JPEG", imgX, imgY, imgSize, imgSize, "", "FAST");
    
    // Text positions (stacked vertically)
    let textXLabel = imgX + imgSize + 5;   // label position
    let textXValue = imgX + imgSize + 40;  // value position (so colons align)
    let lineHeight = 6.5;                  // slightly tighter spacing
    let textY = imgY + 5;                   // align text vertically with image
    
    // Set font slightly smaller and normal
    doc.setFontSize(11.5);
    doc.setFont("helvetica", "normal");
    
    // Name
    doc.text("Name :", textXLabel, textY);
    doc.text(`${staff.staff_name}`, textXValue, textY);
    
    // Job Role
    doc.text("Job Role:", textXLabel, textY + lineHeight);
    doc.text(`${staff.department_name}`, textXValue, textY + lineHeight);
    
    // Branch
    doc.text("Branch :", textXLabel, textY + lineHeight * 2);
    doc.text(`${staff.branch_name}`, textXValue, textY + lineHeight * 2);
    
    // Awarded
    doc.text("Awarded:", textXLabel, textY + lineHeight * 3);
    doc.text(`Rs. ${total.toLocaleString("en-IN")}`, textXValue, textY + lineHeight * 3);
    
    // ✅ Table start just below profile info
    let tableStartY = textY + lineHeight * 4 + 5; // small padding after profile
    doc.autoTable({
        head: [["Incentive", "Target", "Actual", "Status", "Award"]],
        body: rows,
        startY: tableStartY,
        theme: "grid",
        headStyles: { fillColor: [52, 152, 219], textColor: 255, fontStyle: 'bold' },
        styles: { fontSize: 10, valign: "middle", overflow: "linebreak", cellPadding: 3 },
        columnStyles: {
            0: { cellWidth: 45 },
            1: { cellWidth: 35 },
            2: { cellWidth: 35 },
            3: { cellWidth: 30, halign: "center" },
            4: { cellWidth: 35, halign: "right" }
        },
        didParseCell: function (data) {
            if (data.section === 'body' && data.column.index === 3) {
                if (data.cell.raw === "Achieved") data.cell.styles.textColor = [40, 167, 69];
                else if (data.cell.raw === "Not Achieved") data.cell.styles.textColor = [220, 53, 69];
            }
            if (data.section === 'body' && data.row.index === rows.length - 1) {
                data.cell.styles.fillColor = [230, 230, 230];
                data.cell.styles.fontStyle = 'bold';
                data.cell.styles.fontSize = 16;
                data.cell.styles.textColor = [0, 0, 0];
            }
        }
    });

    // ✅ Business Head signature (bottom right)
    // let signatureUrl = `${BASE_URL}terms_condition_signature/${staff.bh_signature}`;
     let signatureUrl = `${BASE_URL}terms_condition_signature/bh_signature.png`;
    doc.addImage(signatureUrl, "PNG", 140, pageHeight - 40, 50, 20);
    doc.text("Business Head", 150, pageHeight - 12);

    // Save PDF
    doc.save(`${staff.staff_name}_incentives.pdf`);
});

    // Clean HTML → plain
    function cleanText(html) {
        let tmp = document.createElement("div");
        tmp.innerHTML = html;
        tmp.querySelectorAll("span.badge-hover-clickable, label, i").forEach(el => el.remove());
        return (tmp.textContent || tmp.innerText || "").replace(/\s+/g, " ").trim();
    }
    
    function stripHtml(html) {
        let tmp = document.createElement("div");
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || "";
    }
    
    
    
   
    
    function formatDate(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }).replace(/ /g, '-');
    }

    function branch_change() {
        const select = document.getElementById('branchSelectsgoal');
        const selectedText = select.options[select.selectedIndex].text;
        // alert("Selected: " + selectedText);
        $('#branch_name_lab').html(selectedText);
        fetchIncentivesList();
        fetchIncentiveReal();
    }
    
    function openActualDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-Convertion-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff_data.staff_image;
                  let staffName = response.staff_data.staff_name || 'No Name Provided';
                  let departmentName = response.staff_data.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImage').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImage').text(initial).removeClass('d-none');
                        $('#actualStaffImage').addClass('d-none');
                    }
                     $('#actualStaffName').text(staffName);
                    $('#actualStaffDept').text(departmentName);
                    
                // if (response.data_prev && response.data_prev.length > 0) {
                //     const staff = response.data_prev[0];
                //     $('#actualStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                //     $('#actualStaffName').text(staff.staff_name);
                //     $('#actualStaffDept').text(staff.department_name);
                // }else{
                //      const staff = response.staff_data;
                //     $('#actualStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                //     $('#actualStaffName').text(staff.staff_name);
                //     $('#actualStaffDept').text(staff.department_name);
                // }
            
                // update Previous Month Heading
                if (response.data_prev && response.data_prev.length > 0) {
                    const prevMonth = response.data_prev[0].month;
                    $("#previousMonth").text(`Previous Month Converted Customers (${prevMonth})`);
                }
            
                // update Current Month Heading
                if (response.data_current && response.data_current.length > 0) {
                    const currMonth = response.data_current[0].month;
                    $("#currentMonth").text(`Current Month Converted Customers (${currMonth})`);
                }
                // Populate Summary
                const prev = response.summary_prev || {};
                const curr = response.summary_current || {};
                
                // Show section if any data exists
                if(response.second_payment_check == 1){
                     $('#previousMonthConvert').hide();
                     $('#currentMonthConvert').removeClass('col-md-6');
                     $('#currentMonthConvert').addClass('col-md-12');
                    if (curr) {
                        $('#summarySection').show();
                        
                        
                    }
                }else{
                     $('#summarySection').hide();
                     $('#previousMonthConvert').hide();
                     $('#currentMonthConvert').removeClass('col-md-6');
                     $('#currentMonthConvert').addClass('col-md-12');
                }
                
                $('#prevConverted').text(prev.converted_total ?? '0');
                $('#prevSecondPay').text(prev.second_payment_total ?? '0');
                $('#prevDrop').text(prev.drop_count_total ?? '0');
                $('#prevLmbc').text(prev.lmbc_total ?? '0');
                
                $('#currConverted').text(curr.converted_total_current ?? '0');
                 $('#minusConverted').text(curr.minus_value ?? '0');
                  $('#finalConverted').text(curr.final_value ?? '0');
                $('#currDrop').text(curr.drop_count_current ?? '0');
                $('#currLmbc').text(curr.lmbc_total_current ?? '0');
                // Previous Month Data
               if (response.data_prev && response.data_prev.length > 0) {
                    let prevRows = '';
                    response.data_prev.forEach(item => {
                        prevRows += `<tr>
                            <td class="text-black fw-bold fs-5">${item.customer_name}<br><small class="text-black fw-semibold">${item.mobile}</small><br><span class="fs-8 text-primary ">${item.proposalId}</span></td>
                            <td class="${item.reason === 'Successfully Paid MPC And Second Payment' ? 'bg-success text-white fw-bold' : 'bg-danger text-white fw-bold'}">
                                ${item.reason ?? '-'}
                            </td>
                        </tr>`;
                    });
                    $("#actualDetailsBody").html(prevRows);
                } else {
                    $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No previous month records.</td></tr>');
                }
    
                // Current Month Data
                if (response.data_current && response.data_current.length > 0) {
                    let currRows = '';
                    response.data_current.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div class="d-flex gap-1 align-items-start">
                                    <div>
                                        <div ><span class="text-black fw-bold fs-5">${item.customer_name}</span></div>
                                        <div>
                                          <small class="fs-7 text-black fw-semibold">${item.mobile}</small>
                                       </div>
                                       <div class="fs-8 text-primary text-nowrap">${item.proposalId}</div>
                                    </div>
                                   <div class="align-self-center">
                                   ${item.currencyId != 70 ?
                                      ` <span class="badge bg-warning text-black fs-6 "> ${item.currencySymbol} ${item.amount}</span>`
                                      :
                                      ` <span class="badge bg-info text-white fs-6 "> ${item.currencySymbol} ${item.amount}</span>`
                                      }
                                   </div>
                               </div>
                            </td>
                            <td class="${item.reason === 'Successfully Paid MPC Value' ? 'bg-success text-white fw-bold' : 'bg-danger text-white fw-bold'}">
                                ${item.reason ?? '-'}
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBody").html(currRows);
                } else {
                    $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsModal'));
        modal.show();
    }

    function openActualCalculationModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        $('#calculationDetailsBody').html('<tr><td colspan="6">Loading...</td></tr>');
        $('#calculationDetailsModal').modal('show');
    
        fetch(`/incentives/pi-calculation?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if (res.data && res.data.length > 0) {
                    
                     let staff = res.data[0];
    
                    // Staff details
                    $('#piStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#piStaffName').text(staff.staff_name);
                    $('#piStaffDept').text(staff.department_name);
                    
                    let rows = '';
                    let totalAmount = 0;
        
                    res.data.forEach(item => {
                        const numericProfit = parseFloat(item.profit_loss_amount.replace('+', '').replace(',', ''));
                        const profitClass = numericProfit >= 0 ? 'bg-success text-white' : 'bg-danger text-white';
        
                        rows += `<tr>
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.customer_name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.month}</td>
                            <td>${item.course_name}</td>
                            <td>₹${item.original_amount}</td>
                            <td>₹${item.confirm_amount}</td>
                            <td class="${profitClass} fw-bold"><span class="badge bg-label-secondary fw-bold fs-3">₹${item.profit_loss_amount}</span></td>
                        </tr>`;
        
                        totalAmount += numericProfit;
                    });
        
                    $('#calculationDetailsBody').html(rows);
        
                    // Sticky footer row
                    const footer = `
                        <td colspan="6" class="text-end">Total Profit/Loss</td>
                        <td class="${totalAmount >= 0 ? 'bg-success text-white' : 'bg-danger text-white'}"><span class="badge bg-label-secondary fw-bold fs-3">₹${totalAmount.toFixed(2)}</span></td>
                    `;
                    $('#calculationDetailsFooter').html(footer);
                } else {
                    $('#calculationDetailsBody').html('<tr><td colspan="6">No data found.</td></tr>');
                    $('#calculationDetailsFooter').html('');
                }
            });
    }
    
    function openActualECIDetailsModal(staffId) {
        console.log('Opening modal...');
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let branch_id = $("#branchSelectsgoal").val();
        
           
            const modal = new bootstrap.Modal(document.getElementById('eciDetailsModal'));
            modal.show();
        
            $('#eciDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
            $('#eciDetailsFooter').html('');
        
            fetch(`/incentives/eci-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
                .then(res => res.json())
                .then(res => {
                    if(res.staff){
                        let staff = res.staff;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                        
                        if (staff.staff_image) {
                                $('#eciStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                                $('#eciStaffIntialImage').addClass('d-none');
                            } else {
                                // Show initial instead of image
                                // alert('no image')
                                let initial = staffName.charAt(0).toUpperCase();
                                // alert(initial)
                                $('#eciStaffIntialImage').text(initial).removeClass('d-none');
                                $('#eciStaffImage').addClass('d-none');
                            }

                        // Set staff details at top
                        // $('#eciStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                        $('#eciStaffName').text(staff.staff_name);
                        $('#eciStaffDept').text(staff.department_name);
                    }else{
                          $('#eciStaffImage').attr('src', '');
                            $('#eciStaffName').text('Staff Name');
                            $('#eciStaffDept').text('Department');
                    }
                    if (res.data && res.data.length > 0) {

                        let rows = '';
                        res.data.forEach(item => {
                           let badgeClass = item.status === 'Converted' ? 'bg-success' : 'bg-danger';
                            rows += `<tr>
                                <td>${item.sno}</td>
                                <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                                <td>${item.course}</td>
                                <td>${item.created_at}</td>
                                <td><span class="badge ${badgeClass}">${item.status}</span></td>
                            </tr>`;
                        });
        
                        $('#eciDetailsBody').html(rows);
        
                        // Optionally: Footer total
                        $('#eciDetailsFooter').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                    } else {
                        $('#eciDetailsBody').html('<tr><td colspan="5">No data found.</td></tr>');
                    }
                })
                .catch(err => {
                    console.error(err);
                    $('#eciDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
                });
    }
    
     // cre 10x details
   
    
    function openManageCallModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        const modal = new bootstrap.Modal(document.getElementById('callDetailsModal'));
        modal.show();
    
        $('#callDetailsBody').html('<tr><td colspan="7">Loading...</td></tr>');
        $('#callDetailsFooter').html('');
    
        fetch(`/incentives/call-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(response => response.json())
            .then(response => {
                console.log('API Response:', response); // Debug
    
                if (response.data && response.data.length > 0) {
                    let staff = response.data[0];
    
                    // Staff details
                    $('#callStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#callStaffName').text(staff.staff_name);
                    $('#callStaffDept').text(staff.department_name);
    
                    let rows = '';
                    let grandTotalReward = 0;

                    response.data.forEach(item => {
                        // Sum up the rewards
                        grandTotalReward += item.Rewards ?? 0;
                        rows += `
                            <tr>
                              <td>${item.sno}</td>
                              <td><b>${item.name}</b><br><small>${item.mobile}</small></td>
                              <td>${item.created_at}</td>
                              <td>${item.on_day}</td>
                              <td>${item.on_month}</td>
                              <td>${item.old_month} ${item.otherstaff ? '<i class="mdi mdi-cellphone-off text-success"></i>' : ''}</td>
                              <td class="fw-bold fs-4 bg-${item.Rewards > 0 ? 'success' : 'danger'}"><span class="badge bg-label-secondary fw-bold  fs-2">${item.Rewards}</span></td>
                            </tr>
                        `;
                    });
    
                    $('#callDetailsBody').html(rows);
    
                    // correct footer rendering
                    $('#callDetailsFooter').html(`
                        <td colspan="4" class="text-start fw-bold text-primary fs-4">Total Records: ${response.data.length}</td>
                        <td colspan="3" class="text-end fw-bold text-primary fs-4">Grand Total Reward: ₹${grandTotalReward}</td>
                    `);
                } else {
                    $('#callStaffImage').attr('src', '');
                    $('#callStaffName').text('Staff Name');
                    $('#callStaffDept').text('Department');
                    $('#callDetailsBody').html('<tr><td colspan="7">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error('Fetch error:', err);
                $('#callDetailsBody').html('<tr><td colspan="7">Something went wrong.</td></tr>');
            });
    }
    
    function openActualCollectionModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#OldDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#CurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-Collection-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
               if (response.staff) {
                    const staff = response.staff;
                    $('#CollectionStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#CollectionStaffName').text(staff.staff_name);
                    $('#CollectionStaffDept').text(staff.department_name);
                }
            
                
               // Populate Collection Amount and Percentage Summary
                $('#oldAmount').text(response.old_amount?.collection ?? '0');
                $('#oldPercentage').text(response.old_amount?.percentage ?? '0');
                
                $('#currentAmount').text(response.current_amount?.collection ?? '0');
                $('#currentPercentage').text(response.current_amount?.percentage ?? '0');
                
                $('#futureAmount').text(response.future_amount?.collection ?? '0');
                $('#futurePercentage').text(response.future_amount?.percentage ?? '0');
                // Previous Month Data
                if (response.old_amount && response.old_amount.customers?.length > 0) {
                    let prevRows = '';
                    response.old_amount.customers.forEach(item => {
                        prevRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-danger text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#OldDetailsBody").html(prevRows);
                } else {
                    $("#OldDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No previous month records.</td></tr>');
                }
    
                // Current Month Data
                if (response.current_amount && response.current_amount.customers?.length > 0) {
                    let currRows = '';
                    response.current_amount.customers.forEach(item => {
                        currRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-success text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#CurrentDetailsBody").html(currRows);
                } else {
                    $("#CurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
                
                if (response.future_amount && response.future_amount.customers?.length > 0) {
                    let futurRows = '';
                    response.future_amount.customers.forEach(item => {
                        futurRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                            <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-info text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#FutureDetailsBody").html(futurRows);
                } else {
                    $("#FutureDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualDetailsCollectionModal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                $("#FutureDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsCollectionModal'));
        modal.show();
    }
    
    


   
    
</script>
    <style>
   

    .reward-frame {
      font-size: 1.3rem;
      font-weight: bold;
      padding: 8px 16px;
      border-radius: 12px;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
      animation: glow 1.5s infinite alternate;
    }
    
    .reward-frame.gold {
      background: linear-gradient(to right, #ffd700, #ffac33);
      color: #000;
      box-shadow: 0 0 12px #ffd700;
    }
    
    .reward-frame.silver {
      background: linear-gradient(to right, #c0c0c0, #aaaaaa);
      color: #000;
      box-shadow: 0 0 10px #c0c0c0;
    }
    
    .reward-frame.bronze {
      background: linear-gradient(to right, #cd7f32, #b87333);
      color: #fff;
      box-shadow: 0 0 8px #cd7f32;
    }
    
    .reward-frame.fail {
      background-color: #dc3545;
      color: #fff;
      box-shadow: none;
      animation: none;
    }
    
    @keyframes glow {
      from {
        transform: scale(1);
        box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
      }
      to {
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(255, 215, 0, 0.9);
      }
    }


    .accordion-button.collapsed .rotate-icon {
        transform: rotate(0deg);
        transition: transform 0.3s ease;
    }
    .accordion-button:not(.collapsed) .rotate-icon {
        transform: rotate(180deg);
        transition: transform 0.3s ease;
    }
    #actualDetailsBody td {
        vertical-align: middle;
        height: 60px;
    }
    .badge-hover-clickable {
        transition: all 0.2s ease;
        border: 2px solid transparent;
    }
    
    .badge-hover-clickable:hover {
        border: 2px solid #0d6efd; /* Bootstrap primary */
        background-color: #e0f2ff; /* light blue */
        box-shadow: 0 0 8px rgba(13, 110, 253, 0.2); /* subtle glow */
        transform: scale(1.03);
        cursor: pointer;
    }
    
    

</style>
<!--Create Dashboards Accordion Start-->
<script>
    'use strict';
    (function() {
        const sgr1 = [].slice.call(document.querySelectorAll('.sgr1'));
        // Collapsible card
        // --------------------------------------------------------------------
        if (sgr1) {
            sgr1.map(function(sgr1_Element) {
                sgr1_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(sgr1_Element.closest('.card').querySelector('.collapse.sgr1_body'));
                    // Toggle collapsed class in `.card-header` element
                    sgr1_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(sgr1_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Create Dashboards Accordion End-->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    // Journal Executive
    function openActualJournalDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournal').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournal').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournal').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournal').addClass('d-none');
                    }
                     $('#actualStaffNameJournal').text(staffName);
                    $('#actualStaffDeptJournal').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                                <div>
                                    <span class="text-primary fw-semibold fs-7">${item.cus_name}</span>
                                </div>
                                <div>
                                    <span class="text-info text-nowrap fw-semibold fs-8">${item.cus_id}</span>
                                </div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                            <td class="">
                                ${item.paper_status == 8 ? `
                                    <div class="mb-1"><span class=" badge bg-success text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">${item.publish_date ?? '-'}</span></div>
                                ` :''}
                                <div class="mb-1"><span class=" text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'Accepted Date">${item.accept_date}</span></div>
                                <div><span class="my-1 badge bg-${item.paper_status == 5 ? 'warning':(item.paper_status == 7 ? 'primary' :'info')} text-black fw-bold fs-7 text-nowrap" >${item.paper_status == 8 ? 'Published':(item.paper_status == 5 ? 'Accepted' : 'E-Proofing')}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournal").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalDetailsModal'));
        modal.show();
    }

    function openActualExtraJournalDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');

        $.ajax({
            url: `/get-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournalExt').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournalExt').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournalExt').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournalExt').addClass('d-none');
                    }
                     $('#actualStaffNameJournalExt').text(staffName);
                    $('#actualStaffDeptJournalExt').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        let badgeClass = item.status === 'Eligible' ? 'bg-success' : 'bg-danger';
                        currRows += `<tr class="">
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                            <td class="${badgeClass}">
                               ${item.paper_status == 8 ? `
                                    <div class="mb-1"><span class=" badge bg-success text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">${item.publish_date ?? '-'}</span></div>
                                ` :''}
                                <div class="mb-1"><span class=" text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'Accepted Date">${item.accept_date}</span></div>
                                <div><span class="my-1 badge bg-${item.paper_status == 5 ? 'warning':(item.paper_status == 7 ? 'primary' :'info')} text-black fw-bold fs-7 text-nowrap" >${item.paper_status == 8 ? 'Published':(item.paper_status == 5 ? 'Accepted' : 'E-Proofing')}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournalExt").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalExtDetailsModal'));
        modal.show();
    }

    function openActualDoubleXJournalDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournalDoubleX").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournalDoubleX').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournalDoubleX').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournalDoubleX').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournalDoubleX').addClass('d-none');
                    }
                    $('#actualStaffNameJournalDoubleX').text(staffName);
                    $('#actualStaffDeptJournalDoubleX').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                                <div>
                                    <span class="text-primary fw-semibold fs-7">${item.cus_name}</span>
                                </div>
                                <div>
                                    <span class="text-info text-nowrap fw-semibold fs-8">${item.cus_id}</span>
                                </div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                           <td class="">
                               ${item.paper_status == 8 ? `
                                    <div class="mb-1"><span class=" badge bg-success text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">${item.publish_date ?? '-'}</span></div>
                                ` :''}
                                <div class="mb-1"><span class=" text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'Accepted Date">${item.accept_date}</span></div>
                                <div><span class="my-1 badge bg-${item.paper_status == 5 ? 'warning':(item.paper_status == 7 ? 'primary' :'info')} text-black fw-bold fs-7 text-nowrap" >${item.paper_status == 8 ? 'Published':(item.paper_status == 5 ? 'Accepted' : 'E-Proofing')}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournalDoubleX").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournalDoubleX").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournalDoubleX").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalDetailsModalDoubleX'));
        modal.show();
    }

   
    function openPerformAttendanceModal(staffId) {

        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        const modal = new bootstrap.Modal(document.getElementById('performanceJournalExeDetails'));
        modal.show();

        $('#performJournalExeDetailsBody').html('<tr><td colspan="3">Loading...</td></tr>');

        fetch(`/incentives/performance-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
        .then(response => response.json())
        .then(response => {

            let staffImage = response.StaffData.staff_image;
            let staffName = response.StaffData.staff_name || 'No Name Provided';
            let departmentName = response.StaffData.department_name || '';

            if (staffImage) {
                $('#performJournalExeStaffImage')
                    .attr('src', `/staff_images/${staffImage}`)
                    .removeClass('d-none');

                $('#performJournalExeStaffInitialImage').addClass('d-none');
            } else {

                let initial = staffName.charAt(0).toUpperCase();

                $('#performJournalExeStaffInitialImage')
                    .text(initial)
                    .removeClass('d-none');

                $('#performJournalExeStaffImage').addClass('d-none');
            }

            $('#performJournalExeStaffName').text(staffName);
            $('#performJournalExeStaffDept').text(departmentName);

            let rows = '';

            response.days.forEach(item => {

                let badge = '';

                switch(item.attendance){
                    case 'P':
                        badge = `<span class="badge bg-success">Present</span>`;
                        break;

                    case 'A':
                        badge = `<span class="badge bg-danger">Absent</span>`;
                        break;

                    case 'L':
                        badge = `<span class="badge bg-warning">Leave</span>`;
                        break;

                    case 'PR':
                        badge = `<span class="badge bg-info">Permission</span>`;
                        break;

                    case 'OD':
                        badge = `<span class="badge bg-primary">On Duty</span>`;
                        break;

                    case 'Weekend':
                        badge = `<span class="badge bg-dark">Weekend</span>`;
                        break;

                    case 'Holiday':
                        badge = `<span class="badge bg-secondary">Holiday</span>`;
                        break;

                    default:
                        badge = `<span class="badge bg-light text-dark">-</span>`;
                }

                rows += `
                <tr>
                    <td>${item.date}</td>
                    <td>${item.day}</td>
                    <td>${badge}</td>
                </tr>
                `;
            });

            $('#performJournalExeDetailsBody').html(rows);

            $('#performJournalExeDetailsFooter').html(`
                <td colspan="2">Total Days: ${response.summary.working_days}</td>
                <td class="fw-bold text-success">Present: ${response.summary.present_days}</td>
            `);

            $('#actualAttendanceRate')
                .removeClass('bg-danger bg-success')
                .addClass(response.summary.attendance_percentage >= 80 ? 'bg-success' : 'bg-danger')
                .text(response.summary.attendance_percentage + '%');

        })
        .catch(err => {

            console.error(err);

            $('#performJournalExeDetailsBody').html(
                '<tr><td colspan="3">Something went wrong.</td></tr>'
            );

        });
    }
</script>
<script>
    function openPerformCallModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        const modal = new bootstrap.Modal(document.getElementById('performanceSalesDetails'));
        modal.show();
    
        $('#performcallDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#performcallDetailsFooter').html('');
    
        fetch(`/incentives/performance-call-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(response => response.json())
            .then(response => {
                console.log('API Response:', response); // Debug

                  let staffImage = response.StaffData.staff_image;
                  let staffName = response.StaffData.staff_name || 'No Name Provided';
                  let departmentName = response.StaffData.department_name || '';

                     let rows = '';
                    let totalOutgoing = 0;
                    let totalMissed = 0;
                  if (staffImage) {
                        $('#performcallStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#performcallStaffInitialImage').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#performcallStaffInitialImage').text(initial).removeClass('d-none');
                        $('#performcallStaffImage').addClass('d-none');
                    }
                     $('#performcallStaffName').text(staffName);
                    $('#performcallStaffDept').text(departmentName);
    
                response.days.forEach(item => {
                    totalOutgoing += item.outgoing;
                    totalMissed += item.missed;

                    rows += `
                        <tr>
                            <td>${item.date}</td>
                            <td>${item.day}</td>
                            <td class="fw-bold text-success">${item.outgoing}</td>
                            <td>${item.incoming}</td>
                            <td class="fw-bold text-danger">${item.missed}</td>
                        </tr>
                    `;
                });
                $('#performcallDetailsBody').html(rows);

                $('#performcallDetailsFooter').html(`
                    <td colspan="2">Total Days: ${response.summary.working_days}</td>
                    <td class="text-success">Total: ${totalOutgoing}</td>
                    <td></td>
                    <td class="text-danger">Total: ${totalMissed}</td>
                `);

                $('#actualOutgoingPerDay').text(
                    response.summary.actual_outgoing_per_day
                );

                $('#actualMissedCallRate').text(
                    response.summary.actual_missed_call_rate + '%'
                );

               

                // if (response.summary.actual_missed_call_rate <= targetMissedRate) {
                //     $('#actualMissedCallRate').removeClass('bg-danger').addClass('bg-success');
                // }
            })
            .catch(err => {
                console.error('Fetch error:', err);
                $('#performcallDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }
</script>
<!-- CRe Details -->
<script>
    function openCollection10xActualDetailsModal(staffId) {
        console.log('Opening modal...');
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let branch_id = $("#branchSelectsgoal").val();
        
           
            const modal = new bootstrap.Modal(document.getElementById('creAwardDetailsModal'));
            modal.show();
        
            $('#eciCreDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
            $('#eciCreDetailsFooter').html('');
        
                fetch(`/incentives/cre-10x-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
                .then(res => res.json())
                .then(res => {
                    if(res.staff){
                        let staff = res.staff;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                        
                        if (staff.staff_image) {
                                $('#eciCreStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                                $('#eciCreStaffIntialImage').addClass('d-none');
                            } else {
                                // Show initial instead of image
                                // alert('no image')
                                let initial = staffName.charAt(0).toUpperCase();
                                // alert(initial)
                                $('#eciCreStaffIntialImage').text(initial).removeClass('d-none');
                                $('#eciCreStaffImage').addClass('d-none');
                            }

                        // Set staff details at top
                        // $('#eciStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                        $('#eciCreStaffName').text(staff.staff_name);
                        $('#eciCreStaffDept').text(staff.department_name);
                    }else{
                          $('#eciCreStaffImage').attr('src', '');
                            $('#eciCreStaffName').text('Staff Name');
                            $('#eciCreStaffDept').text('Department');
                    }

                    $('#creTotalHarvest').text(res.harvesting_amount ?'₹ '+res.harvesting_amount : '₹0');
                    $('#creBalance').text(res.balance_amount?'₹ '+res.balance_amount : '₹0');
                    $('#creCollection').text(res.collection_amount ? '₹ '+res.collection_amount : '₹0');
                    $('#creCollectionAmount').text(res.collection_amount?'₹ '+res.collection_amount : '₹0');
                    $('#creTotalAmount').text(res.harvesting_amount ? '₹ '+res.harvesting_amount : '₹0');
                    $('#finalCreCollectionPercentage').text(res.harvestingPercentage +'%' ?? '0%');

                    if (res.data && res.data.length > 0) {

                        let rows = '';
                        res.data.forEach(item => {
                           let badgeClassCurrency = item.currency_code === 'INR' ? 'bg-secondary text-white' : 'bg-warning text-black';
                            rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                                <td>${item.sno}</td>
                                <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                                <td>${item.course}</td>
                                <td>
                                    <span class="text-nowrap">${item.miletone_date} </span>
                                    <div class="text-center">
                                        <span class="fs-8 badge ${badgeClassCurrency}">${item.currency_code}</span>
                                    </div>
                                </td>
                                <td>
                                <span class="badge  ${item.payment_status == 0 ? 'bg-warning text-white':'bg-success'}">₹ ${item.net_amount}</span>
                                    <span class="text-nowrap d-block">${item.payment_status == 0 ? '-':item.created_at } </span>
                                </td>
                            </tr>`;
                        });
        
                        $('#eciCreDetailsBody').html(rows);
        
                        // Optionally: Footer total
                        $('#eciCreDetailsFooter').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                    } else {
                        $('#eciCreDetailsBody').html('<tr><td colspan="5">No data found.</td></tr>');
                    }
                })
                .catch(err => {
                    console.error(err);
                    $('#eciCreDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
                });
    }
    function openActualCreECIDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('eciCreDetailsModal'));
        modal.show();
    
        $('#eciDetailsBodyCre').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#eciDetailsFooterCre').html('');
    
        fetch(`/incentives/cre-eci-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if(res.staff){
                    let staff = res.staff;
                    
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name Provided';
                    
                    if (staff.staff_image) {
                            $('#eciStaffImageCre').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                            $('#eciStaffIntialImageCre').addClass('d-none');
                        } else {
                            // Show initial instead of image
                            // alert('no image')
                            let initial = staffName.charAt(0).toUpperCase();
                            // alert(initial)
                            $('#eciStaffIntialImageCre').text(initial).removeClass('d-none');
                            $('#eciStaffImageCre').addClass('d-none');
                        }

                    // Set staff details at top
                    // $('#eciStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#eciStaffNameCre').text(staff.staff_name);
                    $('#eciStaffDeptCre').text(staff.department_name);
                }else{
                        $('#eciStaffImageCre').attr('src', '');
                        $('#eciStaffNameCre').text('Staff Name');
                        $('#eciStaffDeptCre').text('Department');
                }
                if (res.data && res.data.length > 0) {

                    let rows = '';
                    res.data.forEach(item => {
                        let badgeClassCurrency = item.currency_code === 'INR' ? 'bg-secondary text-white' : 'bg-warning text-black';
                        let badgeClass = item.status === 'Eligible' ? 'bg-success' : 'bg-danger';
                        rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.course}</td>
                            <td>
                                <span class="text-nowrap">${item.miletone_date} </span>
                                <div class="text-center">
                                    <span class="fs-8 badge ${badgeClassCurrency}">${item.currency_code}</span>
                                </div>
                            </td>
                            <td class="${badgeClass}">
                                <span class="badge  bg-warning text-white ">₹ ${item.net_amount}</span>
                                <span class="text-nowrap d-block">${item.payment_status == 0 ? '-':item.created_at } </span>
                            </td>
                        </tr>`;
                    });
    
                    $('#eciDetailsBodyCre').html(rows);
    
                    // Optionally: Footer total
                    $('#creEciTotalHarvest').text(res.harvesting_amount ?'₹ '+res.harvesting_amount : '₹0');
                    $('#creEciBalance').text(res.totalEligibleAmount?'₹ '+res.totalEligibleAmount : '₹0');
                    $('#creEciCollectionAmount').text(res.totalEligibleAmount?'₹ '+res.totalEligibleAmount : '₹0');
                    $('#creEciTotalAmount').text(res.harvesting_amount ? '₹ '+res.harvesting_amount : '₹0');
                    $('#finalCreEciCollectionPercentage').text(res.eciPercentage +'%' ?? '0%');
                    $('#eciDetailsFooterCre').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                } else {
                    $('#eciDetailsBodyCre').html('<tr><td colspan="5">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#eciDetailsBodyCre').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }

    function openActualCollectionSpotDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('spotCreDetailsModal'));
        modal.show();
    
        $('#spotDetailsBodyCre').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#spotDetailsFooterCre').html('');
    
        fetch(`/incentives/cre-spot-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if(res.staff){
                    let staff = res.staff;
                    
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name Provided';
                    
                    if (staff.staff_image) {
                            $('#spotStaffImageCre').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                            $('#spotStaffIntialImageCre').addClass('d-none');
                        } else {
                            // Show initial instead of image
                            // alert('no image')
                            let initial = staffName.charAt(0).toUpperCase();
                            // alert(initial)
                            $('#spotStaffIntialImageCre').text(initial).removeClass('d-none');
                            $('#spotStaffImageCre').addClass('d-none');
                        }

                    // Set staff details at top
                    // $('#spotStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#spotStaffNameCre').text(staff.staff_name);
                    $('#spotStaffDeptCre').text(staff.department_name);
                }else{
                        $('#spotStaffImageCre').attr('src', '');
                        $('#spotStaffNameCre').text('Staff Name');
                        $('#spotStaffDeptCre').text('Department');
                }
                if (res.data && res.data.length > 0) {

                    let rows = '';
                    res.data.forEach(item => {
                        let badgeClassCurrency = item.currency_code === 'INR' ? 'bg-secondary text-white' : 'bg-warning text-black';
                        let badgeClass = item.status === 'Eligible' ? 'bg-success' : 'bg-danger';
                        rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.course}</td>
                            <td>
                                <span class="text-nowrap">${item.miletone_date} </span>
                                <div class="text-center">
                                    <span class="fs-8 badge ${badgeClassCurrency}">${item.currency_code}</span>
                                </div>
                            </td>
                            <td class="${badgeClass}">
                                <span class="badge  bg-warning text-white ">₹ ${item.net_amount}</span>
                                <span class="text-nowrap d-block">${item.payment_status == 0 ? '-':item.created_at } </span>
                            </td>
                        </tr>`;
                    });
    
                    $('#spotDetailsBodyCre').html(rows);
    
                    // Optionally: Footer total
                    $('#crespotTotalHarvest').text(res.collection_amount ?'₹ '+res.collection_amount : '₹0');
                    $('#crespotBalance').text(res.totalEligibleAmount?'₹ '+res.totalEligibleAmount : '₹0');
                    $('#crespotCollectionAmount').text(res.totalEligibleAmount?'₹ '+res.totalEligibleAmount : '₹0');
                    $('#crespotTotalAmount').text(res.collection_amount ? '₹ '+res.collection_amount : '₹0');
                    $('#finalCrespotCollectionPercentage').text(res.spotPercentage +'%' ?? '0%');
                    $('#spotDetailsFooterCre').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                } else {
                    $('#spotDetailsBodyCre').html('<tr><td colspan="5">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#spotDetailsBodyCre').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }

    function openActualcollectionBonusDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('bonusCreDetailsModal'));
        modal.show();
    
        $('#bonusDetailsBodyCre').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#bonusDetailsFooterCre').html('');
    
        fetch(`/incentives/cre-bonus-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if(res.staff){
                    let staff = res.staff;
                    
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name Provided';
                    
                    if (staff.staff_image) {
                            $('#bonusStaffImageCre').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                            $('#bonusStaffIntialImageCre').addClass('d-none');
                        } else {
                            // Show initial instead of image
                            // alert('no image')
                            let initial = staffName.charAt(0).toUpperCase();
                            // alert(initial)
                            $('#bonusStaffIntialImageCre').text(initial).removeClass('d-none');
                            $('#bonusStaffImageCre').addClass('d-none');
                        }

                    // Set staff details at top
                    // $('#bonusStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#bonusStaffNameCre').text(staff.staff_name);
                    $('#bonusStaffDeptCre').text(staff.department_name);
                }else{
                        $('#bonusStaffImageCre').attr('src', '');
                        $('#bonusStaffNameCre').text('Staff Name');
                        $('#bonusStaffDeptCre').text('Department');
                }
                if (res.data && res.data.length > 0) {

                    let rows = '';
                    res.data.forEach(item => {
                        let badgeClassCurrency = item.currency_code === 'INR' ? 'bg-secondary text-white' : 'bg-warning text-black';
                        let badgeClass = item.status === 'Eligible' ? 'bg-success' : 'bg-danger';
                        rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.course}</td>
                            <td>
                                <span class="text-nowrap">${item.miletone_date} </span>
                                <div class="text-center">
                                    <span class="fs-8 badge ${badgeClassCurrency}">${item.currency_code}</span>
                                </div>
                            </td>
                            <td class="${badgeClass}">
                                <span class="badge  bg-warning text-white ">₹ ${item.net_amount}</span>
                                <span class="text-nowrap d-block">${item.payment_status == 0 ? '-':item.created_at } </span>
                            </td>
                        </tr>`;
                    });
    
                    $('#bonusDetailsBodyCre').html(rows);
    
                    // Optionally: Footer total
                    $('#collectionBonusTotalHarvest').text(res.harvesting_amount ?'₹ '+res.harvesting_amount : '₹0');
                    $('#collectionBonusBalance').text(res.balance_amount?'₹ '+res.balance_amount : '₹0');
                    $('#collectionBonusCollected').text(res.collection_amount ? '₹ '+res.collection_amount : '₹0');
                    $('#collectionBonusAmount').text(res.collection_amount?'₹ '+res.collection_amount : '₹0');
                    $('#collectionBonusTotalAmount').text(res.harvesting_amount ? '₹ '+res.harvesting_amount : '₹0');
                    $('#finalcollectionBonusPercentage').text(res.harvestingPercentage +'%' ?? '0%');

                    // $('#crebonusCollectionAmount').text(res.totalEligibleAmount?'₹ '+res.totalEligibleAmount : '₹0');
                    // $('#crebonusTotalAmount').text(res.collection_amount ? '₹ '+res.collection_amount : '₹0');
                    // $('#finalCrebonusCollectionPercentage').text(res.bonusPercentage +'%' ?? '0%');
                    $('#bonusDetailsFooterCre').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                } else {
                    $('#bonusDetailsBodyCre').html('<tr><td colspan="5">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#bonusDetailsBodyCre').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }

    function openActualCollectionRefrlDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('referralCollectDetailsModal'));
        modal.show();
    
        $('#referralDetailsBodyCollect').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#referralDetailsFooterCollect').html('');
    
        fetch(`/incentives/collection-referral-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if(res.staff){
                    let staff = res.staff;
                    
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name Provided';
                    
                    if (staff.staff_image) {
                            $('#referralStaffImageCollect').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                            $('#referralStaffIntialImageCollect').addClass('d-none');
                        } else {
                            // Show initial instead of image
                            // alert('no image')
                            let initial = staffName.charAt(0).toUpperCase();
                            // alert(initial)
                            $('#referralStaffIntialImageCollect').text(initial).removeClass('d-none');
                            $('#referralStaffImageCollect').addClass('d-none');
                        }

                    // Set staff details at top
                    // $('#referralStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#referralStaffNameCollect').text(staff.staff_name);
                    $('#referralStaffDeptCollect').text(staff.department_name);
                }else{
                        $('#referralStaffImageCollect').attr('src', '');
                        $('#referralStaffNameCollect').text('Staff Name');
                        $('#referralStaffDeptCollect').text('Department');
                }
                if (res.data && res.data.length > 0) {

                    let rows = '';
                    res.data.forEach(item => {
                        rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.course}</td>
                            <td>
                                <span class="text-nowrap">${item.created_at} </span>
                            </td>
                        </tr>`;
                    });
    
                    $('#referralDetailsBodyCollect').html(rows);
    
                    // Optionally: Footer total
                   
                    $('#referralDetailsFooterCollect').html(`<td colspan="4">Total Records: ${res.data.length}</td>`);
                } else {
                    $('#referralDetailsBodyCollect').html('<tr><td colspan="4">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#referralDetailsBodyCre').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }
    function openActualCreRefrlDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('referralCreDetailsModal'));
        modal.show();
    
        $('#referralDetailsBodyCre').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#referralDetailsFooterCre').html('');
    
        fetch(`/incentives/cre-referral-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if(res.staff){
                    let staff = res.staff;
                    
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name Provided';
                    
                    if (staff.staff_image) {
                            $('#referralStaffImageCre').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                            $('#referralStaffIntialImageCre').addClass('d-none');
                        } else {
                            // Show initial instead of image
                            // alert('no image')
                            let initial = staffName.charAt(0).toUpperCase();
                            // alert(initial)
                            $('#referralStaffIntialImageCre').text(initial).removeClass('d-none');
                            $('#referralStaffImageCre').addClass('d-none');
                        }

                    // Set staff details at top
                    // $('#referralStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#referralStaffNameCre').text(staff.staff_name);
                    $('#referralStaffDeptCre').text(staff.department_name);
                }else{
                        $('#referralStaffImageCre').attr('src', '');
                        $('#referralStaffNameCre').text('Staff Name');
                        $('#referralStaffDeptCre').text('Department');
                }
                if (res.data && res.data.length > 0) {

                    let rows = '';
                    res.data.forEach(item => {
                        rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.course}</td>
                            <td>
                                <span class="text-nowrap">${item.created_at} </span>
                            </td>
                        </tr>`;
                    });
    
                    $('#referralDetailsBodyCre').html(rows);
    
                    // Optionally: Footer total
                   
                    $('#referralDetailsFooterCre').html(`<td colspan="4">Total Records: ${res.data.length}</td>`);
                } else {
                    $('#referralDetailsBodyCre').html('<tr><td colspan="4">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error(err);
                $('#spotDetailsBodyCre').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }

    function openActualProductionDetailsModal(staffId) {
    
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        
        const modal = new bootstrap.Modal(document.getElementById('productionDetailsModal'));
        modal.show();
    
        $('#productionDetailsBody').html(`
            <tr>
                <td colspan="5" class="text-center text-muted">
                   <div class="spinner-border text-primary"></div>
                </td>
            </tr>
        `);
        $('#production_summary').html(`
            <div class="text-center p-5">
                <div class="spinner-border text-primary"></div>
            </div>
        `);
       
        fetch(`/incentives/production-details?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                    if(res.staff){
                        let staff = res.staff;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                        
                            if (staff.staff_image) {
                                $('#productionStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                                $('#productionStaffIntialImage').addClass('d-none');
                            } else {
                                // Show initial instead of image
                                // alert('no image')
                                let initial = staffName.charAt(0).toUpperCase();
                                // alert(initial)
                                $('#productionStaffIntialImage').text(initial).removeClass('d-none');
                                $('#productionStaffImage').addClass('d-none');
                            }

                        // Set staff details at top
                        // $('#productionStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                        $('#productionStaffName').text(staff.staff_name);
                        $('#productionStaffDept').text(staff.department_name);
                    }else{
                            $('#productionStaffImage').attr('src', '');
                            $('#productionStaffName').text('Staff Name');
                            $('#productionStaffDept').text('Department');
                    }

                    let summary = res.summary;

                    // Badge colors
                    let savingClass = 'secondary';
                    if (summary.saving_hours > 0) savingClass = 'success';
                    if (summary.saving_hours < 0) savingClass = 'danger';

                    let htmlDashbord = `
                    <div class="row mb-4 text-center">
                        <div class="col-md-4">
                            <div class="card shadow-sm border-0">
                                <div class="card-body">
                                    <h6 class="text-muted">Worked Hours</h6>
                                    <h3>${summary.worked_hours} hrs</h3>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card shadow-sm border-0">
                                <div class="card-body">
                                    <h6 class="text-muted">Saving Hours</h6>
                                    <h3 class="text-${savingClass}">
                                        ${summary.saving_hours} hrs
                                    </h3>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card shadow-sm border-0 bg-light">
                                <div class="card-body">
                                    <h6 class="text-muted">Adjusted Total</h6>
                                    <h3>${summary.adjusted_hours} hrs</h3>
                                </div>
                            </div>
                        </div>
                    </div>`

                    $('#production_summary').html(htmlDashbord);
                if (res.data && res.data.length > 0) {
                    
                    let rows = '';

                    res.data.forEach(item => {

                        // Convert safely to numbers
                        let plannedHours = parseFloat(item.task_hours ?? 0);
                        let actualSeconds = parseFloat(item.actual_seconds ?? 0);

                        let actualHours = actualSeconds / 3600;
                        let saving = plannedHours - actualHours;

                        // Format after calculation
                        actualHours = actualHours.toFixed(2);
                        saving = saving.toFixed(2);

                        // Badge color
                        let badgeClass = 'secondary';
                        if (parseFloat(saving) > 0) badgeClass = 'success';
                        if (parseFloat(saving) < 0) badgeClass = 'danger';
                        console.log(badgeClass)
                        let statusBadge = item.status >= 4
                            ? '<span class="badge bg-success">Completed</span>'
                            : '<span class="badge bg-warning">Pending</span>';

                        rows += `
                            <tr>
                                <td>
                                <span class="text-black fs-7 fw-bold">${item.task_name || '-'}.</span>
                                <span class="text-primary fs-8 fw-semibold">${item.task_date}.</span>
                                </td>
                                <td>${plannedHours.toFixed(2)} hrs</td>
                                <td>${actualHours} hrs</td>
                                <td>${statusBadge}</td>
                                <td><span class="badge bg-${badgeClass}">${saving} hrs</span></td>
                            </tr>
                        `;
                    });

                    $('#productionDetailsBody').html(rows);

                    $('#productionDetailsFooter').html(`
                        <td colspan="5" class="text-end">
                            Total Records: ${res.data.length}
                        </td>
                    `);

                } else {
                    $('#productionDetailsBody').html(`
                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                No data found.
                            </td>
                        </tr>
                    `);
                }

                // $('#productionDetailsBody').html(html);
            })
            .catch(err => {
                console.error(err);
                 $('#productionDetailsBody').html('<tr><td colspan="6" class="text-danger"> Failed to load production details..</td></tr>');
                $('#production_summary').html(``);
            });
    }

    function openPIActualCalculationModal(staffId) {

        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        $('#piCalculationDetailModal').modal('show');
        $('#piDetailModalBody').html(`
            <div class="text-center py-10">
                <div class="spinner-border text-primary"></div>
            </div>
        `);

        $.ajax({
            url: '/staff/pi-details',
            method: 'GET',
            data: {
                staff_id: staffId,
                month: month,
                year: year,
                branch_id: branch_id
            },
            success: function(res) {
                if (res.staff) {
                    let staff = res.staff;
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name';
                    if (staffImage) {
                        $('#piCalStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#piCalStaffIntialImageCre').addClass('d-none');
                    } else {
                        let initial = staffName.charAt(0).toUpperCase();
                        $('#piCalStaffIntialImageCre').text(initial).removeClass('d-none');
                        $('#piCalStaffImage').addClass('d-none');
                    }
                    $('#piCalStaffName').text(staff.staff_name);
                    $('#piCalStaffDept').text(staff.department_name);
                }

                    if (res.error) {
                        $('#piDetailModalBody').html(`
                            <div class="alert alert-danger">
                                ${res.error}
                            </div>
                        `);
                        return;
                    }
                    if (!res.status) {

                        $('#piDetailModalBody').html(`
                            <div class="alert alert-danger">
                                ${res.message || res.error || 'Unable to load details'}
                            </div>
                        `);

                        return;
                    }

                    let summary = res.summary || {};
                    let proposals = res.proposals || [];

                    if (proposals.length === 0) {

                        $('#piDetailModalBody').html(`
                            <div class="alert alert-warning">
                                No eligible proposals found for selected month.
                            </div>
                        `);

                        return;
                    }

                    let html = `

                    <div class="row mb-5">
                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Eligible Proposals
                                    </div>
                                    <div class="fs-1 fw-bold text-primary">
                                        ${summary.eligible_proposals}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Total Reward
                                    </div>
                                    <div class="fs-1 fw-bold text-success">
                                        ₹${Number(summary.total_reward).toLocaleString()}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Highest Slab
                                    </div>
                                    <div class="fs-1 fw-bold text-warning">
                                        ${summary.highest_matched_slab}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Best Profit %
                                    </div>
                                    <div class="fs-1 fw-bold text-info">
                                        ${summary.highest_profit_percentage}%
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-row-bordered align-middle">
                            <thead class="bg-primary text-white sticky-top">
                                <tr>
                                    <th>Proposal</th>
                                    <th>Selling</th>
                                    <th>Actual</th>
                                    <th>Profit</th>
                                    <th>Profit %</th>
                                    <th>Matched Slab</th>
                                    <th>Reward %</th>
                                    <th>Reward Earned</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    proposals.forEach(item => {
                        html += `
                            <tr>
                                <td>
                                    <div>
                                    <span> ${item.service_title}</span>
                                    </div>
                                    <span class="badge bg-label-primary">
                                        ${item.proposal_code}
                                    </span>
                                </td>
                                <td>
                                    ${item.currency_symbol}${Number(item.selling_amount).toLocaleString()}
                                </td>
                                <td>
                                    ${item.currency_symbol}${Number(item.actual_amount).toLocaleString()}
                                </td>
                                <td>
                                    <span class="text-success fw-bold">
                                        ${item.currency_symbol}${Number(item.profit_amount_original).toLocaleString()}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-info">
                                        ${item.profit_percent}%
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-warning">
                                        ${item.matched_slab}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-primary">
                                        ${item.reward_percent}%
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-success fs-6">
                                        ₹${Number(item.reward_amount).toLocaleString()}
                                    </span>
                                </td>
                            </tr>
                        `;
                    });
                    html += `
                            </tbody>
                        </table>
                    </div>
                    `;
                    $('#piDetailModalBody').html(html);
            },
            error: function() {
                $('#piDetailModalBody').html(`
                    <div class="alert alert-danger">
                        Unable to load details
                    </div>
                `);
            }
        });
    }
    function openPIPostActualCalculationModal(staffId) {

        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        $('#piPostCalculationDetailModal').modal('show');
        $('#piPostDetailModalBody').html(`
            <div class="text-center py-10">
                <div class="spinner-border text-primary"></div>
            </div>
        `);

        $.ajax({
            url: '/staff/pi-post-details',
            method: 'GET',
            data: {
                staff_id: staffId,
                month: month,
                year: year,
                branch_id: branch_id
            },
            success: function(res) {
                if (res.staff) {
                    let staff = res.staff;
                    let staffImage = staff.staff_image;
                    let staffName = staff.staff_name || 'No Name';
                    if (staffImage) {
                        $('#piPostStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#piPostStaffIntialImageCre').addClass('d-none');
                    } else {
                        let initial = staffName.charAt(0).toUpperCase();
                        $('#piPostStaffIntialImageCre').text(initial).removeClass('d-none');
                        $('#piPostStaffImage').addClass('d-none');
                    }
                    $('#piPostStaffName').text(staff.staff_name);
                    $('#piPostStaffDept').text(staff.department_name);
                }

                    if (res.error) {
                        $('#piPostDetailModalBody').html(`
                            <div class="alert alert-danger">
                                ${res.error}
                            </div>
                        `);
                        return;
                    }
                    if (!res.status) {

                        $('#piPostDetailModalBody').html(`
                            <div class="alert alert-danger">
                                ${res.message || res.error || 'Unable to load details'}
                            </div>
                        `);

                        return;
                    }

                    let summary = res.summary || {};
                    let proposals = res.proposals || [];

                    if (proposals.length === 0) {

                        $('#piPostDetailModalBody').html(`
                            <div class="alert alert-warning">
                                No eligible proposals found for selected month.
                            </div>
                        `);

                        return;
                    }

                    let html = `

                    <div class="row mb-5">
                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Eligible Proposals
                                    </div>
                                    <div class="fs-1 fw-bold text-primary">
                                        ${summary.eligible_proposals}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Total Reward
                                    </div>
                                    <div class="fs-1 fw-bold text-success">
                                        ₹${Number(summary.total_reward).toLocaleString()}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Highest Slab
                                    </div>
                                    <div class="fs-1 fw-bold text-warning">
                                        ${summary.highest_matched_slab}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="card border-0 shadow-sm">
                                <div class="card-body text-center">
                                    <div class="fs-6 text-muted">
                                        Best Profit %
                                    </div>
                                    <div class="fs-1 fw-bold text-info">
                                        ${summary.highest_profit_percentage}%
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-row-bordered align-middle">
                            <thead class="bg-primary text-white sticky-top">
                                <tr>
                                    <th>Proposal</th>
                                    <th>Selling</th>
                                    <th>Actual</th>
                                    <th>Profit</th>
                                    <th>Profit %</th>
                                    <th>Matched Slab</th>
                                    <th>Reward %</th>
                                    <th>Reward Earned</th>
                                </tr>
                            </thead>
                            <tbody>
                    `;
                    proposals.forEach(item => {
                        html += `
                            <tr>
                                <td>
                                    <div>
                                    <span> ${item.service_title}</span>
                                    </div>
                                    <span class="badge bg-label-primary">
                                        ${item.proposal_code}
                                    </span>
                                </td>
                                <td>
                                    ${item.currency_symbol}${Number(item.selling_amount).toLocaleString()}
                                </td>
                                <td>
                                    ${item.currency_symbol}${Number(item.actual_amount).toLocaleString()}
                                </td>
                                <td>
                                    <span class="text-success fw-bold">
                                        ${item.currency_symbol}${Number(item.profit_amount_original).toLocaleString()}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-info">
                                        ${item.profit_percent}%
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-warning">
                                        ${item.matched_slab}
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-primary">
                                        ${item.reward_percent}%
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-label-success fs-6">
                                        ₹${Number(item.reward_amount).toLocaleString()}
                                    </span>
                                </td>
                            </tr>
                        `;
                    });
                    html += `
                            </tbody>
                        </table>
                    </div>
                    `;
                    $('#piPostDetailModalBody').html(html);
            },
            error: function() {
                $('#piPostDetailModalBody').html(`
                    <div class="alert alert-danger">
                        Unable to load details
                    </div>
                `);
            }
        });
    }
</script>

<script>
    function openSIDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#CrashDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        
        $.ajax({
            url: `/get-si-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
               if (response.staff) {
                    const staff = response.staff;
                    $('#CourseStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#CourseStaffName').text(staff.staff_name);
                    $('#CourseStaffDept').text(staff.department_name);
                }
            
                $('#strategic_status').text(response.slab + " | Average Collection ₹" + response.collection_total_avg);

                let rows = '';

                if (response.data.length > 0) {

                    response.data.forEach(item => {

                        rows += `
                        <tr>
                            <td class="fw-bold">${item.name}</td>
                            <td>${item.service_title}</td>
                            <td>${item.created_at}</td>
                            <td class="fw-bold text-success">
                                ${item.currency_symbol}${item.collection}
                                ${item.currency_id !== '70' ? `<br><small class="text-muted">₹${item.collection_inr}</small>` : ''}
                            </td>
                            <td class="fw-bold text-success">
                                <span class=" badge text-bold text-black bg-warning">₹${item.collection_base_amount}</span>
                            </td>
                        </tr>`;
                    });

                } else {
                    rows = `<tr>
                                <td colspan="4" class="text-center text-muted">
                                    No SI transactions
                                </td>
                            </tr>`;
                }

               
                $("#CrashDetailsBody").html(rows);

                $('#CrashTotalAmount').text('₹' + response.collection_total_inr);
                $('#CrashTotalNetAmount').text('₹' + response.collection_total_net_inr);
                $('#AverageNetAmountCalc').text('('+response.collection_total_net_inr + ' / ' + response.total_customer + ')'); // Example: (₹5000 / 10 SI Transactions)
                $('#AverageNetAmount').text('₹' + (response.collection_total_avg) );

            },
            error: function () {
                // $("#actualDetailsCourseModal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                // $("#TesboDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsCourseModal'));
        modal.show();
    }
</script>

<script>
    function openTeamDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        const modal = new bootstrap.Modal(document.getElementById('teamDetailsModal'));
        modal.show();
    
        $('#teamDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
       
    
        fetch(`/get-team-detail?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(response => response.json())
            .then(response => {
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                    let rows = '';
                    if (staffImage) {
                        $('#teamStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#teamStaffInitialImage').addClass('d-none');
                    } else {
                        let initial = staffName.charAt(0).toUpperCase();
                        $('#teamStaffInitialImage').text(initial).removeClass('d-none');
                        $('#teamStaffImage').addClass('d-none');
                    }

                      $('#teamStaffName').text(staffName);
                    $('#teamStaffDept').text(departmentName);

                    let preCards = renderTeamMembers(
                        response.pre.members,
                        'Pre Sale'
                    );
                    let postCards = renderTeamMembers(
                        response.post.members,
                        'Post Sale'
                    );
                    let totalMembers =
                        response.pre.total_members +
                        response.post.total_members;
                    let totalAchieved =
                        response.pre.total_achieved +
                        response.post.total_achieved;
                    let summaryHtml = `
                    <div class="alert ${
                        totalMembers === totalAchieved
                            ? 'alert-success'
                            : 'alert-warning'
                    }">
                        <div class="d-flex justify-content-between align-items-center flex-wrap">
                            <div>
                                <h5 class="mb-1">
                                    Team Achievement Summary
                                </h5>
                                <small>
                                    ${totalAchieved} of ${totalMembers}
                                    members achieved their targets
                                </small>
                            </div>
                            <span class="badge ${
                                totalMembers === totalAchieved
                                    ? 'bg-success'
                                    : 'bg-warning'
                            } fs-6">
                                ${totalAchieved}/${totalMembers}
                            </span>
                        </div>
                    </div>
                    `;

                    let html = `
                    <div class="row g-3">
                        <div class="col-lg-6">
                            <div class="card shadow-sm h-100">
                                <div class="card-header bg-label-info d-flex justify-content-between">
                                    <span>Pre Sale Team</span>
                                    <span class="badge bg-info">
                                        ${response.pre.total_achieved}/${response.pre.total_members}
                                    </span>
                                </div>
                                <div class="card-body">
                                    ${preCards}
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="card shadow-sm h-100">
                                <div class="card-header bg-label-primary d-flex justify-content-between">
                                    <span>Post Sale Team</span>
                                    <span class="badge bg-primary">
                                        ${response.post.total_achieved}/${response.post.total_members}
                                    </span>
                                </div>
                                <div class="card-body">
                                    ${postCards}
                                </div>
                            </div>
                        </div>
                    </div>
                    `;

                    $('#teamDetailsBody').html(summaryHtml + html);
            })
            .catch(err => {
                console.error('Fetch error:', err);
                $('#teamDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }
    function renderTeamMembers(members, type) {
        let html = '';
        members.forEach(member => {
            let imageHtml = '';
            if (member.staff_image) {
                imageHtml = `
                    <img
                        src="/staff_images/${member.staff_image}"
                        class="rounded-circle border"
                        width="50"
                        height="50"
                        style="object-fit:cover;">
                `;
            } else {
                let initial = member.staff_name
                    .charAt(0)
                    .toUpperCase();

                imageHtml = `
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                        style="width:50px;height:50px;">
                        ${initial}
                    </div>
                `;
            }
            let rowClass = member.status
                ? 'border-success bg-success-subtle'
                : (member.target == 0
                    ? 'border-secondary bg-light'
                    : 'border-danger bg-danger-subtle');

            let statusBadge = '';
            if (member.target == 0) {
                statusBadge = `
                    <span class="badge bg-secondary">
                        Not Eligible
                    </span>
                `;
            } else if (member.status) {
                statusBadge = `
                    <span class="badge bg-success">
                        Achieved
                    </span>
                `;
            } else {
                statusBadge = `
                    <span class="badge bg-danger">
                        Pending
                    </span>
                `;
            }
            html += `
                <div class="card mb-2 shadow-sm border-2 ${rowClass}">
                    <div class="card-body py-2">
                        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
                            <div class="d-flex align-items-center gap-3">
                                ${imageHtml}
                                <div>
                                    <div class="fw-bold">
                                        ${member.staff_name}
                                    </div>
                                    <small class="text-muted">
                                        ${type}
                                    </small>
                                </div>
                            </div>
                            <div class="d-flex align-items-center gap-3 flex-wrap">
                                <div class="text-center">
                                    <div class="small text-muted">
                                        Target
                                    </div>
                                    <div class="fw-bold">
                                        ${member.target}
                                    </div>
                                </div>
                                <div class="text-center">
                                    <div class="small text-muted">
                                        Actual
                                    </div>
                                    <div class="fw-bold">
                                        ${member.actual}
                                    </div>
                                </div>
                                ${statusBadge}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        });

        return html;
    }
</script>

<script>
    function openRewardModal(item){
        $('#rewardTitle').text(
            item.title || 'Reward Challenge'
        );

        let rewardHtml = '';

        if(item.reward_type === 'gift'){
            rewardHtml =`🏆 ${item.incentive_reward}`;
        }
        else{
            rewardHtml = `₹ ${Number(item.incentive_reward || 0 ).toLocaleString()}`;
        }
        $('#rewardValue').html(rewardHtml);

        let rulesHtml = '';
        if(item.rules){
            item.rules.forEach(function(rule,index){
                rulesHtml += `
                    <div class="reward-rule-item">
                        <div class="reward-rule-icon">
                            ${index + 1}
                        </div>
                        <div class="reward-rule-text">
                            ${rule}
                        </div>
                    </div>
                `;
            });
        }else{
            rulesHtml += `
                    <div class="reward-rule-item">
                        No Data Found
                    </div>
                `;
        }
    
        $('#rewardRules').html(rulesHtml);

        $('#rewardChestImage').attr('src',
            item.status
            ?
            "{{ asset('assets/phdizone_images/incentive/chest_open.gif') }}"
            :
            "{{ asset('assets/phdizone_images/incentive/chest.gif') }}"
        );

        $('#rewardInfoModal').modal('show');
    }
</script>

<script>
    // Journal TL
    function openActualJournalTLDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournalTL").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-journalteamlead-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournalTL').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournalTL').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournalTL').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournalTL').addClass('d-none');
                    }
                     $('#actualStaffNameJournalTL').text(staffName);
                    $('#actualStaffDeptJournalTL').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                               <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                                <div>
                                    <span class="text-primary fw-semibold fs-7">${item.cus_name}</span>
                                </div>
                                <div>
                                    <span class="text-info text-nowrap fw-semibold fs-8">${item.cus_id}</span>
                                </div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                            <td class="">
                                ${item.paper_status == 8 ? `
                                    <div class="mb-1"><span class=" badge bg-success text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">${item.publish_date ?? '-'}</span></div>
                                ` :''}
                                <div class="mb-1"><span class=" text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'Accepted Date">${item.accept_date}</span></div>
                                <div><span class="my-1 badge bg-${item.paper_status == 5 ? 'warning':(item.paper_status == 7 ? 'primary' :'info')} text-black fw-bold fs-7 text-nowrap" >${item.paper_status == 8 ? 'Published':(item.paper_status == 5 ? 'Accepted' : 'E-Proofing')}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournalTL").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournalTL").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournalTL").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalTLDetailsModal'));
        modal.show();
    }

    function openActualDoubleXJournalTLDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournalDoubleXTL").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-journalteamlead-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournalDoubleXTL').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournalDoubleXTL').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournalDoubleXTL').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournalDoubleXTL').addClass('d-none');
                    }
                     $('#actualStaffNameJournalDoubleXTL').text(staffName);
                    $('#actualStaffDeptJournalDoubleXTL').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                                <div>
                                    <span class="text-primary fw-semibold fs-7">${item.cus_name}</span>
                                </div>
                                <div>
                                    <span class="text-info text-nowrap fw-semibold fs-8">${item.cus_id}</span>
                                </div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                           <td class="">
                               ${item.paper_status == 8 ? `
                                    <div class="mb-1"><span class=" badge bg-success text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Published Date">${item.publish_date ?? '-'}</span></div>
                                ` :''}
                                <div class="mb-1"><span class=" text-black fw-bold fs-7 text-nowrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'Accepted Date">${item.accept_date}</span></div>
                                <div><span class="my-1 badge bg-${item.paper_status == 5 ? 'warning':(item.paper_status == 7 ? 'primary' :'info')} text-black fw-bold fs-7 text-nowrap" >${item.paper_status == 8 ? 'Published':(item.paper_status == 5 ? 'Accepted' : 'E-Proofing')}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournalDoubleXTL").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournalDoubleXTL").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournalDoubleXTL").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalTLDetailsModalDoubleX'));
        modal.show();
    }
</script>

<!-- collection  -->
 <script>
    function openOldCollectionDetailsModal(staffId) {

        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        const modal = new bootstrap.Modal(
            document.getElementById('oldCollectionDetailsModal')
        );

        modal.show();

        $("#oldCollectionDetailsBody").html(
            '<tr><td colspan="6" class="text-center">Loading...</td></tr>'
        );

        $("#oldCollectionDetailsFooter").html('');

        fetch(`/incentives/old-collection-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)

            .then(res => res.json())

            .then(res => {

                if (res.staff) {

                    let staff = res.staff;

                    let staffName = staff.staff_name ?? '';

                    if (staff.staff_image) {

                        $("#oldCollectionStaffImage")
                            .attr("src", `{{ asset('staff_images') }}/${staff.staff_image}`)
                            .removeClass("d-none");

                        $("#oldCollectionStaffInitial")
                            .addClass("d-none");

                    } else {

                        $("#oldCollectionStaffImage")
                            .addClass("d-none");

                        $("#oldCollectionStaffInitial")
                            .removeClass("d-none")
                            .text(staffName.charAt(0).toUpperCase());

                    }

                    $("#oldCollectionStaffName").text(staff.staff_name);
                    $("#oldCollectionStaffDept").text(staff.department_name);

                }

                $("#oldTargetAmount").text("₹ " + (res.target_amount ?? 0));
                $("#oldCollectedAmount").text("₹ " + (res.collection_amount ?? 0));
                $("#oldPendingAmount").text("₹ " + (res.pending_amount ?? 0));
                $("#oldCollectionPercentage").text((res.collection_percentage ?? 0) + "%");

                if (res.data.length > 0) {

                    let rows = "";

                    res.data.forEach((item, index) => {

                        rows += `

                        <tr>

                            <td>${index+1}</td>

                            <td>

                                <div class="fw-bold">

                                    ${item.name}

                                </div>

                                <small>

                                    ${item.mobile}

                                </small>

                            </td>

                            <td>${item.course}</td>

                            <td>${item.expected_date}</td>
                            

                            <td>
                                <div>
                                    <span class=" text-nowrap ${item.collection_amount ? 'text-success' : 'text-danger'}">
                                         ₹ ${item.collection_amount || item.pending_amount}
                                    </span>
                                </div>
                                <div class="text-nowrap">
                                     ${item.payment_date || '-'}
                                </div>
                              
                                 <span class="badge ${item.status == 'Eligible' ? 'bg-success' : 'bg-danger'}">
                                    ${item.status}
                                </span>

                            </td>

                        </tr>

                        `;

                    });

                    $("#oldCollectionDetailsBody").html(rows);

                    $("#oldCollectionDetailsFooter").html(

                        `<tr>

                            <td colspan="6">

                                Total Records : ${res.data.length}

                            </td>

                        </tr>`

                    );

                } else {

                    $("#oldCollectionDetailsBody").html(

                        `<tr>

                            <td colspan="6" class="text-center">

                                No Old Collection Found

                            </td>

                        </tr>`

                    );

                }

            })

            .catch(function () {

                $("#oldCollectionDetailsBody").html(

                    `<tr>

                        <td colspan="6">

                            Something went wrong.

                        </td>

                    </tr>`

                );

            });

    }
 </script>

@endsection