@extends('layouts/layoutMaster')

@section('title', 'Manage Metrics')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<style>
    .table-rule1 tbody,
    tr,
    td,
    tfoot,
    th,
    thead,
    tr {
        border: 1px solid black !important;
    }

    .table-rule1 thead th {
        background: #333;
        color: #fff;
        position: -webkit-sticky;
        position: sticky;
        top: 0;
    }

    th.sticky,
    tbody td:last-child {
        position: -webkit-sticky;
        position: sticky;
        right: 0;
        z-index: 2;
        background: #ccc;
    }

    th.sticky,
    tbody td:first-child {
        position: -webkit-sticky;
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ccc;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h5 class="mb-1">Manage Metrics</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Metrics Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <!-- Set Goal Button -->
            <div class="col-lg-6 d-flex align-items-center justify-content-end gap-3">
                <!-- Set Goal Button -->
                
            
                <!-- Month Navigation -->
                <ul class="nav nav-pills" role="tablist">
                    <!-- Previous Month Button -->
                    <li class="nav-item">
                        <a class="nav-link px-2" href="javascript:;" id="prevMonthBtn">
                            <span class="mdi mdi-arrow-left-circle-outline fs-2 text-primary"></span>
                        </a>
                    </li>
            
                    <!-- Current Month Display -->
                    <li class="nav-item">
                        <a class="nav-link active px-3 border border-dashed border-primary" href="javascript:;">
                            <div class="text-center">
                                <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                    {{ \Carbon\Carbon::now()->format('F') }}
                                </span>
                                <div class="d-block">
                                    <span class="fw-semibold fs-8" id="selectedYear">
                                        ({{ \Carbon\Carbon::now()->year }})
                                    </span>
                                </div>
                            </div>
                        </a>
                    </li>
            
                    <!-- Next Month Button -->
                    <li class="nav-item">
                        <a class="nav-link px-2" href="javascript:;" id="nextMonthBtn">
                            <span class="mdi mdi-arrow-right-circle-outline fs-2 text-primary"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
           
            <div class="col-lg-4 text-center mb-3 px-2">
                <div class="border-2 border-solid border-gray-300i rounded fw-bold px-0 py-3 mb-2">
                    <label class="fs-4 text-black mb-1">
                        <span>Pre Sale (<?php echo date("d-M-Y"); ?>)</span>
                    </label>
                    <div class="d-flex justify-content-center align-items-center flex-lg-row flex-column gap-2">
                        <div class="border border-dashed border-danger rounded text-center fw-bold px-1 py-1 mb-1">
                            <div class="text-black mb-1">
                                <label class="fs-7">Expected</label>
                            </div>
                            <div class="badge bg-info rounded fw-bold fs-5 text-white mb-0" id="pre_sale_count"></div>
                        </div>
                        <div class="border border-dashed border-danger rounded text-center fw-bold px-1 py-1 mb-1">
                            <div class="text-black mb-1">
                                <label class="fs-7">Actual</label>
                            </div>
                            <div class="badge bg-warning rounded fw-bold fs-5 text-black mb-0" id="pre_sale_count_actual"></div>
                        </div>
                    </div>
                </div>
               
                <div class="border-2 border-solid border-gray-300i rounded fw-bold px-0 py-3 mb-2">
                    <label class="fs-4 text-black mb-1">
                        <span>Post Sale (<?php echo date("d-M-Y"); ?>)</span>
                    </label>
                    <div class="d-flex justify-content-center align-items-center flex-lg-row flex-column gap-2">
                        <div class="border border-dashed border-danger rounded text-center fw-bold px-1 py-1 mb-1">
                            <div class="text-black mb-1">
                                <label class="fs-7">Expected</label>
                            </div>
                            <div class="badge bg-info rounded fw-bold fs-5 text-white mb-0" id="post_sale_count"></div>
                        </div>
                        <div class="border border-dashed border-danger rounded text-center fw-bold px-1 py-1 mb-1">
                            <div class="text-black mb-1">
                                <label class="fs-7">Actual</label>
                            </div>
                            <div class="badge bg-warning rounded fw-bold fs-5 text-black mb-0" id="post_sale_count_actual"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 text-center mb-3 px-2">
                <div class="border-2 border-solid border-gray-300i rounded fw-bold px-0 py-8">
                    <div class="d-flex justify-content-center align-items-center flex-wrap mb-6 py-1">
                        <a href="javascript:;" class="fw-bold me-2 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Target Amount">
                            <svg height="50px" width="50px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 509.287 509.287" xml:space="preserve">
                                <circle style="fill:#F0582F;" cx="254.644" cy="254.644" r="254.644" />
                                <circle style="fill:#FCFCFD;" cx="254.644" cy="254.644" r="212.26" />
                                <circle style="fill:#F0582F;" cx="254.644" cy="254.644" r="165.807" />
                                <circle style="fill:#FCFCFD;" cx="254.644" cy="254.644" r="118.336" />
                                <circle style="fill:#F0582F;" cx="254.644" cy="254.644" r="69.171" />
                                <path style="fill:#FBD303;" d="M264.138,245.15L139.359,120.371l6.442-41.028L72.223,5.764l-9.155,57.642L5.425,72.562
                            l73.579,73.579l41.028-6.442l124.779,124.779c5.086,5.086,13.902,5.086,19.327,0C269.563,259.052,269.563,250.236,264.138,245.15z" />
                            </svg>
                        </a>
                        <div class=" fw-semibold rounded mb-1">
                           <label class="fs-1 text-black mb-1">Target Amount</label>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center flex-lg-row flex-column mb-3">
                        <div class="border border-dashed border-danger rounded fw-bold mx-6 px-2 py-3 mb-2">
                            <div class="text-black mb-1">
                                <label class="fs-4">Expected Collection</label>
                                <label class="fs-5">(<?php echo date("d-M-Y"); ?>)</label>
                            </div>
                            <div class="text-center">
                                <div class="badge bg-info rounded fw-bold mb-0">
                                    <!--<label class="fs-3 text-white"><i class="mdi mdi-currency-rupee fs-4 text-white"></i></label>-->
                                    <label class="fs-2 text-white" id="target_amount"></label>
                                </div>
                            </div>
                        </div>
                        <div class="border border-dashed border-danger rounded fw-bold mx-6 px-2 py-3 mb-2">
                            <div class="text-black mb-1">
                                <label class="fs-4">Actual Collection</label>
                                <label class="fs-5">(<?php echo date("d-M-Y"); ?>)</label>
                            </div>
                            <div class="text-center">
                                <div class="badge bg-success rounded fw-bold mb-0">
                                    <!--<label class="fs-3 text-white"><i class="mdi mdi-currency-rupee fs-4 text-white"></i></label>-->
                                    <label class="fs-2 text-white" id="target_amount_actual"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page table-rule1">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0" style="background-color: #274E13;">
                            <th class="min-w-125px text-center sticky" rowspan="2">Date</th>
                            <th class="min-w-50px text-center">Pre Sale<br>(Expected)</th>
                            <th class="min-w-50px text-center">Pre Sale<br>(Actual)</th>
                            <th class="min-w-50px text-center">Post Sale<br>(Expected)</th>
                            <th class="min-w-50px text-center">Post Sale<br>(Actual)</th>
                            <th class="min-w-50px text-center">Collection<br>(Expected)</th>
                            <th class="min-w-50px text-center">Collection<br>(Actual)</th>
                            <th class="min-w-50px text-center">Harvesting<br>(Expected)</th>
                            <th class="min-w-50px text-center">Harvesting<br>(Actual)</th>
                        </tr>
                    </thead>
                    <tbody id="targetTableBody"  class="text-gray-600 fw-semibold fs-7">
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="conversionModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content border-0 shadow">
      <div class="modal-header  text-white">
        <h5 class="modal-title fw-semibold">Conversion Summary for <span id="modalDate" class="text-warning"></span></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="modal-body">
        <div class="table-responsive">
          <table class="table table-bordered table-hover align-middle mb-0">
            <thead class="bg-primary text-white">
              <tr>
                <th class="fs-5">Conversion Type</th>
                <th class="text-center fs-5">Total Count</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td class="fw-semibold">On-Day Conversion</td>
                <td class="text-center fs-4 fw-bold">
                  <span class="badge bg-success fs-5 px-3 py-2" id="convertedToday">-</span>
                </td>
              </tr>
              <tr>
                <td class="fw-semibold">On-Month Conversion</td>
                <td class="text-center fs-4 fw-bold">
                  <span class="badge bg-success fs-5 px-3 py-2" id="convertedMonth">-</span>
                </td>
              </tr>
              <tr>
                <td class="fw-semibold">Old-Month Conversion</td>
                <td class="text-center fs-4 fw-bold">
                  <span class="badge bg-danger fs-5 px-3 py-2" id="convertedOldMonth">-</span>
                </td>
              </tr>
              <tr class="table-secondary">
                <td class="fw-semibold">Total Conversion</td>
                <td class="text-center fs-3 fw-bold">
                  <span class="badge bg-dark fs-5 px-4 py-2" id="convertedTotal">-</span>
                </td>
              </tr>
            </tbody>

          </table>
        </div>
      </div>

      <div class="modal-footer bg-light">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<style>
.conversion-cell {
    padding: 0.5rem;
    cursor: pointer;
    border: none;
}

.conversion-box {
    padding: 1rem;
    border-radius: 12px;
    background: white;
    color: black;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    transition: all 0.2s ease-in-out;
    font-size: 1.2rem;
}

.conversion-cell:hover .conversion-box {
    transform: scale(1.05);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
}
</style>
<script>
    function regis_dt_edit_mouse_in(x) {
        document.getElementById("regis_edit_icon").setAttribute('style', 'display:inline !important');
    }

    function regis_dt_edit_mouse_out(x) {
        document.getElementById("regis_edit_icon").setAttribute('style', 'display:none !important');
    }

    function coll_dt_edit_mouse_in(x) {
        document.getElementById("coll_edit_icon").setAttribute('style', 'display:inline !important');
    }

    function coll_dt_edit_mouse_out(x) {
        document.getElementById("coll_edit_icon").setAttribute('style', 'display:none !important');
    }
</script>
 <!--getmetrics-->
<script>

    var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
    var currentYear = new Date().getFullYear();
    function updateMonthDisplay() {
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
        document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
        document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

        document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
        document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

        fetchTargets();
    }
    
    document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }
        updateMonthDisplay();
    });
    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }
        updateMonthDisplay();
    });
    fetchTargets();

    function fetchTargets() {
        let branch_id = "{{ auth()->user()->branch_id }}";
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
    
        $.ajax({
            url: "{{ route('get-metrics') }}",
            type: "GET",
            data: { branch_id: branch_id, month: month, year: year },
            success: function (response) {
                if (response.status === 200 && response.data) {
                    // Set summary counts as you do
                    console.log(response.data.no_of_registrations)
                    $("#pre_sale_count").text(response.data.no_of_registrations);
                    $("#post_sale_count").text(response.data.post_sale);
                    $("#target_amount").text("₹ " + Number(response.data.monthly_target).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }));
                    // Set actual counts
                    $("#pre_sale_count_actual").text(response.actuals.pre_sale_actual);
                    $("#post_sale_count_actual").text(response.actuals.post_sale_actual);
                    $("#target_amount_actual").text("₹ " + Number(response.actuals.target_actual).toLocaleString("en-IN", {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    }));
                    
                    
                    let target = Number(response.data.monthly_target || 0);
                    let actual = Number(response.actuals.target_actual || 0);
                    
                    let targetBadgeClass = '';
                    if (target > 0 && actual >= target) {
                        targetBadgeClass = 'bg-success';
                    } else {
                        targetBadgeClass = 'bg-danger';
                    }
                    
                    // Apply class dynamically to the badge div
                    let $actualBadge = $("#target_amount_actual").closest(".badge");
                    $actualBadge.removeClass("bg-success bg-danger bg-info").addClass(targetBadgeClass);
                        
                    // Now build your daily table rows dynamically
                    let rowsHtml = '';
                   
                    let preSaleExpected = response.distribution.pre_sale_expected;
                    let preSaleActual = response.distribution.pre_sale_actual_per_day;
                    let preSaleCollection = response.distribution.dailyPaidAmountsPre; // or your collection data
                    let postSaleExpected = response.distribution.post_sale_expected;
                    let postSaleActual = response.distribution.post_sale_actual_per_day;
                    let targetExpected = response.distribution.monthly_target_expected;
                    let targetActual = response.distribution.monthly_target_actual_per_day;
                    let harvestingExpected = response.distribution.harvestings_expected;
                    let harvestingActual = response.distribution.harvestings_actual_per_day;
                    let postSaleCollection = response.distribution.dailyPaidAmountsPost; // or your collection data
                    let dailyPaidAmountsOther = response.distribution.dailyPaidAmountsOther; // if available
                    let totalAmount = [];
    
                    let dates = response.distribution.dates || [];
                    let todayStr = new Date().toISOString().split('T')[0];
                   const toINR = (num) => Number(num || 0).toLocaleString('en-IN', {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2
                        });

                    let grandTotal = 0;
                    for (let i = 0; i < dates.length; i++) {
                        let date = dates[i];
                        let rowHighlight = '';  // default: no highlight

                        if (date === todayStr) {
                            rowHighlight = 'background-color: #64d1df !important;';  // mild blu
                        } else if (date > todayStr) {
                            rowHighlight = 'background-color: #ccc !important;';  // future dim gray
                        }
                        
                        let isToday = date === todayStr;
                        let isFuture = date > todayStr;
                        let baseStyle = '';
                        
                        if (date === todayStr) {
                            baseStyle = 'background-color: #64d1df !important;';
                            textColorClass = 'text-black';
                            dateIcon = `<i class="mdi mdi-calendar-today text-info ms-1" title="Today"></i>`;
                        } else if (date > todayStr) {
                            baseStyle = 'background-color: #ccc !important;';
                            textColorClass = 'text-black';
                             dateIcon = ''; // no icon
                        }else{
                             textColorClass = 'text-white';
                              dateIcon = ''; // no icon
                        }
                       
                        let preExpected = preSaleExpected?.[date] ?? 0;
                        let preActual = preSaleActual?.[date] ?? 0;
                        let preColl = preSaleCollection?.[date] ?? 0;
                        let postExpected = postSaleExpected?.[date] ?? 0;
                        let postActual = postSaleActual?.[date] ?? 0;
                        let targetExpecteds = targetExpected?.[date] ?? 0;
                        let targetActuals = targetActual?.[date] ?? 0; 
                        let harvestingExpecteds = harvestingExpected?.[date] ?? 0; 
                        let harvestingActuals = harvestingActual?.[date] ?? 0; 
                        let postColl = postSaleCollection?.[date] ?? 0;
                        let othersColl = dailyPaidAmountsOther?.[date] ?? 0;
                    
                        totalAmount[i] = preColl + postColl + othersColl;
                        grandTotal += totalAmount[i];
                        // Color logic
                        let preColor = preActual >= preExpected ? '#1e961e' : '#fd1d1d';
                        let collectionColor = targetActuals >= targetExpecteds ? '#1e961e' : '#fd1d1d';
                        let harvestingColor = harvestingExpecteds == 0 
                            ? '#ff9900' 
                            : (harvestingActuals >= harvestingExpecteds ? '#1e961e' : '#fd1d1d');
                        let postColor = postExpected === 0 
                        ? '#fd1d1d' // gray color for 0 expected
                        : postActual >= postExpected 
                            ? '#1e961e' // green if met or exceeded
                            : '#fd1d1d'; // red if not met
                    
                        rowsHtml += `
                            <tr style="${rowHighlight}">
                                <td align="center" style="${baseStyle}"><label class="text-black fs-7 fw-bold">${formatDate(date)}  ${dateIcon}</label></td>
                                <td align="center" style="background: #FF9900 !important; ${baseStyle}"><label class="text-black fs-7 fw-bold">${preExpected}</label></td>
                                <td 
                                    class="conversion-cell text-center"
                                    style="background-color: ${preColor}; ${baseStyle}">
                                    <div class=" fw-bold">
                                        ${preActual}
                                    </div>
                                </td>
                                <td align="center" style="background: #FF9900 !important; ${baseStyle}"><label class="text-black fs-7 fw-bold">${postExpected}</label></td>
                                <td align="center" style="background: ${postColor}; ${baseStyle}"><label class="fs-7 fw-bold ${textColorClass}" >${postActual}</label></td>
                                <td align="right" style="background: #FF9900 !important; ${baseStyle}"><label class="text-black fs-7 fw-bold"><i class="mdi mdi-currency-rupee fs-9 text-black "></i>${toINR(targetExpecteds)}</label></td>
                                <td align="right" style="background: ${collectionColor}; ${baseStyle}"><label class="fs-7 ${textColorClass}" ><i class="mdi mdi-currency-rupee fs-9 ${textColorClass}"></i> ${toINR(targetActuals)}</label></td>
                                <td align="right" style="background: #FF9900 !important; ${baseStyle}"><label class="text-black fs-7 fw-bold"><i class="mdi mdi-currency-rupee fs-9 text-black "></i>${toINR(harvestingExpecteds)}</label></td>
                                <td align="right" style="background: ${harvestingColor}; ${baseStyle}"><label class="fs-7 ${textColorClass}"><i class="mdi mdi-currency-rupee fs-9 ${textColorClass} "></i> ${toINR(harvestingActuals)}</label></td>
                            </tr>
                        `;
                       
                    }
                    
                    let totalPreSaleActual = 0;
                    let totalPostSaleActual = 0;
                    let totalTargetActual = 0;
                    let totalHarvestingActual = 0;
                    let totalHarvestingExpected = 0;
                    for (let i = 0; i < dates.length; i++) {
                        totalPreSaleActual += Number(preSaleActual?.[dates[i]] ?? 0);
                        totalPostSaleActual += Number(postSaleActual?.[dates[i]] ?? 0);
                        totalTargetActual += Number(targetActual?.[dates[i]] ?? 0);
                        totalHarvestingExpected += Number(harvestingExpected?.[dates[i]] ?? 0);
                        totalHarvestingActual += Number(harvestingActual?.[dates[i]] ?? 0);
                    }
                   rowsHtml += `
                    <tr style="background: #cce5ff; font-size: 1.2rem; font-weight: bold;">
                        <td colspan="7" align="right">
                            <label class="text-dark">Grand Total</label>
                        </td>
                        <td align="right" style="background: #cce5ff; font-size: 1.2rem; font-weight: bold;">
                            <label class="text-black fs-4">
                                <i class="mdi mdi-currency-rupee fs-4 text-black"></i> ${toINR(totalHarvestingExpected)}
                            </label>
                        </td>
                        <td align="right" style="background: #ffcccc; font-size: 1.2rem; font-weight: bold;">
                            <label class="text-black fs-4">
                                <i class="mdi mdi-currency-rupee fs-4 text-black"></i> ${toINR(totalHarvestingActual)}
                            </label>
                        </td>
                    </tr>
                `;

                   

    
                    $("#targetTableBody").html(rowsHtml);
    
                } else {
                    $("#pre_sale_count").text(0);
                    $("#post_sale_count").text(0);
                    $("#target_amount").text("₹ " + Number(0));
                    // Set actual counts
                    $("#pre_sale_count_actual").text(0);
                    $("#post_sale_count_actual").text(0);
                    $("#target_amount_actual").text("₹ " + Number(0));
                    
                    // Handle empty or error state...
                    $("#targetTableBody").html('<tr><td colspan="8" class="text-center">No data available</td></tr>');
                }
            },
            error: function (error) {
                console.error("Error fetching targets:", error);
            }
        });
    }
function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
    }).replace(/ /g, '-');
}
function formatDateReadable(dateStr) {
    const dateObj = new Date(dateStr);
    const day = dateObj.getDate();
    const month = dateObj.toLocaleString('en-US', { month: 'short' }); // "Jun"
    const year = dateObj.getFullYear();
    return `${day} ${month} ${year}`;
}



</script>
<!--Create Dashboards Accordion Start-->
<script>
    'use strict';
    (function() {
        const sgr1 = [].slice.call(document.querySelectorAll('.sgr1'));
        // Collapsible card
        // --------------------------------------------------------------------
        if (sgr1) {
            sgr1.map(function(sgr1_Element) {
                sgr1_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(sgr1_Element.closest('.card').querySelector('.collapse.sgr1_body'));
                    // Toggle collapsed class in `.card-header` element
                    sgr1_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(sgr1_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Create Dashboards Accordion End-->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection