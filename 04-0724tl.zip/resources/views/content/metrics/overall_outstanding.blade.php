@extends('layouts/layoutMaster')

@section('title', 'Overall Outstanding')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/apex-charts/apex-charts.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/apex-charts/apexcharts.js',
])
@endsection



@section('content')

<style>
    .scroll-x {
        overflow-x: auto;
    }

    .scroll-x::-webkit-scrollbar {
        height: 6px;
    }

    .scroll-x::-webkit-scrollbar-thumb {
        background-color: rgba(0, 0, 0, 0.3);
        border-radius: 3px;
    }

    .corner-ribbon {
        /* width: 85px; */
        background: #ff4d4f;
        position: absolute;
        top: 10px;
        right: -1px;
        text-align: center;
        line-height: 30px;
        color: #fff;
        font-weight: bold;
        transform: rotate(360deg);
        z-index: 10;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
        border-top-left-radius: 10%;
        border-bottom-left-radius: 10%;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1 d-flex align-items-center justify-content-between gap-2">
        <div>
            <h5 class="card-title mb-1">Overall Outstanding</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Metrics Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex align-items-end justify-content-between flex-row gap-2 mb-1">
            <div class="d-flex align-items-center justify-content-between flex-row gap-1 mb-1">
                <label class="rounded py-2 px-2 border border-gray" style="background-color: #cfc;"></label>
                <span>-</span>
                <label class="fw-semibold fs-6 text-black">Paid Customer</label>
            </div>
            <div class="d-flex align-items-center justify-content-between flex-row gap-1 mb-1">
                <label class="rounded py-2 px-2 border border-gray" style="background-color: #fcc;"></label>
                <span>-</span>
                <label class="fw-semibold fs-6 text-black">Un-Paid Customer</label>
            </div>
            {{-- <div class="d-flex align-items-center justify-content-between flex-row gap-1 mb-1">
                <label class="rounded py-2 px-2 border border-gray" style="background-color: #9b9999b3;"></label>
                <span>-</span>
                <label class="fw-semibold fs-6 text-black">Dropped Customer</label>
            </div> --}}
            <div class="d-flex align-items-center justify-content-between flex-column mb-1">
                <label class="fs-5 fw-semibold text-black">Total Outstanding</label>
                <label class="fs-3 fw-semibold text-white rounded badge bg-danger" id="total_outstanding"></label>
            </div>
        </div>
    </div>

    <div class="card-body">
        <div class="row mb-2 scroll-x" style="overflow-x:auto; padding-bottom:10px;">
            <div id="month-columns" class="d-flex gap-3">
                <!-- Dynamic month cards will appear here -->
            </div>
        </div>
    </div>
</div>


{{-- <script>
    const currentMonth = new Date().getMonth() + 1; // 1–12
  const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const year = new Date().getFullYear();

  const pad2 = n => String(n).padStart(2, '0');
  const keyOf = (y, m) => `${y}-${pad2(m)}`;
  const addMonths = (y, m, delta) => {
    const d = new Date(y, m - 1 + delta, 1);
    return [d.getFullYear(), d.getMonth() + 1];
  };

  let TIMELINE = []; // global so render can use it

  function getFilteredTimeline(data, timeline, currentMonth, year, lookback = 5) {
    const pastMonthsWithValue = [];

    for (let i = timeline.length - 1; i >= 0; i--) { // start from latest
      const key = timeline[i];
      const [yy, mm] = key.split('-').map(Number);

      // Only consider past months
      if (yy < year || (yy === year && mm < currentMonth)) {
        const monthData = data[key] || { rows: [] };
        const customers = monthData.rows || [];
        const harvestedAmt = customers
          .filter(c => c.bg === '#ffcccc')
          .reduce((sum, c) => sum + c.amount, 0);

        if (harvestedAmt > 0) pastMonthsWithValue.push(key);
      }
    }

    // Keep only last `lookback` months
    pastMonthsWithValue.reverse(); // so oldest first
    return pastMonthsWithValue.slice(-lookback);
  }
  // Fetch data first
  fetch("{{ route('overall.outstanding') }}")
    .then(res => res.json())
    .then(res => {
      if (res.status !== 200) return;

      const data = res.data; // keys like "2025-12", "2026-01", ...
      const keys = Object.keys(data);

      // figure out last key from data, else current month
      let lastKey;
      if (keys.length) {
        const parsed = keys.map(k => {
          const [y, m] = k.split('-').map(Number);
          return { y, m, k };
        }).sort((a, b) => (a.y - b.y) || (a.m - b.m));
        lastKey = parsed[parsed.length - 1].k;
      } else {
        lastKey = keyOf(year, currentMonth);
      }

      const startKey = keyOf(...addMonths(year, currentMonth, -3));
      // build continuous month-by-month timeline from startKey to lastKey
      TIMELINE = [];
      let [cy, cm] = startKey.split('-').map(Number);
      const [ly, lm] = lastKey.split('-').map(Number);

      while (true) {
        TIMELINE.push(keyOf(cy, cm));
        if (cy === ly && cm === lm) break;
        [cy, cm] = addMonths(cy, cm, 1);
      }

      let filteredTimeline = TIMELINE.filter(key => {
        const [yy, mm] = key.split('-').map(Number);
        return yy > year || (yy === year && mm >= currentMonth); // keep ongoing & upcoming
      });
      const pastFiltered = getFilteredTimeline(res.data, TIMELINE, currentMonth, year, 5);
      filteredTimeline = [...pastFiltered, ...filteredTimeline]; // combine past+current/upcoming

      // indices for render (we keep your function signature shape)
      const startIndex = 0;
      const endIndex = TIMELINE.length - 1;

      // renderOutstandingCards(data, startIndex, endIndex, res.grand_total_outstanding);
      renderOutstandingCards(res.data, filteredTimeline, 0, filteredTimeline.length - 1);
    });


    function renderOutstandingCards(data, timeline, startIndex, endIndex) {
      const monthContainer = document.getElementById("month-columns");
      monthContainer.innerHTML = "";

      // 1️⃣ Calculate grand total from all months dynamically
      let grandTotalFromApi = 0;
      TIMELINE.forEach((key) => {
        const monthData = data[key] || { rows: [] };
        const customers = monthData.rows || [];
        customers.forEach(c => {
          if (c.bg === '#ffcccc') grandTotalFromApi += c.amount;
        });
      });

      // 2️⃣ Render each month
      for (let i = startIndex; i <= endIndex; i++) {
        const key = TIMELINE[i]; // e.g. "2026-01"
        const [yy, mm] = key.split('-').map(Number);
        const monthData = data[key] || { rows: [], month_total: 0 };
        const customers = monthData.rows || [];

        let harvestedAmt = 0;  // red
        let collectionAmt = 0; // green
        let rejectedAmt = 0;   // gray
        let actualAmt = 0;

        const card = document.createElement("div");
        card.className = "card rounded px-6 py-6";
        card.style.backgroundColor = (mm === currentMonth && yy === year) ? "#ffe699" : "#e2e2e2ff";
        card.style.minWidth = "350px";
        card.style.minHeight = "500px";
        card.style.flex = "0 0 auto";

        // decide ribbon text and color
        let ribbonText = "";
        let ribbonColor = "#ff4d4f"; // default red
        if (yy < year || (yy === year && mm < currentMonth)) {
            ribbonText = "Past";
        } else if (yy === year && mm === currentMonth) {
            ribbonText = "Ongoing";
            ribbonColor = "#1890ff";
        } else {
            ribbonText = "Upcoming";
            ribbonColor = "#2518ff";
        }

        // card HTML
        card.innerHTML = `
          <div class="corner-ribbon px-1 py-1" style="background: ${ribbonColor};">
            ${ribbonText}
          </div>
          <div class="row mb-4">
            <label class="fw-semibold text-black fs-4">${months[mm - 1]} - ${yy}</label>
          </div>
          <div class="row rounded bg-white py-1 px-1 mb-4 scroll-y"
              style="max-height:370px; overflow-x:hidden; overflow-y:auto; min-height:370px;">
            <div class="col-lg-12" id="month-${key}-list"></div>
          </div>
          <div class="row mb-2">
            <label class="col-lg-6 fw-semibold text-black fs-5">Harvested Amt.</label>
            <label id="month-${key}-harvested"
                  class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
          </div>
          <div class="row mb-2">
            <label class="col-lg-6 fw-semibold text-black fs-5">Collection Amt.</label>
            <label id="month-${key}-collection"
                  class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
          </div>
          <div class="row mb-2">
            <label class="col-lg-6 fw-semibold text-black fs-5">Rejected Amt.</label>
            <label id="month-${key}-rejected"
                  class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
          </div>
          <div class="row mb-2 rounded py-2 px-2" style="background-color : #6969ff;">
            <label class="col-lg-6 fw-semibold text-white fs-5">Actual Amt.</label>
            <label id="month-${key}-actual"
                  class="col-lg-6 text-end fw-semibold text-white fs-5">&#8377; 0</label>
          </div>
          <div class="row mb-2">
            <label class="col-lg-6 fw-semibold text-black fs-5">Outstanding %</label>
            <label id="month-${key}-percent"
                  class="col-lg-6 text-end fw-semibold text-black fs-5">0%</label>
          </div>
        `;
        monthContainer.appendChild(card);

        // render customers
        const listDiv = document.getElementById(`month-${key}-list`);
        customers.forEach((c, idx) => {
          const row = document.createElement("div");
          row.className = "row py-1 rounded mb-1";
          row.style.backgroundColor = c.bg;

          row.innerHTML = `
            <div class="d-flex align-items-center justify-content-between gap-2">
              <div class="d-flex align-items-start flex-column justify-content-start gap-1">
                <div class="d-flex align-items-center gap-2">
                  <label class="fw-semibold text-black fs-6 text-truncate max-w-150px">${c.name}</label>
                  ${
                    c.courseType
                      ? `<span class="badge rounded bg-info text-white fs-9"
                            data-bs-toggle="tooltip"
                            data-bs-placement="top"
                            title="${c.courseType}" >${c.courseType.slice(0,6)}</span>`
                      : ''
                  }
                </div>
                <label class="fw-semibold text-dark fs-7 text-truncate max-w-200px">${c.customerId}</label>
              </div>
              <div>
                <label class="badge bg-secondary fw-semibold text-white fs-6">&#8377; ${c.amount.toLocaleString()}</label>
              </div>
            </div>
          `;
          listDiv.appendChild(row);

          // sum amounts based on color
          if (c.bg === '#ffcccc') harvestedAmt += c.amount;
          else if (c.bg === '#ccffcc') collectionAmt += c.amount;
          else if (c.bg === '#9b9999b3') rejectedAmt += c.amount;

          if (idx !== customers.length - 1) {
            const hr = document.createElement("hr");
            hr.className = "p-1 m-0";
            listDiv.appendChild(hr);
          }
        });

        const tooltipTriggerList = [].slice.call(listDiv.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
          return new bootstrap.Tooltip(tooltipTriggerEl);
        });

        // calculate actual and percentage
        actualAmt = harvestedAmt;
        totalAmount = Math.max(harvestedAmt + collectionAmt + rejectedAmt, 0);

        const outstandingPercent = grandTotalFromApi
          ? ((harvestedAmt / grandTotalFromApi) * 100).toFixed(2)
          : 0;

        // update all labels
        document.getElementById(`month-${key}-harvested`).innerHTML = `&#8377; ${totalAmount.toLocaleString()}`;
        document.getElementById(`month-${key}-collection`).innerHTML = `&#8377; ${collectionAmt.toLocaleString()}`;
        document.getElementById(`month-${key}-rejected`).innerHTML = `&#8377; ${rejectedAmt.toLocaleString()}`;
        document.getElementById(`month-${key}-actual`).innerHTML = `&#8377; ${actualAmt.toLocaleString()}`;
        document.getElementById(`month-${key}-percent`).innerHTML = `${outstandingPercent}%`;

        // Set light red background for past months if harvestedAmt > 0
        if ((yy < year || (yy === year && mm < currentMonth)) && harvestedAmt > 0) {
            card.style.backgroundColor = "#ffd6d6";
        }
      }

      // overall grand total
      document.getElementById("total_outstanding").innerHTML =
        `&#8377; ${grandTotalFromApi.toLocaleString()}`;

      // Scroll so current month starts at the left
      const scroller = document.querySelector('.scroll-x');
      const currentKey = keyOf(year, currentMonth);
      let currentIdx = TIMELINE.indexOf(currentKey);
      if (currentIdx === -1) currentIdx = Math.min(3, TIMELINE.length - 1);

      const currentCard = monthContainer.children[currentIdx - startIndex];
      if (scroller && currentCard) {
        requestAnimationFrame(() => {
          currentCard.scrollIntoView({ behavior: 'auto', inline: 'start' });
          scroller.scrollLeft = currentCard.offsetLeft;
        });
      }
    }





</script> --}}
<script>
    const currentMonth = new Date().getMonth() + 1; // 1–12
  const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const year = new Date().getFullYear();

  const pad2 = n => String(n).padStart(2, '0');
  const keyOf = (y, m) => `${y}-${pad2(m)}`;
  const addMonths = (y, m, delta) => {
    const d = new Date(y, m - 1 + delta, 1);
    return [d.getFullYear(), d.getMonth() + 1];
  };

  let TIMELINE = []; // global timeline

  function getFilteredTimeline(data, timeline, currentMonth, year, lookback = 5) {
    const pastMonthsWithValue = [];

    for (let i = timeline.length - 1; i >= 0; i--) {
      const key = timeline[i];
      const [yy, mm] = key.split('-').map(Number);

      if (yy < year || (yy === year && mm < currentMonth)) {
        const monthData = data[key] || { rows: [] };
        const customers = monthData.rows || [];
        const harvestedAmt = customers
          .filter(c => c.bg === '#ffcccc')
          .reduce((sum, c) => sum + c.amount, 0);

        if (harvestedAmt > 0) pastMonthsWithValue.push(key);
      }
    }

    pastMonthsWithValue.reverse();
    return pastMonthsWithValue.slice(-lookback);
  }

  // Fetch data
  fetch("{{ route('overall.outstanding') }}")
    .then(res => res.json())
    .then(res => {
      if (res.status !== 200) return;

      const data = res.data;
      const keys = Object.keys(data);

      let lastKey;
      if (keys.length) {
        const parsed = keys.map(k => {
          const [y, m] = k.split('-').map(Number);
          return { y, m, k };
        }).sort((a, b) => (a.y - b.y) || (a.m - b.m));
        lastKey = parsed[parsed.length - 1].k;
      } else {
        lastKey = keyOf(year, currentMonth);
      }

      const startKey = keyOf(...addMonths(year, currentMonth, -6));
      TIMELINE = [];
      let [cy, cm] = startKey.split('-').map(Number);
      const [ly, lm] = lastKey.split('-').map(Number);
      while (true) {
        TIMELINE.push(keyOf(cy, cm));
        if (cy === ly && cm === lm) break;
        [cy, cm] = addMonths(cy, cm, 1);
      }

      // Filter timeline
      let filteredTimeline = TIMELINE.filter(key => {
        const [yy, mm] = key.split('-').map(Number);
        return yy > year || (yy === year && mm >= currentMonth);
      });
      const pastFiltered = getFilteredTimeline(data, TIMELINE, currentMonth, year, 5);
      filteredTimeline = [...pastFiltered, ...filteredTimeline];

      console.log('TIMELINE:', TIMELINE);
    console.log('filteredTimeline after filter:', filteredTimeline);
    console.log('pastFiltered:', pastFiltered);

      renderOutstandingCards(data, filteredTimeline, 0, filteredTimeline.length - 1);
    });


  function renderOutstandingCards(data, timeline, startIndex, endIndex) {
    const monthContainer = document.getElementById("month-columns");
    monthContainer.innerHTML = "";

    // 1️⃣ Calculate grand total from timeline
    let grandTotalFromApi = 0;
    timeline.forEach((key) => {
      const monthData = data[key] || { rows: [] };
      const customers = monthData.rows || [];
      customers.forEach(c => {
        if (c.bg === '#ffcccc') grandTotalFromApi += c.amount;
      });
    });

    // 2️⃣ Render each month
    for (let i = startIndex; i <= endIndex; i++) {
      const key = timeline[i];
      const [yy, mm] = key.split('-').map(Number);
      const monthData = data[key] || { rows: [], month_total: 0 };
      const customers = monthData.rows || [];

      let harvestedAmt = 0;
      let collectionAmt = 0;
      let rejectedAmt = 0;
      let actualAmt = 0;

      // Count variables for each category
      let harvestedCount = 0;
      let collectionCount = 0;
      let rejectedCount = 0;

      const card = document.createElement("div");
      card.className = "card rounded px-6 py-6";
      card.style.backgroundColor = (mm === currentMonth && yy === year) ? "#ffe699" : "#e2e2e2ff";
      card.style.minWidth = "350px";
      card.style.minHeight = "500px";
      card.style.flex = "0 0 auto";

      let ribbonText = "";
      let ribbonColor = "#ff4d4f";
      if (yy < year || (yy === year && mm < currentMonth)) {
          ribbonText = "Completed";
      } else if (yy === year && mm === currentMonth) {
          ribbonText = "Ongoing";
          ribbonColor = "#1890ff";
      } else {
          ribbonText = "Upcoming";
          ribbonColor = "#2518ff";
      }

      card.innerHTML = `
        <div class="corner-ribbon px-1 py-1" style="background: ${ribbonColor};">
          ${ribbonText}
        </div>
        <div class="row mb-4">
          <label class="fw-semibold text-black fs-4">${months[mm - 1]} - ${yy}</label>
        </div>
        <div class="row rounded bg-white py-1 px-1 mb-4 scroll-y"
            style="max-height:370px; overflow-x:hidden; overflow-y:auto; min-height:370px;">
          <div class="col-lg-12" id="month-${key}-list"></div>
        </div>
        <div class="row mb-2 align-items-center">
          <div class="col-lg-6 fw-semibold text-black fs-5 d-flex align-items-center gap-1">
            Total
            <span class="animated-badge-div harvested-badge" id="month-${key}-harvested-count"
                  data-bs-toggle="tooltip" data-bs-placement="bottom"
                  data-bs-original-title="Unpaid Students Count" style="display: none;">0</span>
          </div>
          <label id="month-${key}-harvested"
                class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
        </div>
        <div class="row mb-2 align-items-center">
          <div class="col-lg-6 fw-semibold text-black fs-5 d-flex align-items-center gap-1">
            Collection
            <span class="animated-badge-div collection-badge" id="month-${key}-collection-count"
                  data-bs-toggle="tooltip" data-bs-placement="bottom"
                  data-bs-original-title="Paid Students Count" style="display: none;">0</span>
          </div>
          <label id="month-${key}-collection"
                class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
        </div>
        <!--
        <div class="row mb-2 align-items-center">
          <div class="col-lg-6 fw-semibold text-black fs-5 d-flex align-items-center gap-1">
            Rejected
            <span class="animated-badge-div rejected-badge" id="month-${key}-rejected-count"
                  data-bs-toggle="tooltip" data-bs-placement="bottom"
                  data-bs-original-title="Dropped Students Count" style="display: none;">0</span>
          </div>
          <label id="month-${key}-rejected"
                class="col-lg-6 text-end fw-semibold text-black fs-5">&#8377; 0</label>
        </div>
        -->
        <div class="row mb-2 rounded py-2 px-2 align-items-center" style="background-color : #6969ff;">
          <div class="col-lg-6 fw-semibold text-white fs-5 d-flex align-items-center gap-1">
            Actual
            <span class="animated-badge-div actual-badge" id="month-${key}-actual-count"
                  data-bs-toggle="tooltip" data-bs-placement="bottom"
                  data-bs-original-title="Total Students Count" style="display: none;">0</span>
          </div>
          <label id="month-${key}-actual"
                class="col-lg-6 text-end fw-semibold text-white fs-5">&#8377; 0</label>
        </div>
        <div class="row mb-2">
          <label class="col-lg-6 fw-semibold text-black fs-5">Outstanding %</label>
          <label id="month-${key}-percent"
                class="col-lg-6 text-end fw-semibold text-black fs-5">0%</label>
        </div>
      `;
      monthContainer.appendChild(card);

      // render customers
      const listDiv = document.getElementById(`month-${key}-list`);
      customers.forEach((c, idx) => {
        const row = document.createElement("div");
        row.className = "row py-1 rounded mb-1";
        row.style.backgroundColor = c.bg;

        // Only show "Drop" badge if bg is gray
        const dropBadge = c.post_sale_check === 1
          ? `<span class="badge rounded bg-info text-white fs-9"
                  data-bs-toggle="tooltip"
                  data-bs-placement="top"
                  title="Post Sale">Post Sale</span>`
          : `
              <span class="badge rounded bg-primary text-white fs-9"
                data-bs-toggle="tooltip"
                data-bs-placement="top"
                title="Pre Sale">Pre Sale</span>`;

        row.innerHTML = `
          <div class="d-flex align-items-center justify-content-between gap-2">
            <div class="d-flex align-items-start flex-column justify-content-start gap-1">
              <div class="d-flex align-items-center gap-2">
                <label class="fw-semibold text-black fs-6 text-truncate max-w-150px">${c.name}</label>
                ${dropBadge}
              </div>
              <label class="fw-semibold text-dark fs-7 text-truncate max-w-200px">${c.customerId}</label>
            </div>
            <div>
              <label class="badge bg-secondary fw-semibold text-white fs-6">&#8377; ${c.amount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</label>
            </div>
          </div>
        `;
        listDiv.appendChild(row);

        // Count and sum amounts by category
        if (c.bg === '#ffcccc') {
          harvestedAmt += c.amount;
          harvestedCount++;
        } else if (c.bg === '#ccffcc') {
          collectionAmt += c.amount;
          collectionCount++;
        } else if (c.bg === '#9b9999b3') {
          rejectedAmt += c.amount;
          rejectedCount++;
        }

        if (idx !== customers.length - 1) {
          const hr = document.createElement("hr");
          hr.className = "p-1 m-0";
          listDiv.appendChild(hr);
        }
      });

      const tooltipTriggerList = [].slice.call(listDiv.querySelectorAll('[data-bs-toggle="tooltip"]'));
      tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
      });

      actualAmt = harvestedAmt;
      const totalAmount = Math.max(harvestedAmt + collectionAmt + rejectedAmt, 0);

      const totalStudentsCount = harvestedCount + collectionCount + rejectedCount;

      const outstandingPercent = grandTotalFromApi
        ? ((harvestedAmt / grandTotalFromApi) * 100).toFixed(2)
        : 0;

      // Update amounts and counts
     document.getElementById(`month-${key}-harvested`).innerHTML = `&#8377; ${totalAmount.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
    document.getElementById(`month-${key}-collection`).innerHTML = `&#8377; ${collectionAmt.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
    // document.getElementById(`month-${key}-rejected`).innerHTML = `&#8377; ${rejectedAmt.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
    document.getElementById(`month-${key}-actual`).innerHTML = `&#8377; ${actualAmt.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
    document.getElementById(`month-${key}-percent`).innerHTML = `${outstandingPercent}%`;

      // ✅ MOVE THIS SECTION AFTER THE CUSTOMER LOOP (where counts are calculated)
      // Update count badges - only show if count > 0
      const harvestedCountEl = document.getElementById(`month-${key}-harvested-count`);
      const collectionCountEl = document.getElementById(`month-${key}-collection-count`);
      // const rejectedCountEl = document.getElementById(`month-${key}-rejected-count`);
      const actualCountEl = document.getElementById(`month-${key}-actual-count`);

      harvestedCountEl.textContent = totalStudentsCount;
      collectionCountEl.textContent = collectionCount;
      // rejectedCountEl.textContent = rejectedCount;
      actualCountEl.textContent = harvestedCount;

      // Show/hide badges based on count
      harvestedCountEl.style.display = totalStudentsCount > 0 ? 'inline-block' : 'none';
      collectionCountEl.style.display = collectionCount > 0 ? 'inline-block' : 'none';
      // rejectedCountEl.style.display = rejectedCount > 0 ? 'inline-block' : 'none';
      actualCountEl.style.display = harvestedCount > 0 ? 'inline-block' : 'none';

      // Apply color coding for past months with outstanding amounts
      if ((yy < year || (yy === year && mm < currentMonth)) && harvestedAmt > 0) {
          card.style.backgroundColor = "#ffd6d6";
      }
    }

    document.getElementById("total_outstanding").innerHTML =
      `&#8377; ${grandTotalFromApi.toLocaleString()}`;

    // Add CSS for animated badges
    const style = document.createElement('style');
    style.textContent = `
      .animated-badge-div {
        padding: 2px 6px;
        border-radius: 12px;
        font-size: 0.75rem;
        font-weight: 600;
        display: inline-block;
        animation: badge-pulse 2s infinite;
        vertical-align: middle;
        line-height: 1;
      }
      .harvested-badge {
        background-color: #1890ff;
        color: white;
      }
      .collection-badge {
        background-color: #52c41a;
        color: white;
      }
      .rejected-badge {
        background-color: #9b9999b3;
        color: white;
      }
      .actual-badge {
        background-color: #ff4d4f;
        color: white;
      }
      @keyframes badge-pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
    `;
    document.head.appendChild(style);

    // Scroll to current month
    const scroller = document.querySelector('.scroll-x');
    const currentKey = keyOf(year, currentMonth);
    let currentIdx = timeline.indexOf(currentKey);
    if (currentIdx === -1) currentIdx = Math.min(3, timeline.length - 1);

    const currentCard = monthContainer.children[currentIdx - startIndex];
    if (scroller && currentCard) {
      requestAnimationFrame(() => {
        currentCard.scrollIntoView({ behavior: 'auto', inline: 'start' });
        scroller.scrollLeft = currentCard.offsetLeft;
      });
    }
  }
</script>

@endsection