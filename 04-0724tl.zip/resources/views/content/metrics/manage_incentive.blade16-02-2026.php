@extends('layouts/layoutMaster')

@section('title', 'Manage Incentive')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

<style>
    .table-rule1 tbody,
    tr,
    td,
    tfoot,
    th,
    thead,
    tr {
        border: 1px solid black !important;
    }

    .table-rule1 thead th {
        background: #333;
        color: #fff;
        position: -webkit-sticky;
        position: sticky;
        top: 0;
    }

    th.sticky,
    tbody td:last-child {
        position: -webkit-sticky;
        position: sticky;
        right: 0;
        z-index: 2;
        background: #ccc;
    }

    th.sticky,
    tbody td:first-child {
        position: -webkit-sticky;
        position: sticky;
        left: 0;
        z-index: 2;
        background: #ccc;
    }
</style>
<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h5 class="mb-1">Manage Incentive</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Metrics Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
           <div class="col-lg-6 text-end">
                <label class="mt-1 fs-3 bg-label-info px-2 py-2 rounded" id="branch_name_lab">{{ $branch_common->branch_name??'' }}</label>
            </div>
        </div>
       
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                @php
                $helper = new \App\Helpers\Helpers();
                $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id; // Get branch_id from query or user session
                @endphp
    
                @if(isset($role_permission->manage_branch))
                    @if($role_permission->manage_branch == 2)
                        @php
                            // Get the logged-in user_id
                            $user_id = auth()->user()->user_id;
    
                            // Get the filtered branch and franchise list based on user's multi_branch_access
                            $branch_data = $helper->get_branch_control_list($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                        <select name="branch_id" class="select3 form-select" id="branchSelectsgoal" onchange="branch_change()">
                            @if($user_id == 0)
                            <option value="0" selected>All Branches</option>
                            @endif
                            @if ($branches->isNotEmpty())
                                <optgroup  label="Branches">
                                    @foreach ($branches as $branch)
                                        <!--@ if($branch->sno!=1)-->
                                            <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                {{ $branch->branch_name }}
                                            </option>
                                        <!--@ endif-->
                                    @endforeach
                                </optgroup>
                            @endif
    
    
                            @if ($franchises->isNotEmpty())
                                <optgroup label="Franchises">
                                    @foreach ($franchises as $franchise)
                                        <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                            {{ $franchise->franchise_name }}
                                        </option>
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                        
                    @elseif($role_permission->manage_branch == 1)
    
    
                    @if($branch_common)
                      <div class="d-flex align-items-center mt-2">
                          <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                          <div>
                              <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                              <small class="text-truncate max-w-10px text-muted" title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                              <input type="hidden" name="branch_id"  id="branchSelectsgoal" value="{{$branch_common->sno}}">
                          </div>
                      </div>
    
                        @else
    
                        @endif
                    @endif
    
                @endif
                
            </div>
            <!--<div class="col-lg-3 mb-3">-->
            <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>-->
            <!--    <select id="department_filter" name="department_id" class="select3 form-select" onchange="deptChange()">-->
                    <!-- Options will be dynamically populated -->
            <!--    </select>-->
            <!--</div>-->
            <div class="col-lg-3 mb-3">
                <label class="text-dark mb-1 fs-5 fw-semibold">Role<span class="text-danger">*</span></label>
                <select id="role_filter" name="role_id" class="select3 form-select" onchange="deptChange()">
                    <!-- Options will be dynamically populated -->
                </select>
            </div>
            <div class="col-lg-4 mb-3">
              <div class="nav-align-top my-4">
                  <ul class="nav nav-pills justify-content-start" role="tablist">
                      <!-- Previous Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="prevMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
    
                      <!-- Current Month Display -->
                      <li class="nav-item me-1">
                          <a class="nav-link active px-3 border border-dashed border-info" href="#">
                              <div class="text-center">
                                  <span class="fs-6 fw-semibold text-capitalize" id="selectedMonth">
                                      {{ \Carbon\Carbon::now()->format('F') }}
                                  </span>
                                  <div class="d-block">
                                      <span class="fw-semibold fs-8" id="selectedYear">
                                          ({{ \Carbon\Carbon::now()->year }})
                                      </span>
                                  </div>
                              </div>
                          </a>
                      </li>
    
                      <!-- Next Month Button -->
                      <li class="nav-item me-1">
                          <a class="nav-link px-3" href="#" id="nextMonthBtn">
                              <div class="text-center">
                                  <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                              </div>
                          </a>
                      </li>
                  </ul>
              </div>
            </div>
        </div>
        <div class="row" id="incentiveaccordion"></div>
        <div id="incentiveLoader" class="text-center py-4" style="display: none;">
            <div class="progress" style="height: 20px; width: 50%; margin: auto;">
                <div id="incentiveProgressBar" class="progress-bar progress-bar-striped progress-bar-animated bg-info rounded-pill" 
                    role="progressbar" 
                    style="width: 0%" 
                    aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                    Loading...
                </div>
            </div>
            <div id="incentiveLoadingText" class="mt-2 fw-semibold text-primary">Loading Incentives...</div>
        </div>
    </div>
</div>


<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Converted Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-6">
                        <h5 class="text-center bg-light p-2 rounded fw-bold mb-2 "id="previousMonth">Previous Month Converted Customers</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer Name</th>
                                        <th style="min-width: 250px;">Reason</th>
                                    </tr>
                                </thead>
                                <tbody id="actualDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-6">
                        <h5 class="text-center bg-light p-2 rounded fw-bold mb-2" id="currentMonth">Current Month Converted Customers</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer Name</th>
                                        <th style="min-width: 250px;">Reason</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row mt-4" id="summarySection" style="display: none;">
                    <!-- Previous Month Summary -->
                    <div class="col-md-6 mb-4">
                        <div class="card border border-primary shadow-sm h-100">
                            <div class="card-header bg-primary text-white fw-bold text-center fs-5 rounded-top">
                                Previous Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Converted</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="prevConverted">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Second Payment Pending</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevSecondPay">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Dropouts</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevDrop">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Low MPC</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="prevLmbc">0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <!-- Current Month Summary -->
                    <div class="col-md-6 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Converted</div>
                                            <div class="d-flex justify-content-center align-items-center gap-3 flex-wrap fs-4 fw-bold">
                                                <span class="badge bg-secondary px-4 py-2" id="currConverted">0</span>
                                                <span class="text-dark">−</span>
                                                <span class="badge bg-danger px-4 py-2" id="minusConverted">0</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalConverted">0</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Low MPC</div>
                                            <div class="fs-3 fw-bold badge bg-label-danger" id="currLmbc">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Dropouts</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="currDrop">0</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
</div>
<!--end::Actual Details Modal -->
<!--Actual Calculation Modal -->
<div class="modal fade" id="calculationDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                 <div id="piStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="piStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="piStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="callStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">PI Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Month</th>
                                <th style="min-width: 100px;">Course</th>
                                <th style="min-width: 100px;">Actual</th>
                                <th style="min-width: 100px;">Selling Price</th>
                                <th style="min-width: 250px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody id="calculationDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="calculationDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Calculation Modal -->


<!--Actual ECI Modal -->
<div class="modal fade" id="eciDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="eciStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="eciStaffIntialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="eciStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="eciStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">EcI Calculation Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Created At</th>
                                <th style="min-width: 100px;">Status</th>
                            </tr>
                        </thead>
                        <tbody id="eciDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="eciDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual ECI Modal -->

<!--Actual Call Modal -->
<div class="modal fade" id="callDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="callStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="callStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="callStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="callStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Call Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Created Date</th>
                                <th style="min-width: 100px;">On day</th>
                                <th style="min-width: 100px;">On Month</th>
                                <th style="min-width: 100px;">Old Month</th>
                                <th style="min-width: 100px;">Rewards</th>
                            </tr>
                        </thead>
                        <tbody id="callDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="callDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Call Modal -->

<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCollectionModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CollectionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="CollectionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="CollectionStaffDept" class="badge bg-info mt-1">Collection</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Collection Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-danger p-2 rounded fw-bold mb-2 "id="previousMonth">Old Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="OldDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-success p-2 rounded fw-bold mb-2" id="currentMonth">Current Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="CurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-info p-2 rounded fw-bold mb-2" id="currentMonth">Future Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="FutureDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Collection Summary Bar -->
                <div class="bg-white p-3 mb-4 rounded shadow-sm sticky-top border border-primary" style="top: 0; z-index: 1040; border-width: 2px;">
                    <div class="row text-center fw-bold">
                        <div class="col text-danger border-end fs-5">
                            Old Month<br>
                            ₹<span id="oldAmount">0</span>
                            (<span id="oldPercentage">0</span>%)
                        </div>
                        <div class="col text-success border-end fs-5">
                            Current Month<br>
                            ₹<span id="currentAmount">0</span>
                            (<span id="currentPercentage">0</span>%)
                        </div>
                        <div class="col text-info fs-5 bold">
                            Future Month<br>
                            ₹<span id="futureAmount">0</span>
                            (<span id="futurePercentage">0</span>%)
                        </div>
                    </div>
                </div>
               

            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
</div>
<!--end::Actual Details Modal -->


<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCollectionModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CollectionStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="CollectionStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="CollectionStaffDept" class="badge bg-info mt-1">Collection</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Collection Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-danger p-2 rounded fw-bold mb-2 "id="previousMonth">Old Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="OldDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                
                    <!-- Current Month Table -->
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-success p-2 rounded fw-bold mb-2" id="currentMonth">Current Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="CurrentDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <h5 class="text-center text-white bg-info p-2 rounded fw-bold mb-2" id="currentMonth">Future Month</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 200px;">Customer</th>
                                        <th style="min-width: 100px;">Paid</th>
                                    </tr>
                                </thead>
                                <tbody id="FutureDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- Collection Summary Bar -->
                <div class="bg-white p-3 mb-4 rounded shadow-sm sticky-top border border-primary" style="top: 0; z-index: 1040; border-width: 2px;">
                    <div class="row text-center fw-bold">
                        <div class="col text-danger border-end fs-5">
                            Old Month<br>
                            ₹<span id="oldAmount">0</span>
                            (<span id="oldPercentage">0</span>%)
                        </div>
                        <div class="col text-success border-end fs-5">
                            Current Month<br>
                            ₹<span id="currentAmount">0</span>
                            (<span id="currentPercentage">0</span>%)
                        </div>
                        <div class="col text-info fs-5 bold">
                            Future Month<br>
                            ₹<span id="futureAmount">0</span>
                            (<span id="futurePercentage">0</span>%)
                        </div>
                    </div>
                </div>
               
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Details Modal -->

<!--Actual Details Modal -->
<div class="modal fade" id="actualDetailsCourseModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="CourseStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="CourseStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="CourseStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">SI Customer Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Previous Month Table -->
                    <div class="col-md-12">
                        <h5 class="text-center  bg-light p-2 rounded fw-bold mb-2 "id="strategic_status">Below 25K</h5>
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 150px;">Customer</th>
                                        <th style="min-width: 200px;">service</th>
                                        <th style="min-width: 80px;">Transaction Date</th>
                                        <th style="min-width: 80px;">Amount</th>
                                    </tr>
                                </thead>
                                <tbody id="CrashDetailsBody">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<!--end::Actual Details Modal -->
<div class="modal fade" id="creAwardDetailsModal" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="eciCreStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="eciCreStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="eciCreStaffIntialImage"
                                            class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle"
                                            style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="eciSCRetaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="eciCreStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">10x Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Sno</th>
                                <th style="min-width: 200px;">Customer Name</th>
                                <th style="min-width: 120px;">Service</th>
                                <th style="min-width: 100px;">Expected Date</th>
                                <th style="min-width: 100px;">Amount</th>
                            </tr>
                        </thead>
                        <tbody id="eciCreDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="eciCreDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>

                <div class="row my-3">
                    <div class="col-md-12 mb-4">
                        <div class="card border border-success shadow-sm h-100">
                            <div class="card-header bg-success text-white fw-bold text-center fs-5 rounded-top">
                                Current Month Summary
                            </div>
                            <div class="card-body p-4 bg-light">
                                <div class="row ">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Total Amount</div>
                                            <div class="fs-3 fw-bold badge bg-label-secondary" id="creTotalHarvest">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Pending</div>
                                            <div class="fs-3 fw-bold  badge bg-label-danger" id="creBalance">0</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection</div>
                                            <div class="fs-3 fw-bold  badge bg-label-success" id="creCollection">0</div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="border border-primary border-dashed rounded-3 p-3 text-center">
                                            <div class="fs-6 fw-semibold text-black">Collection Percentage</div>
                                            <div class="d-flex justify-content-center align-items-center gap-2 flex-wrap fs-4 fw-bold">
                                                <span class="text-dark">( </span>
                                                <span class="badge bg-secondary px-4 py-2" id="creCollectionAmount">0</span>
                                                <span class="text-dark">/</span>
                                                <span class="badge bg-danger px-4 py-2" id="creTotalAmount">0</span>
                                                <span class="text-dark"> )</span>
                                                <span class="text-dark"> * 100</span>
                                                <span class="text-dark">=</span>
                                                <span class="badge bg-success px-4 py-2" id="finalCreCollectionPercentage">0%</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Actual Details Modal -->

<div class="modal fade" id="actualJournalDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournal" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournal" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournal" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournal" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournal">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<div class="modal fade" id="actualJournalExtDetailsModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="actualStaffImageJournalExt" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                    <div id="staffInitialImageJournalExt" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="actualStaffNameJournalExt" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="actualStaffDeptJournalExt" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Journal Published Extra Acheivement Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
            
                <div class="row">
                    <!-- Current Month Table -->
                    <div class="col-md-12">
                        
                        <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                            <table class="table table-bordered table-hover table-striped mb-0">
                                <thead class="bg-primary text-white sticky-top">
                                    <tr>
                                        <th style="min-width: 100px;">Journal Id</th>
                                        <th style="min-width: 250px;">Paper</th>
                                        <th style="min-width: 200px;">Service</th>
                                        <th style="min-width: 100px;">Published Date</th>
                                    </tr>
                                </thead>
                                <tbody id="actualCurrentDetailsBodyJournalExt">
                                    <!-- Filled by JS -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
            
            
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>


<div class="modal fade" id="performanceSalesDetails" tabindex="-1"  aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
           <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div id="performcallStaffDetails" class="d-flex align-items-center gap-4 mb-5 border p-3 rounded shadow-sm bg-light">
                  <!-- Staff Image -->
                  <div class="flex-shrink-0">
                    <img id="performcallStaffImage" src="" alt="Staff Image" class="rounded-circle border" style="width: 60px; height: 60px; ">
                     <div id="performcallStaffInitialImage" class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;"></div>
                  </div>
                  
                
                  <!-- Full Width Block -->
                  <div class="w-100">
                    <!-- Row with 3 areas: Left (Info), Center (Heading), Right (Empty for balance) -->
                    <div class="d-flex justify-content-between align-items-center">
                      <!-- Left: Staff Info -->
                      <div class="d-flex flex-column">
                        <div id="performcallStaffName" class="fw-bold fs-5 text-dark">Staff Name</div>
                        <span id="performcallStaffDept" class="badge bg-info mt-1">Department</span>
                      </div>
                
                      <!-- Center: Heading -->
                      <div class="text-center flex-grow-1">
                        <h3 class="mb-0 text-black">Performance Details</h3>
                      </div>
                
                      <!-- Right: Empty block to balance spacing -->
                      <div style="width: 100px;"></div>
                    </div>
                  </div>
                </div>
                
                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-bordered table-hover table-striped mb-0">
                        <thead class="bg-primary text-white sticky-top" style="top: 0; z-index: 5;">
                            <tr>
                                <th>Date</th>
                                <th>Day</th>
                                <th>Outgoing Calls</th>
                                <th>Incoming Calls</th>
                                <th>Missed Calls</th>
                            </tr>
                        </thead>
                        <tbody id="performcallDetailsBody">
                            <!-- Dynamically filled -->
                        </tbody>
                        <tfoot class="bg-light fw-bold text-dark sticky-bottom" style="bottom: 0; z-index: 4;">
                            <tr id="performcallDetailsFooter">
                              <!-- Dynamically filled footer -->
                            </tr>
                          </tfoot>
                    </table>
                </div>
                <div id="performCallCalculationCard"
                    class="card mt-4 border border-primary shadow-sm rounded ">
                    <div class="card-body d-flex justify-content-end align-items-center flex-wrap gap-3 p-2">

                        <div class="card px-6 py-4 rounded shadow-md">
                            <div class="fw-bold text-muted mb-2">Actual Outgoing / Day</div>
                            <span id="actualOutgoingPerDay"
                                class="badge bg-success fs-2 px-4 text-center rounded">
                                0
                            </span>
                        </div>

                        <div class="card px-6 py-4 rounded shadow-md">
                            <div class="fw-bold text-muted mb-2">Missed Call Rate</div>
                            <span id="actualMissedCallRate"
                                class="badge bg-danger rounded fs-2 px-4 text-center">
                                0%
                            </span>
                        </div>

                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.29/jspdf.plugin.autotable.min.js"></script>
 <!--getmetrics-->
<script>
    let incentiveRequest = null;      // jQuery AJAX request tracker
    let incentiveRealController = null; // AbortController for fetch
    let debounceTimer = null;
    
    function fetchIncentivesList() {
        let departmentId = $("#department_filter").val();
        let role_id = $("#role_filter").val();
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
        
        if (incentiveRequest) {
            incentiveRequest.abort(); // cancel the previous request
        }

    
        // Show loader, hide accordion
        $("#incentiveLoader").show();
        $("#incentiveaccordion").hide();
        
        const progressBar = $("#incentiveProgressBar");
        let startTime = Date.now();
        const duration = 55000; // 55 seconds = realistic max load time
        let timer;
    
        function updateProgress() {
            const elapsed = Date.now() - startTime;
            let progress = Math.min((elapsed / duration) * 100, 98); // up to 98%
            progressBar.css("width", `${progress}%`).attr("aria-valuenow", progress.toFixed(0));
            if (progress < 98) {
                timer = requestAnimationFrame(updateProgress);
            }
        }
    
        updateProgress(); // start animation
    
        incentiveRequest =$.ajax({
            url: "{{ route('get-incentive') }}",
            type: "GET",
            data: {
                branch_id: branch_id,
                month: month,
                year: year,
                department_id: departmentId,
                role_id: role_id
            },
            success: function (response) {
                cancelAnimationFrame(timer);
                progressBar.css("width", "100%").attr("aria-valuenow", 100).text("Loading...");
    
                setTimeout(() => {
                    $("#incentiveLoader").hide();
                    $("#incentiveaccordion").show();
                    // Populate your incentives accordion here
                }, 400); // short delay for smooth UX
                    let rowsHtml = '';
        
                    if (response.status === 200 && response.data.length > 0) {
                        window.incentiveData = response.data;
                       response.data.forEach((staff, index) => {
                        let staffId = `collapseStaff${index}`;
                        let tbody = '';
                        let totalAward = 0;
                        let rewardSummary = '';
                        const incentiveNameMap = {
                            tenx_award: '10x',
                            eci: 'ECI',
                            bi: 'BI',
                            si: 'SI',
                            pi: 'PI',
                            sp: 'SP',
                            perform_incent: 'PI',
                            exi: 'EXTRA',
                            doublex: '2X',
                            li: 'LI',
                            ri: 'RI'
                        };
                        const incentiveNameMapInside = {
                            tenx_award: '10x Award',
                            eci: 'ECI (Early Cash Incentive)',
                            bi: 'BI (Bonus Incentive)',
                            si: 'SI (Strategy Incentive)',
                            pi: 'PI (Profitable Incentive)',
                            sp: 'SP (Spot Incentive)',
                            doublex: '2X (Double X Incentive)',
                            exi: 'EXTRA (Extra Acheivement Incentive)',
                            perform_incent: 'PI (Performance Incentive)',
                            li: 'LI (Luxury Incentive)',
                            ri: 'RI (Referral Incentive)'
                        };
                    
                        for (const [key, item] of Object.entries(staff.incentives)) {
                            const rewardValue = Number(item.reward) || 0;
                            totalAward += rewardValue;
                            const valueColor = rewardValue > 0 ? 'bg-success' : 'bg-danger';
                            // Top-level badge summary
                           rewardSummary += `
                                <span class="badge d-inline-flex fw-bold align-items-center ${valueColor} text-white border me-2 mb-1 px-3 py-2 shadow-sm fs-4">
                                    
                                    ${incentiveNameMap[key] || key}: ₹${rewardValue.toLocaleString('en-IN')}
                                </span>
                            `;
                    
                            // Row-wise detailed view
                            
                             const statusIcon = item.status
                                    ? `<a href="javascript:;" class="btn btn-icon btn-sm">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-check-mark-on-green-circle" style="width:40px; height:40px;">
                                            <circle cx="236.5" cy="250" r="200" fill="#39ba77"></circle>
                                            <path fill="#fff" d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z"></path>
                                        </svg>
                                    </a>`
                                    : `<a href="javascript:;" class="btn btn-icon btn-sm">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" id="hand-draw-white-cross-mark-on-red-circle" style="width:40px; height:40px;">
                                            <circle cx="250" cy="250" r="200" fill="#f32f45"></circle>
                                            <path fill="#fff" d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z"></path>
                                        </svg>
                                    </a>`;
                    
                            tbody += `
                                <tr>
                                    <td class="text-start fw-bold fs-3">${incentiveNameMapInside[key] || key}</td>
                                    <td class="text-start text-black fs-5">${item.target}</td>
                                    <td class="text-start fw-semibold ${valueColor} fs-5">${item.actual}</td>
                                    <td>${statusIcon}</td>
                                    <td class="fw-bold fs-4 ${valueColor}">
                                      <span class="badge bg-label-secondary fw-bold  fs-2">₹${rewardValue.toLocaleString('en-IN')}</span>
                                    </td>
                                </tr>
                            `;
                        }
                    
                        // Total row
                        tbody += `
                            <tr class="fw-bold bg-light">
                                <td colspan="4" class="text-end fs-5">Total</td>
                                <td class="fs-4 text-white ${totalAward > 0 ? 'bg-success' : 'bg-danger'}">
                                    ₹${totalAward.toLocaleString('en-IN')}
                                </td>
                            </tr>
                        `;
                    
                        let awardBadge = `<span class="badge  ${totalAward > 0 ? 'bg-success' : 'bg-danger'} ms-2 mx-12 fs-3">
                            ₹${totalAward.toLocaleString('en-IN')}
                        </span>`;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                      
                    
                        rowsHtml += `
                            <div class="accordion-item mb-3 shadow-sm border rounded ${totalAward > 0 ? 'border-success' : 'border-danger'}">
                                <h2 class="accordion-header" id="heading${index}">
                                  <button class="accordion-button collapsed py-4 px-3 d-flex flex-column flex-md-row align-items-start align-items-md-center gap-3 text-start" 
                                    type="button" data-bs-toggle="collapse" 
                                    data-bs-target="#${staffId}" aria-expanded="false" 
                                    aria-controls="${staffId}">
                                
                                    <!-- Staff Image -->
                                      <div class="flex-shrink-0">
                                        ${staffImage 
                                            ? `<img src="/staff_images/${staffImage}" alt="user-avatar" class="rounded-circle" style="width: 60px; height: 60px;" />`
                                            : `<div class="bg-label-info d-flex justify-content-center fs-2 fw-bold align-items-center rounded-circle" style="width: 60px; height: 60px;">
                                                  ${staffName.charAt(0).toUpperCase()}
                                              </div>`
                                        }
                                    </div>
                                
                                    <!-- Staff Info & Rewards -->
                                    <div class="w-100">
                                      <!-- Name and Department -->
                                      <div class="d-flex justify-content-between align-items-start flex-column flex-md-row gap-2">
                                        <div class="d-flex flex-column">
                                          <div class="fw-bold fs-5 text-dark">${staff.staff_name}</div>
                                          <span class="badge bg-info mt-1">${staff.department_name}</span>
                                        </div>
                                        <div class="reward-frame mx-2 ${totalAward >= 10000 ? 'gold' : totalAward >= 5000 ? 'silver' : totalAward > 0 ? 'bronze' : 'fail'}">
                                          <i class="mdi mdi-trophy me-1"></i>
                                          ₹${totalAward.toLocaleString('en-IN')}
                                        </div>
                                      </div>
                                
                                      <!-- Incentive Badges -->
                                      <div class="d-flex flex-wrap gap-2 mt-3">
                                        ${rewardSummary}
                                        ${totalAward > 0 ? `
                                            <div class="ms-auto"> <!-- pushes button to the right -->
                                                <a href="javascript:;" class="download-btn" data-staff-id="${staff.staff_id}" data-month="${month}" data-year="${year}">
                                                    <img src="{{ asset('assets/phdizone_images/download_btn.gif') }}" alt="emoji" style="max-width: 135px; height: 40px;">
                                                </a>
                                            </div>
                                            ` : ''}
                                      </div>
                                    </div>
                                
                                    <!-- Accordion Arrow -->
                                    <span class="accordion-arrow position-absolute end-0 me-2 top-50 translate-middle-y">
                                      <i class="fas fa-chevron-down fs-5 rotate-icon"></i>
                                    </span>
                                  </button>
                                </h2>
                                <div id="${staffId}" class="accordion-collapse collapse" aria-labelledby="heading${index}" data-bs-parent="#incentiveaccordion">
                                    <div class="accordion-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered align-middle text-center mb-2">
                                                <thead class="bg-primary text-white fw-semibold">
                                                    <tr>
                                                        <th>Incentive</th>
                                                        <th class="text-start">Target</th>
                                                        <th class="text-start">Actual</th>
                                                        <th>Status</th>
                                                        <th>Award (₹)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    ${tbody}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                     $('#incentiveaccordion').html(rowsHtml);
                    } else {
                        $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
                    }
                },
            error: function (error) {
               cancelAnimationFrame(timer);
               $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
            //   progressBar.removeClass("bg-primary").addClass("bg-danger").text("Failed");
            },
            complete: function () {
                // Hide loader, show accordion
                $("#incentiveLoader").hide();
                $("#incentiveaccordion").show();
                incentiveRequest = null;
            }
        });
    }

     function fetchIncentiveReal() {
          if (incentiveRealController) {
                incentiveRealController.abort(); // cancel the previous fetch
            }
            incentiveRealController = new AbortController();
        document.getElementById('incentiveLoader').style.display = 'block';
    
        let departmentId = $("#department_filter").val();
        let role_id = $("#role_filter").val();
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        fetch('/fetch-incentive', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({
                branch_id: branch_id,
                month: month,
                year: year,
                department_id: departmentId,
                role_id: role_id
            }),
              signal: incentiveRealController.signal
        })
        .then(response => response.json())
        .then(data => {
            if (data.status) {
                const staffNames = data.staff_names; // array from backend
                const types = data.types;            // array from backend
    
                const queue = [];
    
                // Prepare queue: each staff with each type
                staffNames.forEach((name, i) => {
                    types.forEach((type, j) => {
                        queue.push({ name, type });
                    });
                });
    
                // Display one-by-one with delay
                let i = 0;
                function nextMessage() {
                    if (i < queue.length) {
                        const msg = `${queue[i].name} ${queue[i].type} Calculation...`;
                        document.getElementById('incentiveLoadingText').textContent = msg;
                        i++;
                        setTimeout(nextMessage, 1000); // 1 second delay
                    }
                }
    
                nextMessage(); // Start loop
            }
        })
        .catch(error => {
            
            if (error.name !== 'AbortError') {
                console.error('Fetch error:', error);
                 document.getElementById('incentiveLoadingText').textContent = "No data available";
                    $("#incentiveaccordion").html('<div class="text-center text-muted py-4">No data available</div>');
                    $("#incentiveLoader").hide();
            }
        });
    }

    var currentMonth = new Date().getMonth() + 1; // Get current month (1-12)
    var currentYear = new Date().getFullYear();

    function updateMonthDisplay() {
          clearTimeout(debounceTimer);
        let monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        $("#monthLabel").text(monthNames[currentMonth - 1] + " " + currentYear);
        document.getElementById("selectedMonth").textContent = monthNames[currentMonth - 1];
        document.getElementById("selectedYear").textContent = "(" + currentYear + ")";

        document.getElementById("prevMonthBtn").classList.toggle("disabled", false);
        document.getElementById("nextMonthBtn").classList.toggle("disabled", false);

        debounceTimer = setTimeout(() => {
            fetchIncentivesList();
            fetchIncentiveReal();
        }, 500); 
    }
    fetchRoles();
    
    function fetchRoles() {
          $.ajax({
              url: "{{ route('incentive_role') }}",
              type: "GET",
              success: function (response) {
                  if (response.status === 200 && response.data) {
                      var selectDropdown = $("#role_filter");
                      selectDropdown.empty().append('<option value="">Select Role</option>');

                      // Filter departments with sno 11, 12, 13, 14, 17, 22,15
                      let filteredData = response.data.filter(dept => [11, 12, 14, 16, 22,15,33,35,34,36].includes(dept.sno));

                      filteredData.forEach(function (dept) {
                          selectDropdown.append($('<option></option>')
                              .attr('value', dept.sno)
                              .text(dept.role_name));
                      });

                      // Set default selected value to 12
                      selectDropdown.val(11).trigger('change');
                  }
              },
              error: function (error) {
                  console.error('Error fetching departments:', error);
              }
          });
      }
      
    function fetchDepartments() {
        $.ajax({
            url: "{{ route('departments_setgoal') }}",
            type: "GET",
            success: function (response) {
                if (response.status === 200 && response.data) {
                    let selectDropdown = $("#department_filter");
                    selectDropdown.empty().append('<option value="">Select Department</option>');
    
                    let filteredData = response.data.filter(dept => [11, 12, 14, 16, 22].includes(dept.sno));
    
                    filteredData.forEach(function (dept) {
                        selectDropdown.append(
                            $('<option></option>').val(dept.sno).text(dept.department_name)
                        );
                    });
                    
                   $("#department_filter").val(1).change();
                   
                }
            },
            error: function (error) {
                console.error('Error fetching departments:', error);
            }
        });
    }
   
    function deptChange() {
          fetchIncentivesList();
          fetchIncentiveReal();
    }
    document.getElementById("prevMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 1) {
            currentMonth = 12;
            currentYear--;
        } else {
            currentMonth--;
        }
        updateMonthDisplay();
    });

    document.getElementById("nextMonthBtn").addEventListener("click", function (e) {
        e.preventDefault();
        if (currentMonth === 12) {
            currentMonth = 1;
            currentYear++;
        } else {
            currentMonth++;
        }
        updateMonthDisplay();
    });
    
    
    window.addEventListener("DOMContentLoaded", function () {
        setTimeout(() => {
            fetchIncentivesList();
            fetchIncentiveReal();
        }, 200); // 200ms delay lets the loader show up before hidin
        fetchDepartments();
    });
    
    $(document).on("click", ".download-btn", function () {
    let staffId = $(this).data("staff-id");
    let currentMonthslct = $(this).data("month");
    let currentYearslct = $(this).data("year");
    let staff = window.incentiveData.find(s => s.staff_id == staffId);

    if (!staff) {
        console.error("Staff not found for staffId:", staffId);
        return;
    }

    // Incentive label mapping
    const incentiveLabels = {
        tenx_award: "10x Award",
        eci: "ECI (Early Cash Incentive)",
        bi: "BI (Bonus Incentive)",
        si: "SI (Strategy Incentive)",
        pi: "PI (Profitable Incentive)",
        sp: "SP (Spot Incentive)",
        li: "LI (Luxury Incentive)"
    };

    let rows = [];
    let total = 0;

    for (const [key, item] of Object.entries(staff.incentives)) {
        let rewardValue = Number(item.reward) || 0;
        total += rewardValue;

        let target = cleanText(item.target).replace(/₹/g, "Rs.");
        let actual = cleanText(item.actual).replace(/₹/g, "Rs.");
        let label = incentiveLabels[key] || key;

        rows.push([
            label,
            target,
            actual,
            item.status ? "Achieved" : "Not Achieved",
            `Rs. ${rewardValue.toLocaleString("en-IN")}`
        ]);
    }

    rows.push(["", "", "", "TOTAL", `Rs. ${total.toLocaleString("en-IN")}`]);

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // ✅ Page dimensions
    let pageWidth = doc.internal.pageSize.getWidth();
    let pageHeight = doc.internal.pageSize.getHeight();

    // ✅ Background image (added first)
    let bgUrl = "https://erp.elysiumtechnologies.com/assets/phdizone_images/bg_image/guide_bg.jpg"; 
    doc.setGState(new doc.GState({ opacity: 0.1 })); // subtle opacity
    doc.addImage(bgUrl, "PNG", 0, 0, pageWidth, pageHeight);
    doc.setGState(new doc.GState({ opacity: 1 })); // reset opacity

    // ✅ Company Logo (top-right)
    let logoUrl = "https://erp.elysiumtechnologies.com/assets/phdizone_images/phdizone_logo.png";
    doc.addImage(logoUrl, "PNG", 160, 10, 45, 20);

    // ✅ Title
    doc.setFontSize(18);
    doc.setFont("helvetica", "bold");
    doc.text(`Incentive Summary - ${currentMonthslct} ${currentYearslct}`, 14, 20);

    // ✅ Profile Image (Rounded)
    let profileImg = staff.profile_url || `https://erp.elysiumtechnologies.com/staff_images/${staff.staff_image}`;
   
    let y = 70;
  
    // ✅ Profile Image (Rounded) + Text on same row
    
    let imgX = 14; // left margin
    let imgY = 35; // move image slightly down from top
    let imgSize = 30;
    
    // Draw circle outline for profile image
    doc.setDrawColor(200);
    doc.circle(imgX + imgSize / 2, imgY + imgSize / 2, imgSize / 2, "S");
    
    // Add profile image
    doc.addImage(profileImg, "JPEG", imgX, imgY, imgSize, imgSize, "", "FAST");
    
    // Text positions (stacked vertically)
    let textXLabel = imgX + imgSize + 5;   // label position
    let textXValue = imgX + imgSize + 40;  // value position (so colons align)
    let lineHeight = 6.5;                  // slightly tighter spacing
    let textY = imgY + 5;                   // align text vertically with image
    
    // Set font slightly smaller and normal
    doc.setFontSize(11.5);
    doc.setFont("helvetica", "normal");
    
    // Name
    doc.text("Name :", textXLabel, textY);
    doc.text(`${staff.staff_name}`, textXValue, textY);
    
    // Job Role
    doc.text("Job Role:", textXLabel, textY + lineHeight);
    doc.text(`${staff.department_name}`, textXValue, textY + lineHeight);
    
    // Branch
    doc.text("Branch :", textXLabel, textY + lineHeight * 2);
    doc.text(`${staff.branch_name}`, textXValue, textY + lineHeight * 2);
    
    // Awarded
    doc.text("Awarded:", textXLabel, textY + lineHeight * 3);
    doc.text(`Rs. ${total.toLocaleString("en-IN")}`, textXValue, textY + lineHeight * 3);
    
    // ✅ Table start just below profile info
    let tableStartY = textY + lineHeight * 4 + 5; // small padding after profile
    doc.autoTable({
        head: [["Incentive", "Target", "Actual", "Status", "Award"]],
        body: rows,
        startY: tableStartY,
        theme: "grid",
        headStyles: { fillColor: [52, 152, 219], textColor: 255, fontStyle: 'bold' },
        styles: { fontSize: 10, valign: "middle", overflow: "linebreak", cellPadding: 3 },
        columnStyles: {
            0: { cellWidth: 45 },
            1: { cellWidth: 35 },
            2: { cellWidth: 35 },
            3: { cellWidth: 30, halign: "center" },
            4: { cellWidth: 35, halign: "right" }
        },
        didParseCell: function (data) {
            if (data.section === 'body' && data.column.index === 3) {
                if (data.cell.raw === "Achieved") data.cell.styles.textColor = [40, 167, 69];
                else if (data.cell.raw === "Not Achieved") data.cell.styles.textColor = [220, 53, 69];
            }
            if (data.section === 'body' && data.row.index === rows.length - 1) {
                data.cell.styles.fillColor = [230, 230, 230];
                data.cell.styles.fontStyle = 'bold';
            }
        }
    });

    // ✅ Business Head signature (bottom right)
    let signatureUrl = `https://erp.elysiumtechnologies.com/terms_condition_signature/${staff.bh_signature}`;
    doc.addImage(signatureUrl, "PNG", 140, pageHeight - 40, 50, 20);
    doc.text("Business Head", 150, pageHeight - 12);

    // Save PDF
    doc.save(`${staff.staff_name}_incentives.pdf`);
});

    // Clean HTML → plain
    function cleanText(html) {
        let tmp = document.createElement("div");
        tmp.innerHTML = html;
        tmp.querySelectorAll("span.badge-hover-clickable, label, i").forEach(el => el.remove());
        return (tmp.textContent || tmp.innerText || "").replace(/\s+/g, " ").trim();
    }
    
    function stripHtml(html) {
        let tmp = document.createElement("div");
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || "";
    }
    
    
    
   
    
    function formatDate(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-GB', {
            day: '2-digit',
            month: 'short',
            year: 'numeric'
        }).replace(/ /g, '-');
    }

    function branch_change() {
        const select = document.getElementById('branchSelectsgoal');
        const selectedText = select.options[select.selectedIndex].text;
        // alert("Selected: " + selectedText);
        $('#branch_name_lab').html(selectedText);
        fetchIncentivesList();
        fetchIncentiveReal();
    }
    
    function openActualDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-Convertion-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff_data.staff_image;
                  let staffName = response.staff_data.staff_name || 'No Name Provided';
                  let departmentName = response.staff_data.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImage').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImage').text(initial).removeClass('d-none');
                        $('#actualStaffImage').addClass('d-none');
                    }
                     $('#actualStaffName').text(staffName);
                    $('#actualStaffDept').text(departmentName);
                    
                // if (response.data_prev && response.data_prev.length > 0) {
                //     const staff = response.data_prev[0];
                //     $('#actualStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                //     $('#actualStaffName').text(staff.staff_name);
                //     $('#actualStaffDept').text(staff.department_name);
                // }else{
                //      const staff = response.staff_data;
                //     $('#actualStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                //     $('#actualStaffName').text(staff.staff_name);
                //     $('#actualStaffDept').text(staff.department_name);
                // }
            
                // update Previous Month Heading
                if (response.data_prev && response.data_prev.length > 0) {
                    const prevMonth = response.data_prev[0].month;
                    $("#previousMonth").text(`Previous Month Converted Customers (${prevMonth})`);
                }
            
                // update Current Month Heading
                if (response.data_current && response.data_current.length > 0) {
                    const currMonth = response.data_current[0].month;
                    $("#currentMonth").text(`Current Month Converted Customers (${currMonth})`);
                }
                // Populate Summary
                const prev = response.summary_prev || {};
                const curr = response.summary_current || {};
                
                // Show section if any data exists
                if (prev || curr) {
                    $('#summarySection').show();
                }
                
                $('#prevConverted').text(prev.converted_total ?? '0');
                $('#prevSecondPay').text(prev.second_payment_total ?? '0');
                $('#prevDrop').text(prev.drop_count_total ?? '0');
                $('#prevLmbc').text(prev.lmbc_total ?? '0');
                
                $('#currConverted').text(curr.converted_total_current ?? '0');
                 $('#minusConverted').text(curr.minus_value ?? '0');
                  $('#finalConverted').text(curr.final_value ?? '0');
                $('#currDrop').text(curr.drop_count_current ?? '0');
                $('#currLmbc').text(curr.lmbc_total_current ?? '0');
                // Previous Month Data
               if (response.data_prev && response.data_prev.length > 0) {
                    let prevRows = '';
                    response.data_prev.forEach(item => {
                        prevRows += `<tr>
                            <td class="text-black fw-bold fs-5">${item.customer_name}<br><small class="text-black fw-semibold">${item.mobile}</small><br><span class="fs-8 text-primary">${item.proposalId}</span></td>
                            <td class="${item.reason === 'Successfully Paid MPC And Second Payment' ? 'bg-success text-white fw-bold' : 'bg-danger text-white fw-bold'}">
                                ${item.reason ?? '-'}
                            </td>
                        </tr>`;
                    });
                    $("#actualDetailsBody").html(prevRows);
                } else {
                    $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No previous month records.</td></tr>');
                }
    
                // Current Month Data
                if (response.data_current && response.data_current.length > 0) {
                    let currRows = '';
                    response.data_current.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div class="d-flex gap-1 align-items-start">
                                    <div>
                                        <div ><span class="text-black fw-bold fs-5">${item.customer_name}</span></div>
                                        <div>
                                          <small class="fs-7 text-black fw-semibold">${item.mobile}</small>
                                       </div>
                                       <div class="fs-8 text-primary text-nowrap">${item.proposalId}</div>
                                    </div>
                                   <div class="align-self-center">
                                   ${item.currencyId != 70 ?
                                      ` <span class="badge bg-warning text-black fs-6 "> ${item.currencySymbol} ${item.amount}</span>`
                                      :
                                      ` <span class="badge bg-info text-white fs-6 "> ${item.currencySymbol} ${item.amount}</span>`
                                      }
                                   </div>
                               </div>
                            </td>
                            <td class="${item.reason === 'Successfully Paid MPC Value' ? 'bg-success text-white fw-bold' : 'bg-danger text-white fw-bold'}">
                                ${item.reason ?? '-'}
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBody").html(currRows);
                } else {
                    $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                $("#actualCurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsModal'));
        modal.show();
    }

    function openActualCalculationModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();

        $('#calculationDetailsBody').html('<tr><td colspan="6">Loading...</td></tr>');
        $('#calculationDetailsModal').modal('show');
    
        fetch(`/incentives/pi-calculation?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(res => res.json())
            .then(res => {
                if (res.data && res.data.length > 0) {
                    
                     let staff = res.data[0];
    
                    // Staff details
                    $('#piStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#piStaffName').text(staff.staff_name);
                    $('#piStaffDept').text(staff.department_name);
                    
                    let rows = '';
                    let totalAmount = 0;
        
                    res.data.forEach(item => {
                        const numericProfit = parseFloat(item.profit_loss_amount.replace('+', '').replace(',', ''));
                        const profitClass = numericProfit >= 0 ? 'bg-success text-white' : 'bg-danger text-white';
        
                        rows += `<tr>
                            <td>${item.sno}</td>
                            <td class="text-black fw-bold fs-5">${item.customer_name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                            <td>${item.month}</td>
                            <td>${item.course_name}</td>
                            <td>₹${item.original_amount}</td>
                            <td>₹${item.confirm_amount}</td>
                            <td class="${profitClass} fw-bold"><span class="badge bg-label-secondary fw-bold fs-3">₹${item.profit_loss_amount}</span></td>
                        </tr>`;
        
                        totalAmount += numericProfit;
                    });
        
                    $('#calculationDetailsBody').html(rows);
        
                    // Sticky footer row
                    const footer = `
                        <td colspan="6" class="text-end">Total Profit/Loss</td>
                        <td class="${totalAmount >= 0 ? 'bg-success text-white' : 'bg-danger text-white'}"><span class="badge bg-label-secondary fw-bold fs-3">₹${totalAmount.toFixed(2)}</span></td>
                    `;
                    $('#calculationDetailsFooter').html(footer);
                } else {
                    $('#calculationDetailsBody').html('<tr><td colspan="6">No data found.</td></tr>');
                    $('#calculationDetailsFooter').html('');
                }
            });
    }
    
    function openActualECIDetailsModal(staffId) {
        console.log('Opening modal...');
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let branch_id = $("#branchSelectsgoal").val();
        
           
            const modal = new bootstrap.Modal(document.getElementById('eciDetailsModal'));
            modal.show();
        
            $('#eciDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
            $('#eciDetailsFooter').html('');
        
            fetch(`/incentives/eci-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
                .then(res => res.json())
                .then(res => {
                    if(res.staff){
                        let staff = res.staff;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                        
                        if (staff.staff_image) {
                                $('#eciStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                                $('#eciStaffIntialImage').addClass('d-none');
                            } else {
                                // Show initial instead of image
                                // alert('no image')
                                let initial = staffName.charAt(0).toUpperCase();
                                // alert(initial)
                                $('#eciStaffIntialImage').text(initial).removeClass('d-none');
                                $('#eciStaffImage').addClass('d-none');
                            }

                        // Set staff details at top
                        // $('#eciStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                        $('#eciStaffName').text(staff.staff_name);
                        $('#eciStaffDept').text(staff.department_name);
                    }else{
                          $('#eciStaffImage').attr('src', '');
                            $('#eciStaffName').text('Staff Name');
                            $('#eciStaffDept').text('Department');
                    }
                    if (res.data && res.data.length > 0) {

                        let rows = '';
                        res.data.forEach(item => {
                           let badgeClass = item.status === 'Converted' ? 'bg-success' : 'bg-danger';
                            rows += `<tr>
                                <td>${item.sno}</td>
                                <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                                <td>${item.course}</td>
                                <td>${item.created_at}</td>
                                <td><span class="badge ${badgeClass}">${item.status}</span></td>
                            </tr>`;
                        });
        
                        $('#eciDetailsBody').html(rows);
        
                        // Optionally: Footer total
                        $('#eciDetailsFooter').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                    } else {
                        $('#eciDetailsBody').html('<tr><td colspan="5">No data found.</td></tr>');
                    }
                })
                .catch(err => {
                    console.error(err);
                    $('#eciDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
                });
    }
    
     // cre 10x details
    function openCreActualDetailsModal(staffId) {
        console.log('Opening modal...');
            let month = $("#selectedMonth").text().trim();
            let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
            let branch_id = $("#branchSelectsgoal").val();
        
           
            const modal = new bootstrap.Modal(document.getElementById('creAwardDetailsModal'));
            modal.show();
        
            $('#eciCreDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
            $('#eciCreDetailsFooter').html('');
        
                fetch(`/incentives/cre-10x-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
                .then(res => res.json())
                .then(res => {
                    if(res.staff){
                        let staff = res.staff;
                        
                        let staffImage = staff.staff_image;
                        let staffName = staff.staff_name || 'No Name Provided';
                        
                        if (staff.staff_image) {
                                $('#eciCreStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                                $('#eciCreStaffIntialImage').addClass('d-none');
                            } else {
                                // Show initial instead of image
                                // alert('no image')
                                let initial = staffName.charAt(0).toUpperCase();
                                // alert(initial)
                                $('#eciCreStaffIntialImage').text(initial).removeClass('d-none');
                                $('#eciCreStaffImage').addClass('d-none');
                            }

                        // Set staff details at top
                        // $('#eciStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                        $('#eciCreStaffName').text(staff.staff_name);
                        $('#eciCreStaffDept').text(staff.department_name);
                    }else{
                          $('#eciCreStaffImage').attr('src', '');
                            $('#eciCreStaffName').text('Staff Name');
                            $('#eciCreStaffDept').text('Department');
                    }

                    $('#creTotalHarvest').text(res.harvesting_amount ?'₹ '+res.harvesting_amount : '₹0');
                    $('#creBalance').text(res.balance_amount?'₹ '+res.balance_amount : '₹0');
                    $('#creCollection').text(res.collection_amount ? '₹ '+res.collection_amount : '₹0');
                    $('#creCollectionAmount').text(res.collection_amount?'₹ '+res.collection_amount : '₹0');
                    $('#creTotalAmount').text(res.harvesting_amount ? '₹ '+res.harvesting_amount : '₹0');
                    $('#finalCreCollectionPercentage').text(res.harvestingPercentage +'%' ?? '0%');

                    if (res.data && res.data.length > 0) {

                        let rows = '';
                        res.data.forEach(item => {
                           let badgeClassCurrency = item.currency_code === 'INR' ? 'bg-secondary text-white' : 'bg-warning text-black';
                            rows += `<tr class="${item.payment_status == 0 ? 'bg-danger text-white':''} ">
                                <td>${item.sno}</td>
                                <td class="text-black fw-bold fs-5">${item.name}<br><small class="text-black fw-semibold">${item.mobile}</small></td>
                                <td>${item.course}</td>
                                <td>
                                    <span class="text-nowrap">${item.miletone_date} </span>
                                    <div class="text-center">
                                        <span class="fs-8 badge ${badgeClassCurrency}">${item.currency_code}</span>
                                    </div>
                                </td>
                                <td>
                                <span class="badge  ${item.payment_status == 0 ? 'bg-warning text-white':'bg-success'}">₹ ${item.net_amount}</span>
                                    <span class="text-nowrap d-block">${item.payment_status == 0 ? '-':item.created_at } </span>
                                </td>
                            </tr>`;
                        });
        
                        $('#eciCreDetailsBody').html(rows);
        
                        // Optionally: Footer total
                        $('#eciCreDetailsFooter').html(`<td colspan="5">Total Records: ${res.data.length}</td>`);
                    } else {
                        $('#eciCreDetailsBody').html('<tr><td colspan="5">No data found.</td></tr>');
                    }
                })
                .catch(err => {
                    console.error(err);
                    $('#eciCreDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
                });
    }
    
    function openManageCallModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        const modal = new bootstrap.Modal(document.getElementById('callDetailsModal'));
        modal.show();
    
        $('#callDetailsBody').html('<tr><td colspan="7">Loading...</td></tr>');
        $('#callDetailsFooter').html('');
    
        fetch(`/incentives/call-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(response => response.json())
            .then(response => {
                console.log('API Response:', response); // Debug
    
                if (response.data && response.data.length > 0) {
                    let staff = response.data[0];
    
                    // Staff details
                    $('#callStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#callStaffName').text(staff.staff_name);
                    $('#callStaffDept').text(staff.department_name);
    
                    let rows = '';
                    let grandTotalReward = 0;

                    response.data.forEach(item => {
                        // Sum up the rewards
                        grandTotalReward += item.Rewards ?? 0;
                        rows += `
                            <tr>
                              <td>${item.sno}</td>
                              <td><b>${item.name}</b><br><small>${item.mobile}</small></td>
                              <td>${item.created_at}</td>
                              <td>${item.on_day}</td>
                              <td>${item.on_month}</td>
                              <td>${item.old_month} ${item.otherstaff ? '<i class="mdi mdi-cellphone-off text-success"></i>' : ''}</td>
                              <td class="fw-bold fs-4 bg-${item.Rewards > 0 ? 'success' : 'danger'}"><span class="badge bg-label-secondary fw-bold  fs-2">${item.Rewards}</span></td>
                            </tr>
                        `;
                    });
    
                    $('#callDetailsBody').html(rows);
    
                    // correct footer rendering
                    $('#callDetailsFooter').html(`
                        <td colspan="4" class="text-start fw-bold text-primary fs-4">Total Records: ${response.data.length}</td>
                        <td colspan="3" class="text-end fw-bold text-primary fs-4">Grand Total Reward: ₹${grandTotalReward}</td>
                    `);
                } else {
                    $('#callStaffImage').attr('src', '');
                    $('#callStaffName').text('Staff Name');
                    $('#callStaffDept').text('Department');
                    $('#callDetailsBody').html('<tr><td colspan="7">No data found.</td></tr>');
                }
            })
            .catch(err => {
                console.error('Fetch error:', err);
                $('#callDetailsBody').html('<tr><td colspan="7">Something went wrong.</td></tr>');
            });
    }
    
    function openActualCollectionModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#OldDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#CurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-Collection-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
               if (response.staff) {
                    const staff = response.staff;
                    $('#CollectionStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#CollectionStaffName').text(staff.staff_name);
                    $('#CollectionStaffDept').text(staff.department_name);
                }
            
                
               // Populate Collection Amount and Percentage Summary
                $('#oldAmount').text(response.old_amount?.collection ?? '0');
                $('#oldPercentage').text(response.old_amount?.percentage ?? '0');
                
                $('#currentAmount').text(response.current_amount?.collection ?? '0');
                $('#currentPercentage').text(response.current_amount?.percentage ?? '0');
                
                $('#futureAmount').text(response.future_amount?.collection ?? '0');
                $('#futurePercentage').text(response.future_amount?.percentage ?? '0');
                // Previous Month Data
                if (response.old_amount && response.old_amount.customers?.length > 0) {
                    let prevRows = '';
                    response.old_amount.customers.forEach(item => {
                        prevRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-danger text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#OldDetailsBody").html(prevRows);
                } else {
                    $("#OldDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No previous month records.</td></tr>');
                }
    
                // Current Month Data
                if (response.current_amount && response.current_amount.customers?.length > 0) {
                    let currRows = '';
                    response.current_amount.customers.forEach(item => {
                        currRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-success text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#CurrentDetailsBody").html(currRows);
                } else {
                    $("#CurrentDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
                
                if (response.future_amount && response.future_amount.customers?.length > 0) {
                    let futurRows = '';
                    response.future_amount.customers.forEach(item => {
                        futurRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                            <td class="text-black fw-bold fs-5">
                                  <span class="badge bg-info text-white fs-5 ms-2">₹${item.paidAmount}</span>
                            </td>
                        </tr>`;
                    });
                    $("#FutureDetailsBody").html(futurRows);
                } else {
                    $("#FutureDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualDetailsCollectionModal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                $("#FutureDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsCollectionModal'));
        modal.show();
    }
    
    function openCourseDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#CrashDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#ProfessinalDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $("#TesboDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
        $.ajax({
            url: `/get-course-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
               if (response.staff) {
                    const staff = response.staff;
                    $('#CourseStaffImage').attr('src', '/staff_images/' + staff.staff_image);
                    $('#CourseStaffName').text(staff.staff_name);
                    $('#CourseStaffDept').text(staff.department_name);
                }
            
                
               // Populate Collection Amount and Percentage Summary
                $('#crashCount').text(response.crash_course?.count ?? '0');
                $('#crashPercentage').text(response.crash_course?.percentage ?? '0');
                
                $('#professionalCount').text(response.professional_course?.count ?? '0');
                $('#professionalPercentage').text(response.professional_course?.percentage ?? '0');
                
                $('#tesboCount').text(response.tesbo_course?.count ?? '0');
                $('#tesboPercentage').text(response.tesbo_course?.percentage ?? '0');
                // Previous Month Data
                if (response.crash_course && response.crash_course.customers?.length > 0) {
                    let prevRows = '';
                    response.crash_course.customers.forEach(item => {
                        prevRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-6">
                                  ${item.course_name}
                            </td>
                        </tr>`;
                    });
                    $("#CrashDetailsBody").html(prevRows);
                } else {
                    $("#CrashDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No previous month records.</td></tr>');
                }
    
                // Current Month Data
                if (response.professional_course && response.professional_course.customers?.length > 0) {
                    let currRows = '';
                    response.professional_course.customers.forEach(item => {
                        currRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                              <td class="text-black fw-bold fs-6">
                                  ${item.course_name}
                            </td>
                        </tr>`;
                    });
                    $("#ProfessinalDetailsBody").html(currRows);
                } else {
                    $("#ProfessinalDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
                
                if (response.tesbo_course && response.tesbo_course.customers?.length > 0) {
                    let futurRows = '';
                    response.tesbo_course.customers.forEach(item => {
                        futurRows += `<tr>
                            <td class="text-black fw-bold fs-5">
                              ${item.cus_name}
                            </td>
                             <td class="text-black fw-bold fs-6">
                                  ${item.course_name}
                            </td>
                        </tr>`;
                    });
                    $("#TesboDetailsBody").html(futurRows);
                } else {
                    $("#TesboDetailsBody").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                // $("#actualDetailsCourseModal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
                // $("#TesboDetailsBody").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualDetailsCourseModal'));
        modal.show();
    }
    
</script>
    <style>
   

    .reward-frame {
      font-size: 1.3rem;
      font-weight: bold;
      padding: 8px 16px;
      border-radius: 12px;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
      animation: glow 1.5s infinite alternate;
    }
    
    .reward-frame.gold {
      background: linear-gradient(to right, #ffd700, #ffac33);
      color: #000;
      box-shadow: 0 0 12px #ffd700;
    }
    
    .reward-frame.silver {
      background: linear-gradient(to right, #c0c0c0, #aaaaaa);
      color: #000;
      box-shadow: 0 0 10px #c0c0c0;
    }
    
    .reward-frame.bronze {
      background: linear-gradient(to right, #cd7f32, #b87333);
      color: #fff;
      box-shadow: 0 0 8px #cd7f32;
    }
    
    .reward-frame.fail {
      background-color: #dc3545;
      color: #fff;
      box-shadow: none;
      animation: none;
    }
    
    @keyframes glow {
      from {
        transform: scale(1);
        box-shadow: 0 0 10px rgba(255, 215, 0, 0.5);
      }
      to {
        transform: scale(1.05);
        box-shadow: 0 0 20px rgba(255, 215, 0, 0.9);
      }
    }


    .accordion-button.collapsed .rotate-icon {
        transform: rotate(0deg);
        transition: transform 0.3s ease;
    }
    .accordion-button:not(.collapsed) .rotate-icon {
        transform: rotate(180deg);
        transition: transform 0.3s ease;
    }
    #actualDetailsBody td {
        vertical-align: middle;
        height: 60px;
    }
    .badge-hover-clickable {
        transition: all 0.2s ease;
        border: 2px solid transparent;
    }
    
    .badge-hover-clickable:hover {
        border: 2px solid #0d6efd; /* Bootstrap primary */
        background-color: #e0f2ff; /* light blue */
        box-shadow: 0 0 8px rgba(13, 110, 253, 0.2); /* subtle glow */
        transform: scale(1.03);
        cursor: pointer;
    }
    
    

</style>
<!--Create Dashboards Accordion Start-->
<script>
    'use strict';
    (function() {
        const sgr1 = [].slice.call(document.querySelectorAll('.sgr1'));
        // Collapsible card
        // --------------------------------------------------------------------
        if (sgr1) {
            sgr1.map(function(sgr1_Element) {
                sgr1_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(sgr1_Element.closest('.card').querySelector('.collapse.sgr1_body'));
                    // Toggle collapsed class in `.card-header` element
                    sgr1_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(sgr1_Element.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();
</script>
<!--Create Dashboards Accordion End-->
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    function openActualJournalDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');
    
        $.ajax({
            url: `/get-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournal').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournal').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournal').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournal').addClass('d-none');
                    }
                     $('#actualStaffNameJournal').text(staffName);
                    $('#actualStaffDeptJournal').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        currRows += `<tr>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-success fw-bold fs-6">${item.publish_date}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournal").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournal").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalDetailsModal'));
        modal.show();
    }

    function openActualExtraJournalDetailsModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-muted">Loading...</td></tr>');

        $.ajax({
            url: `/get-journal-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`,
            method: 'GET',
            success: function (response) {
                 // Staff Details
                  let staffImage = response.staff.staff_image;
                  let staffName = response.staff.staff_name || 'No Name Provided';
                  let departmentName = response.staff.department_name || '';
                  if (staffImage) {
                        $('#actualStaffImageJournalExt').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#staffInitialImageJournalExt').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#staffInitialImageJournalExt').text(initial).removeClass('d-none');
                        $('#actualStaffImageJournalExt').addClass('d-none');
                    }
                     $('#actualStaffNameJournalExt').text(staffName);
                    $('#actualStaffDeptJournalExt').text(departmentName);

                // Current Month Data
                if (response.data && response.data.length > 0) {
                    let currRows = '';
                    response.data.forEach(item => {
                        let badgeClass = item.status === 'Eligible' ? 'bg-success' : 'bg-danger';
                        currRows += `<tr class="">
                            <td class="">
                                <div><span class="text-black fw-semibold fs-6">${item.journal_id}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-semibold fs-7">${item.paper_name}</span></div>
                            </td>
                            <td class="">
                                <div><span class="text-black fw-bold fs-6">${item.service_title}</span></div>
                            </td>
                            <td class="${badgeClass}">
                                <div><span class="text-white  fw-bold fs-6 ">${item.publish_date}</span></div>
                            </td>
                        </tr>`;
                    });
                    $("#actualCurrentDetailsBodyJournalExt").html(currRows);
                } else {
                    $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-muted">No current month records.</td></tr>');
                }
            },
            error: function () {
                $("#actualCurrentDetailsBodyJournalExt").html('<tr><td colspan="4" class="text-center text-danger">Error loading data.</td></tr>');
            }
        });
    
        const modal = new bootstrap.Modal(document.getElementById('actualJournalExtDetailsModal'));
        modal.show();
    }
</script>
<script>
    function openPerformCallModal(staffId) {
        let month = $("#selectedMonth").text().trim();
        let year = $("#selectedYear").text().trim().replace(/[()]/g, '');
        let branch_id = $("#branchSelectsgoal").val();
    
        const modal = new bootstrap.Modal(document.getElementById('performanceSalesDetails'));
        modal.show();
    
        $('#performcallDetailsBody').html('<tr><td colspan="5">Loading...</td></tr>');
        $('#performcallDetailsFooter').html('');
    
        fetch(`/incentives/performance-call-list?staff_id=${staffId}&month=${month}&year=${year}&branch_id=${branch_id}`)
            .then(response => response.json())
            .then(response => {
                console.log('API Response:', response); // Debug

                  let staffImage = response.StaffData.staff_image;
                  let staffName = response.StaffData.staff_name || 'No Name Provided';
                  let departmentName = response.StaffData.department_name || '';

                     let rows = '';
                    let totalOutgoing = 0;
                    let totalMissed = 0;
                  if (staffImage) {
                        $('#performcallStaffImage').attr('src', `{{ asset('staff_images') }}/${staffImage}`).removeClass('d-none');
                        $('#performcallStaffInitialImage').addClass('d-none');
                    } else {
                        // Show initial instead of image
                        // alert('no image')
                        let initial = staffName.charAt(0).toUpperCase();
                        // alert(initial)
                        $('#performcallStaffInitialImage').text(initial).removeClass('d-none');
                        $('#performcallStaffImage').addClass('d-none');
                    }
                     $('#performcallStaffName').text(staffName);
                    $('#performcallStaffDept').text(departmentName);
    
                response.days.forEach(item => {
                    totalOutgoing += item.outgoing;
                    totalMissed += item.missed;

                    rows += `
                        <tr>
                            <td>${item.date}</td>
                            <td>${item.day}</td>
                            <td class="fw-bold text-success">${item.outgoing}</td>
                            <td>${item.incoming}</td>
                            <td class="fw-bold text-danger">${item.missed}</td>
                        </tr>
                    `;
                });
                $('#performcallDetailsBody').html(rows);

                $('#performcallDetailsFooter').html(`
                    <td colspan="2">Total Days: ${response.summary.working_days}</td>
                    <td class="text-success">Total: ${totalOutgoing}</td>
                    <td></td>
                    <td class="text-danger">Total: ${totalMissed}</td>
                `);

                $('#actualOutgoingPerDay').text(
                    response.summary.actual_outgoing_per_day
                );

                $('#actualMissedCallRate').text(
                    response.summary.actual_missed_call_rate + '%'
                );

               

                // if (response.summary.actual_missed_call_rate <= targetMissedRate) {
                //     $('#actualMissedCallRate').removeClass('bg-danger').addClass('bg-success');
                // }
            })
            .catch(err => {
                console.error('Fetch error:', err);
                $('#performcallDetailsBody').html('<tr><td colspan="5">Something went wrong.</td></tr>');
            });
    }
</script>

@endsection