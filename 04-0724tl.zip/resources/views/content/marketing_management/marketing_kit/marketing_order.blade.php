@extends('layouts/layoutMaster')

@section('title', 'Manage Orders')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/rateyo/rateyo.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/rateyo/rateyo.js',
])
@endsection


@section('content')
<style>
  .list_page thead th,
  .list_page tbody td,
  .list_page tfoot th {
    padding: 7px !important;
  }
</style>
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-0">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Orders</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-chevron-double-right fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <!--<div class="card-action-element">-->
    <!--  <div class="d-flex justify-content-end align-items-center mb-0 gap-1">-->
    <!--    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">-->
    <!--      <span><i class="mdi mdi-filter-outline"></i></span>-->
    <!--    </a>-->
    <!--  </div>-->
    <!--</div>-->
  </div>
  <div class="card-body">
    <div class="filter_tbox" style="display: none;">
      <div class="row py-1">
        <div class="col-lg-6 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Vendors</label>
          <select id="" class="select3 form-select">
            <option value="" selected>All</option>
            <option value="1">Eibs Developers - Elysium Academy Cit Nagar - 9715631759</option>
            <option value="2">Krishnaveni - Elysium Academy Virudhunagar - 7598059545</option>
            <option value="3">Abirami - Elysium Academy Perambalur - 9003259988</option>
            <option value="4">Ramkumar - Elysium Academy Coimbatore - 9789970074</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
          <select class="select3 form-select">
            <option value="" selected>All</option>
            <option value="1">Preparing Orders</option>
            <option value="2">Order Delivered</option>
            <option value="3">Pending Feedback</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
          <select class="select3 form-select" name="dt_fill_coup" id="dt_fill_coup" onchange="date_fill_coup();">
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="monthly">This Month</option>
            <option value="custom_date">Custom Date</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2" id="today_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_today_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_from_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_week_st_dt_fill_coup" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_to_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_week_ed_dt_fill_coup" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="monthly_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="from_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_custom_from_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="to_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_custom_to_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-end align-items-center">
        <button type="reset" class="btn btn-sm btn-secondary me-3" data-bs-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-sm btn-primary" data-bs-dismiss="modal">Go</button>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          @php
              // Check if any order in the order list is for the logged-in user
              $is_user_order = false;
              foreach($order_list as $olist) {
                  if(auth()->user()->user_id == $olist->user_id) {
                      $is_user_order = true;
                      break;
                  }
              }
          @endphp
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              @if(!$is_user_order)  <!-- Condition to check if the current user is part of any order -->
                <th class="min-w-150px">Vendors</th>
                <th class="min-w-125px">Delivery Address</th>
                <th class="min-w-100px">Order Date</th>
                <th class="min-w-100px">Order / Courier ID</th>
                <th class="min-w-80px text-center">Count</th>
                <th class="min-w-100px text-center">Total Amt</th>
                <th class="min-w-125px">Status</th>
                <th class="min-w-80px text-center">Actions</th>
              @else
                <th class="min-w-100px">Order / Courier ID</th>
                <th class="min-w-125px">Delivery Address</th>
                <th class="min-w-100px">Order Date</th>
                <th class="min-w-80px text-center">Count</th>
                <th class="min-w-100px text-center">Total Amt</th>
                <th class="min-w-125px">Status</th>
                <th class="min-w-80px text-center">Actions</th>
              @endif
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if(isset($order_list))
            @foreach($order_list as $i => $olist)
            @if(!$is_user_order) 
            <tr>
              <td>
                <div class="d-flex align-items-center px-1">
                  @if ($olist->staff_image != ' ' && file_exists(public_path('staff_images/' . $olist->staff_image)))
                    <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true">
                            <img src="{{ asset('staff_images/' . $olist->staff_image) }}"
                                alt="user-avatar" class="image-input-wrapper w-45px h-45px"
                                id="uploadedlogo" />
                        </div>
                    </div>
                    @else
                    <div class="symbol symbol-35px me-2">
                        @php
                        $initial = strtoupper(substr($olist->nick_name, 0, 1)); // Only keeps and
                        // capitalizes the first
                        echo $helper->name_image($initial, $olist->gender);
                        @endphp
                    </div>
                  @endif
                  <div class="mb-0">
                    <label class="fw-semibold fs-7 text-black">{{ $olist->staff_name ?? '-' }}</label>
                    <div class="d-block text-primary fs-8">
                      @if ($olist->branch_type == 1)
                        @php
                        $delete_name = $olist->branch_name;
                        @endphp
                          <label class="fs-8 text-dark fw-semibold text-truncate max-w-125px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $olist->branch_name }}">{{ $olist->branch_name ?? '-' }}</label>
                          <label class="badge bg-warning fw-semibold fs-8 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch">B</label>
                        @else
                        @php
                        $delete_name = $olist->franchise_name;
                        @endphp
                          <label class="fs-8 text-dark fw-semibold text-truncate max-w-125px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $olist->franchise_name }}">{{ $olist->franchise_name  ?? '-' }}</label>
                          <label class="badge bg-info fw-semibold fs-8 text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Franchise">F</label>
                      @endif
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <div class="text-wrap max-w-250px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $olist->user_address }}">{{ $olist->user_address ?? '-' }}</div>
              </td>
              <td>
                <label class="fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Order Date">{{ date('d-M-Y', strtotime($olist->order_date)) }}</label>
                @if($olist->status == 4)
                <div class="d-block">
                  <label class="badge bg-success text-black rounded-pill fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered Date">{{ date('d-M-Y', strtotime($olist->delivered_date)) }}</label>
                </div>
                @endif
              </td>
              <td>
                <label class="fw-semibold fs-7">{{ $olist->order_id ?? '-' }}</label>
                @if($olist->courier_id)
                <div class="d-block text-primary fs-8">
                  <label class="fs-8 text-dark fw-semibold text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Courier Tracking ID">{{ $olist->courier_id ?? '-' }}</label>
                </div>
                @endif
              </td>
              <td align="center">
                <label class="badge bg-secondary rounded-pill fw-semibold fs-7">{{ sprintf('%02d', $olist->count) }}</label>
              </td>
              <td align="right">
                <label class="fw-semibold fs-6">&#8377;{{ number_format($olist->total_amount ?? 0) }}</label>
              </td>
              <td>
                @if($olist->status == 4)
                  <div class="badge bg-success rounded text-black fw-semibold fs-7">Order Delivered</div>
                  <div class="d-flex align-items-center gap-1 mt-1">
                    <div class="ord_rat_list{{$i}} z-0 mb-1" data-rateyo-read-only="true"></div>
                      <div class="ms-2 me-2 fs-7 text-dark fw-semibold text-center">
                          <label class="badge bg-info">{{ $olist->order_rating }} / 5</label>
                      </div>
                  </div>
                @else
                  <a class="@if($olist->status == 4)cursor-pointer @endif badge bg-warning rounded" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="text-black fw-semibold fs-7">Preparing Orders</span>
                  </a>
                  @if($olist->status == 3)
                  <div class="dropdown-menu dropdown-menu-end">
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_order_delivered" onclick="deliverOrder('{{ $olist->sno }}', '{{ $olist->order_id }}', '{{ $olist->staff_name }}', '{{ $olist->branch_name ? $olist->branch_name : $olist->franchise_name }}')">
                      Order Delivered
                    </a>
                  </div>
                  @endif
                @endif
              </td>
              <td>
                <div class="text-center">
                  <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_orders" onclick="viewOrder('{{ $olist->sno }}')">
                    <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                  </a>
                    {{-- <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_orders_feedback" onclick="orderFeedback('{{ $olist->sno }}')">
                      <i class="mdi mdi-comment-quote-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback"></i>
                    </a> --}}
                    @if($olist->status <= 3)
                    <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_update_orders" onclick="orderEdit('{{ $olist->sno }}')">
                      <i class="mdi mdi-square-edit-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"></i>
                    </a>
                    @endif
                </div>
              </td>
            </tr>
            @else
            <tr>
              <td>
                <label class="fw-semibold fs-7">{{ $olist->order_id ?? '-' }}</label>
                @if($olist->courier_id)
                <div class="d-block text-primary fs-8">
                  <label class="fs-8 text-dark fw-semibold text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Courier Tracking ID">{{ $olist->courier_id ?? '-' }}</label>
                </div>
                @endif
              </td>
              <td>
                <div class="text-wrap max-w-250px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $olist->user_address }}">{{ $olist->user_address ?? '-' }}</div>
              </td>
              <td>
                <label class="fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Order Date">{{ date('d-M-Y', strtotime($olist->order_date)) }}</label>
                @if($olist->status == 4)
                <div class="d-block">
                  <label class="badge bg-success text-black rounded-pill fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered Date">{{ date('d-M-Y', strtotime($olist->delivered_date)) }}</label>
                </div>
                @endif
              </td>
              <td align="center">
                <label class="badge bg-secondary rounded-pill fw-semibold fs-7">{{ sprintf('%02d', $olist->count) }}</label>
              </td>
              <td align="right">
                <label class="fw-semibold fs-6">&#8377;{{ number_format($olist->total_amount ?? 0) }}</label>
              </td>
              <td>
                @if($olist->status == 4)
                  <div class="badge bg-success rounded text-black fw-semibold fs-7">Order Delivered</div>
                  <div class="d-flex align-items-center gap-1 mt-1">
                    <div class="ord_rat_list{{$i}} z-0 mb-1" data-rateyo-read-only="true"></div>
                      <div class="ms-2 me-2 fs-7 text-dark fw-semibold text-center">
                          <label class="badge bg-info">{{$olist->order_rating}} / 5</label>
                      </div>
                  </div>
                @else
                  <a class="badge bg-warning rounded" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <span class="text-black fw-semibold fs-7">Preparing Orders</span>
                  </a>
                  {{-- <div class="dropdown-menu dropdown-menu-end">
                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_order_delivered" onclick="deliverOrder('{{ $olist->sno }}', '{{ $olist->order_id }}', '{{ $olist->staff_name }}', '{{ $olist->branch_name ? $olist->branch_name : $olist->franchise_name }}')">
                      Order Delivered
                    </a>
                  </div> --}}
                @endif
              </td>
              <td>
                <div class="text-center">
                  <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_orders" onclick="viewOrder('{{ $olist->sno }}')">
                    <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                  </a>
                  @if($olist->status > 3)
                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_orders_feedback" onclick="orderFeedback('{{ $olist->sno }}')">
                      <i class="mdi mdi-comment-quote-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback"></i>
                    </a>
                  @endif
                </div>
              </td>
            </tr>
            @endif
            @endforeach
            @endif
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<!--begin::Modal - Update Orders-->
<div class="modal fade" id="kt_modal_update_orders" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Orders</h3>
        </div>
        <form id="updateOrderForm" action="{{ route('update_order') }}" method="POST" onsubmit="return AddvalidateForm()" novalidate>
          @csrf
          <input type="hidden" id="order_edit_sno" name="order_edit_sno">
          <div class="row mb-3">
            <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
            <label class="col-1 text-black fs-6 fw-bold">:</label>
            <label class="col-8 text-black fs-6 fw-bold" id="edit_order_date"></label>
          </div>
          <div class="row mb-3">
            <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
            <label class="col-1 text-black fs-6 fw-bold">:</label>
            <label class="col-8 text-black fs-6 fw-bold" id="edit_order_id">ORD-0003/25</label>
          </div>
          <div class="row mb-3">
            <div class="col-lg-12 mb-2">
              <label class="text-dark mb-1 fs-6 fw-semibold">Courier Name<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="order_courier_name" name="order_courier_name" placeholder="Enter Courier Name" value="" />
              <div class="text-danger" id="courier_name_err"></div>
            </div>
            <div class="col-lg-12 mb-2">
              <label class="text-dark mb-1 fs-6 fw-semibold">Courier Tracking ID<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="courier_tracking_id" name="courier_tracking_id" placeholder="Enter Courier Tracking ID" value="" />
              <div class="text-danger" id="courier_tracking_id_err"></div>
            </div>
          </div>
          <div class="d-flex justify-content-center align-items-center mt-6">
            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
            <button type="submit" class="btn btn-primary">Update Orders</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Orders-->

<!--begin::Modal - View Orders-->
<div class="modal fade" id="kt_modal_view_orders" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">
            <span>View Orders</span>
            <span class="ms-1 me-1">-</span>
            <span class="badge rounded fw-semibold fs-4" id="view_order_status"></span>
          </h3>
        </div>
        <div class="row mb-6">
          <input type="hidden" id="view_order_sno" name="view_order_sno">
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_order_date"></label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_order_id"></label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Courier</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_courier_name"></label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Tracking ID</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_courier_id"></label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Delivery Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_delivery_date">-</label>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Vendor</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_vendor_name"></label>
            </div>
            <div class="row mb-3">
              <!-- <label class="col-3 text-dark fs-6 fw-semibold">Branch</label> -->
              <label class="col-3 text-dark fs-6 fw-semibold">Franchise</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_branch_name"></label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold" id="view_user_addre"></label>
            </div>
          </div>
        </div>
        <div class="row mb-6">
          <div class="col-8" id="cart-items-container">
            <!-- Cart items will go here -->
          </div>
          <div class="col-4" id="cart-summary-container">
              <!-- Summary will go here -->
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Cart Marketing Kit-->

<!--begin::Modal - Order Delivered-->
<div class="modal fade" id="kt_modal_order_delivered" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <form id="orderDeliveryform" action="{{ route('deliver_order') }}" method="POST">
        @csrf
        <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Order Delivered ?
          <input type="hidden" id="order_sno" name="order_sno">
          <div class="d-block fw-bold fs-5 py-2">
            <label class="mb-1" id="order_id"></label>
            <label class="me-1 ms-1 mb-1">-</label>
            <label class="mb-1" id="order_staff"></label>
            <label class="me-1 ms-1 mb-1">-</label>
            <label class="mb-1" id="order_branch"></label>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
          <button type="submit" class="btn btn-primary me-3">Yes</button>
          <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
        </div>
      </form>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Order Delivered-->

<!--begin::Modal - Feedback-->
<div class="modal fade" id="kt_modal_orders_feedback" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Orders Feedback</h3>
        </div>
        <form id="updateOrderForm" action="{{ route('order_feedback') }}" method="POST" onsubmit="return FeedbackvalidateForm()" novalidate>
          @csrf
          <input type="hidden" id="order_feed_sno" name="order_feed_sno">
          <div class="row mb-3">
            <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
            <label class="col-1 text-black fs-6 fw-bold">:</label>
            <label class="col-8 text-black fs-6 fw-bold" id="feed_order_date"></label>
          </div>
          <div class="row mb-3">
            <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
            <label class="col-1 text-black fs-6 fw-bold">:</label>
            <label class="col-8 text-black fs-6 fw-bold" id="feed_order_id"></label>
          </div>
          <div class="row mb-3">
            <div class="col-lg-3 mb-3">
              <div class="fw-semibold fs-6 mb-1 text-dark me-">Ratings<span class="text-danger">*</span></div>
            </div>
            <div class="col-lg-9 mb-3">
              <div class="d-flex align-items-center gap-3">
                <label class="ord_ratings_update fs-2hx" data-rateyo-full-star="true"></label>
                <label class="fs-5 text-black fw-semibold rating_val_update">0 / 5</label>
                <input type="hidden" id="order_ratings_hidden" name="order_ratings_hidden">
              </div>
              <div class="text-danger" id="order_rating_hidden_err"></div>
            </div>
            <div class="col-lg-12 mb-2">
              <label class="text-dark mb-1 fs-6 fw-semibold">Feedback<span class="text-danger">*</span></label>
              <textarea class="form-control" rows="5" id="ord_feedback" name="ord_feedback" placeholder="Enter Feedback"></textarea>
              <div class="text-danger" id="feedback_err"></div>
            </div>
          </div>
          <div class="d-flex justify-content-center align-items-center mt-6">
            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
            <button type="submit" class="btn btn-primary">Submit Feedback</button>
          </div>
        </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Feedback-->

  <!-- end Bootstrap old Modal for showing messages -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

  <style>
      /* Customize Toastr notification */
      .toast-success {
          background-color: green;
      }

      /* Customize Toastr notification */
      .toast-error {
          background-color: red;
      }
      .error_msg {
          border: solid 2px red !important;
          border-color: red !important;
      }
      .tags-inline.tagify__dropdown {
          z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
      }
  </style>

  <script>
    // Display Toastr messages
    @if(Session::has('toastr'))
    var type = "{{ Session::get('toastr')['type'] }}";
    var message = "{{ Session::get('toastr')['message'] }}";
    toastr[type](message);
    @endif
  </script>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const maxChars = 90;
    const elements = document.querySelectorAll('.mk_cart_name');

    elements.forEach(el => {
      const fullText = el.textContent.trim();
      el.setAttribute('title', fullText);
      if (fullText.length > maxChars) {
        el.textContent = fullText.slice(0, maxChars) + '...';
      }
      bootstrap.Tooltip.getOrCreateInstance(el);
    });
  });
</script>

<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $(".list_page_1").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>

<script>
  $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
  function date_fill_coup() {
    var dt_fill_coup = document.getElementById('dt_fill_coup').value;
    var today_dt_coup = document.getElementById('today_dt_coup');
    var week_from_dt_coup = document.getElementById('week_from_dt_coup');
    var week_to_dt_coup = document.getElementById('week_to_dt_coup');
    var monthly_dt_coup = document.getElementById('monthly_dt_coup');
    var from_dt_coup = document.getElementById('from_dt_coup');
    var to_dt_coup = document.getElementById('to_dt_coup');

    if (dt_fill_coup == "today") {
      today_dt_coup.style.display = "block";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else if (dt_fill_coup == "week") {
      today_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "block";
      week_to_dt_coup.style.display = "block";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#lead_week_st_dt_fill_coup').val(firstday);
      $('#lead_week_ed_dt_fill_coup').val(lastday);

    } else if (dt_fill_coup == "monthly") {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "block";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else if (dt_fill_coup == "custom_date") {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "block";
      to_dt_coup.style.display = "block";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    }
  }
</script>

<script>
  function deliverOrder(sno, order_id, staff_name, branch_name)
  {
    console.log('sno :', sno , 'order id :', order_id, 'Staff Name :' , staff_name, 'branch_name :', branch_name);
    $('#order_sno').val(sno);
    $('#order_id').html(order_id);
    $('#order_staff').html(staff_name);
    $('#order_branch').html(branch_name);
  }

  function formatDate(dateString) {
      let date = new Date(dateString); 
      let day = String(date.getDate()).padStart(2, '0'); 
      let monthIndex = date.getMonth();
      let year = date.getFullYear(); 

      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let month = months[monthIndex]; 

      return `${day}-${month}-${year}`;
  }

  function orderEdit(sno){
      // // Clear any previous error messages when the popup is opened
      // $('#courier_tracking_id_err').text("");
      // $('#courier_name_err').text("");
    
      fetch(`/order_edit/${sno}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                console.error('Error parsing JSON:', error.message);
                return;
            }

            const orderData = data.data;
            console.log(orderData);
            // Set values on the form inputs
            document.getElementById('order_edit_sno').value = orderData.sno;
            document.getElementById('edit_order_date').innerText = formatDate(orderData.order_date);
            document.getElementById('edit_order_id').innerText = orderData.order_id;
            document.getElementById('order_courier_name').value = orderData.courier_name;
            document.getElementById('courier_tracking_id').value = orderData.courier_id;
        })
        .catch(error => {
            console.error('Error fetching Order data:', error);
        });
  }

  function AddvalidateForm() 
  {
      var order_courier_name = document.getElementById('order_courier_name').value;
      var err = 0;
      
      // Trim the input to prevent spaces from being counted as valid input
      if (order_courier_name.trim() == "") {
          $('#courier_name_err').text("Courier Name is Required..!");
          err++;
      }

      var courier_tracking_id = document.getElementById('courier_tracking_id').value;
      
      // Trim the input to prevent spaces from being counted as valid input
      if (courier_tracking_id.trim() == "") {
          $('#courier_tracking_id_err').text("Courier Tracking Id is Required..!");
          err++;
      }

      if (err > 0) {
          return false; // Prevent form submission if validation fails
      } else {
          return true; // Allow form submission if validation passes
      }
  }

  function orderFeedback(sno){
    
      fetch(`/order_edit/${sno}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                console.error('Error parsing JSON:', error.message);
                return;
            }

            const orderData = data.data;
            console.log(orderData);
            // Set values on the form inputs
            document.getElementById('order_feed_sno').value = orderData.sno;
            document.getElementById('feed_order_date').innerText = formatDate(orderData.order_date);
            document.getElementById('feed_order_id').innerText = orderData.order_id;
            document.getElementById('ord_feedback').value = orderData.order_feedback;
            document.getElementById('order_ratings_hidden').value = orderData.order_rating;
            // Set the rating text value in the label
            // document.getElementById('rating_value').innerText = orderData.order_rating;

            // Set the rating value in the label (rating_val_update)
            let rating = orderData.order_rating ? orderData.order_rating : 0;  // Use a default value if empty
            document.querySelector('.rating_val_update').innerText = `${rating} / 5`;
            $('.ord_ratings_update').rateYo("destroy");
            // Initialize or update RateYo widget
            $('.ord_ratings_update').rateYo({
                rating: rating,         // Set the initial rating
                readOnly: false,         // Make the rating editable
                starWidth: "25px",       // Optional: Set the star width if necessary
                normalFill: "#d3d3d3",  // Optional: Set the normal star color
                ratedFill: "#ffcc00"     // Optional: Set the rated star color
            });

            // Attach onchange event for the rating widget
            $('.ord_ratings_update').on('rateyo.change', function(e, data) {
                var rating = data.rating + ' / 5';
                $(this)
                    .parent()
                    .find('.rating_val_update')
                    .text(rating);  // Update the displayed rating text
                $('#order_ratings_hidden').val(data.rating);  // Store the rating value in the hidden input
            });
        })
        .catch(error => {
            console.error('Error fetching Order data:', error);
        });
  }

  function FeedbackvalidateForm() 
  {
      var order_ratings_hidden = document.getElementById('order_ratings_hidden').value;
      var err = 0;
      
      // Trim the input to prevent spaces from being counted as valid input
      if (order_ratings_hidden.trim() == "") {
          $('#order_rating_hidden_err').text("Rating is Required..!");
          err++;
      }

      var ord_feedback = document.getElementById('ord_feedback').value;
      
      // Trim the input to prevent spaces from being counted as valid input
      if (ord_feedback.trim() == "") {
          $('#feedback_err').text("Feedback is Required..!");
          err++;
      }

      if (err > 0) {
          return false; // Prevent form submission if validation fails
      } else {
          return true; // Allow form submission if validation passes
      }
  }
</script>
@if (isset($order_list))    
    @foreach ($order_list as $i => $olist2)
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $('.ord_rat_list{{$i}}').rateYo({
                    rating: {{$olist2->order_rating}}, 
                    starWidth: "20px"
                });
            });
        </script>
    @endforeach
@endif

<script>

  function formatDateView(dateString) {
      let date = new Date(dateString); 
      let day = String(date.getDate()).padStart(2, '0'); 
      let monthIndex = date.getMonth();
      let year = date.getFullYear(); 

      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      let month = months[monthIndex]; 

      return `${day}-${month}-${year}`;
  }

  function viewOrder(sno)
  {
    // alert(sno);
    fetch(`/order_view/${sno}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.text();
        })
        .then(text => {
            let data;

            try {
                data = JSON.parse(text);
            } catch (error) {
                console.error('Error parsing JSON:', error.message);
                return;
            }

            const orderData = data.data.data;
            console.log(orderData);
            // Set values on the form inputs
            document.getElementById('view_order_sno').value = orderData.sno;
            document.getElementById('view_order_date').innerText = orderData.order_date ? formatDateView(orderData.order_date) : '-';
            document.getElementById('view_order_id').innerText = orderData.order_id ?? '-';
            document.getElementById('view_courier_name').innerText = orderData.courier_name ?? '-';
            document.getElementById('view_courier_id').innerText = orderData.courier_id ?? '-';
            document.getElementById('view_delivery_date').innerText = orderData.delivered_date ? formatDateView(orderData.delivered_date) : '-';
            document.getElementById('view_vendor_name').innerText = orderData.staff_name;
            if(orderData.branch_type == 1){
              document.getElementById('view_branch_name').innerText = orderData.branch_name;
            }else if (orderData.branch_type == 2) {
              document.getElementById('view_branch_name').innerText = orderData.franchise_name;
            }

            document.getElementById('view_user_addre').innerText = orderData.user_address ?? '-';

            if (orderData.status == 3) {
                document.getElementById('view_order_status').innerText = 'Preparing Order';
                // Remove previous classes if any
                document.getElementById('view_order_status').classList.remove('bg-success', 'text-white'); // Remove the classes from other states
                document.getElementById('view_order_status').classList.add('bg-warning', 'text-black'); // Add the new classes
            } else if (orderData.status == 4) {
                document.getElementById('view_order_status').innerText = 'Order Delivered';
                // Remove previous classes if any
                document.getElementById('view_order_status').classList.remove('bg-warning', 'text-black'); // Remove the classes from other states
                document.getElementById('view_order_status').classList.add('bg-success', 'text-white'); // Add the new classes
            } else {
                document.getElementById('view_order_status').innerText = 'Preparing Order';
                // Remove previous classes if any
                document.getElementById('view_order_status').classList.remove('bg-success', 'text-white'); // Remove the classes from other states
                document.getElementById('view_order_status').classList.add('bg-warning', 'text-black'); // Add the new classes
            }

            console.log(data.data.items);
            const items = data.data.items;
            console.log(data.data.summary);

            const summary = data.data.summary;

            $('#cart-items-container').html('');
            $('#cart-summary-container').html('');
     
              // Append cart items
              let itemsHtml = '';
              items.forEach((item, index) => {
                  itemsHtml += `

                          <div class="d-flex align-items-start mb-4" data-cart-id="${item.cart_id}"  data-index-id="${item.index_id || index}">
                              <div class="symbol symbol-35px border border-gray-500 rounded px-2 py-1 me-3">
                                  <div class="image-input image-input-circle" data-kt-image-input="true">
                                      <img src="/marketing_kits/${item.marketing_attachments}" alt="user-avatar" class="image-input-wrapper w-125px h-125px" />
                                  </div>
                              </div>
                              <div class="w-100 mb-0">
                                  <div class="d-flex align-items-start fs-5 fw-semibold text-black mb-2">
                                      <div class="mk_cart_name w_99" data-bs-toggle="tooltip" data-bs-placement="bottom" data-marketing-id="${item.marketing_kit_id}" title="${item.marketing_kit_name}">${item.marketing_kit_name}</div>
                                      <a href="javascript:;" class="btn btn-icon btn-sm p-0 float-end remove-kit-btn" data-buyitem-id="${item.buy_item_id}">
                                      </a>
                                  </div>
                                  <div class="d-flex align-items-start">
                                      <div class="text-dark fs-7 w-50" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category">${item.category_name}</div>
                                      <label class="text-dark fs-7 ms-1 me-2">|</label>
                                      <div class="w-50">
                                          <label class="text-dark fs-7">Count</label>
                                          <label class="text-dark fs-7 ms-1 me-1">-</label>
                                          <label class="text-dark fw-bold fs-7">${item.count} Pcs</label>
                                      </div>
                                  </div>
                                  <div class="d-flex align-items-start mb-3">
                                      <div class="w-50">
                                          <label class="text-dark fs-7">Color</label>
                                          <label class="text-dark fs-7 ms-1 me-1">-</label>
                                          <label class="text-dark fs-7">
                                              <span class="badge w-20px h-20px border rounded mb-n1" style="background-color:${item.color.code} !important;"> </span>
                                              <span class="fw-bold ms-1" data-color-id="${item.color.id}">${item.color.name}</span>
                                              <span class="fw-bold">(&#8377; ${item.color.price})</span>
                                          </label>
                                      </div>
                                      <label class="text-dark fs-7 ms-1 me-2">|</label>
                                      <div class="w-50">
                                          <label class="text-dark fs-7">Size</label>
                                          <label class="text-dark fs-7 ms-1 me-1">-</label>
                                          <label class="text-dark fs-7">
                                              <span class="fw-bold ms-1" data-size-id="${item.size.id}">${item.size.width} X ${item.size.height} inch</span>
                                              <span class="fw-bold">(&#8377; ${item.size.price})</span>
                                          </label>
                                      </div>
                                  </div>
                                  <div class="d-flex align-items-start">
                                      <div class="w-100 text-black fs-4 fw-semibold">&#8377; ${item.item_total}</div>
                                  </div>
                              </div>
                          </div>
                          <div class="border-dashed border-1 border-bottom border-gray-700 mb-3"></div>

                  `;
              });

              // Add items to modal
              $('#cart-items-container').html(itemsHtml);

              // Update price summary
              let summaryHtml = `
                <div class="border border-gray-700 rounded px-3 py-4">
                  <div class="text-black text-center fs-4 fw-semibold mb-3"><u>Price Details</u></div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold" data-price-amount="${summary.item_total}">Price<br><span class="fs-8 text-info">( ${summary.total_item} Items)</span></div>
                      <div class="text-black fs-6 text-end fw-semibold">&#8377; ${summary.item_total}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold">GST <span class="fs-7 text-danger">( ${summary.gst_percentage}%)</span></div>
                      <div class="text-black fs-6 text-end fw-semibold" data-gst-amount="${summary.gst_value}"><span class="fs-7 text-black me-1">( + )</span>&#8377; ${summary.gst_value}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold">Delivery Charges</div>
                      <div class="text-black fs-6 text-end fw-semibold" data-delivery-amount="${summary.delivery_charge}"><span class="fs-7 text-black me-1">( + )</span>&#8377; ${summary.delivery_charge}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-black fs-5 fw-semibold">Total Amount</div>
                      <div class="text-black fs-5 text-end fw-bold" data-total-amount="${summary.final_total}">&#8377; ${summary.final_total}</div>
                  </div>
                </div>

              `;
              $('#cart-summary-container').html(summaryHtml);           
        })
        .catch(error => {
            console.error('Error fetching Order data:', error);
        });
  }
</script>
@endsection
