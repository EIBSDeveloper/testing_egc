@extends('layouts/layoutMaster')

@section('title', 'Paymnets')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/rateyo/rateyo.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/rateyo/rateyo.js',
])
@endsection

@section('content')
<!--begin::Theme mode setup on page load-->


<form name="razorpayform" action="{{ route('razorpay.verify') }}" method="POST">
  @csrf
  <input type="hidden" name="razorpay_payment_id" id="razorpay_payment_id">
  <input type="hidden" name="razorpay_signature" id="razorpay_signature">
  <input type="hidden" name="razorpay_order_id" value="{{ $data['razorpay_order_id'] }}">
</form>

<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
  var options = {
      "key": "{{ env('RAZORPAY_KEY') }}",
      "amount": "{{ $data['total'] * 100 }}",
      "currency": "INR",
      "name": "Elysium Academy",
      "description": "Marketing Kit Purchase",
      "image": "{{ asset('logos/2637.png') }}", // optional
      "order_id": "{{ $data['razorpay_order_id'] }}",
      "handler": function (response){
          // console.log("Razorpay Response:", response); // ✅ View in browser console

          // alert("Payment ID: " + response.razorpay_payment_id); // ✅ Quick popup to test
          document.getElementById('razorpay_payment_id').value = response.razorpay_payment_id;
          document.getElementById('razorpay_signature').value = response.razorpay_signature;
          document.razorpayform.submit();
      },
      "theme": {
          "color": "#7A55C8",
          "image_padding": false
      },
      "modal": {
          "ondismiss": function() {
              window.location.href = "{{ url('/marketing_kit') }}";
          },
          "escape": true,
          "backdropclose": false
      }
  };

  var rzp = new Razorpay(options);

  $(document).ready(function(){
      $("#rzp-button1").click();  // if you need auto open
      rzp.open();
      return false;
  });
</script>

<!-- Trigger (invisible) -->
<button id="rzp-button1" style="display:none;"></button>

@endsection
