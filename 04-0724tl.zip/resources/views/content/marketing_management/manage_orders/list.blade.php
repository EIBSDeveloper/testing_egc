@extends('layouts/layoutMaster')

@section('title', 'Manage Orders')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/rateyo/rateyo.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/rateyo/rateyo.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<style>
  .list_page thead th,
  .list_page tbody td,
  .list_page tfoot th {
    padding: 7px !important;
  }
</style>
<!-- Users List Table -->
<div class="card card-action">
  <div class="card-header border-bottom pb-0">
    <div class="card-action-title">
      <h5 class="card-title mb-1">Manage Orders</h5>
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
          </li>
          <span class="text-dark opacity-75 me-1 ms-1">
            <i class="mdi mdi-chevron-double-right fs-4"></i>
          </span>
          <li class="breadcrumb-item">
            <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
          </li>
        </ol>
      </nav>
    </div>
    <div class="card-action-element">
      <div class="d-flex justify-content-end align-items-center mb-0 gap-1">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
          <span><i class="mdi mdi-filter-outline"></i></span>
        </a>
      </div>
    </div>
  </div>
  <div class="card-body">
    <div class="filter_tbox" style="display: none;">
      <div class="row py-1">
        <div class="col-lg-6 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Vendors</label>
          <select id="" class="select3 form-select">
            <option value="" selected>All</option>
            <option value="1">Eibs Developers - Elysium Academy Cit Nagar - 9715631759</option>
            <option value="2">Krishnaveni - Elysium Academy Virudhunagar - 7598059545</option>
            <option value="3">Abirami - Elysium Academy Perambalur - 9003259988</option>
            <option value="4">Ramkumar - Elysium Academy Coimbatore - 9789970074</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
          <select class="select3 form-select">
            <option value="" selected>All</option>
            <option value="1">Preparing Orders</option>
            <option value="2">Order Delivered</option>
            <option value="3">Pending Feedback</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
          <select class="select3 form-select" name="dt_fill_coup" id="dt_fill_coup" onchange="date_fill_coup();">
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="monthly">This Month</option>
            <option value="custom_date">Custom Date</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2" id="today_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_today_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_from_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_week_st_dt_fill_coup" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_to_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_week_ed_dt_fill_coup" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="monthly_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="from_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_custom_from_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="to_dt_coup" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="lead_custom_to_dt_fill" placeholder="Select Date" class="form-control max-h-100" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
      </div>
      <div class="d-flex justify-content-end align-items-center">
        <button type="reset" class="btn btn-sm btn-secondary me-3" data-bs-dismiss="modal">Reset</button>
        <button type="submit" class="btn btn-sm btn-primary" data-bs-dismiss="modal">Go</button>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-150px">Vendors</th>
              <th class="min-w-125px">Delivery Address</th>
              <th class="min-w-100px">Order Date</th>
              <th class="min-w-100px">Order / Courier ID</th>
              <th class="min-w-80px text-center">Count</th>
              <th class="min-w-100px text-center">Total Amt</th>
              <th class="min-w-125px">Status</th>
              <th class="min-w-80px text-center">Actions</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            <tr>
              <td>
                <div class="d-flex align-items-center px-1">
                  <div class="symbol symbol-35px me-2">
                    <div class="image-input image-input-circle" data-kt-image-input="true">
                      <img src="{{asset('assets/eapl_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                    </div>
                  </div>
                  <div class="mb-0">
                    <label class="fw-semibold fs-7 text-black">Krishnaveni</label>
                    <div class="d-block text-primary fs-8">
                      <label class="fs-8 text-dark fw-semibold text-truncate max-w-125px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elysium Academy Virudhunagar">Elysium Academy Virudhunagar</label>
                      <label class="badge bg-info fw-semibold fs-8 text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Franchise">F</label>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <div class="text-wrap max-w-250px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="1/2A, AA Road, Near Head Post Office, Virudhunagar, Tamil Nadu, India, 626001">1/2A, AA Road, Near Head Post Office, Virudhunagar, Tamil Nadu, India, 626001</div>
              </td>
              <td>
                <label class="fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Order Date">09-Apr-2025</label>
              </td>
              <td>
                <label class="fw-semibold fs-7">ORD-0003/25</label>
              </td>
              <td align="center">
                <label class="badge bg-secondary rounded-pill fw-semibold fs-7">02</label>
              </td>
              <td align="right">
                <label class="fw-semibold fs-6">&#8377; 4,75,800</label>
              </td>
              <td>
                <a class="cursor-pointer badge bg-warning rounded" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <span class="text-black fw-semibold fs-7">Preparing Orders</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                  <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_order_delivered">Order Delivered</a>
                </div>
              </td>
              <td>
                <div class="text-center">
                  <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_orders">
                    <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                  </a>
                  <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_update_orders">
                    <i class="mdi mdi-square-edit-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"></i>
                  </a>
                </div>
              </td>
            </tr>
            <tr>
              <td>
                <div class="d-flex align-items-center px-1">
                  <div class="symbol symbol-35px me-2">
                    <div class="image-input image-input-circle" data-kt-image-input="true">
                      <img src="{{asset('assets/eapl_images/user_2.png')}}" alt="user-avatar" class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                    </div>
                  </div>
                  <div class="mb-0">
                    <label class="fw-semibold fs-7 text-black">Abirami</label>
                    <div class="d-block text-primary fs-8">
                      <label class="fs-8 text-dark fw-semibold text-truncate max-w-125px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elysium Academy Perambalur">Elysium Academy Perambalur</label>
                      <label class="badge bg-info fw-semibold fs-8 text-white" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Franchise">F</label>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <div class="text-wrap max-w-250px fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="2nd Floor, Ponmanam Plaza, Above Reliance Trends, Near New Bus Stand, Perambalur, Tamil Nadu, India, 621212">2nd Floor, Ponmanam Plaza, Above Reliance Trends, Near New Bus Stand, Perambalur, Tamil Nadu, India, 621212</div>
              </td>
              <td>
                <label class="fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Order Date">05-Apr-2025</label>
                <div class="d-block">
                  <label class="badge bg-success text-black rounded-pill fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered Date">08-Apr-2025</label>
                </div>
              </td>
              <td>
                <label class="fw-semibold fs-7">ORD-0002/25</label>
                <div class="d-block text-primary fs-8">
                  <label class="fs-8 text-dark fw-semibold text-truncate max-w-150px me-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Courier Tracking ID">E123456789IN</label>
                </div>
              </td>
              <td align="center">
                <label class="badge bg-secondary rounded-pill fw-semibold fs-7">01</label>
              </td>
              <td align="right">
                <label class="fw-semibold fs-6">&#8377; 1,58,800</label>
              </td>
              <td>
                <div class="badge bg-success rounded text-black fw-semibold fs-7">Order Delivered</div>
                <div class="d-flex align-items-center gap-1 mt-1">
                  <label class="ord_rat_list fs-7" data-rateyo-full-star="true"></label>
                  <label class="badge bg-label-danger border rounded fs-7 fw-semibold">4 / 5</label>
                </div>
              </td>
              <td>
                <div class="text-center">
                  <a href="javascript:;" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_view_orders">
                    <i class="mdi mdi-eye-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"></i>
                  </a>
                  <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_orders_feedback">
                    <i class="mdi mdi-comment-quote-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Feedback"></i>
                  </a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>



<!--begin::Modal - Update Orders-->
<div class="modal fade" id="kt_modal_update_orders" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Orders</h3>
        </div>
        <div class="row mb-3">
          <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
          <label class="col-1 text-black fs-6 fw-bold">:</label>
          <label class="col-8 text-black fs-6 fw-bold">09-Apr-2025</label>
        </div>
        <div class="row mb-3">
          <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
          <label class="col-1 text-black fs-6 fw-bold">:</label>
          <label class="col-8 text-black fs-6 fw-bold">ORD-0003/25</label>
        </div>
        <div class="row mb-3">
          <div class="col-lg-12 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Courier Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Courier Name" value="Ekart" />
          </div>
          <div class="col-lg-12 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Courier Tracking ID<span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="" placeholder="Enter Courier Tracking ID" value="E123456789IN" />
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
          <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Update Orders</a>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Orders-->

<!--begin::Modal - View Orders-->
<div class="modal fade" id="kt_modal_view_orders_1" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">
            <span>View Orders</span>
            <span class="ms-1 me-1">-</span>
            <span class="badge bg-warning text-black rounded fw-semibold fs-4">Preparing Orders</span>
          </h3>
        </div>
        <div class="row">
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">09-Apr-2025</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">ORD-0003/25</label>
            </div>
            <!-- <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Delivery Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">14-Apr-2025</label>
            </div> -->
          </div>
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Vendor</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">Krishnaveni</label>
            </div>
            <div class="row mb-3">
              <!-- <label class="col-3 text-dark fs-6 fw-semibold">Branch</label> -->
              <label class="col-3 text-dark fs-6 fw-semibold">Franchise</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">Elysium Academy Virudhunagar</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">1/2A, AA Road, Near Head Post Office, Virudhunagar, Tamil Nadu, India, 626001</label>
            </div>
          </div>
        </div>
        <div class="row mb-6">
          <div class="col-lg-12">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-200px">Marketing Kit</th>
                  <th class="min-w-100px">Count / Per Unit</th>
                  <th class="min-w-100px text-center">GST Amt</th>
                  <th class="min-w-125px">Delivery Charges</th>
                  <th class="min-w-100px">Total Amt</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7">
                <tr>
                  <td>
                    <div class="d-flex align-items-center px-1">
                      <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true">
                          <img src="{{asset('assets/eapl_images/marketing_kit/poster.jpg')}}" alt="user-avatar" class="image-input-wrapper w-100px h-60px" />
                        </div>
                      </div>
                      <div class="mb-0">
                        <label class="fs-7">Smart Job Poster Design for Faster Hiring</label>
                        <div class="d-block text-primary fs-8" title="Category">Posters</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <label class="fw-semibold fs-6 text-black">2000</label>
                    <label class="fw-semibold fs-6 text-black ms-1 me-1">/</label>
                    <label class="fw-semibold fs-7 text-black">&#8377; 150</label>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 15,000</label>
                    <div class="d-block">
                      <label class="badge bg-secondary fw-semibold fs-8 text-white">5%</label>
                    </div>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 2,000</label>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 3,17,000</label>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div class="d-flex align-items-center px-1">
                      <div class="symbol symbol-35px me-2">
                        <div class="image-input image-input-circle" data-kt-image-input="true">
                          <img src="{{asset('assets/eapl_images/marketing_kit/poster_1.jpg')}}" alt="user-avatar" class="image-input-wrapper w-100px h-60px" />
                        </div>
                      </div>
                      <div class="mb-0">
                        <label class="fs-7">Branch Opening Poster</label>
                        <div class="d-block text-primary fs-8" title="Category">Posters</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <label class="fw-semibold fs-6 text-black">1000</label>
                    <label class="fw-semibold fs-6 text-black ms-1 me-1">/</label>
                    <label class="fw-semibold fs-7 text-black">&#8377; 150</label>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 7,500</label>
                    <div class="d-block">
                      <label class="badge bg-secondary fw-semibold fs-8 text-white">5%</label>
                    </div>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 1,300</label>
                  </td>
                  <td align="right">
                    <label class="fw-semibold fs-6 text-black">&#8377; 1,58,800</label>
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr class="text-start align-top fw-bold fs-5 gs-0 bg-primary">
                  <th class="min-w-200px text-center">Total</th>
                  <th class="min-w-100px">3000</th>
                  <th align="right" class="min-w-100px text-end">&#8377; 22,500</th>
                  <th align="right" class="min-w-125px text-end">&#8377; 3,300</th>
                  <th align="right" class="min-w-100px text-end">&#8377; 4,75,800</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - View Orders-->

<!--begin::Modal - View Orders-->
<div class="modal fade" id="kt_modal_view_orders" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-8 text-center">
          <h3 class="text-center mb-4 text-black">
            <span>View Orders</span>
            <span class="ms-1 me-1">-</span>
            <span class="badge bg-warning text-black rounded fw-semibold fs-4">Preparing Orders</span>
          </h3>
        </div>
        <div class="row mb-6">
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">09-Apr-2025</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">ORD-0003/25</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Courier</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">Ekart Courier</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Tracking ID</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">E123456789IN</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Delivery Date</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">14-Apr-2025</label>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Vendor</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">Krishnaveni</label>
            </div>
            <div class="row mb-3">
              <!-- <label class="col-3 text-dark fs-6 fw-semibold">Branch</label> -->
              <label class="col-3 text-dark fs-6 fw-semibold">Franchise</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">Elysium Academy Virudhunagar</label>
            </div>
            <div class="row mb-3">
              <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
              <label class="col-1 text-black fs-6 fw-bold">:</label>
              <label class="col-8 text-black fs-6 fw-bold">1/2A, AA Road, Near Head Post Office, Virudhunagar, Tamil Nadu, India, 626001</label>
            </div>
          </div>
        </div>
        <div class="row mb-6">
          <div class="col-lg-8">
            <div class="d-flex align-items-start mb-4">
              <div class="symbol symbol-35px border border-gray-500 rounded px-2 py-1 me-3">
                <div class="image-input image-input-circle" data-kt-image-input="true">
                  <img src="{{asset('assets/eapl_images/marketing_kit/poster.jpg')}}" alt="user-avatar" class="image-input-wrapper w-125px h-125px" />
                </div>
              </div>
              <div class="w-100 mb-0">
                <div class="fs-5 fw-semibold text-black mk_cart_name mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Smart Job Poster Design for Faster Hiring">Smart Job Poster Design for Faster Hiring</div>
                <div class="d-flex align-items-start">
                  <div class="text-dark fs-7 w-50" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category">Posters</div>
                  <label class="text-dark fs-7 ms-1 me-2">|</label>
                  <div class="w-50">
                    <label class="text-dark fs-7">Count</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fw-bold fs-7">2000 Pcs</label>
                  </div>
                </div>
                <div class="d-flex align-items-start mb-3">
                  <div class="w-50">
                    <label class="text-dark fs-7">Color</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fs-7">
                      <span class="badge w-20px h-20px border rounded mb-n1" style="background-color:#ff0000 !important;"> </span>
                      <span class="fw-bold ms-1">Red</span>
                      <span class="fw-bold">(&#8377; 200)</span>
                    </label>
                  </div>
                  <label class="text-dark fs-7 ms-1 me-2">|</label>
                  <div class="w-50">
                    <label class="text-dark fs-7">Size</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fs-7">
                      <span class="fw-bold ms-1">48 X 36 inch</span>
                      <span class="fw-bold">(&#8377; 0)</span>
                    </label>
                  </div>
                </div>
                <div class="d-flex align-items-start">
                  <div class="w-100 text-black fs-4 fw-semibold">&#8377; 4,00,000</div>
                </div>
              </div>
            </div>
            <div class="border-dashed border-1 border-bottom border-gray-700 mb-3"></div>
            <div class="d-flex align-items-start mb-4">
              <div class="symbol symbol-35px border border-gray-500 rounded px-2 py-1 me-3">
                <div class="image-input image-input-circle" data-kt-image-input="true">
                  <img src="{{asset('assets/eapl_images/marketing_kit/poster_1.jpg')}}" alt="user-avatar" class="image-input-wrapper w-125px h-125px" />
                </div>
              </div>
              <div class="w-100 mb-0">
                <div class="fs-5 fw-semibold text-black mk_cart_name mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch Opening Poster">Branch Opening Poster</div>
                <div class="d-flex align-items-start">
                  <div class="text-dark fs-7 w-50" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category">Posters</div>
                  <label class="text-dark fs-7 ms-1 me-2">|</label>
                  <div class="w-50">
                    <label class="text-dark fs-7">Count</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fw-bold fs-7">100 Pcs</label>
                  </div>
                </div>
                <div class="d-flex align-items-start mb-3">
                  <div class="w-50">
                    <label class="text-dark fs-7">Color</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fs-7">
                      <span class="badge w-20px h-20px border rounded mb-n1" style="background-color:#0000ff !important;"> </span>
                      <span class="fw-bold ms-1">Blue</span>
                      <span class="fw-bold">(&#8377; 350)</span>
                    </label>
                  </div>
                  <label class="text-dark fs-7 ms-1 me-2">|</label>
                  <div class="w-50">
                    <label class="text-dark fs-7">Size</label>
                    <label class="text-dark fs-7 ms-1 me-1">-</label>
                    <label class="text-dark fs-7">
                      <span class="fw-bold ms-1">48 X 36 inch</span>
                      <span class="fw-bold">(&#8377; 300)</span>
                    </label>
                  </div>
                </div>
                <div class="d-flex align-items-start">
                  <div class="w-100 text-black fs-4 fw-semibold">&#8377; 65,000</div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-4">
            <div class="border border-gray-700 rounded px-3 py-4">
              <div class="text-black text-center fs-4 fw-semibold mb-3"><u>Price Details</u></div>
              <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="text-dark fs-6 fw-semibold">Price<br><span class="fs-8 text-info">( 2 Items)</span></div>
                <div class="text-black fs-6 text-end fw-semibold">&#8377; 4,65,000</div>
              </div>
              <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="text-dark fs-6 fw-semibold">GST <span class="fs-7 text-danger">( 5% )</span></div>
                <div class="text-black fs-6 text-end fw-semibold"><span class="fs-7 text-black me-1">( + )</span>&#8377; 23,250</div>
              </div>
              <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="text-dark fs-6 fw-semibold">Delivery Charges</div>
                <div class="text-black fs-6 text-end fw-semibold"><span class="fs-7 text-black me-1">( + )</span>&#8377; 3,500</div>
              </div>
              <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="text-black fs-5 fw-semibold">Total Amount</div>
                <div class="text-black fs-5 text-end fw-bold">&#8377; 4,91,750</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Cart Marketing Kit-->

<!--begin::Modal - Order Delivered-->
<div class="modal fade" id="kt_modal_order_delivered" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
        <div class="swal2-icon-content">?</div>
      </div>
      <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Order Delivered ?
        <div class="d-block fw-bold fs-5 py-2">
          <label class="mb-1">ORD-0003/25</label>
          <label class="me-1 ms-1 mb-1">-</label>
          <label class="mb-1">Krishnaveni</label>
          <label class="me-1 ms-1 mb-1">-</label>
          <label class="mb-1">Elysium Academy Virudhunagar</label>
        </div>
      </div>
      <div class="d-flex justify-content-center align-items-center pt-8">
        <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div><br><br>
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Order Delivered-->

<!--begin::Modal - Feedback-->
<div class="modal fade" id="kt_modal_orders_feedback" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Orders Feedback</h3>
        </div>
        <div class="row mb-3">
          <label class="col-3 text-dark fs-6 fw-semibold">Order Date</label>
          <label class="col-1 text-black fs-6 fw-bold">:</label>
          <label class="col-8 text-black fs-6 fw-bold">09-Apr-2025</label>
        </div>
        <div class="row mb-3">
          <label class="col-3 text-dark fs-6 fw-semibold">Order ID</label>
          <label class="col-1 text-black fs-6 fw-bold">:</label>
          <label class="col-8 text-black fs-6 fw-bold">ORD-0003/25</label>
        </div>
        <div class="row mb-3">
          <div class="col-lg-3 mb-3">
            <div class="fw-semibold fs-6 mb-1 text-dark me-">Ratings<span class="text-danger">*</span></div>
          </div>
          <div class="col-lg-9 mb-3">
            <div class="d-flex align-items-center gap-3">
              <label class="ord_ratings_update fs-2hx" data-rateyo-full-star="true"></label>
              <label class="fs-5 text-black fw-semibold rating_val_update">0 / 5</label>
            </div>
          </div>
          <div class="col-lg-12 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Feedback<span class="text-danger">*</span></label>
            <textarea class="form-control" rows="5" placeholder="Enter Feedback"></textarea>
          </div>
        </div>
        <div class="d-flex justify-content-center align-items-center mt-6">
          <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
          <a href="javascript:;" class="btn btn-primary" data-bs-dismiss="modal">Submit Feedback</a>
        </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Feedback-->

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const maxChars = 90;
    const elements = document.querySelectorAll('.mk_cart_name');

    elements.forEach(el => {
      const fullText = el.textContent.trim();
      el.setAttribute('title', fullText);
      if (fullText.length > maxChars) {
        el.textContent = fullText.slice(0, maxChars) + '...';
      }
      bootstrap.Tooltip.getOrCreateInstance(el);
    });
  });
</script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    $('.ord_ratings_update').rateYo({
      rating: 0
    });
    $('.ord_ratings_update').rateYo().on('rateyo.change', function(e, data) {
      var rating = data.rating + ' / 5';
      $(this)
        .parent()
        .find('.rating_val_update')
        .text(rating);
    });
  });

  document.addEventListener('DOMContentLoaded', function() {
    $('.ord_rat_list').rateYo({
      rating: 4,
      readOnly: true,
      starWidth: "20px"
    });
  });
</script>
<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $(".list_page_1").DataTable({
    "ordering": false,
    "paging": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>

<script>
  $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
  function date_fill_coup() {
    var dt_fill_coup = document.getElementById('dt_fill_coup').value;
    var today_dt_coup = document.getElementById('today_dt_coup');
    var week_from_dt_coup = document.getElementById('week_from_dt_coup');
    var week_to_dt_coup = document.getElementById('week_to_dt_coup');
    var monthly_dt_coup = document.getElementById('monthly_dt_coup');
    var from_dt_coup = document.getElementById('from_dt_coup');
    var to_dt_coup = document.getElementById('to_dt_coup');

    if (dt_fill_coup == "today") {
      today_dt_coup.style.display = "block";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else if (dt_fill_coup == "week") {
      today_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "block";
      week_to_dt_coup.style.display = "block";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#lead_week_st_dt_fill_coup').val(firstday);
      $('#lead_week_ed_dt_fill_coup').val(lastday);

    } else if (dt_fill_coup == "monthly") {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "block";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else if (dt_fill_coup == "custom_date") {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "block";
      to_dt_coup.style.display = "block";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    } else {
      today_dt_coup.style.display = "none";
      monthly_dt_coup.style.display = "none";
      from_dt_coup.style.display = "none";
      to_dt_coup.style.display = "none";
      week_from_dt_coup.style.display = "none";
      week_to_dt_coup.style.display = "none";
    }
  }
</script>
@endsection