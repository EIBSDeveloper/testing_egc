@extends('layouts/layoutMaster')

@section('title', 'Manage Marketing Kit')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

    #clear_rlts {
        display: inline-flex;
        justify-content: flex-end;
        width: 100%;
        text-align: right;
    }

    .icon-wrapper {
        display: inline-flex;
        align-items: center;
        flex-direction: row-reverse;
        gap: 8px;
        transition: transform 0.5s ease;
        transform: translateX(0);
    }

    .clr_txt {
        opacity: 0;
        transform: translateX(20px);
        transition: all 0.5s ease;
        white-space: nowrap;
    }

    #clear_rlts:hover .icon-wrapper {
        transform: translateX(-100px);
        color: #7239EA !important;
        text-decoration: underline !important;
    }

    #clear_rlts:hover .clr_txt {
        opacity: 1;
        transform: translateX(130px);
    }

    .txt_hov:hover {
        text-decoration: underline !important;
    }

    #sidebar_tbox {
        transition: opacity 0.5s ease, width 0.5s ease;
        opacity: 1;
    }

    #sidebar_tbox.fade-out {
        opacity: 0;
        width: 0;
        overflow: hidden;
        pointer-events: none;
    }

    .emboss-effect {
        /* background: #f0f0f0; */
        padding: 20px;
        border-radius: 10px;
        transition: box-shadow 0.3s ease, transform 0.3s ease;
    }

    .emboss-effect:hover {
        box-shadow: -12px 0.5rem 1rem 6px rgba(0, 0, 0, 0.22);
        transform: scale(1.1);
        background-color: #eaffee;
        border: 1px solid #e1e1e1;
    }

    .list_page_1 thead th,
    .list_page_1 tbody td,
    .list_page_1 tfoot th {
        padding: 5px !important;
    }

    .add_to_cart {
        position: fixed;
        z-index: 105;
        bottom: 40px;
        right: 50px;
    }

    .add_to_cart:hover {
        box-shadow: 0 0 15px 13px rgba(0, 0, 0, 0.2);
        border-radius: 50%;
        background-color: white;
    }

    .w_99 {
        width: 99% !important;
    }

    .vart_menu_clr:hover,
    .vart_menu_clr.active {
        border: 1px solid rgb(189, 188, 188) !important;
        background-color: #f5f5f5 !important;
        border-radius: 10px !important;
        cursor: pointer !important;
    }

    .vart_menu_sz:hover,
    .vart_menu_sz.active {
        border: 1px solid rgb(189, 188, 188) !important;
        background-color: #f5f5f5 !important;
        border-radius: 10px !important;
        cursor: pointer !important;
    }

    /* .menu_clr_sz.active {
        border: 1px solid rgb(189, 188, 188) !important;
        background-color: #f5f5f5 !important;
        border-radius: 10px !important;
        cursor: pointer !important;
    } */
</style>
    <div class="card">
        <div class="card-header border-bottom pb-1 ">
            <div class="card-action-title text-black fs-5 fw-bold mb-1">
              <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
            
                <!-- Left: Title + Breadcrumb -->
                <div class="d-flex flex-column">
                  <h5 class="card-title mb-1">Manage Marketing Kit</h5>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0">
                      <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                          <i class="mdi mdi-home text-body fs-4"></i>
                        </a>
                      </li>
                      <span class="text-dark opacity-75 mx-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                      </span>
                      <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center fw-semibold">Marketing Management</a>
                      </li>
                    </ol>
                  </nav>
                </div>
            
                <!-- Right: Count + Button in same row -->
                <div class="d-flex align-items-center gap-3">
            
                  <!-- Count -->
                  <div class="border bg-primary text-white shadow-sm rounded-2 px-3 py-2 text-center">
                    <div class="fs-3 fw-bold" id="kit-count">0</div>
                    <div class="fs-7 fw-semibold">Total Kit</div>
                  </div>
            
                  <!-- Add Button -->
                  <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white"
                     data-bs-toggle="modal" data-bs-target="#kt_modal_create_marketing_kit">
                    <i class="mdi mdi-plus me-2"></i>Add Marketing Kit
                  </a>
                </div>
                
              </div>
            </div>

        </div>

        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                          @php
                          $options = [10, 25, 100, 500]; // Define available options
                          @endphp
                          @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                              @php echo $option; @endphp
                            </option>
                          @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                  <form id="search_form" method="POST" action="/manage_marketing_kit">
                    @csrf
                      <div class="d-flex align-items-center gap-2">
                          <div class="mb-1">
                              <input type="hidden" name="page" value="{{ request('page', 1) }}">
                              <input type="hidden" name="filter_on" value="1">
                              <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                              <input
                              type="text"
                              class="form-control"
                              id="cus_fill" name="cus_fill" value="{{ $cus_fill ?? "" }}"
                              placeholder="Enter Marketing Kit - Name"
                              />
                          </div>
                          <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                      </div>
                  </form>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                  <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-80px">Marketing Kit</th>
                            <th class="min-w-80px">Category/SubCategeory</th>
                            <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" >Type</th>
                            <th class="min-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" >Options</th>
                            <!--<th class="min-w-80px">Status</th>-->
                            <th class="min-w-50px">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7" id="kit-table-body">
                        @foreach ($kits as $kit)
                            <tr>
                                <!-- Marketing Kit Name with thumbnail -->
                                <td>
                                    <div class="d-flex align-items-center px-1">
                                        <div class="symbol symbol-35px me-2">
                                            <img src="{{ asset('marketing_kits_thumbnail/' . $kit->marketing_thumbnail) }}" 
                                                 class="w-45px h-45px rounded border cursor-pointer" 
                                                 alt="Thumbnail" 
                                                 data-bs-toggle="tooltip" 
                                                 title="{{ $kit->description ?? $kit->marketing_kit_name }}">
                                        </div>
                                        <div class="ms-1">
                                            <div class="fs-5 fw-bold">{{ $kit->marketing_kit_name }}</div>
                                            <div class="text-primary fs-8">{{ $kit->marketing_kit_id }}</div>
                                        </div>
                                    </div>
                                </td>
                        
                                <!-- Category / Subcategory -->
                                <td>
                                    <div class="mb-1">
                                        <span class="badge bg-primary text-white fs-6 fw-semibold">{{ $kit->category_name }}</span>
                                    </div>
                                    @foreach ($kit->subcategory_names as $subcat)
                                        <div>
                                            <span class="badge bg-info text-white fs-8 fw-normal">{{ $subcat }}</span>
                                        </div>
                                    @endforeach
                                </td>
                        
                                <!-- File Type -->
                                <td>
                                    <span class="badge bg-secondary text-white fs-8" data-bs-toggle="tooltip" title="File Type">
                                        {{ strtoupper($kit->file_type) }}
                                    </span>
                                    <div class="text-muted fs-8">{{ ucfirst($kit->source_type) }}</div>
                                </td>
                        
                                <!-- Checks -->
                                <td>
                                    @if ($kit->preview_check)
                                        <div><span class="badge bg-warning text-dark fs-8 mb-1">Preview</span></div>
                                    @endif
                                    @if ($kit->download_check)
                                        <div><span class="badge bg-success text-white fs-8 mb-1">Download</span></div>
                                    @endif
                                    @if ($kit->buy_check)
                                        <div><span class="badge bg-danger text-white fs-8">Buy</span></div>
                                    @endif
                                </td>
                        
                                <!-- Status -->
                                <!--<td>-->
                                <!--    <span class="badge bg-{{ $kit->status == 0 ? 'success' : 'danger' }} fs-8">-->
                                <!--        {{ $kit->status == 0 ? 'Active' : 'Inactive' }}-->
                                <!--    </span>-->
                                <!--</td>-->
                                
                                <!-- Actions -->
                                <td>
                                    <div class="d-flex align-items-center">
                                        <!-- Dropdown trigger -->
                                        <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                        </a>
                                
                                        <!-- Dropdown menu -->
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <!-- View -->
                                            <a href="javascript:;" 
                                               class="dropdown-item"
                                               data-bs-toggle="modal" 
                                               data-id="{{ $kit->sno }}" 
                                               data-name="{{ $kit->marketing_kit_name }}" 
                                               data-bs-target="#kt_modal_view_marketing_kit">
                                                <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>
                                                View
                                            </a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-id="{{ $kit->sno }}" 
                                               data-name="{{ $kit->marketing_kit_name }}"  data-bs-target="#kt_modal_update_marketing_kit" >
                                                <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                <span>Edit</span>
                                            </a>
                                
                                            <!-- Delete -->
                                            <a href="javascript:;" 
                                               class="dropdown-item"
                                               data-id="{{ $kit->sno }}" 
                                               data-name="{{ $kit->marketing_kit_name }}" 
                                               data-bs-toggle="modal" 
                                               data-bs-target="#kt_modal_delete_marketing_kit">
                                                <i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>
                                                Delete
                                            </a>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                        @endforeach
                    </tbody>

                </table>
    
    
                </div>
                
                <div class="mt-4">
                    @if ($kits instanceof \Illuminate\Pagination\LengthAwarePaginator)
                        {{ $kits->appends(request()->except(['page', '_token']))->links() }}
                    @endif
                </div>
            </div>
        </div>
    </div>




<!--begin::Modal - Create Marketing Kit-->
<div class="modal fade" id="kt_modal_create_marketing_kit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Create Marketing Kit</h3>
                </div>
                <form id="marketingKitForm">
                  <div class="row mb-2" >
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                          <select id="category_id_add" name="category_id" class="select3 form-select category-select" required>
                              <option value="">Select Category</option>
                              @foreach($categories as $cat)
                                  <option value="{{ $cat->sno }}">{{ $cat->category_name }}</option>
                              @endforeach
                          </select>
                          <div class="text-danger validation-msg" id="category_id_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Sub Category<span class="text-danger">*</span></label>
                          <select id="subcategory_id_add" name="subcategory_id[]" class="select3 form-select subcategory-select" required multiple>
                            <option value="">Select Subcategory</option>
                        </select>
                        <div class="text-danger validation-msg" id="sub_category_id_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Marketing Kit Name<span class="text-danger">*</span></label>
                          <input type="text" class="form-control" id="" placeholder="Enter Marketing Kit Name" />
                          <div class="text-danger validation-msg" id="kit_name_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">File Type<span class="text-danger">*</span></label>
                          <select id="file_type_add" name="file_type" class="select3 form-select">
                            <option value="">Select File Type</option>
                            <option value="zip">.Zip</option>
                            <option value="rar">.Rar</option>
                            <option value="7z">.7z</option>
                            <option value="pdf">.PDF</option>
                            <option value="doc">.DOC</option>
                            <option value="docx">.DOCX</option>
                            <option value="ppt">.PPT</option>
                            <option value="pptx">.PPTX</option>
                            <option value="xls">.XLS</option>
                            <option value="xlsx">.XLSX</option>
                            <option value="jpeg">.JPEG</option>
                            <option value="jpg">.JPG</option>
                            <option value="png">.PNG</option>
                            {{-- <option value="gif">.GIF</option> --}}
                            <option value="svg">.SVG</option>
                            {{-- <option value="mp4">.MP4</option> --}}
                            <option value="mov">.MOV</option>
                            {{-- <option value="mp3">.MP3</option> --}}
                            <option value="wav">.WAV</option>
                        </select>

                          <div class="text-danger validation-msg" id="file_type_error" style="display:none;"></div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-lg-12 mb-3">
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" id="preview_check_add" name="preview_check" type="checkbox" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Preview</label>
                          </div>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" id="download_check_add" name="download_check" type="checkbox" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Download</label>
                          </div>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input"  type="checkbox" id="buy_chk" name="buy_chk"  />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Buy</label>
                          </div>
                            
                      </div>
                      <div class="mb-4 mt-1" id="add_more_btn_wrapper_add" style="display: none;">
                        <div class="form-blocks-container-add"></div>
                        <div class="text-danger validation-msg" id="buy_items_error" style="display:none;"></div>
                        <!--<div class="col-lg-3 mb-3"  id="delivery_input_wrapper" style="display: none;">-->
                        <!--  <label class="text-dark mb-1 fs-6 fw-semibold">Delivery Charges</label>-->
                        <!--  <input type="text" class="form-control" id="delivery_charges_main" placeholder="Enter Delivery Charges" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="0"/>-->
                        <!--  <div class="text-danger validation-msg" id="delivery_error" style="display:none;"></div>-->
                        <!--</div>-->
                        <button class="btn btn-primary btn-sm" id="add_more_variant_buy_add">
                            <i class="mdi mdi-plus me-1"></i> Add more
                        </button>
                      </div>

                  </div>
                  <div class="divider mt-0 mb-2">
                      <div class="text-black mb-2 fs-4 fw-semibold divider-text">Varients</div>
                  </div>
                  <div class="row">
                    @foreach ($Variantdata as $variant)
                        <div class="col-lg-4 mb-3" style="display:none;">
                            <div class="card shadow-none border border-gray-300">
                                <div class="card-action">
                                    <div class="card-header align-items-center px-4 py-2 rounded" style="background-color: #dfdfdf !important;">
                                        <div class="card-action-title text-dark fs-6 fw-semibold cursor-pointer">
                                            <div class="form-check mt-1 mb-0">
                                                <input class="form-check-input me-0 variant-check" id="variant_check_{{ $variant->sno }}" name="variant_check[]" type="checkbox" />
                                                <label class="form-check-label text-black mb-1 fs-6 fw-semibold">
                                                    {{ $variant->variant_name }}
                                                </label>
                                            </div>
                                        </div>
                                        <div class="card-action-element">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="javascript:;" class="variant_toggle_icon text-black" data-target=".variant_body_{{ $variant->sno }}">
                                                        <i class="mdi mdi-chevron-up fs-3"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                    
                                <div class="collapse variant_body_{{ $variant->sno }}">
                                    <div class="card-body px-4 py-4">
                                        <div class="scroll-y min-h-200px max-h-200px px-3">
                                            @php $vIndex = 1; @endphp
                                            @foreach ($variant->variables as $variable)
                                                <div class="row">
                                                    <div class="col-lg-6">
                                                        <div class="form-check mt-6 mb-0">
                                                            <input class="form-check-input me-0 variant-checkbox" data-id="{{ $variable->sno }}" type="checkbox" id="variant_{{ $variant->sno }}_{{ $vIndex }}" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                {{ $variable->variables_name }}
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <label class="text-dark mb-1 fs-7 fw-semibold">
                                                            Cost <span class="text-danger" style="display: none !important;" id="reqd_{{ $variant->sno }}_{{ $vIndex }}"> *</span>
                                                        </label>
                                                        <input type="text" class="form-control fs-7 px-2 py-1 variant-input" id="variant_{{ $variant->sno }}_{{ $vIndex }}_tbox"
                                                            oninput="this.value = this.value.replace(/[^0-9]/g, '')" placeholder="Enter Cost" disabled />
                                                    </div>
                                                </div>
                                                <div class="border-dashed border-1 border-bottom border-gray-700 mt-3 mb-2"></div>
                                                @php $vIndex++; @endphp
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
              
                 
                      <!--<div class="col-lg-4 mb-3">-->
                      <!--  <label class="text-dark mb-1 fs-6 fw-semibold">Attachment <span class="text-danger">*</span></label>-->
                      <!--  <div class="d-flex align-items-center gap-4">-->
                      <!--    <div class="text-center">-->
                      <!--        <img id="attachmentPreview"-->
                      <!--            src="{{asset('assets/eapl_images/Document.jpg')}}"-->
                      <!--            alt="user-avatar"-->
                      <!--            class="d-block w-150px h-100px rounded border border-gray-600 border-solid mb-2" />-->
                      <!--        <p id="fileNameDisplay" class="mb-0 text-success small"></p>-->
                      <!--    </div>-->

                      <!--      <div class="button-wrapper">-->
                      <!--          <div class="d-flex align-items-start mt-2 mb-2">-->
                      <!--              <label for="attachmentUpload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Attachment">-->
                      <!--                  <i class="mdi mdi-tray-arrow-up"></i>-->
                      <!--                  <input type="file" id="attachmentUpload" class="marketing_kit_file-in" hidden  />-->
                      <!--                  <div class="text-danger validation-msg" id="attachment_error" style="display:none;"></div>-->
                      <!--                </label>-->
                      <!--              <button type="button" class="btn btn-sm btn-outline-danger marketing_kit_file-reset" id="resetAttachment" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Attachment">-->
                      <!--                  <i class="mdi mdi-reload"></i>-->
                      <!--              </button>-->
                      <!--          </div>-->
                      <!--          <div class="small text-muted">Allowed: All | Max size: 5MB</div>-->
                      <!--      </div>-->
                      <!--  </div>-->
                      <!--</div>-->
                      <!-- Upload or URL Radio Options -->
                        <div class="col-lg-4 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Source Type <span class="text-danger">*</span></label>
                          <div class="d-flex gap-3">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="source_type" id="source_upload" value="upload" checked>
                              <label class="form-check-label" for="source_upload">Upload</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="source_type" id="source_url" value="url">
                              <label class="form-check-label" for="source_url">URL</label>
                            </div>
                          </div>
                        </div>
                        
                        <!-- Upload Block -->
                        <div class="col-lg-4 mb-3" id="uploadSection">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Attachment <span class="text-danger">*</span></label>
                          <div class="d-flex align-items-center gap-4">
                            <div class="text-center">
                              <img id="attachmentPreview"
                                   src="{{asset('assets/eapl_images/Document.jpg')}}"
                                   alt="user-avatar"
                                   class="d-block w-150px h-100px rounded border border-gray-600 border-solid mb-2" />
                              <p id="fileNameDisplay" class="mb-0 text-success small"></p>
                            </div>
                        
                            <div class="button-wrapper">
                              <div class="d-flex align-items-start mt-2 mb-2">
                                <label for="attachmentUpload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Attachment">
                                  <i class="mdi mdi-tray-arrow-up"></i>
                                  <input type="file" id="attachmentUpload" class="marketing_kit_file-in" hidden />
                                  <div class="text-danger validation-msg" id="attachment_error" style="display:none;"></div>
                                </label>
                                <button type="button" class="btn btn-sm btn-outline-danger marketing_kit_file-reset" id="resetAttachment" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Attachment">
                                  <i class="mdi mdi-reload"></i>
                                </button>
                              </div>
                              <div class="small text-muted">Allowed: All | Max size: 5MB</div>
                            </div>
                          </div>
                        </div>
                        
                        <!-- URL Block (Hidden by default) -->
                        <div class="col-lg-4 mb-3 d-none" id="urlSection">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Attachment URL <span class="text-danger">*</span></label>
                          <input type="url" class="form-control" id="attachmentUrl" placeholder="https://example.com/your-file.pdf" />
                          <div class="text-muted small mt-1">Provide a valid URL to an online resource.</div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Thumbnail <span class="text-danger">*</span></label>
                            <div class="d-flex align-items-center gap-4">
                              <div class="text-center">
                                  <img id="thumbnailPreview"
                                      src="{{asset('assets/eapl_images/Document.jpg')}}"
                                      alt="user-avatar"
                                      class="d-block w-150px h-100px rounded border border-gray-600 border-solid mb-2" />
                                  <p id="fileNameDisplaythumb" class="mb-0 text-success small"></p>
                              </div>
    
                                <div class="button-wrapper">
                                    <div class="d-flex align-items-start mt-2 mb-2">
                                        <label for="thumbnailUpload" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Thumbnail">
                                            <i class="mdi mdi-tray-arrow-up"></i>
                                            <input type="file" id="thumbnailUpload" class="marketing_kit_Thumbnail-in" hidden  />
                                            <div class="text-danger validation-msg" id="thumbnail_error" style="display:none;"></div>
                                          </label>
                                        <button type="button" class="btn btn-sm btn-outline-danger marketing_kit_Thumbnail-reset" id="resetThumbnail" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Thumbnail">
                                            <i class="mdi mdi-reload"></i>
                                        </button>
                                    </div>
                                    <div class="small text-muted">Allowed: All | Max size: 5MB</div>
                                </div>
                            </div>
                        </div>
                      <div class="col-lg-8 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                          <textarea class="form-control" rows="2" placeholder="Enter Description"></textarea>
                      </div>
                      
                  </div>
                  <div class="d-flex justify-content-end align-items-center mt-4">
                      <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                       <button type="button" class="btn btn-primary d-flex align-items-center gap-2" id="marketing_kit_add">
                          <span class="btn-text">Create Marketing Kit</span>
                          <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true" id="kit_add_spinner"></span>
                        </button>
                  </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Marketing Kit-->



<!--begin::Modal - Update Marketing Kit-->
<div class="modal fade" id="kt_modal_update_marketing_kit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Update Marketing Kit</h3>
                </div>
                <form id="marketingKitFormedit" enctype="multipart/form-data">
                    <input type="text" id="hidden_kit_sno" hidden />
                  <div class="row mb-2" >
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                          <select id="category_id_edit" name="category_id" class="select3 form-select category-select-edit" required>
                              <option value="">Select Category</option>
                              @foreach($categories as $cat)
                                  <option value="{{ $cat->sno }}">{{ $cat->category_name }}</option>
                              @endforeach
                          </select>
                          <div class="text-danger validation-msg" id="category_id_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Sub Category<span class="text-danger">*</span></label>
                          <select id="subcategory_id_edit" name="subcategory_id[]" class="select3 form-select subcategory-select" required multiple>
                            <option value="">Select Subcategory</option>
                        </select>
                        <div class="text-danger validation-msg" id="sub_category_id_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Marketing Kit Name<span class="text-danger">*</span></label>
                          <input type="text" class="form-control" id="marketing-edit-name" placeholder="Enter Marketing Kit Name" />
                          <div class="text-danger validation-msg" id="kit_name_error" style="display:none;"></div>
                      </div>
                      <div class="col-lg-3 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">File Type<span class="text-danger">*</span></label>
                          <select id="file_type_edit" name="file_type" class="select3 form-select">
                            <option value="">Select File Type</option>
                            <option value="zip">.Zip</option>
                            <option value="rar">.Rar</option>
                            <option value="7z">.7z</option>
                            <option value="pdf">.PDF</option>
                            <option value="doc">.DOC</option>
                            <option value="docx">.DOCX</option>
                            <option value="ppt">.PPT</option>
                            <option value="pptx">.PPTX</option>
                            <option value="xls">.XLS</option>
                            <option value="xlsx">.XLSX</option>
                            <option value="jpeg">.JPEG</option>
                            <option value="jpg">.JPG</option>
                            <option value="png">.PNG</option>
                            <option value="svg">.SVG</option>
                        </select>

                          <div class="text-danger validation-msg" id="file_type_error" style="display:none;"></div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-lg-12 mb-3">
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" id="preview_check_edit" name="preview_check" type="checkbox" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Preview</label>
                          </div>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" id="download_check_edit" name="download_check" type="checkbox" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Download</label>
                          </div>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input"  type="checkbox" id="buy_chk_edit" name="buy_chk"  />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Buy</label>
                          </div>
                      </div>
                      <div class="mb-4 mt-1" id="add_more_btn_wrapper_edit" style="display: none;">
                        <div class="form-blocks-container-edit"></div>
                            <!--<div class="col-lg-3 mb-3"  id="delivery_input_wrapper_edit" style="display: none;">-->
                            <!--  <label class="text-dark mb-1 fs-6 fw-semibold">Delivery Charges</label>-->
                            <!--  <input type="text" class="form-control" id="delivery_charges_edit" placeholder="Enter Delivery Charges" oninput="this.value = this.value.replace(/[^0-9]/g, '')" value="0"/>-->
                            <!--  <div class="text-danger validation-msg" id="delivery_error" style="display:none;"></div>-->
                            <!--</div>-->
                        <div class="text-danger validation-msg" id="buy_items_error" style="display:none;"></div>
                        <button class="btn btn-primary btn-sm" id="add_more_variant_buy_edit">
                            <i class="mdi mdi-plus me-1"></i> Add more
                        </button>
                      </div>

                  </div>
                  <div class="divider mt-0 mb-2">
                      <div class="text-black mb-2 fs-4 fw-semibold divider-text">Varients</div>
                  </div>
                  <div class="row">
                    <!-- Upload or URL Radio Options -->
                        <div class="col-lg-4 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Source Type <span class="text-danger">*</span></label>
                          <div class="d-flex gap-3">
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="source_type_edit" id="source_upload_edit" value="upload" checked>
                              <label class="form-check-label" for="source_upload">Upload</label>
                            </div>
                            <div class="form-check">
                              <input class="form-check-input" type="radio" name="source_type_edit" id="source_url_edit" value="url">
                              <label class="form-check-label" for="source_url">URL</label>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-4 mb-3" id="uploadSectionedit">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Attachment <span class="text-danger">*</span></label>
                            <div class="d-flex align-items-center gap-4">
                              <div class="text-center">
                                  <img id="attachmentPreviewedit"
                                      src="{{asset('assets/eapl_images/Document.jpg')}}"
                                      alt="user-avatar"
                                      class="d-block w-150px h-100px rounded border border-gray-600 border-solid mb-2" />
                                  <p id="fileNameDisplayedit" class="mb-0 text-success small"></p>
                              </div>
    
                                <div class="button-wrapper">
                                    <div class="d-flex align-items-start mt-2 mb-2">
                                        <label for="attachmentUploadedit" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Attachment">
                                            <i class="mdi mdi-tray-arrow-up"></i>
                                            <input type="file" id="attachmentUploadedit" class="marketing_kit_file-in-edit" hidden  />
                                            <div class="text-danger validation-msg" id="attachment_error" style="display:none;"></div>
                                          </label>
                                        <button type="button" class="btn btn-sm btn-outline-danger marketing_kit_file-reset-edit" id="resetAttachmentedit" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Attachment">
                                            <i class="mdi mdi-reload"></i>
                                        </button>
                                    </div>
                                    <div class="small text-muted">Allowed: All | Max size: 5MB</div>
                                </div>
                            </div>
                        </div>
                          <!-- URL Block (Hidden by default) -->
                        <div class="col-lg-4 mb-3 d-none" id="urlSectionedit">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Attachment URL <span class="text-danger">*</span></label>
                          <input type="url" class="form-control" id="attachmentUrledit" placeholder="https://example.com/your-file.pdf" />
                          <div class="text-muted small mt-1">Provide a valid URL to an online resource.</div>
                        </div>
                     
                       <div class="col-lg-4 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Thumbnail <span class="text-danger">*</span></label>
                        <div class="d-flex align-items-center gap-4">
                          <div class="text-center">
                              <img id="thumbnailPreviewedit"
                                  src="{{asset('assets/eapl_images/Document.jpg')}}"
                                  alt="user-avatar"
                                  class="d-block w-150px h-100px rounded border border-gray-600 border-solid mb-2" />
                              <p id="fileNameDisplaythumbedit" class="mb-0 text-success small"></p>
                          </div>

                            <div class="button-wrapper">
                                <div class="d-flex align-items-start mt-2 mb-2">
                                    <label for="thumbnailUploadedit" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Thumbnail">
                                        <i class="mdi mdi-tray-arrow-up"></i>
                                        <input type="file" id="thumbnailUploadedit" class="marketing_kit_Thumbnail-in" hidden  />
                                        <div class="text-danger validation-msg" id="thumbnail_error" style="display:none;"></div>
                                      </label>
                                    <button type="button" class="btn btn-sm btn-outline-danger marketing_kit_Thumbnail-reset" id="resetThumbnail" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Thumbnail">
                                        <i class="mdi mdi-reload"></i>
                                    </button>
                                </div>
                                <div class="small text-muted">Allowed: All | Max size: 5MB</div>
                            </div>
                        </div>
                      </div>
                       <div class="col-lg-8 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                          <textarea class="form-control" rows="2" id="description_edit"placeholder="Enter Description"></textarea>
                      </div>
                  </div>
                  <div class="d-flex justify-content-end align-items-center mt-4">
                      <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                      <a href="javascript:;" class="btn btn-primary d-flex align-items-center gap-2" id="marketing_kit_edit">
                        <span class="btn-text">Update Marketing Kit</span>
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true" id="kit_edit_spinner"></span>
                      </a>
                  </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Marketing Kit-->

<!--begin::Modal - View Marketing Kit-->
<div class="modal fade" id="kt_modal_view_marketing_kit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">View Marketing Kit</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-3 text-dark fs-6 fw-semibold">Marketing Kit</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-bold">Smart Job Poster Design for Faster Hiring</label>
                </div>
                <div class="row mb-3">
                    <label class="col-3 text-dark fs-6 fw-semibold">Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-bold view-category"></label>
                </div>
                <div class="row mb-3">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sub Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-bold view-sub-category"></label>

                </div>
                <div class="row mb-3">
                    <label class="col-3 text-dark fs-6 fw-semibold">File Type</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-bold view-file-type"></label>
                </div>
                <div class="row mb-3">
                    <div class="col-lg-4">
                        <img src="{{asset('assets/eapl_images/marketing_kit/poster.jpg')}}" alt="user-avatar" class="d-block w-px-150 h-px-150 rounded border border-gray-600 border-solid" id="marketing_kit_atmt" />
                    </div>
                    <div class="col-lg-8 check-section">

                    </div>
                </div>
                <div class="row mb-3 hidden" id="tableHidden" >
                    <div class="col-lg-12 mb-3">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-80px">Count</th>
                                    <th class="min-w-80px">Cost</th>
                                    <th class="min-w-50px text-center">GST(%)</th>
                                    <th class="min-w-125px">Weight Value</th>
                                    <th class="min-w-125px">Weight Unit</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">

                            </tbody>
                        </table>
                    </div>
                    <!--<div class="col-lg-12 text-black text-center fs-4 fw-semibold mb-3"><u>Variant Groups</u></div>-->
                    <!--<div class="variant-variant-wrapper scroll-y max-h-250px px-3"></div>-->
                </div>
                <div class="row mb-3">
                    <label class="col-12 text-dark fs-6 fw-semibold mb-2">Description</label>
                    <label class="col-12 text-black fs-6 fw-semibold view-description"></label>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Marketing Kit-->

<!--begin::Modal - Delete Marketing Kit-->
<div class=" modal fade" id="kt_modal_delete_marketing_kit" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Marketing Kit?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Smart Job Poster Design for Faster Hiring</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="button" id="confirmDeleteBtn" class="btn btn-danger me-3">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Marketing Kit-->

<!--begin::Modal - Preview Marketing Kit-->
<div class="modal fade" id="kt_modal_preview_marketing_kit" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog">
        <!--begin::Modal content-->
        <div class="modal-content bg-transparent shadow-none rounded">
            <!--begin::Modal body-->
            <div class="modal-body py-0 px-0">
                <div class="d-flex align-items-center justify-content-end position-relative end-0 border-0 pb-0 mb-4">
                    <div class="btn btn-sm btn-icon btn-active-color-primary fs-1 fw-semibold text-white" data-bs-dismiss="modal">x</div>
                </div>
                <div class="row">
                    <div class="col-lg-12 py-0 px-0">
                        <img id="marketing_preview_image" src="{{asset('assets/eapl_images/marketing_kit/poster.jpg')}}" alt="user-avatar" class="d-block w-100 h-100 rounded border border-gray-600 border-solid" />
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Preview Marketing Kit-->
<!--begin::Modal - Add to Cart Marketing Kit-->
<div class="modal fade" id="kt_modal_add_to_cart" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
          <!--begin::Modal header-->
          <div class="modal-header justify-content-end border-0 pb-0">
              <!--begin::Close-->
              <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                  <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                  <span class="svg-icon svg-icon-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                          <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                      </svg>
                  </span>
                  <!--end::Svg Icon-->
              </div>
              <!--end::Close-->
          </div>
          <!--end::Modal header-->
          <!--begin::Modal body-->
          <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
              <!--begin::Heading-->
              <div class="mb-8 text-center">
                  <h3 class="text-center mb-4 text-black">Add To Cart</h3>
              </div>
              <div class="d-flex justify-content-center align-items-start w_99 mb-3">
                  <img src="{{asset('assets/eapl_images/marketing_kit/poster.jpg')}}" alt="user-avatar" id="marketing_kit_cart_view" class="w-175px h-175px rounded border border-gray-600 border-solid" />
              </div>
              <input type="hidden" id="martketing_kit_id" />
              <input type="hidden" id="buy_item_id" />
              <div class="text-dark fs-5 fw-semibold text-center mb-3 " id="martketing_name_cart_view" data-bs-toggle="tooltip" data-bs-placement="bottom" title=""></div>
              <div class="text-black text-center fs-4 fw-semibold mb-3"><u>Variant</u></div>
              <div class="row" id="accordion-cart-view">
              </div>
              <div class="d-flex align-items-center justify-content-center gap-3 mb-2 mt-3">
                  <a href="javascript:;" class="btn fw-bold btn-secondary" data-bs-dismiss="modal">Cancel</a>
                  <a href="javascript:;" class="btn text-white" style="background-color: #7A55C8;">
                      <span class="me-1">
                          <i class="mdi mdi-cart-outline fs-4"></i>
                      </span>
                      <span class="fs-6" id="kt_add_to_cart_btn">Add To Cart</span>
                  </a>
              </div>
          </div>
          <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add to Cart Marketing Kit-->

<!--begin::Modal - Cart Marketing Kit-->
<div class="modal fade" id="kt_modal_cart" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
          <!--begin::Modal header-->
          <div class="modal-header justify-content-end border-0 pb-0">
              <!--begin::Close-->
              <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                  <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                  <span class="svg-icon svg-icon-1">
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                          <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                      </svg>
                  </span>
                  <!--end::Svg Icon-->
              </div>
              <!--end::Close-->
          </div>
          <!--end::Modal header-->
          <!--begin::Modal body-->
          <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
              <!--begin::Heading-->
              <div class="mb-8 text-center">
                  <h3 class="text-center mb-4 text-black">Cart's</h3>
              </div>
              <div class="row mb-6"  >
                <div class="col-8" id="cart-items-container">
                  <!-- Cart items will go here -->
                </div>
                <div class="col-4" id="cart-summary-container">
                    <!-- Summary will go here -->
                </div>


              </div>
              <div class="d-flex align-items-center justify-content-end gap-3 mb-2">
                  <a href="javascript:;" class="btn fw-bold btn-primary" data-bs-dismiss="modal">Cancel</a>
                  <a href="javascript:;" class="btn text-white"  style="background-color: #7A55C8;">
                      <span class="me-1">
                          <i class="mdi mdi-lightning-bolt fs-4"></i>
                      </span>
                      <span class="fs-6" id="btnPlaceOrderCart">Place Order</span>
                  </a>
              </div>
          </div>
          <!--end::Modal body-->
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Cart Marketing Kit-->
<!-- begin::Modal - Buy Marketing Kit -->
<div class="offcanvas offcanvas-end w-500px" id="kt_modal_buy_marketing_kit" tabindex="-1" data-bs-keyboard="false" data-bs-backdrop="static" style="border-top-left-radius: 15px !important;border-bottom-left-radius: 15px !important;">
    <div class="offcanvas-header border-bottom mb-1">
        <h5 class="offcanvas-title">Buy Marketing Kit</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1 py-0 px-0 mb-15">
        <!--<div class="d-flex align-items-center justify-content-center bg-gray-300 pt-4 pb-4 mb-2">-->
        <!--    <img src="{{asset('/marketing_kit/poster.jpg')}}" alt="user-avatar" class="w-150 h-150 rounded border border-gray-600 border-solid payment-image" id="marketing_kit_payment_image" />-->
        <!--</div>-->
        <div id="marketing_kit_payment_wrapper"></div>
        <div class="mb-0 px-4 pt-2 pb-4">
            <div class="text-black fw-semibold mk_name fs-5 mb-2 marketing_pay_name">Smart Job Poster Design for Faster Hiring - Posters</div>
            <div class="d-block text-dark fw-semibold text-justify fs-7 mb-4 marketing_descripion">&emsp;&emsp;Design professional job posters to attract the right candidates with clear, eye-catching visuals.</div>
            <div class="text-black text-center fs-4 fw-semibold mb-3"><u>Choose Item</u></div>
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <div class="accordion" id="accordionExamplepayment">

                    </div>
                </div>
            </div>
            <div class="text-black border-bottom text-center fs-5 fw-semibold mt-10 mb-3">Price Details</div>
            <div class="mb-0">
              <div class="d-flex align-items-center justify-content-between px-3 mb-3">
                <div class="text-dark fs-6 fw-semibold">Count (Pcs)</div>
                <div class="text-black fs-6 text-end fw-bold price-count">0</div>
            </div>
            <div class="d-flex align-items-center justify-content-between px-3 mb-3">
                <div class="text-dark fs-6 fw-semibold">Cost</div>
                <div class="text-black fs-6 text-end fw-bold price-cost">0</div>
            </div>
            <div class="d-flex align-items-center justify-content-between px-3 mb-3">
                <div class="text-dark fs-6 fw-semibold">GST <span class="fs-7">( 5% )</span></div>
                <div class="text-black fs-6 text-end fw-bold price-gst">0</div>
            </div>
            <div class="d-flex align-items-center justify-content-between px-3 mb-3">
                <div class="text-dark fs-6 fw-semibold">Delivery Charges</div>
                <div class="text-black fs-6 text-end fw-bold price-delivery">0</div>
            </div>
            <div class="d-flex align-items-center justify-content-between px-3 mb-3">
                <div class="text-black fs-5 fw-semibold">Total Amount</div>
                <div class="text-black fs-5 text-end fw-bold price-total">0</div>
            </div>
            <div class="d-flex align-items-center justify-content-center flex-wrap mb-1">
                <div class="position-fixed bottom-0 pb-3">
                    <a href="javascript:;" class="badge bg-primary rounded text-white me-3" data-bs-toggle="offcanvas" data-bs-target="#kt_modal_buy_marketing_kit" >

                        <span class="fs-5 mb-5">Cancel</span>
                    </a>
                    <a href="javascript:;" id="btnPlaceOrder" class="badge rounded text-white" style="background-color: #7A55C8;">
                      <span class="me-1"><i class="mdi mdi-lightning-bolt fs-4"></i></span>
                      <span class="fs-6">Place Order</span>
                  </a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- end::Modal - Buy Marketing Kit -->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>


  /* Customize Toastr notification */
  .toast-success {
      background-color: green;
  }

  /* Customize Toastr notification */
  .toast-error {
      background-color: rgb(196, 3, 3);
  }
  .error_msg {
      border: solid 2px red !important;
      border-color: red !important;
  }
  
  .payment-image {
      width: 190px;
      height: 150px;
      object-fit: cover;
      border-radius: 0.5rem;
      border: 1px solid #666;
    }
    
    #tableHidden.hidden {
      display: none !important;
    }
</style>
<style>
    .active.bg-light-success {
        background-color: #d1e7dd !important;
        border-radius: 40px;
    }
</style>
<script>
  $(document).ready(function () {
    $('input[name="source_type"]').change(function () {
      const selected = $('input[name="source_type"]:checked').val();
      if (selected === 'upload') {
        $('#uploadSection').removeClass('d-none');
        $('#urlSection').addClass('d-none');
      } else {
        $('#uploadSection').addClass('d-none');
        $('#urlSection').removeClass('d-none');
      }
    });
  });
  $(document).ready(function () {
    $('input[name="source_type_edit"]').change(function () {
      const selected = $('input[name="source_type_edit"]:checked').val();
      if (selected === 'upload') {
        $('#uploadSectionedit').removeClass('d-none');
        $('#urlSectionedit').addClass('d-none');
      } else {
        $('#uploadSectionedit').addClass('d-none');
        $('#urlSectionedit').removeClass('d-none');
      }
    });
  });
</script>
<script>
  $(document).ready(function () {

    // Colors section master checkbox
    $('#colors_check_add').on('change', function () {
      const isChecked = $(this).is(':checked');

      // Enable/disable color checkboxes
      $('.color-checkbox').prop('disabled', !isChecked).prop('checked', false);
      $('.color-input').prop('disabled', true).val('');

      // Show/hide section
      const collapseTarget = $(this).closest('.card').find('.collapse');
      if (isChecked) {
        collapseTarget.addClass('show');
      } else {
        collapseTarget.removeClass('show');
      }
    });

    // Sizes section master checkbox
    $('#size_check_add').on('change', function () {
      const isChecked = $(this).is(':checked');

      // Enable/disable size checkboxes
      $('.size-checkbox').prop('disabled', !isChecked).prop('checked', false);
      $('.size-input').prop('disabled', true).val('');

      // Show/hide section
      const collapseTarget = $(this).closest('.card').find('.collapse');
      if (isChecked) {
        collapseTarget.addClass('show');
      } else {
        collapseTarget.removeClass('show');
      }
    });

    // Color checkbox toggle -> Enable Cost only if both checked
    $(document).on('change', '.color-checkbox', function () {
      const input = $(this).closest('.row').find('.color-input');
      if ($(this).is(':checked') && $('#colors_check_add').is(':checked')) {
        input.prop('disabled', false);
      } else {
        input.prop('disabled', true).val('');
      }
    });

    // Size checkbox toggle -> Enable Cost only if both checked
    $(document).on('change', '.size-checkbox', function () {
      const input = $(this).closest('.row').find('.size-input');
      if ($(this).is(':checked') && $('#size_check_add').is(':checked')) {
        input.prop('disabled', false);
      } else {
        input.prop('disabled', true).val('');
      }
    });

  });
  </script>

<!--//add more -->
<script>
  $(document).ready(function () {
      // Toggle block when Buy is checked
      $('#buy_chk').on('change', function () {
          if ($(this).is(':checked')) {
              $('#variant_tbox_add').show();
              $('#add_more_btn_wrapper_add').show(); // 👈 Show the button
               $('#delivery_input_wrapper').show();
              $('#add_more_variant_buy_add').click(); // add initial block
          } else {
              $('#variant_tbox_add').hide();
              $('#add_more_btn_wrapper_add').hide(); // 👈 Hide the button
              $('#delivery_input_wrapper').hide();
              $('.form-blocks-container-add').html(''); // remove all blocks
          }
      });

    // Click Add More
    $('#add_more_variant_buy_add').on('click', function (e) {
    e.preventDefault();
    let index = $('.form-blocks-container-add .form-row-block').length + 1;

    let block = `
        <div class="form-row-block mb-3 px-3 py-2 position-relative border rounded">
            <div class="row" id="buyItem_${index}">
                
                <!-- Count -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Count <span class="text-danger">*</span></label>
                    <input type="text" name="count[]" class="form-control" placeholder="Enter Count" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
                
                <!-- Cost -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cost <span class="text-danger">*</span></label>
                    <input type="text" name="cost[]" class="form-control" placeholder="Enter Cost" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
                
                <!-- GST -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">GST (%) <span class="text-danger">*</span></label>
                    <select name="gst[]" class="form-select select34">
                        <option value="">Select GST(%)</option>
                        <option value="5">5%</option>
                        <option value="12">12%</option>
                        <option value="18">18%</option>
                    </select>
                </div>
                
                <!-- Weight Value -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Weight Value <span class="text-danger">*</span></label>
                    <input type="text" name="weight_value[]" class="form-control" placeholder="Enter Weight" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" />
                </div>
                
                <!-- Weight Unit -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Weight Unit <span class="text-danger">*</span></label>
                    <select name="weight_unit[]" class="form-select select34">
                        <option value="">Select Unit</option>
                        <option value="KG">KG</option>
                        <option value="Gram">Gram</option>
                    </select>
                </div>

                <!-- Remove Button -->
                <div class="col-lg-2 d-flex align-items-end mb-3">
                    <button type="button" class="btn btn-outline-danger remove-block">
                        <i class="mdi mdi-delete fs-4"></i>
                    </button>
                </div>
            </div>
        </div>
    `;

    $('.form-blocks-container-add').append(block);
});



      // Remove a block
      $(document).on('click', '.remove-block', function () {
          $(this).closest('.form-row-block').remove();
      });
  });
  $(document).ready(function () {
      // Toggle block when Buy is checked
      $('#buy_chk_edit').on('change', function () {
          if ($(this).is(':checked')) {
              $('#variant_tbox_edit').show();
              $('#add_more_btn_wrapper_edit').show(); // 👈 Show the button
               $('#delivery_input_wrapper_edit').show();
              $('#add_more_variant_buy_edit').click(); // add initial block
          } else {
              $('#variant_tbox_add').hide();
              $('#add_more_btn_wrapper_edit').hide(); // 👈 Hide the button
              $('#delivery_input_wrapper_edit').hide();
              $('.form-blocks-container-edit').html(''); // remove all blocks
          }
      });


      // Click Add More edit
      $('#add_more_variant_buy_edit').on('click', function (e) {
          e.preventDefault();
          let index = $('.form-blocks-container-edit .form-row-block-edit').length + 1;

         let block = `
        <div class="form-row-block-edit mb-3 px-3 py-2 position-relative border rounded">
            <div class="row" id="buyItem_${index}">
                
                <!-- Count -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Count <span class="text-danger">*</span></label>
                    <input type="text" name="count[]" class="form-control" placeholder="Enter Count" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
                
                <!-- Cost -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Cost <span class="text-danger">*</span></label>
                    <input type="text" name="cost[]" class="form-control" placeholder="Enter Cost" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
                
                <!-- GST -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">GST (%) <span class="text-danger">*</span></label>
                    <select name="gst[]" class="form-select select34">
                        <option value="">Select GST(%)</option>
                        <option value="5">5%</option>
                        <option value="12">12%</option>
                        <option value="18">18%</option>
                    </select>
                </div>
                
                <!-- Weight Value -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Weight Value <span class="text-danger">*</span></label>
                    <input type="text" name="weight_value[]" class="form-control" placeholder="Enter Weight" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" />
                </div>
                
                <!-- Weight Unit -->
                <div class="col-lg-2 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Weight Unit <span class="text-danger">*</span></label>
                    <select name="weight_unit[]" class="form-select select34">
                        <option value="">Select Unit</option>
                        <option value="KG">KG</option>
                        <option value="Gram">Gram</option>
                    </select>
                </div>

                <!-- Remove Button -->
                <div class="col-lg-2 d-flex align-items-end mb-3">
                    <button type="button" class="btn btn-outline-danger remove-block">
                        <i class="mdi mdi-delete fs-4"></i>
                    </button>
                </div>
            </div>
        </div>
    `;

          $('.form-blocks-container-edit').append(block);



      });


      // Remove a block
      $(document).on('click', '.remove-block-edit', function () {
          $(this).closest('.form-row-block-edit').remove();
      });
  });
</script>
<script>
  //attchament
  $(document).ready(function () {
      const defaultImage = "{{ asset('assets/eapl_images/Document.jpg') }}";
      const previewImg = $('#attachmentPreview');
      const uploadInput = $('#attachmentUpload');

      uploadInput.on('change', function () {
          const file = this.files[0];
          const maxSizeMB = 16;
          const maxSizeBytes = maxSizeMB * 1024 * 1024;
          if (file) {

            
              if (file.size >= maxSizeBytes) {
                  alert('File size must be less than or equal to 15MB.');
                  $(this).val(''); // Clear the file input
                  previewImg.attr('src', defaultImage);
                  $('#fileNameDisplay').text('');
                  return;
              }
              const reader = new FileReader();

              reader.onload = function (e) {
                  if (file.type.startsWith('image/')) {
                      previewImg.attr('src', e.target.result);
                  } else {
                      previewImg.attr('src', defaultImage);
                  }
                  $('#fileNameDisplay').text(file.name); // 👈 Show file name
              };

              reader.readAsDataURL(file);
          }
      });


      $('#resetAttachment').on('click', function () {
          uploadInput.val('');
          previewImg.attr('src', defaultImage);
          $('#fileNameDisplay').text('');
      });

  });
  //thumbnail
  $(document).ready(function () {
      const defaultImagethumbnail = "{{ asset('assets/eapl_images/Document.jpg') }}";
      const previewImgthumbnail = $('#thumbnailPreview');
      const uploadInputthumbnail = $('#thumbnailUpload');

      uploadInputthumbnail.on('change', function () {
          const file = this.files[0];

          if (file) {
              if (file.size > 15 * 1024 * 1024) {
                  alert('File size must be less than or equal to 15MB.');
                  $(this).val('');
                  previewImgthumbnail.attr('src', defaultImagethumbnail);
                  $('#fileNameDisplaythumb').text('');
                  return;
              }
              // if (file.size > maxSizeBytes) {
              //     alert('File size must be less than or equal to 15MB.');
              //     $(this).val(''); // Clear the file input
              //     previewImgthumbnail.attr('src', defaultImagethumbnail);
              //     $('#fileNameDisplaythumb').text('');
              //     return;
              // }
              const reader = new FileReader();
              reader.onload = function (e) {
                  if (file.type.startsWith('image/')) {
                    previewImgthumbnail.attr('src', e.target.result);
                  } else {
                    previewImgthumbnail.attr('src', defaultImagethumbnail);
                  }
                  $('#fileNameDisplaythumb').text(file.name);
              };
              reader.readAsDataURL(file);
          }
      });

      $('#resetThumbnail').on('click', function () {
        uploadInputthumbnail.val('');
          previewImgthumbnail.attr('src', defaultImagethumbnail);
          $('#fileNameDisplaythumb').text('');
      });
  });
  
   //attchament edit
  $(document).ready(function () {
      const defaultImage = "{{ asset('assets/eapl_images/Document.jpg') }}";
      const previewImg = $('#attachmentPreviewedit');
      const uploadInput = $('#attachmentUploadedit');

      uploadInput.on('change', function () {
          const file = this.files[0];
          const maxSizeMB = 16;
          const maxSizeBytes = maxSizeMB * 1024 * 1024;
          if (file) {

             
              if (file.size >= maxSizeBytes) {
                  alert('File size must be less than or equal to 15MB.');
                  $(this).val(''); // Clear the file input
                  previewImg.attr('src', defaultImage);
                  $('#fileNameDisplayedit').text('');
                  return;
              }
              const reader = new FileReader();

              reader.onload = function (e) {
                  if (file.type.startsWith('image/')) {
                      previewImg.attr('src', e.target.result);
                  } else {
                      previewImg.attr('src', defaultImage);
                  }
                  $('#fileNameDisplayedit').text(file.name); // 👈 Show file name
              };

              reader.readAsDataURL(file);
          }
      });


      $('#resetAttachmentedit').on('click', function () {
          uploadInput.val('');
          previewImg.attr('src', defaultImage);
          $('#fileNameDisplayedit').text('');
      });

  });
  //thumbnail edit
  $(document).ready(function () {
      const defaultImagethumbnail = "{{ asset('assets/eapl_images/Document.jpg') }}";
      const previewImgthumbnail = $('#thumbnailPreviewedit');
      const uploadInputthumbnail = $('#thumbnailUploadedit');

      uploadInputthumbnail.on('change', function () {
          const file = this.files[0];

          if (file) {
              if (file.size > 15 * 1024 * 1024) {
                  alert('File size must be less than or equal to 15MB.');
                  $(this).val('');
                  previewImgthumbnail.attr('src', defaultImagethumbnail);
                  $('#fileNameDisplaythumbedit').text('');
                  return;
              }
         
              const reader = new FileReader();
              reader.onload = function (e) {
                  if (file.type.startsWith('image/')) {
                    previewImgthumbnail.attr('src', e.target.result);
                  } else {
                    previewImgthumbnail.attr('src', defaultImagethumbnail);
                  }
                  $('#fileNameDisplaythumbedit').text(file.name);
              };
              reader.readAsDataURL(file);
          }
      });

      $('#resetThumbnailedit').on('click', function () {
        uploadInputthumbnail.val('');
          previewImgthumbnail.attr('src', defaultImagethumbnail);
          $('#fileNameDisplaythumbedit').text('');
      });
  });

</script>

<script>

       
   
  $(document).ready(function () {
    // Add More
    // Category Change
    $(document).on('change', '.category-select', function () {
        let categoryId = $(this).val();
        let subcategorySelect = $('#subcategory_id_add');

        subcategorySelect.html('<option value="">Loading...</option>').prop('disabled', true);

        if (categoryId) {
            $.get(`/subcategories/${categoryId}`, function (data) {
                let options = '<option value="">Select Subcategory</option>';
                $.each(data, function (i, val) {
                    options += `<option value="${val.sno}">${val.marketing_subcategory_name}</option>`;
                });
                subcategorySelect.html(options).prop('disabled', false);
            });
        }
    });
      //add market
    $('#marketing_kit_add').on('click', function () {
       
            const $btn = $(this);
            const $spinner = $('#kit_add_spinner');
            const $btnText = $btn.find('.btn-text');
    
            // Prevent multiple clicks
            if ($btn.prop('disabled')) return;
    
            // Disable and show loader
            $btn.prop('disabled', true);
            $spinner.removeClass('d-none');
    
            let isValid = true;
    
            // Required fields
            $('#marketingKitForm').find('select[required], input[required]').each(function () {
                if (!$(this).val()) {
                    $(this).addClass('is-invalid');
                    isValid = false;
                } else {
                    $(this).removeClass('is-invalid');
                }
            });
    
            // Get base fields
            const categoryId = $('#category_id_add').val();
            const subCategoryIds = $('#subcategory_id_add').val(); // it's multiple
            const kitName = $('#marketingKitForm input[placeholder="Enter Marketing Kit Name"]').val();
            const fileType = $('#file_type_add').val();
            const previewCheck = $('#preview_check_add').is(':checked') ? 1 : 0;
            const downloadCheck = $('#download_check_add').is(':checked') ? 1 : 0;
            const buyCheck = $('#buy_chk').is(':checked') ? 1 : 0;
            const description = $('#marketingKitForm textarea').val();
            const sourceType = $('input[name="source_type"]:checked').val();
            const attachment = $('#attachmentUpload')[0].files[0]; // for upload
            const url = $('#attachmentUrl').val();  
            const thumbnail = $('#thumbnailUpload')[0].files[0];
            // Clear all previous error messages
              $('.validation-msg').hide().text('');
    
              // Attachment validation
                if (sourceType === 'upload') {
                    if (!attachment) {
                        $('#attachment_error').text('Please upload an attachment.').show();
                        isValid = false;
                    }
                } else if (sourceType === 'url') {
                    if (!url) {
                        $('#attachment_error').text('Please enter a valid URL.').show();
                        isValid = false;
                    }
                }
    
              // Category ID
              if (!categoryId) {
                  $('#category_id_error').text('Please select a category.').show();
                  isValid = false;
              }
               // sub Category ID
               if (!categoryId) {
                  $('#sub_category_id_error').text('Please select a category.').show();
                  isValid = false;
              }
    
              // Kit Name
              if (!kitName) {
                  $('#kit_name_error').text('Please enter a kit name.').show();
                  isValid = false;
              }
             
    
              // File Type
              if (!fileType) {
                  $('#file_type_error').text('Please select a file type.').show();
                  isValid = false;
              }
    
    
            // Buy Items - Collect if Buy is checked
            let buyItems = [];
            if (buyCheck) {
             
              $('.form-blocks-container-add .row').each(function () {
                  const idAttr = $(this).attr('id');
                  const id = idAttr ? idAttr.split('_')[1] : null;
                  const count = $(this).find('[name="count[]"]').val();
                  const cost = $(this).find('[name="cost[]"]').val();
                  const gst = $(this).find('[name="gst[]"]').val();
                  const weight_value = $(this).find('[name="weight_value[]"]').val();
                  const weight_unit = $(this).find('[name="weight_unit[]"]').val();
                  if (!count || !gst || !cost) {
                      isValid = false;
                  } else {
                      buyItems.push({ index_id: id, count, cost, gst, weight_value, weight_unit });
                  }
              });
    
    
                if (buyItems.length === 0) {
                    $('#buy_items_error').text('Please add at least one Buy item.').show();
                    isValid = false;
                }
                // if (!deliveryCharges) {
                //     $('#delivery_error').text('Please enter a valid Delivery Charges amount.').show();
                //     isValid = false;
                // } else {
                //     $('#delivery_error').hide(); // ✅ hide if it's valid
                // }
            }
    
            let variantDatas = [];
    
            $('.variant-check').each(function () {
                const $variantCheckbox = $(this);
                const variantId = this.id.split('_')[2];
                if ($variantCheckbox.is(':checked')) {
                    let variantItem = {
                        variant_id: variantId,
                        variables: []
                    };
            
                    $(`.variant_body_${variantId} .variant-checkbox:enabled:checked`).each(function () {
                        const $variableCheckbox = $(this);
                        const variableId = $variableCheckbox.data('id');
                        const variableInputId = $variableCheckbox.attr('id') + '_tbox';
                        const cost = $('#' + variableInputId).val();
            
                        if (!cost) {
                            $('#' + variableInputId).addClass('is-invalid');
                            isValid = false;
                        } else {
                            variantItem.variables.push({
                                variable_id: variableId,
                                cost: cost
                            });
                        }
                    });
            
                    if (variantItem.variables.length > 0) {
                        variantDatas.push(variantItem);
                    }
                }
            });
           
            if (!isValid) {
                $btn.prop('disabled', false);
                $spinner.addClass('d-none');
                return;
            }
    
              // Construct form data for file upload + JSON fields
              let formData = new FormData();
              formData.append('category_id', categoryId);
              formData.append('sub_category_id', JSON.stringify(subCategoryIds));
              formData.append('marketing_kit_name', kitName);
              formData.append('file_type', fileType);
              formData.append('preview_check', previewCheck);
              formData.append('download_check', downloadCheck);
              formData.append('buy_check', buyCheck);
              formData.append('buy_items', JSON.stringify(buyItems));
              formData.append('variant_datas', JSON.stringify(variantDatas));
              formData.append('description', description);
              formData.append('source_type', sourceType);
                if (sourceType === 'upload') {
                    formData.append('marketing_attachments', attachment);
                } else if (sourceType === 'url') {
                    formData.append('marketing_url', url);
                }
              formData.append('marketing_thumbnail', thumbnail);
    
              // AJAX Submit
              $.ajax({
                  url: '/marketing-kit/add', // Update with actual route
                  type: 'POST',
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  },
                  data: formData,
                  processData: false,
                  contentType: false,
                  success: function (response) {
                  
                    // loadMarketingKitList(filters={});
                    toastr.success('Marketing Kit created successfully!');
                    location.reload();
                      // Optional: reload, close modal, etc.
    
                  },
                  error: function (err) {
                      console.error(err);
                      // alert('Something went wrong.');
                      toastr.error('Something went wrong.');
                  },
                   complete: function () {
                      // Always re-enable and hide spinner
                      $btn.prop('disabled', false);
                      $spinner.addClass('d-none');
                  }
              });
          });
          
          
    //edit market
    $('#marketing_kit_edit').on('click', function () {
         console.log('Clicked Update Button');
        // const $btn = $(this);
        // const $spinner = $('#kit_edit_spinner');
        // const $btnText = $btn.find('.btn-text');

        // // Prevent multiple clicks
        // if ($btn.prop('disabled')) return;

        // // Disable and show loader
        // $btn.prop('disabled', true);
        // $spinner.removeClass('d-none');

        let isValid = true;

        // Required fields
        $('#marketingKitFormedit').find('select[required], input[required]').each(function () {
            if (!$(this).val()) {
                $(this).addClass('is-invalid');
                isValid = false;
            } else {
                $(this).removeClass('is-invalid');
            }
        });

        // Get base fields
        const sno = $('#hidden_kit_sno').val();
        const categoryId = $('#category_id_edit').val();
        const subCategoryIds = $('#subcategory_id_edit').val(); // it's multiple
        const kitName = $('#marketingKitFormedit input[placeholder="Enter Marketing Kit Name"]').val();  
        const fileType = $('#file_type_edit').val();
        const previewCheck = $('#preview_check_edit').is(':checked') ? 1 : 0;
        const downloadCheck = $('#download_check_edit').is(':checked') ? 1 : 0;
        const buyCheck = $('#buy_chk_edit').is(':checked') ? 1 : 0;
         const description = $('#marketingKitFormedit textarea').val();
         const sourceType = $('input[name="source_type_edit"]:checked').val();
            const attachment = $('#attachmentUploadedit')[0].files[0]; // for upload
            const url = $('#attachmentUrledit').val();  
            const thumbnail = $('#thumbnailUploadedit')[0].files[0];
            // Clear all previous error messages
              $('.validation-msg').hide().text('');
    
              // Attachment validation
                if (sourceType === 'upload') {
                    if (!attachment) {
                        $('#attachment_error').text('Please upload an attachment.').show();
                        isValid = false;
                    }
                } else if (sourceType === 'url') {
                    if (!url) {
                        $('#attachment_error').text('Please enter a valid URL.').show();
                        isValid = false;
                    }
                }
    

          // Attachment validation
          if (!attachment) {
              $('#attachment_error').text('Please upload an attachment.').show();
              isValid = false;
          }

          // Category ID
          if (!categoryId) {
              $('#category_id_error').text('Please select a category.').show();
              isValid = false;
          }
           // sub Category ID
            if (!subCategoryIds || subCategoryIds.length === 0) {
                $('#sub_category_id_error').text('Please select at least one subcategory.').show();
                isValid = false;
            }

          // Kit Name
          if (!kitName) {
              $('#kit_name_error').text('Please enter a kit name.').show();
              isValid = false;
          }

          // File Type
          if (!fileType) {
              $('#file_type_error').text('Please select a file type.').show();
              isValid = false;
          }


        // Buy Items - Collect if Buy is checked
        let buyItems = [];
        if (buyCheck) {
          $('.form-blocks-container-edit .row').each(function () {
              const idAttr = $(this).attr('id');
              const id = idAttr ? idAttr.split('_')[1] : null;
              const count = $(this).find('[name="count[]"]').val();
              const cost = $(this).find('[name="cost[]"]').val();
              const gst = $(this).find('[name="gst[]"]').val();
              const weight_value = $(this).find('[name="weight_value[]"]').val();
              const weight_unit = $(this).find('[name="weight_unit[]"]').val();
                  if (!count || !gst || !cost) {
                      isValid = false;
                  } else {
                      buyItems.push({ index_id: id, count, cost, gst, weight_value, weight_unit });
                  }
          });


            if (buyItems.length === 0) {
                $('#buy_items_error').text('Please add at least one Buy item.').show();
                isValid = false;
            }
        }

        // Color Variants
      
        // if (!isValid) {
        //     $btn.prop('disabled', false);
        //     $spinner.addClass('d-none');
        //     return;
        // }

          // Construct form data for file upload + JSON fields
          let formData = new FormData();
          formData.append('sno', sno);
          formData.append('category_id', categoryId);
          formData.append('sub_category_id', JSON.stringify(subCategoryIds));
          formData.append('marketing_kit_name', kitName);
          formData.append('file_type', fileType);
          formData.append('preview_check', previewCheck);
          formData.append('download_check', downloadCheck);
          formData.append('buy_check', buyCheck);
              formData.append('buy_items', JSON.stringify(buyItems));
              formData.append('description', description);
              formData.append('source_type', sourceType);
                if (sourceType === 'upload') {
                    formData.append('marketing_attachments', attachment);
                } else if (sourceType === 'url') {
                    formData.append('marketing_url', url);
                }
          formData.append('marketing_thumbnail', thumbnail);

          // AJAX Submit
          $.ajax({
              url: '/marketing-kit/update', // Update with actual route
              type: 'POST',
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              },
              data: formData,
              processData: false,
              contentType: false,
              success: function (response) {
                 // Hide the modal first
              $('#kt_modal_update_marketing_kit').modal('hide');

              
                // loadMarketingKitList(filters={});
                toastr.success('Marketing Kit updated successfully!');
                location.reload();
                  // Optional: reload, close modal, etc.

              },
              error: function (err) {
                  console.error(err);
                  // alert('Something went wrong.');
                  toastr.error('Something went wrong.');
              },
               complete: function () {
                  // Always re-enable and hide spinner
                //   $btn.prop('disabled', false);
                //   $spinner.addClass('d-none');
              }
          });
      });
    });
    //  list marketing
    loadMarketingKitList(filters={});
    function loadMarketingKitList(filters = {}) {
      $.ajax({
          url: '/marketing-kit/list',
          method: 'post',
          data: filters,
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
          success: function(data) {
              let container = $('#marketingKitContainer'); // your div
              container.empty();
              // optional: update filter count
             let variantCount = 0;
            if (filters.variants && typeof filters.variants === 'object') {
                for (const variantId in filters.variants) {
                    if (Array.isArray(filters.variants[variantId])) {
                        variantCount += filters.variants[variantId].length;
                    }
                }
            }
            
            let count = (filters.subcategories?.length || 0) +
                        (filters.sort ? 1 : 0) +
                        variantCount;
              if (count === 0) {
                  $('#filter_count').hide();
              } else {
                  $('#filter_count').text(`${count.toString().padStart(2, '0')} filtered`).show();
              }
            $('#kit-count').text(data.kit_count);
              data.kits.forEach(kit => {
              let actionButtons = '';
              let actionButtonsCart = '';

              if (kit.preview_check == 1) {
                  actionButtons += `
                      <a href="javascript:;"
                        class="badge rounded text-white w-75px px-2 py-1 btn-preview-kit"
                        style="background-color: #0A7810;"
                        data-preview="/marketing_kits_thumbnail/${kit.marketing_thumbnail}"
                        data-bs-toggle="modal"
                        data-bs-target="#kt_modal_preview_marketing_kit">
                          <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Preview Marketing Kit">
                              <span class="me-1"><i class="mdi mdi-folder-eye-outline fs-3"></i></span><br>
                              <span>Preview</span>
                          </div>
                      </a>`;
              }

               if (kit.download_check == 1) {
                    if (kit.source_type === 'upload') {
                        actionButtons += `
                        <a href="/marketing_kits/${kit.marketing_attachments}" download class="badge rounded text-white w-75px px-2 py-1" style="background-color: #D78117;">
                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download Marketing Kit">
                                <span class="me-1"><i class="mdi mdi-download-box-outline fs-3"></i></span><br>
                                <span>Download</span>
                            </div>
                        </a>`;
                    } else if (kit.source_type === 'url') {
                        actionButtons += `
                        <a href="${kit.marketing_url}" target="_blank" class="badge rounded text-white w-75px px-2 py-1" style="background-color: #D78117;">
                            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Open Marketing Kit URL">
                                <span class="me-1"><i class="mdi mdi-link-box-outline fs-3"></i></span><br>
                                <span>Open Link</span>
                            </div>
                        </a>`;
                    }
                }

              if (kit.buy_check == 1) {
                  actionButtons += `
                      <a href="javascript:;" class="badge rounded text-white w-75px px-2 py-1" style="background-color: #7A55C8;">
                          <div data-id="${kit.sno}" data-name="${kit.marketing_kit_name}" data-bs-toggle="offcanvas" data-bs-target="#kt_modal_buy_marketing_kit" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Buy Marketing Kit">
                              <span class="me-1">
                                  <i class="mdi mdi-lightning-bolt fs-3"></i>
                              </span><br>
                              <span>Buy</span>
                          </div>
                      </a>`;
              }
              
              if (kit.buy_check == 1) {
                    actionButtonsCart += `
                        <a href="javascript:;" class="w-100px border rounded-pill fw-semibold fs-7 text-black px-2 py-2" style="border: 1px solid #0A7810 !important;" data-id="${kit.sno}" data-name="${kit.marketing_kit_name}" data-bs-toggle="modal" data-bs-target="#kt_modal_add_to_cart">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add To Cart">
                              <i class="mdi mdi-cart-outline fs-3"></i>
                            </span>
                        </a>`;
              }

              container.append(`
                  <div class="col-lg-4 cont_indv_tbox mb-4">
                      <div class="card h-100 emboss-effect shadow_lg">
                          <div class="card-body px-1 pt-0 pb-0">
                              <div class="d-flex justify-content-between align-items-start mb-3 gap-1">
                                  <div class="d-flex justify-content-center align-items-start w_99 mb-0">
                                      <img src="/marketing_kits_thumbnail/${kit.marketing_thumbnail}" class="w-175px h-175px rounded border border-gray-600 border-solid" />
                                  </div>
                                  <div class="mb-0">
                                      <a class="btn btn-icon btn-sm me-n3" data-bs-toggle="dropdown">
                                          <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                      </a>
                                      <div class="dropdown-menu dropdown-menu-end">
                                          <a class="dropdown-item text-black" data-bs-toggle="modal" data-id="${kit.sno}" data-name="${kit.marketing_kit_name}" data-bs-target="#kt_modal_view_marketing_kit"><i class="mdi mdi-eye-outline fs-4"></i> View</a>
                                          
                                          <a href="javascript:;" class="dropdown-item text-black delete-kit-btn" data-id="${kit.sno}" data-name="${kit.marketing_kit_name}"  data-bs-toggle="modal"  data-bs-target="#kt_modal_delete_marketing_kit"><i class="mdi mdi-delete-outline fs-4"></i> Delete</a>
                                      </div>
                                  </div>
                              </div>
                               <div class="d-flex justify-content-between align-items-start flex-wrap mb-3 gap-2 px-2">
                                  <div class="d-flex flex-column gap-1 flex-grow-1">
                                    <div class="text-dark fs-5 fw-bold mk_name" 
                                         data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                         title="${kit.marketing_kit_name}">
                                      ${kit.marketing_kit_name}
                                    </div>
                                
                                    <div>
                                      <span class=" text-dark fs-6 fw-semibold px-2 rounded-pill" 
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Category">
                                        ${kit.category_name} 
                                        <i class="mdi mdi-help-rhombus text-dark ms-1"
                                           data-bs-toggle="tooltip"
                                           data-bs-placement="right"
                                           title="${kit.description}">
                                        </i>
                                      </span>
                                    </div>
                                
                                    <div class="d-flex flex-wrap fw-semibold gap-1">
                                      ${kit.subcategory_names.map(name => `
                                        <span class=" px-2 text-dark fs-6 rounded-pill" 
                                              data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                              title="Subcategory">
                                          ${name}
                                        </span>
                                      `).join('')}
                                    </div>
                                  </div>
                                
                                  <div class="text-end">
                                    ${actionButtonsCart}
                                  </div>
                                </div>

                              <div class="d-flex justify-content-between align-items-center position-sticky top-100 flex-wrap gap-1 mb-2">
                                  ${actionButtons}
                              </div>
                          </div>
                      </div>
                  </div>
              `);
          });


            //   // 🔁 Re-initialize tooltips after appending
            //   const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
            //   tooltipTriggerList.forEach(el => {
            //       new bootstrap.Tooltip(el);
            //   });
          }
      });
    }
    // addd check condtion variable and varient 
    document.querySelectorAll('.variant_toggle_icon').forEach(function(icon) {
        icon.addEventListener('click', function() {
            const target = document.querySelector(this.dataset.target);
            if (target.classList.contains('show')) {
                target.classList.remove('show');
            } else {
                target.classList.add('show');
            }
        });
    });


    document.addEventListener("DOMContentLoaded", function () {
    // 1. Handle Variant Checkbox (parent)
    document.querySelectorAll('.variant-check').forEach(function (variantCheckbox) {
        variantCheckbox.addEventListener('change', function () {
            const variantId = this.id.split('_').pop();

            // Enable/Disable all variable checkboxes under this variant
            document.querySelectorAll(`[id^=variant_${variantId}_]`).forEach(function (el) {
                if (el.classList.contains('variant-checkbox')) {
                    el.disabled = !variantCheckbox.checked;

                    // Also disable the input field if parent is unchecked
                    const inputId = el.id + '_tbox';
                    const inputBox = document.getElementById(inputId);
                    if (inputBox) {
                        inputBox.disabled = true;
                    }

                    // Uncheck variable checkbox if main is unchecked
                    if (!variantCheckbox.checked) {
                        el.checked = false;
                    }
                }
            });
        });
    });

    // 2. Handle Individual Variable Checkbox
    document.querySelectorAll('.variant-checkbox').forEach(function (variableCheckbox) {
        variableCheckbox.addEventListener('change', function () {
            const inputId = this.id + '_tbox';
            const inputBox = document.getElementById(inputId);
            if (inputBox) {
                inputBox.disabled = !this.checked;
                if (!this.checked) {
                    inputBox.value = ''; // Optional: clear input on uncheck
                }
            }
        });
    });
});



   function getFilterValues() {
    const subcategories = [];
    const variants = {};

    // ✅ Subcategories
    $('[data-filter="subcategory"]:checked').each(function () {
        subcategories.push($(this).val());
    });

    // dynamic variant & variable selection
    $('[data-filter="variant"]:checked').each(function () {
        const variantId = $(this).data('variant-id'); // get variant_id
        const variableId = $(this).val();              // get variable_id

        if (!variants[variantId]) {
            variants[variantId] = [];
        }

        variants[variantId].push(variableId);
    });

    // sort logic remains unchanged
    const sort = $('input[name="price_chk"]:checked').next('label').text().trim();

    return {
        subcategories,
        variants,
        sort
    };
}

  //  preview image model trigger
  $(document).on('click', '.btn-preview-kit', function () {
      const imageUrl = $(this).data('preview');
      $('#marketing_preview_image').attr('src', imageUrl);
  });
  function applyFilters() {
      const filters = getFilterValues();
      loadMarketingKitList(filters);
  }
    $(document).on('change', '[data-filter]', function () {
        applyFilters();
    });

    $('input[name="price_chk"]').on('change', function () {
        applyFilters();
    });

    $('#clear_rlts').on('click', function () {
        $('[data-filter]').prop('checked', false);
        $('input[name="price_chk"]').prop('checked', false).first().prop('checked', true); // Reset sort
        applyFilters();
    });


    let deleteKitId = null;

    // When delete button clicked
    $(document).on('click', '.delete-kit-btn', function () {
        deleteKitId = $(this).data('id');
        const kitName = $(this).data('name');
        $('#kt_modal_delete_marketing_kit label').text(kitName); // Fill modal name
    });

    // On Confirm Delete button
    $('#confirmDeleteBtn').on('click', function () {
        if (deleteKitId) {
            $.ajax({
                url: '/marketing-kit/delete',
                method: 'POST',
                data: {
                    id: deleteKitId,
                    _token: $('meta[name="csrf-token"]').attr('content'),
                },
                success: function (res) {
                    if (res.status === 'success') {
                        $('#kt_modal_delete_marketing_kit').modal('hide');
                        toastr.success('Marketing Kit Deleted successfully!');
                        // Refresh list
                        loadMarketingKitList(filters={}); // Assuming you wrap the $.ajax list call in this function
                    }else{
                         toastr.error('Something went wrong.');
                    }
                }
            });
        }
    });

</script>
<script>
  $(document).ready(function () {
    // filter
    $.ajax({
        url: '/marketing-kit/filter-list',
        method: 'GET',
        success: function (data) {
            renderCategories(data.categories, data.subcategories);
            renderVariants(data.variants, data.variables); 
        }
    });
    
    
     // filter

  function renderCategories(categories, subcategories) {
    categories.forEach(cat => {
        const collapseId = `collapse-category-${cat.sno}`;

        const catDiv = $(`
            <div class="col-lg-12 mb-1">
                <div class="card-action">
                    <div class="card-header align-items-center bg-transparent px-2 py-2">
                        <div class="d-flex justify-content-between align-items-center w-100">
                            <div class="card-action-title text-dark fs-6 fw-semibold cursor-pointer" data-bs-toggle="collapse" data-bs-target="#${collapseId}">
                                ${cat.category_name}
                            </div>
                            <div>
                                <a href="javascript:;" class="text-black" data-bs-toggle="collapse" data-bs-target="#${collapseId}">
                                    <i class="mdi mdi-chevron-up fs-3"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="${collapseId}" class="collapse show">
                    <div class="card-body px-2 ps-3 pt-1 pb-2">
                        <div class="row" id="subcat-${cat.sno}"></div>
                    </div>
                </div>
                <div class="border-dashed border-1 border-bottom border-gray-700"></div>
            </div>
        `);

        $('#filtersContainer').append(catDiv);

        subcategories
            .filter(sub => Number(sub.marketing_category_id) === cat.sno)
            .forEach(sub => {
                 const countBadge = sub.kit_count > 0 
                  ? `<span class="badge bg-info text-white rounded-pill ms-1">${sub.kit_count}</span>` 
                  : '';
                $(`#subcat-${cat.sno}`).append(`
                    <div class="col-lg-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" data-filter="subcategory" value="${sub.sno}" />
                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">${sub.marketing_subcategory_name} ${countBadge}</label>
                        </div>
                    </div>
                `);
            });
    });
  }


  function renderVariants(variants, variables) {
    variants.forEach(variant => {
        const collapseId = `collapse-variant-${variant.sno}`;
        const filteredVariables = variables.filter(v => Number(v.variant_id) === variant.sno);

        if (filteredVariables.length === 0) return;

        const variantDiv = $(`
            <div class="col-lg-12 mb-1">
                <div class="card-action">
                    <div class="card-header align-items-center bg-transparent px-2 py-2">
                        <div class="d-flex justify-content-between align-items-center w-100">
                            <div class="card-action-title text-dark fs-6 fw-semibold cursor-pointer"
                                data-bs-toggle="collapse" data-bs-target="#${collapseId}">
                                ${variant.variant_name}
                            </div>
                            <div>
                                <a href="javascript:;" class="text-black" data-bs-toggle="collapse" data-bs-target="#${collapseId}">
                                    <i class="mdi mdi-chevron-up fs-3"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div id="${collapseId}" class="collapse show">
                        <div class="card-body px-2 ps-3 pt-1 pb-2">
                            <div class="row" id="variant-${variant.sno}"></div>
                        </div>
                    </div>
                </div>
                <div class="border-dashed border-1 border-bottom border-gray-700"></div>
            </div>
        `);

        $('#filtersContainer').append(variantDiv);

        filteredVariables.forEach(variable => {
            $(`#variant-${variant.sno}`).append(`
                <div class="col-lg-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" data-filter="variant" data-variant-id="${variant.sno}" value="${variable.sno}" />
                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">${variable.variables_name}</label>
                    </div>
                </div>
            `);
        });
    });
}
  
//   $(document).on('change', '.category-select-edit', function () {
//         let categoryId = $(this).val();
//         let subcategorySelect = $('#subcategory_id_edit');
    
//         subcategorySelect.html('<option value="">Loading...</option>').prop('disabled', true);
    
//         if (categoryId) {
//             $.get(`/subcategories/${categoryId}`, function (subcatData) {
//                 let options = '<option value="">Select Subcategory</option>';
//                 $.each(subcatData, function (i, val) {
//                     options += `<option value="${val.sno}">${val.marketing_subcategory_name}</option>`;
//                 });
    
//                 subcategorySelect.html(options).prop('disabled', false);
    
//                 // Apply previously selected subcategories if any
//                 let selectedSubCats = subcategorySelect.data('selected');
//                 if (selectedSubCats) {
//                     try {
//                         selectedSubCats = JSON.parse(selectedSubCats);
//                         subcategorySelect.val(selectedSubCats).trigger('change');
//                     } catch (e) {
//                         console.error('Invalid subcategory format', selectedSubCats);
//                     }
//                     subcategorySelect.removeAttr('data-selected');
//                 }
//             });
//         }
//     });

  function loadSubcategories(categoryId, selectedSubCats = [], onComplete = () => {}) {
    const subcategorySelect = $('#subcategory_id_edit');
    subcategorySelect.html('<option value="">Loading...</option>').prop('disabled', true);

    if (!categoryId) {
        subcategorySelect.html('<option value="">Select Subcategory</option>').prop('disabled', false);
        return;
    }

    $.get(`/subcategories/${categoryId}`, function (subcatData) {
        let options = '<option value="">Select Subcategory</option>';
        $.each(subcatData, function (i, val) {
            options += `<option value="${val.sno}">${val.marketing_subcategory_name}</option>`;
        });

        subcategorySelect.html(options).prop('disabled', false);

        if (selectedSubCats && selectedSubCats.length > 0) {
            subcategorySelect.val(selectedSubCats).trigger('change');
        }

        // Call the completion callback
        if (typeof onComplete === 'function') onComplete();
    });
}
    // view model details
    $(document).on('click', '[data-bs-target="#kt_modal_view_marketing_kit"]', function () {
        const id = $(this).data('id');

        $.ajax({
            url: `/marketing-kit/view/${id}`,
            method: 'GET',
            success: function (data) {
                console.log(data); // For debug

                // Set modal title
                $('#kt_modal_view_marketing_kit h3').text(data.marketing_kit_name);

                // Set image
                $('#marketing_kit_atmt').attr('src', `/marketing_kits_thumbnail/${data.marketing_thumbnail}`);

                // Category/Subcategory
                // Assuming backend sends category_name and sub_category_name
                $('.view-category').text(data.category_name ?? '—');
                const subCategoryNames = (data.sub_categories || []).map(sc => sc.marketing_subcategory_name).join(', ');
                $('.view-sub-category').text(subCategoryNames || '—');

                // File type
                $('.view-file-type').text(data.file_type);

                // Description
                $('.view-description').text(data.description);
                $('.view-color-count').text(data.color_details.length);
                $('.view-size-count').text(data.size_details.length);

               const tableHidden = document.getElementById('tableHidden');
                if (data.buy_check == 1) {
                    tableHidden.classList.remove('hidden');
                } else {
                    tableHidden.classList.add('hidden');
                }
                const $checkSection = $('#kt_modal_view_marketing_kit .check-section'); // Add this class to your container div
                $checkSection.empty();

                // Define your checks and labels
                const checks = [
                    { key: 'preview_check', label: 'Preview' },
                    { key: 'download_check', label: 'Download' },
                    { key: 'buy_check', label: 'Buy' }
                ];

                // Loop through and render only if check is 1
                checks.forEach(item => {
                    if (data[item.key] == 1) {
                        $checkSection.append(`
                            <div class="d-block mb-3">
                                <label class="text-dark fs-6 fw-semibold">
                                    <i class="mdi mdi-check-decagram text-info fs-2"></i>
                                </label>
                                <label class="text-dark fs-4 fw-semibold">${item.label}</label>
                            </div>
                        `);
                    }
                });

                const $variantWrapper = $('#kt_modal_view_marketing_kit .variant-groups-wrapper');
                $variantWrapper.empty();
                
                const variantDetails = data.variant_details || [];
                
                variantDetails.forEach(group => {
                    const variables = group.variables || [];
                    const badgeCount = variables.length.toString().padStart(2, '0');
                
                    const variablesHtml = variables.map(v =>
                        `<div class="d-flex justify-content-between mb-1">
                            <div class="text-black fs-7">${v.variable_name}</div>
                            <div class="text-black fs-7">&#8377; ${v.cost}</div>
                        </div>`
                    ).join('');
                
                    $variantWrapper.append(`
                        <div class="mb-3 p-2 border rounded">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <div class="fw-semibold text-primary">${group.variant_name}</div>
                                <span class="badge bg-warning text-black fw-semibold rounded-pill fs-8">${badgeCount}</span>
                            </div>
                            ${variablesHtml}
                        </div>
                    `);
                });

              // Update count badge
             $('.variant-count-badge').text(variantDetails.length.toString().padStart(2, '0'));
                               
                const buyItems = data.buy_items || [];

                let rowsHtml = '';

                buyItems.forEach(item => {
                    const count = parseInt(item.count || 0);
                     const cost = parseInt(item.cost || 0);
                    const gstPercent = parseFloat(item.gst || 0);
                    const weight_value = parseInt(item.weight_value || 0);
                    const weight_unit = item.weight_unit;
                    const deliveryCharges = parseFloat(item.delivery_charges || 0);

                    // Let's assume per unit cost is fixed or coming from backend
                   

                    const baseCost = count * cost;
                    const gstAmount = (baseCost * gstPercent) / 100;
                    const totalCost = baseCost + gstAmount + deliveryCharges;

                    rowsHtml += `
                        <tr>
                            <td><label class="fw-semibold fs-6 text-black">${count}</label></td>
                            <td align="right"><label class="fw-semibold fs-6 text-black">&#8377; ${cost.toLocaleString()}</label></td>
                            <td align="center"><label class="fw-semibold fs-6 text-black">${gstPercent}%</label></td>
                            <td align="center"><label class="fw-semibold fs-6 text-black">${weight_value}</label></td>
                            <td align="center"><label class="fw-semibold fs-6 text-black">${weight_unit}</label></td>
                        </tr>
                    `;
                });

                $('.list_page_1 tbody').html(rowsHtml);


                // Show modal (if not auto via Bootstrap)
                // $('#kt_modal_view_marketing_kit').modal('show');
            }
        });
    });
    // edit model details fetch
    $(document).on('click', '[data-bs-target="#kt_modal_update_marketing_kit"]', function () {
        const id = $(this).data('id');
    
        $.ajax({
            url: `/marketing-kit/edit/${id}`,
            method: 'GET',
            success: function (data) {
                console.log(data); // Debug
             $('#hidden_kit_sno').val(data.sno);
                // Basic fields
               $('#category_id_edit').val(data.category_id).trigger('change.select2');
                 const selectedSubCats = JSON.parse(data.sub_category_id);
                    loadSubcategories(data.category_id, selectedSubCats, function () {
                        console.log('Subcategories loaded and selected');
                    });
                
            
                $('#marketingKitFormedit input[placeholder="Enter Marketing Kit Name"]').val(data.marketing_kit_name);
                $('#description_edit').val(data.description);
                $('#file_type_edit').val(data.file_type).trigger('change');
                $('#delivery_charges_edit').val(data.delivery_charges || 0);
            
                // Checkboxes
                $('#preview_check_edit').prop('checked', data.preview_check == 1);
                $('#download_check_edit').prop('checked', data.download_check == 1);
                $('#buy_chk_edit').prop('checked', data.buy_check == 1);
            
                // Show buy block if checked
                if (data.buy_check == 1) {
                    $('#add_more_btn_wrapper_edit').show();
                    $('#delivery_input_wrapper_edit').show();
                    $('.form-blocks-container-edit').empty(); // clear existing
            
                    data.buy_items.forEach((item, index) => {
                        $('#add_more_variant_buy_edit').click(); // trigger Add More
                        setTimeout(() => {
                            let block = $('.form-blocks-container-edit .form-row-block-edit').eq(index);
                            block.find('[name="count[]"]').val(item.count);
                            block.find('[name="cost[]"]').val(item.cost);
                            block.find('[name="gst[]"]').val(item.gst);
                            block.find('[name="weight_value[]"]').val(item.weight_value);
                            block.find('[name="weight_unit[]"]').val(item.weight_unit);
                        }, 100); // slight delay to ensure DOM is ready
                    });
                } else {
                    $('#add_more_btn_wrapper_edit').hide();
                    $('#delivery_input_wrapper_edit').hide();
                    $('.form-blocks-container-edit').html('');
                }
            
                // Handle Source Type (Upload or URL)
                let attachmentPath = '/marketing_kits/' + data.marketing_attachments;
                let thumbnailPath = '/marketing_kits_thumbnail/' + data.marketing_thumbnail;
                
                // For attachments
                if (data.source_type === 'upload') {
                    $('#source_upload_edit').prop('checked', true).trigger('change');
                    $('#uploadSectionedit').removeClass('d-none');
                    $('#urlSectionedit').addClass('d-none');
                    
                    $('#attachmentPreviewedit').attr('src', attachmentPath);
                    $('#fileNameDisplayedit').text(data.marketing_attachments);
                } else {
                    $('#source_url_edit').prop('checked', true).trigger('change');
                    $('#uploadSectionedit').addClass('d-none');
                    $('#urlSectionedit').removeClass('d-none');
                    $('#attachmentUrledit').val(data.marketing_url);
                }
          
                // Thumbnail
                if (data.marketing_thumbnail) {
                    $('#thumbnailPreviewedit').attr('src', thumbnailPath);
                    $('#fileNameDisplaythumbedit').text(data.marketing_thumbnail);
                }
                            
                
                $('#kt_modal_update_marketing_kit').modal('show');
            }

        });
    });

    // view model cart details
    $(document).on('click', '[data-bs-target="#kt_modal_add_to_cart"]', function () {
        const id = $(this).data('id');
    
        $.ajax({
            url: `/marketing-kit/cart-view/${id}`,
            method: 'GET',
            success: function (data) {
                console.log(data); // For debug
    
                // Set modal values
                $('#martketing_name_cart_view').text(data.marketing_kit_name);
                $('#martketing_kit_id').val(data.sno);
                $('#marketing_kit_cart_view').attr('src', `/marketing_kits_thumbnail/${data.marketing_thumbnail}`);
    
                const buyItems = data.buy_items || [];
                let rowsHtml = '';
    
                buyItems.forEach((item, index) => {
                    const count = parseInt(item.count || 0);
                    const buy_item_id = parseInt(item.index_id || 0);
                    const gstPercent = parseFloat(item.gst || 0);
                    const deliveryCharges = parseFloat(item.delivery_charges || 0);
    
                    // Totals (you can use these if needed later)
                    const baseCost = count * deliveryCharges;
                    const gstAmount = (baseCost * gstPercent) / 100;
                    const totalCost = baseCost + gstAmount + deliveryCharges;
    
                    // Generate variant blocks
                    const variantHtml = (data.variant_details || []).map((variant, variantIndex) => {
                    const variableHtml = (variant.variables || []).map((variable, varIndex) => `
                        <div class="d-flex align-items-center justify-content-between vart_menu_var_cart px-2 pt-1 mb-3 cursor-pointer ${varIndex === 0 ? 'active bg-light-success' : ''}"
                            data-variable-id="${variable.variable_id}">
                            <div class="text-black fs-6 fw-semibold mb-1">${variable.variable_name}</div>
                            <div class="text-black fs-6 fw-semibold mb-1">&#8377; ${variable.cost}</div>
                        </div>
                    `).join('');
                
                    return `
                        <div class="col-lg-12 mb-3" data-variant-id="${variant.variant_id}">
                            <div class="d-flex align-items-center justify-content-between border-bottom px-3 mb-3">
                                <div class="text-black fs-6 fw-semibold mb-1">
                                    ${variant.variant_name}
                                    <span class="badge bg-warning text-black fw-semibold rounded-pill fs-8" title="Total Options">
                                        ${variant.variables?.length || 0}
                                    </span>
                                </div>
                                <div class="text-black fs-6 fw-semibold mb-1">Amount<br><span class="fs-8">(Per Unit)</span></div>
                            </div>
                            <div class="scroll-y max-h-150px px-2">
                                ${variableHtml}
                            </div>
                        </div>
                    `;
                }).join('');
    
                    const isActive = index === 0 ? 'show' : '';
                    const isAccordionItemActive = index === 0 ? 'active' : '';
                    const checkedAttr = index === 0 ? 'checked' : '';
                    const accordionId = `accordionExample${index}`;
                    const headingId = `heading${index}`;
                    const collapseId = `collapse${index}`;
    
                    // Accordion Item
                    rowsHtml += `
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion" id="${accordionId}">
                                    <div class="accordion-item mb-3 ${isAccordionItemActive}" data-buy-item-id="${buy_item_id}">
                                        <h2 class="accordion-header" id="${headingId}">
                                            <button type="button" class="accordion-button pb-2" data-bs-toggle="collapse"
                                                data-bs-target="#${collapseId}" aria-expanded="${index === 0}" aria-controls="${collapseId}">
                                                <div class="form-check">
                                                    <input class="form-check-input me-0" type="radio" value="${buy_item_id}" name="var_pre_chk_cart" ${checkedAttr} />
                                                    <label class="form-check-label text-black mb-1 fs-5 fw-semibold">${count} Pcs</label>
                                                </div>
                                            </button>
                                        </h2>
                                        <div id="${collapseId}" class="accordion-collapse collapse ${isActive}" data-bs-parent="#${accordionId}">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    ${variantHtml}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                });
    
                // Inject HTML
                $('#accordion-cart-view').html(rowsHtml);
            }
        });
    });

  
    $(document).on('click', '.vart_menu_var_cart', function () {
          console.log("clicked");
        const parent = $(this).closest('[data-variant-id]');
        parent.find('.vart_menu_var_cart').removeClass('active bg-light-success');
        $(this).addClass('active bg-light-success');
    });
    
   $(document).on('change', 'input[name="var_pre_chk_cart"]', function () {
        // Remove active state globally
        $('.vart_menu_var_cart').removeClass('active bg-light-success');
    
        const selectedAccordionItem = $(this).closest('.accordion-item');
    
        // Only activate the first variable inside each variant group of the selected accordion
        selectedAccordionItem.find('[data-variant-id]').each(function () {
            $(this).find('.vart_menu_var_cart').first().addClass('active bg-light-success');
        });
    });
    
    $(document).on('click', '.vart_menu_var_paymnet', function () {
          console.log("clicked");
        const parent = $(this).closest('[data-variant-id]');
        parent.find('.var_pre_chk_payment').removeClass('active bg-light-success');
        $(this).addClass('active bg-light-success');
    });
    
   $(document).on('change', 'input[name="var_pre_chk_payment"]', function () {
        // Remove active state globally
        $('.var_pre_chk_payment').removeClass('active bg-light-success');
    
        const selectedAccordionItem = $(this).closest('.accordion-item');
    
        // Only activate the first variable inside each variant group of the selected accordion
        selectedAccordionItem.find('[data-variant-id]').each(function () {
            $(this).find('.var_pre_chk_payment').first().addClass('active bg-light-success');
        });
    });


    // view payment off canva details
    $(document).on('click', '[data-bs-target="#kt_modal_buy_marketing_kit"]', function () {
      const marketing_kit_id = $(this).data('id');

        $.ajax({
            url: `/marketing-kit/payment-get`,
            method: 'GET',
            data: {
                marketing_kit_id: marketing_kit_id,
                add_to_cart_id: ''
            },
            success: function (data) {
              console.log(data); // Debug

                const thumbnail = data.marketing_thumbnail;
                const defaultImg = "{{ asset('marketing_kit/poster.jpg') }}";
            
                const imagePath = thumbnail 
                    ? `/marketing_kits_thumbnail/${thumbnail}` 
                    : defaultImg;
            
                const html = `
                        <div class="d-flex align-items-center justify-content-center bg-gray-300 pt-4 pb-4 mb-2">
                            <img 
                                src="${imagePath}" 
                                alt="user-avatar" 
                                class="rounded border border-gray-600 border-solid payment-image"
                                style="width: 342px; height: 199px; object-fit: cover;"
                                onerror="this.onerror=null;this.src='${defaultImg}';"
                            />
                        </div>
                    `;
            
                $('#marketing_kit_payment_wrapper').html(html);
              $('.marketing_pay_name').text(data.marketing_kit_name);
              $('.marketing_descripion').text(data.description || '');

              const buyItems = data.buy_items || [];
              const colorDetails = data.color_details || [];
              const sizeDetails = data.size_details || [];
              const marketing_kit_id = data.sno;
              let accordionHTML = '';

                 buyItems.forEach((item, index) => {
                    const count = parseInt(item.count || 0);
                    const cost = parseInt(item.cost || 0);
                    const gstPercent = parseFloat(item.gst || 0);
                    const delivery = parseFloat(item.delivery_charges || 0);
                
                    // ✅ No need to use static color/size costs; pricing now dynamic via variant selection
                
                    // ✅ Build variant HTML dynamically
                    const variantHtml = (data.variant_datas || []).map((variant, variantIndex) => {
                        const variableHtml = (variant.variables || []).map((variable, varIndex) => `
                            <div class="d-flex align-items-center justify-content-between vart_menu_var_payment px-2 pt-1 mb-3 cursor-pointer ${varIndex === 0 ? 'selected active bg-light-success' : ''}" 
                                data-variable-id="${variable.variable_id}" 
                                data-cost="${variable.cost}">
                                <div class="text-black fs-6 fw-semibold mb-1">${variable.variable_name || variable.name}</div>
                                <div class="text-black fs-6 fw-semibold mb-1">&#8377; ${variable.cost}</div>
                            </div>
                        `).join('');
                
                        return `
                            <div class="col-lg-12 mb-3" data-variant-id="${variant.variant_id}">
                                <div class="d-flex align-items-center justify-content-between border-bottom px-3 mb-3">
                                    <div class="text-black fs-6 fw-semibold mb-1">
                                        ${variant.variant_name}
                                        <span class="badge bg-warning text-black fw-semibold rounded-pill fs-8" title="Total Options">
                                            ${variant.variables?.length || 0}
                                        </span>
                                    </div>
                                    <div class="text-black fs-6 fw-semibold mb-1">Amount<br><span class="fs-8">(Per Unit)</span></div>
                                </div>
                                <div class="scroll-y max-h-150px px-2">
                                    ${variableHtml}
                                </div>
                            </div>
                        `;
                    }).join('');

                    accordionHTML += `
                        <div class="accordion-item mb-3 ${index === 0 ? 'active' : ''}" data-gst="${gstPercent}" data-delivery="${delivery}">
                            <h2 class="accordion-header" id="heading${index}">
                                <button type="button" class="accordion-button pb-2 ${index === 0 ? '' : 'collapsed'}" data-bs-toggle="collapse"
                                    data-bs-target="#accordion${index}" aria-expanded="${index === 0}" aria-controls="accordion${index}" role="tabpanel">
                                    <div class="form-check">
                                        <input class="form-check-input me-0" type="radio" name="var_place_order_chk"
                                            data-count="${count}" data-cost="${cost}" data-gst="${gstPercent}" data-delivery="${delivery}"
                                            data-index="${index}" data-buyitemid="${item.index_id}" data-marketingid="${marketing_kit_id}" ${index === 0 ? 'checked' : ''} />
                                        <label class="form-check-label text-black mb-1 fs-5 fw-semibold">${count} Pcs</label>
                                    </div>
                                </button>
                            </h2>
                            <div id="accordion${index}" class="accordion-collapse collapse ${index === 0 ? 'show' : ''}" data-bs-parent="#accordionExamplepayment">
                                <div class="accordion-body">
                                    <div class="row">
                                        <div class="col-lg-12 mb-3">
                                            <div class="scroll-y max-h-150px px-2">
                                                <strong>Cost per unit:</strong> ₹ ${cost}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

              });

              $('#accordionExamplepayment').html(accordionHTML);


            }


        });
    });


  });
  //payment details changes
  function updatePriceDetails() {
    const selectedAccordion = $('input[name="var_place_order_chk"]:checked').closest('.accordion-item');

    const count = parseInt(selectedAccordion.find('label.form-check-label').text() || 0);
    const gstPercent = parseFloat(selectedAccordion.find('input[name="var_place_order_chk"]').data('gst') || 0);
    const delivery = parseFloat(selectedAccordion.find('input[name="var_place_order_chk"]').data('delivery') || 0);

    // ✅ Dynamic total cost from selected variant options
    let unitPrice = 0;
    selectedAccordion.find('.vart_menu_var_payment.selected').each(function () {
        const cost = parseFloat($(this).data('cost') || 0);
        unitPrice += cost;
    });

    const total = unitPrice * count;
    const gst = (total * gstPercent) / 100;
    const final = total + gst + delivery;

    $('.price-count').text(count);
    $('.price-cost').text(`₹ ${total.toLocaleString()}`);
    $('.price-gst').text(`₹ ${gst.toLocaleString()}`);
    $('.price-delivery').text(`₹ ${delivery.toLocaleString()}`);
    $('.price-total').text(`₹ ${final.toLocaleString()}`);
    $('.price-gst').prev().find('span').text(`( ${gstPercent}% )`);
}


  // When radio is changed (selecting buy item)
  $(document).on('change', 'input[name="var_place_order_chk"]', function () {
      updatePriceDetails();
  });

  
  // When a variant option is clicked (generic for all)
    $(document).on('click', '.vart_menu_var_payment', function () {
        const container = $(this).closest('.accordion-body');
        const variantSection = $(this).closest('.col-lg-12');
        
        // Remove 'selected' from all in this section
         variantSection.find('.vart_menu_var_payment').removeClass('selected active bg-light-success');
        
        // Mark clicked one as selected
        $(this).addClass('selected active bg-light-success');
    
        updatePriceDetails();
    });

  
  $(document).on('click', '#btnPlaceOrder', function () {
    // console.log($('#btnPlaceOrder').length);
      const count = $('.price-count').text();
      const cost = $('.price-cost').text().replace(/[₹,\s]/g, '');
      const gst = $('.price-gst').text().replace(/[₹,\s]/g, '');
      const delivery = $('.price-delivery').text().replace(/[₹,\s]/g, '');
      const total = $('.price-total').text().replace(/[₹,\s]/g, '');

      // Get selected variant // this data not getting i thing??
      const selected = $('input[name="var_place_order_chk"]:checked');
      console.log("Selected Radio:", selected);
      console.log("Buy Item ID:", selected.data('buyitemid'));
      console.log("Marketing Kit ID:", selected.data('marketingid'));
      // if (!selected.length) {
      //     alert('Please select a quantity option');
      //     return;
      // }
      const indexId = selected.data('index');
      const buy_item_id = selected.data('buyitemid');
      const marketingId = selected.data('marketingid');
      // alert(marketingId);
      const parentAccordion = selected.closest('.accordion-item');
      const colorId = parentAccordion.find('.vart_menu_clr.active').data('color-id');
      const sizeId = parentAccordion.find('.vart_menu_sz.active').data('size-id');

      $.ajax({
          url: '/razorpay-store-payment-data',
          method: 'POST',
          data: {
              _token: $('meta[name="csrf-token"]').attr('content'),
              count,
              cost,
              gst,
              delivery,
              total,
              marketing_kit_id: marketingId,
              index_id: indexId,
              buy_item_id: buy_item_id,
              color_id: colorId,
              size_id: sizeId
          },
          success: function () {
              window.location.href = '/razorpay-payment';
          }
      });
  });


 



</script>

<script>

  $(document).on('click', '#kt_add_to_cart_btn', function () {
    let selectedAccordionItem = $('input[name="var_pre_chk_cart"]:checked').closest('.accordion-item');
    let buy_item_id = parseInt(selectedAccordionItem.attr('data-buy-item-id') || 0);

    let hasError = false;
    $('.error-div').remove(); // clear previous errors

   
    // Dynamically collect variant selections
    const variantSelections = [];
    selectedAccordionItem.find('.vart_menu_var_cart').each(function () {
        if ($(this).hasClass('active')) {
            const parentLabel = $(this).closest('.col-lg-12').find('.fw-semibold').first().text().trim();
            const variantGroup = selectedAccordionItem.find('.fw-semibold').filter(function () {
                return $(this).text().trim() === parentLabel;
            }).text().trim();

            const variantId = $(this).closest('.col-lg-12').data('variant-id'); // if set in HTML
            const variableId = $(this).data('variable-id');
            if (variableId) {
                variantSelections.push({
                    variant_id: variantId,
                    variable_id: variableId
                });
            } else {
                hasError = true;
                $(this).before('<div class="error-div text-danger mb-2">Please select a value for all variants</div>');
            }
        }
    });

    if (hasError) return;


    const payload = {
        marketing_kit_id: $('#martketing_kit_id').val(),
        buy_item_id: buy_item_id,
        variant_selections: variantSelections // this is an array of {variant_id, variable_id}
    };

    const btn = $(this);
    btn.prop('disabled', true);
    btn.html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Adding...');

    $.ajax({
        url: '/marketing-kit/add_to_cart',
        type: 'POST',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        data: payload,
        success: function (res) {
            btn.html('<i class="mdi mdi-check-bold me-1"></i>Added');
            updateCartCount();
            $('#kt_modal_add_to_cart').modal('hide');
            toastr.success('Item added to cart successfully.');
        },
        error: function (err) {
            btn.prop('disabled', false);
            btn.html('<span class="fs-6">Add To Cart</span>');
            toastr.error('Something went wrong.');
        }
    });
});

    function updateCartCount() {
        $.ajax({
            url: '/get_Cart_Count',
            type: 'GET',
            success: function (count) {
                if (count > 0) {
                    $('.cart-badge-count').text(count).show();
                } else {
                    $('.cart-badge-count').hide();
                }
            },
            error: function () {
                console.error('Failed to fetch cart count.');
            }
        });
    }

    function loadCartView() {
      $.ajax({
          url: '/get_Cart_view',
          type: 'GET',
          success: function (response) {
              // Clear previous items
              $('#cart-items-container').html('');
              $('#cart-summary-container').html('');
            // Check if cart is empty


              // Append cart items
              let itemsHtml = '';
              response.items.forEach((item, index) => {
                  
                   let variantHtml = '';
                        if (Array.isArray(item.variant_datas)) {
                            item.variant_datas.forEach((variant, vIndex) => {
                                let colorSwatch = '';
                                if (variant.variant_name.toLowerCase() === 'color') {
                                    // Optionally render a color swatch
                                    colorSwatch = `<span class="badge w-20px h-20px border rounded mb-n1" style="background-color:${variant.variable_name};"></span>`;
                                }
                    
                                variantHtml += `
                                    <div class="w-50 mb-1">
                                        <label class="text-dark fs-7">${variant.variant_name}</label>
                                        <label class="text-dark fs-7 ms-1 me-1">-</label>
                                        <label class="text-dark fs-7">
                                            ${colorSwatch}
                                            <span class="fw-bold ms-1">${variant.variable_name}</span>
                                            <span class="fw-bold">(&#8377; ${variant.cost})</span>
                                        </label>
                                    </div>
                                    ${vIndex % 2 === 0 ? '<label class="text-dark fs-7 ms-1 me-2">|</label>' : ''}
                                `;
                            });
                        }
                        
                  itemsHtml += `

                          <div class="d-flex align-items-start mb-4" data-cart-id="${item.cart_id}"  data-index-id="${item.index_id || index}">
                              <div class="symbol symbol-35px border border-gray-500 rounded px-2 py-1 me-3">
                                  <div class="image-input image-input-circle" data-kt-image-input="true">
                                      <img src="/marketing_kits_thumbnail/${item.marketing_thumbnail}" alt="user-avatar" class="image-input-wrapper w-125px h-125px" />
                                  </div>
                              </div>
                              <div class="w-100 mb-0">
                                  <div class="d-flex align-items-start fs-5 fw-semibold text-black mb-2">
                                      <div class="mk_cart_name w_99" data-bs-toggle="tooltip" data-bs-placement="bottom" data-marketing-id="${item.marketing_kit_id}" title="${item.marketing_kit_name}">${item.marketing_kit_name}</div>
                                      <a href="javascript:;" class="btn btn-icon btn-sm p-0 float-end remove-kit-btn" data-remove-id="${item.cart_id}" data-buyitem-id="${item.buy_item_id}">
                                          <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Remove Kit"  ><i class="mdi mdi-alpha-x-circle-outline fs-3 text-black"></i></span>
                                      </a>
                                  </div>
                                  <div class="d-flex align-items-start">
                                      <div class="text-dark fs-7 w-50" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category">${item.category_name}</div>
                                      <label class="text-dark fs-7 ms-1 me-2">|</label>
                                      <div class="w-50">
                                          <label class="text-dark fs-7">Count</label>
                                          <label class="text-dark fs-7 ms-1 me-1">-</label>
                                          <label class="text-dark fw-bold fs-7">${item.count} Pcs</label>
                                      </div>
                                  </div>
                                  <div class="d-flex align-items-start mb-3">
                                      ${variantHtml}
                                  </div>
                                  <div class="d-flex align-items-start">
                                      <div class="w-100 text-black fs-4 fw-semibold">&#8377; ${item.item_total}</div>
                                  </div>
                              </div>
                          </div>
                          <div class="border-dashed border-1 border-bottom border-gray-700 mb-3"></div>

                  `;
              });

              // Add items to modal
              $('#cart-items-container').html(itemsHtml);

              // Update price summary
              let summaryHtml = `
                <div class="border border-gray-700 rounded px-3 py-4">
                  <div class="text-black text-center fs-4 fw-semibold mb-3"><u>Price Details</u></div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold" data-price-amount="${response.summary.item_total}">Price<br><span class="fs-8 text-info">( ${response.summary.total_item} Items)</span></div>
                      <div class="text-black fs-6 text-end fw-semibold">&#8377; ${response.summary.item_total}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold">GST <span class="fs-7 text-danger">( ${response.summary.gst_percentage}%)</span></div>
                      <div class="text-black fs-6 text-end fw-semibold" data-gst-amount="${response.summary.gst_value}"><span class="fs-7 text-black me-1">( + )</span>&#8377; ${response.summary.gst_value}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-dark fs-6 fw-semibold">Delivery Charges</div>
                      <div class="text-black fs-6 text-end fw-semibold" data-delivery-amount="${response.summary.delivery_charge}"><span class="fs-7 text-black me-1">( + )</span>&#8377; ${response.summary.delivery_charge}</div>
                  </div>
                  <div class="d-flex align-items-center justify-content-between mb-4">
                      <div class="text-black fs-5 fw-semibold">Total Amount</div>
                      <div class="text-black fs-5 text-end fw-bold" data-total-amount="${response.summary.final_total}">&#8377; ${response.summary.final_total}</div>
                  </div>
                </div>

              `;
              $('#cart-summary-container').html(summaryHtml);
          },
          error: function (xhr) {
            if (xhr.status === 404) {
              const res = xhr.responseJSON;
                  $('#cart-items-container').html(`
                      <div class="d-flex justify-content-center align-items-center py-10 gap-5 flex-wrap">
                          <div>
                              <img src="/assets/eapl_images/empty-cart.gif" alt="Empty Cart" style="width: 180px; height: auto;" />
                          </div>
                          <div>
                              <div class="fs-4 fw-semibold text-gray-700">${res.message || 'No items in cart'}</div>
                          </div>
                      </div>
                  `);
                  $('#cart-summary-container').html('');
                  $('.cart-badge-count').text('0');
              } else {
                  console.error('Failed to fetch cart data.');
              }
          }
      });
    }

    $(document).on('click', '#kt_modal_cart_id', function () {
       loadCartView();
    });


    // Run on page load
    $(document).ready(function () {
        updateCartCount();
    });


      // Function to handle "Remove Kit" click
      function removeKitFromCart(cartId) {
          // Send AJAX request to update the status to 2
          $.ajax({
              url: '/cart/remove/' + cartId,  // Your API endpoint to update the status
              type: 'POST',
              data: {
                  _token: $('meta[name="csrf-token"]').attr('content'),  // CSRF Token
                  cart_id: cartId
              },
              success: function(response) {
                  // Handle the success response
                  if (response.success) {
                      toastr.success('Removing item from cart successfully!');
                      loadCartView();
                      updateCartCount();
                  }
              },
              error: function(xhr, status, error) {
                toastr.error('Error removing item from cart:', error);
              }
          });
      }

      // Example of binding the click event dynamically
      $(document).on('click', '.remove-kit-btn', function() {
          var cartId = $(this).data('remove-id');  // Get cart ID from data attribute
          removeKitFromCart(cartId);
      });

      $(document).on('click', '#btnPlaceOrderCart', function () {
          const $btn = $(this);
          $btn.prop('disabled', true).text('Processing...');
          let items = [];
          let cartIds = []; // Array to store cart_id values
          $('#cart-items-container > div').each(function () {
              const $item = $(this);

              const marketing_kit_id = $item.find('[data-marketing-id]').data('marketing-id'); // cart_id used as proxy
              const buy_item_id = $item.find('[data-buyitem-id]').data('buyitem-id'); // cart_id used as proxy
              const cart_id = $item.data('cart-id'); // cart_id used as proxy
              const countText = $item.find('.fw-bold:contains("Pcs")').text().trim();
              const count = parseInt(countText.replace(/\D/g, '')) || 0;

              const colorId = $item.find('[data-color-id]').data('color-id');
              const sizeId = $item.find('[data-size-id]').data('size-id');

              // If you're rendering buy_item_id and index_id somewhere, fetch them here. Otherwise, add them to your HTML.
              const index_id =  $item.find('[data-index-id]').data('index-id'); // cart_id used as proxy

              if (marketing_kit_id && buy_item_id && colorId && sizeId) {
                  items.push({
                      marketing_kit_id,
                      buy_item_id,
                      index_id,
                      color_id: colorId,
                      size_id: sizeId
                  });
              }
              cartIds.push(cart_id); // Add cart_id to the array

          });
          cartIds = cartIds.filter(id => id !== null);
          const summaryBox = $('#cart-summary-container');

          const cost     = summaryBox.find('[data-price-amount]').data('price-amount') || 0;
          const gst      = summaryBox.find('[data-gst-amount]').data('gst-amount') || 0;
          const delivery = summaryBox.find('[data-delivery-amount]').data('delivery-amount') || 0;
          const total    = summaryBox.find('[data-total-amount]').data('total-amount') || 0;

          // Filter out items where index_id is null or undefined (or any other condition if needed)
          let validItems = items.filter(item => item.index_id !== null);

          // Get the length of the valid items array (it should return 2)
          const count = validItems.length;
          $.ajax({
              url: '/razorpay-store-payment-data',
              method: 'POST',
              data: {
                  _token: $('meta[name="csrf-token"]').attr('content'),
                  items: JSON.stringify(items),
                  count,
                  cart_ids: cartIds, // Send the array of cart_ids
                  cost,
                  gst,
                  delivery,
                  total
              },
              success: function () {
                  window.location.href = '/razorpay-payment';
              },
              error: function () {
                  $btn.prop('disabled', false).text('Place Order');
                  alert('Something went wrong. Please try again.');
              }
          });
      });

</script>

<style>
  .vart_menu_clr.active,
  .vart_menu_sz.active {
    background-color: #d1e7dd !important;
    border: 1px solid #198754 !important;
    color: #000 !important;
  }
    .cart-badge-count {
      display: none; /* hide by default */
  }
</style>
<!-- begin::Marketing Kit Add To Cart Color Varient Active -->

<!-- end::Marketing Kit Add To Cart Color Varient Active -->

<!-- begin::Marketing Kit Add Color Variant -->
<script>
    function clr_red_chk_func() {
        var clr_red = document.getElementById("clr_red");

        if (clr_red.checked) {
            document.getElementById("reqd_1").style.display = "inline";
            document.getElementById("clr_red_tbox").disabled = false;
        } else {
            document.getElementById("reqd_1").style.display = "none";
            document.getElementById("clr_red_tbox").disabled = true;
        }
    }

    function clr_blue_chk_func() {
        var clr_blue = document.getElementById("clr_blue");

        if (clr_blue.checked) {
            document.getElementById("reqd_2").style.display = "inline";
            document.getElementById("clr_blue_tbox").disabled = false;
        } else {
            document.getElementById("reqd_2").style.display = "none";
            document.getElementById("clr_blue_tbox").disabled = true;
        }
    }

    function clr_white_chk_func() {
        var clr_white = document.getElementById("clr_white");

        if (clr_white.checked) {
            document.getElementById("reqd_3").style.display = "inline";
            document.getElementById("clr_white_tbox").disabled = false;
        } else {
            document.getElementById("reqd_3").style.display = "none";
            document.getElementById("clr_white_tbox").disabled = true;
        }
    }

    function clr_orange_chk_func() {
        var clr_orange = document.getElementById("clr_orange");

        if (clr_orange.checked) {
            document.getElementById("reqd_4").style.display = "inline";
            document.getElementById("clr_orange_tbox").disabled = false;
        } else {
            document.getElementById("reqd_4").style.display = "none";
            document.getElementById("clr_orange_tbox").disabled = true;
        }
    }
</script>
<!-- End::Marketing Kit Add Color Variant -->

<!-- begin::Marketing Kit Add Size Variant -->
<script>
    function size_1_chk_func() {
        var size_1 = document.getElementById("size_1");

        if (size_1.checked) {
            document.getElementById("size_reqd_1").style.display = "inline";
            document.getElementById("size_1_tbox").disabled = false;
        } else {
            document.getElementById("size_reqd_1").style.display = "none";
            document.getElementById("size_1_tbox").disabled = true;
        }
    }

    function size_2_chk_func() {
        var size_2 = document.getElementById("size_2");

        if (size_2.checked) {
            document.getElementById("size_reqd_2").style.display = "inline";
            document.getElementById("size_2_tbox").disabled = false;
        } else {
            document.getElementById("size_reqd_2").style.display = "none";
            document.getElementById("size_2_tbox").disabled = true;
        }
    }

    function size_3_chk_func() {
        var size_3 = document.getElementById("size_3");

        if (size_3.checked) {
            document.getElementById("size_reqd_3").style.display = "inline";
            document.getElementById("size_3_tbox").disabled = false;
        } else {
            document.getElementById("size_reqd_3").style.display = "none";
            document.getElementById("size_3_tbox").disabled = true;
        }
    }
</script>
<!-- End::Marketing Kit Add Size Variant -->

<!-- begin::Marketing Kit List Max Text Size Tooltip -->
<script>
    'use strict';
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 55;
        const elements = document.querySelectorAll('.mk_name');

        elements.forEach(el => {
            const fullText = el.textContent.trim();
            el.setAttribute('title', fullText);
            if (fullText.length > maxChars) {
                el.textContent = fullText.slice(0, maxChars) + '...';
            }
            bootstrap.Tooltip.getOrCreateInstance(el);
        });
    });
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 90;
        const elements = document.querySelectorAll('.mk_cart_name');

        elements.forEach(el => {
            const fullText = el.textContent.trim();
            el.setAttribute('title', fullText);
            if (fullText.length > maxChars) {
                el.textContent = fullText.slice(0, maxChars) + '...';
            }
            bootstrap.Tooltip.getOrCreateInstance(el);
        });
    });
</script>
<!-- end::Marketing Kit List Max Text Size Tooltip -->

<!-- begin::Marketing Kit Refine Results Show & Hide -->
<script>
    function sidebar_func() {
        const sidebar = document.getElementById("sidebar_tbox");
        const content = document.getElementById("cont_tbox");
        var cont_indv_tbox = document.querySelectorAll('.cont_indv_tbox');


        if (sidebar.style.display === "block") {
            sidebar.classList.add("fade-out");
            content.classList.remove("col-lg-9");
            content.classList.add("col-lg-12");
            cont_indv_tbox.forEach(el => {
                el.classList.remove("col-lg-4");
                el.classList.add("col-lg-3");
            });
            setTimeout(() => {
                sidebar.style.display = "none";
                sidebar.classList.remove("fade-out");
            }, 500);
        } else {
            sidebar.style.display = "block";
            sidebar.classList.remove("fade-out");
            content.classList.remove("col-lg-12");
            content.classList.add("col-lg-9");
            cont_indv_tbox.forEach(el => {
                el.classList.remove("col-lg-3");
                el.classList.add("col-lg-4");
            });
        }
    }
</script>
<!-- end::Marketing Kit Refine Results Show & Hide -->

<!-- begin::Marketing Kit Add Buy checkbox Addmore -->
<script>
    $('.variant_buy_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_variant_buy_add').length);
        let $clone = $('.form-repeater_variant_buy_add').first().clone().hide();
        $clone.insertBefore('.form-repeater_variant_buy_add:first').slideDown();
        if (bt == 1) {
            $('.variant_buy_add_del_list').attr('style', 'display: block !important');
        } else {
            $('.variant_buy_add_del_list').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_variant_buy_add .variant_buy_add_del_list', e => {
        var bt = parseFloat($('.variant_buy_add_del_list').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_variant_buy_add').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.variant_buy_add_del_list').attr('style', 'display: none !important');
        } else {}
    });
</script>
<!-- end::Marketing Kit Add Buy checkbox Addmore -->

<!-- end::Marketing Kit Add Buy Checkbox -->

<!-- begin::Marketing Kit Add Attachment -->
<script>
    let marketing_kit_atmt = document.getElementById('marketing_kit_atmt');
    const marketing_kit_fileInput = document.querySelector('.marketing_kit_file-in'),
        marketing_kit_resetFileInput = document.querySelector('.marketing_kit_file-reset');

    if (marketing_kit_atmt) {
        const resetImage = marketing_kit_atmt.src;
        marketing_kit_fileInput.onchange = () => {
            if (marketing_kit_fileInput.files[0]) {
                marketing_kit_atmt.src = window.URL.createObjectURL(marketing_kit_fileInput.files[0]);
            }
        };
        marketing_kit_resetFileInput.onclick = () => {
            marketing_kit_fileInput.value = '';
            marketing_kit_atmt.src = resetImage;
        };
    }
</script>
<!-- end::Marketing Kit Add Attachment -->

<!-- begin::Marketing Kit Add & Edit variant checkbox -->
<script>
    'use strict';
    (function() {
        document.querySelectorAll('.variant_1_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.variant_1_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.variant_2_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.variant_2_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.variant_1_icon_edit').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.variant_1_body_edit');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.variant_2_icon_edit').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.variant_2_body_edit');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
</script>
<!-- end::Marketing Kit Add & Edit variant checkbox -->

<!-- begin::Marketing Kit Refine Results checkbox -->
<script>
    'use strict';

    (function() {
        document.querySelectorAll('.menu_1_hd, .menu_1_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_1_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.menu_2_hd, .menu_2_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_2_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.menu_3_hd, .menu_3_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_3_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.menu_4_hd, .menu_4_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_4_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.menu_5_hd, .menu_5_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_5_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
    (function() {
        document.querySelectorAll('.menu_6_hd, .menu_6_icon').forEach(trigger => {
            trigger.addEventListener('click', e => {
                e.preventDefault();

                const card = trigger.closest('.card');
                const collapseEl = card.querySelector('.collapse.menu_6_body');
                const header = card.querySelector('.card-header');
                const icon = trigger.querySelector('i'); // icon inside the clicked element

                const collapseInstance = bootstrap.Collapse.getOrCreateInstance(collapseEl);
                collapseInstance.toggle();

                header.classList.toggle('collapsed');

                if (icon) {
                    Helpers._toggleClass(icon, 'mdi-chevron-down', 'mdi-chevron-up');
                }
            });
        });
    })();
</script>
<!-- end::Marketing Kit Refine Results checkbox -->



<!-- end::Marketing Kit Refine Results checkbox Show more & Less -->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

    $(".list_page_1").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
            "info": "" // Hides the "Showing 0 to 0 of 0 entries" message
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection
