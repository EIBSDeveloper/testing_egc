@extends('layouts/layoutMaster')

@section('title', 'Verify Campaign Checklist')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-4 text-black">Verify Campaign Checklist</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Campaign</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-2">
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-domain fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->campaign_name ??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-group fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_category_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-text fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Type"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_type_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-text-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->description??''}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-counter fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Count"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->count??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cash fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment"></i>
                        </label>
                        <div class="text-info fw-bold fs-6">
                            <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-info fw-bold"></i></label>
                            <label class="fs-6" id='initial_amount'>{{$verify_activity_edit->payment??""}}</label>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-calendar-range fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->start_date ??'-'}} to {{$verify_activity_edit->end_date??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-map-marker-radius fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Zone"></i>
                        </label>
                        <label class="fw-semibold fs-6 zone_name">{{$verify_activity_edit->zone_name??'-'}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_vendor_name??'-'}}</label>
                        <div class="d-block fw-semibold fs-7"></div>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-account-supervisor fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->vendor_contact_person_name??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cellphone fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Mobile No"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->vendor_contact_person_mobile??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building-marker fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity_edit->marketing_vendor_address??'-'}}</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="mb-2 d-flex align-items-center">
                <label class="fw-semibold fs-6 me-1">
                    <i class="mdi mdi-text-box-check-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign Checklist"></i>
                </label>
                <label class="text-black my-4 fs-5 fw-semibold">Campaign Checklist</label>
            </div>
            @php
            $zone_area_name = json_decode($verify_activity_edit->zone_area_name, true);
            $champ_name = json_decode($verify_activity_edit->camp_checklist, true);


            $counter = 0; // Initialize the counter
            $totalCount = !empty($champ_name) ? count($champ_name) : 0;

            //print_r($totalCount);
            @endphp

            <form id="mar_verify_activity_edit" action="{{ route('marketing_verifiy_activity') }}" method="POST">
                @csrf
                @php
                // Decode the checklist JSON string
                $checklistData = json_decode($verify_activity_edit->checklist, true);
                $checklistArray = [];

                // Prepare a lookup array for quick access
                if ($checklistData) {
                foreach ($checklistData as $check) {
                $checklistArray[$check['inner_check_id']] = $check;
                }
                }
                @endphp
                @if(isset($verify_activity_edit->payment) && isset($verify_activity_edit->zone_area_name))
                @php
                // Decode the checklist JSON string
                $checklistData = json_decode($verify_activity_edit->checklist, true);
                $checklistArray = [];

                // Prepare a lookup array for quick access
                if ($checklistData) {
                foreach ($checklistData as $check) {
                $checklistArray[$check['inner_check_id']] = $check;
                }
                }
                @endphp
                @if(isset($zone_area_name))
                @foreach($zone_area_name as $key => $value)
                <div class="col-lg-12 mb-4">
                    <div class="card-action">
                        <div class="card-header bg-label-success">
                            <div class="card-action-title">
                                <div class="row">
                                    <div class="col-lg-4 d-flex align-items-center">
                                        <div class="form-check form-check-inline">
                                            @php
                                            // Check if outer_check_id is present in the checklist data
                                            $outerChecked = false;
                                            foreach ($checklistData as $check) {
                                            if ($check['outer_check_id'] == $value['id']) {
                                            $outerChecked = true;
                                            break;
                                            }
                                            }
                                            @endphp
                                            <input class="form-check-input outer_checkbox" type="checkbox" name="outer_checkbox[{{ $value['id'] }}]" value="1" id="area_{{$value['id']}}" {{ $outerChecked ? 'checked' : '' }} />
                                            <label class="text-black fs-6 fw-bold" for="area_{{$value['id']}}">{{ $value['value'] }}</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 mb-3">
                                        <div class="d-flex align-items-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Count">
                                            <label class="text-dark fs-5 fw-bold">0</label>
                                            <label class="text-dark fs-5 fw-bold">/</label>
                                            <label class="text-dark fs-5 fw-bold">{{ $totalCount }}</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="badge bg-info fw-bold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Actual Amount">
                                            <label class="fs-5"><i class="mdi mdi-currency-rupee fs-5 text-white fw-bold"></i></label>
                                            <label class="fs-5 amount_display" id="amount_display_{{ $key }}">0.00</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-action-element">
                                <ul class="list-inline mb-0">
                                    <li class="list-inline-item">
                                        <a href="javascript:;" class="first_zone_add_{{ $counter }}" onclick="up_down_branch({{ $counter }})"><i class="mdi mdi-chevron-up fs-3 text-black"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="collapse first_zone_body_add_{{ $counter }} border">
                        <div class="card-body">
                            <div class="row">
                                <input type="hidden" name="marketing_sno_edit" id="marketing_sno_edit" value="{{$verify_activity_edit->mark_sno}}">
                                <div class="col-lg-12">
                                    <div class="row bg-label-danger rounded">
                                        <div class="col-lg-6 mt-2 mb-1 text-black fs-6 fw-semibold">Checklist</div>
                                        <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Amount</div>
                                        <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Reason</div>
                                    </div>
                                    @php
                                    print_r($champ_name);
                                    @endphp
                                    @if(isset($champ_name))
                                    @foreach($champ_name as $key => $activity)
                                    @php
                                    // Check if the check_id exists in the checklistArray
                                    $isChecked = isset($checklistArray[$activity['id']]);

                                    // Check if the check_id exists and get amount and reason as strings
                                    $amount = $isChecked && isset($checklistArray[$activity['id']]['amount'])
                                    ? (is_array($checklistArray[$activity['id']]['amount'])
                                    ? implode(', ', $checklistArray[$activity['id']]['amount'])
                                    : $checklistArray[$activity['id']]['amount'])
                                    : '';
                                    $reason = $isChecked && isset($checklistArray[$activity['id']]['reason'])
                                    ? (is_array($checklistArray[$activity['id']]['reason'])
                                    ? implode(', ', $checklistArray[$activity['id']]['reason'])
                                    : $checklistArray[$activity['id']]['reason'])
                                    : '';
                                    @endphp

                                    {{-- HTML Section --}}
                                    <div class="row mt-2">
                                        <div class="col-lg-6 mb-2 d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input activity_chk" name="inner_checkbox[{{ $key }}][{{ $activity['id'] }}]" type="checkbox" id="activity_{{ $activity['id'] }}" value="1" {{ $isChecked ? 'checked' : '' }} onchange="toggleAmountField({{ $key }}, {{ $activity['id'] }})" />
                                                <label class="text-dark fs-6 fw-semibold" for="activity_{{ $activity['id'] }}">
                                                    {{ $activity['value'] }}
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 mb-2">
                                            <input type="text" class="form-control amount-input" id="checklist_amount_{{ $activity['id'] }}" name="checklist_amount[{{ $key }}][{{ $activity['id'] }}]" placeholder="Enter Amount" value="{{ $amount }}" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\\..*)\\./g, '$1');" onkeyup="calculateTotal({{ $key }})" />
                                        </div>

                                        <div class="col-lg-3">
                                            {{-- Uncomment and handle the reason field if needed --}}
                                            <textarea class="form-control" rows="1" id="checklist_reason_{{ $activity['id'] }}" name="checklist_reason[{{ $key }}][{{ $activity['id'] }}]" placeholder="Enter Reason">{{ $reason ?? 'no data' }}</textarea>
                                        </div>
                                    </div>
                                    @endforeach

                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
                @endif
                @else
                <div class="card-body">
                    <div class="row">
                        <input type="hidden" name="marketing_sno_edit" id="marketing_sno_edit" value="{{$verify_activity_edit->mark_sno}}">
                        <div class="col-lg-12">
                            {{-- <label class="info badged-danger amount_display">{{$verify_activity_edit->total_amount}}</label> --}}
                            <div class="row bg-label-danger rounded">
                                <div class="col-lg-6 mt-2 mb-1 text-black fs-6 fw-semibold">Checklist</div>
                                <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Amount</div>
                                <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Reason</div>
                            </div>
                            @if(isset($champ_name))
                            @foreach($champ_name as $key => $activity)
                            @php
                            // Check if the check_id exists in the checklistArray
                            $isChecked = isset($checklistArray[$activity['id']]);
                            $amount = $isChecked ? $checklistArray[$activity['id']]['amount'] : '';
                            $reason = $isChecked ? $checklistArray[$activity['id']]['reason'] : '';
                            @endphp
                            <div class="row mt-2">
                                @if($key<=0) <label class="fs-5  info badge-warning amount_display" id="amount_display_{{ $key }}">0.00</label>
                                    @endif
                                    <div class="col-lg-6 mb-2 d-flex align-items-center">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input activity_chk" name='inner_checkbox[{{ $activity['id'] }}]' type="checkbox" id="activity_{{ $activity['id'] }}" value="1" {{ $isChecked ? 'checked' : '' }} />
                                            <label class="text-dark fs-6 fw-semibold" for="activity_{{ $activity['id'] }}">{{ $activity['value'] }}</label>
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <input type="text" class="form-control amount-input" id="checklist_amount_{{ $activity['id'] }}" name="checklist_amount[{{ $activity['id'] }}]" placeholder="Enter Amount" value="{{ $amount }}" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\\..*)\\./g, '$1');" onkeyup="calculateTotal({{ $key }})" />
                                    </div>
                                    <div class="col-lg-3">
                                        <textarea class="form-control" rows="1" id="checklist_reason_{{ $activity['id'] }}" name="checklist_reason[{{ $activity['id'] }}]" placeholder="Enter Reason">{{ $reason }}</textarea>
                                    </div>
                            </div>
                            @endforeach
                            @endif
                        </div>
                    </div>
                </div>
                @endif
                <div class="d-flex justify-content-end align-items-center gap-2 mt-4">
                    <a href="{{url('/marketing')}}" class="btn fw-bold btn-secondary">Cancel</a>
                    <button type='button' id='submitbtn' class="btn fw-bold btn-primary" onclick="validateForm()">Verify Campaign Checklist</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('.outer_checkbox').change(function() {
                // Check or uncheck all activity checkboxes based on the outer checkbox
                $('.activity_chk').prop('checked', this.checked);
                // Clear all amount inputs if the outer checkbox is unchecked
                if (!this.checked) {
                    $('input[id^="checklist_amount_"]').val('');
                }
            });

            $('.activity_chk').change(function() {
                // Get the corresponding amount input field
                const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                const amountInput = document.getElementById(amountInputId);

                // If the checkbox is unchecked, clear the corresponding amount input
                if (!this.checked) {
                    if (amountInput) {
                        amountInput.value = ''; // Clear the amount
                    }
                }

                // Count how many inner checkboxes are checked
                const checkedCount = $('.activity_chk:checked').length;
               console.log('checkedCount',checkedCount);
                const totalCount = $('.activity_chk').length;

                // If all inner checkboxes are checked, check the outer checkbox
                if (checkedCount === totalCount) {
                    $('.outer_checkbox').prop('checked', true);
                } else {
                    // Only uncheck the outer checkbox if no inner checkboxes are checked
                    if (checkedCount === 0) {
                        $('.outer_checkbox').prop('checked', false);
                    }
                }
            });
        });

    </script>



    <!--Create Zone Accordion Start-->
    <script>
        'use strict';

        function up_down_branch(id) {
            const first_zone_add = [].slice.call(document.querySelectorAll('.first_zone_add_' + id));
            // Collapsible card
            // --------------------------------------------------------------------
            if (first_zone_add) {
                first_zone_add.map(function(syll_chapter_add_Element) {
                    syll_chapter_add_Element.addEventListener('click', event => {
                        event.preventDefault();
                        // Collapse the element
                        new bootstrap.Collapse(syll_chapter_add_Element.closest('.card').querySelector(
                            '.collapse.first_zone_body_add_' + id));
                        // Toggle collapsed class in `.card-header` element
                        syll_chapter_add_Element.closest('.card-header').classList.toggle('collapsed');
                        // Toggle class mdi-chevron-down & mdi-chevron-up
                        Helpers._toggleClass(syll_chapter_add_Element.firstElementChild
                            , 'mdi-chevron-down', 'mdi-chevron-up');
                    });
                });
            }

        }

    </script>
    <!--Create Zone Accordion End-->




    <script>
        function calculateTotal(zoneIndex) {
            let total = 0;

            // Select all input fields whose IDs start with "checklist_amount_"
            const amountInputs = document.querySelectorAll(`input[id^="checklist_amount_"]`);

            amountInputs.forEach(input => {
                const checkboxId = input.id.replace("checklist_amount_", "activity_");
                const checkbox = document.getElementById(checkboxId);

                if (checkbox && checkbox.checked) {
                    // Parse the input value as a float, default to 0 if NaN
                    const value = parseFloat(input.value) || 0;
                    total += value; // Add the value to the total
                    console.log('Current Total:', total);
                }
            });

            // Update the displayed total, ensuring it's formatted to two decimal places
            document.getElementById(`amount_display_${zoneIndex}`).innerText = total.toFixed(2);
            document.querySelectorAll(`.amount_display`).innerText = total.toFixed(2);
        }

        $(document).ready(function() {
            $('.outer_checkbox').change(function() {
                $('.activity_chk').prop('checked', this.checked);
                if (!this.checked) {
                    $('input[id^="checklist_amount_"]').val(''); // Clear amounts if outer checkbox is unchecked
                    calculateTotal(0);
                }
            });

            $('.activity_chk').change(function() {
                const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                const amountInput = document.getElementById(amountInputId);
                if (!this.checked) {
                    if (amountInput) {
                        amountInput.value = ''; // Clear input value if checkbox is unchecked
                    }
                }

                calculateTotal(0); // Recalculate total on checkbox change
            });

            // Update total on amount input change
            $('input[id^="checklist_amount_"]').on('input', function() {
                calculateTotal(0);
            });

            $('#myForm').on('submit', function(e) {
                // Loop through each checkbox
                $('.activity_chk').each(function() {
                    const amountInputId = `checklist_amount_${this.id.split('_')[1]}`;
                    const amountInput = document.getElementById(amountInputId);

                    // If the checkbox is unchecked, remove its corresponding amount input
                    if (!this.checked) {
                        if (amountInput) {
                            amountInput.name = ''; // Set name to empty to prevent sending
                        }
                    }
                });
            });
        });

    </script>


    <script>
        function validateForm() {
            var initialAmount = parseFloat($("#initial_amount").text()).toFixed(2) || 0;
            var totalDisplayAmount = parseFloat($(".amount_display").text()).toFixed(2) || 0;

            console.log('initial', initialAmount);
            console.log('total display', totalDisplayAmount);

            // Compare the amounts
            if (initialAmount === totalDisplayAmount) {
                // Submit the form if amounts match
                document.getElementById('mar_verify_activity_edit').submit();
            } else {
                alert('Amounts do not match!'); // Alert if amounts do not match
            }
        }

    </script>




    @endsection
