@extends('layouts/layoutMaster')

@section('title', 'Manage Events')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss','resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss','resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/js/forms_file_upload.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
    <!-- Users List Table -->
    <style>
        .dataTables_scroll3 {
            position: relative;
            overflow: auto;
            max-height: 400px;
            /*the maximum height you want to achieve*/
            width: 100%;
        }

        .dataTables_scroll3 thead {

            position: -webkit-sticky;
            position: sticky;
            top: 0;
            background-color: #fff;
            z-index: 2;
        }
        
        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 2;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
    <style>
  #studs_table thead th {
    padding: 5px !important;
  }

  #studs_table tbody td {
    padding: 5px !important;
  }

  .dataTables_scroll {
    position: relative;
    overflow: auto;
    max-height: 271px;
    /*the maximum height you want to achieve*/
    width: 100%;
  }

  .dataTables_scroll thead {
    position: -webkit-sticky;
    position: sticky;
    top: 0;
    /*background-color: #fff;*/
    z-index: 2;
  }
  /* Progress Bar Container */
.progress-container {
    width: 100%;
    height: 10px;
    background-color: #f3f3f3; /* Light gray background */
    border-radius: 5px;
    overflow: hidden;
    display: none; /* Hidden by default */
    position: relative; /* For positioning sending text */
    margin :5px 0 ;
    
}
/* Progress Bar Container */
.progress-container {
    width: 100%;
    height: 15px; /* Increased height of the container */
    background-color: #f3f3f3; /* Light gray background for the progress container */
    border-radius: 5px;
    overflow: hidden;
    display: none; /* Hidden by default */
    position: relative; /* For positioning sending text */
    margin: 5px 0;
}

/* Progress Bar */
.progress-bar {
    height: 100%;
    width: 0%; /* Initial width is 0% */
    background-color: red; /* Default color when sending */
    transition: width 1s ease-in-out, background-color 1s ease-in-out;
}

/* Success color for the progress bar (Green) */
.progress-bar.success {
    background-color: green;
}

/* Failure color for the progress bar (Red) */
.progress-bar.failure {
    background-color: red;
}

/* Warning color for the progress bar (Yellow) */
.progress-bar.warning {
    background-color: yellow;
}

/* "Sending..." text inside the Progress Bar */
.sending-text {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 12px;
    font-weight: bold;
    color: black;
    padding: 0 8px; /* Horizontal padding to space out the text */
    line-height: 15px; /* Centers the text vertically in the container */
}



</style>
    @php
    $helper = new \App\Helpers\Helpers();
    @endphp
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Manage Events</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Marketing Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                @php
                    // Get the logged-in user_id
                    $user_id = auth()->user()->user_id;
                    $role_id = auth()->user()->role_id;
                    // Get the filtered branch and franchise list based on user's multi_branch_access
                    $branch_data = $helper->get_branch_control_list($user_id);
                    $branches = $branch_data['branches'];
                    $franchises = $branch_data['franchises'];
                @endphp
                @if($role_id ==1)
                <select class="select3 form-select" id="branch_filter" onchange=branch_filter_func()>
                    <option value="" selected>All Branches</option>
                    @if ($branches->isNotEmpty())
                        <optgroup  label="Branches">
                            @foreach ($branches as $branch)
                                <option value="{{ $branch->sno }}" {{$branch_fill == $branch->sno ? 'selected' : '' }}>
                                    {{ $branch->branch_name }}
                                </option>
                            @endforeach
                        </optgroup>
                    @endif
                    @if ($franchises->isNotEmpty())
                        <optgroup label="Franchises">
                            @foreach ($franchises as $franchise)
                                <option value="{{ $franchise->sno }}" {{$branch_fill == $branch->sno ? 'selected' : '' }}>
                                    {{ $franchise->franchise_name }}
                                </option>
                            @endforeach
                        </optgroup>
                    @endif
                </select>
                @endif
              
                <form id="branch_form" method="POST" action="/events">
                    @csrf
                    <input type="hidden" name="branch_fill" id="branch_fill" />
                </form>
                @if(auth()->user()->hasPermission('Marketing Management', 'Create Event', 'Manage Events'))
                <a href="{{ url('/events/event_add') }}" class="btn btn-sm fw-bold btn-primary">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Create Event
                </a>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_add_poster_template">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Poster Template
                </a>
                @endif
                <div class="btn-group">
                
                  <button type="button" class="btn btn-sm fw-bold btn-primary dropdown-toggle hide-arrow" id="filter_student" title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                  </button>
                </div>
             
              
                
            </div>
            <div class="filter_tbox" style="display: none;">
            <form id="filter_form" method="POST" action="/events">
                @csrf
                <div class="row py-1">
                    <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Status</label>
                    <select id="event_status_fill" class="select3 form-select" name="event_status_fill" >
                        <option value="">All</option>
                        <option value="Schedule" @if($event_status_fill =="Schedule") selected @endif>Schedule</option>
                        <option value="Live" @if($event_status_fill =="Live") selected @endif>Live</option>
                        <option value="not_completed" @if($event_status_fill =="not_completed") selected @endif>Not Completed</option>
                        <option value="Attendance" @if($event_status_fill =="Attendance") selected @endif>Attendance</option>
                        <option value="Completed" @if($event_status_fill =="Completed") selected @endif>Completed</option>
                        <option value="Cancelled" @if($event_status_fill =="Cancelled") selected @endif>Cancelled</option>
                    </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Name</label>
                    <input type="text" class="form-control" id="" name="event_name" placeholder="Event Name" value="{{$event_name ??'' }}" />
                    </div>
                    <!--<div class="col-lg-3 mb-2">-->
                    <!--<label class="text-dark mb-1 fs-6 fw-semibold">Event Type</label>-->
                    <!--<select id="event_type_fill" class="select3 form-select" name="event_type_fill" >-->
                    <!--    <option value="">All</option>-->

                    <!--</select>-->
                    <!--</div>-->
                    <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Name</label>
                    <input type="text" class="form-control" id="" name="person_name" placeholder="Contact Person Name" value="{{$person_name ??'' }}"  />
                    </div>
                    <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Mobile</label>
                    <input type="text" class="form-control" id="" name="person_mobile" value="{{$person_mobile ??'' }}"  placeholder="Contact Person Mobile" maxlength="10"
                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                            <option value="all" @if($date_filter =="all") selected @endif>All</option>
                            <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                            <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                            <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                            <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_acc_month_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_from_dt_fill" readonly name="from_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="acc_daily_to_dt_fill" readonly name="to_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end mb-3">
                    <a href="{{ url('/events') }}" type="button"
                    class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                </div>
            </form>
            </div>
          
           
                  
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="mb-4">
                          @php $perpage_count = $perpage ? $perpage : 25; @endphp
                          <div>
                              <span>Show</span>
                              <br>
                              <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                  <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                  </option>
                                @php endforeach; @endphp
                              </select>
                          </div>
                      </div>
                      <div class="mb-4">
                        <form id="search_form" method="POST" action="/events">
                          @csrf
                        <div class="d-flex align-items-center gap-2">
                          <div class="mb-1">
                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                            <input type="hidden" name="filter_on" value="1">
                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                            <input
                              type="text"
                              class="form-control"
                              id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                              placeholder="Enter Event - Name/ date .."
                            />
                          </div>
                          <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" >Search</button>
                        </div>
                        </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 ">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-80px">Branch</th>
                                    <th class="min-w-120px">Event</th>
                                    <th class="min-w-80px">Event Mode</th>
                                    <!--<th class="min-w-80px">Event Amount</th>-->
                                    <th class="min-w-80px">Event Date<br>Amount</th>
                                    <th class="min-w-100px">Contact</th>
                                    <th class="min-w-50px">Participants</th>
                                    <th class="min-w-50px">Status</th>
                                    <th class="min-w-175px">Action</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                @if (isset($event_list))
                                    @foreach ($event_list as $list)
                                    @csrf
                                    @php
                                    $encryptedValue = $helper->encrypt_decrypt($list->sno, 'encrypt');
                                    $branch_franchise_name=$list->branch_name ?? $list->franchise_name ;
                                    @endphp
                                    <tr>
                                        <td>
                                                
                                                @if($list->branch_name)
                                                <label class="fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->branch_name }}">{{ $list->branch_name }}</label>
                                                <!-- <label class="fs-7 fw-semibold text-truncate max-w-80px" data-bs-toggle="tooltip" data-bs-placement="bottom" title=""></label> -->
                                                @elseif($list->franchise_name)
                                                <label class="fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->franchise_name }}">{{ $list->franchise_name }}</label>
                                                @endif
                                            
                                                @if($list->certificateIssued ==1 && $list->status == 4)
                                                <div class="d-block">
                                                        <span id="" class="d-block  badge text-black rounded fw-semibold fs-8 p-1  mt-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Certificate Issued" style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">Certificate Issued</span>
                                                    </div>
                                                @endif
                                        
                                        
                                        </td> 
                                        <td>
                                            <div>
                                                <label class="fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->event_name }}">{{ $list->event_name }}</label>
                                            </div>
                                            <div class="d-block">
                                                <label class="text-black border border-gray-400 rounded badge bg-label-warning fs-8 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Event Category">{{ $list->event_category_name }}</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">{{ $list->event_type_id }}</div>
                                            @if($list->event_offer !='free')
                                            <div class="d-block">
                                                <label class="text-black border border-gray-400 rounded badge bg-label-info fs-8 fw-semibold text-capitalize" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Event Offers">{{ $list->event_offer }}
                                                </label>
                                            </div>
                                            @endif
                                        </td>
                                        <!--<td align="right">-->
                                        <!--    <label class="badge {{$list->event_amount > 0 ? 'bg-danger text-white' : 'bg-success text-black'}} fs-8 rounded  fw-bold mb-2">-->
                                        <!--        <span class="mdi mdi-currency-rupee {{$list->event_amount > 0 ? 'text-white' : 'text-black'}}  fw-bold fs-8"></span>-->
                                        <!--        <span class="fs-7">{{ number_format($list->event_amount, 2) }}</span>-->
                                        <!--    </label>-->
                                        <!--</td>-->
                                        <td>
                                            <label class="text-truncate fs-7 fw-semibold max-w-100px @if($list->event_date < date('Y-m-d')) text-danger @else text-black @endif">{{ date('d-M-Y', strtotime($list->event_date)) }}</label>
                                            <div>
                                                @if($list->event_offer =='free')
                                                <label class="badge {{$list->event_amount > 0 ? 'bg-danger text-white' : 'bg-success text-black'}} fs-8 rounded  fw-bold mb-2">
                                                    <span class="fs-8">Free</span>
                                                </label>
                                                @else
                                                <label class="badge {{$list->event_amount > 0 ? 'bg-danger text-white' : 'bg-success text-black'}} fs-8 rounded  fw-bold mb-2">
                                                    <span class="mdi mdi-currency-rupee {{$list->event_amount > 0 ? 'text-white' : 'text-black'}}  fw-bold fs-8"></span>
                                                    <span class="fs-8">{{ number_format($list->event_amount, 2) }}</span>
                                                </label>
                                                @endif
                                            </div>
                                        </td>
                                        <td>
                                            <label class="text-truncate fs-7 fw-semibold max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Name">{{ $list->contact_person_name }}</label>
                                            <div class="d-block fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Mobile Number">{{ $list->contact_person_mob_no }}</div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold text-center text-black">{{ $list->no_of_participants?$list->no_of_participants:"Unlimited"  }}</div>
                                        </td>
                                        <td>
                                            @if($list->status == 0 && $list->event_date > date('Y-m-d'))
                                            <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Scheduled</a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <!--<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','1','Live','{{$list->event_category_name}}')">Live</a>-->
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','4','Completed','{{$list->event_category_name}}')">Completed</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','3','Cancelled','{{$list->event_category_name}}')">Cancelled</a>
                                            </div>
                                            @elseif(($list->status == 0 || $list->status == 1)  && $list->event_date < date('Y-m-d'))
                                                <div class="d-block">
                                                    <span id="" class="d-block boom badge rounded fw-semibold fs-8 px-2 py-1  mt-1 leadBoom bg-danger text-white cursor-pointer" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border:1px dashed white !important;">Completed ?</span>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','4','Completed','{{$list->event_category_name}}')">Completed</a>
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','3','Cancelled','{{$list->event_category_name}}')">Cancelled</a>
                                                    </div>
                                                </div>
                                            @elseif($list->status != 4 && $list->event_date == date('Y-m-d'))
                                            <a href="javascript:;" class="badge bg-info text-white rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Live</a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','4','Completed','{{$list->event_category_name}}')">Completed</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_live" onclick="confirmChangeStatus('{{ $list->sno }}','{{$list->event_name}}','3','Cancelled','{{$list->event_category_name}}')">Cancelled</a>
                                            </div>
                                            @elseif($list->status == 3)
                                            <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Cancelled</a>
                                            @elseif($list->status == 4 && $list->attendance_status == 0)
                                            
                                                <span  class="d-block boom badge rounded fw-semibold fs-8 px-2 py-1  mt-1 leadBoom bg-info text-white cursor-pointer" data-bs-toggle="modal" data-bs-target="#kt_modal_event_attendance"   style="border:1px dashed white !important;" onClick='eventAttendanceFunc({{ $list->sno }})'>Attendance </span>
                                            
                                            @elseif($list->status == 4 && $list->attendance_status == 1)
                                            <a href="javascript:;" class="badge bg-success text-black rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Completed</a>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                
                                                @if(($list->status != 4 && $list->status != 3) || $list->event_date == date('Y-m-d'))
                                                    @if($list->no_of_participants )
                                                        @if($list->no_of_participants == $list->applied_count)
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Add Participant', 'Manage Events'))
                                                                <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" >
                                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Participants Full">
                                                                        <i class="mdi mdi-account-multiple-plus fs-3 text-danger"></i>
                                                                         @if($list->applied_count > 0)
                                                                            <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                                {{ $list->applied_count }}
                                                                            </span>
                                                                            @endif
                                                                        </span>
                                                                </a>
                                                            @endif
                                                        @else
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Add Participant', 'Manage Events'))
                                                                <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" data-bs-toggle="modal" data-bs-target="#kt_modal_add_paticipants" onclick="add_particpant_func('{{$list->sno}}','{{$list->event_name}}','{{$list->event_date}}','{{$list->event_type_id}}','{{$list->event_category_name}}')">
                                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Participants">
                                                                        <i class="mdi mdi-account-multiple-plus fs-3 text-black"></i>
                                                                          @if($list->applied_count > 0)
                                                                            <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                                {{ $list->applied_count }}
                                                                            </span>
                                                                            @endif
                                                                        </span>
                                                                </a>
                                                            @endif
                                                        @endif
                                                    @else
                                                        @if(auth()->user()->hasPermission('Marketing Management', 'Add Participant', 'Manage Events'))
                                                            <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" data-bs-toggle="modal" data-bs-target="#kt_modal_add_paticipants" onclick="add_particpant_func('{{$list->sno}}','{{$list->event_name}}','{{$list->event_date}}','{{$list->event_type_id}}','{{$list->event_category_name}}')">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Participants">
                                                                    <i class="mdi mdi-account-multiple-plus fs-3 text-black"></i>
                                                                        @if($list->applied_count > 0)
                                                                        <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                            {{ $list->applied_count }}
                                                                        </span>
                                                                        @endif
                                                                    </span>
                                                            </a>
                                                        @endif
                                                    @endif
                                                @elseif($list->status == 3)
                                                        @if($list->applied_count > 0)
                                                        <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" data-bs-toggle="modal" data-bs-target="#kt_modal_transfer_paticipants" onclick="transfer_particpant_func('{{$list->sno}}','{{$list->event_name}}','{{$list->applied_count}}','{{$list->event_category_name}}')" >
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Transfer Participants" >
                                                                <i class="mdi mdi-account-switch fs-3 text-black"></i>
                                                                 @if($list->applied_count > 0)
                                                                <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                    {{ $list->applied_count }}
                                                                </span>
                                                                @endif
                                                            </span>
                                                        </a>
                                                        @else
                                                            <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" >
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Participants" >
                                                                    <i class="mdi mdi-account-multiple fs-3 text-black"></i>
                                                                    @if($list->applied_count > 0)
                                                                    <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                        {{ $list->applied_count }}
                                                                    </span>
                                                                    @endif
                                                                </span>
                                                            </a>
                                                        @endif
                                                @else
                                                    <a href="javascript:;" class="btn btn-icon btn-sm me-2 position-relative" >
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Participants" >
                                                            <i class="mdi mdi-account-multiple fs-3 text-black"></i>
                                                             @if($list->applied_count > 0)
                                                                <span class="badge bg-danger badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                    {{ $list->applied_count }}
                                                                </span>
                                                                @endif
                                                            </span>
                                                    </a>
                                            
                                                @endif
                                                    @if($list->status == 4 && $list->attendance_status == 1)
                                                        @if($list->certificateSendAll ==0)
                                                                @if(auth()->user()->hasPermission('Marketing Management', 'Send Whatsapp', 'Manage Events'))
                                                                    <a href="javascript:;" class="btn btn-icon btn-sm me-1 position-relative" data-bs-toggle="modal" data-bs-target="#kt_modal_send_bulk_certificate"  onClick='bulkSendCertificateFunc({{ $list->sno }})'>
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Send Certificate">
                                                                            <i class="mdi mdi-invoice-text-send fs-3 text-black"></i>
                                                                                @if( $list->attend_count > 0)
                                                                                <span class="badge bg-success badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                                    {{ $list->attend_count }}
                                                                                </span>
                                                                                @endif
                                                                            </span>
                                                                    </a>
                                                                @endif
                                                            @else
                                                                <a href="javascript:;" class="btn btn-icon btn-sm me-1 position-relative" data-bs-toggle="modal" data-bs-target="#kt_modal_view_bulk_certificate"  onClick='bulkViewCertificateFunc({{ $list->sno }})'>
                                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View">
                                                                        <i class="mdi mdi-invoice-text-check fs-3 text-success"></i>
                                                                        @if( $list->attend_count > 0)
                                                                        <span class="badge bg-success badge-pill position-absolute top-0 start-250 translate-middle animate__animated animate__pulse animate__infinite rounded-circle">
                                                                            {{ $list->attend_count }}
                                                                        </span>
                                                                        @endif
                                                                        </span>
                                                                </a>
                                                            @endif
                                                    @endif
                                                
                                                        
                                                
                                                <!-- <a href="#" target="_blank" class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2">
                                                    <i class="mdi mdi-clipboard-list-outline fs-4 text-black"></i>
                                                    <span class="badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle px-1 py-1 fs-9" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Event (Live)">Live</span>
                                                </a> -->
                                                <a class="btn btn-icon btn-sm p-0" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                </a>
                                                
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    @if($list->status != 4 && $list->status != 3)
                                                        <a href="javascript:;" class="dropdown-item generate-qr-btn" title="Generate QR" data-id="{{ $list->sno }}" data-eventname="{{$list->event_name}}" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_generate">
                                                            <i class="mdi mdi-qrcode-scan fs-3 text-black"></i>
                                                            <span>Download QR</span>
                                                        </a>
                                                        
                                                        <a href="javascript:;" class="dropdown-item generate-qr-btn" title="Download Poster" data-bs-toggle="modal" data-bs-target="#kt_modal_download_poster" onclick="openDownloadPoster({{ $list->sno }})">
                                                            <i class="mdi mdi-post fs-3 text-black"></i>
                                                            <span>Download Poster</span>
                                                        </a>
                                                    @endif
                                                        
                                                    @if(auth()->user()->hasPermission('Marketing Management', 'View', 'Manage Events'))
                                                    <a href="#" target="_blank" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_events" onClick='viewEvent({{ $list->sno }})'>
                                                        <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                        <span>View</span>
                                                    </a>
                                                    @endif
                                                
                                                        @if($list->eventScannerLatitudeCount > 0)
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Map View', 'Manage Events'))
                                                                <a href="javascript:;" onclick="MultiLocation('{{ $list->sno }}','{{ $list->event_name ?? '' }}')" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_multi_location_popup" class="dropdown-item"><span><i class="mdi mdi-map-marker-radius fs-3 text-black me-1"></i></span>Map View
                                                                
                                                                </a>
                                                            @endif
                                                        @endif
                                                        @if($list->eventScannerCount > 0)
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Scanner View', 'Manage Events'))
                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_scanner" onclick="ScannerModel({{$list->sno}},'{{$list->event_name}}','{{$branch_franchise_name}}')" >
                                                                    <span >
                                                                        <i class="mdi mdi-cog-counterclockwise fs-3 text-black"></i> Scanner View
                                                                    </span>
                                                                    
                                                                </a>
                                                            @endif
                                                        @endif
                                            
                                                    @if(auth()->user()->role_id == 1)
                                                        @if($list->event_date > date('Y-m-d') ||  $list->status == 0)
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Edit', 'Manage Events'))
                                                            <a href="{{ url('/events/event_edit/' . $encryptedValue) }}"
                                                                class="dropdown-item">
                                                                <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                <span>Edit</span>
                                                            </a>
                                                            @endif
                                                        @endif
                                                    @endif
                                                    @if(auth()->user()->role_id == 1)
                                                        @if($list->event_date > date('Y-m-d'))
                                                            @if(auth()->user()->hasPermission('Marketing Management', 'Delete', 'Manage Events'))
                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_event" onclick="confirmDelete('{{ $list->sno }}','{{ $list->event_name }}','{{ $list->event_category_name }}')">
                                                                    <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i></span>
                                                                    <span>Delete</span>
                                                                </a>
                                                            @endif
                                                        @endif
                                                    @endif
                                                </div>
                                            </span>
                                        </td>
                                    </tr>
                                    @endforeach
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="mt-4">
                    {{ $event_list->appends(request()->except(['page', '_token']))->links() }}
                </div>
            </div>
        </div>
    </div>
    

     <!--begin::Modal - Transfer Participants-->

    <div class="modal fade" id="kt_modal_transfer_paticipants" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="modal-dialog modal-md">
            <div class="modal-content rounded shadow-sm">
                <div class="modal-header justify-content-end border-0 pb-0">
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-dark fw-bold">Transfer Participant</h3>
                    </div>

                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="transfer_event_category">Seminar</label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="transfer_event_name">Advanced AI Technology</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-7 fw-semibold">Applied Count</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-7">
                            <span class="badge bg-info fs-7" id="transfer_applied_count">1</span>
                        </div>
                    </div>

                    <div class="row">
                        <input type="hidden" name="old_event_id" id="old_event_id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Transfer Event <span class="text-danger">*</span></label>
                            <select id="transfer_event_id" name="transfer_event_id" class="select3 form-select">
                                <option value="">Select Event</option>
                            </select>
                            <div class="text-danger" id="transfer_event_id_err"></div>
                            <div id="event-dropdown-status" class="text-status"></div>
                        </div>
                    </div>

                    <!-- Dynamic Event Details -->
                    <div id="transfer_event_datails"></div>

                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                        <button id="transferParticpntBtn" type="button" class="btn btn-primary px-5" onclick="transferParticipant()">Transfer</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--end::Modal - Transfer Participants-->
    <!--begin::Modal - View Scanner -->
    <div class="modal fade" id="kt_modal_view_scanner" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl" >
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                        <!--begin::Svg Icon-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </button>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
    
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">QR Event Scanner List</h3>
                    </div>
                    <!--end::Heading-->
                    <!--begin::Form-->
                        <div class="row">
                            <!-- Lead Name -->
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Qr Event Name </label>
                                <br><label id="qr_event_name_scan" class="text-dark mb-1 mt-2 fs-5 fw-bold" ></label>
                            </div>
    
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Branch / Franchise</label>
                                <br><label id="branchId_scan" class="text-dark mb-1 fs-5 fw-bold mt-2" ></label>
                            </div>
                      
                            
                         
                            <table class="mt-3 table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Date & Time</th>
                                        <th class="min-w-80px">Device</th>
                                        <th class="min-w-80px">Name</th>
                                        <th class="min-w-100px">Ip Address</th>
                                        <th class="min-w-100px">Latitude</th>
                                        <th class="min-w-100px">Longitude</th>
                                        <th class="min-w-100px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7" id="scanner_list_table_view">
                                    
                                </tbody>
                            </table>
                        </div>
                    <!--end::Form-->
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Scanner -->
    
    <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_qr_location_popup" id="map_modal">
<!--begin::Modal - Delete variable-->
<div class="modal fade" id="kt_modal_qr_location_popup" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg" >
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal" aria-label="Close">
                    <!--begin::Svg Icon-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </button>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->

            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="row" id="Map_view">
                
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete variable-->


<!--begin::Modal - Delete variable-->
<div class="modal fade" id="kt_modal_qr_multi_location_popup" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-center"><span id="docu_map" class="text-info"></span> Multiple Locations</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div id="multi_map" style="height:700px; width:100%;"></div>
            </div>
        </div>
    </div>
</div>

<!--end::Modal - Delete variable-->

<!--begin::Modal - QR Generated-->
<div class="modal fade" id="kt_modal_qr_generate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-md">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
              <h3 class="text-black mb-4">Generate Event QR</h3>
                <div id="qrcode" class="d-flex justify-content-center align-items-center " title="{{url('/interactive_audio_qr')}}">
                    <canvas width="256" height="256" style="display: none;"></canvas>
                    <img id="qrImage" src="{{ asset('assets/phdizone_images/payment_qr.png') }}" style="display:block;" class="p-2">
                </div>

              <div class="mb-1">
                  <label class="text-black fs-6 fw-semibold me-3" id="download_qr_code_name">{{url('/interactive_audio_qr')}}</label>
                    <a href="javascript:;" 
                       class="cpy-btn btn btn-sm btn-label-primary px-2 py-1" 
                       data-target="download_qr_code_name">
                       <i class="mdi mdi-content-copy fs-4 text-black"></i>
                    </a>
              </div>
          </div>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - QR Generated-->

    <!--begin::Modal - View Events-->
    <div class="modal fade" id="kt_modal_view_events" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">View Events
                            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold">Madurai Anna Nagar</label>
                            </div> -->
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_category_name">Seminar</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_event_name">Advanced AI Technology</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Mode</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_event_mode"> Offline</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Location URL</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7 text-black fs-7 fw-semibold">
                                    <div class="text-truncate max-w-75" id="view_location_url">
                                        <a href="https://www.google.com/maps/place/Elysium+Academy+%7C+Computer+Training+Institute+Madurai+%7C+Java+Course+%7C+Python+%7C+CCNA+%7C+Data+Science+%7C+Networking+%7C+Software/@9.9202938,78.1454081,17z/data=!3m1!4b1!4m20!1m13!4m12!1m4!2m2!1d78.1451264!2d9.928704!4e1!1m6!1m2!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!2selysium+academy!2m2!1d78.147983!2d9.9202885!3m5!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!8m2!3d9.9202885!4d78.147983!16s%2Fg%2F11cm77jd8g?entry=ttu" class="text-info fs-7 fw-bold">https://www.google.com/maps/place/Elysium+Academy+%7C+Computer+Training+Institute+Madurai+%7C+Java+Course+%7C+Python+%7C+CCNA+%7C+Data+Science+%7C+Networking+%7C+Software/@9.9202938,78.1454081,17z/data=!3m1!4b1!4m20!1m13!4m12!1m4!2m2!1d78.1451264!2d9.928704!4e1!1m6!1m2!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!2selysium+academy!2m2!1d78.147983!2d9.9202885!3m5!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!8m2!3d9.9202885!4d78.147983!16s%2Fg%2F11cm77jd8g?entry=ttu</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_event_address">227, IInd Floor, B Block, Elysium Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020, India</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Zoom Link</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7 text-black fs-7 fw-semibold">
                                    <div class="text-truncate max-w-75" id="view_zoom_link">
                                        <a href="https://www.google.com/maps/place/Elysium+Academy+%7C+Computer+Training+Institute+Madurai+%7C+Java+Course+%7C+Python+%7C+CCNA+%7C+Data+Science+%7C+Networking+%7C+Software/@9.9202938,78.1454081,17z/data=!3m1!4b1!4m20!1m13!4m12!1m4!2m2!1d78.1451264!2d9.928704!4e1!1m6!1m2!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!2selysium+academy!2m2!1d78.147983!2d9.9202885!3m5!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!8m2!3d9.9202885!4d78.147983!16s%2Fg%2F11cm77jd8g?entry=ttu" class="text-info fs-7 fw-bold">https://www.google.com/maps/place/Elysium+Academy+%7C+Computer+Training+Institute+Madurai+%7C+Java+Course+%7C+Python+%7C+CCNA+%7C+Data+Science+%7C+Networking+%7C+Software/@9.9202938,78.1454081,17z/data=!3m1!4b1!4m20!1m13!4m12!1m4!2m2!1d78.1451264!2d9.928704!4e1!1m6!1m2!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!2selysium+academy!2m2!1d78.147983!2d9.9202885!3m5!1s0x3b00c5aed85c27f7:0x604df1dd5fd43964!8m2!3d9.9202885!4d78.147983!16s%2Fg%2F11cm77jd8g?entry=ttu</a>
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_event_date">06-Jul-2024</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-12 text-dark fs-7 fw-semibold mb-2">Description</label>
                                <label class="col-12 text-black fs-7 fw-semibold" >&emsp;&emsp; <span id="view_event_description"></span> </label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Offer</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_event_offer">Paid</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Amount</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" >&#8377; <span id="view_event_amount"></span></label>
                            </div>
                            <!-- <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Coupon Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold">CODE-001</label>
                            </div> -->
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_participants">Limited</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">No of Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_no_of_participants">10</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Contact Person</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_contact_person_name">Daniel J</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Contact Person Mobile</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_contact_person_mob_no">9862457318</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Certificate</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_certificate">Yes</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Certificate Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_certificate_type">Hard Copy</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 std_list_page" id="studs_table">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                        <th class="min-w-150px">Participants</th>
                                        <th class="min-w-100px">Mobile No</th>
                                        <th class="min-w-100px">Alt. Mobile No</th>
                                        <th class="min-w-100px">Email ID</th>
                                        <th class="min-w-150px">Participants Type</th>
                                        <th class="min-w-175px">Participants Details</th>
                                        <th class="min-w-50px">Certificate</th>
                                        <!-- <th class="min-w-150px">Certificate Status</th> -->
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Events-->
    
     <!--begin::Modal - attendance  Events-->
    <div class="modal fade" id="kt_modal_event_attendance" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">Participant Attendance
                            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="attendance_category_name">Seminar</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="attendance_event_name">Advanced AI Technology</label>
                                <input type="hidden" id="attendance_event_id" />
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="attendance_participants">Limited</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">No of Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="attendance_no_of_participants">10</label>
                            </div>
                           
                        </div>
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 std_list_page" id="studs_table_event_attendance">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                        <th class="min-w-150px">Participants</th>
                                        <th class="min-w-100px">Mobile No</th>
                                        <th class="min-w-100px">Email ID</th>
                                        <th class="min-w-50px "><input type="checkbox" id="checkAll" class="form-check-input border-white" checked/> Attendance </th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-end my-1">
                            <button type="button" id="updateAttendanceBtn" class="btn btn-primary">Update Attendance</button>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - attendance  Events-->
    
    
     <!--begin::Modal - Send Certificate Events-->
    <!-- Modal for Sending Bulk Certificates -->
    <div class="modal fade" id="kt_modal_send_bulk_certificate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!-- Modal Dialog -->
    <div class="modal-dialog modal-xl">
        <!-- Modal Content -->
        <div class="modal-content rounded">
            <!-- Modal Header -->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!-- Close Button -->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <!-- Modal Body -->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!-- Heading -->
                <div class="mb-6">
                    <h3 class="text-center text-black">Send Certificate</h3>
                </div>
                 <div class="row">
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="send_ceriticate_category_name">Seminar</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="send_ceriticate_event_name">Advanced AI Technology</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="send_ceriticate_participants">Limited</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">No of Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="send_ceriticate_no_of_participants">10</label>
                            </div>
                           
                        </div>
                
                </div>
                <!-- Bulk Send Button Above Table -->
                <div class="d-flex justify-content-end mb-4">
                    <button id="bulkSendBtn" class="btn btn-primary">Send Certificates</button>
                </div>

                <!-- Table for Students -->
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 std_list_page" id="studs_table_send_ceriticate">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                <th class="min-w-150px">Participants</th>
                                <th class="min-w-100px">Mobile No</th>
                                <th class="min-w-100px">Alt. Mobile No</th>
                                <th class="min-w-100px">Email ID</th>
                                <th class="min-w-150px">Status</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            <!-- Student rows will be populated here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <!--end::Modal - Send Certificate Events-->
    
     <!--begin::Modal - Send Certificate Events-->
    <div class="modal fade" id="kt_modal_view_bulk_certificate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">View Certificates
                            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_ceriticate_category_name">Seminar</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_ceriticate_event_name">Advanced AI Technology</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_ceriticate_participants">Limited</label>
                            </div>
                            <div class="row mb-2">
                                <label class="col-4 text-dark fs-7 fw-semibold">No of Participants</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-7 fw-semibold" id="view_ceriticate_no_of_participants">10</label>
                            </div>
                           
                        </div>
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 std_list_page" id="studs_table_view_ceriticate">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                        <th class="min-w-150px">Participants</th>
                                        <th class="min-w-100px">Mobile No</th>
                                        <th class="min-w-100px">Alt. Mobile No</th>
                                        <th class="min-w-100px">Email ID</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px ">Download</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Send Certificate Events-->
    
        <!--begin::Modal - Lead syllabus document send-->
     <div class="modal fade" id="kt_modal_syllabus_document_send" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Send Event Certificate</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" id="lead_id_document" name="lead_id">
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Participant Name</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_document">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">participant Mobile</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_document">-</label>
                            </div>
                        </div>
                         <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">participant Email</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_mail_document">-</label>
                            </div>
                        </div>
                         <div class="col-lg-6 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Event Name</label>
                            <div>
                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_event_name_document">-</label>
                            </div>
                        </div>
                        
                        
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="sendCertificateBtn" onclick="sendCertificate_func()" class="btn btn-primary">Send Certificate</button>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead syllabus document send-->

    <!--begin::Modal - Add Participants-->
    <div class="modal fade" id="kt_modal_add_paticipants" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Add Participant</h3>
                    </div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event Category</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="add_part_event_category">Seminar</label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="add_part_event_name">Advanced AI Technology</label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="add_part_event_date">06-Jul-2024</label>
                    </div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-7 fw-semibold">Event Mode</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-7 fw-bold" id="add_part_event_mode">Offline</label>
                    </div>
                    <form id="addParticipantForm" action="{{ route('add_event_Participant') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="participant_event_id" id="add_part_event_id">
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Participant Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Participants Name" name="participant_name" id="participant_name"/>
                                <div class="text-danger" id="participant_name_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile No<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="participant_mobile" id="participant_mobile" placeholder="Enter Mobile No" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"  />
                                <div class="text-danger" id="participant_mobile_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile No</label>
                                <input type="text" class="form-control" name="participant_alter_mobile" id="participant_alter_mobile" placeholder="Enter Alternate Mobile No" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10"  />
                                <div class="text-danger" id="participant_alter_mobile_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email ID</label>
                                <input type="text" class="form-control" name="participant_email" id="participant_email" placeholder="Enter Email ID" oninput=" this.value = this.value.toLowerCase();"/>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Participant Type<span class="text-danger">*</span></label>
                                <select id="partpts_type" name="partpts_type" class="select3 form-select" onchange="participants_type_fun()">
                                    <option value="">Select Participant Type</option>
                                    <option value="Employee">Employee</option>
                                    <option value="Student">Student</option>
                                    <option value="Others">Others</option>
                                </select>
                                <div class="text-danger" id="partpts_type_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3" id="clg_tbox" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">College Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="participant_college" id="participant_college" placeholder="Enter College Name" />
                                <div class="text-danger" id="participant_college_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3" id="oths_tbox" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Others<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="participant_other_value" id="participant_other_value" placeholder="Enter Others Value" />
                                <div class="text-danger" id="participant_other_value_err"></div>
                            </div>
                            <!-- <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" placeholder="Enter Description"></textarea>
                            </div> -->
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-6">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button id="addParticpntBtn" type="button" class="btn btn-primary" onclick="addParticipant()">Add Participants</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Participants-->

    <!--begin::Modal - Live Interview Status-->
    <div class="modal fade" id="kt_modal_live" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                    <span id="status_message"></span>
                    <input type="hidden" name="status_event_id" id="status_event_id">
                    <input type="hidden" name="status_code" id="status_code">
                    <div class="d-block fw-bold fs-5 mt-2 py-2">
                        <label id="staus_event_name">Advanced AI Technology</label>
                        <span class="ms-2 me-2">-</span>
                        <label id="staus_event_category">Seminar</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal" onclick="statusUpdate()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Live Interview Status-->
    
    
    
    
    <!--begin::Modal - Poster Template-->
    <div class="modal fade" id="kt_modal_add_poster_template" tabindex="-1" aria-hidden="true"
  data-bs-keyboard="false" data-bs-backdrop="static">
  <div class="modal-dialog modal-lg">
    <div class="modal-content rounded">
      <div class="modal-header border-0 pb-0 justify-content-end">
        <button type="button" class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <i class="bi bi-x-lg fs-2"></i>
        </button>
      </div>
        <h3 class="text-center mb-4 text-black">Add Poster Template</h3>
      <div class="modal-body m-4">
       

        <form id="poster_template_form" action="{{ route('add_poster_template') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
          @csrf
          <div class="container-fluid">
            <div>
                <div class="col-12">
                    <label for="template_name" class="form-label fw-bold">Template Name <span class="text-danger">*</span></label>
                    <input id="template_name" name="template_name" class="form-control " placeholder="Enter Template name (eg. Exclusive Workshop)"/>
                     <div class="text-danger" id="template_name_err"></div>
                  </div>
            </div>
            <!-- Row 1: Poster Type + Upload -->
            <div class="row mb-4 align-items-center">
              <!-- Poster Type -->
              <div class="col-md-6">
                <label for="poster_type" class="form-label fw-bold">Poster Type<span class="text-danger">*</span></label>
                <select id="poster_type" name="poster_type" class="form-select select3" onchange="type_change()">
                  <option value="">Select Type</option>
                  <option value="1">Type 1</option>
                  <option value="2">Type 2</option>
                </select>
                 <div class="text-danger" id="poster_type_err"></div>
              </div>

              <!-- Upload Box -->
              <div class="col-md-6">
                <label class="form-label fw-bold">Poster Template Design<span class="text-danger">*</span></label>
                <div id="drop_zone"
                  class="border border-2 border-dashed rounded text-center bg-light d-flex align-items-center justify-content-center position-relative"
                  style="height:40px; cursor:pointer;">
                  <div id="upload_message" class="w-100">
                    <p class="mb-0 text-muted small">
                      <i class="mdi mdi-cloud-upload-outline text-primary me-1"></i>
                      Drag & Drop or Click to Upload
                    </p>
                  </div>
                  <input type="file" id="template_image" name="template_image" class="d-none" accept="image/*">
                </div>
                 <div class="text-danger" id="template_image_err"></div>
              </div>
            </div>

            <!-- Row 2: Preview Areas -->
            <div class="row">
              <!-- Poster Type Preview -->
              <div class="col-md-6 text-center">
                <label class="form-label fw-bold d-block">Preview (Poster Type)</label>
                <div id="poster_preview"
                  class="border rounded bg-white mx-auto d-flex align-items-center justify-content-center"
                  style="width:320px; height:440px; overflow:hidden; position:relative;">
                  
                  <div id="empty_preview" class="text-muted small ">No Type Selected</div>

                  <!-- Type 1 Layout -->
                  <div id="type1_ui" class="poster-type d-none"
                    style="font-size:9px; color:#000; width:100%; height:100%; background:#fff; display:flex; flex-direction:column; justify-content:space-between; padding:12px 10px;">
                      
                    <div style="text-align:center; flex-grow:1;">
                        <div class="px-4 fw-bold" style="padding-top:140px;">
                          <p style="margin:4px 0;">We are Excited to Announce Our Upcoming</p>
                          <p style="margin:4px 0;"> Workshop Titled</p>
                          <p style="margin:4px 0;">_______________________________________________________(46),</p>
                          <p style="margin:4px 0;">Conducted by _______________________________(30).The </p>
                          <p style="margin:4px 0;">Session will be Held On _________________(10)From</p>
                          <p style="margin:4px 0;"> ____________(10) To ____________(10).This____________(10)</p>
                          <p style="margin:4px 0;"> Workshop is Open to Participants from the</p>
                          <p style="margin:4px 0;">_________________________________(36) and Limited to</p>
                          <p style="margin:4px 0;"> _______(10) Attendees to Ensure an Engaging and</p>
                          <p style="margin:4px 0;">Intractive Experience. A Participation Certificate</p>
                          <p style="margin:4px 0;">will be Provided to All Attendees.</p>
                          <div style="text-align:center;">
                              <div class="fw-bold text-white rounded px-2 py-1 mx-auto"
                                style="font-size:6px; background:#1a237e; display:inline-block; margin-bottom:4px;">
                                ENTRY FEE :<span class="w-50px"></span>
                              </div>
                            </div>
                        </div>
                        
                        <div class=" d-flex justify-content-start ">
                            <div class="qr_container d-flex flex-column border" style="border-radius:2px;box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                                <div class="w-50px h-50px">
                                    
                                </div>
                                <div class="bg-black text-white px-2 fw-bold border-top-0" style="font-size:6px;" >Scan & Get<br>Started Now</div>
                            </div>
                        </div>
                    </div>
                  </div>

                  <!-- Type 2 Layout -->
                  <div id="type2_ui" class="poster-type d-none" style="font-size:9px; color:#000; width:100%; height:100%; background:#fff; display:flex; flex-direction:column; justify-content:space-between; padding:12px 10px;">
                    <div style="text-align:center; flex-grow:1;">
                        <div class="px-4  fw-bold" style="padding-top:140px;">
                          <p style="margin:4px 0;">We are Delighted to Announce Our Upcoming</p>
                          <p style="margin:4px 0;"> Workshop Titled</p>
                          <p style="margin:4px 0;">_________________________________________________________(46),</p>
                          <p style="margin:4px 0;">Presented by ________________________________(30).</p>
                          <p style="margin:4px 0;">The Session will be Conducted On _________________,(15)</p>
                          <p style="margin:4px 0;"> from ____________(10) To ____________(10),in</p>
                          <p style="margin:4px 0;"> ______________ Mode.</p>
                          <hr>
                          <p style="margin:4px 0;">This Workshop is Organized by</p>
                          <p style="margin:4px 0;">___________________________________(36) and the</p>
                          <p style="margin:4px 0;"> Number of participants Allocated is______________(10),</p>
                          <p style="margin:4px 0;">Providing a Valuable Opportunity to Learn and</p>
                          <p style="margin:4px 0;">Interact</p>
                        </div>
                        
                        <div style="position:absolute; bottom:8px; left:8px; display:flex; align-items:start; gap:8px;">
    
                                <!-- QR Box -->
                            <div class="qr_container border"
                              style="width:48px; height:60px; border-radius:3px; box-shadow:0 4px 8px rgba(0,0,0,0.25); overflow:hidden; display:flex; flex-direction:column;">
                              <div style="flex-grow:1;"></div>
                              <div class="bg-black text-white fw-bold text-center" style="font-size:6px; line-height:1.1; padding:2px 0;">
                                Scan & Get<br>Started Now
                              </div>
                            </div>
                        
                            <!-- Certificate + Entry Fee Boxes -->
                            <div style="display:flex; flex-direction:row; gap:6px; align-items:end;" class="mt-6">
                              <div style="display:flex; flex-direction:row; align-items:center;">
                                <div style="background:#0020ff; color:#fff; font-size:6px; text-align:center; width:45px; padding:2px 0;border-radius:2px 0px 0px 2px;">Certificate</div>
                                <div style="background:#c4c4c5; font-size:6px;text-align:center;width:45px;padding:2px 0;border-radius:0 2px 2px 0;">&nbsp;&nbsp;&nbsp;</div>
                              </div>
                              <div style="display:flex; flex-direction:row; align-items:center;">
                                <div style="background:#0020ff; color:#fff; font-size:6px; text-align:center; width:45px; padding:2px 0;border-radius:2px 0px 0px 2px;">Entry Fee</div>
                                <div style="background:#c4c4c5; font-size:6px;width:45px;text-align:center;padding:2px 0;border-radius:0 2px 2px 0;">&nbsp;&nbsp;&nbsp;</div>
                              </div>
                            </div>
                        
                          </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Uploaded Image Preview -->
              <div class="col-md-6 text-center">
                <div id="upload_preview" class="d-none ">
                  <label class="form-label fw-bold d-block">Preview Template</label>
                  <div class="position-relative border rounded bg-white mx-auto d-flex align-items-center justify-content-center"
                    style="width:320px; height:440px; overflow:hidden;">
                    <img id="upload_preview_img" src="" alt="Uploaded Poster Template"
                      class="rounded shadow-sm border" style="width:100%; height:100%; object-fit:cover;">
                    <button type="button" id="remove_upload"
                      class="btn btn-sm btn-danger position-absolute top-0 end-0 m-1 rounded-circle p-1"
                      style="width:22px; height:22px;">
                      <i class="mdi mdi-close fs-6"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <!-- Footer Buttons -->
          <div class="d-flex justify-content-end align-items-center mb-4 mt-4">
            <button type="button" class="btn btn-primary me-3" id="createPosterBtn" onclick="addValidateForm()">Add Poster Template</button>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
    <!--end::Modal - Poster Template-->
    
    <!--begin::Modal - Poster Template-->
   <!-- Modal: Download Event Poster -->
        <div class="modal fade" id="kt_modal_download_poster" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
          <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content rounded shadow-lg border-0">
        
              <!-- HEADER -->
              <div class="modal-header justify-content-center position-relative">
                <h5 class="modal-title fw-bold text-center w-100">Download Event Poster</h5>
                <button type="button" class="btn-close position-absolute end-0 me-3" data-bs-dismiss="modal"></button>
              </div>
        
              <!-- BODY -->
              <div class="modal-body">
                <div class="container-fluid">
        
                  <!-- Event Details -->
                  <div class="row g-3 mb-4 text-center">
                    <div class="col-md-3">
                      <span class="badge bg-primary">Event Name</span>
                      <div id="poster_event_name" class="fw-bold text-dark"></div>
                    </div>
                    <div class="col-md-3">
                      <span class="badge bg-success">Event Date</span>
                      <div id="poster_event_date" class="fw-bold text-dark"></div>
                    </div>
                    <div class="col-md-3">
                      <span class="badge bg-info">Event Time</span>
                      <div id="poster_event_time" class="fw-bold text-dark"></div>
                    </div>
                    <div class="col-md-3">
                      <span class="badge bg-warning text-dark">Event Offer</span>
                      <div id="poster_event_offer" class="fw-bold text-dark"></div>
                    </div>
                  </div>
        
                  <!-- Poster Type & Template Selection -->
                  <div class="row mb-4 g-3 align-items-start">
                    <!--<div class="col-md-6">-->
                    <!--  <label class="form-label fw-bold">Poster Type</label>-->
                    <!--  <select id="poster_type_download" class="form-select select3" onchange="fetchPosterTemplates(this.value)">-->
                    <!--    <option value="">Select Type</option>-->
                    <!--    <option value="1">Type 1</option>-->
                    <!--    <option value="2">Type 2</option>-->
                    <!--  </select>-->
                    <!--</div>-->
        
                    <div class="col-md-6">
                      <label class="form-label fw-bold">Poster Template</label>
                      <select id="poster_template_download" class="form-select select3" onchange="poster_template_change()">
                        <option value="">Select Template</option>
                      </select>
                    </div>
                    
                     <!-- Poster Preview -->
                    <div class="col-md-6">
                      <div class="d-flex justify-content-center mt-4">
                        <div id="poster_preview_container" class="position-relative" 
                             style="width:372px; height:526.2px; overflow:hidden; background-color:#f8f9fa;">
            
                          <!-- Base Poster Image -->
                          <img id="poster_preview_img" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover d-none" />
            
                          <!-- Dynamic Text Overlay -->
                          <div id="poster_text_overlay" class="position-absolute top-0 start-0 w-100 h-100 d-none"
                               style="font-family:'Poppins', sans-serif; color:#000;">
                          </div>
            
                          <div id="empty_preview_download" class="text-muted text-center small py-5">No Template Selected</div>
                        </div>
                      </div>
                    </div>
                    
                  </div>
        
                 
        
                </div>
              </div>
        
              <!-- FOOTER -->
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="downloadPosterBtn" onclick="downloadPoster()">Download Poster</button>
              </div>
        
            </div>
          </div>
        </div>
    <!--end::Modal - Poster Template-->

    <!--begin::Modal - Completed Interview Status-->
    <div class="modal fade" id="kt_modal_completed" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Change Completed Status ?
                    <div class="d-block fw-bold fs-5 mt-2 py-2">
                        <label>Advanced AI Technology</label>
                        <span class="ms-2 me-2">-</span>
                        <label>Seminar</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Completed Interview Status-->

    <!--begin::Modal - Cancelled Interview Status-->
    <div class="modal fade" id="kt_modal_cancelled" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to Change Cancelled Status ?
                    <div class="d-block fw-bold fs-5 mt-2 py-2">
                        <label>Advanced AI Technology</label>
                        <span class="ms-2 me-2">-</span>
                        <label>Seminar</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Cancelled Interview Status-->



    <!--begin::Modal - Active Event-->
    <div class="modal fade" id="kt_modal_active_event" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container active_message" id="swal2-html-container" style="display: block;">
                    <span id="active_message"></span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-primary me-3 eventActive" onclick="updateEventActive()"
                        data-bs-dismiss="modal">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -Active Event-->

     <!--begin::Modal - Drop Event-->
     <div class="modal fade" id="kt_modal_customer_drop" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
      <!--begin::Modal dialog-->
      <div class="modal-dialog modal-lg">
          <!--begin::Modal content-->
          <div class="modal-content rounded">
              <!--begin::Modal header-->
              <div class="modal-header justify-content-end border-0 pb-0">
                  <!--begin::Close-->
                  <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                      <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                      <span class="svg-icon svg-icon-1">
                          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                          </svg>
                      </span>
                      <!--end::Svg Icon-->
                  </div>
                  <!--end::Close-->
              </div>
              <!--end::Modal header-->
              <!--begin::Modal body-->
              <div class="modal-body pt-0 pb-6 px-10 px-xl-20">
                  <!--begin::Heading-->
                  <div class="mb-4 text-center">
                      <h3 class="text-center mb-4 text-black">Are You Sure Want to Drop Event?</h3>
                  </div>
                <form id="cus_drp_form" action="{{ route('event_drop') }}"  onsubmit="return confirmDrop()" method="POST" enctype="multipart/form-data" autocomplete="off">
                  @csrf
                  <div class="row mt-2">
                      <div class="row">
                          <input type="hidden" name="event_drop_sno" id="event_drop_sno">
                          <div class="w-100">
                              <div class="row ms-2 w-100">
                              <div class="col-lg-12 my-2 text-start">
                                  <div class="row">
                                      <label class="col-4 text-dark fs-6 fw-semibold">Event Name</label>
                                      <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                      <label class="col-7 text-black fs-6 fw-bold" id="drp_evnt_name"></label>
                                  </div>
                              </div>
                              <div class="col-lg-12 mb-2 text-start">
                                  <div class="row">
                                      <label class="col-4 text-dark fs-6 fw-semibold">Event Category</label>
                                      <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                      <label class="col-7 text-black fs-6 fw-bold" id="drp_evnt_category"></label>
                                  </div>
                              </div>
                              <div class="col-lg-12 mb-2 text-start">
                                  <div class="row">
                                      <label class="col-4 text-dark fs-6 fw-semibold">Event Type</label>
                                      <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                      <label class="col-7 fs-6 fw-bold text-capitalize" id="drp_evnt_type"></label>
                                  </div>
                              </div>
                              <div class="col-lg-12 mb-2 text-start">
                                  <div class="row">
                                      <label class="col-4 text-dark fs-6 fw-semibold">Event Date</label>
                                      <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                      <label class="col-7 text-black fs-7 fw-bold"><span class="fw-bold badge bg-success" id="drp_evnt_date"></span></label>
                                  </div>
                              </div>
                              <div class="col-lg-12 mb-2 text-start">
                                  <div class="row">
                                      <label class="col-4 text-dark fs-6 fw-semibold">Contact person</label>
                                      <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                      <label class="col-7 text-black fs-6 fw-bold" id="drp_cnt_per"></label>
                                  </div>
                              </div>
                            </div>
                            </div>

                          </div>
                          <div class="row">
                            <div class="col-lg-8 mb-2">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Drop Reason<span class="text-danger">*</span></label>
                              <textarea textarea class="form-control" rows="1" id="drp_reason" name="drp_reason" placeholder="Enter Drop Reason"></textarea>
                              <div class="text-danger" id="drp_reason_err"></div>
                            </div>
                          </div>

                  </div>


              </div>
              <!--end::Modal body-->
              <div class="d-flex justify-content-center align-items-center mb-4">
                  <button type="submit" class="btn btn-primary me-3" id="drp_button" >Yes</button>
                  <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
              </div>
            </form>
          </div>
          <!--end::Modal content-->
      </div>
      <!--end::Modal dialog-->
    </div>
 <!--end::Modal - Drop Event-->

    <!--begin::Modal - Delete Event-->
    <div class="modal fade" id="kt_modal_delete_event" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                    <span id="delete_message"></span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal"
                        onclick="deletelevel()">Yes, delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Event-->

    <!--begin::Modal - Generated Event Link-->
    <div class="modal fade" id="kt_modal_generated_event_link" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Generate Event Link</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark fs-6 fw-semibold mt-2">Attachment<span
                                    class="text-danger">*</span></label>
                            <div action="/upload" class="dropzone needsclick" id="dropzone-multi">
                                <div class="dz-message needsclick fs-6">
                                    <div class="text-center me-3">Drop files here or click to upload</div>
                                </div>
                                <div class="fallback">
                                    <input name="file" type="file" />
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">URL</label>
                            <input type="text" class="form-control" id="" placeholder=""
                                value="https://ui.elysium.academy/" readonly />
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Generate Event
                            Link</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Generated Event Link-->

    <div class="modal fade" id="kt_modal_view_events_old" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">View Events
                            <!-- <label class="me-4 badge bg-warning text-black rounded fw-bold fs-4">Email</label> -->
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mt-2">
                            <div class="row d-flex text-end">
                                <label class="col-12 text-white fs-6">
                                    <span class="badge bg-success text-black fw-bold" id="view_event_category"></span>
                                    <!-- <span class="text-danger fw-bold">06-Jul-2024</span> -->
                                </label>
                            </div>
                            <div class="row">
                                <label class="col-2 text-black fs-7 fw-semibold">
                                    <span class="mdi mdi-google-classroom fs-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Event Title"></span>
                                </label>
                                <label class="col-10 text-black fs-6 fw-bold">
                                    <span id="view_event_title"></span>
                                </label>
                            </div>
                            <div class="row">
                                <label class="col-2 text-black fs-7 fw-semibold">
                                    <span class="mdi mdi-desktop-classic fs-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Event Type"></span>
                                </label>
                                <label class="col-3 text-white fs-6 fw-bold">
                                    <span class="badge bg-info text-white fw-bold " id="view_event_type"></span>
                                </label>
                                <label class="col-4 text-end d-flex justify-content-center " data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Event Date">
                                    <span class="mdi mdi-calendar-range text-black fw-bold fs-4  "></span>
                                    <span class="badge text-danger fs-6 fw-bold " id="view_event_date"></span>
                                </label>
                                <label class="col-3 text-end evnt_amount"  >
                                    <span id="view_paid" style="display:none;">
                                      <span class="mdi mdi-currency-rupee text-black fw-bold"></span>
                                      <span class="text-black fs-6 fw-bold" id="view_event_amount" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Event Amount"></span>
                                    </span>
                                </label>
                            </div>
                            <!-- <div class="row d-flex text-end">                             <label class="col-12 text-white fs-7">
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            <span class="badge bg-info  fw-bold">Offline</span>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        </label>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    </div> -->
                            <div class="row loct_url_row">
                                <label class="col-2 text-black fs-7 fw-semibold">
                                    <span class="mdi mdi-map-marker-outline fs-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Location"></span>
                                </label>
                                <label class="col-10 text-black fs-6 fw-bold">
                                  <label class="text-truncate max-w-100" data-bs-toggle="tooltip"
                                  data-bs-placement="bottom" title="Event Location" id="view_event_location" ></label>
                            </div>
                            <div class="row address_row">
                                <label class="col-2 text-black fs-7 fw-semibold">
                                    <span class="mdi mdi-map-plus fs-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Address"></span>
                                </label>
                                <label class="col-10 text-black fs-6 fw-bold">
                                    <label class="text-truncate max-w-100" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Event Address" id="view_event_address">
                                    </label>
                                </label>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="row">
                                        <label class="col-4 text-black fs-7 fw-semibold">
                                            <span class="mdi mdi-account-outline fs-2" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Contact Person Name"></span>
                                        </label>
                                        <label class="col-8 text-black fs-6 fw-bold">
                                            <label class="text-truncate max-w-100" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Contact Person Name"
                                                id="view_contact_person"></label>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="row ">
                                        <label class="col-4 text-black fs-7 fw-semibold ">
                                            <span class="mdi mdi-phone-outline fs-4 " data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Contact Person Number"></span>
                                        </label>
                                        <label class="col-8 text-black fs-6 fw-bold ">
                                            <label class="text-truncate max-w-100" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Contact Person Number"
                                                id="view_contact_number"></label>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row certificate_row">
                                <label class="col-2 text-black fs-7 fw-semibold">
                                    <span class="mdi mdi-certificate-outline fs-2" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Certificate"></span>
                                </label>
                                <label class="col-10 text-black fs-6 fw-bold">
                                    <label class="" id="view_certificate_type"></label>
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View offerzone-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }


        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>


    <script>
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "pageLength": 25,
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <script>

        function viewEventOld(event) {
            const date = new Date(event.event_date);
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            const formattedDate =
                `${date.getUTCDate().toString().padStart(2, '0')}-${months[date.getUTCMonth()]}-${date.getUTCFullYear()}`;

            console.log(event)
            $('#view_event_category').text(event.event_category_name)
            $('#view_event_title').text(event.event_name)
            $('#view_event_type').text(event.event_type_id)
            $('#view_event_date').text(formattedDate)

            $('#view_contact_person').text(event.contact_person_name)
            $('#view_contact_number').text(event.contact_person_mob_no)

            var view_paid =document.getElementById('view_paid');

            if(event.event_offer=="free" || event.event_offer=="redeem"){
              view_paid.style.display="none";
            }
            else{
              view_paid.style.display="block";
              $('#view_event_amount').text(event.event_amount)
            }
            if(event.event_type_id=="Online"){
              $('#view_event_location').html("-")
              $('#view_event_address').text("-")
            }
            else{
              $('#view_event_location').text(event.location_url)
              $('#view_event_address').text(event.event_address)

            }
            if(event.certificate=="no"){
              $('#view_certificate_type').text("-")
            }
            else{
              $('#view_certificate_type').text(event.certificate_type)
            }
        }

        function updatelevelStatus(categoryId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state
            fetch(`/event_status/${categoryId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error updating Event status:', error);
                });
        }

        function confirmActive(id, name, active) {
            console.log("act bef set ", active)
            document.querySelector('#kt_modal_active_event .eventActive').setAttribute('data-id', id);
            document.querySelector('#kt_modal_active_event .eventActive').setAttribute('data-active', active);
             $('#active_message').html('Are you sure you want to Active <br> <b>' + name + '</b> Event ?');


        }


        function updateEventActive() {
            var eventId = document.querySelector('#kt_modal_active_event .eventActive').getAttribute('data-id');
            var activeStatus = document.querySelector('#kt_modal_active_event .eventActive').getAttribute('data-active');
            console.log("aft set", activeStatus)
            const status = activeStatus == 1 ? 0 : 1; // Set status
            fetch(`/active_event/${eventId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        active_Event: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        if (data.data === 1) {
                            toastr.success('Event Active Successfully!');
                        } else {
                            toastr.success('Event Deactive Successfully!');
                        }
                        setTimeout(() => {
                            window.location.reload();
                        }, 500);

                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error updating Event status:', error);
                });

        }

        function confirmDelete(id, name, ids) {

            document.querySelector('#kt_modal_delete_event .btn-danger').setAttribute('data-id', id);
            $('#delete_message').html('Are you sure you want to delete Event ?<br> <br> <b> ' + name + ' - ' + ids + '</b>');

        }

        function deletelevel() {
            var eventId = document.querySelector('#kt_modal_delete_event .btn-danger').getAttribute('data-id');
            fetch('/event-delete/' + eventId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success(data.message);
                        location.reload();
                    } else {
                        toastr.error(data.error_msg);
                    }
                })
                .catch(error => {

                });
        }
    </script>

<script>
    function participants_type_fun() {
        var partpts_type = document.getElementById("partpts_type").value;
        if (partpts_type == "Student") {
            document.getElementById("clg_tbox").style.display = "block";
            document.getElementById("oths_tbox").style.display = "none";
        } else if (partpts_type == "Others") {
            document.getElementById("clg_tbox").style.display = "none";
            document.getElementById("oths_tbox").style.display = "block";
        } else {
            document.getElementById("clg_tbox").style.display = "none";
            document.getElementById("oths_tbox").style.display = "none";
        }
    }
</script>

    <script>
     function event_drop(val){
      $('#event_drop_sno').val(val.sno);
      $('#drp_evnt_name').text(val.event_name);
      $('#drp_evnt_category').text(val.event_category_name);
      $('#drp_evnt_type').text(val.event_type_id);
      $('#drp_evnt_date').text(val.event_date);
      $('#drp_cnt_per').text(val.contact_person_name);
      }


      function confirmDrop() {
        var err =0;
        var drop_reason = $('#drp_reason').val();

          if (drop_reason == "") {
              $('#drp_reason_err').html('Drop Reason is required...!');
              err++;
          } else {
              $('#drp_reason_err').html('');
          }
        if (err > 0) {
              return false;
          } else {
           this.submit();
          }
        }
    </script>

    <!-- Thumbnail Image Upload Start : ADD -->
    <script>
        let thumb_img = document.getElementById('thumb_img');
        const fileInput_thumb_img = document.querySelector('.thumb_img_file-in'),
            resetFileInput_thumb_img = document.querySelector('.thumb_img_file-reset');

        if (thumb_img) {
            const resetImage = thumb_img.src;
            fileInput_thumb_img.onchange = () => {
                if (fileInput_thumb_img.files[0]) {
                    thumb_img.src = window.URL.createObjectURL(fileInput_thumb_img.files[0]);
                }
            };
            resetFileInput_thumb_img.onclick = () => {
                fileInput_thumb_img.value = '';
                thumb_img.src = resetImage;
            };
        }
    </script>
    <!-- Thumbnail Image Upload End : ADD -->
    <!-- Attachment(pdf) File Upload Start : ADD -->
    <script>
        let attach_upload = document.getElementById('attach_upload');
        const attach_upload_fileInput = document.querySelector('.attach_upload_cls'),
            attach_upload_resetFileInput = document.querySelector('.attach_upload-reset');

        if (attach_upload) {
            const fav_resetImage = attach_upload.src;
            attach_upload_fileInput.onchange = () => {
                if (attach_upload_fileInput.files[0]) {
                    attach_upload.src = window.URL.createObjectURL(attach_upload_fileInput.files[0]);
                }
            };
            attach_upload_resetFileInput.onclick = () => {
                attach_upload_fileInput.value = '';
                attach_upload.src = fav_resetImage;
            };
        }
    </script>
    <!-- Attachment(pdf) File Upload End : ADD -->

    <!-- Thumbnail Image Upload Start : Update -->
    <script>
        let thumb_img_edit = document.getElementById('thumb_img_edit');
        const fileInput_thumb_img_edit = document.querySelector('.thumb_img_edit_file-in'),
            resetFileInput_thumb_img_edit = document.querySelector('.thumb_img_edit_file-reset');

        if (thumb_img_edit) {
            const resetImage = thumb_img_edit.src;
            fileInput_thumb_img_edit.onchange = () => {
                if (fileInput_thumb_img_edit.files[0]) {
                    thumb_img_edit.src = window.URL.createObjectURL(fileInput_thumb_img_edit.files[0]);
                }
            };
            resetFileInput_thumb_img_edit.onclick = () => {
                fileInput_thumb_img_edit.value = '';
                thumb_img_edit.src = resetImage;
            };
        }
    </script>
    <!-- Thumbnail Image Upload End : Update -->
    <!-- Attachment(pdf) File Upload Start : Update -->
    <script>
        let attach_upload_edit = document.getElementById('attach_upload_edit');
        const attach_upload_edit_fileInput = document.querySelector('.attach_upload_edit_cls'),
            attach_upload_edit_resetFileInput = document.querySelector('.attach_upload_edit-reset');

        if (attach_upload_edit) {
            const fav_resetImage = attach_upload_edit.src;
            attach_upload_edit_fileInput.onchange = () => {
                if (attach_upload_edit_fileInput.files[0]) {
                    attach_upload_edit.src = window.URL.createObjectURL(attach_upload_edit_fileInput.files[0]);
                }
            };
            attach_upload_edit_resetFileInput.onclick = () => {
                attach_upload_edit_fileInput.value = '';
                attach_upload_edit.src = fav_resetImage;
            };
        }
    </script>
    <!-- Attachment(pdf) File Upload End : Update -->
    <script>
      function exportToExcel() {
        // Replace with your server endpoint for exporting to Excel
        let url = '/events/event-excel';

        // Example AJAX call to trigger export
        $.ajax({
            url: url,
            type: 'GET',
            success: function(response) {
                // Handle success, such as downloading the file
                window.location.href = url; // Redirect to download link
            },
            error: function(xhr, status, error) {
                // Handle errors
                console.error('Error exporting to Excel:', error);
            }
        });
    }
    $('#export_event_excel').on('click', function(e) {
        e.preventDefault();
        exportToExcel();
    });
    </script>
    <script>
      // Check if 'filter_on' session variable is set and trigger click event
      $(document).ready(function() {
              @if ($filter_on ?? '')
                  $('.filter_tbox').slideToggle('fast');
                  // });
              @endif
          });

          // Toggle branch filter section
          $('#filter_student').click(function() {
              $('.filter_tbox').slideToggle('slow');
          });

          document.getElementById('filter_form').onsubmit = function() {
              this.querySelector('button[type="submit"]').disabled = true;
          };
          function branch_filter_func() {
              var branch_id=$('#branch_filter').val();
              $('#branch_fill').val(branch_id);
              $('#branch_form').submit();
        
          }
    </script>
    <script>
    function formatDate(dateString) {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');  // Ensures day is 2 digits (e.g., '02')
        const month = date.toLocaleString('default', { month: 'short' });  // Abbreviated month (e.g., 'Nov')
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }
</script>

    <script>
        function add_particpant_func(id,eventName,eventDate,eventMode,eventCategory){
            $('#add_part_event_id').val(id)
            $('#add_part_event_category').text(eventCategory)
            $('#add_part_event_name').text(eventName)
            $('#add_part_event_date').text(formatDate(eventDate))
            $('#add_part_event_mode').text(eventMode)
        }
    </script>

<script>
    function addParticipant(){
        $("#addParticpntBtn").prop('disabled', true);
        
            var participant_name = $('#participant_name').val();
            var participant_mobile = $('#participant_mobile').val();
            var partpts_type = $('#partpts_type').val();
            var participant_college = $('#participant_college').val();
            var participant_other_value = $('#participant_other_value').val();
            
            // Clear previous errors
            $('#participant_name_err').text('');
            $('#participant_mobile_err').text('');
            $('#partpts_type_err').text('');
            $('#participant_college_err').text('');
            $('#participant_other_value_err').text('');

            let err = false;

            if (participant_name === '') {
                $('#participant_name_err').text('Participant Name is Required.');
                err = true;
            }
            if (participant_mobile === '') {
                $('#participant_mobile_err').text('Mobile No is Required.');
                err = true;
            }
            if (partpts_type === '') {
                $('#partpts_type_err').text('Participant Type is Required.');
                err = true;
            }
            if(partpts_type === 'Student'){
                if (participant_college === '') {
                    $('#participant_college_err').text('College Name or School is Required.');
                    err = true;
                }
            }else if(partpts_type === 'Others'){
                if (participant_other_value === '') {
                    $('#participant_other_value_err').text('Other Value is Required.');
                    err = true;
                }
            }
                
                    
        
            if (err) {
                $("#addParticpntBtn").prop('disabled', false);
                return false;
            }
            else{
                $("#addParticpntBtn").prop('disabled', true);
                // return false;
                $('#addParticipantForm').submit();
            }

    }
</script>

<script>
     function viewEvent(event_id) {
        $.ajax({
            url: '/view_event/' + event_id, // URL to your route
            type: 'GET',
            success: function(response) {
                if(response.success) {
                      $("#view_category_name").text(response.data.event_category_name);
                      $('#view_event_name').text(response.data.event_name);
                      $('#view_event_offer').text(response.data.event_offer);
                      $('#view_event_amount').text(response.data.event_amount);
                      $('#view_participants').text(
                            response.data.participants === 'Limited' 
                            ? response.data.participants + ' (' + response.data.no_of_participants + ')'
                            : response.data.participants
                        );
                      $('#view_no_of_participants').text(response.data.applied_count || '0');

                      $('#view_event_mode').text(response.data.event_type_id);

                      $('#view_event_address').text(response.data.event_address ? response.data.event_address : '-');
                     { response.data.location_url ? 
                      $('#view_location_url').html('<a href="' + response.data.location_url + '" class="text-info fw-bold fs-7" target="_blank">' + response.data.location_url + '</a>')
                      : $('#view_location_url').text('-') }

                      { response.data.zoom_link ? 
                      $('#view_zoom_link').html('<a href="' + response.data.zoom_link + '" class="text-info fw-bold fs-7" target="_blank">' + response.data.zoom_link + '</a>')
                      : $('#view_zoom_link').text('-') }
                     
                      $('#view_contact_person_name').text(response.data.contact_person_name);
                      $('#view_contact_person_mob_no').text(response.data.contact_person_mob_no);
                      $('#view_certificate').text(response.data.certificate);
                      $('#view_certificate_type').text(response.data.certificate_type);
                      $('#view_event_date').text(formatDate(response.data.event_date));
                      $('#view_event_description').text(response.data.event_description ? response.data.event_description  : '-');

                       // Populate student table data (assuming an array of students)
                    let studentTableBody = $('#kt_modal_view_events').find('#studs_table tbody');
                    studentTableBody.empty();
                    response.data.student_list.forEach(function(student, index) {
                        let student_intrv_status= student.status == '1'? 'On Progress' :(student.status == '3'? 'Rejected' :(student.status == '4'? 'Selected' :'Select Status'))
                        let student_intrv_color= student.status == '1'? 'bg-info text-white' :(student.status == '3'? 'bg-danger text-white' :(student.status == '4'? 'bg-success text-black' :'bg-secondary text-white'))
                        let encryptedValue = student.encrypted_sno;
                        let printValue = student.encrypted_index;
                          var user_id = {{auth()->user()->role_id}};
                        let studentRow = `
                                    <tr>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.participant_name}</div>
                                        </td>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.mobile_no}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7">${student.alter_mobile_no || "-"}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7">${student.participant_email || '-'}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7">${student.participant_type || '-'}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black  fs-7">${student.college_name || student.other_value || '-' }</div>
                                        </td>
                                        <td class="text-center text-black fw-semibold fs-3">
                                            ${response.data.status === 4 ?
                                                (student.certificate_status === 1 || student.email_send === 1 ? 
                                                    `<span class="mdi mdi-check-circle text-success"></span>` : 
                                                    `<span class="mdi mdi-close-circle text-danger"></span>`) 
                                                : '-'
                                            }
                                            ${response.data.status === 4 ?
                                                ((student.certificate_status === 1 || student.email_send === 1) && student.download_status === 0 ? 
                                                    `<a href="${student.certificate_link}" class="" >
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Download Certificate">
                                                                 <i class="ms-1 mdi mdi-download-circle-outline cursor-pointer text-black"></i>
                                                            </span>
                                                        </a>` : 
                                                    `<span class="ms-1 mdi mdi-download-off"></span>`) 
                                                : ''
                                            }
                                        </td>
                                       
                                    </tr>
                                `;
                        studentTableBody.append(studentRow);
                    });

                     $(".std_list_page").DataTable({
                    "ordering": false,
                    "paging": false,
                    "language": {
                        "lengthMenu": "Show _MENU_",
                    },
                    "dom": "<'row mb-3'" +
                        "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                        ">" +
                        "<'table-responsive'tr>" +
                        "<'row'" +
                        "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                        ">" 
                });

                // Wrap the table in a scrollable container
                $('.std_list_page').wrap('<div class="dataTables_scroll" />');
                    
                } else {
                    console.error('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Error fetching company data:', error);
                console.error('An error occurred while fetching the company data.');
            }
        });
    }
</script>

<script>

    // function confirmChangeStatus(id, event_name,status,status_name,category_name) {
    //   $('#status_event_id').val(id)
    //   $('#status_code').val(status)
    //   $('#staus_event_name').text(event_name)
    //   $('#staus_event_category').text(category_name)
    //   $('#status_message').html('Are you sure you want to Change ' + status_name + ' Status  ?');
    // }
    
    function confirmChangeStatus(id, event_name, status, status_name, category_name) {
        $('#status_event_id').val(id);
        $('#status_code').val(status);
        $('#staus_event_name').text(event_name);
        $('#staus_event_category').text(category_name);
    
        // Default message
        let message = 'Are you sure you want to Change ' + status_name + ' Status ?';
    
        // If status_name is Completed, show warning
        if (status_name.toLowerCase() === "completed") {
            message += `<div class="alert alert-warning mt-3" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <strong>Important:</strong> <span class="text-danger">Once the event is marked as </span><span class="text-danger fw-bold">Completed ,</span>
                            <span class="text-danger">you will not be able to add participant details.</span>
                        </div>`;
        }
    
        $('#status_message').html(message);
    }


    function statusUpdate() {
        var eventId = $('#status_event_id').val();
        var status =  $('#status_code').val();
        fetch('/event_status_update/' + eventId, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                },
                body: JSON.stringify({
                    status: status
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                }
            })
            .catch(error => {
            toastr.error("Could not Update Event Status");
            });
    }
  
</script>

<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#acc_daily_acc_week_st_dt_fill').val(firstday);
            $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>
  
 
  <script>
       function sendEventCertificate(leadId,name,mobile,email,event_name) {
        $('#lead_name_document').html(name);
        $('#lead_phone_document').html(mobile || '-');
        $('#lead_email_document').html(email || '-');
        $('#lead_event_name_document').html(event_name || '-');
        $('#lead_id_document').val(leadId); // Set the lead ID in the hidden input field
        $('#kt_modal_syllabus_document_send').modal('show'); // Show the modal
    }

    function sendCertificate_func(){
        $('#sendCertificateBtn').prop('disabled', true);
        var err=0;

        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const lead_id = $('#lead_id_document').val();
        

        if(err==0){
            $('#sendCertificateBtn').prop('disabled', true);
            $.ajax({
                url: '/send_event_certificate',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    lead_id: lead_id,
                    
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        console.log(response)
                        $('#sendCertificateBtn').prop('disabled', true);
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                        $('#sendCertificateBtn').prop('disabled', false);
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                    $('#sendCertificateBtn').prop('disabled', false);
                }
            });
            
        }else{
            $('#sendCertificateBtn').prop('disabled', false);
            return false;
        }

        
    }
  </script>
  
  <!--send Certificate-->
<script>
var students = [];

function bulkSendCertificateFunc(event_id) {
    students = [];
    $.ajax({
        url: '/view_event_updated/' + event_id,
        type: 'GET',
        success: function(response) {
            if (response.success) {
                // Set Event Data
                $("#send_ceriticate_category_name").text(response.data.event_category_name);
                $('#send_ceriticate_event_name').text(response.data.event_name);
                $('#send_ceriticate_participants').text(
                            response.data.participants === 'Limited' 
                            ? response.data.participants + ' (' + response.data.no_of_participants + ')'
                            : response.data.participants
                        );
                $('#send_ceriticate_no_of_participants').text(response.data.applied_count || '0');
                
                // Empty the student table and repopulate it
                let studentTableBody = $('#kt_modal_send_bulk_certificate').find('#studs_table_send_ceriticate tbody');
                studentTableBody.empty();

                response.data.student_list.forEach(function(student) {
                    let cert_status =student.certificate_status == 1 ?'Sent':'Pending';
                    let studentRow = `
                        <tr data-student-id="${student.sno}">
                            <td><div class="text-black fw-semibold fs-7">${student.participant_name}</div></td>
                            <td><div class="text-black fw-semibold fs-7">${student.mobile_no}</div></td>
                            <td><div class="fw-semibold text-black fs-7">${student.alter_mobile_no || "-"}</div></td>
                            <td><div class="fw-semibold text-black fs-7">${student.participant_email || '-'}</div></td>
                            <td class="status-column">
                                <div class="fw-semibold text-black fs-7 status">${cert_status} ${student.certificate_status == 1 ? `<span class="mdi mdi-whatsapp text-success"></span>` :''}</div>
                                <div class="progress-container " style="display: none;">
                                    <div class="progress-bar"></div>
                                    <span class="sending-text">Sending...</span>
                                </div>
                            </td>
                        </tr>
                    `;
                    studentTableBody.append(studentRow);
                    students.push(student); // Store student data for bulk sending
                });

                $(".std_list_page").DataTable({
                    "ordering": false,
                    "paging": false,
                    "language": {
                        "lengthMenu": "Show _MENU_",
                    },
                    "dom": "<'row mb-3'<'col-sm-12 d-flex align-items-center justify-content-end'f>>" +
                        "<'table-responsive'tr>" +
                        "<'row'<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>>"
                });
            } else {
                console.error('Error: ' + response.message);
            }
        },
        error: function(xhr, status, error) {
            console.log('Error fetching event data:', error);
            console.error('An error occurred while fetching the event data.');
        }
    });
}

$('#bulkSendBtn').off('click').on('click', function() {
    startBulkSend(students);
});

function startBulkSend(students) {
    $('#bulkSendBtn').prop('disabled', true).text('Sending...');
    let currentIndex = 0;

    function sendNextStudent() {
        if (currentIndex >= students.length) {
            $('#bulkSendBtn').prop('disabled', false).text('Send Certificates');
             setTimeout(function() {
                location.reload();  // This will refresh the page
            }, 500);
            return;
        }

        let student = students[currentIndex];
        
         if (student.certificate_status === 1) {
            updateStatusInTable(student.sno, 'Sent');  
            currentIndex++; 
            sendNextStudent(); 
            return;  
        }

        // Show progress bar for this student
        let row = $('#studs_table_send_ceriticate tbody tr').filter(function() {
            return $(this).data('student-id') == student.sno;
        });
        let progressBarContainer = row.find('.progress-container');
        let progressBar = progressBarContainer.find('.progress-bar');
        let sendingText = progressBarContainer.find('.sending-text');

        // Show the progress bar and "Sending..." text
        progressBarContainer.show();
        progressBar.css('width', '0%');
        progressBar.removeClass('success failure warning'); // Reset color classes
        sendingText.show(); // Show "Sending..." text

        // Hide the "Pending" text
        row.find('.status').hide();

        // Animate progress bar from 0% to 90%
        let width = 0;
        let interval = setInterval(function() {
            if (width >= 90) {
                clearInterval(interval); // Stop animation at 90%
            }
            width += 5; // Increase width by 5% each step
            progressBar.css('width', Math.min(width, 90) + '%'); // Stop at 90%

            // Change color based on width
            if (width < 50) {
                progressBar.removeClass('warning success').addClass('failure'); // Red (0-50%)
            } else if (width < 90) {
                progressBar.removeClass('failure success').addClass('warning'); // Yellow (50-90%)
            }
        }, 100); // Adjust the speed of progress animation (100ms for each increment)
        var sent_status ='Pending';
        // Simulate sending process with AJAX request
        $.ajax({
            url: '/send_event_certificate',
            method: 'POST',
            data: {
                lead_id: student.sno,  // Send student ID
                _token: '{{ csrf_token() }}'  // CSRF token for security
            },
            success: function(response) {
                sent_status=response.certificate_status ==1 ? 'Sent' : (response.certificate_status == 0 ? 'Failed' :'Failed');
                if (response.status === 200) {
                    
                    // Success: Update color to green and hide the progress bar
                    updateStatusInTable(student.sno, sent_status);
                    progressBar.css('width', '100%').addClass('success');
                } else {
                    // Failure: Update color to red and hide the progress bar
                    updateStatusInTable(student.sno, sent_status);
                    progressBar.css('width', '100%').addClass('failure');
                }
                // After success or failure, hide the progress bar and "Sending..." text
                setTimeout(function() {
                    progressBarContainer.hide();
                }, 500); // 500ms delay before hiding the progress bar
                currentIndex++;
                sendNextStudent();  // Recursively send next student
            },
            error: function() {
                // Failure: Update status to Failed and color to red
                updateStatusInTable(student.sno, 'Failed');
                progressBar.css('width', '100%').addClass('failure');
                // After failure, hide the progress bar and "Sending..." text
                setTimeout(function() {
                    progressBarContainer.hide();
                }, 500); // 500ms delay before hiding the progress bar
                currentIndex++;
                sendNextStudent();  // Continue to next student
            }
        });
    }

    // Start sending the first student
    sendNextStudent();
}

function updateStatusInTable(studentSno, status) {
    let row = $('#studs_table_send_ceriticate tbody tr').filter(function() {
        return $(this).data('student-id') == studentSno;
    });

    let progressBarContainer = row.find('.progress-container');
    let statusElement = row.find('.status');

    if (status === 'In Progress') {
        statusElement.hide();
        progressBarContainer.show();
    } 
    else if(status === 'Sent') {
        statusElement.html('Sent <span class="mdi mdi-whatsapp text-success"></span>').show();
        progressBarContainer.hide();
    }else if(status === 'Failed') {
        statusElement.html('Failed <span class="mdi mdi-close text-danger"></span>').show();
        progressBarContainer.hide();
    } else {
        statusElement.text(status).show();
        progressBarContainer.hide();
    }
}


</script>
  
  <!--view Certificate-->
  <script>
       function bulkViewCertificateFunc(event_id) {
        $.ajax({
            url: '/view_event_updated/' + event_id, // URL to your route
            type: 'GET',
            success: function(response) {
                if(response.success) {
                      $("#view_ceriticate_category_name").text(response.data.event_category_name);
                      $('#view_ceriticate_event_name').text(response.data.event_name);
                    $('#view_ceriticate_participants').text(
                            response.data.participants === 'Limited' 
                            ? response.data.participants + ' (' + response.data.no_of_participants + ')'
                            : response.data.participants
                        );
                      $('#view_ceriticate_no_of_participants').text(response.data.applied_count || '0');

                     

                       // Populate student table data (assuming an array of students)
                    let studentTableBody = $('#kt_modal_view_bulk_certificate').find('#studs_table_view_ceriticate tbody');
                    studentTableBody.empty();
                    response.data.student_list.forEach(function(student, index) {
                         let cert_status =student.certificate_status == 1 ?'Sent':'Pending';
                        let student_intrv_status= student.status == '1'? 'On Progress' :(student.status == '3'? 'Rejected' :(student.status == '4'? 'Selected' :'Select Status'))
                        let student_intrv_color= student.status == '1'? 'bg-info text-white' :(student.status == '3'? 'bg-danger text-white' :(student.status == '4'? 'bg-success text-black' :'bg-secondary text-white'))
                        let encryptedValue = student.encrypted_sno;
                        let printValue = student.encrypted_index;
                          var user_id = {{auth()->user()->role_id}};
                        let studentRow = `
                                    <tr>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.participant_name}</div>
                                        </td>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.mobile_no}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7">${student.alter_mobile_no || "-"}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${student.participant_email || '-'}">${student.participant_email || '-'}</div>
                                        </td>
                                       
                                        <td class="text-center text-black fw-semibold fs-3">
                                           
                                          <div class="fw-semibold text-black fs-7 status">${cert_status} ${student.certificate_status == 1 ? `<span class="mdi mdi-whatsapp text-success"></span>` :''}</div>
                                          
                                        </td>
                                         <td class="text-start text-black fw-semibold fs-3">
                                           
                                          <div class="fw-semibold text-black fs-7 ">${student.download_status == 1 ? `<span class="mdi mdi-check-decagram fs-3 font-bold text-success"></span> Downloaded ` :'<span class="mdi mdi-close-thick fs-3 font-bold text-danger"></span> Not Yet Download'}</div>
                                          
                                        </td>
                                       
                                    </tr>
                                `;
                        studentTableBody.append(studentRow);
                    });

                    $(".std_list_page").DataTable({
                        "ordering": false,
                        "paging": false,
                        "language": {
                        "lengthMenu": "Show _MENU_",
                        },
                        "dom": "<'row mb-3'" +
                        "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                        ">" +
                        "<'table-responsive'tr>" +
                        "<'row'" +
                        "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                        ">" 
                    });

                    $('.std_list_page').wrap('<div class="dataTables_scroll" />');
                    
                } else {
                    console.error('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Error fetching company data:', error);
                console.error('An error occurred while fetching the company data.');
            }
        });
    }
  </script>
  <!--qr view-->
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('[data-bs-target="#kt_modal_qr_generate"]').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            const event_name = this.getAttribute('data-eventname');

            fetch(`/gen_event_qr/${id}/generate-qr`)
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        const qrImage = document.getElementById('qrImage');
                        qrImage.src = data.qr_base64;
                        qrImage.style.display = "block";
            
                        document.querySelector('#download_qr_code_name').textContent = data.link;
                        
                        setTimeout(() => {
                            if (data.qr_base64) {
                              const dataUrl = data.qr_base64 || "";
                              const link = document.createElement("a");
                              link.href = dataUrl;
                              link.download = event_name+"-qr-code.png";
                              link.click();
                            }
                          }, 500);
                    } else {
                        console.error("QR generation failed");
                    }
                })
                .catch(err => console.error(err));

        });
    });
});


// scnner view
  function ScannerModel(id,event,branch) {
             $('#qr_event_name_scan').text('');
             $('#branchId_scan').text('');
             $('#qr_event_name_scan').text(event);
             $('#branchId_scan').text(branch);
                $.ajax({
                    url: "{{ route('qr.scanner.event') }}",
                    method: "GET",
                    data: {
                        sno: id
                    },
                    beforeSend: function () {
                        $('#scanner_list_table_view').html('<tr><td colspan="7" class="text-center">Loading...</td></tr>');
                    },
                    success: function (response) {
                        if (response) {
                        $('#scanner_list_table_view').html(response);
                        } else {
                            $('#scanner_list_table_view').html('<tr><td colspan="7" class="text-center">No Record found</td></tr>');
                        }
                        // $('[data-bs-toggle="tooltip"]').tooltip();
                    },
                    error: function (xhr) {
                        console.error(xhr.responseText);
                    }
                });
        }

</script>
<script>
function ViewLocation(ip, lat, long) {
    if (lat && long) { // check if lat and long exist
        // Show the modal
        const mapModal = new bootstrap.Modal(document.getElementById('kt_modal_qr_location_popup'), {
            backdrop: 'static',
            keyboard: false
        });
        mapModal.show();

        // Insert a satellite map iframe inside the modal
        const modalContent = document.getElementById('Map_view');
        modalContent.innerHTML = `
            <div class="mb-4 text-center">
                <h3 class="text-center text-danger fs-5 fw-bold mb-4">IP Address: ${ip}</h3>
            </div>
            <iframe
                width="100%"
                height="400"
                style="border:0"
                loading="lazy"
                allowfullscreen
                src="https://maps.google.com/maps?q=${lat},${long}&t=k&z=15&output=embed">
            </iframe>
           
        `;
    }
}
</script>
<script>
    function MultiLocation(id, name) {
    $('#docu_map').html(name);
    $.ajax({
        url: "{{ route('qr.scanner.event.map') }}",
        method: "GET",
        data: { sno: id },
        beforeSend: function () {
            $('#multi_map').html('Loading map...');
        },
        success: function (locations) {
            if (locations.length > 0) {
                $('#multi_map').html('<div id="map" style="height:700px; width:100%;"></div>');

                const firstLoc = locations[0];
                const map = L.map('map').setView([firstLoc.latitude, firstLoc.longitude], 5);

                // --- Street (default OSM) ---
                const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: ''
                });

                // --- Satellite (Esri) ---
                const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                    attribution: ''
                });

                // Add default layer
                streetLayer.addTo(map);

                // Layer control (toggle)
                const baseMaps = {
                    "Street View": streetLayer,
                    "Satellite View": satelliteLayer
                };
                L.control.layers(baseMaps).addTo(map);

                const bounds = [];

                locations.forEach(loc => {
                    const marker = L.marker([loc.latitude, loc.longitude]).addTo(map);
                    var participant_name = loc.participant_name;
                      marker.bindPopup(`${participant_name ? '<b>' + participant_name + '</b><br>' : ''}<b>IP: ${loc.name}</b><br>Lat: ${loc.latitude}, Lng: ${loc.longitude}`);
                    bounds.push([loc.latitude, loc.longitude]);
                });

                map.fitBounds(bounds);

            } else {
                $('#multi_map').html('<p class="text-center text-danger mt-4 fs-4 fw-bold">No locations found</p>');
            }
        },
        error: function (xhr) {
            console.error(xhr.responseText);
        }
    });
}

</script>
<!--event Attendance -->
<script>
$(document).ready(function() {
  // Handle the "Check All" checkbox
  $('#checkAll').on('change', function() {
    let isChecked = $(this).prop('checked');
    $('#studs_table_event_attendance tbody input[type="checkbox"]').each(function() {
      $(this).prop('checked', isChecked);
        toggleCheckboxText($(this)); // Update color for each checkbox
    });
  });

  // Handle individual checkboxes
  $('#studs_table_event_attendance tbody').on('change', 'input[type="checkbox"]', function() {
    let isChecked = $(this).prop('checked');
    toggleCheckboxText($(this));  // Update color for the changed checkbox

    // Check if all checkboxes are checked to toggle the "Check All" checkbox
    let allChecked = $('#studs_table_event_attendance tbody input[type="checkbox"]').length === $('#studs_table_event_attendance tbody input[type="checkbox"]:checked').length;
    $('#checkAll').prop('checked', allChecked);
  });

  // Function to toggle the checkbox color
   function toggleCheckboxText(checkbox) {
    let label = checkbox.closest('td').find('span'); // Find the span that contains the text (Present/Absent)
    if (checkbox.prop('checked')) {
      label.text('Present').removeClass('text-danger').addClass('text-success');
    } else {
      label.text('Absent').removeClass('text-success').addClass('text-danger');
    }
  }

  // Update attendance on button click
  $('#updateAttendanceBtn').on('click', function() {
    let attendanceData = [];
    $('#studs_table_event_attendance tbody input[type="checkbox"]').each(function() {
      let studentSno = $(this).attr('id').split('_')[2];  // Extract student sno from checkbox id
      let attendanceStatus = $(this).prop('checked') ? 1 : 0;
      attendanceData.push({
        sno: studentSno,
        attendance_status: attendanceStatus
      });
    });
    
    var attendance_event_id = $('#attendance_event_id').val();
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    // Send updated attendance data to the backend
    $.ajax({
      url: '/update_attendance',  // Your API endpoint
      type: 'POST',
      headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': csrfToken
            },
      data: JSON.stringify({ attendance_data: attendanceData , event_id:attendance_event_id }),
      contentType: 'application/json',
      success: function(response) {
        if (response.success) {
            window.location.reload();
          toastr.success('Attendance updated successfully!');
        } else {
           toastr.error('Error updating attendance.');
        }
      },
      error: function(xhr, status, error) {
        console.error('Error updating attendance:', error);
      }
    });
  });
});

   function eventAttendanceFunc(event_id) {
       $('#attendance_event_id').val(event_id);
        $.ajax({
            url: '/view_event/' + event_id, // URL to your route
            type: 'GET',
            success: function(response) {
                if(response.success) {
                      $("#attendance_category_name").text(response.data.event_category_name);
                      $('#attendance_event_name').text(response.data.event_name);
                    $('#attendance_participants').text(
                            response.data.participants === 'Limited' 
                            ? response.data.participants + ' (' + response.data.no_of_participants + ')'
                            : response.data.participants
                        );
                      $('#attendance_no_of_participants').text(response.data.applied_count || '0');

                     

                       // Populate student table data (assuming an array of students)
                    let studentTableBody = $('#kt_modal_event_attendance').find('#studs_table_event_attendance tbody');
                    studentTableBody.empty();
                    response.data.student_list.forEach(function(student, index) {
                         let cert_status =student.certificate_status == 1 ?'Sent':'Pending';
                        let student_intrv_status= student.status == '1'? 'On Progress' :(student.status == '3'? 'Rejected' :(student.status == '4'? 'Selected' :'Select Status'))
                        let student_intrv_color= student.status == '1'? 'bg-info text-white' :(student.status == '3'? 'bg-danger text-white' :(student.status == '4'? 'bg-success text-black' :'bg-secondary text-white'))
                        let encryptedValue = student.encrypted_sno;
                        let printValue = student.encrypted_index;
                          var user_id = {{auth()->user()->role_id}};
                        let studentRow = `
                                    <tr>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.participant_name}</div>
                                        </td>
                                        <td>
                                            <div class="text-black fw-semibold fs-7">${student.mobile_no}</div>
                                        </td>
                                        <td>
                                            <div class="fw-semibold text-black fs-7 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${student.participant_email || '-'}">${student.participant_email || '-'}</div>
                                        </td>
                                       
                                         <td class="text-start text-black fw-semibold fs-3">
                                           
                                          <div class="fw-semibold text-black fs-7 "><input type="checkbox" class="form-check-input" name="attendance_check_${student.sno}" id="attendance_check_${student.sno}" checked value="1"/> <span class="ms-2 text-success">Present</span></div>
                                          
                                        </td>
                                       
                                    </tr>
                                `;
                        studentTableBody.append(studentRow);
                    });

                    $(".std_list_page").DataTable({
                        "ordering": false,
                        "paging": false,
                        "language": {
                        "lengthMenu": "Show _MENU_",
                        },
                        "dom": "<'row mb-3'" +
                        "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                        ">" +
                        "<'table-responsive'tr>" +
                        "<'row'" +
                        "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                        ">" 
                    });

                    $('.std_list_page').wrap('<div class="dataTables_scroll" />');
                    
                } else {
                    console.error('Error: ' + response.message);
                }
            },
            error: function(xhr, status, error) {
                console.log('Error fetching company data:', error);
                console.error('An error occurred while fetching the company data.');
            }
        });
    }
 
</script>
 <script>
	$(".list_page_scroll3").DataTable({
		// "ordering": false,
		"aaSorting": [],
		// "pagingType": 'simple_numbers',
		"pagingType": "full_numbers",
		"sorting": false,
		"paging": false,
		// "info": false,
		// "buttons": [
		//             'copy', 'csv', 'excel', 'pdf', 'print'
		//         ],
		"language": {
			"lengthMenu": "Show _MENU_",
		},
		// "pageLength": 5,
		"dom": "<'row'" +
			// "<'col-sm-6 d-flex align-items-center justify-conten-start my-3'l>" +
			//   "<'col-sm-12 d-flex align-items-center justify-content-end my-3'f>" +
			">" +

			"<'table-responsive'tr>" +

			"<'row'" +
// 			"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
			// "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
			">"
	});
	$('.list_page_scroll3').wrap('<div class="dataTables_scroll3" />');
</script>
<script>
    const leadBoomElements = document.querySelectorAll('.leadBoom'); // Get all elements with the class 'leadBoom'

    setInterval(() => {
        leadBoomElements.forEach(leadBoom => { // Loop through each element
            leadBoom.classList.add('boom-animate');

            setTimeout(() => {
                leadBoom.classList.remove('boom-animate');
            }, 500); // Remove animation after 500ms
        });
    }, 2000); 
</script>
<!--copy-->
<script>

document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.cpy-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            const targetId = this.getAttribute('data-target');
            const text = document.getElementById(targetId).textContent;

            // Copy text to clipboard
            navigator.clipboard.writeText(text).then(() => {
                // ✅ Optional: show toast/alert
                toastr.success('Copied: ' + text);
            }).catch(err => {
                console.error('Failed to copy text: ', err);
            });
        });
    });
});
</script>

<!-- Upload & Preview Logic -->
<script>
 
 function type_change(){
     const posterTypeSelect = document.getElementById('poster_type');
     document.getElementById('empty_preview').classList.add('d-none');
    document.querySelectorAll('.poster-type').forEach(el => el.classList.add('d-none'));
    if (posterTypeSelect.value === '1'){
        console.log('work'); 
        document.getElementById('type1_ui').classList.remove('d-none');
    } 
    else if (posterTypeSelect.value === '2'){
        document.getElementById('type2_ui').classList.remove('d-none');
    } 
    else{
         console.log('work empty'); 
        document.getElementById('empty_preview').classList.remove('d-none');
    } 
 }

document.addEventListener("DOMContentLoaded", function () {
  const dropZone = document.getElementById('drop_zone');
  const modalBody = document.querySelector('#kt_modal_add_poster_template .modal-body');
  const fileInput = document.getElementById('template_image');
  const previewBox = document.getElementById('upload_preview');
  const previewImg = document.getElementById('upload_preview_img');
  const removeBtn = document.getElementById('remove_upload');
  const uploadMsg = document.getElementById('upload_message');
 
  const modal = document.getElementById('kt_modal_add_poster_template');

  // === Handle Poster Type Switch ===
 

  // === Upload Click and Drag on Drop Zone ===
  dropZone.addEventListener('click', e => {
    if (e.target === dropZone || e.target.closest('#upload_message')) fileInput.click();
  });

  // === Global Drag & Drop Anywhere in Modal ===
  modalBody.addEventListener('dragover', e => {
    e.preventDefault();
    modalBody.classList.add('border', 'border-dashed', 'rounded');
  });

  modalBody.addEventListener('dragleave', e => {
    e.preventDefault();
    modalBody.classList.remove('border', 'border-dashed', 'rounded');
  });

  modalBody.addEventListener('drop', e => {
    e.preventDefault();
    modalBody.classList.remove('border', 'border-dashed', 'rounded');
    // Assign dropped file to input
    if (e.dataTransfer.files.length > 0) {
      fileInput.files = e.dataTransfer.files;
      handleFile();
    }
  });

  fileInput.addEventListener('change', handleFile);

  function handleFile() {
    const file = fileInput.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = e => {
        previewImg.src = e.target.result;
        previewBox.classList.remove('d-none');
        uploadMsg.innerHTML = `
          <p class="mb-0 small text-success">
            <i class="mdi mdi-check-circle text-success me-1"></i>${file.name}
          </p>`;
      };
      reader.readAsDataURL(file);
    }
  }

  removeBtn.addEventListener('click', e => {
    e.stopPropagation();
    fileInput.value = '';
    previewImg.src = '';
    previewBox.classList.add('d-none');
    uploadMsg.innerHTML = `
      <p class="mb-0 text-muted small">
        <i class="mdi mdi-cloud-upload-outline text-primary me-1"></i>
        Drag & Drop or Click to Upload
      </p>`;
  });
});
</script>
 <script>
        function addValidateForm() {
            $("#createPosterBtn").prop('disabled', true);
            var err = 0;
            // Validate knowledge Name
            var template_name = document.getElementById("template_name").value.trim();
            if (template_name === "") {
                document.getElementById('template_name_err').innerHTML = 'Template Name is required...!';
                err++;
            } else {
                document.getElementById('template_name_err').innerHTML = '';
            }
            var poster_type = document.getElementById("poster_type").value;
            if (poster_type === "") {
                document.getElementById('poster_type_err').innerHTML = 'Poster Type is required...!';
                err++;
            } else {
                document.getElementById('poster_type_err').innerHTML = '';
            }
            var template_image = document.getElementById("template_image").value.trim();
            if (template_image === "") {
                document.getElementById('template_image_err').innerHTML = 'Poster Template is required...!';
                err++;
            } else {
                document.getElementById('template_image_err').innerHTML = '';
            }

            if(err>0){
                $("#createPosterBtn").prop('disabled', false);
                return false;
            }else{
                $("#createPosterBtn").prop('disabled', true);
                $('#poster_template_form').submit();
            }
        }
        </script>
        


<script>
  // Fetch poster templates by type
  function fetchPosterTemplates(type_id) {
    $.ajax({
      url: '/poster_list_by_type',
      type: 'GET',
      data: { type_id },
      success: function (response) {
        if (response.status === 200) {
          const select = $('#poster_template_download');
          select.empty().append('<option value="">Select Template</option>');
          var type_name='Type 1'
          response.data.forEach(tpl => {
              type_name = `Type ${tpl.poster_type_id}`
            select.append(`<option value="${tpl.sno}" data-type="${tpl.poster_type_id}">${tpl.poster_template} ( ${type_name} )</option>`);
          });
        }
      },
      error: () => console.error('Error fetching poster templates')
    });
  }

  // On template change
  function poster_template_change() {
    const id = $('#poster_template_download').val();
    const type = $('#poster_template_download option:selected').data('type');
    if (id && type) {
      showPosterPreview(id, type);
    }
  }

  // Show image + build overlay
  function showPosterPreview(template_id, type) {
    $.ajax({
      url: '/get_poster_preview',
      type: 'GET',
      data: { template_id },
      success: function (response) {
        if (response.status === 200 && response.data.poster_image) {
          const imgUrl = `/Poster_images/${response.data.poster_image}`;
          $('#poster_preview_img').attr('src', imgUrl).removeClass('d-none');
          $('#poster_text_overlay').removeClass('d-none').empty();
          $('#empty_preview_download').addClass('d-none');

          // Create layout based on type
          if (type == 1) buildType1Layout();
          else if (type == 2) buildType2Layout();

          // Refill text (if event data already fetched)
          fillPosterData(window.currentEventData || {});
          
           if (window.currentEventData?.sno) {
              generate_qr_event(window.currentEventData.sno);
            }
        }
      },
      error: () => console.error('Error loading poster preview')
    });
  }

  // Type layouts
  function buildType1Layout() {
    $('#poster_text_overlay').html(`
      <div id="fill_title" class="position-absolute text-center fw-bold" style="top:220px;left:0;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_presenter" class="position-absolute text-center fw-bold" style="top:240px;left:10px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_date" class="position-absolute text-center fw-bold" style="top:260px;left:50px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_start_time" class="position-absolute text-center fw-bold" style="top:280px;left:-90px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_end_time" class="position-absolute text-center fw-bold" style="top:280px;left:-10px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_mode" class="position-absolute text-center fw-bold" style="top:280px;left:80px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_organizer" class="position-absolute text-center fw-bold" style="top:320px;left:-40px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_participants" class="position-absolute text-center fw-bold" style="top:340px;left:-90px;width:100%;font-size:10px;color:#0f1b61;"></div>
      <div id="fill_fees" class="position-absolute text-center text-warning fw-bold" style="top:404px;left:35px;width:100%;font-size:14px;color:#0f1b61;"></div>
      <div id="fill_qr" class="position-absolute text-center fw-bold" 
             style="top:428px;left:24px;width:100%;font-size:14px;color:#0f1b61;">
          <img id="fillQrImage" 
               src="" 
               alt="QR Code" 
               style="width:56px;height:56px;object-fit:contain;display:none;">
        </div>
      <div id="fill_contact" class="position-absolute text-center  fw-bold" style="top:485px;left:120px;width:100%;font-size:14px;color:#0f1b61;"></div>
    `);
  }

  function buildType2Layout() {
    $('#poster_text_overlay').html(`
          <div id="fill_title" class="position-absolute text-center fw-bold" style="top:222px;left:0;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_presenter" class="position-absolute text-center fw-bold" style="top:242px;left:10px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_date" class="position-absolute text-center fw-bold" style="top:276px;left:90px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_start_time" class="position-absolute text-center fw-bold" style="top:294px;left:-40px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_end_time" class="position-absolute text-center fw-bold" style="top:294px;left:50px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_mode" class="position-absolute text-center fw-bold" style="top:312px;left:-20px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_organizer" class="position-absolute text-center fw-bold" style="top:360px;left:-25px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_participants" class="position-absolute text-center fw-bold" style="top:380px;left:95px;width:100%;font-size:10px;color:#0120ff;"></div>
          <div id="fill_certificate" class="position-absolute text-center  fw-bold" style="top:441px;left:-5px;width:100%;font-size:11px;color:#0120ff;"></div>
          <div id="fill_fees" class="position-absolute text-center  fw-bold" style="top:441px;left:108px;width:100%;font-size:11px;color:#0120ff;"></div>
          <div id="fill_qr" class="position-absolute text-center fw-bold" 
                 style="top:426px;left:24px;width:100%;font-size:14px;color:#0f1b61;">
              <img id="fillQrImage" 
                   src="" 
                   alt="QR Code" 
                   style="width:56px;height:56px;object-fit:contain;display:none;">
            </div>
        <div id="fill_contact" class="position-absolute text-center  fw-bold" style="top:489px;left:116px;width:100%;font-size:11px;color:#0120ff;"></div>
    `);
  }

  // Fetch event data
  function openDownloadPoster(event_id) {
      resetPosterModal();
      
      fetchPosterTemplates(1)
    $.ajax({
      url: '/view_event/' + event_id,
      type: 'GET',
      success: function (response) {
        if (response.success) {
          const d = response.data;
          window.currentEventData = d; // store for reuse
          $('#poster_event_name').text(d.event_name);
          $('#poster_event_date').text(formatDate(d.event_date));
          $('#poster_event_time').text(`${formatTime(d.start_time)} to ${formatTime(d.end_time)}`);
          $('#poster_event_offer').text(d.event_offer === 'free' ? 'Free' : `₹${d.event_amount}`);

          fillPosterData(d);
        }
      },
      error: () => console.error('Error fetching event data')
    });
  }
  
  $('#kt_modal_download_poster').on('hidden.bs.modal', resetPosterModal);
  
   function resetPosterModal() {
      // Clear global data
      window.currentEventData = null;
    
      // Clear event info header
      $('#poster_event_name, #poster_event_date, #poster_event_time, #poster_event_offer').text('');
    
      // Reset poster preview
      $('#poster_preview_img').attr('src', '').addClass('d-none');
      $('#poster_text_overlay').addClass('d-none').empty();
      $('#empty_preview_download').removeClass('d-none');
    
      // Clear selects
      $('#poster_type_download').val('');
      $('#poster_template_download').empty().append('<option value="">Select Template</option>');
    
      // Hide any existing QR
      const qrImage = document.getElementById('fillQrImage');
      if (qrImage) {
        qrImage.src = '';
        qrImage.style.display = 'none';
      }
    }


  // Fill poster text fields
  function fillPosterData(d) {
    if (!d) return;
    var participantData = d.participants === 'Limited' 
                            ? d.participants + ' (' + d.no_of_participants + ')'
                            : d.participants;
    var eventFee = d.event_offer === 'free' ? 'Free' : `₹${d.event_amount}`;
    var certificate = d.certificate === 'yes' ? 'Provided' : `No`;
                        
    $('#fill_title').text(d.event_name || '');
    $('#fill_presenter').text(d.conducted_staff_name ||d.handle_others_name);
    $('#fill_date').text(formatDate(d.event_date || ''));
    $('#fill_start_time').text(`${formatTime(d.start_time)}`);
    $('#fill_end_time').text(`${formatTime(d.end_time)}`);
    $('#fill_mode').text(d.event_type_id || '');
    $('#fill_organizer').text(d.branch_name || d.franchise_name);
    $('#fill_participants').text(participantData);
    $('#fill_fees').text(eventFee);
    $('#fill_certificate').text(certificate);
    $('#fill_contact').text(d.contact_person_mob_no);
  }

  // Formatting helpers
  function formatDate(date) {
    if (!date) return '';
    const d = new Date(date);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  }

  function formatTime(timeStr) {
    if (!timeStr) return '';
    const [hour, minute] = timeStr.split(':');
    const h = parseInt(hour);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const formattedHour = h % 12 || 12;
    return `${formattedHour.toString().padStart(2, '0')}.${minute} ${ampm}`;
  }

  // Fixed html2canvas (v1.4.1+) download
function downloadPoster() {
  const container = document.getElementById('poster_preview_container');

  html2canvas(container, {
    useCORS: true,
    scale: 4, // 🚀 Increase scale for sharper output (2 is default)
    backgroundColor: null,
    allowTaint: true,
    imageTimeout: 0,
    logging: false
  }).then(canvas => {
    // Optional crop if needed
    const croppedCanvas = document.createElement('canvas');
    const ctx = croppedCanvas.getContext('2d');
    const cropX = 0, cropY = 0;
    const cropWidth = canvas.width;
    const cropHeight = canvas.height;

    croppedCanvas.width = cropWidth;
    croppedCanvas.height = cropHeight;
    ctx.drawImage(canvas, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);

    let event_name = 'EventPoster';
    if (window.currentEventData?.sno) {
      event_name = window.currentEventData.event_name.replace(/[^\w\s]/gi, '');
    }

    // 📸 Convert to high-quality PNG
    const link = document.createElement('a');
    link.download = `${event_name}.png`;
    link.href = croppedCanvas.toDataURL('image/png', 1.0); // 1.0 = best quality
    link.click();
  });
}
</script>

<script>
  function generate_qr_event(id) {
      fetch(`/gen_event_qr/${id}/generate-qr`)
        .then(res => res.json())
        .then(data => {
          if (data.status === 200 && data.qr_base64) {
            const qrImage = document.getElementById('fillQrImage');
            qrImage.src = data.qr_base64;
            qrImage.style.display = "block";
          } else {
            console.error("QR generation failed or missing base64 data");
          }
        })
        .catch(err => console.error('Error generating QR:', err));
    }
</script>

<script>
    function transfer_particpant_func(id, eventName, applyCount, eventCategory) {
        $('#old_event_id').val(id);
        $('#transfer_event_category').text(eventCategory);
        $('#transfer_event_name').text(eventName);
        $('#transfer_applied_count').text(applyCount);

        let eventDrop = $('#transfer_event_id');
        eventDrop.empty().append('<option value="">Select Event</option>');
        $('#transfer_event_datails').empty();

        // Show loading text
        $('#event-dropdown-status').text('Loading scheduled events...');

        $.ajax({
            url: "{{ route('get_branch_scheduled_event') }}",
            type: 'GET',
            data: { event_id: id },
            success: function (res) {
                eventDrop.empty().append('<option value="">Select Event</option>');
                $('#transfer_event_datails').empty();

                if (res.status === 200 && res.data && res.data.length > 0) {
                    res.data.forEach(function (row) {
                        eventDrop.append(
                            $('<option></option>').val(row.sno).text(row.event_name)
                        );
                    });
                    $('#event-dropdown-status').text(res.data.length + ' Scheduled Events Available');
                } else {
                    $('#event-dropdown-status').text('0 Scheduled Events Found');
                }
            },
            error: function (err) {
                console.error('Error fetching transfer events:', err);
                $('#event-dropdown-status').text('Error loading events');
            }
        });
    }

    $(document).ready(function () {
        $('#transfer_event_id').on('change', function () {
            let transfer_event_id = $(this).val();
            if (transfer_event_id) {
                $('#transfer_event_datails').html('<div class="text-center text-muted mt-2">Loading event details...</div>');
                $.ajax({
                    url: '/view_event/' + transfer_event_id,
                    type: 'GET',
                    success: function (res) {
                        if (res.status === 200 && res.data) {
                            let e = res.data;
                            $('#transfer_event_datails').html(`
                                <div class="event-details-card fade-in">
                                    <h6><i class="fas fa-calendar-alt text-primary"></i>Transfer Event Details</h6>
                                    <div class="event-detail-row">
                                        <span class="event-detail-label">Event Name:</span>
                                        <span class="event-detail-value">${e.event_name}</span>
                                    </div>
                                    <div class="event-detail-row">
                                        <span class="event-detail-label">Date:</span>
                                        <span class="event-detail-value">${formatDate(e.event_date)}</span>
                                    </div>
                                    <div class="event-detail-row">
                                        <span class="event-detail-label">Start Time:</span>
                                        <span class="event-detail-value">${formatTime(e.start_time)}</span>
                                    </div>
                                    <div class="event-detail-row">
                                        <span class="event-detail-label">End Time:</span>
                                        <span class="event-detail-value">${formatTime(e.end_time)}</span>
                                    </div>
                                    <div class="event-detail-row">
                                        <span class="event-detail-label">Mode:</span>
                                        <span class="event-detail-value">${e.event_type_id}</span>
                                    </div>
                                </div>
                            `);
                        } else {
                            $('#transfer_event_datails').html('<div class="text-center text-danger mt-2">No event details found</div>');
                        }
                    },
                    error: function (err) {
                        console.error('Error loading event details:', err);
                        $('#transfer_event_datails').html('<div class="text-center text-danger mt-2">Error fetching event details</div>');
                    }
                });
            } else {
                $('#transfer_event_datails').empty();
            }
        });
    });
</script>

<script>
function transferParticipant() {
    let event_id = $('#transfer_event_id').val().trim();
    let old_event_id = $('#old_event_id').val();
    let $btn = $('#transferParticpntBtn');
    let $error = $('#transfer_event_id_err');

    // Reset error
    $error.text('');

    // Validate
    if (!event_id) {
        $error.text('Please select an event to transfer.');
        return;
    }

    // Disable button & show spinner
    $btn.prop('disabled', true)
        .html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Transferring...');

    $.ajax({
        url: "{{ route('tranfer_event_participant') }}",
        type: 'POST',
        data: {
            event_id: event_id,
            old_event_id: old_event_id,
            _token: "{{ csrf_token() }}" // Ensure CSRF token is included
        },
        success: function (res) {
            // Toastr success message
            toastr.success('Participant transferred successfully!');
            
            // Optionally close modal after short delay
            setTimeout(() => {
                $('#kt_modal_transfer_paticipants').modal('hide');
                location.reload(); // Reload the page
            }, 1000);
        },
        error: function (err) {
            console.error('Error while transferring participant:', err);
            toastr.error('Something went wrong while transferring participant.');
        },
        complete: function () {
            // Re-enable button & restore text
            $btn.prop('disabled', false).html('Transfer');
        }
    });
}
</script>
<script>
      function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#search_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#search_form').submit();
        }
      }
    </script>


@endsection
