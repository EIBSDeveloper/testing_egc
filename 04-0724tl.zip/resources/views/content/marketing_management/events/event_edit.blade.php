@extends('layouts/layoutMaster')

@section('title', 'Update Event')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss','resources/assets/vendor/libs/tagify/tagify.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss','resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js','resources/assets/vendor/libs/flatpickr/flatpickr.js','resources/assets/vendor/libs/tagify/tagify.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/accordian.js', 'resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
    <!-- Users List Table -->
    @php
    $helper = new \App\Helpers\Helpers();
    @endphp
    <style>
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Update Event</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Marketing Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:void(0);" class="d-flex align-items-center">Events</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-body">
            <form method="POST" action="{{ route('Placement_event_update') }}" enctype="multipart/form-data"
                autocomplete="off" id="event_form">
                @csrf
            <div class="row">
              {{-- {{ $event_data }} --}}
                  <input type="hidden" name="edit_sno" id="edit_sno" value="{{ $event_data->sno }}">
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                    @php
                            // Get the logged-in user_id
                            $user_id = auth()->user()->user_id;
                            $role_id = auth()->user()->role_id;
    
                            // Get the filtered branch and franchise list based on user's multi_branch_access
                            $branch_data = $helper->get_branch_control_list($user_id);
                            $branches = $branch_data['branches'];
                            $franchises = $branch_data['franchises'];
                        @endphp
                         @if($role_id == 1)
                            <select name="branch_name" class="select3 form-select" id="branch_name" >
                            
                                <option value="" selected>Select Branch</option>
                            
                                @if ($branches->isNotEmpty())
                                    <optgroup  label="Branches">
                                        @foreach ($branches as $branch)
                                            <!--@ if($branch->sno!=1)-->
                                                <option value="{{ $branch->sno }}" {{ $event_data->branch_id == $branch->sno ? 'selected' : '' }}>
                                                    {{ $branch->branch_name }}
                                                </option>
                                            <!--@ endif-->
                                        @endforeach
                                    </optgroup>
                                @endif
        
        
                                @if ($franchises->isNotEmpty())
                                    <optgroup label="Franchises">
                                        @foreach ($franchises as $franchise)
                                            <option value="{{ $franchise->sno }}" {{ $event_data->branch_id == $franchise->sno ? 'selected' : '' }}>
                                                {{ $franchise->franchise_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                            </select>
                        @else
                   
                        <div class="d-flex align-items-center mt-2">
                            <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                            <div>
                                <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                <small class="text-truncate max-w-10px text-muted" title="{{ $branch_common->branch_name }}">{{ $branch_common->branch_name }}</small>
                                <input type="hidden" name="branch_name"  id="branch_name" value="{{$event_data->branch_id}}">
                            </div>
                        </div>
                        @endif
                    <div class="text-danger" id="branch_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Name<span class="text-danger">*</span><small class="form-text text-muted ms-1">Max 45 characters</small></label>
                    <input type="text" class="form-control" id="event_name" name="event_name" maxlength="45"
                        placeholder="Enter Event Name" value="{{ $event_data->event_name }}" />
                        <div class="text-danger" id="event_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Category<span class="text-danger">*</span></label>
                    <select id="event_category" class="select3 form-select" name="event_category">
                        <option value="">Select Event Category</option>
                        @foreach ($event_categories as $event_category)
                            <option value="{{ $event_category->sno }}"
                                {{ $event_category->sno == $event_data->event_category ? 'selected' : '' }}>
                                {{ $event_category->event_category_name }}
                            </option>
                        @endforeach
                    </select>
                    <div class="text-danger" id="event_category_err"></div>
                </div>
                <!-- <div class="col-lg-4 mb-3">                                                                                                                                                                                                                                  </div>
                                                                                                                                                                                                                                                                                                                                                        </div> -->

                <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Event Type<span
                          class="text-danger">*</span></label>
                  <div class="d-flex align-items-center mt-1">
                      <div class="form-check form-check-inline me-3">
                          <input class="form-check-input" type="radio" id="event_type"
                              name="event_type" value="Offline" onclick="event_type_fun(1)" {{ $event_data->event_type_id =="Offline" ? 'checked':'' }}  />
                          <label class="text-dark mb-1 fs-6 fw-semibold">Offline</label>
                      </div>
                      <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" id="event_type_1"
                              name="event_type" value="Online" onclick="event_type_fun(2)" {{ $event_data->event_type_id =="Online" ? 'checked':'' }}  />
                          <label class="text-dark mb-1 fs-6 fw-semibold">Online</label>
                      </div>
                  </div>
                </div>
                <!-- <div class="col-lg-4 mb-3">                                                                                                                                                                                                                                        </div>
                                                                                                                                                                                                                                                                                                                                                            </div>
                                                                                                                                                                                                                                                                                                                                                        </div> -->
                <div class="col-lg-4 mb-3 offline_campus_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="location_url" placeholder="Enter Location URL"
                        value="{{ $event_data->location_url }}" name="location_url" />
                        <div class="text-danger" id="location_url_err"></div>
                </div>
                <div class="col-lg-4 mb-3 offline_campus_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Address<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="event_address" name="event_address"
                        placeholder="Enter Address" value="{{ $event_data->event_address }}" />
                        <div class="text-danger" id="event_address_err"></div>
                </div>
                 <!-- <div class="col-lg-4 mb-3 online_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Zoom Link<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="zoom_link" name="zoom_link" placeholder="Enter Zoom Link"
                        value="{{ $event_data->zoom_link }}" />
                        <div class="text-danger" id="zoom_link_err"></div>
                </div>  -->
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="event_add_dt" placeholder="Select Event Date"
                            class="form-control  common_date_class"
                            value="{{ date('d-M-Y', strtotime($event_data->event_date)) }}" name="event_date" />
                    </div>
                    <div class="text-danger" id="event_date_err"></div>
                </div>
                <div class="col-lg-4 mb-3 ">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Start Time<span class="text-danger">*</span></label>
                    <input type="text" class="form-control common_time_class" placeholder="HH:MM" id="start_time" name="start_time"  value="{{ date('H:i', strtotime($event_data->start_time)) }}" readonly />
                    <div class="text-danger" id="start_time_err"></div>
                </div>
                <div class="col-lg-4 mb-3 ">
                    <label class="text-dark mb-1 fs-6 fw-semibold">End Time<span class="text-danger">*</span></label>
                    <input type="text" class="form-control common_time_class_new " placeholder="HH:MM" id="end_time" name="end_time"  value="{{ date('H:i', strtotime($event_data->end_time)) }}" readonly/>
                    <div class="text-danger" id="end_time_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Event Offer<span
                          class="text-danger">*</span></label>
                  <div class="d-flex align-items-center mt-1">
                      <div class="form-check form-check-inline me-3">
                          <input class="form-check-input" type="radio" id="event_offer"
                              name="event_offer" value="free" onclick="event_offer_fun(1)" {{ $event_data->event_offer =="free" ? 'checked':'' }} />
                          <label class="text-dark mb-1 fs-6 fw-semibold">Free</label>
                      </div>
                      <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" id="event_offer_1"
                              name="event_offer" value="paid" onclick="event_offer_fun(2)" {{ $event_data->event_offer =="paid" ? 'checked':'' }}/>
                          <label class="text-dark mb-1 fs-6 fw-semibold">Paid</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" id="event_offer_2"
                            name="event_offer" value="redeem" onclick="event_offer_fun(3)" {{ $event_data->event_offer =="redeem" ? 'checked':'' }}/>
                        <label class="text-dark mb-1 fs-6 fw-semibold">Redeem</label>
                    </div>
                  </div>
                </div>
                <!-- <div class="col-lg-4 mb-3">
                                                                                                                                                                                                                                                                                                                                                                   </div> -->

                <div class="col-lg-4 mb-3 paid_row" >
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Amount<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="event_amount" placeholder="Enter Amount"
                        value="{{ $event_data->event_amount }}" name="event_amount" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-danger" id="event_amount_err"></div>
                </div>

                <div class="col-lg-4 mb-3 redeem_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Event Coupon code<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="coupon_code" name="coupon_code"
                        placeholder="Enter Coupon Code" value="{{ $event_data->coupon_code }}" />
                        <div class="text-danger" id="coupon_code_err"></div>
                </div>

                <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Participants<span
                          class="text-danger">*</span></label>
                  <div class="d-flex align-items-center mt-1">
                      <div class="form-check form-check-inline me-3">
                          <input class="form-check-input" type="radio" id="participants"
                              name="participants" value="Limited" onclick="participant_count(1)" {{ $event_data->participants =="Limited" ? 'checked':'' }} />
                          <label class="text-dark mb-1 fs-6 fw-semibold">Limited</label>
                      </div>
                      <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" id="participants_1"
                              name="participants" value="Unlimited" onclick="participant_count(2)" {{ $event_data->participants =="Unlimited" ? 'checked':'' }}/>
                          <label class="text-dark mb-1 fs-6 fw-semibold">Unlimited</label>
                      </div>
                  </div>
              </div>
                <!-- <div class="col-lg-4 mb-3">                                                                                                                                        </div> -->
                <div class="col-lg-4 mb-3 paricipants_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">No of Participants<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="no_of_participants" placeholder="Enter No of Participants"
                        value="{{ $event_data->no_of_participants }}" name="no_of_participants" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-danger" id="no_of_participants_err"></div>
                </div>
                <div class="col-lg-4 mb-3 ">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Name<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="contact_person_name" name="contact_person_name"
                        placeholder="Enter Contact Person Name" value="{{ $event_data->contact_person_name }}" />
                        <div class="text-danger" id="contact_person_name_err"></div>

                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="contact_person_number"
                        placeholder="Enter Contact Person Mobile Number" value="{{ $event_data->contact_person_mob_no }}"
                        name="contact_person_number"  maxlength="10"
                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                        <div class="text-danger" id="contact_person_number_err"></div>
                </div>
                <div class="col-lg-4 mb-3 handle_add_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Handle By<span
                            class="text-danger">*</span></label>
                    <select id="handle_type" class="select3 form-select" name="handle_type" onchange="changeHandleBy()">
                        <option value="Inhouse" {{ $event_data->handle_type == 'Inhouse' ? 'selected' : '' }}>Inhouse</option>
                        <option value="Others" {{ $event_data->handle_type == 'Others' ? 'selected' : '' }}>Others</option>
                    </select>
                    <div class="text-danger" id="handle_type_err"></div>
                </div>
                <div class="col-lg-4 mb-3 handle_person">
                    <input type="hidden" name="" id="handle_staff_id" value ="{{$event_data->handle_staff_id ?? '' }}">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Handle person<span
                            class="text-danger">*</span></label>
                    <select id="handle_person" class="select3 form-select" name="handle_person">
                        <option value="">Select Handle person</option>
                    </select>
                    <div class="text-danger" id="handle_person_err"></div>
                </div>

                <div class="col-lg-4 mb-3 handle_other_person " style="display:none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Other person Name<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="other_person_name" name="other_person_name"
                    placeholder="Enter Other person Name" value="{{ $event_data->handle_others_name  ?? ''}}" />
                    
                    <div class="text-danger" id="other_person_name_err"></div>
                </div>
                <div class="col-lg-4 mb-3 handle_other_mobile " style="display:none;">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Other person Mobile<span
                            class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="other_person_mobile" name="other_person_mobile"
                    placeholder="Enter Other person Mobile" value="{{ $event_data->handle_others_mobile ?? '' }}" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"  />
                    <div class="text-danger" id="other_person_mobile_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Certificate<span class="text-danger">*</span></label>
                    <div class="d-flex align-items-center mt-1">
                        <div class="form-check form-check-inline me-3">
                            <input class="form-check-input" type="radio" id="certificate_check" value="yes"
                                name="certificate_check" onclick="cert_add(1)"
                                {{ $event_data->certificate === 'yes' ? 'checked' : '' }} />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" id="" value="no"
                                name="certificate_check" onclick="cert_add(2)"
                                {{ $event_data->certificate === 'no' ? 'checked' : '' }} />
                            <label class="text-dark mb-1 fs-6 fw-semibold">No</label>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-3 cert_add_row">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Certificate Type<span
                            class="text-danger">*</span></label>
                    <select id="certificate_type" name="certificate_type" class="select3 form-select">
                        <option value="">Select Certificate Type</option>
                        <option value="Online Certificate" {{ $event_data->certificate_type === 'Online Certificate' ? 'selected' : '' }}>
                          Online Certificate</option>
                        <option value="Offline Certificate" {{ $event_data->certificate_type === 'Offline Certificate' ? 'selected' : '' }}>
                          Offline Certificate </option>
                    </select>
                    <div class="text-danger" id="certificate_type_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Event Key Tags (e.g., AI & Automation, Features of AI/ML, etc.)<span class="text-danger">*</span></label>
                  <div class="form-floating form-floating-outline">
                    <input id="event_Key_tag" name="event_Key_tag" class="form-control h-auto" placeholder="Enter Event Key Tags" value="">
                  </div>
                  <div class="text-danger" id="event_Key_tag_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                    <textarea class="form-control" rows="1" id="" name="event_desc" placeholder="Enter Description">{{ $event_data->event_description }}</textarea>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="{{ url('/events') }}" class="btn btn-secondary me-3">Cancel</a>
                <a href="javascript:;" class="btn btn-primary" data-bs-toggle="modal" id="submit_btn">Update Event</a>
                <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal"
                    data-bs-target="#kt_modal_cfm_create_event">
            </div>
          </form>
        </div>
    </div>


    <!--begin::Modal - Confirm Create Event-->
    <div class="modal fade" id="kt_modal_cfm_create_event" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                  <span id="create_label"></span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8">
                  <button type="button" class="btn fw-bold btn-primary me-3" onclick="submit_form()">Yes</button>
                  <button type="button" class="btn btn-secondary" id="pop_cancel" data-bs-dismiss="modal">No</button>
                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Confirm Create Event-->


    <script>

          function generateCouponCode() {
            // Define the character set for the random part of the code
            const charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

            // Generate a random alphanumeric string of specified length
            function getRandomString(length) {
                let result = '';
                for (let i = 0; i < length; i++) {
                    const randomIndex = Math.floor(Math.random() * charset.length);
                    result += charset[randomIndex];
                }
                return result;
            }

            // Get a shortened date component (e.g., last 2 digits of the year and month)
            function getShortDate() {
                const now = new Date();
                const year = String(now.getFullYear()).slice(-2); // Last 2 digits of the year
                const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
                return `${year}${month}`; // Format: YYMM
            }

            // Combine the shortened date and random string to form the coupon code
            const datePart = getShortDate(); // YYMM (4 characters)
            const randomPart = getRandomString(6); // 6-character random string
            return `${datePart}${randomPart}`; // Total length: 10 characters
          }
          var new_coupon_code = generateCouponCode();

        $(document).ready(function() {

            var event_type = document.getElementById("event_type")
            if (event_type.checked) {
                // $('.online_row').hide();
                $('.offline_campus_row').show();
            } else {
              // $('.online_row').hide();
              $('.offline_campus_row').hide();
            }

            var paricipants = document.getElementById("participants")
            if (paricipants.checked) {
                $('.paricipants_row').show();
            } else {
              $('.paricipants_row').hide();
            }

            var event_offer = document.getElementById("event_offer")
            var event_offer_paid = document.getElementById("event_offer_1")
            if (event_offer.checked) {
              $('.redeem_row').hide();
              $('.paid_row').hide();
            } else if(event_offer_paid.checked){
              $('.redeem_row').hide();
              $('.paid_row').show();
            }else{
              // displayCouponCode();
              $('.redeem_row').show();
              $('.paid_row').hide();
            }
        })


    </script>
    <script>
       function event_offer_fun(val) {
          if (val == 1) {
              $('.redeem_row').hide();
              $('.paid_row').hide();
          } else if (val == 2) {
              $('.redeem_row').hide();
              $('.paid_row').show();
          } else if (val == 3) {
              $('#coupon_code').val(new_coupon_code);
              $('.redeem_row').show();
              $('.paid_row').hide();
          } else {
            $('.redeem_row').hide();
            $('.paid_row').hide();
          }
        }
    </script>

    <script>
        $(document).ready(function() {
            const certificate = document.querySelectorAll('input[name="certificate_check"]');

              let selectedValue = null;

              // Iterate over the radio buttons
              certificate.forEach(radio => {
                  if (radio.checked) {
                      selectedValue = radio.value;
                  }
              });

            if (selectedValue == "yes") {
                $('.cert_add_row').show();
            } else if (selectedValue == "no") {
                $('.cert_add_row').hide();
            }
        })


    </script>
    <script>
      function event_type_fun(val) {
            if (val == 1) {
                // $('.online_row').hide();
                $('.offline_campus_row').show();
            } else if (val == 2) {
                // $('.online_row').show();
                $('.offline_campus_row').hide();
            } else {
              // $('.online_row').hide();
              $('.offline_campus_row').show();
            }
        }
    </script>
<script>
    function participant_count(val){
            if (val == 1) {
                $('.paricipants_row').show();
            } else if (val == 2) {
                $('.paricipants_row').hide();
            }
      }
</script>
    <script>

        function submit_form() {
            $('#event_form').submit();
        }

        $(document).ready(function() {
            
            $(".common_time_class_new").flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                defaultHour: new Date().getHours(),
                defaultMinute: new Date().getMinutes()
            });

$("#submit_btn").on("click", function(event) {

    var err = 0;
    var event_name = document.getElementById("event_name").value.trim();
    if (event_name === "") {
        if (err === 0) {
            $('#event_name_err').html('Event Name is required...!');
            $('#event_name').addClass('error_msg');
            err++;
        }
    } else {
        $('#event_name').removeClass('error_msg');
        $('#event_name_err').html('');
    }

    var event_category = document.getElementById("event_category").value.trim();
    if (event_category === "") {
        if (err === 0) {
            $('#event_category_err').html('Event Category is required...!');
            $('#event_category').addClass('error_msg');
            err++;
        }
    } else {
        $('#event_category').removeClass('error_msg');
        $('#event_category_err').html('');
    }



    var event_type = document.getElementById("event_type");
    var location_url = document.getElementById("location_url").value.trim();
    var event_address = document.getElementById("event_address").value.trim();

    if (event_type.checked) {
      if (event_type.value="Offline") {
        if (location_url === "") {
              if (err === 0) {
                  $('#location_url_err').html('Location URL is required...!');
                  $('#location_url').addClass('error_msg');
                  err++;
              }
          } else {
              $('#location_url').removeClass('error_msg');
              $('#location_url_err').html('');
          }
          if (event_address === "") {
              if (err === 0) {
                  $('#event_address_err').html('Address is required...!');
                  $('#event_address').addClass('error_msg');
                  err++;
              }
          } else {
              $('#event_address').removeClass('error_msg');
              $('#event_address_err').html('');
          }
      }else{
        $('#location_url').removeClass('error_msg');
        $('#location_url_err').html('');
        $('#event_address').removeClass('error_msg');
        $('#event_address_err').html('');
      }
    }



    var event_date = document.getElementById("event_add_dt").value.trim();
    if (event_date === "") {
        if (err === 0) {
            $('#event_date_err').html('Event Date is required...!');
            // $('.evnt_dt').addClass('error_msg');
            err++;
        }
    } else {
        // $('.evnt_dt').removeClass('error_msg');
        $('#event_date_err').html('');
    }

    var event_offer_paid = document.getElementById("event_offer_1");
    var event_offer_redeem = document.getElementById("event_offer_2");
    var event_amount = document.getElementById("event_amount").value.trim();
    var coupon_code = $("#coupon_code").val().trim();
    if (event_offer_paid.checked) {
        if (event_amount === "" || event_amount == "0") {
            if (err === 0) {
                $('#event_amount_err').html('Event Amount is required...!');
                $('#event_amount').addClass('error_msg');
                err++;
            }
        } else {
            $('#event_amount').removeClass('error_msg');
            $('#event_amount_err').html('');
        }
        $('#coupon_code').removeClass('error_msg');
        $('#coupon_code_err').html('');
    } else if (event_offer_redeem.checked) {
        if (coupon_code === "") {
            if (err === 0) {
                $('#coupon_code_err').html('coupon code is required...!');
                $('#coupon_code').addClass('error_msg');
                err++;
            }
        } else {
            $('#coupon_code').removeClass('error_msg');
            $('#coupon_code_err').html('');
        }
        $('#event_amount').removeClass('error_msg');
        $('#event_amount_err').html('');

    } else {
      $('#event_amount').removeClass('error_msg');
      $('#event_amount_err').html('');
      $('#coupon_code').removeClass('error_msg');
      $('#coupon_code_err').html('');
    }

    var participants = document.getElementById("participants");
    var no_of_participants = document.getElementById("no_of_participants").value.trim();
    if(participants.checked) {
    if (participants.value === "Limited") {

        if (no_of_participants === "" || no_of_participants == "0") {
            if (err === 0) {
                $('#no_of_participants_err').html('Number of participants  is required...!');
                $('#no_of_participants').addClass('error_msg');
                err++;
            }
        } else {
            $('#no_of_participants').removeClass('error_msg');
            $('#no_of_participants_err').html('');
        }
    }
   }else {
            $('#no_of_participants').removeClass('error_msg');
            $('#no_of_participants_err').html('');
        }



    var contact_person_name = document.getElementById("contact_person_name").value.trim();
    if (contact_person_name === "") {
        if (err === 0) {
            $('#contact_person_name_err').html('Contact Person Name is required...!');
            $('#contact_person_name').addClass('error_msg');
            err++;
        }
    } else {
        $('#contact_person_name').removeClass('error_msg');
        $('#contact_person_name_err').html('');
    }

    var contact_person_number = document.getElementById("contact_person_number").value.trim();
    if (contact_person_number === "") {
        if (err === 0) {
            $('#contact_person_number_err').html(
                'Contact Person Mobile Number is required...!');
            $('#contact_person_number').addClass('error_msg');
            err++;
        }
    } else {
        var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
        if (filter.test(contact_person_number)) {
            // Mobile number is valid
            $('#contact_person_number').removeClass('error_msg');
            $('#contact_person_number_err').html('');
        } else {
            if (err == 0) {
                $('#contact_person_number_err').html(
                    'Invalid Mobile Number !');
                $('#contact_person_number').addClass('error_msg');
                err++;
            }
        }
    }
    var certificate = document.getElementById("certificate_check")
    var certificate_1 = document.getElementById("certificate_check_1")
    if (certificate.checked) {
        if (certificate.value.trim() === "yes") {
            var certificate_type = document.getElementById("certificate_type").value.trim();
            if (certificate_type === "") {
                if (err === 0) {
                    $('#certificate_type_err').html(
                        'Certificate Type is required...!');
                    $('#certificate_type').addClass('error_msg');
                    err++;
                }
            } else {
                $('#certificate_type').removeClass('error_msg');
                $('#certificate_type_err').html('');
            }
        }
    } else {
        $('#certificate_type').removeClass('error_msg');
        $('#certificate_type_err').html('');
    }
    
       var event_Key_tag = document.getElementById("event_Key_tag").value.trim();
            if (event_Key_tag === "") {
                if (err === 0) {
                    $('#event_Key_tag_err').html('Event Key Tag is required...!');
                    err++;
                }
            } else {
                $('#event_Key_tag_err').html('');
            }

    var location_val = document.getElementById("location_url");
    var zoom_val = document.getElementById("zoom_link");
    var event_address_val = document.getElementById("event_address");

    if (err == 0) {
        var event_name_add = $('#event_name').val();
        var event_category_name_add = $('#event_category option:selected').text();
        var event_type_name_add = $('#event_type').val();
        if($('#event_type').is(':checked')){
          event_type_name_add =  $('#event_type').val();
        }else{
          event_type_name_add =  $('#event_type_1').val();
        }
        var event_offer_name_add = $('#event_offer').val();
        if($('#event_offer').is(':checked')){
          event_offer_name_add =  $('#event_offer').val();
        }else if($('#event_offer').is(':checked')){
          event_offer_name_add =  $('#event_offer_1').val();
        }else{
          event_offer_name_add =  $('#event_offer_2').val();
        }

        var contact_per_add = $('#contact_person_name').val();
        var event_date_add = $('#event_add_dt').val();
        // console.log(event_type)
        // var name = $('#event_name').val();
        if (event_type_name_add == "Online") {
          location_val.value=null;
          event_address_val.value=null;
        }
        var confirmHtml=`<div class="w-100">
                          <p class ="fw-bold text-center mb-4 text-black">Are you sure you want to Create Event ?</p>
                          <div class="ms-2 border border-dashed border-success rounded fw-bold px-1 py-1 mb-1 gap-2 ">
                            <div class="row ms-2 w-100">
                            <div class="col-lg-12 my-2 text-start">
                                <div class="row">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Event Name</label>
                                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">${event_name_add}</label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-2 text-start">
                                <div class="row">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Event Category</label>
                                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">${event_category_name_add}</label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-2 text-start">
                                <div class="row">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Event Type</label>
                                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                    <label class="col-7 fs-6 fw-bold text-capitalize"> <span class="fw-bold badge ${event_type_name_add== "Online"? 'bg-info text-white':'bg-warning text-black'}">${event_type_name_add}</span></label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-2 text-start">
                                <div class="row">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Event Date</label>
                                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                    <label class="col-7 text-black fs-7 fw-bold"><span class="fw-bold badge bg-success">${event_date_add}</span></label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-2 text-start">
                                <div class="row">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Contact person</label>
                                    <label class="col-1 text-dark fs-6 fw-semibold">:</label>
                                    <label class="col-7 text-black fs-6 fw-bold">${contact_per_add}</label>
                                </div>
                            </div>
                          </div>
                          </div>

                        </div>`

        $('#create_label').html(confirmHtml);
        $('#submit_popup').click();

    } else {
        $('#pop_cancel').click();
    }
});
});
    </script>

    <script>
        cert_add(1)

        function cert_add(val) {
            // alert(val);
            if (val == 1) {
                $('.cert_add_row').show();
            } else if (val == 2) {
                $('.cert_add_row').hide();
            }
        }
    </script>

<script>
        changeHandleBy();
         function changeHandleBy() {
            var handle_type = $("#handle_type").val();
            if (handle_type == "Inhouse") {
                $('.handle_person').show();
                $('.handle_other_person').hide();
                $('.handle_other_mobile').hide();
            } else if (handle_type == "Others") {
                $('.handle_other_person').show();
                $('.handle_other_mobile').show();
                $('.handle_person').hide();
            }
        }
    </script>
    <script>
         document.addEventListener("DOMContentLoaded", function () {
         $('#branch_name').on('change', function() {
                var branch_id = $(this).val();
                  $.ajax({
                      url: "{{ route('branch_all_staff') }}",
                      type: "GET",
                      data: { branch_id: branch_id },
                      success: function(response) {
                          if (response.status === 200 && response.data) {
                              var selectDropdown = $('#handle_person');
                              selectDropdown.empty().append('<option value="">Select Handle staff</option>');
                              response.data.forEach(function(staff) {
                                var option = $('<option></option>')
                                    .attr('value', staff
                                        .sno)
                                    .text(staff.staff_name + " - "+staff.position_name);
                                selectDropdown.append(option);
                            });
                          } else {
                              console.error('Error fetching Job Role:', response);
                          }
                      },
                      error: function(error) {
                          console.error('Error fetching Job Role:', error);
                      }
                  });
              });
              var branch_id = $('#branch_name').val();
              var handle_staff_id = $('#handle_staff_id').val();
                  $.ajax({
                      url: "{{ route('branch_all_staff') }}",
                      type: "GET",
                      data: { branch_id: branch_id },
                      success: function(response) {
                          if (response.status === 200 && response.data) {
                              var selectDropdown = $('#handle_person');
                              selectDropdown.empty().append('<option value="">Select Handle staff</option>');
                              response.data.forEach(function(staff) {
                                var option = $('<option></option>')
                                    .attr('value', staff
                                        .sno)
                                    .text(staff.staff_name + " - "+staff.position_name);
                                    if(handle_staff_id){
                                        if (staff.sno == handle_staff_id) {
                                            option.attr('selected', 'selected');
                                        }

                                    }
                                selectDropdown.append(option);
                            });
                          } else {
                              console.error('Error fetching Job Role:', response);
                          }
                      },
                      error: function(error) {
                          console.error('Error fetching Job Role:', error);
                      }
                  });
         })
    </script>
    
<script>
    $(document).ready(function() {
        var data = @json($event_data); // This is the full event data
        var tags = @json($event_data->event_key_tag ?? []); // This is the decoded event key tags
        
        // If tags is not empty, set the value and initialize Tagify
        if (tags.length > 0) {
            $('#event_Key_tag').val(tags.map(tag => tag.value)); // Set the values of the tags
        }

        // Initialize Tagify only once the DOM is ready
        const event_keyTagEl = document.querySelector('#event_Key_tag');
        let whitelist = ["Workshop", "Learning", "Training", "Skills Development", "Networking"];
        
        // Initialize Tagify with a timeout only if needed, otherwise directly
        setTimeout(function() {
            initializeTagifyEvent();
        }, 1000);

        function initializeTagifyEvent() {
            // Initialize Tagify with the updated whitelist
            let KnowledgeTag = new Tagify(event_keyTagEl, {
                whitelist: whitelist,
                maxTags: 500,
                dropdown: {
                    maxItems: 1000,
                    classname: 'tags-inline',
                    enabled: 0,
                    closeOnSelect: true
                }
            });

            KnowledgeTag.DOM.dropdown.style.zIndex = '9999';
        }
    });
</script>

@endsection
