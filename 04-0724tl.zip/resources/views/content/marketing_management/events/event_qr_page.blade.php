@extends('layouts/blankLayout')

@section('title', 'Apply Event')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection
@section('content')
<link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Black Han Sans" rel="stylesheet">
<style>
    body {
        background: transparent !important;
    }


    .bg_img {
          position: relative;
        background-image: url('../../../../assets/phdizone_images/discount/izone_bg.jpg');
        background-size: cover !important;
        background-repeat: no-repeat;
        background-position: center;
        /* border-radius: 10px !important; */
    }
    .bg_img::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        /*background-color: rgba(135, 206, 235, 0.5); */
        z-index: 1;
    }
    
    /* Ensure your content inside .bg_img appears above the overlay */
    .bg_img > * {
        position: relative;
        z-index: 2;
    }

    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }

   /* Wrapper for layout flexibility */
    .catalogue-title-wrapper {
        text-align: center;
        /*margin-bottom: 20px;*/
    }
    
    /* Professional Heading Style */
    .catalogue-title {
        font-family: 'Black Han Sans', sans-serif;
        font-size: 2.5rem;
        font-weight: 800;
        color: #f7c839;
        letter-spacing: 1.5px;
        position: relative;
        display: inline-block;
        padding-bottom: 10px;
        line-height: 1.2;
    }
    
    /* Responsive adjustment for tablets and mobile */
    @media (max-width: 768px) {
        .catalogue-title {
            font-size: 2rem;
        }
    }
    
    @media (max-width: 480px) {
        .catalogue-title {
            font-size: 1rem;
            /*padding-top: 20px; */
             font-family: 'Poppins', sans-serif;
        }
        .mobile_view_input{
            padding:20px;
        }
    }
    
    /* Elegant underline effect */
    .catalogue-title::after {
        content: '';
        position: absolute;
        left: 50%;
        bottom: 0;
        width: 60%;
        height: 4px;
        background: linear-gradient(90deg, #8e836d, #93bbff);
        transform: translateX(-50%);
        border-radius: 2px;
        transition: width 0.3s ease;
    }
    
    /* Optional Hover Effect */
    .catalogue-title:hover::after {
        width: 80%;
    }

    .txt_efft_label {
        -webkit-text-stroke: 0.3px rgb(157 95 95);
        transition: all 250ms;
        text-shadow: 20px 1px 20px rgb(255 255 255);
    }
    .w-70{
        width:70% !important;
    }
    select.form-select {
    text-align: left !important;
}
</style>

@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<div class="d-flex justify-content-center">
     <div class="mt-0 w-lg-45 w-md-100 w-sm-100">
        <div class="border border-gray-500i bg_img  text-center p-4">
           
             <div class="">
                 <div class="mb-1 mt-2">
                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" class="w-xs-75 w-sm-50 w-md-50 w-lg-50">
                </div>
                <div class="catalogue-title-wrapper mt-4">
                    <h1 class="catalogue-title ">Apply Now</h1>
                </div>
                <div class="d-flex justify-content-center align-items-center flex-column w-100 bg-transparent p-3 fs-5 mb-2">
                      <h4 class="text-center text-white">{{$QR_data->event_name}}</h4>
                    <div class="d-flex flex-column align-items-center  p-2 rounded " style="border:1px solid white;">
                        <div class="text-start">
                            <span class="mdi mdi-calendar-month text-white fw-bold "></span>
                            <span  class="text-white">{{date($common_date_format,strtotime($QR_data->event_date))}}</span>
                        </div>
                        <div class="text-start">
                            <span class="mdi mdi-clock-outline text-white fw-bold"></span>
                            <span class="text-white">{{ date('h:i A', strtotime($QR_data->start_time)) }} - {{ date('h:i A', strtotime($QR_data->end_time)) }}</span>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-start mobile_view_input">
                    <input type="hidden" name="event_id" id="event_id" value="{{$QR_data->sno}}"/>
                    <div>
                    <div class="w-100 mb-5">
                       <label class="text-white float-start mb-1 fs-6 fw-semibold txt_efft_label">Enter Your Mobile No<span class="text-white">*</span></label>
                        <div class="input-group mb-4 shadow-sm rounded">
                             <span class="input-group-text bg-primary text-white"><i class="mdi mdi-phone"></i></span>
                            <input type="text" class="form-control" placeholder="Enter Your Mobile No" id="mobile_number" maxlength="10" placeholder="Enter Mobile Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                        </div>
                        <div class="text-center mt-1" id="mobile_div" style="display:none;">
                            <span class="bg-danger rounded fw-bold fs-7 text-white text-start border border-white px-2 py-1" id="mobile_number_err"></span>
                        </div>
                    </div>
                    <div class="w-100 mb-5">
                        <label class="text-white float-start mb-1 fs-6 fw-semibold txt_efft_label">Enter Your Name<span class="text-white">*</span></label>
                        <div class="input-group mb-4 shadow-sm rounded">
                            <span class="input-group-text bg-primary text-white"><i class="mdi mdi-account"></i></span>
                        <input type="text" class="form-control" placeholder="Enter Your Name" id="lead_name"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"/>
                        </div>
                        <div class="text-center mt-1" id="name_div" style="display:none;"> 
                            <span class="bg-danger rounded fw-bold fs-7 text-white text-start border border-white px-2 py-1" id="lead_name_err"></span>
                        </div>
                    </div>
                    <div class="w-100 mb-5">
                        <label class="text-white float-start mb-1 fs-6 fw-semibold txt_efft_label">Enter Your Email</label>
                        <div class="input-group mb-4 shadow-sm rounded">
                        <span class="input-group-text bg-primary text-white"><i class="mdi mdi-email"></i></span>
                        <input type="text" class="form-control" placeholder="Enter Your Email" id="lead_email"  oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toLowerCase(); });"/>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
             <button type="button" id="generateBtn" class="btn fw-bold btn-primary border border-white mb-2" onclick="apply_event()">
              <span class="btn-text">Apply</span>
              <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
            </button>
        </div>
    </div>
</div>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>


function apply_event() {
    var event_id = document.getElementById('event_id').value.trim();
    var mobile = document.getElementById('mobile_number').value.trim();
    var name = document.getElementById('lead_name').value.trim();
    var email = document.getElementById('lead_email').value.trim();
    // var branchElement = document.getElementById('branchId');
    // var branch_id = branchElement ? branchElement.value.trim() : '';
    const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

    $('#mobile_number_err, #lead_name_err, #branch_name_err').html('');
    $('#mobile_div, #name_div, #branch_id_div').hide();

    if (mobile === '' || !mobilePattern.test(mobile)) {
        $('#mobile_div').show();
        $('#mobile_number_err').html('Enter a valid 10-digit Mobile Number is Required.');
        return;
    }

    if (name === '') {
        $('#lead_name_err').text('Enter Your Name is Required.');
        $('#name_div').show();
        return;
    }
   


    // Disable button and show loader
    const btn = document.getElementById('generateBtn');
    btn.disabled = true;
    btn.querySelector('.btn-text').textContent = 'Applying...';
    btn.querySelector('.spinner-border').classList.remove('d-none');

    $.ajax({
        url: '{{ route("checkEventMobileExists") }}',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        data: JSON.stringify({ mobile: mobile ,event_id:event_id}),
        success: function(response) {
            if (response.exists) {
                $('#mobile_div').show();
                $('#mobile_number_err').text('This mobile number is already registered.');
                resetBtn();
            } else {
               
                $.ajax({
                    url: '{{ route("add_qr_event_participant") }}',
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    data: JSON.stringify({
                        lead_mobile: mobile,
                        lead_name: name,
                        lead_email: email,
                        event_id: event_id
                    }),
                    success: function(response) {
                        if (response.success) {
                             const AppliedBtn = document.getElementById('generateBtn');
                                 AppliedBtn.disabled = true;
                                 AppliedBtn.querySelector('.btn-text').textContent = 'Applied';
                                 AppliedBtn.querySelector('.spinner-border').classList.add('d-none');
                            // window.location.href = '/event_applied_successfully/' + response.link;
                                const newTabUrl =  '/event_applied_successfully/' + response.link;
                                const newTab = window.open(newTabUrl, '_blank');
                               
                                setTimeout(() => {
                                        window.close(); 
                                }, 500);
                                
                        } else {
                            $('#mobile_div').show();
                            $('#mobile_number_err').text('Try Again After Some Time.');
                            resetBtn();
                        }
                    },
                    error: function() {
                        $('#mobile_div').show();
                        $('#mobile_number_err').text('Try Again After Some Time.');
                        resetBtn();
                    }
                });
            }
        },
        error: function() {
            $('#mobile_div').show();
            $('#mobile_number_err').text('Error checking mobile number.');
            resetBtn();
        }
    });
}

// Helper function to reset button state
function resetBtn() {
    const btn = document.getElementById('generateBtn');
    btn.disabled = false;
    btn.querySelector('.btn-text').textContent = 'Apply';
    btn.querySelector('.spinner-border').classList.add('d-none');
}


scanner_count_save()
function scanner_count_save() {
    const event_id = {{ $QR_data->sno }};

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            $.ajax({
                url: '{{ route("participant_location_qr") }}',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                data: JSON.stringify({
                    event_id: event_id,
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude
                }),
                success: function (response) {
                    if (response.success) {
                        console.log("Scanner count + location saved");
                    } else {
                        console.log("Error:", response.message);
                    }
                },
                error: function () {
                }
            });
        }, function (error) {
            console.warn("Geolocation failed:", error);
             $.ajax({
                url: '{{ route("participant_location_qr") }}',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                data: JSON.stringify({
                    event_id: event_id,
                })
            });
            
        });
    } else {
        console.warn("Geolocation not supported");
    }
}

</script>

@endsection