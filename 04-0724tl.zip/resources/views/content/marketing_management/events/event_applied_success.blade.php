@extends('layouts/blankLayout')

@section('title', 'Event Applied')

@section('content')
<link href="https://fonts.googleapis.com/css2?family=Wendy+One&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css2?family=Sawarabi+Mincho" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css2?family=Exo+2:wght@300;700;900&display=swap" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Black Han Sans" rel="stylesheet">

<style>
    body {
        background: transparent !important;
        /* font-family: "Sawarabi Mincho", sans-serif !important; */
    }

    .bg_img {
        /* background-image: url('../../../../assets/eapl_images/discount/dis_4.jpeg'), url('../../../../assets/eapl_images/discount/dis.gif'); */
        /* background-size: cover !important;
        background-repeat: no-repeat;
        background-position: center; */
        /* background-position: center center, top right;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, 200px 200px;
        border-radius: 10px !important; */

        background-image: url('../../../../assets/phdizone_images/discount/izone_bg.jpg'), url('../../../../assets/phdizone_images/discount/izone_bg.jpg');
        background-position: center, center center;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, cover;
        background-blend-mode: lighten;
       
    }
    
    
    
    /* For screens 425px and below */
    @media screen and (max-width: 425px) {
        .bg_img {
            background-image: url('../../../../assets/phdizone_images/discount/izone_bg.jpg') !important;
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
            background-blend-mode: initial; /* optional: reset blend mode */
        }
    }

    .bg_img2 {
        background-image: url('../../../../assets/phdizone_images/discount/izone_bg.jpg');
        background-position: center, center center;
        background-repeat: no-repeat, no-repeat;
        background-size: cover, cover;
    }

    .txt_efft {
        text-decoration: none;
        text-align: center;
        line-height: 1;
        /* -webkit-text-stroke: 0.3px rgb(255, 255, 255); */
        -webkit-text-stroke: 0.001px rgb(255, 255, 255);
        transition: all 250ms;
        /* text-shadow: 10px 1px 10px rgb(107, 107, 107); */
        /*text-shadow: 5px 1px 5px #2e145a;*/
    }
    .txt_efft2 {
        text-decoration: none;
        text-align: center;
        line-height: 1;
        /* -webkit-text-stroke: 0.3px rgb(255, 255, 255); */
        -webkit-text-stroke: 1px #2e145a;
        transition: all 250ms;
        /* text-shadow: 10px 1px 10px rgb(107, 107, 107); */
        /*text-shadow: 5px 1px 5px #2e145a;*/
    }

    /* .txt_efft:hover {
        transform: translate(-1px, -1px)
    } */
    @media (max-width: 576px) {
        .comm {
            /*width: 250px !important;*/
            /*height: 250px !important;*/
            font-size: 40px !important;
        }

        .justify-content-xs-center {
            justify-content: center !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {
        .w-sm-100 {
            width: 100% !important;
        }

        .comm {
            /*width: 375px !important;*/
            /*height: 375px !important;*/
            font-size: 40px !important;
        }

        .justify-content-sm-center {
            justify-content: center !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-100 {
            width: 100% !important;
        }

        .comm {
            /*width: 400px !important;*/
            /*height: 400px !important;*/
            font-size: 80px !important;
        }

        .justify-content-md-center {
            justify-content: center !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {
        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-350px {
            width: 350px !important;
        }

        .justify-content-lg-end {
            justify-content: end !important;
        }

        .h-lg-350px {
            height: 350px !important;
        }

        .comm {
            font-size: 70px !important;
        }
    }


    .circle-animation {
        background-color: transparent;
        border-radius: 50%;
        animation: pulse 2s infinite ease-in-out;
        margin: 50px auto;
    }

    @keyframes pulse {
        0% {
            transform: scale(1);
            opacity: 1;
        }

        50% {
            transform: scale(1.1);
            opacity: 1;
        }

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    .button_call_now {
        font-weight: 600 !important;
        font-size: 2rem;
        margin: 0;
        cursor: pointer;
        padding: .1em .3em;
        /*--c: #e3e3e3;*/
        background-color: rgb(0, 38, 255) !important;
        color: rgb(214, 214, 214) !important;
        border: none;
        /*transform: perspective(500px) rotateY(calc(20deg*var(--_i, -1)));*/
        /*text-shadow: calc(var(--_i, -1)* 0.08em) -.01em 0 var(--c),*/
        /*    calc(var(--_i, -1)*-0.08em) .01em 2px #0004;*/
        /*outline-offset: .1em;*/
        /*transition: 0.3s;*/
    }

    /*.button_call_now:hover,*/
    /*.button_call_now:focus-visible {*/
        /*--_p: 0%;*/
        /*--_i: 1;*/
        /*box-shadow: 0px 4px 9px 8px rgba(0, 0, 0, 0.42) !important;*/
    /*}*/

    .button_call_now:active {
        /*text-shadow: none;*/
        /*color: var(--c);*/
        /*box-shadow: inset 0 0 9e9q #0005;*/
        /*transition: 0s;*/
    }


    .button_download {
        font-weight: 600 !important;
        font-size: 2rem;
        margin: 0;
        cursor: pointer;
        padding: .1em .3em;
        --c: #e3e3e3;
        --_i: 1;
        /* Default left tilt */
        background-color: #ff6f00 !important;
        color: rgb(214, 214, 214) !important;
        border: none;
        display: inline-block;
        /*transform: perspective(500px) rotateY(calc(20deg * var(--_i)));*/
        /*text-shadow: calc(var(--_i) * 0.08em) -.01em 0 var(--c),*/
        /*    calc(var(--_i) * -0.08em) .01em 2px #0004;*/
        /*outline-offset: .1em;*/
        /*transition: transform 0.3s, box-shadow 0.3s, text-shadow 0.3s;*/
    }

    .button_download:hover,
    .button_download:focus-visible {
        /*--_i: -1;*/
        /* Reverse to right tilt on hover */
        /*box-shadow: 4px 4px 9px 8px rgba(0, 0, 0, 0.42) !important;*/
    }

    .button_download:active {
        text-shadow: none;
        /*color: var(--c);*/
        /*box-shadow: inset 0 0 9e9q #0005;*/
        /*transition: 0s;*/
    }
    
    .button_accept {
        font-weight: 600 !important;
        font-size: 2rem;
        margin: 0;
        cursor: pointer;
        padding: .1em .3em;
        --c: #e3e3e3;
        --_i: 1;
        /* Default left tilt */
        background-color: #0d8f40 !important;
        color: rgb(214, 214, 214) !important;
        border: none;
        display: inline-block;
        /*transform: perspective(500px) rotateY(calc(20deg * var(--_i)));*/
        /*text-shadow: calc(var(--_i) * 0.08em) -.01em 0 var(--c),*/
        /*    calc(var(--_i) * -0.08em) .01em 2px #0004;*/
        /*outline-offset: .1em;*/
        /*transition: transform 0.3s, box-shadow 0.3s, text-shadow 0.3s;*/
    }

    .button_accept:hover,
    .button_accept:focus-visible {
        /*--_i: -1;*/
        /* Reverse to right tilt on hover */
        /*box-shadow: 4px 4px 9px 8px rgba(0, 0, 0, 0.42) !important;*/
    }

    .button_accept:active {
        text-shadow: none;
        /*color: var(--c);*/
        /*box-shadow: inset 0 0 9e9q #0005;*/
        /*transition: 0s;*/
    }
    
    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>

@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $encryptedValue = $helper->encrypt_decrypt($QR_data->sno, 'encrypt');
    $url = url('/Event-Qr-Verify/' . $encryptedValue);
@endphp
@php
  use Carbon\Carbon;

  // Convert DB date to Carbon instance
  $eventDate = Carbon::parse($QR_data->event_date);
  $startTime = Carbon::parse($QR_data->start_time);
  $endTime   = Carbon::parse($QR_data->end_time);

  $dayNumber   = $eventDate->format('d');       // 02
  $monthName   = $eventDate->format('F');       // August
  $weekDay     = $eventDate->format('l');       // Friday
  $timeRange   = $startTime->format('h:i A') . ' - ' . $endTime->format('h:i A'); // 10:50 AM - 12:30 PM
@endphp

<center>
  <div class="p-5 w-100" style="max-width: 900px;">
    <div class="bg_img h-100 p-4">

      <!-- Top Row: Date Left / Day & Time Right -->
      <div class="d-flex justify-content-between align-items-center mb-4 mt-3" 
           style="margin-left: auto; margin-right: auto; max-width: 600px;">
        
        <!-- Date Section -->
        <div class="text-center text-white">
          <div class="display-4 fw-bold" style="line-height: 1; font-size: 5.2rem;">{{ $dayNumber }}</div>
          <div style="font-size: 2.2rem;">{{ $monthName }}</div>
        </div>
            
        <!-- Day & Time Section -->
        <div class="text-center text-white">
          <div class="" style="font-size: 1.2rem;letter-spacing: 4px;">{{ strtoupper($weekDay) }}</div>
          <div class="fw-semibold" style="font-size: 1rem;">{{ $timeRange }}</div>
        </div>
      </div>

      <!-- Center Content Box -->
      <div class="p-4 border border-2 rounded text-center text-white mb-9" 
           style="border-color: white; margin-left: auto; margin-right: auto; max-width: 600px;">
        <div class="fs-4 mb-2">{{ $QR_data->event_name }}</div>
        <div class="fs-3 fw-bold mb-2">THANK YOU</div>
        <div class="fs-2 fw-bold mb-2">YOUR REGISTER</div>
        <div class="fs-1 fw-bold mb-2">SUCCESSFULLY</div>
        <div class="fs-5 mb-2" style="letter-spacing: 4px;">{{ $QR_data->event_category_name }}</div>
      </div>

      <!-- Event Details Section -->
      <div class="d-flex text-white" style="max-width: 600px; margin-left: auto; margin-right: auto; align-items: stretch;">
        <!-- Vertical Line -->
        <div style="width: 3px; background-color: white; margin-right: 15px;"></div>
        
        <!-- Event Details -->
        <div class="flex-grow-1 mx-3">
          <div class="mb-2">{{ $QR_data->event_description }}</div>
          <div class="d-flex mb-2">
            <div class="me-2 fw-bold">More Info:</div>
            <div>{{ $QR_data->contact_person_mob_no }}</div>
          </div>
        </div>
      </div>

    </div>
  </div>
</center>









<!--<div class="p-5 pb-0 mt-0 w-lg-50 w-md-100 w-sm-100">-->
<!--        <div class="bg_img h-100">-->
<!--            <div class="border border-gray-400i rounded pb-6">-->
<!--                <div class="fs-2hx fw-bold mb-1 mx-3 mt-6">-->
<!--                    <span class="pt-1 bg-transparant txt_efft message1" style="font-family: 'Black Han Sans', sans-serif !important;color:#d7720d !important;" >"Applied Successfully!"</span>-->
<!--                </div>-->
<!--                <div class=" fw-bold mx-3 mt-2">-->
<!--                     <div class="d-block fs-2 my-4 text-white"><span>{{$QR_data->event_name}}</span></div>-->
<!--                </div>-->
                
<!--                <div class="d-flex align-items-center justify-content-center comm  flex-column fw-bold mb-4   " style="">-->
                    
<!--                   <div class="mb-2">-->
<!--                        <img src="{{asset('assets/eapl_images/applied_success.gif')}}" style="width:300px;">-->
<!--                   </div>-->
<!--                </div >-->
<!--                    <div class="row w-100 bg-secondary p-3 fs-5">-->
<!--                        <div class="col-lg-4 text-center border-end text-white">-->
<!--                            <div><span class="mdi mdi-calendar-month fs-4 fw-bold"></span></div>-->
<!--                            <div><span class="fs-4 fw-bold">{{date($common_date_format,strtotime($QR_data->event_date))}}</span></div>-->
<!--                        </div>-->
<!--                        <div class="col-lg-4 text-center border-end text-white">-->
<!--                            <div><span class="mdi mdi-clock-outline fs-4 fw-bold"></span></div>-->
<!--                            <div><span class="fs-4 fw-bold text-nowrap">{{ date('h:i A', strtotime($QR_data->start_time)) }}</span> - <span class="fs-4 fw-bold text-nowrap">{{ date('h:i A', strtotime($QR_data->end_time)) }}</span></div>-->
<!--                        </div>-->
                        
<!--                        <div class="col-lg-4 text-center text-white">-->
<!--                            <div><span class="mdi mdi-account-tie fs-4 fw-bold"></span></div>-->
<!--                            <div><span class="fs-4 fw-bold">Mr.Vijay</span></div>-->
<!--                        </div>-->
<!--                    </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->





@endsection