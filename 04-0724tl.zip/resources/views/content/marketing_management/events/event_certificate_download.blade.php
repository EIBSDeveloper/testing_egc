<html>
<head>
<title>Event Certificate | {{$event_certificate->participant_name }} | Elysium Academy</title>
<style>
  @font-face {
    font-family: 'sofia';
    src: url('{{ public_path("fonts/Sofia-Regular.ttf") }}') format("truetype");
  }

  body {
    margin: 0;
    padding: 0;
  }

  @page {
    size: 1123px 794px;
    margin: 0;
  }

  .certificate {
    width: 1123px;
    height: 794px;
    background-image: url('{{ asset("assets/eapl_images/certificate_template/events_participants.jpg") }}');
    background-size: cover;
    background-repeat: no-repeat;
    position: relative;
  
  }

  .participant_name {
   font-family: 'sofia';
    position: absolute;
    top:300px; left: 120px;
    width: 800px;
    text-align: center;
    font-size: 30px;
    color: #000080;
    font-weight:bold
  }

      .event_name {
        font-family: 'sofia';
        position: absolute;
        top: 380px; left: 420px;
        width: 500px;       /* fixed box */
        text-align: center;
        font-size: 20px;    /* maximum size */
        font-weight: bold;
        color: #000080;
        white-space: nowrap;   /* force single line */
        transform-origin: left center;
        display: inline-block;
        overflow: visible;
    }

  .event_category {
      font-family: 'sofia';
    position: absolute;
    top: 440px; left: 180px;
    font-size: 26px;
    font-weight: bold;
    color: #000080;
  }

  .event_date {
      font-family: 'sofia';
    position: absolute;
    top: 440px; left: 600px;
    font-size: 24px;
    font-weight: bold;
    color: #000080;
  }

  .branch_name {
      font-family: 'sofia';
    position: absolute;
    top: 510px; left: 0;
    width: 1123px;
    text-align: center;
    font-size: 26px;
    font-weight: bold;
    color: #000080;
  }

  .cert_auth_name {
    position: absolute;
    bottom: 100px; left: 450px;
    width: 250px;
    text-align: center;
    font-size: 22px;
    font-weight: bold;
      color:black;
  }


  .cert_auth_sign {
    position: absolute;
    bottom: 30px; left: 450px;
    width: 250px;
  
    text-align: center;
  }

  .cert_auth_sign img {
    width: 150px;
    height: 75px;
    object-fit: contain;
  }
</style>
</head>
<body>
  <div class="certificate">
    <div class="participant_name">
      {{$event_certificate->participant_name ?? '' }}
    </div>

    <div class="event_name">
        {{ $event_certificate->event_name ?? '' }}
    </div>


    <div class="event_category">
      {{ $event_certificate->event_category_name ?? 'Workshop' }}
    </div>

    <div class="event_date">
      {{ $event_certificate->event_date ? date('d-M-Y', strtotime($event_certificate->event_date)) : '' }}
    </div>

    <div class="branch_name">
      {{$event_certificate->branch_name ? $event_certificate->branch_name : ($event_certificate->franchise_name ? $event_certificate->franchise_name :'') }}
    </div>

    <div class="cert_auth_name">
      {{$event_certificate->cert_auth_name ?? '' }}
    </div>

    <div class="cert_auth_sign">
      <img src="{{ asset('branch_cert_auth_attachments/' . $event_certificate->cert_auth_sign) }}" alt="Signature" />
    </div>
  </div>
</body>

</html>
