@extends('layouts/blankLayout')

@section('title', 'Certificate')

@section('content')
 <link href="https://fonts.googleapis.com/css2?family=Just+Another+Hand&family=Sue+Ellen+Francisco&family=Give+You+Glory&family=Stalemate&family=The+Girl+Next+Door&family=Swanky+and+Moo+Moo&family=Grand+Hotel&family=Cedarville+Cursive&family=Sofia&family=Sacramento&family=Leckerli+One&family=Amatic+SC&family=Loved+by+the+King&family=Edu+NSW+ACT+Cursive&display=swap" rel="stylesheet">
<style>


  body {
    background: transparent !important;
    
  }

  table {
    border-collapse: collapse;
    width: 100%;
  }

  table tr,
  td,
  th {
    border: 1px solid #acaaaa;
  }

  .bg_img {
    background-image: url('{{ asset("assets/phdizone_images/certificate_template/events_participants.jpg") }}');
    background-size: contain !important;
    background-repeat: no-repeat;
    position: sticky;
    top: 100%;
  }
  
  .event-name {
   display: block;
   width: 100%;
   font-family: 'sofia';
   color: #000080;
   font-weight: bold;
   letter-spacing: 2px;
   text-align: center;
   white-space: nowrap;
   overflow: hidden;
   font-size: clamp(14px, 2vw, 24px); /* auto-resize between 14px and 24px */
}

    
    


  @page {
    size: A4;
    width: 1123px;
    height: 794px;
  }

  @media print {
    * {
      box-sizing: border-box;
    }

    @page {
      width: 1123px;
      height: 794px;
    }
  }
</style>
<center>
  <div class="bg_img" style="width: 1123px !important;height: 794px !important;font-family:'Mustica Pro' !important;">
    <div class="d-flex align-items-center">
      <div class=" text-center" style="width:68% !important;padding-left: 155px!important;padding-top: 325px !important;font-size:30px !important; font-family: 'sofia';color: #000080;font-weight:bold;letter-spacing: 2px;">{{$event_certificate->participant_name ?? '' }}</div>
      <div style="width:32% !important;padding-top: 325px !important;"></div>
    </div>
    <div class="d-flex align-items-center">
      <div style="width:34% !important;padding-top: 28px !important;"></div>
      <div class="fw-bold event-name " id="event-name" style="width:53% !important;padding-top: 28px !important;font-size:24px !important;font-family:'sofia';color: #000080;font-weight:bold;letter-spacing: 2px;">{{$event_certificate->event_name ?? '' }}</div>
      <div style="width:13% !important;padding-top: 28px !important;"></div>
    </div>
    <div class="d-flex align-items-center">
      <div style="width:12% !important;padding-top: 10px !important;"></div>
      <div class="" style="width:25% !important;padding-top: 28px !important;  font-size:26px !important;font-family:'sofia';color: #000080;font-weight:bold;letter-spacing: 2px;">{{ $event_certificate->event_category_name ?? 'Workshop' }} </div>
      <div style="width:15% !important;padding-top: 34px !important;"></div>
      <div class="fw-bold " style="width:22% !important;padding-top: 28px !important;font-size:24px !important;font-family:'sofia';color: #000080;font-weight:bold;letter-spacing: 2px;">{{ $event_certificate->event_date ? date('d-M-Y', strtotime($event_certificate->event_date))  : '' }}</div>
      <div style="width:29% !important;padding-top: 34px !important;"></div>
    </div>
    <div class="d-flex align-items-center">
      <div style="width:100% !important;padding-top: 34px !important;"></div>
      <div class="fw-bold " style="width:100% !important;padding-top: 26px !important;font-size:26px !important;  white-space: nowrap!important;font-family:'sofia';color: #000080;font-weight:bold;letter-spacing: 2px;">{{$event_certificate->branch_name ? $event_certificate->branch_name : ($event_certificate->franchise_name ? $event_certificate->franchise_name  :'') }}</div>
      <div style="width:100% !important;padding-top: 34px !important;"></div>
    </div>
    <div class="d-flex align-items-center">
      <div style="width:40% !important;padding-top: 101px !important;"></div>
      <div class="fw-bold " style="width:22% !important;padding-top: 101px !important;font-size:22px !important;">{{$event_certificate->cert_auth_name ?? '' }}</div>
      <div style="width:26% !important;padding-top: 101px !important;"></div>
      
    </div>
    <div class="d-flex align-items-center">
      <div style="width:40% !important;padding-top: 10px !important;"></div>
      <div class="fw-bold text-danger" style="width:22% !important;padding-top: 0px !important;font-size:22px !important;">
         <img src="{{ asset('branch_cert_auth_attachments/' . $event_certificate->cert_auth_sign) }}" alt="BH Sign" class="image-input-wrapper w-150px h-75px" /> 
      </div>
      <div style="width:26% !important;padding-top: 10px !important;"></div>
      
    </div>
  </div>
</center>

<script>
//   $(document).ready(function() {
//     window.print()
//   });
</script>
<script>
//     window.addEventListener("load", () => {
//     window.print(); // trigger print dialog
// });
</script>
<script>
function fitTextToContainer(elementId, minFontSize = 12, maxFontSize = 28) {
    const el = document.getElementById(elementId);
    if (!el) return;

    let fontSize = maxFontSize;
    el.style.fontSize = fontSize + "px";

    // Reduce font size until it fits
    while (el.scrollWidth > el.offsetWidth && fontSize > minFontSize) {
        fontSize--;
        el.style.fontSize = fontSize + "px";
    }
}

// Run after page load
window.addEventListener("load", () => fitTextToContainer("event-name"));
</script>

@endsection