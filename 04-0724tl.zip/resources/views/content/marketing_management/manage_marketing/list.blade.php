@extends('layouts/layoutMaster')

@section('title', 'Marketing Campaign')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }

</style>

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Marketing Campaign</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
                </li>
            </ol>
        </nav>
    </div>
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    <div class="card-body">
        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
            {{-- @if(auth()->user()->hasPermission('Marketing Management', 'Export', 'Manage Campaign'))
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="" title="Export" id="export_excel">
                <span class=""><i class="mdi mdi-calendar-export-outline"></i></span>
            </a>
            @endif --}}
            {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                <span><i class="mdi mdi-filter-outline"></i></span>
            </a> --}}
            {{-- @if(auth()->user()->hasPermission('Marketing Management', 'Add Campaign', 'Manage Campaign'))
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_campaign">
                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Campaign
            </a>
            @endif --}}
        </div>
        <div class="branch_filter mb-4" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Branch Type</label>
                    <select id="" class="select3 form-select">
                        <option value="1">All</option>
                        <option value="2">Branch</option>
                        <option value="3">Franchise</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">City</label>
                    <select id="" class="select3 form-select" multiple>
                        <option value="" selected>All</option>
                        <option value="1">Madurai</option>
                        <option value="2">Virudhunagar</option>
                        <option value="3">Thirunelveli</option>
                        <option value="4">Coimbatore</option>
                        <option value="5">Chennai</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">City Short Code</label>
                    <input type="text" class="form-control" id="" placeholder="Enter City Short Code" maxlength="3" />
                </div>
            </div>
            <div class="d-flex justify-content-end">
                <button class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
            </div>
        </div>
        <div class="row">
            <div class="d-flex justify-content-between align-items-center">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
            
                <div class="mb-4">
                    <form id="search_form" method="POST" action="/marketing">
                    @csrf
                        <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control" id="cus_fill" name="cus_fill" value="{{ $cus_fill ?? '' }}" placeholder="Enter search filter"/>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px">Campaign</th>
                            <th class="min-w-100px">Category / Type</th>
                            <th class="min-w-100px">Estimated Amt</th>
                            <th class="min-w-100px">Actual Amt</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-50px">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        @if (isset($marketing))
                        @foreach ($marketing as $market)
                        <tr>
                            <td>
                                <label class="text-truncate max-w-100px text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $market->campaign_name }}">{{ $market->campaign_name }}</label>
                                <div class="d-block"><span class="badge bg-warning fw-bold text-black fs-8">{{ $market->branch_name }} @if($market->branch_name && $market->franchise_name) || @endif {{ $market->franchise_name }}</span></div>
                            </td>
                            <td>
                                <label class="text-truncate max-w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $market->marketing_category_name }}">{{ $market->marketing_category_name }}</label>
                                <div class="d-block fw-semibold text-dark">{{ $market->marketing_type_name }}
                                </div>
                            </td>
                            <td>
                                <label class="badge bg-info rounded fs-7 fw-semibold">
                                    <span class="fs-8"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                                    <span class="fs-7">{{ $market->payment }}</span>
                                </label>
                            </td>
                            <td>
                                <label class="badge bg-success rounded fs-7 fw-semibold">
                                    <span class="fs-8"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                                    <span class="fs-7">{{ $market->total_amount ?? 0 }}</span>
                                </label>
                            </td>
                            <td>
                                @if($market->status == 0)
                                <a href="javascript:;" class="badge bg-primary text-white rounded fw-semibold fs-7" >Scheduled</a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='1' data-bs-target="#kt_modal_not_yet_started" onclick="notStartedModal('{{  $market->sno }}','{{ $market->campaign_name }}')">Not Yet Started</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='2' data-bs-target="#kt_modal_on_progress" onclick="onProgressModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Progress</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='3' data-bs-target="#kt_modal_on_hold" onclick="onHoldModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Hold</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='4' data-bs-target="#kt_modal_complete" onclick="completeModal('{{  $market->sno }}','{{ $market->campaign_name }}')">Complete</a>
                                </div>
                                @elseif($market->status === 1)
                                <a href="javascript:;" class="badge bg-warning text-black rounded fw-semibold fs-7" >Not Yet Started</a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='2' data-bs-target="#kt_modal_on_progress" onclick="onProgressModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Progress</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='3' data-bs-target="#kt_modal_on_hold" onclick="onHoldModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Hold</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='4' data-bs-target="#kt_modal_complete" onclick="completeModal('{{  $market->sno }}','{{ $market->campaign_name }}')">Complete</a>
                                </div>
                                @elseif($market->status === 3)
                                <a href="javascript:;" class="badge bg-info text-white rounded fw-semibold fs-7" >On Progress</a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='3' data-bs-target="#kt_modal_on_hold" onclick="onHoldModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Hold</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='4' data-bs-target="#kt_modal_complete" onclick="completeModal('{{  $market->sno }}','{{ $market->campaign_name }}')">Complete</a>
                                </div>
                                @elseif($market->status === 4)
                                <a href="javascript:;"  class="badge bg-danger text-white rounded fw-semibold fs-7" >On Hold</a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='2' data-bs-target="#kt_modal_on_progress" onclick="onProgressModal('{{  $market->sno }}','{{ $market->campaign_name }}')">On Progress</a>
                                    <a href="javascript:;" class="dropdown-item fw-semibold fs-7" data-bs-toggle="modal" value='4' data-bs-target="#kt_modal_complete" onclick="completeModal('{{  $market->sno }}','{{ $market->campaign_name }}')">Complete</a>
                                </div>
                                @elseif($market->status === 5)
                                    <label class="badge bg-success text-white rounded fw-semibold fs-7">Completed</label>
                                @endif
                            </td>  
                            <td>
                                <span class="text-end">
                                    @php
                                    $encryptedValue = $helper->encrypt_decrypt($market->sno, 'encrypt');
                                    $verify_activity_url = url('manage_marketing/verify_activity/' . $encryptedValue);
                                    $verify_activity_edit_url = url('manage_marketing/verify_activity_edit/' . $encryptedValue);

                                    $view_url = url('manage_marketing/view_activity/' . $encryptedValue);
                                    $chapter = $helper->get_verify_activity_count($market->sno) ?? '';

                                    $cha_count=0;

                                    if($chapter){
                                        if(isset($chapter->checklist)){
                                        $cha_count = 1;
                                    }

                                    }
                                    // echo $cha_count; D:\Xampp_8.2.4\htdocs\eapl_7_10_2024\resources\views\content\marketing_management\verify_activity_edit.blade.php
                                    @endphp
                                    @if(auth()->user()->hasPermission('Marketing Management', 'View', 'Marketing Campaign'))
                                        <a href="{{$view_url }}">
                                            <span><i class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                            {{-- <span>View</span> --}}
                                        </a>
                                    @endif
                                </span>
                            </td>
                        </tr>
                        @endforeach
                        @endif
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $marketing->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - Update Campaign-->
<div class="modal fade" id="kt_modal_update_campaign" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Update Campaign</h3>
                </div>
                <div class="container-xxl">
                    <form id="edit_mar_form" action="{{ route('marketing_update') }}" method="POST">
                        @csrf
                        <div class="row">
                            {{-- {{$edit}} --}}
                            <input type="hidden" name="sno_edit" id="sno_edit">
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                                <select id="branch_select_edit" name="branch_select_edit" class="select3 form-select" data-placeholder="Select Branch" data-parent-dropdown="#kt_modal_update_campaign">
                                  @if($branch)
                                  @foreach($branch as $b_list)
                                    <option value="{{ $b_list->sno }}" 
                                        @if(isset($branch_select_edit) && $branch_select_edit == $b_list->sno) selected @endif>
                                        @if($b_list->branch_type == 1)
                                            {{ $b_list->branch_name }}
                                        @elseif($b_list->branch_type == 2)
                                            {{ $b_list->franchise_name }}
                                        @endif
                                    </option>                                
                                  @endforeach
                              @endif
                              </select>
                                <div class="text-danger" id="branch_select_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Campaign Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="camp_name" name="camp_name" placeholder="Enter Campaign Name" />
                                <div class="text-danger" id="camp_name_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                                <select id="cat_id_edit" name="cat_id_edit" class="select3 form-select cat_id_edit" onchange="category_change_edit(this.value)">
                                    <option value="">Select Category</option>

                                </select>
                                <div class="text-danger" id="cat_id_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                                <select id="type_id_edit" name="type_id_edit" class="select3 form-select">
                                    <option value="">Select Type</option>

                                </select>
                                <div class="text-danger" id="type_id_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="vendor_edit_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Vendor<span class="text-danger">*</span></label>
                                <select id="vendor_id_edit" name="vendor_id_edit" class="select3 form-select">
                                    <option value="">Select Vendor</option>

                                </select>
                                <div class="text-danger" id="vendor_id_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="cound_edit_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Count<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="cound_edit" name="cound_edit" placeholder="Enter Count" />
                                <div class="text-danger" id="cound_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="schedule_date_edit_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Schedule<span class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="schedule_date_edit" name="schedule_date_edit" placeholder="YYYY-MM-DD to YYYY-MM-DD" class="form-control flatpickr-range" />
                                </div>
                                <div class=" text-danger" id="schedule_date_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="Payment_edit_show" {{-- style="display: none !important;" --}}>
                                <label class="text-dark mb-1 fs-6 fw-semibold">Payment<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="Payment_edit" id="Payment_edit" placeholder="Enter Payment" />
                                <div class="text-danger" id="Payment_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="zone_id_edit_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Zone<span class="text-danger">*</span></label>
                                <select id="zone_id_edit" name="zone_id_edit" class="select3 form-select" onchange="changeAreaName(this.value)">
                                    <option value="">Select Zone</option>
                                </select>
                                <div class="text-danger" id="zone_id_edit_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="gst_edit_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">GST</label>
                                <input type="text" class="form-control" name="gst_edit" id="gst_edit" placeholder="Enter Payment" />
                                {{-- <div class="text-danger" id="gst_edit_err"></div> --}}
                            </div>
                            <div class="col-lg-6">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="description_edit" name="description_edit" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                        <div class="row mt-4" id="zone_area_edit_show" style="display: none !important;">
                            <div class="col-lg-6">
                                <label class="text-black mb-1 fs-5 fw-semibold" id="zone_nme_edit"></label>
                                <div class="border rounded border-gray-500i">
                                    <div class="row py-1">
                                        <div class="col-lg-7">
                                            <label class="text-black fs-6 fw-semibold px-3">Area</label>
                                        </div>
                                        <div class="col-lg-5">
                                            <label class="text-black fs-6 fw-semibold px-3">Schedule<span class="text-danger">*</span></label>
                                        </div>
                                    </div>
                                    <div class="scroll-y min-h-200px max-h-200px px-3 repeater">
                                        {{-- <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Andarkottaram">Andarkottaram</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Angadimangalam">Angadimangalam</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Arumbanur">Arumbanur</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ayilangudi">Ayilangudi</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Chinnamangalam">Chinnamangalam</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elangiyendal">Elangiyendal</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Idayapatti">Idayapatti</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ilamanur">
                                                Ilamanur</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Isalani">
                                                Isalani</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Kalimangalam">Kalimangalam</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                    <div class="row pt-3 pb-3">
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Kallandhiri">Kallandhiri</div>
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="upd_mark_sch_ind" placeholder="Select Date" class="form-control" value="20-07-2024" />
                                            </div>
                                        </div>
                                    </div> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-8">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="edit_submitbtn" class="btn btn-primary" onclick="EditvalidateForm_marketing()">Update Campaign</button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Campaign-->

<!--begin::Modal - Create Campaign-->
<div class="modal fade" id="kt_modal_create_campaign" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4">
                    <h3 class=" mb-4 text-black text-center">Create Campaign</h3>
                </div>
                <form id="add_marketing_campaign_form" method="POST" action="{{ route('add_marketing') }}">
                    @csrf
                    <div class="container-xxl">
                        <div class="row" id='add_mark_campagain'>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Branch<span class="text-danger">*</span></label>
                                <select id="branch_select" name="branch_select" class="select3 form-select" data-placeholder="Select Branch" data-parent-dropdown="#kt_modal_create_campaign">
                                  @if($branch)
                                      @foreach($branch as $b_list)
                                          <option value="{{ $b_list->sno }}">
                                              @if($b_list->branch_type == 1)
                                                {{ $b_list->branch_name }} <!-- Display branch_name if branch_type == 1 -->
                                              @elseif($b_list->branch_type == 2)
                                                {{ $b_list->franchise_name }} <!-- Display franchise_name if branch_type == 2 -->
                                              @endif
                                          </option>
                                      @endforeach
                                  @endif
                              </select>
                                <div class="text-danger" id="branch_select_err"></div>
                              </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Campaign Name<span class="text-danger">*</span></label>
                                <input type="text" class="form-control campaign_name" id="campaign_name" name="campaign_name" placeholder="Enter Campaign Name" />
                                <div class="text-danger" id="campaign_name_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Category<span class="text-danger">*</span></label>
                                <select required id="mar_cat_select" name="mar_cat_select" class="select3 form-select" onchange="company_change(this.value);">
                                    <option value="">Select Category</option>
                                </select>
                                <div class="text-danger" id="mar_cat_select_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                                <select required id="type_select" name="type_select" class="select3 form-select">
                                    <option value="">Select Type</option>

                                </select>
                                <div class="text-danger" id="type_select_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="vendor_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Vendor<span class="text-danger">*</span></label>
                                <select required id="vendor_select" name="vendor_select" class="select3 form-select">
                                </select>
                                <div class="text-danger" id="vendor_select_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="count_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Count<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="count" name="count" placeholder="Enter Count" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\\..*)\\./g, '$1');" />
                                <div class="text-danger" id="count_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="schedule_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Schedule<span class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="schedule" name="schedule" placeholder="YYYY-MM-DD to YYYY-MM-DD" class="form-control flatpickr-range" />
                                    <div class="text-danger" id="schedule_err"></div>
                                </div>
                            </div>
                            <div class="col-lg-3 mb-3" id="payment_show" {{-- style="display: none !important;" --}}>
                                <label class="text-dark mb-1 fs-6 fw-semibold">Payment<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="payment" name="payment" placeholder="Enter Payment" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\\..*)\\./g, '$1');" />
                                <div class="text-danger" id="payment_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="zone_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Zone<span class="text-danger">*</span></label>
                                <select required id="zone_select" name="zone_select" class="select3 form-select">
                                    <option value="">Select Zone</option>
                                </select>
                                <div class="text-danger" id="zone_select_err"></div>
                            </div>
                            <div class="col-lg-3 mb-3" id="gst_show" style="display: none !important;">
                                <label class="text-dark mb-1 fs-6 fw-semibold">GST</label>
                                <div class="input-group input-group-merge">
                                    <input type="text" id="gst" name="gst" placeholder="Enter Gst" class="form-control " />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" id="description" name="description" placeholder="Enter Description"></textarea>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col-lg-6" id="zone_area_show" style="display: none !important;">
                                <label class="text-black mb-1 fs-5 fw-semibold" id="zone_nme"></label>
                                <div class="border rounded border-gray-500i">
                                    <div class="row py-1">
                                        <div class="col-lg-7">
                                            <label class="text-black fs-6 fw-semibold px-3">Area</label>
                                        </div>
                                        <div class="col-lg-5">
                                            <label class="text-black fs-6 fw-semibold px-3">Schedule<span class="text-danger">*</span></label>
                                        </div>
                                    </div>
                                    <div class="scroll-y min-h-200px max-h-200px px-3">
                                        {{-- <div class="row pt-3 pb-3">
                                                <div class="col-lg-7">
                                                    <div class="d-block text-dark mb-1 fs-6 fw-semibold"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Andarkottaram">Andarkottaram</div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="input-group input-group-merge">
                                                        <span class="input-group-text"><i
                                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                        <input type="text" id="upd_mark_sch_ind"
                                                            placeholder="Select Date" class="form-control"
                                                            value="20-07-2024" />
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="fw-bold my-0 mb-1">
                                            <div class="row pt-3 pb-3">
                                                <div class="col-lg-7">
                                                    <div class="d-block text-dark mb-1 fs-6 fw-semibold"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Angadimangalam">Angadimangalam</div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="input-group input-group-merge">
                                                        <span class="input-group-text"><i
                                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                        <input type="text" id="upd_mark_sch_ind"
                                                            placeholder="Select Date" class="form-control"
                                                            value="20-07-2024" />
                                                    </div>
                                                </div>
                                            </div>
                                            <hr class="fw-bold my-0 mb-1">
                                            <div class="row pt-3 pb-3">
                                                <div class="col-lg-7">
                                                    <div class="d-block text-dark mb-1 fs-6 fw-semibold"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Arumbanur">Arumbanur</div>
                                                </div>
                                                <div class="col-lg-5">
                                                    <div class="input-group input-group-merge">
                                                        <span class="input-group-text"><i
                                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                        <input type="text" id="upd_mark_sch_ind"
                                                            placeholder="Select Date" class="form-control"
                                                            value="20-07-2024" />
                                                    </div>
                                                </div>
                                            </div> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <a href="javascript:;" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</a>
                            <button type="button" id="addbtn" class="btn btn-primary" onclick="AddvalidateForm_campaign()">Create Campaign</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Campaign-->



<!--begin::Modal - Delete Campaign-->
<div class=" modal fade" id="kt_modal_delete_campaign" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="delete_message"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" onclick="deleteQuestionbankType()">Yes,
                    delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Campaign-->

<!--begin::Modal - Not Yet Started Campaign-->
<div class=" modal fade" id="kt_modal_not_yet_started" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Not Yet Started?</div>
            <div class="text-center">
                <label class="text-danger fw-bold fs-5 campaign-name"></label>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Not Yet Started Campaign-->

<!--begin::Modal - On Progress Campaign-->
<div class=" modal fade" id="kt_modal_on_progress" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to On Progress?</div>
            <div class="text-center">
                <label class="text-danger fw-bold fs-5 campaign-name"></label>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="on_progress_message"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal" onclick="Schedule_change()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - On Progress Campaign-->

<!--begin::Modal - On Hold Campaign-->
<div class=" modal fade" id="kt_modal_on_hold" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to On Hold?</div>
            <div class="text-center">
                <label class="text-danger fw-bold fs-5 campaign-name"></label>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="on_hold_message"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal" onclick="Schedule_change()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - On Hold Campaign-->

<!--begin::Modal - Complete Campaign-->
<div class=" modal fade" id="kt_modal_complete" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Complete?</div>
            <div class="text-center">
                <label class="text-danger fw-bold fs-5 campaign-name"></label>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span id="completed_message"></span></div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal" onclick="Schedule_change()">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Complete Campaign-->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }

</style>
<script>
    // Display Toastr messages
    @if(Session::has('toastr'))
    var type = "{{ Session::get('toastr')['type'] }}";
    var message = "{{ Session::get('toastr')['message'] }}";
    toastr[type](message);
    @endif

</script>

<script>
    function AddvalidateForm_campaign() {
        var err = 0;

        var campaign_name = $("#campaign_name").val().trim();
        if (campaign_name === "") {
            $('#campaign_name_err').html('Enter Campaign Name is required...!');
            err++;
        } else {
            $('#campaign_name_err').html('');
        }

        var mar_cat_select = $("#mar_cat_select").val().trim();
        if (mar_cat_select === "") {
            $('#mar_cat_select_err').html('Select Category is required...!');
            err++;
        } else {
            $('#mar_cat_select_err').html('');
        }

        var type_select = $("#type_select").val().trim();
        if (type_select === "") {
            $('#type_select_err').html('Select  Type is required...!');
            err++;
        } else {
            $('#type_select_err').html('');
        }

        // Check if the vendor selection box is visible
        if ($("#vendor_show").is(":visible")) {
            var vendor_select = $("#vendor_select").val().trim();
            if (vendor_select === "") {
                $('#vendor_select_err').html('Select Vendor is required...!');
                err++;
            } else {
                $('#vendor_select_err').html('');
            }
        }

        // Check if the count input is visible
        if ($("#count_show").is(":visible")) {
            var count = $("#count").val().trim();
            if (count === "") {
                $('#count_err').html('Enter Count is required...!');
                err++;
            } else {
                $('#count_err').html('');
            }
        }
        // Check if the count input is visible
        if ($("#count_show").is(":visible")) {
            var count = $("#count").val().trim();
            if (count === "") {
                $('#count_err').html('Enter Count is required...!');
                err++;
            } else {
                $('#count_err').html('');
            }
        }

        // Check if the schedule input is visible
        if ($("#schedule_show").is(":visible")) {
            var schedule = $("#schedule").val().trim();
            if (schedule === "") {
                $('#schedule_err').html('Select Schedule Date is required...!');
                err++;
            } else {
                $('#schedule_err').html('');
            }
        }

        // Check if the payment input is visible
        if ($("#payment_show").is(":visible")) {
            var payment = $("#payment").val().trim();
            if (payment === "") {
                $('#payment_err').html('Enter Payment is required...!');
                err++;
            } else {
                $('#payment_err').html('');
            }
        }

        // Check if the zone selection box is visible
        if ($("#zone_show").is(":visible")) {
            var zone_select = $("#zone_select").val().trim();
            if (zone_select === "") {
                $('#zone_select_err').html('Select Zone is required...!');
                err++;
            } else {
                $('#zone_select_err').html('');
            }
        }

        // $('[data-repeater-item_vancany_info]').each(function() {
        //     var area_date = $(this).find(".area_schedule").val().trim(); // Use `$(this)` to scope to the current item
        //     var errorElement = $(this).find('.area_schedule_err'); // Get the error element for the current item
        //     //if (err == 0) {
        //     if (area_date === "") {
        //         errorElement.html('Enter date is required...!'); // Show error message for this specific input
        //         err++; // Increment error count
        //     } else {
        //         err--;
        //         errorElement.html(''); // Clear error message for this specific input
        //     }
        //     //}
        // });

         // Loop through each repeater item and check if at least one date is provided
         $('[data-repeater-item_vancany_info]').each(function() {
            var area_date = $(this).find(".area_schedule").val().trim();  // Get the value for this area's date
            var errorElement = $(this).find('.area_schedule_err');  // Get the error element for this area

            console.log('Area Date:', area_date);  // Debugging the area date

            // Validate the current date field
            if (area_date === "") {
                // Show error message for the specific date field
                errorElement.html('Enter date is required...!');
                err++;  // Increment error counter for invalid fields
            } else {
                // If a date is selected, clear the error message
                errorElement.html('');
                hasValidDate = true;  // Set flag to true if at least one date is valid

                // Stop further validation after finding a valid date
                return false;  // Exit the loop early
            }
        });
        
        // If there are no errors (err === 0) and we have at least one valid date, submit the form
        if (hasValidDate && err === 0) {
            $('#add_marketing_campaign_form').submit();  // Submit the form
            $('#addbtn').prop('disabled', true);  // Disable the submit button to prevent multiple submissions
        } else {
            // If there are errors or no valid date, re-enable the submit button
            $('#addbtn').prop('disabled', false);
            if (!hasValidDate) {
                errorElement.html("At least one date must be filled in.");
            } else {
                $('#add_marketing_campaign_form').submit();
                $('#addbtn').prop('disabled', true);
            }
        }

         // Loop through each repeating area item
        //  $('[data-repeater-item_vancany_info_edit]').each(function() {
        //     var area_date = $(this).find(".area_schedule_edit").val().trim();  // Get the value for this area
        //     var errorElement = $(this).find('.area_schedule_edit_err'); // Error element for this area
            
        //     // Check if the area_date is empty
        //     if (area_date === "") {
        //         errorElement.html('Enter Date is required...!');  // Show error message for this specific field
        //         err++;  // Increment error count
        //     } else {
        //         errorElement.html('');  // Clear error message for this specific field
        //         hasValidDate = true; // Mark that we have at least one valid date
        //     }
        // });

        // if (hasValidDate && err === 0) {
        //     // Proceed with form submission if there's at least one valid date and no errors
        //     $('#edit_mar_form').submit();
        //     $('#edit_submitbtn').prop('disabled', true);
        // } else {
        //     // If no valid date, or errors still exist, prevent submission and show alert
        //     if (!hasValidDate) {
        //         errorElement.html("At least one date must be filled in.");
        //     } else {
        //         errorElement.html('');
        //     }
        //     $('#edit_submitbtn').prop('disabled', false);
        // }


        //Submit form if no errors
        // if (err === 0) {
        //     $('#add_marketing_campaign_form').submit();  // Submit the form
        //     $('#addbtn').prop('disabled', true);  // Disable the submit button to prevent multiple submissions
        // } else {
        //     // If there are errors, re-enable the submit button so the user can fix them
        //     $('#addbtn').prop('disabled', false);
        // }
    }

</script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    // Initialize Flatpickr for the input field
    flatpickr("#schedule", {
        mode: "range"
        , dateFormat: "Y-m-d"
        , onClose: function(selectedDates) {
            // Set the value in the input field if dates are selected
            if (selectedDates.length === 2) {
                const start = selectedDates[0].toISOString().split('T')[0];
                const end = selectedDates[1].toISOString().split('T')[0];
                document.getElementById('schedule').value = start + ' to ' + end;
            } else {
                // Clear the input if the range is not selected properly
                document.getElementById('schedule').value = '';
            }
        }
    });

    function fetchDate() {
        //alert('fetchDate');

        // Set the desired start and end dates
        var start = '2024-09-05';
        var end = '2024-09-27';

        // Create the date range string
        var dateRange = start + ' to ' + end;

        // Manually set the value in the input field
        document.getElementById('schedule').value = dateRange;

        // Optionally, trigger flatpickr to update the selected dates
        const startDate = new Date(start);
        const endDate = new Date(end);
        const flatpickrInstance = flatpickr("#schedule");
        flatpickrInstance.setDate([startDate, endDate]);
    }

</script>

{{--
<script>
    var flatpickrRange = document.querySelector(".flatpickr-range");

    flatpickrRange.flatpickr({
        mode: "range"
    });

</script> --}}


<script>
    $(document).ready(function() {
        $.ajax({
            url: "{{ route('marketing_category') }}"
            , type: "GET"
            , success: function(response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('#mar_cat_select');
                    selectDropdown.empty();
                    selectDropdown.append($('<option></option>').attr('value', '').text('Select Category'));
                    response.data.forEach(function(category) {
                        selectDropdown.append($('<option></option>').attr('value', category.sno).text(category.marketing_category_name));
                    });
                }
            }
            , error: function(error) {
                console.error('Error fetching marketing categories:', error);
            }
        });
    });

    function company_change(categoryId) {
        if (!categoryId) {
            $('#type_select').empty().append($('<option></option>').attr('value', '').text('Select Type'));
            return; // Exit the function if categoryId is invalid
        }

        $.ajax({
            url: "{{ url('type_dropdown') }}/" + categoryId, // Include categoryId in the URL
            type: "GET"
            , success: function(response) {
                console.log('response', response);
                if (response.status === 200 && response.data) {
                    // Clear previous options and append default option
                    var selectDropdown = $('#type_select');
                    selectDropdown.empty();
                    selectDropdown.append($('<option></option>').attr('value', '').text('Select Type'));
                    response.data.forEach(function(category) {
                        selectDropdown.append($('<option></option>').attr('value', category.sno).text(category.marketing_type_name));
                    });
                    // Add change event listener to the dropdown
                    selectDropdown.on('change', function() {
                        var selectedValue = $(this).val();
                        var selectedData = response.data.find(function(category) {
                            return category.sno == selectedValue;
                        });
                        if (selectedData) {
                            type_based_change_func(selectedData);
                        }
                    });
                    // Call the function to handle the selected response
                    type_based_change_func(response.data);
                }
            }
            , error: function(error) {
                console.error('Error fetching marketing types:', error);
            }
        });
    }

</script>
<script>
    function type_based_change_func(response) {
        console.log('selected data', response);
        var vendor_select = document.getElementById("vendor_show");
        var count = document.getElementById("count_show");
        var schedule = document.getElementById("schedule_show");
        var payment = document.getElementById("payment_show");
        var gst = document.getElementById("gst_show");
        var zone_select = document.getElementById("zone_show");
        var zone_area_show = document.getElementById("zone_area_show");

        if (response.vendor_chk == 1) {
            vendor_select.style.display = "block";
        } else {
            vendor_select.style.display = "none";
        }
        if (response.count_chk == 1) {
            count.style.display = "block";
        } else {
            count.style.display = "none";
        }

        if (response.zone_chk == 1) {
            zone_select.style.display = "block";
            zone_area_show.style.display = "block";
        } else {
            zone_select.style.display = "none";
            zone_area_show.style.display = "none";
        }

        if (response.schedule_chk == 1) {
            schedule.style.display = "block";
        } else {
            schedule.style.display = "none";
        }
        if (response.gst_chk == 1) {
            gst.style.display = "block";
        } else {
            gst.style.display = "none";
        }

    }

</script>

<script>
    $(document).ready(function() {

        $.ajax({
            url: "{{ route('vendor_dropdown') }}"
            , type: "GET"
            , success: function(response) {
                if (response.status === 200 && response.data) {
                    // Populate the select dropdown with fetched course categories
                    var selectDropdown = $('select[name="vendor_select"]');
                    selectDropdown.empty();
                    selectDropdown.append($(
                        '<option value="">Select vendor</option>'));
                    response.data.forEach(function(category) {
                        selectDropdown.append($('<option></option>').attr('value', category
                                .sno)
                            .text(category.marketing_vendor_name));
                    });
                }
            }
            , error: function(error) {
                console.error('Error fetching marketing vendor:', error);
            }
        });
    });

</script>

<script>
    $(document).ready(function() {
        // Populate the zone dropdown on page load
        $.ajax({
            url: "{{ route('zone_dropdown') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('select[name="zone_select"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Zone</option>'));
                    response.data.forEach(function(category) {
                        selectDropdown.append($('<option></option>').attr('value', category.sno).text(category.zone_name));
                    });
                }
            },
            error: function(error) {
                console.error('Error fetching zones:', error);
            }
        });

        // Handle dropdown change event to fetch and display areas
        $('select[name="zone_select"]').on('change', function() {
            var selectedZone = $(this).val();
            var selectedBranch = $('#branch_select').val();
            // alert(selectedBranch);

            if (selectedZone) {
                $.ajax({
                    url: "{{ route('zone_dropdown_area') }}", // Update this URL to your route for fetching areas
                    type: "GET",
                    data: { zone_id: selectedZone, 
                        branch_id: selectedBranch
                     },
                     success: function(response) {
                        console.log('Response:', response);
                        if (response.status === 200 && response.data) {
                            var areasContainer = $('.scroll-y');
                            areasContainer.empty(); // Clear existing areas
                            var inputIndex = 0; // Initialize a separate index for inputs

                            response.data.forEach(function(area) {
                                console.log('Area:', area);

                                // Check if zone_area_name is a string or an array
                                var zoneAreaNames = Array.isArray(area.zone_area_name) 
                                    ? area.zone_area_name // If it's already an array
                                    : tryParseJson(area.zone_area_name); // Otherwise, try to parse it

                                console.log('Parsed zoneAreaNames:', zoneAreaNames);

                                // If it's a string (after parsing), make it an array with a single value
                                if (typeof zoneAreaNames === 'string') {
                                    zoneAreaNames = [zoneAreaNames];
                                }

                                // Loop through each area name (now guaranteed to be an array)
                                zoneAreaNames.forEach(function(areaObj) {
                                    // If it's a single string (not parsed as JSON), treat it as a simple object
                                    if (typeof areaObj === 'string') {
                                        areaObj = { id: inputIndex, value: areaObj };
                                    }

                                    var areaId = areaObj.id;
                                    var areaValue = areaObj.value;

                                    // Increment the index for the next input
                                    inputIndex++;

                                    console.log('Area ID:', areaId); // Use console.log instead of alert

                                    // Create HTML structure for each area
                                    var areaHtml = `
                                        <div class="row pt-3 pb-3" data-repeater-item_vancany_info>
                                            <div class="col-lg-7">
                                                <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" id="zone_area_name_${areaId}" name="zone_area_name[]" data-bs-placement="bottom" title="${areaValue}">
                                                    ${areaValue}
                                                </div>
                                                <input type="hidden" name="zone_area_id[]" value="${areaId}" />
                                                <input type="hidden" name="zone_area_name[]" value="${areaValue}" />
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="input-group input-group-merge" id="date_valid">
                                                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="area_schedule_${areaId}_${inputIndex}" placeholder="Select Date" name="zone_area_date[]" class="form-control area_schedule common_date_class" />
                                                    <div class="text-danger area_schedule_err" id="area_schedule_err"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr class="fw-bold my-0 mb-1">
                                    `;

                                    // Append the constructed HTML to the areas container
                                    areasContainer.append(areaHtml);
                                });
                            });

                            // Initialize date picker on dynamically added inputs
                            $('.common_date_class').datepicker({
                                dateFormat: 'yyyy-mm-dd' // Specify the date format here
                            });

                            var selectedZoneText = $('select[name="zone_select"] option:selected').text();
                            document.getElementById('zone_nme').textContent = selectedZoneText;
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching areas:', error);
                    }
                });
            } else {
                $('.scroll-y').empty(); // Clear areas if no zone is selected
            }
        });
    });

    // Helper function to safely parse JSON
    function tryParseJson(jsonString) {
        try {
            return JSON.parse(jsonString);
        } catch (e) {
            return jsonString; // Return the original string if parsing fails
        }
    }
</script>




<script>
    // Initialize flatpickr with range selection
    flatpickr("#schedule_date_edit", {
        mode: "range"
        , dateFormat: "Y-m-d"
        , onClose: function(selectedDates) {
            // Set the value in the input field if dates are selected
            if (selectedDates.length === 2) {
                const start = selectedDates[0].toISOString().split('T')[0];
                const end = selectedDates[1].toISOString().split('T')[0];
                document.getElementById('schedule_date_edit').value = start + ' to ' + end;
            }
        }
    });

    function changeAreaName(selectedZone, zone_schedule) {
        // Fetch zones
        if (selectedZone) {
            console.log('ID passed:', selectedZone);
            $.ajax({
                url: "{{ route('zone_dropdown') }}",
                type: "GET",
                data: {
                    zone_id: selectedZone
                },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        console.log('response', response);

                        // Find the zone data based on selectedZone
                        const zoneData = response.data.find(zone => zone.sno == selectedZone);

                        if (zoneData) {
                            let zoneAreaNames = zoneData.zone_area_name;
                            
                            // Check if zone_area_name is a valid JSON string
                            try {
                                zoneAreaNames = JSON.parse(zoneAreaNames);
                            } catch (e) {
                                // If it's not a valid JSON, treat it as a plain string
                                if (typeof zoneAreaNames === 'string') {
                                    zoneAreaNames = [zoneAreaNames]; // Wrap it in an array
                                }
                            }

                            console.log("Zone Area Names:", zoneAreaNames);

                            // Parse the zone schedule
                            const zoneScheduleArr = Array.isArray(zone_schedule) ? zone_schedule : JSON.parse(zone_schedule || '[]');
                            console.log("Zone Schedule:", zoneScheduleArr);
                            const areasContainer = $('.scroll-y');
                            areasContainer.empty(); // Clear existing areas
                            // alert(zoneAreaNames);
                            // Iterate over the zone area names
                            zoneScheduleArr.forEach(function(item) {
                                console.log('Area Item:', item);
                                const areaId = item.id; // Get the area ID
                                const areaName = item.area; // Get the area name
                                let date = ""; // Initialize date
                                // alert(areaName);
                                // Find the corresponding schedule item based on area ID
                                const scheduleItem = zoneScheduleArr.find(scheduleItem => scheduleItem.id == areaId);
                                // alert(scheduleItem); 
                                if (scheduleItem) {
                                    date = scheduleItem.date; // Get the date if the IDs match
                                }
                                

                                const areaHtml = `
                                    <div class="row pt-3 pb-3" data-repeater-item_vancany_info_edit>
                                        <div class="col-lg-7">
                                            <div class="d-block text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip" id="zone_area_id_${areaId}" name="zone_area_name[]" data-bs-placement="bottom" title="${areaName}">
                                                ${areaName}
                                            </div>
                                            <input type="hidden" name="zone_area_id_[]" value="${areaId}" />
                                            <input type="hidden" name="zone_area_name[]" value="${areaName}" />
                                        </div>
                                        <div class="col-lg-5">
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="area_schedule_${areaId}" placeholder="Select Date" name="zone_area_date[]" class="form-control area_schedule_edit common_date_class" value="${date}" />
                                                <div class="text-danger area_schedule_edit_err" id="area_schedule_edit_err"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr class="fw-bold my-0 mb-1">
                                `;

                                // Append the constructed HTML to the areas container
                                areasContainer.append(areaHtml);
                            });

                            // Initialize date picker on dynamically added inputs
                            $('.common_date_class').datepicker({
                                dateFormat: 'yyyy-mm-dd' // Specify the date format here
                            });

                            // Update the displayed zone name
                            const selectedZoneText = $('select[name="zone_id_edit"] option:selected').text();
                            document.getElementById('zone_nme_edit').textContent = selectedZoneText;

                        } else {
                            console.error('Zone data not found for selected zone ID:', selectedZone);
                        }
                    } else {
                        console.error('No data found or incorrect status');
                    }
                },
                error: function(error) {
                    console.error('Error fetching zones:', error);
                }
            });
        } else {
            const areasContainer = $('.scroll-y');
            areasContainer.empty(); // Clear areas if no zone is selected
        }
    }

    function populateUpdateModal(sno) {
        // alert(sno);

        $.ajax({
            url: `/marketing_campaign_edit/${sno}`
            , method: 'GET'
            , dataType: 'json'
            , success: function(data) {
                if (data.status === 200) {
                    const response = data.data; // Correctly define 'response'
                    console.log(response);
                    document.getElementById('camp_name').value = response.campaign_name;
                    document.getElementById('Payment_edit').value = response.payment || '';
                    document.getElementById('cound_edit').value = response.count || '';
                    document.getElementById('description_edit').value = response.description || '';
                    document.getElementById('sno_edit').value = response.sno;
                    document.getElementById('gst_edit').value = response.gst;
                    document.getElementById('branch_select_edit').value = response.branch_id;
                    $('#branch_select_edit').trigger('change');

                    // Extract values
                    var cat_id = response.category_id;
                    var type_id = response.type_id;
                    var zone_id = response.zone_id;
                    var zone_schedule = JSON.parse(response.zone_schedule); // Ensure to parse if needed
                    var start = response.start_date; // Assuming this is in "YYYY-MM-DD" format
                    var end = response.end_date; // Assuming this is in "YYYY-MM-DD" format
                    console.log('start date', start);
                    var dateRange = start + ' to ' + end;

                    // Set the date range in the Flatpickr input
                    const flatpickrInstance = flatpickr("#schedule_date_edit", {
                        mode: "range"
                        , dateFormat: "Y-m-d"
                    , });

                    // Set the dates in Flatpickr instance
                    flatpickrInstance.setDate([start, end]);

                    // Optionally, set the value in the input field if needed
                    document.getElementById('schedule_date_edit').value = dateRange;

                    console.log('category id:', cat_id);

                    $(document).ready(function() {
                        // Load categories, vendors, and zones
                        category_change_edit(cat_id, type_id);
                        loadCategories(cat_id);
                        loadVendors(response.vendor_id); // Access vendor_id from response
                        loadZones(zone_id, zone_schedule);
                    });
                }
            }
            , error: function(jqXHR, textStatus, errorThrown) {
                console.error('Error fetching data:', textStatus, errorThrown);
            }
        });
    }

    function loadCategories(cat_id) {
        $.ajax({
            url: "{{ route('marketing_category') }}"
            , type: "GET"
            , success: function(response) {
                if (response.status === 200 && response.data) {
                    const selectDropdown = $('select[name="cat_id_edit"]');
                    selectDropdown.empty().append($('<option value="">Select Category</option>'));
                    response.data.forEach(function(branch_list) {
                        const option = $('<option></option>').attr('value', branch_list.sno).text(branch_list.marketing_category_name);
                        if (branch_list.sno == cat_id) {
                            option.attr('selected', 'selected');
                        }
                        selectDropdown.append(option);
                    });
                }
            }
            , error: function(error) {
                console.error('Error fetching course categories:', error);
            }
        });
    }

    function loadVendors(vendor_id) {
        $.ajax({
            url: "{{ route('vendor_dropdown') }}"
            , type: "GET"
            , success: function(response) {
                if (response.status === 200 && response.data) {
                    const selectDropdown = $('select[name="vendor_id_edit"]');
                    selectDropdown.empty().append($('<option value="">Select Vendor</option>'));
                    response.data.forEach(function(branch_list) {
                        const option = $('<option></option>').attr('value', branch_list.sno).text(branch_list.marketing_vendor_name);
                        if (branch_list.sno == vendor_id) {
                            option.attr('selected', 'selected');
                        }
                        selectDropdown.append(option);
                    });
                }
            }
            , error: function(error) {
                console.error('Error fetching vendors:', error);
            }
        });
    }

    function loadZones(zone_id, zone_schedule) {
        $.ajax({
            url: "{{ route('zone_dropdown') }}"
            , type: "GET"
            , success: function(response) {
                if (response.status === 200 && response.data) {
                    const selectDropdown = $('select[name="zone_id_edit"]');
                    selectDropdown.empty().append($('<option value="">Select Zone</option>'));
                    response.data.forEach(function(branch_list) {
                        const option = $('<option></option>').attr('value', branch_list.sno).text(branch_list.zone_name);
                        if (branch_list.sno == zone_id) {

                            option.attr('selected', 'selected');
                        }
                        selectDropdown.append(option);
                    });

                    // Call changeAreaName after loading zones to set initial area names
                    changeAreaName(zone_id, zone_schedule);
                }
            }
            , error: function(error) {
                console.error('Error fetching zones:', error);
            }
        });

        // Handle zone selection change
        $(document).on('change', 'select[name="zone_id_edit"]', function() {
            const selectedZone = $(this).val();
            console.log('Selected zone:', selectedZone);
            changeAreaName(selectedZone, zone_schedule);
        });
    }

</script>

<script>
    function category_change_edit(val, type) {
        console.log('type id', val);
        $.ajax({
            url: "/type_dropdown/" + val
            , type: "GET"
            , success: function(response) {
                console.log('Response:', response);
                // Check if the response is valid before proceeding
                if (response.status === 200 && response.data) {
                    var selectDropdown = $('select[name="type_id_edit"]');
                    selectDropdown.empty();
                    selectDropdown.append($('<option value="">Select Type</option>'));

                    response.data.forEach(function(branch_list) {
                        var option = $('<option></option>')
                            .attr('value', branch_list.sno)
                            .text(branch_list.marketing_type_name);
                        // Set the selected option if it matches the current type
                        if (branch_list.sno == type) {
                            option.prop('selected', true);
                        }

                        selectDropdown.append(option);
                    });

                    // Call the function with the initially selected type
                    selectDropdown.change(function() {
                        var selectedValue = $(this).val();
                        var selectedData = response.data.find(function(category) {
                            return category.sno == selectedValue;
                        });
                        if (selectedData) {
                            type_based_change_edit_func(selectedData);

                        }
                    });

                    // Trigger change event for the initial value
                    selectDropdown.change();
                }
            }
            , error: function(error) {
                console.error('Error fetching Campaign Checklist type:', error);
            }
        });
    }

</script>


<script>
    function type_based_change_edit_func(response) {
        console.log('edit data', response);


        var vendor_select = document.getElementById("vendor_edit_show");
        var count = document.getElementById("cound_edit_show");
        var schedule = document.getElementById("schedule_date_edit_show");
        var payment = document.getElementById("Payment_edit_show");
        var gst = document.getElementById("gst_edit_show");
        var zone_select = document.getElementById("zone_id_edit_show");
        var zone_area_show = document.getElementById("zone_area_edit_show");

        if (response.vendor_chk == 1) {
            vendor_select.style.display = "block";
        } else {
            vendor_select.style.display = "none";
            $('select[name="vendor_id_edit"]').val("");
        }
        if (response.count_chk == 1) {
            count.style.display = "block";
        } else {
            count.style.display = "none";
            $("#cound_edit").val("");
        }

        if (response.zone_chk == 1) {
            zone_select.style.display = "block";
            zone_area_show.style.display = "block";
        } else {
            zone_select.style.display = "none";
            zone_area_show.style.display = "none";
            $('select[name="zone_id_edit"]').val("");
        }
        //if (response.payment_chk == 1) {
        //  payment.style.display = "block";
        //} else {
        //  payment.style.display = "none";
        // $("#Payment_edit").val("");
        // }
        if (response.schedule_chk == 1) {
            schedule.style.display = "block";
        } else {
            schedule.style.display = "none";
            $('select[name="schedule_date_edit"]').val("");
        }
        if (response.gst_chk == 1) {
            gst.style.display = "block";
        } else {
            gst.style.display = "none";
            $('select[name="gst_edit"]').val("");
        }

    }

</script>

<script>
    function EditvalidateForm_marketing() {
        var err = 0;
        var hasValidDate = false;

        var campaign_name = $("#camp_name").val().trim();
        if (campaign_name === "") {
            $('#camp_name_err').html('Enter Campaign Name is required...!');
            err++;
        } else {
            $('#camp_name_err').html('');
        }

        var mar_cat_select = $("#cat_id_edit").val().trim();
        if (mar_cat_select === "") {
            $('#cat_id_edit_err').html('Select Category is required...!');
            err++;
        } else {
            $('#cat_id_edit_err').html('');
        }

        var type_select = $("#type_id_edit").val().trim();
        if (type_select === "") {
            $('#type_id_edit_err').html('Select  Type is required...!');
            err++;
        } else {
            $('#type_id_edit_err').html('');
        }

        // Check if the vendor selection box is visible
        if ($("#vendor_edit_show").is(":visible")) {
            var vendor_select = $("#vendor_id_edit").val().trim();
            if (vendor_select === "") {
                $('#vendor_id_edit_err').html('Select Vendor is required...!');
                err++;
            } else {
                $('#vendor_id_edit_err').html('');
            }
        }

        // Check if the count input is visible
        if ($("#cound_edit_show").is(":visible")) {
            var count = $("#cound_edit").val().trim();
            if (count === "") {
                $('#cound_edit_err').html('Enter Count is required...!');
                err++;
            } else {
                $('#cound_edit_err').html('');
            }
        }

        // Check if the schedule input is visible
        if ($("#schedule_date_edit_show").is(":visible")) {
            var schedule = $("#schedule_date_edit").val().trim();
            if (schedule === "") {
                $('#schedule_date_edit_err').html('Select Schedule Date is required...!');
                err++;
            } else {
                $('#schedule_date_edit_err').html('');
            }
        }

        // Check if the payment input is visible
        if ($("#Payment_edit_show").is(":visible")) {
            var payment = $("#Payment_edit").val().trim();
            if (payment === "") {
                $('#Payment_edit_err').html('Enter Payment is required...!');
                err++;
            } else {
                $('#Payment_edit_err').html('');
            }
        }

        // Check if the zone selection box is visible
        if ($("#zone_id_edit_show").is(":visible")) {
            var zone_select = $("#zone_id_edit").val().trim();
            if (zone_select === "") {
                $('#zone_id_edit_err').html('Select Zone is required...!');
                err++;
            } else {
                $('#zone_id_edit_err').html('');
            }
        }

        // Loop through each repeating area item
        $('[data-repeater-item_vancany_info_edit]').each(function() {
            var area_date = $(this).find(".area_schedule_edit").val().trim();  // Get the value for this area
            var errorElement = $(this).find('.area_schedule_edit_err'); // Error element for this area
            
            // Check if the area_date is empty
            if (area_date === "") {
                errorElement.html('Enter Date is required...!');  // Show error message for this specific field
                err++;  // Increment error count
            } else {
                errorElement.html('');  // Clear error message for this specific field
                hasValidDate = true; // Mark that we have at least one valid date
            }
        });

        if (hasValidDate && err === 0) {
            // Proceed with form submission if there's at least one valid date and no errors
            $('#edit_mar_form').submit();
            $('#edit_submitbtn').prop('disabled', true);
        } else {
            // If no valid date, or errors still exist, prevent submission and show alert
            if (!hasValidDate) {
                errorElement.html("At least one date must be filled in.");
            } else {
                errorElement.html('');
            }
            $('#edit_submitbtn').prop('disabled', false);
        }

        // //Submit form if no errors
        // if (err === 0) {

        //     $('#edit_mar_form').submit();
        //     $('#edit_submitbtn').prop('disabled', true);
        // } else {
        //     $('#edit_submitbtn').prop('disabled', false);
        // }
    }

</script>

{{-- DELETE FUNCTION CALL --}}
<script>
    function confirmDelete(id, name) {
        document.querySelector('#kt_modal_delete_campaign .btn-danger').setAttribute(
            'data-id', id);
        $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger">' + name +
            '</b> Marketing Campaign ?');
    }

    function deleteQuestionbankType() {
        var categoryId = document.querySelector('#kt_modal_delete_campaign .btn-danger').getAttribute(
            'data-id');

        fetch('/marketing_campaign_delete/' + categoryId, {
                method: 'DELETE'
                , headers: {
                    'Content-Type': 'application/json'
                    , 'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.error_msg);
                    console.error(data.error_msg);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

</script>

<script>

        function updatestatus(statusId, status) {
    
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/marketing_campaign_status/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status
                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        // alert(data.status);
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        // toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }

        function notStartedModal(id, leadName) {
            $('#kt_modal_not_yet_started').modal('show');
            $('#kt_modal_not_yet_started .campaign-name').text(leadName);
            $('#kt_modal_not_yet_started .btn-primary').off('click').on('click', function() {
                updatestatus(id, 1); // Assuming status 1 is Inactive
                $('#kt_modal_not_yet_started').modal('hide');
            });
        }

        function onProgressModal(id, leadName) {
            $('#kt_modal_on_progress').modal('show');
            $('#kt_modal_on_progress .campaign-name').text(leadName);
            $('#kt_modal_on_progress .btn-primary').off('click').on('click', function() {
                updatestatus(id, 3); // Assuming status 1 is Inactive
                $('#kt_modal_on_progress').modal('hide');
            });
        }

        function onHoldModal(id, leadName) {
            $('#kt_modal_on_hold').modal('show');
            $('#kt_modal_on_hold .campaign-name').text(leadName);
            $('#kt_modal_on_hold .btn-primary').off('click').on('click', function() {
                updatestatus(id, 4); // Assuming status 1 is Inactive
                $('#kt_modal_on_hold').modal('hide');
            });
        }

        function completeModal(id, leadName) {
            $('#kt_modal_complete').modal('show');
            $('#kt_modal_complete .campaign-name').text(leadName);
            $('#kt_modal_complete .btn-primary').off('click').on('click', function() {
                updatestatus(id, 5); // Assuming status 1 is Inactive
                $('#kt_modal_complete').modal('hide');
            });
        }

    // // Define the Schedule_status function
    // function Schedule_status(val, id) {
    //     let modalElement;
    //     let messageElement;
        
    //     // Check if the correct modal exists before accessing
    //     if (val === 1) {
    //         modalElement = document.querySelector('#kt_modal_not_yet_started .btn-danger');
    //         messageElement = $('#not_yet_started');
    //         Schedule_change();
    //     } else if (val === 2) {
    //         modalElement = document.querySelector('#kt_modal_on_progress .btn-danger');
    //         messageElement = $('#on_progress_message');
    //         Schedule_change();
    //     } else if (val === 3) {
    //         modalElement = document.querySelector('#kt_modal_on_hold .btn-danger');
    //         messageElement = $('#on_hold_message');
    //         Schedule_change();
    //     } else if (val === 4) {
    //         modalElement = document.querySelector('#kt_modal_complete .btn-danger');
    //         messageElement = $('#completed_message');
    //         Schedule_change();
    //     }

    //     // If the modal element is found, proceed to set attributes
    //     if (modalElement) {
    //         modalElement.setAttribute('data-id', id);
    //     } 

    //     // Update the message inside the modal
    //     if (messageElement) {
    //         messageElement.html(`Are you sure you want to Change Status to ${getStatusMessage(val)}? <br> <b class="text-danger">`);
    //     } 
    // }

    // function getStatusMessage(val) {
    //     switch(val) {
    //         case 1: return 'Not Yet Started';
    //         case 2: return 'On Progress';
    //         case 3: return 'On Hold';
    //         case 4: return 'Complete';
    //         default: return 'Unknown Status';
    //     }
    // }
    
    // // Function to handle the schedule change logic
    // function Schedule_change() {
    //     var categoryId = document.querySelector('#kt_modal_delete_campaign .btn-danger').getAttribute(
    //         'data-id');

    //     fetch('/marketing_campaign_status/' + categoryId, {
    //             method: 'DELETE'
    //             , headers: {
    //                 'Content-Type': 'application/json'
    //                 , 'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
    //             }
    //         })
    //         .then(response => response.json())
    //         .then(data => {
    //             if (data.status === 200) {
    //                 toastr.success(data.message);
    //                 location.reload();
    //             } else {
    //                 toastr.error(data.error_msg);
    //                 console.error(data.error_msg);
    //             }
    //         })
    //         .catch(error => {
    //             console.error('Error:', error);
    //         });
    // }
</script>


    {{-- <script>
        function exportToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/marketing_campaign/export-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url
                , type: 'GET'
                , success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link
                }
                , error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
        }

        // Event listener for Excel export button
        $('#export_excel').on('click', function(e) {
            e.preventDefault();
            exportToExcel();
        });

    </script> --}}
<script>
    function sort_filter(val) {
        if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
        } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
        }
    }
</script>


<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_"
        , }
        , "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });

</script>
@endsection
