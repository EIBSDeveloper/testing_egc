@extends('layouts/layoutMaster')

@section('title', 'View Campaign')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss'
])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-4 text-black">View Campaign</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Campaign</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-2">
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-domain fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->campaign_name}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-group fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->marketing_category_name}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-text fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Type"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->marketing_type_name}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-text-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->description??'-'}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-counter fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Count"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->count??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cash fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment"></i>
                        </label>
                        <div class="text-info fw-bold fs-6">
                            <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-info fw-bold"></i></label>
                            <label class="fs-6">{{$view->payment??'-'}}</label>
                        </div>
                    </div>
                    @if($view->start_date && $view->end_date)
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-calendar-range fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->start_date ?? '-'}} to {{$view->end_date ?? '-'}}
                        </label>
                    </div>
                    @endif
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-map-marker-radius fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Zone"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->zone_name??'-'}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->marketing_vendor_name??'-'}} </label>
                        <div class="d-block fw-semibold fs-7"></div>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-account-supervisor fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->vendor_contact_person_name??'-'}} </label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cellphone fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Mobile No"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->vendor_contact_person_mobile??'-'}} </label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building-marker fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$view->marketing_vendor_address??'-'}} </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-lg-6 mb-2 d-flex align-items-center">
                <label class="fw-semibold fs-6 me-1">
                    <i class="mdi mdi-text-box-check-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign Checklist"></i>
                </label>
                <label class="text-black fs-5 fw-semibold">Campaign Checklist</label>
            </div>
            @php
                $zone_area_name = json_decode($view->zone_schedule, true);
                $champ_name = $view->camp_checklist;

                if (is_string($champ_name)) {
                    $champ_name = json_decode($champ_name, true); // Decode into an associative array
                }

                $counter = 0; 
                $totalCount = is_array($champ_name) ? count($champ_name) : 0;

                $checklistData = json_decode($view->checklist, true);
                // Initialize array for storing total amounts per area
                $areaTotalAmounts = [];
                
                if ($checklistData) {
                    foreach ($checklistData as $check) {
                        // Only consider checklist entries where checked == 1
                        if ($check['checked'] == 1) {
                            // Add the amount for this area to the total
                            if (!isset($areaTotalAmounts[$check['area']])) {
                                $areaTotalAmounts[$check['area']] = 0;
                            }
                            $areaTotalAmounts[$check['area']] += $check['amount'];
                        }
                    }
                }
                
                // Sum all values in $areaTotalAmounts to get the total amount
                $totalAmount = array_sum($areaTotalAmounts);
            @endphp

            <div class="col-lg-6 mb-2 text-end">
                <div class="badge bg-info fw-bold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Actual Amount">
                    <label class="fs-5"><i class="mdi mdi-currency-rupee fs-5 text-white fw-bold"></i></label>
                    <label class="fs-5">{{ number_format($totalAmount, 2) }}</label>
                </div>
            </div>
            @php
                // Decode the checklist JSON string
                $checklistData = json_decode($view->checklist, true);
                $checklistArray = [];

                // Prepare a lookup array for quick access
                if ($checklistData) {
                    foreach ($checklistData as $check) {
                        $checklistArray[$check['checked']] = $check;
                    }
                }
            @endphp
            @if(isset($view->payment) && isset($view->zone_schedule))
            @if(isset($zone_area_name))
            @foreach($zone_area_name as $key => $value)
            <div class="col-lg-12 mb-4">
                <div class="card-action">
                    <div class="card-header collapse_{{$key}} bg-label-success">
                        <div class="card-action-title">
                            <div class="row">
                                <div class="col-lg-4 d-flex align-items-center">
                                    <div class="form-check form-check-inline">
                                        @php
                                            $isChecked = false;
                                            // Loop through checklistData to see if any item for this area has checked == 1
                                            foreach ($checklistData as $check) {
                                                // Make sure you're accessing the value using array notation, assuming $value is an array
                                                if (isset($value['area']) && $check['area'] == $value['area'] && $check['checked'] == 1) {
                                                    $isChecked = true;
                                                    break; // Exit loop after finding first match
                                                }
                                            }
                                        @endphp
                                        <input class="form-check-input outer_checkbox" 
                                            type="checkbox" 
                                            name="area_name[]" 
                                            id="area_{{$value['id']}}" 
                                            data-index="{{ $key }}" 
                                            disabled
                                            value="{{ $value['area'] }}" 
                                            {{ $isChecked ? 'checked' : '' }} />
                                        <label class="text-black fs-6 fw-bold" 
                                            for="area_{{$value['id']}}">
                                            {{ $value['area'] }}
                                        </label>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-3">
                                    <div class="d-flex align-items-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Count">
                                        <label class="text-dark fs-5 fw-bold">{{$totalCount}}</label>
                                        <label class="text-dark fs-5 fw-bold">/</label>
                                        <label class="text-dark fs-5 fw-bold">{{ $totalCount }}</label>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <div class="badge bg-info fw-bold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Actual Amount">
                                        <label class="fs-5"><i class="mdi mdi-currency-rupee fs-5 text-white fw-bold"></i></label>
                                        <label class="fs-5 amount_display" id="amount_display_{{ $key }}">{{ isset($areaTotalAmounts[$value['area']]) ? number_format($areaTotalAmounts[$value['area']], 2) : '0.00' }}</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-action-element">
                            <ul class="list-inline mb-0">
                                <li class="list-inline-item">
                                    <a href="javascript:;" class="first_zone_add_{{ $key }}"  onclick="up_down_branch({{ $key }})"><i class="mdi mdi-chevron-up fs-3 text-black"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="collapse first_zone_body_add_{{ $key }} border">
                    <div class="card-body">
                        <div class="row">
                            <input type="hidden" name="marketing_sno_edit" id="marketing_sno_edit" value="{{$view->mark_sno}}">
                            <div class="col-lg-12">
                                <div class="row bg-label-danger rounded">
                                    <div class="col-lg-6 mt-2 mb-1 text-black fs-6 fw-semibold">Checklist</div>
                                    <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Amount</div>
                                    <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Reason</div>
                                </div>
                                @if(isset($champ_name))
                                    @foreach($champ_name as $chk_key => $activity)
                                        @php
                                            $amount = ''; // Initialize amount
                                            $reason = ''; // Initialize reason
                                            $isChecked = false; // Default unchecked

                                            // Loop through the checklistData to find the corresponding checklist entry for this activity
                                            foreach ($checklistData as $check) {
                                                // Match the activity to the 'checklist' field in checklistData
                                                if ($check['checklist'] == $activity && $check['checked'] == 1) {
                                                    $amount = $check['amount'];  // Get the corresponding amount
                                                    $reason = $check['reason'];  // Get the corresponding reason
                                                    $isChecked = true;  // Set the checkbox to checked if the condition is met
                                                    break; // Exit the loop after finding the match
                                                }
                                            }
                                        @endphp

                                        <div class="row mt-2">
                                            <div class="col-lg-6 mb-2 d-flex align-items-center">
                                                <div class="form-check form-check-inline">
                                                    <!-- Checkbox: Check if checklist == 1 and if the 'checked' field is 1 -->
                                                    @php
                                                        // Check if $value is an array, then use the array index for 'area'
                                                        $area = isset($value['area']) ? $value['area'] : ''; // Access 'area' key in case of an array
                                                    @endphp
                                                    <input class="form-check-input activity_chk" type="checkbox" 
                                                        id="activity_{{ $chk_key }}{{ $area }}" 
                                                        name="activity_{{ $area }}[{{ $chk_key }}][checked]" 
                                                        data-index="{{ $key }}" 
                                                        value="1"
                                                        disabled
                                                        {{ $isChecked ? 'checked' : '' }} 
                                                        onchange="toggleAmountField({{ $chk_key }}, '{{ $area }}')" />

                                                    <label class="text-dark fs-6 fw-semibold" for="activity_{{ $chk_key }}_{{ $area }}">
                                                        {{ $activity }}
                                                    </label>

                                                    <input type="hidden" name="activity_{{ $area }}[{{ $chk_key }}][activity]" value="{{ $activity }}" />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <input type="text" class="form-control amount-input checklist_amount" name="checklist_amount_{{ $area }}[{{ $chk_key }}]" id="checklist_amount_{{ $chk_key }}{{ $area }}" data-index="{{ $key }}" placeholder="Enter Amount" value="{{ $amount }}"
                                                oninput="calculateTotal({{ $key }})" />
                                            </div>
                                            <div class="col-lg-3">
                                                <textarea class="form-control fs-6" rows="1"
                                                        id="checklist_reason_{{ $chk_key }}_{{ $area }}" 
                                                        name="checklist_reason_{{ $area }}[{{ $chk_key }}]"
                                                        placeholder="Enter Reason">
                                                    {{ $reason ?? '-' }}
                                                </textarea>
                                            </div>
                                        </div>
                                    @endforeach
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            @endif
            @endif
        </div>
    </div>
</div>

<!--Create Zone Accordion Start-->
<script>
    function up_down_branch(id) {
        // Get all chevron elements with the specific class for each card
        const chevronElement = document.querySelector('.first_zone_add_' + id);
        
        if (chevronElement) {
            // Add click event listener to that specific chevron
            chevronElement.addEventListener('click', function(event) {
                event.preventDefault();
                
                // Get the specific card header containing the chevron
                const cardHeader = chevronElement.closest('.card-header');
                
                // Find the corresponding collapse body within the same card
                const collapseElement = cardHeader.closest('.card').querySelector('.collapse.first_zone_body_add_' + id);
                
                if (collapseElement) {
                    // Collapse the target element
                    const collapseInstance = new bootstrap.Collapse(collapseElement);
                    
                    // Toggle the collapse state
                    collapseInstance.toggle();

                    // Toggle the collapsed class for the card header (now scoped to the correct header)
                    cardHeader.classList.toggle('collapsed');
                    
                    // Toggle chevron icon between up and down
                    const icon = chevronElement.querySelector('i');
                    icon.classList.toggle('mdi-chevron-down');
                    icon.classList.toggle('mdi-chevron-up');
                }
            });
        }
    }
</script>
<!--Create Zone Accordion End-->

<!--Create Second Zone Accordion Start-->
<script>
    'use strict';

    (function() {
        const second_zone_add = [].slice.call(document.querySelectorAll('.second_zone_add'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (second_zone_add) {
            second_zone_add.map(function(second_zone_add_Element) {
                second_zone_add_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(second_zone_add_Element.closest('.card').querySelector('.collapse.second_zone_body_add'));
                    // Toggle collapsed class in `.card-header` element
                    second_zone_add_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(second_zone_add_Element.secondElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();

</script>
<!--Create Second Zone Accordion End-->
<script>
    'use strict';

    function up_down_branch(id) {
        const first_zone_add = [].slice.call(document.querySelectorAll('.first_zone_add_' + id));
        // Collapsible card
        // --------------------------------------------------------------------
        if (first_zone_add) {
            first_zone_add.map(function(syll_chapter_add_Element) {
                syll_chapter_add_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(syll_chapter_add_Element.closest('.card').querySelector(
                        '.collapse.first_zone_body_add_' + id));
                    // Toggle collapsed class in `.card-header` element
                    syll_chapter_add_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(syll_chapter_add_Element.firstElementChild
                        , 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    }

</script>
<script>
    'use strict';

    function up_down_branch(id) {
        const first_zone_add = [].slice.call(document.querySelectorAll('.first_zone_add_' + id));
        // Collapsible card
        // --------------------------------------------------------------------
        if (first_zone_add) {
            first_zone_add.map(function(syll_chapter_add_Element) {
                syll_chapter_add_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(syll_chapter_add_Element.closest('.card').querySelector(
                        '.collapse.first_zone_body_add_' + id));
                    // Toggle collapsed class in `.card-header` element
                    syll_chapter_add_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(syll_chapter_add_Element.firstElementChild
                        , 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    }

</script>
<!--Create third Zone Accordion Start-->
<script>
    'use strict';

    (function() {
        const third_zone_add = [].slice.call(document.querySelectorAll('.third_zone_add'));

        // Collapsible card
        // --------------------------------------------------------------------
        if (third_zone_add) {
            third_zone_add.map(function(third_zone_add_Element) {
                third_zone_add_Element.addEventListener('click', event => {
                    event.preventDefault();
                    // Collapse the element
                    new bootstrap.Collapse(third_zone_add_Element.closest('.card').querySelector('.collapse.third_zone_body_add'));
                    // Toggle collapsed class in `.card-header` element
                    third_zone_add_Element.closest('.card-header').classList.toggle('collapsed');
                    // Toggle class mdi-chevron-down & mdi-chevron-up
                    Helpers._toggleClass(third_zone_add_Element.thirdElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });
        }

    })();

</script>
<!--Create third Zone Accordion End-->

@endsection
