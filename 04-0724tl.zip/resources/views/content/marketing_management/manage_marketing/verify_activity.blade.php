@extends('layouts/layoutMaster')

@section('title', 'Verify Campaign Checklist')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/jquery-repeater/jquery-repeater.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms_file_upload.js')
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="mb-4 text-black">Verify Campaign Checklist</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Marketing Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-chevron-double-right fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Manage Campaign</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-2">
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-domain fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->campaign_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-group fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Category"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->marketing_category_name??""}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-format-list-text fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Type"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->marketing_type_name??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-text-box-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Description"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->description??"-"}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-counter fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Count"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->count??''}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cash fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Payment"></i>
                        </label>
                        <div class="text-info fw-bold fs-6">
                            <label class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-info fw-bold"></i></label>
                            <label class="fs-6" id='initial_amount'>{{$verify_activity->payment ?? ""}}</label>
                        </div>
                    </div>
                    @if($verify_activity->start_date && $verify_activity->end_date)
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-calendar-range fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->start_date ?? '-'}} to {{$verify_activity->end_date ?? '-'}}
                        </label>
                    </div>
                    @endif
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-map-marker-radius fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Zone"></i>
                        </label>
                        <label class="fw-semibold fs-6 zone_name">{{$verify_activity->zone_name??'-'}}</label>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="row mb-2">
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Vendor"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->marketing_vendor_name??'-'}}</label>
                        <div class="d-block fw-semibold fs-7"></div>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-account-supervisor fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->vendor_contact_person_name??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-cellphone fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Contact Person Mobile No"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->vendor_contact_person_mobile??'-'}}</label>
                    </div>
                    <div class="col-lg-12 mb-2 d-flex align-items-center">
                        <label class="fw-semibold fs-6 me-1">
                            <i class="mdi mdi-office-building-marker fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Address"></i>
                        </label>
                        <label class="fw-semibold fs-6">{{$verify_activity->marketing_vendor_address ?? '-'}}</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="mb-2 d-flex align-items-center">
                <label class="fw-semibold fs-6 me-1">
                    <i class="mdi mdi-text-box-check-outline fs-3 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Campaign Checklist"></i>
                </label>
                <label class="text-black my-4 fs-5 fw-semibold">Campaign Checklist</label>
            </div>
            @php
                $zone_area_name = json_encode($zone_schedule);  // Encode into JSON string
                $decoded_zone_area_name = json_decode($zone_area_name, true);
                $champ_name = json_decode($verify_activity->camp_checklist, true);
                $totalCount = !empty($champ_name) ? count($champ_name) : 0;
            @endphp
            
            <form id="mar_verify_activity" action="{{ route('marketing_verifiy_activity') }}" method="POST">
                @csrf
                @if(isset($verify_activity->payment) && isset($decoded_zone_area_name))
                @foreach($decoded_zone_area_name as $key => $value)
                    <input type="hidden" name="marketing_sno_edit" id="marketing_sno_edit" value="{{$verify_activity->mark_sno}}" />
                    <div class="col-lg-12 mb-4">
                        <div class="card-action">
                            <div class="card-header collapse_{{$key}} bg-label-success">
                                <div class="card-action-title">
                                    <div class="row">
                                        <div class="col-lg-4 d-flex align-items-center">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input outer_checkbox" type="checkbox" name="area_name[]" id="area_{{$value['id']}}" data-index="{{ $key }}" value="{{ $value['area'] }}" />
                                                <label class="text-black fs-6 fw-bold" name="area[]" for="area_{{$value['id']}}">{{ $value['area'] }}</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-1 mb-3">
                                            <div class="d-flex align-items-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Count">
                                                <label class="text-dark fs-5 fw-bold" id="check_count">0</label>
                                                <label class="text-dark fs-5 fw-bold">/</label>
                                                <label class="text-dark fs-5 fw-bold">{{ $totalCount }}</label>
                                            </div>
                                        </div>
                                        <div class="col-lg-4 mb-3">
                                            <div class="badge bg-info fw-bold rounded" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Actual Amount">
                                                <label class="fs-5"><i class="mdi mdi-currency-rupee fs-5 text-white fw-bold"></i></label>
                                                <label class="fs-5 amount_display" name="amount_display[]" id="amount_display_{{ $key }}"></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-action-element">
                                    <ul class="list-inline mb-0">
                                        <li class="list-inline-item">
                                            <a href="javascript:;" class="first_zone_add_{{ $key }}" onclick="up_down_branch({{ $key }})"><i class="mdi mdi-chevron-up fs-3 text-black"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="collapse first_zone_body_add_{{ $key }} border">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row bg-label-danger rounded">
                                            <div class="col-lg-6 mt-2 mb-1 text-black fs-6 fw-semibold">Checklist</div>
                                            <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Amount</div>
                                            <div class="col-lg-3 mt-2 mb-1 text-black fs-6 fw-semibold">Reason</div>
                                        </div>
                                        @foreach($checklist as $chk_key => $activity)
                                            <div class="row mt-2">
                                                <div class="col-lg-6 mb-2 d-flex align-items-center">
                                                    <div class="form-check form-check-inline">
                                                        {{-- <input class="form-check-input activity_chk" type="checkbox" id="activity_{{ $chk_key }}_{{ $value['area'] }}" name="activity_{{ $value['area'] }}[{{ $chk_key }}]" data-index="{{ $key }}" value="1" />
                                                        <label class="text-dark fs-6 fw-semibold" for="activity_{{ $chk_key }}_{{ $value['area'] }}">{{ $activity }}</label> --}}

                                                        <input class="form-check-input activity_chk" type="checkbox" 
                                                            id="activity_{{ $chk_key }}_{{ $value['area'] }}" 
                                                            name="activity_{{ $value['area'] }}[{{ $chk_key }}][checked]" 
                                                            data-index="{{ $key }}" 
                                                            value="1"/>

                                                        <label class="text-dark fs-6 fw-semibold" for="activity_{{ $chk_key }}_{{ $value['area'] }}">
                                                            {{ $activity }}
                                                        </label>

                                                        <input type="hidden" name="activity_{{ $value['area'] }}[{{ $chk_key }}][activity]" value="{{ $activity }}" />
                                                    </div>
                                                </div>
                                                <div class="col-lg-3 mb-2">
                                                    <input type="text" class="form-control amount-input checklist_amount" name="checklist_amount_{{ $value['area'] }}[{{ $chk_key }}]" id="checklist_amount_{{ $chk_key }}_{{ $value['area'] }}" data-index="{{ $key }}" placeholder="Enter Amount" oninput="calculateTotal({{ $key }})" />
                                                </div>
                                                <div class="col-lg-3">
                                                    <textarea class="form-control" rows="1" id="checklist_reason_{{ $chk_key }}_{{ $value['area'] }}" name="checklist_reason_{{ $value['area'] }}[{{ $chk_key }}]" placeholder="Enter Reason"></textarea>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
                @endif
                <div class="d-flex justify-content-end align-items-center gap-2 mt-4">
                    <a href="{{url('/marketing')}}" class="btn fw-bold btn-secondary">Cancel</a>
                    <button type='button' id='submitbtn' class="btn fw-bold btn-primary" onclick="validateForm()">Verify Campaign Checklist</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // When an outer checkbox is changed (checked or unchecked)
            $('.outer_checkbox').change(function() {
                var index = $(this).data('index'); // Get the index of the outer checkbox
                var card = $(this).closest('.col-lg-12'); // Find the closest card
    
                // Find all activity checkboxes inside the same card using the index
                var activityCheckboxes = card.find('.activity_chk[data-index="' + index + '"]');
                
                // Check or uncheck all activity checkboxes based on the outer checkbox
                activityCheckboxes.prop('checked', this.checked);
    
                // Clear all amount inputs if the outer checkbox is unchecked
                if (!this.checked) {
                    card.find('.checklist_amount[data-index="' + index + '"]').val('');
                }
            });
    
            // When any activity checkbox is changed
            $('.activity_chk').change(function() {
                var index = $(this).data('index'); // Get the index of the clicked activity checkbox
                var card = $(this).closest('.col-lg-12'); // Find the closest card
    
                // Get the corresponding amount input field for the checkbox
                var amountInput = card.find('#checklist_amount_' + index);
    
                // If the checkbox is unchecked, clear the corresponding amount input
                if (!this.checked) {
                    amountInput.val(''); // Clear the amount
                }
    
                // Count how many inner checkboxes are checked in the current card
                const checkedCount = card.find('.activity_chk[data-index="' + index + '"]:checked').length;
                const totalCount = card.find('.activity_chk[data-index="' + index + '"]').length;
    
                // If all inner checkboxes are checked, check the outer checkbox for this card
                if (checkedCount === totalCount) {
                    card.find('.outer_checkbox[data-index="' + index + '"]').prop('checked', true);
                } else {
                    // Only uncheck the outer checkbox if no inner checkboxes are checked
                    if (checkedCount === 0) {
                        card.find('.outer_checkbox[data-index="' + index + '"]').prop('checked', false);
                    }
                }
            });
        });
    </script>
    
    
    <script>
        function up_down_branch(id) {
            // Get all chevron elements with the specific class for each card
            const chevronElement = document.querySelector('.first_zone_add_' + id);
            
            if (chevronElement) {
                // Add click event listener to that specific chevron
                chevronElement.addEventListener('click', function(event) {
                    event.preventDefault();
                    
                    // Get the specific card header containing the chevron
                    const cardHeader = chevronElement.closest('.card-header');
                    
                    // Find the corresponding collapse body within the same card
                    const collapseElement = cardHeader.closest('.card').querySelector('.collapse.first_zone_body_add_' + id);
                    
                    if (collapseElement) {
                        // Collapse the target element
                        const collapseInstance = new bootstrap.Collapse(collapseElement);
                        
                        // Toggle the collapse state
                        collapseInstance.toggle();
    
                        // Toggle the collapsed class for the card header (now scoped to the correct header)
                        cardHeader.classList.toggle('collapsed');
                        
                        // Toggle chevron icon between up and down
                        const icon = chevronElement.querySelector('i');
                        icon.classList.toggle('mdi-chevron-down');
                        icon.classList.toggle('mdi-chevron-up');
                    }
                });
            }
        }
    </script>
    
    <script>
      function calculateTotal(zoneIndex) {
            const zone = document.querySelector(`.first_zone_body_add_${zoneIndex}`);

            if (zone) {
                const amountInputs = zone.querySelectorAll(`input[id^="checklist_amount_"]`);
                let total = 0;

                amountInputs.forEach(input => {
                    // Get the corresponding checkbox for the amount input
                    const checkboxId = input.id.replace("checklist_amount_", "activity_");
                    const checkbox = document.getElementById(checkboxId);

                    if (checkbox) {
                        // Get the activityIndex from the checkbox
                        const activityIndex = checkbox.getAttribute('data-index');

                        // Ensure the checkbox is checked and belongs to the correct zone (using zoneIndex)
                        if (checkbox.checked) {
                            const value = parseFloat(input.value) || 0;
                            if (!isNaN(value)) {
                                total += value; // Add the valid input value to total
                            }
                        }
                    }
                });

                // Log the total before updating the display
                console.log("Total calculated for zoneIndex " + zoneIndex + ":", total);

                // Update the total amount display for the specific zone
                const amountDisplay = document.querySelector(`#amount_display_${zoneIndex}`);
                if (amountDisplay) {
                    amountDisplay.innerText = total.toFixed(2);  // Update the total display
                } else {
                    console.log("Amount display not found for zoneIndex:", zoneIndex);  // Log if amount display is not found
                }
            }
        }
    </script>
    


    <script>
        function validateForm() {
            var initialAmount = parseFloat($("#initial_amount").text()) || 0;
            
            var totalDisplayAmount = 0;
    
            $(".amount_display").each(function() {
                var amountValue = parseFloat($(this).text()) || 0;
                totalDisplayAmount += amountValue;
            });
    
            console.log('Initial Amount:', initialAmount);
            console.log('Total Display Amount:', totalDisplayAmount);
    
            // Compare the amounts
            if (initialAmount === totalDisplayAmount) {
                // Submit the form if amounts match
                document.getElementById('mar_verify_activity').submit();
            } else {
                // Display an error message if amounts don't match
                Swal.fire({
                    title: 'Error!',
                    text: `Amounts don't match with the payment.`,
                    icon: 'error',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
            }
        }
    </script>
    




    @endsection
