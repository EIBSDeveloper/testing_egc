@extends('layouts/blankLayout')

@section('title', 'Contact Us')

@section('content')
<div class="container py-5">
    <h1 class="text-center mb-4">Contact Us</h1>
    <p class="text-center lead">We are here to assist you. Please feel free to contact us through any of the following methods:</p>

    <div class="row g-4">
        <!-- Left Column -->
        <div class="col-lg-6 col-md-12 d-flex flex-column justify-content-between">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5><i class="mdi mdi-email-outline"></i> Email</h5>
                    <p>Email us at <a href="mailto:info@phdizone.com">info@phdizone.com</a></p>
                </div>
            </div>
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5><i class="mdi mdi-phone-outline"></i> Phone</h5>
                    <p>Call us at <strong>+91-9677722623, +91-8870200389</strong></p>
                </div>
            </div>
        </div>

        <!-- Right Column -->
        <div class="col-lg-6 col-md-12 d-flex flex-column justify-content-between">
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5><i class="mdi mdi-map-marker-outline"></i> Address</h5>
                    <p>Visit us at: <br>229, Ist & IInd Floor, A, Block, Elysium Campus, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</p>
                </div>
            </div>
            <div class="card shadow-sm mb-4">
                <div class="card-body">
                    <h5><i class="mdi mdi-clock-outline"></i> Business Hours</h5>
                    <p>Monday - Sunday: 24 Hours</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
