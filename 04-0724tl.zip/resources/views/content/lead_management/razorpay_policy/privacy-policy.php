@extends('layouts/blankLayout')

@section('title', 'Privacy Policy')

@section('content')
<div class="container py-5">
    <h1 class="text-center mb-4">Privacy Policy</h1>
    <p class="lead text-center">If you're not satisfied with your purchase, here's how you can request a cancellation or refund:</p>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-delete-outline"></i> Cancellation Policy</h5>
            <p>We accept cancellations within 24 hours of placing the order, provided the product has not yet been shipped.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-cash-refund"></i> Refund Process</h5>
            <p>Refund requests can be made within 30 days of purchase. We will process the refund to the original payment method.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-close-circle-outline"></i> Non-Refundable Items</h5>
            <p>Items marked as "non-refundable" are not eligible for refunds unless defective or damaged upon receipt.</p>
        </div>
    </div>
</div>
@endsection
