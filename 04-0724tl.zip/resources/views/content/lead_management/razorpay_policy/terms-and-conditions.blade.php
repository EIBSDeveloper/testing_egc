@extends('layouts/blankLayout')


@section('title', 'Terms and Conditions')

@section('content')
<div class="container py-5">
    <h1 class="text-center mb-4">Terms and Conditions</h1>
    <p class="lead text-center">Please read our terms and conditions carefully before using our services.</p>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-file-document-outline"></i> General Terms</h5>
            <p>By using our website and services, you agree to these terms and conditions. If you do not agree, please do not use our website.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-lock-outline"></i> Privacy Policy</h5>
            <p>Your privacy is important to us. We do not share your personal data without your consent.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-information-outline"></i> Modifications</h5>
            <p>We may modify these terms from time to time. Any changes will be communicated to you via our website.</p>
        </div>
    </div>
</div>
@endsection
