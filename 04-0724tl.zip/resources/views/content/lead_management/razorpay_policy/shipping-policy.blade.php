@extends('layouts/blankLayout')

@section('title', 'Shipping Policy')

@section('content')
<div class="container py-5">
    <h1 class="text-center mb-4">Shipping Policy</h1>
    <p class="lead text-center">We strive to deliver your products as quickly and safely as possible. Here are the details of our shipping policy:</p>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-truck-fast-outline"></i> Shipping Timeline</h5>
            <p>Orders are processed within 2-3 business days. You will receive an email notification when your order ships.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-currency-usd"></i> Shipping Charges</h5>
            <p>Shipping charges depend on your location and the size of the order. Charges are shown at checkout.</p>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <h5><i class="mdi mdi-currency-inr"></i> International Shipping</h5>
            <p>We offer international shipping to select countries. International orders may incur additional customs fees.</p>
        </div>
    </div>
</div>

@endsection
