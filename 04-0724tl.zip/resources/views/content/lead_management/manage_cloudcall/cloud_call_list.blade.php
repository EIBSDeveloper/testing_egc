@extends('layouts/layoutMaster')

@section('title', 'Manage Cloud Call')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->
<style>
table thead tr th{       
  padding: 5px !important;
}
table tbody tr td{
  padding: 5px !important;
}
</style>

<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data=$helper->get_staff_data($user_id);
        $document_send_count = $helper->general_setting_data()->max_document_send_limit ?? 7;
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
        $module_name = 'Lead Management';
        $menu_name = 'Manage Cloud Call';
    @endphp
        
         <div class="row">
          
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Manage Cloud Call</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Cloud Call Log</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-pills justify-content-end" role="tablist">
                  @php
                      $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
                      $currentYear = request()->get('year', date('Y')); // Default to current year if not provided
    
                      // Calculate previous month and year
                      $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
                      $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January
    
                      // Calculate next month and year
                      $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
                      $nextYear = $currentMonth == 12 ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December
                      
                  @endphp
    
                  <!-- Previous Month Button -->
                  <li class="nav-item me-1">
                      <a class="nav-link px-3"
                          href="{{ route('lead-management-manage-cloud_call', ['month' => $previousMonth, 'year' => $previousYear]) }}">
                          <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline  fs-2"></span>
                          </div>
                      </a>
                  </li>
    
                  <!-- Current Month Button (Active) -->
                  <li class="nav-item me-1">
                      <a class="nav-link active px-3 border border-dashed border-info"
                          href="{{ route('lead-management-manage-cloud_call', ['month' => $currentMonth, 'year' => $currentYear]) }}">
                          <div class="text-center">
                              <span class="fs-6 fw-semibold text-capitalize">{{ \Carbon\Carbon::create($currentYear, $currentMonth)->format('F') }}</span>
                              <div class="d-block">
                                  <span class="fw-semibold fs-8">({{ $currentYear }})</span>
                              </div>
                          </div>
                      </a>
                  </li>
                  <!-- Next Month Button -->
                  <!--{{ $nextYear }}-->
                  <!--{{ $nextMonth }}-->
                  @if ($month_chk)
                  <li class="nav-item me-1">
                      <a class="nav-link px-3"
                          href="{{ route('lead-management-manage-cloud_call', ['month' => $nextMonth, 'year' => $nextYear]) }}">
                          <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline  fs-2"></span>
                          </div>
                      </a>
                  </li>
                  @endif
              </ul>
            </div>
        </div>
    </div>
    <div class="card-body">        
        <div class="row">
          <div class="d-flex align-items-center justify-content-lg-between justify-content-center flex-wrap gap-2">
            <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mb-0">
                <!-- <div class="row"> -->
                <a href="#" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Incoming Calls">
                    <div class="fw-semibold fs-6 text-black text-center">Received Calls</div>
                    <div class="fw-semibold fs-7 text-black text-center">(<span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('M');}}</span>)</div>
                    <div>
                        <img src="https://erp.elysium.academy/public/assets/eapl_images/incoming_call.gif" alt="emoji" class="rounded  align-middle" style="max-width: 70px; height: auto;">
                    </div>
                    <div class="d-block">
                        <div style="background-color:#ebb5a9;" class="badge text-black rounded fw-bold fs-6">{{  sprintf("%02d",$received_call_count)  }}</div>
                    </div>
                </a>
                <a href="#" class="text-center border border-2 p-2 mb-2">
                    <div class="fw-semibold fs-6 text-black text-center">Missed Calls</div>
                    <div class="fw-semibold fs-7 text-black text-center">(<span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('M');}}</span>)</div>
                    <div>
                        <img src="https://erp.elysium.academy/public/assets/eapl_images/missed_call.gif" alt="emoji" class="rounded align-middle" style="max-width: 70px; height: auto;">
                    </div>
                    <div class="d-flex align-items-center justify-content-center">
                        <label data-bs-toggle="tooltip" data-bs-placement="bottom" class="badge  rounded fw-bold fs-6" style="background-color:#4c84e1;" data-bs-original-title="Total Missed Calls">{{  sprintf("%02d",$missed_call_count)  }}</label>
                    </div>
                </a>
                <a href="{{ route('lead-management-manage-cloud_call', ['month' => $currentMonth, 'year' => $currentYear,'unattended' =>1]) }}" class="text-center border border-2 p-2 mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Rejected Calls">
                    <div class="fw-semibold fs-6 text-black text-center">Unattended Calls</div>
                    <div class="fw-semibold fs-7 text-black text-center">(<span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('M');}}</span>)</div>
                    <div>
                        <img src="https://erp.elysium.academy/public/assets/eapl_images/declined_Call.gif" alt="emoji" class="rounded align-middle" style="max-width: 70px; height: auto;">
                    </div>
                    <div class="d-block">
                        <div style="background-color:#ff0028;" class="badge rounded fw-bold fs-6">{{  sprintf("%02d",$not_atten_call_count)  }}</div>
                    </div>
                </a>
               
            </div>
        </div>
            <div class="d-flex justify-content-between align-items-center">
                <div class="mb-4">
                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                            @php
                            $options = [10, 25, 100, 500]; // Define available options
                            @endphp
                            @php foreach ($options as $option): @endphp
                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                @php echo $option; @endphp
                            </option>
                            @php endforeach; @endphp
                        </select>
                    </div>
                </div>
                <div class="mb-4">
                    <form id="search_form" method="POST" action="/lead/cloudcall">
                    @csrf
                        <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                                <input type="text" class="form-control" id="cus_fill" name="cus_fill" placeholder="Enter Who / What" value="{{$customer_fill??''}}"/>
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        <div class="col-lg-12">
<!--            <audio controls>-->
<!--    <source src="{{ url('/play-audio') }}" type="audio/mpeg">-->
<!--    Your browser does not support the audio element.-->
<!--</audio>-->
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
            <thead>
                <tr class=" align-top fw-bold fs-6 gs-0 bg-primary">
                    <th class="text-start" style="width: 30%;">Lead Details</th>
                    <th class="text-start" style="width: 10%;">Lead status</th>
                    <th class="text-start" style="width: 20%;">What</th>
                    <th class="text-start" style="width: 10%;">State/Country</th>
                    <th class="text-start" style="width: 10%;">Call Date</th>
                    <th class="text-start" style="width: 5%;">Start Time</th>
                    <th class="text-start" style="width: 5%;">End Time</th>
                    <th class="text-start" style="width: 5%;">Duration</th> 
                    <!--<th class="text-start" style="width: 5%;">Download</th> -->
                    @if(auth()->user()->hasPermission($module_name, 'Audio', $menu_name))
                    <th class="text-start" style="width: 5%;">Audio</th> 
                    @endif
                </tr>                
            </thead>
            <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                @if (isset($Call_log))
                     @foreach ($Call_log as $i=> $call)
                     <tr>                            
                            <td>
                                @if($call->lead_name)
                                  <label class="fs-6 fw-bold" title="Lead Name">{{ $call->lead_name }}</label>
                                  <label class="d-block fs-7 fw-semibold">{{ $call->caller_number }}</label>
                                  <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-info rounded fw-bold fs-8 mb-2 px-1 py-1">{{ $call->staff_name ?? 'Old Staff'}}</span></div>
                                @elseif($call->internal_user_name)
                                    <div class="d-flex align-items-center px-1">
                                      <div class="mb-0 align-items-center">
                                          <label class="fs-7 me-1">{{ $call->internal_user_name ? $call->internal_user_name :($call->customer_name ? $call->customer_name :"Unknown")}}</label>
                                          <div class="d-block text-primary fs-8 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">{{ $call->customer_phone_no }}</div>
                                          <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-primary rounded fw-bold fs-8 mb-2 mt-1 px-2 py-1 ">Internal</span></div>
                                      </div>
                                    </div>
                                @else
                                <div class="d-flex align-items-center justify-content-start gap-2">
                                  <label class="fs-7 fw-bold bg-label-danger rounded px-1 py-1">{{ $call->caller_number }} </label>
                                    @if(\Carbon\Carbon::parse($call->start_time)->lt(\Carbon\Carbon::now()->subHours(24)))
                                        <a href="javascript:;" class="fw-bold me-2 mb-2 btn btn-icon btn-sm"
                                            data-bs-toggle="modal" data-bs-target="#kt_modal_lead_convert" 
                                            onclick="convertLeadOrSpam('{{ $call->id }}','{{ $call->caller_number }}')">
                                            <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>
                                        </a>
                                    @endif

                                </div>
                                @endif
                            </td>
                            <td>
                                @if($call->lead_name)
                                    @if( $call->lead_status == 0)
                                    <label class="badge bg-info text-white rounded fw-bold fs-8 mb-2" >Active</label>
                                    @elseif( $call->lead_status == 1)
                                    <label class="badge bg-warning text-white rounded fw-bold fs-8 mb-2 " >In Active</label>
                                    @elseif( $call->lead_status == 4)
                                    <label class="badge bg-success text-white rounded fw-bold fs-8 mb-2" >Customer</label>
                                    @elseif( $call->lead_status == 10)
                                    <label class="badge bg-success text-white rounded fw-bold fs-8 mb-2" >Old Customer</label>
                                    @elseif($call->lead_status == 5 && ($call->drop_verified == 0 || $call->drop_tl_verified == 0) ) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead Awaiting </label>
                                    @elseif($call->lead_status == 5 && $call->drop_verified == 1 && in_array(auth()->user()->role_id, [12,18,20,21])) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead </label> 
                                    @elseif($call->lead_status == 5 && $call->drop_verified == 1 && !in_array(auth()->user()->role_id, [12,18,20,21])) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead Awaiting </label> 
                                    @elseif( $call->lead_status == 7 && ($call->spam_verified == 0 || $call->spam_tl_verified == 0) ) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam Awaiting </label> 
                                    @elseif($call->lead_status == 7 && $call->spam_verified == 1 && in_array(auth()->user()->role_id, [12,18,20,21])) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam </label> 
                                    @elseif($call->lead_status == 7 && $call->spam_verified == 1 && !in_array(auth()->user()->role_id, [12,18,20,21])) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam Awaiting </label>
                                    @elseif( $call->lead_status == 8)
                                    <label class="badge bg-warning text-primary rounded fw-bold fs-8 mb-2" >OLD Lead</label>
                                @endif
                                @else
                                -
                                @endif
                            </td>
                            <td class="text-start">
                                <label class="fs-7 ">
                                  @if($call->action)
                                  Call {{ $call->action??'-' }} by {{ $call->received_by ??'-' }} at ({{$call->department_name}})
                                  @else
                                  -
                                  @endif
                                </label>
                            </td>
                            <td class="text-start">
                              <label class="mt-1">
                                  <span class="fs-7 fw-bold text-black">{{$call->state}}</span>
                              </label>
                            </td>
                            <td class="text-start">
                                <label class="badge bg-warning fs-7 text-black" title="Call Date">
                                    <span>{{ date('d-M-Y', strtotime($call->start_time)) }}</span>
                                </label>
                            </td>
                            <td class="text-start">
                              <label class="badge bg-success fs-7 ">
                                  <span  title="Call Start Date">{{ date('h:i:s A', strtotime($call->start_time)) }}</span>
                              </label>
                            </td>
                            <td class="text-start">                              
                              <label class="badge bg-danger fs-7 fw-bold text-white">
                                  <span  title="Call End Date">{{ date('h:i:s A',
                                      strtotime($call->end_time))
                                      }}</span>
                              </label>
                          </td>

                          <td class="text-start">
                              <label class="fs-7">{{ $call->duration }}</label>
                          </td>
                            <!--<td class="text-end">-->
                            <!--    @if ($call->audioUrl)-->
                            <!--    <a href="{{ $call->audioUrl }}" download-->
                            <!--        class="btn btn-icon btn-sm">-->
                            <!--        <i class="mdi mdi-download-circle-outline fs-3 text-black"></i>-->
                            <!--    </a>-->
                            <!--    @endif-->
                                
                                
                            <!--</td>-->
                            @if(auth()->user()->hasPermission($module_name, 'Audio', $menu_name))
                            <td class="text-end" style='min-width: 300px;'>
                                <?php
                                    // $token = "47f1cefa17f5577bc8ce1c26f58fee39";
                                    // $parsedPath = parse_url($call->audioUrl, PHP_URL_PATH); // e.g., /audio/filename
                                    // $file = basename($parsedPath) . ".mp3";

                                    // $url = "https://developers.myoperator.co/recordings/link?token=$token&file=$file";
                                    
                                    // // Fetch API
                                    // $ch = curl_init($url);
                                    // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                    // $response = curl_exec($ch);
                                    // curl_close($ch);
                                    // // Decode JSON properly
                                    // $data = json_decode($response, true);
                                    // // Debugging (optional)
                                    // //  echo "<pre>"; print_r($data); echo "</pre>";
                                    // $audioUrl = $data['url'] ?? null;
                                ?>
                                @php
                                    $audioFile = $call->audio_file;
                                @endphp
                                
                                @if ($audioFile)
                                    @php
                                        $relativePath = 'cloud_call_recordings/' . $audioFile;
                                        $audioPath = public_path($relativePath);
                                        $audioUrl = asset($relativePath);
                                    @endphp
                                
                                    @if (file_exists($audioPath))
                                        <audio controls style="background-color: #007bff; border-radius: 8px; padding: 5px;">
                                            <source src="{{ $audioUrl }}" type="audio/mpeg">
                                            Your browser does not support the audio element.
                                        </audio>
                                    @else
                                        <p style="color: red;" class="fs-6"> 🎧 No recording available for this call  🎧</p>
                                    @endif
                                @else
                                    <p style="color: red;" class="fs-6"> 🎧 No recording available for this call  🎧</p>
                                @endif



                                <!--< ?php if ($audioUrl): ?>-->
                                    <!--<audio controls>-->
                                    <!--    <source src="< ?= htmlspecialchars($audioUrl) ?>" type="audio/mpeg" style="width: 100%; background-color: #50cd89; border-radius: 8px; padding: 5px;">-->
                                    <!--    Your browser does not support the audio element.-->
                                    <!--</audio>-->
                                <!--< ?php else: ?>-->
                                    <!--<p style="color:red;" class="fs-6">	ðŸŽ§  No recording available for this call ðŸŽ§ </p>-->
                                <!--< ?php endif; ?>-->
                            </td>
                            @endif
                        </tr>
                    @endforeach
                @endif
            </tbody>
            </table>

        </div>
        <div class="mt-4">
            {{ $Call_log->appends(request()->except(['page', '_token']))->links() }}
        </div>
        </div>
    </div>
</div>


<!--begin::Modal - View Lead-->
<div class="modal fade" id="kt_modal_cus_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6">
          <h3 class="text-center text-black">Payment Details</h3>
        </div>
        <form>
          <div class="row">
            <div class="col-lg-12 text-black fs-5 fw-bold"><u>Customer Information</u></div>
            <div class="col-lg-6" id="customer-details">
              <!-- Customer details will be injected here -->
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 text-black fs-5 fw-bold"><u>Total Payments</u></div>
            <div class="col-lg-12" id="customer-payments">
              <!-- Customer details will be injected here -->
            </div>
          </div>
          <div class="row">
            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page2">
              <thead>
                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                  <th class="min-w-125px">Date</th>
                  <th class="min-w-125px">MDD</th>
                  <th class="min-w-100px">Schd.Fees</th>
                  <th class="min-w-100px">Paid Fees</th>
                  <th class="min-w-100px">Bal.Fees</th>
                  <th class="min-w-80px">Status</th>
                </tr>
              </thead>
              <tbody class="text-black fw-semibold fs-7" id="payment-table-body-model">
                <!-- Payment details will be injected here -->
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<!--end::Modal - View Lead-->
<!-- Full Image Modal -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Profile Image</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body d-flex justify-content-center align-items-center">
        <img id="fullImage" src="" class="img-fluid rounded" style="max-height: 80vh;" />
      </div>
    </div>
  </div>
</div>

<!--begin::Modal - Convert to Lead Or Spam-->
<div class="modal fade" id="kt_modal_lead_convert" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md" id="leadConvertModal">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Lead Convert</h3>
                </div>
                <form id="leadSpamForm" action="{{ route('spam_lead_convert') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="container" id="swal2-html-container" style="display: block;">
                      <div class="mb-4 fw-bold fs-6 text-center">
                        <span>Are you sure you want to Convert <b class='text-danger' id="lead_convert_no"></b> Lead?</span>
                      </div>
                      <div class="row mb-4">
                        <input type="hidden" id="cloud_call_id" name="cloud_call_id" value=""/>
                        <div class="col-lg-12 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold d-block">Convert To<span class="text-danger">*</span></label>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="lead_convert_to" id="inlineRadio1" value="1" checked/>
                              <label class="form-check-label" for="inlineRadio1">Lead</label>
                          </div>
                          <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" name="lead_convert_to" id="inlineRadio2" value="2"/>
                              <label class="form-check-label" for="inlineRadio2">Spam</label>
                          </div>
                          <div class="text-danger" id="lead_convert_to_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold" id="lead_name_label">Lead Name</label><span class="text-danger">*</span>
                            <input type="text" class="form-control" id="lead_name_create" name="lead_name" placeholder="Enter Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                            <div class="text-danger" id="lead_name_create_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold required">Sales Person <span class="text-danger">*</span></label>
                          <select id="sales_staff_add" name="sales_staff_add" class="select3 form-select" data-parent-dropDown="#kt_modal_lead_convert">
                          </select>
                          <div class="text-danger" id="sales_staff_add_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="spam_reason_select_div" style="display: none;">
                          <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span class="text-danger">*</span></label>
                          <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleReason(this.value)" data-parent-dropDown="#kt_modal_lead_convert">
                              <option value="">Select Reason</option>
                              @if (isset($reasonList) && count($reasonList) > 0)
                              @foreach ($reasonList as $reason_spam)
                              <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                                  {{ $reason_spam->reason_name }}
                              </option>
                              @endforeach
                              @endif
                              <option value="1">Others</option>
                          </select>
                          <div class="text-danger" id="reason_select_err"></div>
                      </div>
                      <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        <div class="text-danger" id="reason_text_err"></div>
                    </div>
                    <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
                      <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
                      <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                      <div class="text-danger" id="spam_comments_err"></div>
                  </div>
                      <div class="text-center mt-2">
                        <button type="submit" class="btn btn-danger me-3" id="submitConvert" onclick="convertValidation(event)">Yes, Convert!</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                      </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Convert to Lead Or Spam-->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>

// Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
function fsc_sts_func(val) {

    if (val == "reject") {
        document.getElementById("rejct_tbox").style.display = "block";
        document.getElementById("smt_butt").innerHTML = "Rejected";
    } else if (val == "accept") {
        document.getElementById("rejct_tbox").style.display = "none";
        document.getElementById("smt_butt").innerHTML = "Approved";
    } else {
        document.getElementById("rejct_tbox").style.display = "none";
        document.getElementById("smt_butt").innerHTML = "Approved";
    }
}
</script>
<script>

  function viewCustomerDetails(customerId) {
    // Fetch customer and payment details based on customerId
    $.ajax({
      url: '/get_customer_details/' + customerId,
      method: 'GET',
      success: function(response) {
        // Inject customer details into the modal
        let customerDetails = `
        <div class="customer-info">
          <div class="row">
            <div class="col-12 col-md-6">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-account fs-5"></i> <strong>Name:</strong></span>
                <span class="info-value">${response.customer.cus_name}</span>
              </div>
            </div>
            <div class="col-12">
              <div class="info-item">
                <span class="info-label"><i class="mdi mdi-phone-in-talk fs-5"></i> <strong>Mobile:</strong></span>
                <span class="info-value">${response.customer.cus_mobile}</span>
              </div>
            </div>
          </div>
        </div>
      `;
      
        // Extract payment details from response.payments array
       let totalFees = parseFloat(response.payments[0]?.total_amount || 0);
        let paidFees = 0;
        
        // Loop through payments array and sum up the total and paid fees
        response.payments.forEach(payment => {
            paidFees += parseFloat(payment.paidAmount || 0);
        });
        
        // Calculate balance fees
        let balanceFees = totalFees - paidFees;
        
       let paymentsDetails = `
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex flex-wrap gap-3 mt-2">
                    <span class="badge bg-info rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Total Fees:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${totalFees.toFixed(2)}
                    </span>
                    <span class="badge bg-success rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Paid Fees:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${paidFees.toFixed(2)}
                    </span>
                    <span class="badge bg-danger rounded text-white p-3 fs-6">
                        <i class="mdi mdi-cash fs-5"></i> <strong>Balance Fees:</strong> 
                        <i class="mdi mdi-currency-rupee"></i> ${balanceFees.toFixed(2)}
                    </span>
                </div>
            </div>
        </div>
    `;





        $('#customer-details').html(customerDetails);
        $('#customer-payments').html(paymentsDetails);
        let paymentRows = '';
        $.each(response.payments, function(index, payment) {
          const gstPercentage = parseFloat(response.gstPercentage) || 0;  // Ensure valid GST percentage

          // Calculate GST and totals once for reuse
          const courseFeeGST = parseFloat(payment.amount) * gstPercentage;
          const totalCourseFee = parseFloat(payment.amount) + courseFeeGST;

          const paidAmountGST = parseFloat(payment.paidAmount) * gstPercentage;
          const totalPaidAmount = parseFloat(payment.paidAmount) + paidAmountGST;

          const balanceFeeGST = parseFloat(payment.balanceFee) * gstPercentage;
          const totalBalanceFee = parseFloat(payment.balanceFee) + balanceFeeGST;

          // Start building payment row
          paymentRows += '<tr>';

          // Display the initial payment date
          paymentRows += '<td>' + payment.initialPayDate + '</td>';

          // Display next payment date with tooltip for maximum due date
          paymentRows += `<td>
            <div class="d-block mt-1">
              <label class="badge bg-label-danger fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Maximum Due Date">
                ${payment.nextPayDate}
              </label>
            </div>
          </td>`;

          // Display scheduled fees with currency and GST
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Schedule Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.amount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 "><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${courseFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-info rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalCourseFee.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Display paid fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.paidAmount).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${paidAmountGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-success rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalPaidAmount.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Display balance fees with GST calculation
          paymentRows += '<td align="right">';
          paymentRows += `
            <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Balance Fees">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${parseFloat(payment.balanceFee).toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block" data-bs-toggle="tooltip" data-bs-placement="bottom" title="GST Amount">
              <span class="fs-9 me-n1"><i class="mdi mdi-currency-rupee"></i></span>
              <span class="fs-7">${balanceFeeGST.toFixed(2)}</span>
              <span class="fs-7">/</span>
            </div>
            <div class="d-block">
              <label class="badge bg-danger rounded fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Schedule Fees">
                <span class="fs-8"><i class="mdi mdi-currency-rupee fs-7"></i></span>
                <span class="fs-7">${totalBalanceFee.toFixed(2)}</span>
              </label>
            </div>
          `;
          paymentRows += '</td>';

          // Status column (Paid or Pending)
          paymentRows += `<td>
            ${payment.status == 1 ?
              '<label class="badge bg-success text-black fw-semibold fs-6">Paid</label>' :
              '<label class="badge bg-danger fw-semibold fs-6">Pending</label>'
          }</td>`;

          paymentRows += '</tr>';
        });
        $('#payment-table-body-model').html(paymentRows);
      }
    });
  }

</script>
<style>
    #course {
        /* background-image: linear-gradient(to bottom, #1397c7, #007fbe, #0066b3, #004da4, #11318f); */
        background: rgb(13, 214, 80);
        background: linear-gradient(90deg, rgba(13, 214, 80, 1) 0%, rgba(64, 121, 9, 1) 35%, rgba(134, 255, 0, 1) 100%);
    }
    .txt_vertical {
      writing-mode: vertical-lr;
      transform: rotate(180deg);
    }
</style>
<style>


    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: rgb(196, 3, 3);
    }
    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
     .payment-btn.notify {
        position: relative;
        animation: pulseOuter 1.5s infinite; /* Outer pulse effect */
        border: 2px solid red; /* Red border to indicate urgency */
        border-radius: 50%;
        overflow: hidden;
    }

    .payment-btn.notify i {
        color: white; /* Ensure inner icon is visible */
        /* background: radial-gradient(circle, #ffcccc 0%, #ff9999 70%, transparent 100%); */
        border-radius: 50%; /* Make the icon circular */
        animation: pulseInner 1.5s infinite; /* Inner subtle glow */
    }

    /* Outer pulse animation */
    @keyframes pulseOuter {
        0% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
        50% {
            box-shadow: 0 0 30px rgba(255, 0, 0, 1);
            transform: scale(1.1);
        }
        100% {
            box-shadow: 0 0 10px rgba(255, 0, 0, 0.5);
            transform: scale(1);
        }
    }

    /* Inner subtle glow animation */
    @keyframes pulseInner {
        0% {
            transform: scale(1);
            opacity: 1;
        }
        50% {
            transform: scale(1.1);
            opacity: 0.7;
        }
        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>

<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
  $(".list_page2").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
</script>
<script>
  $.ajax({
      url: "{{ route('sales_staff') }}",
      type: "GET",
      success: function(response) {
          if (response.status === 200 && response.data) {
            let select = document.getElementById('sales_staff_add');
            select.innerHTML = ''; // Clear existing options
            // Add the empty option
            let defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = 'Select Sales Person';
            select.appendChild(defaultOption);
            
              response.data.forEach(staff => {
                if(staff.department_id === 1){
                    let option = document.createElement('option');
                    option.value = staff.sno;
                    option.textContent = staff.staff_name + " - "+staff.position_name;
                    select.appendChild(option);
                }
            });
          } else {
              let select = document.getElementById('sales_staff_add');
              select.innerHTML = ''; // Clear existing options
              // Add the empty option
              let defaultOption = document.createElement('option');
              defaultOption.value = '';
              defaultOption.textContent = 'Select Sales Person';
              select.appendChild(defaultOption);

          }
      },
      error: function(error) {

        }
  });

  function convertLeadOrSpam(id, mobile) { 
    // alert(mobile);
    $('#cloud_call_id').val(id);
    $('#lead_convert_no').html(mobile);
  }

  function convertValidation(event) {
    var err = 0;
    
     var lead_name_create = document.getElementById("lead_name_create");

    if (lead_name_create.value === "") {
        document.getElementById('lead_name_create_err').innerHTML = 'Name is required...!';
        err++;
    } else {
        document.getElementById('lead_name_create_err').innerHTML = '';
    }


    var sales_staff_add = document.getElementById("sales_staff_add");

    if (sales_staff_add.value === "") {
        document.getElementById('sales_staff_add_err').innerHTML = 'Sales Person is required...!';
        err++;
    } else {
        document.getElementById('sales_staff_add_err').innerHTML = '';
    }
    
    var lead_convert_to = document.querySelector('input[name="lead_convert_to"]:checked').value;
    if(lead_convert_to==2){
    // Get other fields and validate
    var spam_reason = document.getElementById("spam_reason");
    var reason_text = document.getElementById("reason_text");
    var spam_comments = document.getElementById("spam_comments");

    // Clear error messages for reason and comments
    document.getElementById('reason_text_err').innerHTML = '';
    document.getElementById('spam_comments_err').innerHTML = '';

    // Check if spam reason is provided
    if (!spam_reason || spam_reason.value === "") {
        // alert('reason valid');
        document.getElementById('reason_select_err').innerHTML = 'Reason is required...!';
        err++;
    } else if (spam_reason.value === "1") {
        // alert('other reason valid');
        if (!reason_text || reason_text.value.trim() === "") {
            document.getElementById('reason_text_err').innerHTML = 'Other reason is required...!';
            err++;
        }
    }
    
    // Check if the selected reason's comments_check is 1 before validating comments
    var selectedReasonOption = spam_reason.options[spam_reason.selectedIndex];
    var commentsCheck = selectedReasonOption ? selectedReasonOption.getAttribute('data-comments-check') : null;
    
    }else{
         document.getElementById('reason_text_err').innerHTML = '';
        document.getElementById('spam_comments_err').innerHTML = '';
    }

    if (commentsCheck == "1" && (!spam_comments || spam_comments.value.trim() === "")) {
        // alert('comments valid');
        document.getElementById('spam_comments_err').innerHTML = 'Comments are required...!';
        err++;
    }

    if (err === 0) {
        $('#leadSpamForm').submit();
        $('#submitConvert').prop('disabled', true);
    } else {
        $('#submitConvert').prop('disabled', false);
        
        event.preventDefault();
    }
  }
</script>

<script>
  function toggleReason(value) {
      
        document.getElementById('reason_text_err').innerHTML = '';
        document.getElementById('spam_comments_err').innerHTML = '';
        document.getElementById('sales_staff_add_err').innerHTML = '';
        document.getElementById('lead_name_create_err').innerHTML = '';
         
      var convertValue = document.querySelector('input[name="lead_convert_to"]:checked').value;
      var spamReasonSelect = document.getElementById('spam_reason_select_div');
      var spamReasonDiv = document.getElementById('reason_div');
      var spamReasonText = document.getElementById('reason_text');
      var spamCommentsDiv = document.getElementById('comments_div');
      var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
      var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

      if (convertValue == '2') {
        spamReasonSelect.style.display = 'block';
        $('#lead_name_label').html('Spam Name');
        
      } else {
        spamReasonSelect.style.display = 'none';
        $('#lead_name_label').html('Lead Name');
      }

      // Show or hide reason div and set required attribute
      if (value == '1') {
          spamReasonDiv.style.display = 'block';
          spamReasonText.setAttribute('required', 'required');
      } else {
          spamReasonDiv.style.display = 'none';
          spamReasonText.removeAttribute('required');
      }

      // Show or hide comments div based on selected reason
      if (commentsCheck == '1') {
          spamCommentsDiv.style.display = 'block';
      } else {
          spamCommentsDiv.style.display = 'none';
      }
  }

  // Add event listeners to the radio buttons to trigger toggleReason when changed
  document.querySelectorAll('input[name="lead_convert_to"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
      toggleReason(document.getElementById('spam_reason').value);
    });
  });

  // Initialize display based on the default selected radio button value
  window.addEventListener('DOMContentLoaded', function() {
    toggleReason(document.getElementById('spam_reason').value);
  });
</script>

@endsection