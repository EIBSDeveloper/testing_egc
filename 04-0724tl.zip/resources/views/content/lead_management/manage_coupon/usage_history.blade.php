@extends('layouts/layoutMaster')

@section('title', 'Usage History')


@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/animate-css/animate.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <!-- Lead List Table -->
    <div class="card">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
        <div class="card card-action">
            <div class="card-header border-bottom pb-1">
                <div class="card-action-title">
                    <h5 class="card-title mb-1">Manage Coupon</h5>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                        class="mdi mdi-home-outline text-body fs-4"></i></a>
                            </li>
                            <span class="text-dark opacity-75 me-1 ms-1">
                                <i class="mdi mdi-arrow-right-thin fs-4"></i>
                            </span>
                            <li class="breadcrumb-item">
                                <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="card-action-element">
                    <div class="nav-align-top mb-2">
                        <ul class="nav nav-pills" role="tablist">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;" role="presentation">
                                <a href="{{ url('/lead/manage_coupon') }}" type="button"
                                    class="nav-link text-capitalize ">Coupons</a>
                            </li>
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;" role="presentation">
                                <a href="{{ url('/lead/usage_history') }}" type="button"
                                    class="nav-link text-capitalize active text-white">Usage History</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body px-4 py-0">
            <div class="row mt-2">
                <div class="col-xl-12">

                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_usage_history" role="tabpanel">
                                <div class="d-flex justify-content-end align-items-center flex-wrap">
                                    {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" id="coup_his_filter" title="Filter">
                                    <i class="mdi mdi-filter-outline text-center"></i>
                                </a> --}}
                                </div>
                                <div class="coup_his_filter_tbox" style="display: none;">
                                    <form id="filter_form2" method="POST" action="/lead/usage_history">
                                        @csrf
                                        <div class="row py-1">
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" name="fill_chk" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Coupons</label>
                                                <input type="text" placeholder="Enter Coupon Name"
                                                    name="coupon_name_fill" id="coupon_name_fill" class="form-control"
                                                    value="{{ $coupon_name_fill ?? '' }}" />
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <div class="form-check form-check-inline mt-6">
                                                    <input class="form-check-input" type="checkbox" id='multi_check_fill'
                                                        name='multi_check_fill' value="1"
                                                        @if ($multi_check_fill == '1') checked @endif />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Multiple</label>
                                                </div>
                                                <div class="form-check form-check-inline mt-6">
                                                    <input class="form-check-input" type="checkbox" id='public_check_fill'
                                                        name='public_check_fill' value="1"
                                                        @if ($public_check_fill == '1') checked @endif />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Public</label>
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                                <select class="select3 form-select" name="dt_fill_issue_rpt"
                                                    id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                                    <option value="all"
                                                        @if ($date_filter == 'all') selected @endif>All</option>
                                                    <option value="today"
                                                        @if ($date_filter == 'today') selected @endif>Today</option>
                                                    <option value="week"
                                                        @if ($date_filter == 'week') selected @endif>This Week</option>
                                                    <option value="monthly"
                                                        @if ($date_filter == 'monthly') selected @endif>This Month
                                                    </option>
                                                    <option value="custom_date"
                                                        @if ($date_filter == 'custom_date') selected @endif>Custom Date
                                                    </option>

                                                </select>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="lead_today_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="lead_week_st_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="lead_week_ed_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="lead_this_month_dt_fill"
                                                        placeholder="Select Date" class="form-control this_month_dt_fill"
                                                        value="<?php echo date('M-Y'); ?>" />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" placeholder="Select Date" readonly
                                                        name="from_date_fillter_textbox"
                                                        class="form-control common_date_class"
                                                        value="<?php echo date(' d-M-Y'); ?>" />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" placeholder="Select Date"
                                                        class="form-control common_date_class" readonly
                                                        name="to_date_fillter_textbox" value="<?php echo date(' d-M-Y'); ?>" />
                                                </div>
                                            </div>

                                        </div>
                                        <div class="d-flex justify-content-end align-items-center">
                                            <a href="{{ url('/lead/usage_history/') }}"
                                                class="btn btn-sm btn-secondary me-3">Reset</a>
                                            <button type="submit" class="btn btn-sm btn-primary"
                                                data-bs-dismiss="modal">Go</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="row mb-2">
                                    @php $perpage_count = $perpage ? $perpage : 1; @endphp
                                    <div class="col-lg-2">
                                        <span>Show</span>
                                        <br>
                                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                            onchange="sort_filter(this.value);">
                                            @php
                                                $options = [10, 25, 100, 500]; // Define available options
                                            @endphp
                                            @foreach ($options as $option)
                                                <option value="{{ $option }}"
                                                    @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                    @php echo $option; @endphp
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                        <form id="filter_form" method="POST" action="/lead/usage_history">
                                            @csrf
                                        <div class="d-flex align-items-center gap-2 mt-2">
                                            <div>
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input
                                                type="text"
                                                class="form-control"
                                                id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                                                placeholder="Enter Search"
                                            />
                                            </div>
                                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-100px">Usage Date</th>
                                                    <th class="min-w-100px">Used By</th>
                                                    <th class="min-w-150px">Coupons</th>
                                                    <th class="min-w-100px">Amount</th>
                                                    <th class="min-w-100px">Public / Multiple</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                @if ($usage_history_list)
                                                    @foreach ($usage_history_list as $i => $list)
                                                        <tr>
                                                            <td>
                                                                <label
                                                                    class="fw-semibold text-black fs-7">{{ date($common_date_format, strtotime($list->used_date)) }}</label>
                                                            </td>
                                                            <td>
                                                                <label
                                                                    class="fw-semibold text-black fs-7">{{ $list->lead_name }}</label>
                                                                <div class="d-block">
                                                                    <label
                                                                        class="fw-semibold text-secondary fs-7 fw-bold">{{ $list->proposal_id }}</label>
                                                                </div>

                                                            </td>
                                                            <td>
                                                                <label
                                                                    class="fw-semibold text-black fs-7">{{ $list->coupon_name }}
                                                                </label>
                                                                <div class="d-block">
                                                                    <label class="text-info fs-8 fw-bold me-1"
                                                                        id="coup_code_val_td_{{ $i }}">{{ $list->coupon_code }}</label>
                                                                    <a href="javascript:;"
                                                                        class="cpy-btn btn btn-sm btn-label-primary px-2 py-1"
                                                                        data-clipboard-action="copy"
                                                                        data-clipboard-target="#coup_code_val_td_{{ $i }}"
                                                                        onclick="copyToClipboard({{ $i }});">
                                                                        <i
                                                                            class="mdi mdi-content-copy fs-6 text-black"></i>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <label class="badge fw-semibold text-white fs-7"
                                                                    style="background-color: #FF5733; color: white;">{{ $list->currency_symbol ?? '₹' }}
                                                                    {{ $list->amount }}</label>
                                                            </td>
                                                            <td>
                                                                @if ($list->multiple_check == 1 && $list->public_check == 1)
                                                                    <label
                                                                        class="fw-semibold text-black fs-7">Public/Multiple</label>
                                                                @elseif ($list->multiple_check == 1)
                                                                    <label
                                                                        class="fw-semibold text-black fs-7">Multiple</label>
                                                                @elseif ($list->public_check == 1)
                                                                    <label
                                                                        class="fw-semibold text-black fs-7">Public</label>
                                                                @else
                                                                    <label class="fw-bold text-black fs-7 badge"
                                                                        style="background-color: #33dbff; color: white;">Individual</label>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-4">
                                        {{ $usage_history_list->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        <style>
            /* Customize Toastr notification */
            .toast-success {
                background-color: green;
            }

            /* Customize Toastr notification */
            .toast-error {
                background-color: rgb(196, 3, 3);
            }

            .error_msg {
                border: solid 2px red !important;
                border-color: red !important;
            }
        </style>
        <script>
            // Function to copy coupon code to clipboard dynamically by index
            function copyToClipboard(index) {
                const couponCodeElement = document.getElementById('coup_code_val_td_' + index);
                const couponCodeText = couponCodeElement ? couponCodeElement.innerText : '';

                if (couponCodeText) {
                    // Check if Clipboard API is available
                    if (navigator.clipboard) {
                        // Use Clipboard API for modern browsers
                        navigator.clipboard.writeText(couponCodeText).then(function() {
                            toastr.success('Coupon code copied to clipboard!');
                        }).catch(function(err) {
                            toastr.error('Failed to copy coupon code.');
                        });
                    } else {
                        // Fallback to execCommand for older browsers or unsupported environments
                        const textArea = document.createElement('textarea');
                        textArea.value = couponCodeText;
                        document.body.appendChild(textArea);
                        textArea.select();

                        try {
                            document.execCommand('copy');
                            toastr.success('Coupon code copied to clipboard!');
                        } catch (err) {
                            // toastr.error('Failed to copy coupon code.');
                        }

                        document.body.removeChild(textArea);
                    }
                } else {
                    toastr.error('No coupon code found.');
                }
            }
        </script>

        
        <script>
            $(document).ready(function() {
                @if ($filter_on ?? '')
                    $('.coup_his_filter_tbox').slideToggle('fast');
                    // });
                @endif
            });

            // Toggle branch filter section
            $('#coup_his_filter').click(function() {
                $('.coup_his_filter_tbox').slideToggle('slow');
            });
        </script>
        <script>
            function date_fill_issue_rpt() {
                var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
                var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
                var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
                var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
                var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
                var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
                var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
                var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
                var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

                if (dt_fill_issue_rpt == "today") {
                    today_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "week") {
                    today_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "block";
                    week_to_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";

                    var curr = new Date; // get current date
                    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                    var last = first + 6; // last day is the first day + 6

                    var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                    firstday = firstday.split("-").reverse().join("-");
                    var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                    lastday = lastday.split("-").reverse().join("-");
                    $('#lead_week_st_dt_fill').val(firstday);
                    $('#lead_week_ed_dt_fill').val(lastday);

                } else if (dt_fill_issue_rpt == "monthly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "block";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "custom_date") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "block";
                    to_dt_iss_rpt.style.display = "block";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }
            }
        </script>

        <script>
            function sort_filter(val) {
                if (val != "") {
                    $('.sorting_filter_class').val(val);
                    $('#filter_form').submit();
                } else {
                    $('.sorting_filter_class').val(25);
                    $('#filter_form').submit();
                }
            }
        </script>
        <script>
            $(".list_page").DataTable({
                "ordering": false,
                // "aaSorting":[],
                "language": {
                    "lengthMenu": "Show _MENU_",
                },
                "dom": "<'row mb-3'" +
                    // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                    // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                    ">" +

                    "<'table-responsive'tr>" +

                    "<'row'" +
                    // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                    ">"
            });
        </script>
    @endsection
