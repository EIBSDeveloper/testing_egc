@extends('layouts/layoutMaster')

@section('title', 'Manage Coupon')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/animate-css/animate.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <!-- Lead List Table -->
    <div class="card">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        @endphp
        <div class="card card-action">
            <div class="card-header border-bottom pb-1">
                <div class="card-action-title">
                    <h5 class="card-title mb-1">Manage Coupon</h5>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                        class="mdi mdi-home-outline text-body fs-4"></i></a>
                            </li>
                            <span class="text-dark opacity-75 me-1 ms-1">
                                <i class="mdi mdi-arrow-right-thin fs-4"></i>
                            </span>
                            <li class="breadcrumb-item">
                                <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                            </li>
                        </ol>
                    </nav>
                </div>
                <div class="card-action-element">
                    <div class="nav-align-top mb-2">
                        <ul class="nav nav-pills" role="tablist">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;" role="presentation">
                                <a href="{{ url('/lead/manage_coupon') }}" type="button"
                                    class="nav-link text-capitalize active text-white">Coupons</a>
                            </li>
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;" role="presentation">
                                <a href="{{ url('/lead/usage_history') }}" type="button"
                                    class="nav-link text-capitalize">Usage History</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body px-4 py-0">
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_coupons" role="tabpanel">

                                <div class="d-flex justify-content-end align-items-center flex-wrap">
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" id="filter"
                                        title="Filter">
                                        <i class="mdi mdi-filter-outline text-center"></i>
                                    </a>
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2"
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_create_coupon">
                                        <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Create Coupons
                                    </a>
                                </div>
                                <div class="filter_tbox" style="display: none;">
                                    <form id="filter_form" method="POST" action="/lead/manage_coupon">
                                        @csrf
                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                        <input type="hidden" name="filter_on" value="1">
                                        <input type="hidden" name="fill_chk" value="1">
                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                            id="sorting_filter" value="@php echo $perpage ? $perpage : 25; @endphp" />
                                        <div class="row py-1">
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Coupons</label>
                                                <input type="text" class="form-control" name="coupon_fill"
                                                    id="coupon_fill" value="{{ $coupon_fill ?? '' }}"
                                                    placeholder="Enter Coupon Name" />
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Type</label>
                                                <select class="select3 form-select" id="coupon_type_fill"
                                                    name="coupon_type_fill">
                                                    <option value=""
                                                        @if ($coupon_type_fill == '') selected @endif>All</option>
                                                    <option value="rupee"
                                                        @if ($coupon_type_fill == 'rupee') selected @endif>Rupee</option>
                                                    <option value="dollar"
                                                        @if ($coupon_type_fill == 'dollar') selected @endif>Dollar</option>
                                                    <option value="percentage"
                                                        @if ($coupon_type_fill == 'percentage') selected @endif>Percentage
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Max. Usage Count</label>
                                                <input type="text" class="form-control"
                                                    placeholder="Enter Max. Usage Count" value="{{ $max_usg_count_fill }}"
                                                    id="max_usg_count_fill" name="max_usg_count_fill" />
                                            </div>
                                            <div class="col-lg-3 mb-2">
                                                <div class="form-check form-check-inline mt-6">
                                                    <input class="form-check-input" type="checkbox" value="1"
                                                        @if ($multiple_check_fill == '1') checked @endif
                                                        id="multiple_check_fill" name="multiple_check_fill" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Multiple</label>
                                                </div>
                                                <div class="form-check form-check-inline mt-6">
                                                    <input class="form-check-input" type="checkbox" value="1"
                                                        @if ($public_check_fill == '1') checked @endif
                                                        id="public_check_fill" name="public_check_fill" />
                                                    <label class="text-dark mb-1 fs-6 fw-semibold">Public</label>
                                                </div>
                                            </div>
                                            {{-- <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Lead</label>
                                            <input type="text" class="form-control" id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                                    placeholder="Enter Lead - Name/ Mob. No"/>
                                        </div> --}}
                                            <div class="col-lg-3 mb-2">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                                <select class="select3 form-select" name="dt_fill_issue_rpt"
                                                    id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                                    <option value="all"
                                                        @if ($date_filter == 'all') selected @endif>All</option>
                                                    <option value="today"
                                                        @if ($date_filter == 'today') selected @endif>Today</option>
                                                    <option value="week"
                                                        @if ($date_filter == 'week') selected @endif>This Week</option>
                                                    <option value="monthly"
                                                        @if ($date_filter == 'monthly') selected @endif>This Month
                                                    </option>
                                                    <option value="custom_date"
                                                        @if ($date_filter == 'custom_date') selected @endif>Custom Date
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_acc_today_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_acc_week_st_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text bg-gray-200"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_acc_week_ed_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('d-M-Y'); ?>" disabled />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_acc_month_dt_fill"
                                                        placeholder="Select Date" class="form-control"
                                                        value="<?php echo date('M-Y'); ?>" />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_from_dt_fill" readonly
                                                        name="from_date_fillter_textbox" placeholder="Select Date"
                                                        class="form-control common_date_class"
                                                        value="<?php echo date('d-M-Y'); ?>" />
                                                </div>
                                            </div>
                                            <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                                <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                                <div class="input-group input-group-merge">
                                                    <span class="input-group-text"><i
                                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                    <input type="text" id="acc_daily_to_dt_fill" readonly
                                                        name="to_date_fillter_textbox" placeholder="Select Date"
                                                        class="form-control common_date_class"
                                                        value="<?php echo date('d-M-Y'); ?>" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-end align-items-center">
                                            <a href="{{ url('/lead/manage_coupon') }}" type="button"
                                                class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                                            <button type="submit" class="btn btn-sm btn-primary">Go</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="row">
                                    <div class="mb-2">
                                        @php $perpage_count = $perpage ? $perpage : 1; @endphp
                                        <div>
                                            <span>Show</span>
                                            <br>
                                            <select id="perpage" name="perpage"
                                                class="form-select form-select-sm w-60px"
                                                onchange="sort_filter(this.value);">
                                                @php
                                                    $options = [10, 25, 100, 500]; // Define available options
                                                @endphp
                                                @foreach ($options as $option)
                                                    <option value="{{ $option }}"
                                                        @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                        @php echo $option; @endphp
                                                    </option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <table
                                            class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-100px">Coupons</th>
                                                    <th class="min-w-100px">Coupon Code</th>
                                                    <th class="min-w-100px">Coupon<br>Type</th>
                                                    <th class="min-w-125px">Expiry Date /<br>Max. Usage</th>
                                                    <th class="min-w-100px">Public /<br> Unlimited</th>
                                                    {{-- <th class="min-w-100px">Assigned<br>Lead</th> --}}
                                                    <th class="min-w-50px">Status</th>
                                                    <th class="min-w-50px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                @if (count($coupon_list) > 0)
                                                    @foreach ($coupon_list as $i => $c_list)
                                                        <tr>
                                                            <td>
                                                                <label
                                                                    class="fw-semibold text-black fs-7">{{ $c_list->coupon_name }}</label>
                                                                <div class="d-block">
                                                                    <label class="text-secondary fs-8 fw-bold me-1"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom" title="Created Date">
                                                                        {{ date('d-M-Y', strtotime($c_list->created_at)) }}
                                                                    </label>
                                                                </div>


                                                            </td>
                                                            <td>
                                                                <div class="d-block">
                                                                    <label class="text-info fs-8 fw-bold me-1"
                                                                        id="coup_code_val_td_{{ $i }}">{{ $c_list->coupon_code }}</label>
                                                                    <a href="javascript:;"
                                                                        class="cpy-btn btn btn-sm btn-label-primary px-2 py-1"
                                                                        data-clipboard-action="copy"
                                                                        data-clipboard-target="#coup_code_val_td_{{ $i }}"
                                                                        onclick="copyToClipboard({{ $i }});">
                                                                        <i
                                                                            class="mdi mdi-content-copy fs-6 text-black"></i>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                @if ($c_list->coupon_type == 'rupee')
                                                                    <label
                                                                        class="badge bg-info fw-semibold text-white fs-7">&#8377;
                                                                        {{ $c_list->coupon_value }}</label>
                                                                @elseif($c_list->coupon_type == 'percentage')
                                                                    <label
                                                                        class="badge bg-info fw-semibold text-white fs-7">{{ $c_list->coupon_value }}
                                                                        %</label>
                                                                @elseif($c_list->coupon_type == 'dollar')
                                                                    <label
                                                                        class="badge bg-info fw-semibold text-white fs-7">&dollar;
                                                                        {{ $c_list->coupon_value }}</label>
                                                                @endif
                                                                @if ($c_list->end_date < date('Y-m-d', strtotime('-1 day')) && $c_list->unexpired_check == 0)
                                                                    <div class="d-block mt-1">
                                                                        <label
                                                                            class="badge bg-success fw-semibold text-white fs-8">Expired</label>
                                                                    </div>
                                                                @endif
                                                            </td>
                                                            <td>
                                                                @if ($c_list->unexpired_check == 1)
                                                                    <label
                                                                        class="badge bg-danger fw-semibold text-white fs-8">No
                                                                        Expiry</label>
                                                                    <label class="fw-bold text-black">&nbsp;/&nbsp;</label>
                                                                    <label
                                                                        class="badge bg-warning rounded-circle fs-8 fw-semibold text-black">{{ sprintf('%02d', $c_list->max_usage_count) }}</label>
                                                                @else
                                                                    <label
                                                                        class="badge bg-danger fw-semibold text-white fs-8">{{ $c_list->end_date ? date($common_date_format, strtotime($c_list->end_date)) : '-' }}</label>
                                                                    <label class="fw-bold text-black">&nbsp;/&nbsp;</label>
                                                                    <label
                                                                        class="badge bg-warning rounded-circle fs-8 fw-semibold text-black">{{ sprintf('%02d', $c_list->max_usage_count) }}</label>
                                                                @endif
                                                            </td>
                                                            <td>
                                                                <label class="fw-semibold text-black fs-7">
                                                                    @if ($c_list->public_check == 1)
                                                                        Public
                                                                    @else
                                                                        -
                                                                    @endif
                                                                </label>
                                                                <label class="fw-bold text-black me-1 ms-1">/</label>
                                                                <label class="fw-semibold text-black fs-7">
                                                                    @if ($c_list->multiple_check == 1)
                                                                        Unlimited
                                                                    @else
                                                                        -
                                                                    @endif
                                                                </label>
                                                            </td>
                                                            {{-- <td>
                                                    <label class="fw-semibold text-black fs-7">{{ $c_list->lead_name ?? '-' }}</label>
                                                    <div class="d-block">
                                                        <label class="fw-semibold text-dark fs-8">{{ $c_list->lead_mobile ?? '-' }}</label>
                                                    </div>
                                                </td> --}}
                                                            <td>
                                                                <label class="switch switch-square">
                                                                    <input type="checkbox" class="switch-input"
                                                                        {{ $c_list->coupon_status == 0 ? 'checked' : '' }}
                                                                        onchange="updateslotStatus('{{ $c_list->sno }}', this.checked)" />
                                                                    <span class="switch-toggle-slider">
                                                                        <span class="switch-on"></span>
                                                                        <span class="switch-off"></span>
                                                                    </span>
                                                                </label>
                                                            </td>
                                                            <td>
                                                                <span class="text-end">
                                                                    <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_delete_coupon"
                                                                        onclick="confirmDelete('{{ $c_list->sno }}','{{ $c_list->coupon_name }}','{{ $c_list->coupon_id }}')">
                                                                        <span data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="Delete">
                                                                            <i
                                                                                class="mdi mdi-delete-outline fs-3 text-black"></i>
                                                                        </span>
                                                                    </a>
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-4">
                                        {{ $coupon_list->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--begin::Modal - Add Coupons-->
        <div class="modal fade" id="kt_modal_create_coupon" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
            data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Create Coupon</h3>
                        </div>
                        <form id="addCouponForm" action="{{ route('add_coupon') }}" method="POST"
                            onsubmit="return AddvalidateForm(event)" novalidate>
                            @csrf
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Coupon Name"
                                        maxlength="150" id="coupon_name" name="coupon_name" value="" />
                                    <div class="text-danger" id="coupon_name_err"></div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Type<span
                                            class="text-danger">*</span></label>
                                    <div class="d-flex align-items-center justify-content-start">
                                        <input type="text" class="form-control" placeholder="Enter Value"
                                            maxlength="6"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                            value="" id="coupon_value" name="coupon_value" />
                                        <div class="ms-2 min-w-150px mw-150px">
                                            <select class="select3 form-select" id="coupon_type" name="coupon_type">
                                                <option value="rupee" selected>Rupee</option>
                                                <option value="dollar">Dollar</option>
                                                <option value="percentage">Percentage</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="text-danger" id="coupon_value_err"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Coupon Code<span
                                            class="text-danger">*</span></label>
                                    <div class="mb-1" id="gen_code">
                                        <label class="text-black fs-4 fw-bold me-3" id="coup_code_val"
                                            name="coup_code_val"></label>
                                        <a href="javascript:;" class="cpy-btn btn btn-sm btn-label-primary px-2 py-1"
                                            id="copy_gen_code" data-clipboard-action="copy"
                                            data-clipboard-target="#coup_code_val">
                                            <i class="mdi mdi-content-copy fs-4 text-black"></i>
                                        </a>
                                    </div>
                                    <div class="mb-1" id="cust_code" style="display:none">
                                        <input type="text" class="form-control" placeholder="Enter Coupon Code"
                                            id="coupon_code_cust" name="coupon_code_cust" value=""
                                            maxlength="50" />
                                    </div>
                                    <div class="text-danger" id="coupon_code_err"></div>
                                </div>
                                <div class="col-lg-3 mb-3 d-flex align-items-center justify-content-start">
                                    <a href="javascript:;" class="btn btn-sm btn-primary" id="gen_butt">Generate</a>
                                </div>
                                <div class="col-lg-3 mb-3 d-flex align-items-center justify-content-start">
                                    <a href="javascript:;" class="btn btn-sm btn-primary" id="custom_butt">Custom</a>
                                </div>
                                <div class="col-lg-6 mb-3 max_count">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Maximum Usage Count</label>
                                    <input type="text" class="form-control" placeholder="Enter Usage Count"
                                        value="" maxlength="3"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                        id="max_usg_count"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                        name="max_usg_count" />
                                </div>
                                <div class="col-lg-6 mb-3 d-flex align-items-center justify-content-start">
                                    <div class="form-check form-check-inline mt-6">
                                        <input class="form-check-input" type="checkbox" value="1"
                                            id="multiple_check" name="multiple_check" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Unlimited</label>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3" id="dur_div">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Duration</label>
                                    <div class="d-flex align-items-center justify-content-start">
                                        <input type="text" class="form-control" placeholder="Duration" value=""
                                            id="coupon_dur" name="coupon_dur" maxlength="2"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                        <div class="ms-2 min-w-125px mw-125px">
                                            <select class="select3 form-select" id="coupon_dur_type"
                                                name="coupon_dur_type">
                                                <option value="1">Days</option>
                                                <option value="2">Week</option>
                                                <option value="3">Month</option>
                                                <option value="4">Year</option>
                                                <option value="5">Life Time</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-3 d-flex align-items-center justify-content-start">
                                    <div class="form-check form-check-inline mt-6">
                                        <input class="form-check-input" type="checkbox" value="1" id="public_check"
                                            name="public_check" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Public</label>
                                    </div>
                                </div>
                                <div class="col-lg-3 mb-3 d-flex align-items-center justify-content-start">
                                    <div class="form-check form-check-inline mt-6">
                                        <input class="form-check-input" type="checkbox" value="1"
                                            id="unexpired_check" name="unexpired_check" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold">No Expiry</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3" id="end_dt_div">
                                    <div class="row">
                                        <label class="col-5 text-black fs-6 fw-semibold">End Date</label>
                                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                                        <label class="col-6 text-black fs-6 fw-bold" id="coupon_end_dt"
                                            name="coupon_end_dt"></label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assign Branch<span
                                            class="text-danger">*</span></label>
                                    <select name="branch_id[]" class="select3 form-select" id="branchSelect_coupon"
                                        multiple>

                                    </select>
                                    <div class="text-danger" id="branch_err"></div>
                                </div>
                                <input type="hidden" id="hidden_coup_code_val" name="coup_code_val" />
                                <input type="hidden" id="hidden_coupon_end_dt" name="coupon_end_dt" />
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary" id="coupon_submit">Create Coupons</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Add Coupons-->

        <!--begin::Modal - Delete Coupons-->
        <div class="modal fade" id="kt_modal_delete_coupon" tabindex="-1" aria-hidden="true" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-m">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                        <div class="swal2-icon-content">?</div>
                    </div>
                    <div class="swal2-html-container" id="swal2-html-container" style="display: block;"><span
                            id="delete_message"></span></div>
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-danger me-3"onclick="deleteCourseCategory()">Yes,
                            delete!</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                    </div>
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Delete Coupons-->


        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        <style>
            /* Customize Toastr notification */
            .toast-success {
                background-color: green;
            }

            /* Customize Toastr notification */
            .toast-error {
                background-color: rgb(196, 3, 3);
            }

            .error_msg {
                border: solid 2px red !important;
                border-color: red !important;
            }
        </style>

        <script>
            // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
        </script>
        <script>
            $(document).ready(function() {

                $.ajax({
                    url: "{{ route('bran_drop_down') }}", // Only works inside Blade
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var BranchDropdown = $('#branchSelect_coupon');

                            if (BranchDropdown.length === 0) {
                                console.error('Dropdown element not found!');
                                return;
                            }

                            BranchDropdown.empty();
                            BranchDropdown.append('<option value="">Select Branch / Franchise</option>');

                            var branchGroup = $('<optgroup label="Branch"></optgroup>');
                            var franchiseGroup = $('<optgroup label="Franchise"></optgroup>');

                            response.data.forEach(function(branch) {
                                if (branch.branch_type == 1) {
                                    branchGroup.append($('<option></option>')
                                        .attr('value', branch.sno)
                                        .text(branch.branch_name));
                                } else if (branch.branch_type == 2) {
                                    franchiseGroup.append($('<option></option>')
                                        .attr('value', branch.sno)
                                        .text(branch.franchise_name));
                                }
                            });

                            BranchDropdown.append(branchGroup);
                            BranchDropdown.append(franchiseGroup);
                        } else {
                            console.warn('Unexpected response format:', response);
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching data:', error);
                    }
                });
            });
        </script>

        <script>
            function generateCouponCode() {
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                let couponCode = '';

                for (let i = 0; i < 10; i++) {
                    const randomIndex = Math.floor(Math.random() * characters.length);
                    couponCode += characters[randomIndex];
                }

                return couponCode;
            }

            document.getElementById('gen_butt').addEventListener('click', function() {
                const code = generateCouponCode();
                // $('#coup_code_val').val(code);
                document.getElementById('coup_code_val').textContent = code;
            });
        </script>


        <script>
            // When the 'Custom' button is clicked
            document.getElementById('custom_butt').addEventListener('click', function() {
                // Show the input field and hide the label
                document.getElementById('cust_code').style.display = 'block';
                document.getElementById('gen_code').style.display = 'none';
            });

            // When the 'Generate' button is clicked
            document.getElementById('gen_butt').addEventListener('click', function() {
                // Hide the input field and show the label
                document.getElementById('cust_code').style.display = 'none';
                document.getElementById('gen_code').style.display = 'block';
            });
        </script>

        <script>
            // Function to copy coupon code to clipboard dynamically by index
            function copyToClipboard(index) {
                const couponCodeElement = document.getElementById('coup_code_val_td_' + index);
                const couponCodeText = couponCodeElement ? couponCodeElement.innerText : '';

                if (couponCodeText) {
                    // Check if Clipboard API is available
                    if (navigator.clipboard) {
                        // Use Clipboard API for modern browsers
                        navigator.clipboard.writeText(couponCodeText).then(function() {
                            toastr.success('Coupon code copied to clipboard!');
                        }).catch(function(err) {
                            toastr.error('Failed to copy coupon code.');
                        });
                    } else {
                        // Fallback to execCommand for older browsers or unsupported environments
                        const textArea = document.createElement('textarea');
                        textArea.value = couponCodeText;
                        document.body.appendChild(textArea);
                        textArea.select();

                        try {
                            document.execCommand('copy');
                            toastr.success('Coupon code copied to clipboard!');
                        } catch (err) {
                            toastr.error('Failed to copy coupon code.');
                        }

                        document.body.removeChild(textArea);
                    }
                } else {
                    toastr.error('No coupon code found.');
                }
            }
        </script>


        <script>
            $(document).ready(function() {
                @if ($filter_on ?? '')
                    $('.filter_tbox').slideToggle('fast');
                    // });
                @endif
            });

            // Toggle branch filter section
            $('#filter').click(function() {
                $('.filter_tbox').slideToggle('slow');
            });
        </script>

        <script>
            function date_fill_issue_rpt() {
                var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
                var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
                var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
                var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
                var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
                var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
                var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
                var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
                var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

                if (dt_fill_issue_rpt == "today") {
                    today_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "week") {
                    today_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "block";
                    week_to_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";

                    var curr = new Date; // get current date
                    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                    var last = first + 6; // last day is the first day + 6

                    var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                    firstday = firstday.split("-").reverse().join("-");
                    var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                    lastday = lastday.split("-").reverse().join("-");
                    $('#acc_daily_acc_week_st_dt_fill').val(firstday);
                    $('#acc_daily_acc_week_ed_dt_fill').val(lastday);

                } else if (dt_fill_issue_rpt == "monthly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "block";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "custom_date") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "block";
                    to_dt_iss_rpt.style.display = "block";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }
            }
        </script>

        <script>
            $(".list_page").DataTable({
                "ordering": false,
                "paging": false,
                // "aaSorting":[],
                "language": {
                    "lengthMenu": "Show _MENU_",
                },
                "dom": "<'row mb-3'" +
                    //   "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                    //   "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                    ">" +

                    "<'table-responsive'tr>" +

                    "<'row'" +
                    //   "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    //   "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                    ">"
            });
        </script>

        <script>
            function updateslotStatus(categoryId, isChecked) {
                // If categoryId is empty, log an error
                if (!categoryId) {
                    console.error('Category ID is missing');
                    return;
                }

                const status = isChecked ? 0 : 1; // Set status based on checkbox state

                fetch(`/coupon_status/${categoryId}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                        },
                        body: JSON.stringify({
                            status: status
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            console.log('Coupon status updated successfully:', data.message);
                            toastr.success('Coupon status updated successfully!');
                        } else {
                            console.error('Error updating Slot status:', data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating Slot status:', error);
                    });
            }
        </script>

        <script>
            function confirmDelete(id, name, ids) {
                document.querySelector('#kt_modal_delete_coupon .btn-danger').setAttribute(
                    'data-id', id);
                $('#delete_message').html('Are you sure you want to delete <br> <b>' + name + '</b> Coupon ?');
            }

            function deleteCourseCategory() {

                var categoryId = document.querySelector('#kt_modal_delete_coupon .btn-danger').getAttribute('data-id');

                fetch('/coupon_delete/' + categoryId, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log(data);
                        if (data.status === 200) {
                            toastr.success('Coupon Deleted successfully!');
                            location.reload();

                        } else {

                            console.error(data.error_msg);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            }
        </script>

        <script>
            function AddvalidateForm(event) {
                var err = 0;

                // Validate Coupon Name
                var coupon_name = document.getElementById("coupon_name").value.trim();
                if (coupon_name === "") {
                    document.getElementById('coupon_name_err').innerHTML = 'Coupon Name is required...!';
                    err++;
                } else {
                    document.getElementById('coupon_name_err').innerHTML = '';
                }

                // Validate Coupon Value
                var coupon_value = document.getElementById("coupon_value").value.trim();
                if (coupon_value === "") {
                    document.getElementById('coupon_value_err').innerHTML = 'Coupon Value is required...!';
                    err++;
                } else {
                    document.getElementById('coupon_value_err').innerHTML = '';
                }

                // Validate Coupon Code (both generated and custom)
                var coupon_code_cust = document.getElementById("coupon_code_cust").value.trim();
                var coup_code_val = document.getElementById("coup_code_val").innerText.trim();

                if (coupon_code_cust === "" && coup_code_val === "") {
                    document.getElementById('coupon_code_err').innerHTML = 'Coupon Code is required...!';
                    err++;
                } else {
                    document.getElementById('coupon_code_err').innerHTML = '';
                }

                var branchSelect_coupon = document.getElementById("branchSelect_coupon").value.trim();
                if (branchSelect_coupon === "") {
                    document.getElementById('branch_err').innerHTML = 'Branch is required...!';
                    err++;
                } else {
                    document.getElementById('branch_err').innerHTML = '';
                }

                // If there are any errors, prevent form submission
                if (err > 0) {
                    event.preventDefault(); // This prevents the form from submitting
                    return false; // Return false to stop form submission
                }

                // If no errors, allow form submission
                $('#coupon_submit').prop('disabled', true);
                return true; // Allow form submission
            }
        </script>

        <script>
            // Get the checkbox and max_count div
            const multipleCheck = document.getElementById('multiple_check');
            const maxCountDiv = document.querySelector('.max_count');

            // Function to toggle visibility based on checkbox state
            function toggleMaxCountVisibility() {
                if (multipleCheck.checked) {
                    maxCountDiv.style.display = 'none';
                } else {
                    maxCountDiv.style.display = 'block';
                }
            }

            // Run the function initially in case the checkbox is already checked
            toggleMaxCountVisibility();

            // Add an event listener to the checkbox to handle changes
            multipleCheck.addEventListener('change', toggleMaxCountVisibility);
        </script>

        <script>
            // Wait for the DOM to be fully loaded
            document.addEventListener('DOMContentLoaded', function() {
                // Get elements
                const couponDurInput = document.getElementById('coupon_dur');
                const couponDurType = document.getElementById('coupon_dur_type');
                const couponEndDtLabel = document.getElementById('coupon_end_dt');

                // Function to calculate the end date
                function calculateEndDate() {
                    const duration = parseInt(couponDurInput.value, 10);
                    const durType = parseInt(couponDurType.value, 10);

                    if (isNaN(duration) || duration <= 0) {
                        couponEndDtLabel.textContent = '';
                        return;
                    }

                    const startDate = new Date();
                    let endDate = new Date(startDate);

                    // Adjust the end date based on duration type
                    switch (durType) {
                        case 1: // Days
                            endDate.setDate(startDate.getDate() + duration);
                            break;
                        case 2: // Week
                            endDate.setDate(startDate.getDate() + (duration * 7)); // Multiply by 7 for weeks
                            break;
                        case 3: // Month
                            endDate.setMonth(startDate.getMonth() + duration);
                            break;
                        case 4: // Year
                            endDate.setFullYear(startDate.getFullYear() + duration);
                            break;
                        case 5: // Lifetime (100 years later)
                            endDate.setFullYear(startDate.getFullYear() + 100);
                            break;
                        default:
                            break;
                    }

                    // Manually format the date as 'DD-MMM-YYYY'
                    const day = endDate.getDate().toString().padStart(2, '0');
                    const month = endDate.toLocaleString('default', {
                        month: 'short'
                    }); // Get 3-letter month abbreviation
                    const year = endDate.getFullYear();

                    // Format the date as 'DD-MMM-YYYY'
                    const formattedDate = `${day}-${month}-${year}`;

                    // Set the end date label
                    couponEndDtLabel.textContent = formattedDate;
                }

                // Event listeners for input changes
                couponDurInput.addEventListener('input', calculateEndDate);
                couponDurType.addEventListener('change', calculateEndDate);

                // Initial calculation if there's any default value
                calculateEndDate();
            });
        </script>


        <script>
            document.getElementById('addCouponForm').addEventListener('submit', function(event) {

                var couponCode = document.getElementById('coup_code_val').textContent.trim();
                var couponEndDate = document.getElementById('coupon_end_dt').textContent.trim();

                if (couponCode !== "") {
                    document.getElementById('hidden_coup_code_val').value = couponCode;
                } else {
                    document.getElementById('hidden_coup_code_val').value = "";
                }

                if (couponEndDate !== "") {
                    document.getElementById('hidden_coupon_end_dt').value = couponEndDate;
                } else {
                    document.getElementById('hidden_coupon_end_dt').value = "";
                }
            });
        </script>
        <script>
            function sort_filter(val) {
                if (val != "") {
                    $('.sorting_filter_class').val(val);
                    $('#filter_form').submit();
                } else {
                    $('.sorting_filter_class').val(25);
                    $('#filter_form').submit();
                }
            }
        </script>

        <script>
            // Function to toggle visibility based on the 'Unexpired' checkbox state
            document.getElementById('unexpired_check').addEventListener('change', function() {
                const durDiv = document.getElementById('dur_div');
                const endDtDiv = document.getElementById('end_dt_div');

                // If the 'Unexpired' checkbox is checked, hide the duration and end date sections
                if (this.checked) {
                    durDiv.style.display = 'none';
                    endDtDiv.style.display = 'none';
                } else {
                    durDiv.style.display = 'block';
                    endDtDiv.style.display = 'block';
                }
            });
        </script>
        <script>
            document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
                el.addEventListener('click', function() {
                    // Small delay to allow modal animation to finish
                    setTimeout(() => {
                        location.reload();
                    }, 150);
                });
            });
        </script>

    @endsection
