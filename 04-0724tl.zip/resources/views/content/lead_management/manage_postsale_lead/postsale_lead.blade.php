@extends('layouts/layoutMaster')

@section('title', 'Manage Postsale Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data = $helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
        $module_name = 'Lead Management';
        $menu_name = 'Manage Postsale Lead';
    @endphp
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            /* padding: 7px 15px 7px 7px !important; */
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Postsale Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
                    {{-- <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #c2fbb6 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Customer</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #fcff66 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Postsale Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #6fd1fb !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Hot Postsale Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: lightpink !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Pending</label>
                    </div> --}}
                    {{-- <div class="d-flex align-items-center px-1 py-1">
                         <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"  id="filter">
                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"  title="Filter">
                                <i class="mdi mdi-filter-outline text-center"></i>
                            </span>
                        </a>
                    </div> --}}
                </div>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">

            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="row">
                            {{-- <div class="col-lg-8 d-flex flex-wrap align-items-center mb-2">
                                <a href="#" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Total Number of Leads">
                                    <div class="text-dark fw-semibold fs-6 mb-1">Total Postsale Lead</div>
                                    <div class="mb-3">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead.png') }}" alt="Lead Icon"
                                            class="w-80px h-50px text-black fw-bold">
                                    </div>
                                    <div class="d-block">
                                        <div class="badge bg-gray-600i rounded fw-bold fs-5">
                                            {{ sprintf('%02d', $leadOriginalCount) }}</div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Current Month Leads">
                                    <div class="text-dark fw-semibold fs-6 mb-1">Postsale Leads (<?php echo date('F'); ?>)</div>
                                    <div class="mb-3">
                                        <img src="{{ asset('assets/phdizone_images/lead/month.png') }}"
                                            alt="Current Month Lead Icon" class="w-55px h-50px text-black fw-bold">
                                    </div>
                                    <div class="d-block mt-2">
                                        <div class="badge bg-gray-600i rounded fw-bold fs-5">
                                            {{ sprintf('%02d', $currentMonthLeadCount) }}</div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Conversion Rate">
                                <div class="text-dark fw-semibold fs-6 mb-1">Total ACR</div>
                                <div class="mb-3">
                                    <img src="{{asset('assets/phdizone_images/lead/convertion.png')}}" alt="Avg. Conversion Icon" class="w-55px h-50px text-black fw-bold">
                                </div>
                                <div class="d-block mt-2">
                                    <div class="badge bg-gray-600i rounded fw-bold fs-5">90 %</div>
                                </div>
                            </a>
                            <a href="#" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Current Month Conversion">
                                <div class="text-dark fw-semibold fs-6 mb-1">Conversion (<?php echo date('F'); ?>)</div>
                                <div class="mb-3">
                                    <img src="{{asset('assets/phdizone_images/lead/calendar.png')}}" alt="Current Month Conversion Icon" class="w-55px h-50px text-black fw-bold">
                                </div>
                                <div class="d-block mt-2">
                                    <div class="badge bg-gray-600i rounded fw-bold fs-5">80 %</div>
                                </div>
                            </a>
                                <a href="#" class="text-center border border-2 p-2">
                                    <div class="text-dark fw-semibold fs-6 mb-1">Pending Followup</div>
                                    <div class="mb-3">
                                        <img src="{{ asset('assets/phdizone_images/lead/pending_followup.png') }}"
                                            alt="Pending Followup Icon" class="w-55px h-50px text-black fw-bold">
                                    </div>
                                    <div class="d-block mt-2">
                                        <div class="badge bg-gray-600i rounded fw-bold fs-5">01</div>
                                    </div>
                                </a>
                            </div> --}}
                            <div class="col-lg-8"></div>
                            <div class="col-lg-4 mb-2 d-flex  align-items-end justify-content-end">
                                <div class="d-flex align-items-end justify-content-end ">
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_lead_import">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Export"><i
                                                class="mdi mdi-calendar-export-outline"></i></span>
                                    </a>
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2" id="filter">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter"><i
                                                class="mdi mdi-filter-outline text-center"></i></span>
                                    </a>
                                </div>
                                <div class="d-flex align-items-end justify-content-end ">

                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                        data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead">
                                        <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Postsale Lead
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="filter_tbox" style="display: none;">
                            <form id="filter_form" method="POST" action="/manage_post_sale_lead">
                                @csrf
                                <div class="row py-1">
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="1">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                        id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />

                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Gender</label>
                                        <select class="select3 form-select" name="gender_fill" id="gender_fill">
                                            <option value="">All</option>
                                            <option value="1" @if ($gender_fill == '1') selected @endif>Male
                                            </option>
                                            <option value="2" @if ($gender_fill == '2') selected @endif>Female
                                            </option>
                                            <option value="3" @if ($gender_fill == '3') selected @endif>Others
                                            </option>
                                        </select>
                                    </div>

                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source</label>
                                        <select class="select3 form-select" id="lead_source_fill" name="lead_source_fill">
                                            <option value="">All</option>
                                            @if (isset($CourseCategory))
                                                @foreach ($CourseCategory as $course_ty_fill)
                                                    <option value="{{ $course_ty_fill->sno }}"
                                                        @if ($course_ty_fill->sno == $lead_source_fill) selected @endif>
                                                        {{ $course_ty_fill->lead_source_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Potential Type</label>
                                        <select class="select3 form-select" id="potential_type_fill"
                                            name="potential_type_fill">
                                            <option value="">All</option>
                                            @if (isset($PotentialType))
                                                @foreach ($PotentialType as $course_ty_fill)
                                                    <option value="{{ $course_ty_fill->sno }}"
                                                        @if ($course_ty_fill->sno == $potential_type_fill) selected @endif>
                                                        {{ $course_ty_fill->potential_type_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales Person</label>
                                        <select id="staff_fill" name="staff_fill" class="select3 form-select">
                                            <option value="">Select Sales Person</option>
                                            @if (isset($staff_filter_list))
                                                @foreach ($staff_filter_list as $staff_li)
                                                    <option value="{{ $staff_li->sno }}"
                                                        @if ($staff_li->sno == $staff_fill) selected @endif>
                                                        {{ $staff_li->nick_name }} - {{ $staff_li->staff_name }}
                                                    </option>
                                                @endforeach
                                            @endif
                                            <option value="0">Old Staff</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                                        <select class="select3 form-select" name="lead_status_fill" id="lead_status_fill">
                                            <option value="">All</option>
                                            <option value="0" @if ($lead_status_fill == 0) selected @endif>Active
                                            </option>
                                            <!--<option value="1" @if ($lead_status_fill == 1) selected @endif>Inactive</option>-->
                                            <option value="4" @if ($lead_status_fill == 4) selected @endif>
                                                Customer</option>
                                            <option value="5" @if ($lead_status_fill == 5) selected @endif>Dead
                                            </option>
                                            <option value="7" @if ($lead_status_fill == 7) selected @endif>Spam
                                            </option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                        <select class="select3 form-select" name="dt_fill_issue_rpt"
                                            id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                            <option value="all" @if ($date_filter == 'all') selected @endif>All
                                            </option>
                                            <option value="today" @if ($date_filter == 'today') selected @endif>
                                                Today</option>
                                            <option value="week" @if ($date_filter == 'week') selected @endif>This
                                                Week
                                            </option>
                                            <option value="monthly" @if ($date_filter == 'monthly') selected @endif>
                                                This Month
                                            </option>
                                            <option value="custom_date"
                                                @if ($date_filter == 'custom_date') selected @endif>Custom Date
                                            </option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date"
                                                class="form-control this_month_dt_fill" value="<?php echo date('M-Y'); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_custom_from_dt_fill" placeholder="Select Date"
                                                readonly name="from_date_fillter_textbox"
                                                class="form-control common_date_class" value="<?php echo date('d-M-Y'); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_custom_to_dt_fill" placeholder="Select Date"
                                                class="form-control common_date_class" readonly
                                                name="to_date_fillter_textbox" value="<?php echo date('d-M-Y'); ?>" />
                                        </div>
                                    </div>
                                    {{-- <div class="col-lg-3 mb-2">
                                                <label></label>
                                                <div><input class="form-check-input me-1" type="checkbox"
                                                        name="tranfer_order" id="tranfer_order" value="1"
                                                        {{ $tranfer_order == 1 ? 'checked' : '' }}>
                                                    <span class="text-dark mb-1 fs-6 fw-semibold">Order By Transfer</span>
                                                </div>
                                            </div> --}}

                                </div>
                                <div class="d-flex justify-content-end mb-2">
                                    <a href="{{ url('/manage_post_sale_lead') }}" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
                                    </a>
                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                                </div>

                            </form>
                        </div>
                        <div class="row">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="mb-4">
                                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                                    <div>
                                        <span>Show</span>
                                        <br>
                                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                            onchange="sort_filter(this.value);">
                                            @php
                                                $options = [10, 25, 100, 500]; // Define available options
                                            @endphp
                                            @foreach ($options as $option)
                                                <option value="{{ $option }}"
                                                    @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                    @php echo $option; @endphp
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="ms-auto">
                                    @if (auth()->user()->hasPermission($module_name, 'Bulk Transfer', $menu_name))
                                        <a href="javascript:;" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_bulk_convert_sales_person" id="bulkConversionBtn"
                                            style="display:none">
                                            <span class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2 "><i
                                                    class="mdi mdi-transfer fs-5"></i> Bulk
                                                Transfer</span>
                                        </a>
                                    @endif
                                </div>
                                <div class="mb-2">
                                    <form id="filter_form" method="POST" action="/manage_post_sale_lead">
                                        @csrf
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="mb-1">
                                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                <input type="hidden" name="filter_on" value="0">
                                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                    id="sorting_filter"
                                                    value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                <input type="text" class="form-control" id="lead_fill"
                                                    name="lead_fill" value="{{ $lead_fill ?? '' }}"
                                                    placeholder="Enter Lead - Name/ Mob. No/ Email Id" />
                                            </div>
                                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1"
                                                onclick="search_filter_func()">Search</button>
                                            <a href="{{ url('/manage_post_sale_lead') }}" type="button"
                                                class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span
                                                    class="mdi mdi-refresh fs-6"></span>
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <table
                                    class="table align-top table-row-dashed table-striped table-hover gy-1 gs-2 lead_list list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">

                                            <th class="min-w-250px">Postsale Lead</th>
                                            <!-- <th class="min-w-100px">Mobile / LFD</th> -->
                                            <th class="min-w-125px">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Registered Date">RD</span> / <span data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Last Followup Date">LFD</span>
                                            </th>
                                            <th class="min-w-75px">Sales Person</th>
                                            {{-- <th class="min-w-100px">Followup Status</th> --}}
                                            <th class="min-w-80px text-center">Proposal</th>
                                            <th class="min-w-100px">Status</th>
                                            <th class="min-w-50px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @if (count($leads) > 0)
                                            @foreach ($leads as $i => $category)
                                                <tr class="{{ $category->just_dial_id > 0 && $category->lead_status_id == 1 ? 'highlight-row' : '' }}"
                                                    style="background-color: 
                                        
                                                            @if ($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8) lightpink;@elseif($category->status != 4 && $category->is_hot_lead == 1)#6fd1fb;@else{{ $category->lead_bg_color }} {{-- Use the existing color otherwise --}} @endif;">

                                                    <td>
                                                        <div class="d-flex align-items-center gap-1">
                                                            @if ($category->is_hot_lead == 2)
                                                                <div data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Hot Lead Star">
                                                                    <img src="{{ asset('assets/phdizone_images/lead/Star_animate.gif') }}"
                                                                        alt="Hot Lead Star"
                                                                        class="w-50px h-50px text-black fw-bold">
                                                                </div>
                                                            @endif
                                                            @if ($category->lead_appointment_status == 1)
                                                                <div class="animation-blink" data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Appointment Onprogress">
                                                                    <img src="{{ asset('assets/phdizone_images/lead/appointment.ico') }}"
                                                                        alt="Appointment Onprogress Icon"
                                                                        class="w-30px h-30px text-black fw-bold">
                                                                </div>
                                                            @endif
                                                            <div class="ms-1 mb-0">
                                                                <div class="d-flex align-items-center gap-2">
                                                                    <label
                                                                        class="fs-7 text-nowrap text-black fw-semibold">{{ trim($category->lead_name) }}</label>

                                                                    @if (isset($category->productsData) && count($category->productsData) > 0)
                                                                        <span
                                                                            class="text-dark fs-8 fw-semibold cursor-pointer"
                                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false"><span
                                                                                class="mdi mdi mdi-information fs-8"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Product"></span></span>
                                                                        <div
                                                                            class="dropdown-menu dropdown-menu-start w-350px">
                                                                            <div
                                                                                class="text-dark fs-6 text-center my-2 fw-semibold">
                                                                                Products</div>
                                                                            <hr class="mt-0 mb-2 border-dark">
                                                                            <div
                                                                                class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                                @if (isset($category->productsData))
                                                                                    @foreach ($category->productsData as $product)
                                                                                        <div
                                                                                            class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                                            <div
                                                                                                class="text-black mb-1 fw-semibold fs-5 me-2">
                                                                                                &#9733;
                                                                                            </div>
                                                                                            <div class="d-block">
                                                                                                <div
                                                                                                    class="text-black fw-semibold text-justify fs-7">
                                                                                                    {{ $product->product_name }}
                                                                                                </div>
                                                                                                <div
                                                                                                    class="fw-semibold text-info fs-8">
                                                                                                    {{ $product->product_category_name }}
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    @endforeach
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                    @if ($category->transfer_status == 1)
                                                                        <span id=""
                                                                            class="d-block boom badge text-black rounded-circle fw-semibold fs-8 p-1  mt-1 leadBoom"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_transfer_log"
                                                                            onclick="leadTransfer('{{ $category->sno }}', '{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $category->lead_source_name }}', '{{ $category->registered_date }}')"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="Transfer"
                                                                            style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                            T</span>
                                                                    @elseif(
                                                                        $category->lead_status_id == 1 &&
                                                                            $category->lead_score == null &&
                                                                            ($category->lead_condition == 1 || ($category->lead_condition == 2 && $category->status != 1)))
                                                                        <span id=""
                                                                            class="d-block boom badge text-black rounded fw-semibold fs-8 py-0 mt-1 leadBoom"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="New Lead"
                                                                            style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                            New Lead</span>
                                                                    @endif
                                                                </div>
                                                                <div class="d-block">
                                                                    <div class="d-flex align-items-center mb-0">
                                                                        @if ($category->lead_mobile)
                                                                            @if ($category->status != 7)
                                                                                <label
                                                                                    class="fs-7 text-dark fw-semibold me-1 text-nowrap">
                                                                                    @php
                                                                                        $call_chk = isset(
                                                                                            $category->inter_calls,
                                                                                        )
                                                                                            ? $category->inter_calls
                                                                                            : 0;
                                                                                        $countryCode =
                                                                                            $call_chk == 0
                                                                                                ? '+91'
                                                                                                : '+' .
                                                                                                    $category->inter_calls;
                                                                                        $mobileNumber =
                                                                                            $category->status == 1
                                                                                                ? 'XXXXXXXXXX'
                                                                                                : $category->lead_mobile;
                                                                                    @endphp
                                                                                    {{ $countryCode }}
                                                                                    {{ $mobileNumber }}
                                                                                </label>
                                                                            @endif
                                                                            @if ($category->status == 7)
                                                                                <label
                                                                                    class="fs-7 text-black fw-semibold me-1 text-nowrap"
                                                                                    title="Mobile No">
                                                                                    {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}
                                                                                </label>
                                                                            @endif
                                                                            @php
                                                                                $phoneVerifyContent = json_decode(
                                                                                    $category->phone_verify_content,
                                                                                    true,
                                                                                );
                                                                            @endphp
                                                                            @if ($category->phone_verify_status == 1)
                                                                                <a href="javascript:;"
                                                                                    class="fs-7 text-black fw-semibold me-1"
                                                                                    onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                    <span data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="Mobile No Verified"><i
                                                                                            class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                                                </a>
                                                                            @elseif($category->phone_verify_status == 2)
                                                                                <a href="javascript:;"
                                                                                    class="fs-7 text-black fw-semibold me-1"
                                                                                    onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                    <span data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="Mobile No. Not Verified">
                                                                                        <svg class="w-20px h-20px"
                                                                                            enable-background="new 0 0 500 500"
                                                                                            viewBox="0 0 500 500"
                                                                                            id="hand-draw-white-cross-mark-on-red-circle">
                                                                                            <rect id="Layer_1"
                                                                                                fill="#fff0f0"
                                                                                                display="none">
                                                                                            </rect>
                                                                                            <g id="Layer_2">
                                                                                                <circle cx="250"
                                                                                                    cy="250" r="200"
                                                                                                    fill="#f32f45">
                                                                                                </circle>
                                                                                                <path fill="#f32f45"
                                                                                                    d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                                                                            l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                                                                            c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                                                                            c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                                                                            c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                                                                            c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                                                                            C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                                </path>
                                                                                                <path fill="#fff"
                                                                                                    d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                                                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                                                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                                                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                                </path>
                                                                                            </g>
                                                                                        </svg>
                                                                                    </span>
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                    <div class="d-flex align-items-center mb-0">
                                                                        @if ($category->lead_email_id)
                                                                            <label
                                                                                class="fs-7 text-dark fw-semibold me-1 text-truncate max-w-170px"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="{{ $category->lead_email_id }}">
                                                                                {{ $category->lead_email_id }}</label>
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                                <div class="d-block text-dark fs-8 mb-2 fw-semibold"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Id">
                                                                    {{ $category->lead_id ?? '' }}</div>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div
                                                            class="d-flex align-items-center justify-content-start mb-2 gap-2">
                                                            <div>
                                                                @if (auth()->user()->user_id > 2)
                                                                    <label class="badge text-black fw-semibold fs-8"
                                                                        style="background-color:rgb(78, 202, 94);"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Lead Registered Date">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) : date($common_date_format, strtotime($category->created_at)) }}</label>
                                                                @else
                                                                    <label
                                                                        class="badge text-black fw-semibold fs-8 cursor-pointer"
                                                                        style="background-color:rgb(78, 202, 94);"
                                                                        data-bs-toggle="dropdown" aria-haspopup="true"
                                                                        aria-expanded="false">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) : date($common_date_format, strtotime($category->created_at)) }}</label>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_register_date_change"
                                                                            onclick="confirmChangeDate('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->registered_date }}')">Change
                                                                            Date</a>
                                                                    </div>
                                                                @endif

                                                                @if (isset($category->appointment_date))
                                                                    <hr class="mt-1 mb-1">
                                                                    <div class="d-block mt-1">
                                                                        <label
                                                                            class="badge bg-body text-danger fw-semibold fs-8"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Last Follow Up Date">
                                                                            {{ $category->appointment_date ? date($common_date_format, strtotime($category->appointment_date)) : '' }}</label>
                                                                    </div>
                                                                @endif


                                                                <div>
                                                                    <a href="javascript:;"
                                                                        class="badge bg-info fs-8 rounded text-white fw-semibold me-1">

                                                                        <span data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Life Time">{{ $category->formattedDifference ?? '0 day' }}</span>


                                                                    </a>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex gap-2">
                                                            <span
                                                                class="text-truncate max-w-125px fw-semibold fs-7 text-black"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->nick_name ?? 'Old Staff' }}">{{ $category->staff_name ?? 'Old Staff' }}</span>
                                                            <div class="avatar avatar-sm me-1">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    onclick="openCallHistoryModal('{{ $category->sno }}','Outgoing','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}' ,'{{ $category->incoming_count }}','{{ $category->outgoing_count }}','{{ $category->missed_reject_count }}','{{ $category->dialed_count }}')"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_call_log">
                                                                    <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Outgoing Calls Count">
                                                                        <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                            alt="Outgoing Call Icon"
                                                                            class="w-15px h-15px text-black fw-bold">
                                                                    </div>
                                                                    @if ($category->outgoing_count > 0)
                                                                        <span
                                                                            class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                            style="background-color: #FFA500 !important;">{{ $category->outgoing_count }}</span>
                                                                    @endif
                                                                </a>
                                                            </div>
                                                        </div>
                                                        <div class="d-block">
                                                            @if ($category->just_dial_id > 0)
                                                                <label
                                                                    class="badge bg-white text-primary rounded fw-bold fs-6 blink source-label"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    <span class="jd-blue">Just</span><span
                                                                        class="jd-orange">dial</span>
                                                                </label>
                                                            @elseif($category->cloud_call_id > 0)
                                                                <label
                                                                    class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    <i class="fas fa-cloud cc-icon"></i><span
                                                                        class="cc-purple">Cloud</span><span
                                                                        class="cc-purple">Call</span>
                                                                </label>
                                                            @elseif($category->call_tracker_id > 0)
                                                                <label
                                                                    class="badge ct-orange text-white rounded fw-bold fs-8 blink source-label"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    <span>Tra<i
                                                                            class="mdi mdi-phone-in-talk ct-icon"></i>cker</span>
                                                                </label>
                                                            @elseif($category->website_id > 0)
                                                                <label
                                                                    class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    <span class="text-primary">Web</span><span
                                                                        class="text-primary">Site</span>
                                                                </label>
                                                            @elseif($category->lead_source_id == 20)
                                                                <span
                                                                    class="qr-badge d-inline-flex align-items-center gap-1 fs-7"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    <i
                                                                        class="mdi mdi-qrcode-scan fs-7"></i>{{ $category->lead_source_name ?? '-' }}
                                                                </span>
                                                            @else
                                                                <label
                                                                    class="badge bg-secondary text-white rounded fw-semibold fs-8 "
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">
                                                                    {{ $category->lead_source_name ?? '-' }}
                                                                </label>
                                                            @endif
                                                        </div>
                                                    </td>
                                                    {{-- <td>
                                                        <div class="d-flex align-items-center mt-2 gap-1">

                                                            @if ($category->potential_type_image != '' && file_exists(public_path('potential_image/' . $category->potential_type_image)))
                                                                <img src="{{ asset('potential_image/' . $category->potential_type_image) }}"
                                                                    alt="Image" class="w-35px h-35px"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="{{ $category->potential_type_name ?? '' }}">
                                                            @else
                                                                <a href="javascript:;"
                                                                    class="badge bg-label-danger border border-gray-400 rounded text-white fw-semibold fs-8 px-1 py-0"
                                                                    data-bs-toggle="dropdown" aria-haspopup="true"
                                                                    aria-expanded="false"
                                                                    style="background-color: #F0913D !important;"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Add Potential Type">
                                                                    <span><i class="mdi mdi-plus fs-5"></i></span>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    @if (isset($potential_list))
                                                                        @foreach ($potential_list as $plist)
                                                                            <a href="javascript:;"
                                                                                class="dropdown-item border-bottom"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_premium_potential_type"
                                                                                onclick="potentialUpdate('{{ $category->sno }}','{{ $plist->sno }}')">
                                                                                <div class="d-flex align-items-center">
                                                                                    @if ($plist->potential_type_image != '' && file_exists(public_path('potential_image/' . $plist->potential_type_image)))
                                                                                        <div
                                                                                            class="border border-primary rounded px-1 py-1 me-2">
                                                                                            <img src="{{ asset('potential_image/' . $plist->potential_type_image) }}"
                                                                                                alt="Premium Potential Icon"
                                                                                                class="w-25px h-25px text-black fw-bold">
                                                                                        </div>
                                                                                    @endif
                                                                                    <div>
                                                                                        {{ $plist->potential_type_name }}
                                                                                    </div>
                                                                                </div>
                                                                            </a>
                                                                        @endforeach
                                                                    @endif
                                                                </div>
                                                            @endif
                                                            @if ($category->status != 7 && $category->spam_verified != 1)
                                                                @if ($category->appointment_status == 1 && $category->status !== 4 && $category->status !== 10)
                                                                    <div class="avatar avatar-sm me-2">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_follow_up_lead_schedule"
                                                                            onclick="openResheduleModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                            <div class="border border-gray-500i rounded"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Followup">
                                                                                <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                                    alt="Premium Potential Icon"
                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                            </div>
                                                                            <span
                                                                                class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Followup Count"
                                                                                style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                            <span
                                                                                class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Followup Pending">!</span>
                                                                        </a>
                                                                    </div>
                                                                @elseif($category->appointment_status == 4 && $category->status !== 4 && $category->status !== 10)
                                                                    <!--<div class="avatar avatar-sm me-2">-->
                                                                    <!--    <a href="javascript:;"-->
                                                                    <!--        class="dropdown-item"-->
                                                                    <!--        data-bs-toggle="modal"-->
                                                                    <!--        data-bs-target="#kt_modal_again_follow_up_lead_schedule"-->
                                                                    <!--        onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">-->
                                                                    <!--        <div class="border border-gray-500i rounded"-->
                                                                    <!--            data-bs-toggle="tooltip"-->
                                                                    <!--            data-bs-placement="bottom"-->
                                                                    <!--            title="Followup">-->
                                                                    <!--            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"-->
                                                                    <!--                alt="Premium Potential Icon"-->
                                                                    <!--                class="w-30px h-30px text-black fw-bold">-->
                                                                    <!--        </div>-->
                                                                    <!--        <span-->
                                                                    <!--            class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"-->
                                                                    <!--            data-bs-toggle="tooltip"-->
                                                                    <!--            data-bs-placement="bottom"-->
                                                                    <!--            title="Followup Count"-->
                                                                    <!--            style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>-->
                                                                    <!--    </a>-->
                                                                    <!--</div>-->

                                                                    @if ($category->not_closed == 1)
                                                                        <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_not_closed"
                                                                                onclick="openNotClosedModal('{{ $category->created_by }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                                <span
                                                                                    class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup Count"
                                                                                    style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                            </a>
                                                                        </div>
                                                                    @else
                                                                        <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_again_follow_up_lead_schedule"
                                                                                onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                                <span
                                                                                    class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup Count"
                                                                                    style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                            </a>
                                                                        </div>
                                                                    @endif
                                                                @elseif($category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                                    <!--<div class="avatar avatar-sm me-2">-->
                                                                    <!--    <a href="javascript:;"-->
                                                                    <!--        class="dropdown-item"-->
                                                                    <!--        data-bs-toggle="modal"-->
                                                                    <!--        data-bs-target="#kt_modal_follow_up_lead"-->
                                                                    <!--        onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">-->
                                                                    <!--        <div class="border border-gray-500i rounded"-->
                                                                    <!--            data-bs-toggle="tooltip"-->
                                                                    <!--            data-bs-placement="bottom"-->
                                                                    <!--            title="Not Yet Followed">-->
                                                                    <!--            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"-->
                                                                    <!--                alt="Premium Potential Icon"-->
                                                                    <!--                class="w-30px h-30px text-black fw-bold">-->
                                                                    <!--        </div>-->
                                                                    <!--    </a>-->
                                                                    <!--</div>-->

                                                                    @if ($category->not_closed == 1)
                                                                        <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_not_closed"
                                                                                onclick="openNotClosedModal('{{ $category->created_by }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Not Yet Followed">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                    @else
                                                                        <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_follow_up_lead"
                                                                                onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Not Yet Followed">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                    @endif
                                                                @elseif($category->status == 5)
                                                                @endif
                                                            @endif

                                                        </div>

                                                        <!--<a href="javascript:;"-->
                                                        <!--    class="badge bg-label-danger border border-gray-400 rounded text-white fw-semibold fs-8 px-1 py-0"-->
                                                        <!--    data-bs-toggle="dropdown" aria-haspopup="true"-->
                                                        <!--    aria-expanded="false"-->
                                                        <!--    style="background-color: #F0913D !important;">-->
                                                        <!--    <span><i class="mdi mdi-plus fs-5"></i></span>-->
                                                        <!--    <span>Add Potential</span>-->
                                                        <!--</a>-->
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_premium_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                                            alt="Premium Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Premium Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_high_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                            alt="High Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>High Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_good_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                                                            alt="Good Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Good Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_medium_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                            alt="Medium Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Medium Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item border-bottom"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_critical_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/critical.png') }}"
                                                                            alt="Critical Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Critical Potential</div>
                                                                </div>
                                                            </a>
                                                            <a href="javascript:;" class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_low_potential_type">
                                                                <div class="d-flex align-items-center">
                                                                    <div
                                                                        class="border border-primary rounded px-1 py-1 me-2">
                                                                        <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                                                            alt="Low Potential Icon"
                                                                            class="w-25px h-25px text-black fw-bold">
                                                                    </div>
                                                                    <div>Low Potential</div>
                                                                </div>
                                                            </a>
                                                        </div>
                                                    </td> --}}
                                                    <td class="text-center">
                                                        @php
                                                            $encryptedValue = $helper->encrypt_decrypt(
                                                                $category->customer_sno,
                                                                'encrypt',
                                                            );
                                                            $new_service_url = url(
                                                                '/add_new_services/' . $encryptedValue,
                                                            );
                                                        @endphp
                                                        @if ($category->is_post_sale_lead == 0)
                                                            @if ($category->customer_sno > 0)
                                                                <a href="{{ $new_service_url }}"
                                                                    class="text-black fw-bold me-2">
                                                                    <span data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="Add New Service">
                                                                        <i
                                                                            class="mdi mdi-note-plus-outline fs-3 text-info fe-bold"></i>
                                                                    </span>
                                                                </a>
                                                            @else
                                                                -
                                                            @endif
                                                        @else
                                                            @if ($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                                @if (count($category->proposal_list) > 0)
                                                                    <a href="javascript:;"
                                                                        class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_view_quotation"
                                                                        onclick="revised_proposal_func('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_id }}',{{ $category->proposal_list }})"><i
                                                                            class="mdi mdi-note-plus-outline fs-3"></i>
                                                                        <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Proposal Count">
                                                                            <span
                                                                                class="fs-9">{{ count($category->proposal_list) }}</span>
                                                                        </div>
                                                                    </a>
                                                                @else
                                                                    <a href="javascript:;" class="text-black fw-bold"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_lead_quotation"
                                                                        onclick="create_proposal_func('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_id }}')">
                                                                        <span data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="Proposal"><i
                                                                                class="mdi mdi-note-plus-outline fs-3"></i></span>
                                                                    </a>
                                                                @endif
                                                            @else
                                                                <div>-</div>
                                                            @endif
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if ($category->status == 0)
                                                            <a href="javascript:;"
                                                                class="badge bg-info text-white rounded fw-bold fs-8"
                                                                data-bs-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                                Active
                                                            </a>
                                                        @elseif($category->status == 1)
                                                            <a href="javascript:;"
                                                                class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                data-bs-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false">
                                                                In Active
                                                            </a>
                                                        @elseif($category->status == 4)
                                                            <a href="javascript:;"
                                                                class="badge bg-success text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false">
                                                                Customer
                                                            </a>
                                                        @elseif($category->status == 5 && ($category->drop_verified == 0 || $category->drop_tl_verified == 0))
                                                            <a href="javascript:;"
                                                                class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"> Dead Lead
                                                                Awaiting
                                                            </a>
                                                        @elseif($category->status == 5 && $category->drop_verified == 1)
                                                            <a href="javascript:;"
                                                                class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"> Dead Lead </a>
                                                        @elseif($category->status == 5 && $category->drop_verified == 1)
                                                            <a href="javascript:;"
                                                                class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"> Dead Lead
                                                                Awaiting
                                                            </a>
                                                        @elseif($category->status == 7 && ($category->spam_verified == 0 || $category->spam_tl_verified == 0))
                                                            <a href="javascript:;"
                                                                class="badge bg-dark text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"> Spam Awaiting
                                                            </a>
                                                        @elseif($category->status == 7 && $category->spam_verified == 1)
                                                            <a href="javascript:;"
                                                                class="badge bg-dark text-white rounded fw-bold fs-8 mb-2"
                                                                id="" data-bs-toggle="dropdown"
                                                                aria-haspopup="true" aria-expanded="false"> Spam </a>
                                                        @endif
                                                        @php
                                                            $hot_lead_followup = $helper->getFollowupCount(
                                                                $category->sno,
                                                            );
                                                        @endphp
                                                        @if ($category->status == 0)
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <!--<a href="javascript:;" class="dropdown-item"-->
                                                                <!--    data-bs-toggle="modal"-->
                                                                <!--    data-bs-target="#kt_modal_lead_inactivate" onclick="inactiveModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Inactivate</a>-->
                                                                @if ($hot_lead_followup >= 2)
                                                                    @if ($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)
                                                                        <a href="javascript:;"
                                                                            class="dropdown-item d-none"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_hot_lead"
                                                                            onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot
                                                                            Lead</a>
                                                                    @elseif($category->lead_status_id != 3)
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_hot_lead"
                                                                            onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot
                                                                            Lead</a>
                                                                    @endif
                                                                @endif
                                                                @if ($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                                    {{-- @if ($category->dead_not_closed == 1)
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_drop_list"
                                                                            onclick="dropModalList('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')">Dead
                                                                            Lead</a>
                                                                    @else
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_drop"
                                                                            onclick="dropModal('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')">Dead
                                                                            Lead</a>
                                                                    @endif
                                                                    @if ($category->dead_not_closed == 1)
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_spam_list"
                                                                            onclick="spamModalList('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->created_by }}')">Spam
                                                                            Lead</a>
                                                                    @else
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_spam"
                                                                            onclick="spamModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->created_by }}')">Spam
                                                                            Lead</a>
                                                                    @endif
                                                                    @if (empty($category->productsData))
                                                                        {{-- When productsData is not set OR empty 
                                                                        @if ($category->outgoing_count > 0)
                                                                            @if (count($category->proposal_list) == 0)
                                                                                <a href="javascript:;"
                                                                                    class="dropdown-item"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_lead_potential"
                                                                                    onclick="PotentialModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">
                                                                                    Lead Basket
                                                                                </a>
                                                                            @endif
                                                                        @endif
                                                                    @endif --}}
                                                                @elseif($category->appointment_status != 4)
                                                                    <label
                                                                        class="text-danger fs-8 fw-bold dropdown-item">Pending
                                                                        Follow-up</label>
                                                                @elseif($category->lead_appointment_status == 1)
                                                                    <label class="dropdown-item"
                                                                        class="text-danger fs-8 fw-bold dropdown-item">Pending
                                                                        Appointment</label>
                                                                @endif
                                                            </div>
                                                        @elseif($category->status == 1)
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_lead_activate"onclick="activeModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Activate</a>
                                                            </div>
                                                        @elseif($category->status == 4)
                                                        @endif
                                                    </td>
                                                    <td>
                                                        @if ($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                            <span class="text-end">
                                                                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                    aria-haspopup="true" aria-expanded="false">
                                                                    <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    {{-- @if (auth()->user()->hasPermission($module_name, 'View', $menu_name)) --}}
                                                                    <a href="javascript:;" class="dropdown-item"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_view_lead"
                                                                        onclick="populateViewModal('{{ $category->sno }}')">
                                                                        <span><i
                                                                                class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                        <span>View</span>
                                                                    </a>
                                                                    {{-- @endif --}}
                                                                    <!--<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_to_intern" onclick="ConvertIntern('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')" style="background-color: #b6f1fb !important;">-->
                                                                    <!--    <span><i class="mdi mdi-account-arrow-right-outline fs-3 text-black me-1"></i>Intern</span>-->
                                                                    <!--</a>-->
                                                                    {{-- @if ($category->status !== 4 && $category->status !== 10)
                                                                        @if (auth()->user()->hasPermission($module_name, 'Add Requirement', $menu_name))
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_assign_requirements"
                                                                                onclick="openRequirement('{{ $category->sno }}')">
                                                                                <span><i
                                                                                        class="mdi mdi-file-document-plus-outline fs-3 text-black me-1"></i></span>
                                                                                <span>Requirments</span>
                                                                            </a>
                                                                        @endif
                                                                        @if (auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_edit_lead"
                                                                                onclick="populateEditModal('{{ $category->sno }}')">
                                                                                <span><i
                                                                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                                <span>Edit</span>
                                                                            </a>
                                                                        @endif
                                                                    @endif --}}
                                                                </div>
                                                                @if (auth()->user()->hasPermission($module_name, 'Call Summary', $menu_name))
                                                                    @if ($category->outgoing_count == $category->total_appointments && $category->status != 4)
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_succ_sum"
                                                                            onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','The number of outgoing calls matches the follow-ups', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-check-mark-on-green-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="236.5" cy="250"
                                                                                        r="200" fill="#39ba77"></circle>
                                                                                    <path fill="#39ba77"
                                                                                        d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                                                                            c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                                                                            c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                                                                            c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                                                                            c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                                                                            c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                                                                            c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @elseif(
                                                                        $category->outgoing_count == $category->total_appointments ||
                                                                            ($category->total_appointments >= 5 && $category->status != 4))
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_succ_sum"
                                                                            onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed!', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-check-mark-on-green-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="236.5" cy="250"
                                                                                        r="200" fill="#39ba77"></circle>
                                                                                    <path fill="#39ba77"
                                                                                        d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                                                                                c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                                                                                c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                                                                                c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                                                                                c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                                                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                                                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                        {{-- Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed! --}}
                                                                    @elseif($category->outgoing_count != $category->total_appointments && $category->status != 4)
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_fail_sum"
                                                                            onclick="failSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}', 'Outgoing calls and follow-ups are mismatched. Please review the call and follow-up details', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            {{-- data-bs-toggle="modal" data-bs-target="#kt_modal_lead_wallet" onclick="leadWallet('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')"> --}}
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-cross-mark-on-red-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="250" cy="250"
                                                                                        r="200" fill="#f32f45"></circle>
                                                                                    <path fill="#f32f45"
                                                                                        d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @endif
                                                                    @php
                                                                        $currentDate = \Carbon\Carbon::now();
                                                                        $registeredDate = \Carbon\Carbon::parse(
                                                                            $category->registered_date,
                                                                        );
                                                                        $diffInDays = $registeredDate->diffInDays(
                                                                            $currentDate,
                                                                        );

                                                                        $expectedOutgoingCount = 0;
                                                                        if ($diffInDays >= 15) {
                                                                            $expectedOutgoingCount = 5;
                                                                        } elseif ($diffInDays >= 7) {
                                                                            $expectedOutgoingCount = 4;
                                                                        } elseif ($diffInDays >= 3) {
                                                                            $expectedOutgoingCount = 3;
                                                                        } elseif ($diffInDays >= 2) {
                                                                            $expectedOutgoingCount = 2;
                                                                        } elseif ($diffInDays >= 1) {
                                                                            $expectedOutgoingCount = 1;
                                                                        }
                                                                    @endphp
                                                                    @if ($category->outgoing_count != $expectedOutgoingCount && $category->status != 4)
                                                                        <a href="javascript:;"
                                                                            class="btn btn-icon btn-sm animate__animated animate__pulse animate__infinite"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_danger_sum"
                                                                            onclick="dangerSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','{{ $diffInDays }}', '{{ $category->outgoing_count }}', '{{ $expectedOutgoingCount }}', '{{ $category->total_appointments }}')">
                                                                            {{-- Insert your SVG or button content here --}}
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 33.5 31.25"
                                                                                id="ExclamationSign"
                                                                                style="width:76%!important">
                                                                                <defs>
                                                                                    <linearGradient id="a"
                                                                                        x1="27.59" x2="8.53"
                                                                                        y1="6.27" y2="33.97"
                                                                                        gradientUnits="userSpaceOnUse">
                                                                                        <stop offset="0"
                                                                                            stop-color="#ff8383"></stop>
                                                                                        <stop offset="1"
                                                                                            stop-color="#fa1818"></stop>
                                                                                    </linearGradient>
                                                                                </defs>
                                                                                <g fill="#ef1818">
                                                                                    <path fill="url(#a)"
                                                                                        d="m16.75,31.25c-7.48,0-11.22,0-13.38-1.57C1.49,28.31.27,26.2.03,23.88c-.28-2.66,1.59-5.9,5.33-12.37C9.1,5.04,10.97,1.8,13.41.71c2.13-.95,4.56-.95,6.69,0,2.44,1.09,4.31,4.33,8.05,10.8,3.74,6.48,5.61,9.71,5.33,12.37-.25,2.32-1.46,4.42-3.35,5.79-2.16,1.57-5.9,1.57-13.38,1.57Z">
                                                                                    </path>
                                                                                    <line x1="16.75" x2="16.75"
                                                                                        y1="8.22" y2="18.09"
                                                                                        fill="none" stroke="#ffffff"
                                                                                        stroke-linecap="round"
                                                                                        stroke-width="3"></line>
                                                                                    <path fill="#ffffff"
                                                                                        d="m18.4,23.02c0,.91-.74,1.64-1.64,1.64s-1.64-.74-1.64-1.64.74-1.64,1.64-1.64,1.64.74,1.64,1.64Z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @endif
                                                                @endif
                                                            </span>
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <!--begin::Modal -  Call Log-->
    <div class="modal fade" id="kt_modal_call_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-5 px-5 px-xl-10">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center mb-4 text-black">
                            <span><span id="call_lead_name">Priya</span> [ </span>
                            <span class="text-info" id="call_lead_mobile">+91 9876543210</span>
                            <span>] Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="nav-align-top mb-2">
                                <ul class="nav nav-pills flex-nowrap call_navbar" role="tablist">

                                </ul>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane call_log fade show active" id="tab_incoming_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Incoming Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_outgoing_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Outgoing Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_missed_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Missed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_dailled_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Dialed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -  Call Log-->
    <!-- call history -->
    <script>
        function formatDateTransfer(dateString) {
            let date = new Date(dateString);
            let day = String(date.getDate()).padStart(2, '0');
            let monthIndex = date.getMonth();
            let year = date.getFullYear();

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex];

            return `${day}-${month}-${year}`;
        }

        function openCallHistoryModal(leadId, status, name = '', mobile = '', incomingCount, outgoingCount, missedCount,
            dialedCount) {
            $('#call_lead_name').text(name);
            $('#call_lead_mobile').text(mobile);

            let tabHtml = `
            <li class="nav-item me-2 mb-2">
                <a href="#tab_incoming_calls" class="nav-link call_log_link text-capitalize active" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Incoming', '#tab_incoming_calls')">
                    <img src="/assets/phdizone_images/calls/incoming_call.ico" class="w-20px h-25px fw-bold me-2"> Incoming Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${incomingCount >= 10 ? incomingCount : '0'+incomingCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_outgoing_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Outgoing', '#tab_outgoing_calls')">
                    <img src="/assets/phdizone_images/calls/outgoing_call.ico" class="w-20px h-25px fw-bold me-2"> Outgoing Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${outgoingCount >= 10 ? outgoingCount : '0'+outgoingCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_missed_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Missed & Rejected', '#tab_missed_calls')">
                    <img src="/assets/phdizone_images/calls/reject_call.ico" class="w-20px h-25px fw-bold me-2"> Missed & Rejected
                    <span class="badge bg-label-info fs-6 rounded ms-2">${missedCount >= 10 ? missedCount : '0'+missedCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_dailled_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Dialed', '#tab_dailled_calls')">
                    <img src="/assets/phdizone_images/calls/dialed_call.ico" class="w-20px h-25px fw-bold me-2"> Dialed Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${dialedCount >= 10 ? dialedCount : '0'+dialedCount }</span>
                </a>
            </li>
        `;

            $(".call_navbar").html(tabHtml);

            // Clear existing table content to avoid leftover data
            $('#tab_incoming_calls tbody').html('');
            $('#tab_outgoing_calls tbody').html('');
            $('#tab_missed_calls tbody').html('');
            $('#tab_dailled_calls tbody').html('');

            // Reset tab to default (Incoming)
            $('.call_log_link').removeClass('active');
            $('.call_log_link[href="#tab_incoming_calls"]').addClass('active');

            // Optionally hide all tabs and show only active
            $('.call_log').removeClass('active show');
            $('#tab_incoming_calls').addClass('active show');

            // Show modal and load default tab
            $('#kt_modal_call_log').modal('show');
            callHistoryTable(leadId, 'Incoming', '#tab_incoming_calls');
        }

        function callHistoryTable(leadId, status, tabSelector) {

            const $tbody = $(tabSelector).find("tbody");

            $.ajax({
                url: "{{ route('get_call_history_post_sale') }}",
                type: "GET",
                data: {
                    lead_id: leadId,
                    status: status
                },
                beforeSend: function() {
                    $tbody.html('<tr><td colspan="6" class="text-center">Loading...</td></tr>');
                },
                success: function(response) {
                    let rows = '';

                    if (response.calls.length > 0) {
                        response.calls.forEach(call => {
                            let img = "outgoing_call.ico";
                            let statusText = "Outgoing Call";
                            let bgColor = "";
                            let statusColor = "#7594E8";

                            switch (call.call_status) {
                                case 0:
                                    img = "outgoing_call.ico";
                                    statusText = "Outgoing Call";
                                    statusColor = "#7594E8";
                                    break;
                                case 1:
                                    img = "incoming_call.ico";
                                    statusText = "Incoming Call";
                                    statusColor = "#FFBF66";
                                    break;
                                case 2:
                                    img = "missed_call.ico";
                                    bgColor = "#ecc093";
                                    statusText = "Missed Call";
                                    statusColor = "#FFA500";
                                    break;
                                case 3:
                                    img = "reject_call.ico";
                                    bgColor = "#ff00004f";
                                    statusText = "Rejected Call";
                                    statusColor = "#FF7979";
                                    break;
                                default:
                                    img = "dialed_call.ico";
                                    statusText = "Dialed Call";
                                    statusColor = "#7594E8";
                                    break;
                            }

                            rows += `
                            <tr style="background: ${bgColor}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px border bg-primary rounded px-1 py-1 me-2">
                                            <img src="{{ asset('assets/phdizone_images/calls/') }}/${img}" class="w-20px h-20px" />
                                        </div>
                                        <div>
                                            <label class="fs-7 me-1">${call.staff_name}</label>
                                            <div class="text-primary fs-8">${call.staff_phone_no}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>${call.call_start_date ? formatDateTransfer(call.call_start_date) : '-'}</td>
                                <td><label class="text-info fs-7 fw-semibold">${call.call_start_time}</label></td>
                                <td><label class="text-danger fs-7 fw-semibold">${call.call_end_time || '-'}</label></td>
                                <td><label class="badge bg-warning text-black fs-7 fw-bold">${call.call_duration || '-'}</label></td>
                                <td><label class="badge rounded text-white fs-7 fw-semibold" style="background-color: ${statusColor}">${statusText}</label></td>
                            </tr>
                        `;
                        });
                    } else {
                        rows = '<tr><td colspan="6" class="text-center">No call history found</td></tr>';
                    }

                    $tbody.html(rows);
                }
            });
        }
    </script>

    <script>
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .source-label {
            position: relative;
            /* Ensure the label is positioned relative for absolute positioning of ::before */
            display: inline-block;
        }

        .source-label::before {
            /*content: '\1F31F'; */
            content: '\2728';
            /* ðŸŒŸ Sparkles */
            position: absolute;
            top: -12px;
            /* Move it further up */
            left: 90%;
            /* Center it horizontally */
            transform: translateX(-50%);
            /* Adjust horizontal alignment */
            font-size: 1rem;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }


        .jd-blue {
            color: #1976d2;
            /* Justdial Blue */
            font-weight: bold;
        }

        .jd-orange {
            color: #f16522;
            /* Justdial Orange */
            font-weight: bold;
        }

        .jd-blue,
        .jd-orange {
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }

        .cc-purple {
            color: #5c2d91;
            /* CloudCall Purple */
            font-weight: bold;
        }

        .cc-orange {
            color: #f58220;
            /* CloudCall Orange */
            font-weight: bold;
        }

        /* Cloud Icon Styling */
        .cc-icon {
            color: #5c2d91;
            /* Matching CloudCall Purple */
            margin-right: 5px;
        }


        .ct-black {
            color: #000000;
            /* Call in Black */
            font-weight: bold;
        }

        .ct-orange {
            background-color: #f16522;
            /* Justdial Orange */
            color: #ffffff;
            /* White text inside */
            /*font-weight: bold;*/
            padding: 2px 6px;
            border-radius: 4px;
        }

        /* Call Icon Styling */
        .ct-icon {
            color: #000000;
            /* Black Call Icon */
            font-size: 14px;
            margin-left: 3px;
        }


        /* Loading Dots */
        .loading-dots {
            display: flex;
            gap: 8px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Individual Balls */
        .loading-dots span {
            width: 15px;
            height: 15px;
            background-color: rgb(32, 32, 34);
            border-radius: 50%;
            opacity: 0;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }

        /* Add More Balls with Delay */
        .loading-dots span:nth-child(1) {
            animation-delay: 0s;
        }

        .loading-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }

        .loading-dots span:nth-child(4) {
            animation-delay: 0.6s;
        }

        .loading-dots span:nth-child(5) {
            animation-delay: 0.8s;
        }

        .loading-dots span:nth-child(6) {
            animation-delay: 1s;
        }

        /* Animation */
        @keyframes fadeInOut {

            0%,
            100% {
                opacity: 0;
                transform: scale(0.8);
            }

            50% {
                opacity: 1;
                transform: scale(1);
            }
        }


        /* Stylish Fade Effect Box */
        .fade-effect {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #dbdd47, #ccce43);
            color: rgb(255, 255, 255);
            font-weight: bold;
            font-size: 18px;
            text-align: center;
            line-height: 60px;
            border-radius: 10px;
            text-shadow: 0 0 5px rgba(137, 92, 219, 0.5),
                0 0 10px rgba(137, 92, 219, 0.5),
                0 0 20px rgba(137, 92, 219, 0.5);
            /* Intense Neon Glow */
            box-shadow: 0 0 15px rgba(137, 92, 219, 0.5),
                0 0 25px rgba(16, 168, 185, 0.8),
                0 0 35px rgba(137, 92, 219, 0.5);
            /* Red & Black Glow */
            letter-spacing: 2px;
            opacity: 0;
            /* Initially hidden */
            transition: all 0.5s ease-in-out;
            animation: shimmer 3s infinite alternate, runText 12s linear infinite, fadeEffect 3s infinite alternate;
        }

        /* Hover Glow Effect */
        .fade-effect:hover {
            box-shadow: 0 0 15px rgba(135, 0, 0, 0.7),
                0 0 25px rgba(25, 10, 5, 0.8),
                0 0 35px rgba(135, 0, 0, 0.6);
            /* Red & Black Glow */
            transform: scale(1.05);
            /* Slight Zoom */
        }

        /* Running Text Animation */
        @keyframes runText {
            from {
                left: 100%;
            }

            to {
                left: -100%;
            }
        }

        /* Fade Effect Animation */
        @keyframes fadeEffect {
            0% {
                opacity: 0.3;
            }

            100% {
                opacity: 1;
            }
        }

        @keyframes shimmer {
            0% {
                background-position: -200%;
            }

            100% {
                background-position: 200%;
            }
        }

        /* Blinking text animation */
        .blink {
            /*animation: blinker 1.5s linear infinite;*/
            /* font-weight: bold; */
            color: white;
            /* White text for better contrast */
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9;
            /* Soft pink color */
            padding: 0px 8px;
            border-radius: 12px;
            /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            /* Soft shadow for depth */
            font-size: 0.3rem;
            /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }

        /* Adding a cute icon or star effect */
        .new-label::before {
            content: 'ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨';
            /* You can replace this with any icon or emoji */
            position: absolute;
            top: -8px;
            right: -10px;
            /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }


        /* Bounce animation for cute effect */
        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-8px);
            }

            60% {
                transform: translateY(-4px);
            }
        }
    </style>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .tags-inline.tagify__dropdown {
            z-index: 9999 !important;
            /* Ensure it is higher than the modal's z-index */
        }
    </style>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#filter_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#filter_form').submit();
            }
        }
    </script>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <!--begin::Modal - View Lead-->
    <div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">
                            <label>View Lead</label>
                            <label class="ms-1 me-1">-</label>
                            <label class="badge bg-info rounded fw-semibold fs-4">Active</label>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 text-black fs-5 fw-bold">Basic Information</div>
                        <div class="col-lg-6 text-end">
                            <div class="badge bg-secondary text-end fs-6 text-white fw-semibold rounded"
                                id="view_lead_auto_id">LD-0003/24</div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_created" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_name_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_gender_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_dob_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="lead_email_view"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="priya@gmail.com">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_address" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_mobile_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_alternate_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_marital_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="text-black fs-5 fw-bold">Product Information</label>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_category" class="col-7 text-black fs-6 fw-bold">Development
                                    Services</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Product</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_service" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold">Lead Information</div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"><span id="view_leadtype"></span></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Potential Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7 text-black fs-6 fw-bold">
                                    <div class="d-flex align-items-center">
                                        <div class="me-1">
                                            <img id="potential_image_view" src="" alt="Premium Potential Icon"
                                                class="w-25px h-25px text-black fw-bold">
                                        </div>
                                        <label id="view_potentialtype" class="text-black fs-6 fw-bold"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_leadsource" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">University</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_university" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="text-dark fs-6 fw-semibold mb-2">Comments</label>
                            <div class="d-block">
                                <label id="view_comments" class="text-black fs-7 fw-bold">&emsp;&emsp;</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Lead-->
    <script>
        function populateViewModal(categoryId) {
            fetch(`/post_sale_lead_view/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data;
                        // console.log(lead);

                        // Function to format date to '10-Jun-2024'
                        function formatDate(dateString) {
                            if (!dateString) return '-'; // Handle null or undefined dates
                            const date = new Date(dateString);
                            const day = date.getDate().toString().padStart(2, '0');
                            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
                                "Nov", "Dec"
                            ];
                            const month = monthNames[date.getMonth()];
                            const year = date.getFullYear();
                            return `${day}-${month}-${year}`;
                        }


                        $('#lead_id_view').html(lead.lead_id || '-');
                        $('#lead_created').html(formatDate(lead.created_at));
                        $('#lead_name_view').html(lead.lead_name || '-');
                        $('#lead_mobile_view').html(lead.lead_mobile || '-');
                        $('#lead_alternate_view').html(lead.lead_alternate_mobile || '-');
                        $('#lead_email_view').html(lead.lead_email_id || '-');

                        const gender = lead.lead_gender === 1 ? 'Male' : (lead.lead_gender === 2 ? 'Female' : 'Other');
                        $('#lead_gender_view').html(gender);

                        $('#lead_dob_view').html(formatDate(lead.lead_dob));

                        const maritalStatus = lead.lead_marital_status === 1 ? 'Married' : (lead.lead_marital_status ===
                            2 ? 'Unmarried' : '-');
                        $('#lead_marital_view').html(maritalStatus);


                        let imageUrl = lead.potential_type_image ?
                            `{{ asset('potential_image/') }}/${lead.potential_type_image}` : '';

                        document.getElementById('potential_image_view').src = imageUrl;

                        $('#view_lead_auto_id').html(lead.lead_id || '-');
                        $('#lead_type_view').html(lead.lead_type_name || '-');
                        $('#lead_source_view_h').html(lead.lead_source_name || '-');
                        $('#view_leadsource').html(lead.leadsourcename || '-');
                        $('#view_university').html(lead.universityname || '-');
                        $('#lead_potential_view').html(lead.potential_type_name || '-');
                        // $('#view_edit_id').val(lead.sno || '');
                        $('#view_address').html((lead.address || '') + ' ' + lead.citiesname + ' ' + lead.statename +
                            ' ' + lead.name);
                        $('#view_leadtype').html(lead.leadtypename || '-');
                        $('#view_potentialtype').html(lead.potential_type_name || '-');
                        $('#view_comments').html(lead.lead_comments || '-');
                        $('#view_category').html(lead.product_category_name || '-');
                        $('#view_service').html(lead.product_name || '-');

                        // if(lead.status == 4) {
                        //     $('#edit_icon').hide();
                        // } else {
                        //     $('#edit_icon').show();
                        // }

                        // Assuming lead.lead_knowledge_tags is your JSON array or string
                        let tagsString = '-';
                        if (lead.lead_knowledge_tags) {
                            const tagsArray = Array.isArray(lead.lead_knowledge_tags) ? lead.lead_knowledge_tags : JSON
                                .parse(lead.lead_knowledge_tags);
                            tagsString = tagsArray.map(tag => tag.value).join(', ');
                        }
                        $('#lead_tag_view').html(tagsString);

                    } else {
                        console.error('Error fetching category:', data.message);
                        // Optionally, show an alert or update the UI to reflect the error.
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                    // Optionally, show an alert or update the UI to reflect the error.
                });
        }
    </script>
    <!--begin::Modal - Customer HotLead-->
    <div class="modal fade" id="kt_modal_hot_lead" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Hot Lead?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/manage_post_sale_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer HotLead-->
    <script>
        //hot lead modal
        function hotLeadModal(id, leadName) {
            $('#kt_modal_hot_lead').modal('show');
            $('#kt_modal_hot_lead .lead-name').text(leadName);
            $('#kt_modal_hot_lead .btn-primary').off('click').on('click', function() {
                leadstatusupdate(id, 3); // Assuming status 1 is Inactive
                $('#kt_modal_hot_lead').modal('hide');
            });
        }

        function leadstatusupdate(statusId, status) {

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/hot_post_sale_lead_status_update/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status

                    }),
                })
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }


        function updatestatus(statusId, status) {
            // const statusId = status_id;
            // const status = document.getElementById('status_id').value;


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/status_update/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        // alert(data.status);
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        // toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }
    </script>
    <!--begin::Modal - Generate Quotation-->
    <div class="modal fade" id="kt_modal_lead_quotation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Want
                    To Generate Proposal?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label id="proposal_lead_name">Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label id="proposal_lead_genrate_id">LD-0006/24</label>
                        <input type="hidden" name="proposal_lead_id" id="proposal_lead_id">
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" onclick="createProposal()" class="btn btn-primary me-3">
                        Yes
                    </button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Generate Quotation-->
    <!--begin::Modal - Proposal Details-->
    <div class="modal fade" id="kt_modal_view_quotation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row" id="proposal_list">

                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Proposal Details-->

    <!--begin::Modal - View Only Proposal Details-->
    <div class="modal fade" id="kt_modal_view_only_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="bg-label-success rounded-circle fw-semibold"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Proposal Accepted"><i
                                                class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">02</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003670/04/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">02-Apr-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">07-Apr-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,21,068</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                                                                            <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                                                                        </a> -->
                                                <a href="{{ url('/manage_proposal/proposal_print') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">01</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003669/03/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">27-Mar-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">31-Mar-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,36,998</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                                                                            <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                                                                        </a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Only Proposal Details-->


    <!-- proposal -->

    <script>
        function create_proposal_func(id, name, leadId) {
            $('#proposal_lead_name').text(name)
            $('#proposal_lead_genrate_id').text(leadId)
            $('#proposal_lead_id').val(id)
        }

        function createProposal() {

            var lead_id = $('#proposal_lead_id').val();

            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            if (lead_id) {
                $.ajax({
                    url: '/create_post_sale_lead_proposal', // Your encryption route
                    type: 'POST',
                    data: {
                        lead_id: lead_id,
                        _token: csrfToken // Include CSRF token here
                    },
                    success: function(encrypted_lead_id) {
                        // Redirect to the desired route with the encrypted ID
                        window.location.href = '/manage_proposal/proposal_post_sale_add/' + encrypted_lead_id;
                    },
                    error: function(xhr) {
                        toastr.error('Please Try Again Later');
                    }
                })
            } else {
                toastr.error('Lead Id is Missing');
            }

            ;
        }

        function revised_proposal_func(id, name, leadId, proposal) {
            $('#proposal_lead_name').text(name)
            $('#proposal_lead_genrate_id').text(leadId)
            $('#proposal_lead_id').val(id)
            $('#proposal_list').html('')

            var html = ""
            if (proposal.length > 0) {
                proposal.forEach(function(data, index) {
                    var printurl = 'manage_proposal/print_proposal/' + data.encrypt_id;
                    var viewurl = 'manage_proposal/proposal_view/' + data.encrypt_id;


                    html = `
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count"> ${(proposal.length - index) > 10 ? (proposal.length - index) : ('0' + (proposal.length - index))}</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">${data.proposal_id}</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.estimate_date)}</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.due_date)}</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; ${formatCurrency(data.grant_total_amount)}</label>
                                            </div>
                                            <div class="d-block text-end">
                                            
                                                 <a href="{{ url('${viewurl}') }}" target="_blank" class="btn btn-icon btn-sm me-2" title="View Proposal" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                               
                                               
                                                
                                                <a href="{{ url('${printurl}') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                `;
                    $('#proposal_list').append(html)
                })
            }

        }

        function formatCurrency(amt) {
            var roundedAmt = parseFloat(amt);
            var isWhole = Number.isInteger(roundedAmt);

            return roundedAmt.toLocaleString('en-IN', {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2
            });
        }

        function reviseProposal(id) {

            var proposal_id = id;

            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            if (proposal_id) {
                $.ajax({
                    url: '/revise_lead_proposal', // Your encryption route
                    type: 'POST',
                    data: {
                        proposal_id: proposal_id,
                        _token: csrfToken // Include CSRF token here
                    },
                    success: function(encrypted_lead_id) {
                        // Redirect to the desired route with the encrypted ID
                        window.location.href = '/manage_proposal/proposal_revise/' + encrypted_lead_id;
                    },
                    error: function(xhr) {
                        toastr.error('Please Try Again Later');
                    }
                })
            } else {
                toastr.error('Lead Id is Missing');
            }

            ;
        }
    </script>
    <!--begin::Modal - Import Lead-->
    <div class="modal fade" id="kt_modal_lead_import" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Import Old Post Sale Lead</h3>
                    </div>
                    <div class="text-end">
                        <span>
                            <label>Sample Download For Lead Import</label>
                            <a href="javascript:;" download="Lead Data" class="hover-warning cursor-pointer"
                                title="Click To Download" id="sample_excel">
                                <i class="mb-1 mdi mdi-download-circle fs-3 text-danger"
                                    title="Click Here to Download"></i>
                            </a>
                        </span>
                    </div>
                    <form id="leadImportForm" method="POST" enctype="multipart/form-data" autocomplete="off">
                        @csrf <!-- Include CSRF token for security -->
                        <div class="row">
                            <!--<div class="col-lg-6 mb-1">-->
                            <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type<span class="text-danger">*</span></label>-->
                            <!--    <select id="lead_type_import" name="lead_type_id"  class="select3 form-select" data-placeholder="Select Lead Type">-->
                            <!--        <option value="">Select Lead Type</option>-->
                            <!--    </select>-->
                            <!--</div>-->
                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Group<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_group" name="lead_group"
                                    placeholder="Enter Lead Group"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                    required />
                            </div>

                            <div class="col-lg-6 mb-1">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span
                                        class="text-danger">*</span></label>
                                <select id="lead_source_import" name="lead_source_id" class="select3 form-select"
                                    required>
                                    <option value="">Select Lead Source</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div id="dropArea" class="border border-4 border-dashed p-5 text-center rounded">
                                <p class="mb-2">Drag & Drop your (.xls) files here or click to select</p>
                                <input type="file" id="fileInput" name="file_import" class="d-none"
                                    accept=".xls,.xlsx,.xlsm,.csv" required />
                                <button type="button" class="btn btn-outline-primary"
                                    onclick="document.getElementById('fileInput').click()">
                                    Browse (.xls) Files
                                </button>
                            </div>
                            <div id="fileList" class="text-muted"></div>
                            <div class="text-danger" id="err_mssg"></div>
                        </div>
                        <div class="row">
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Import</button>
                            </div>
                        </div>

                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Lead-->

    <!-- start Bootstrap Modal for showing messages -->
    <div class="modal fade" id="messageModal" tabindex="-1" aria-labelledby="messageModalLabel"
        aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="messageModalLabel">Import Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modalMessageContent" class="alert" role="alert">
                        <!-- Dynamic content will be injected here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="closeModalButton"
                        data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- end Bootstrap Modal for showing messages -->
    <style>
        #modalMessageContent {
            font-size: 1.2rem;
            /* Make font larger */
            padding: 10px;
            /* Add padding */
            border-radius: 5px;
            /* Rounded corners */
        }

        /* Example styles for success, warning, and error */
        .text-successs {
            background-color: #d4edda;
            color: #155724;
        }

        .text-dangers {
            background-color: #f8d7da;
            color: #721c24;
        }

        .text-warnings {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>

    <style>
        #dropArea {
            cursor: pointer;
        }

        #dropArea.bg-light {
            background-color: #f8f9fa;
        }

        #fileList p {
            margin: 0;
            font-size: 0.8rem;
        }
    </style>
    <script>
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const fileList = document.getElementById("fileList");

        // Highlight drop area when dragging files
        dropArea.addEventListener("dragover", (e) => {
            e.preventDefault();
            dropArea.classList.add("bg-light");
        });

        dropArea.addEventListener("dragleave", () => {
            dropArea.classList.remove("bg-light");
        });

        // Handle file drop
        dropArea.addEventListener("drop", (e) => {
            e.preventDefault();
            dropArea.classList.remove("bg-light");

            if (e.dataTransfer.files.length > 0) {
                fileInput.files = e.dataTransfer.files;
                displayFileNames(Array.from(e.dataTransfer.files));
            }
        });

        // Display selected file names
        fileInput.addEventListener("change", (e) => {
            if (e.target.files.length > 0) {
                displayFileNames(Array.from(e.target.files));
            }
        });

        function displayFileNames(files) {
            fileList.innerHTML = files
                .map((file, index) => `<span>${index + 1}. ${file.name} </span>`)
                .join("");
        }
    </script>
    <script>
        document.getElementById('leadImportForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            const form = event.target;
            const formData = new FormData(form);
            fetch('{{ route('lead_import') }}', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: formData
                })
                .then(response => response.json()) // assuming the backend returns a JSON response
                .then(data => {
                    // Handle success or error response
                    let modalMessage = '';
                    if (data.status === 'success') {
                        modalMessage = `<span class="text-success">${data.message}</span>`;
                    } else if (data.status === 'partial_success') { // Handle partial success
                        modalMessage =
                            `<span class="text-warnings">${data.message}<br>${data.error_msg.join(', ')}</span>`; // Join error messages
                    } else if (data.status === 'error') { // Make sure to define error handling on the backend
                        modalMessage = `<span class="text-dangers">${data.error_msg}</span>`;
                    }

                    // Set the modal message content
                    document.getElementById('modalMessageContent').innerHTML = modalMessage;

                    // Close the import modal in case of error as well
                    var importModal = bootstrap.Modal.getInstance(document.getElementById(
                        'kt_modal_lead_import'));
                    if (importModal) {
                        importModal.hide();
                    }
                    // Show the message modal
                    var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
                    messageModal.show();

                    // Reload the page after a short delay
                    // setTimeout(() => {
                    //     location.reload();
                    // }, 8000); // 2-second delay to allow the user to read the message
                })
                .catch(error => {
                    // Handle any errors
                    console.error('Error:', error);
                    document.getElementById('modalMessageContent').innerHTML =
                        '<span class="text-danger">An error occurred while importing leads.</span>';

                    // Close the import modal in case of error as well
                    var importModal = bootstrap.Modal.getInstance(document.getElementById(
                        'kt_modal_lead_import'));
                    if (importModal) {
                        importModal.hide();
                    }

                    // Show the error message in the message modal
                    var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
                    messageModal.show();

                    // Reload the page after a short delay
                    // setTimeout(() => {
                    //     location.reload();
                    // }, 8000); // 2-second delay to allow the user to read the error message
                });
        });
        // Reload the page when the close button is clicked
        document.getElementById('closeModalButton').addEventListener('click', function() {
            location.reload(); // Reload the page when the close button is clicked
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector("form#leadDropzone").addEventListener("submit", function(e) {
                e.preventDefault();
                e.stopPropagation();

                let formData = new FormData(this);
                formData.append("_token", document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content'));

                fetch("{{ route('lead_import') }}", {
                        method: "POST",
                        body: formData,
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            toastr.success(data.message); // Display success message
                            // setTimeout(() => {
                            //     window.location.reload(); // Refresh page to show success message
                            // }, 1500);
                        } else {
                            // Handle error response
                            if (data.status === 401 || data.status === 400) {
                                if (data.error_msg) {
                                    toastr.error(data.error_msg.join(
                                        "<br>")); // Join and display validation errors
                                } else {
                                    toastr.error(data.message); // General error message
                                }
                            } else {
                                toastr.error("An unexpected error occurred.");
                            }
                        }
                    })
                    .catch(error => {
                        toastr.error("An error occurred while processing the request: " + error
                            .message);
                    });
            });
        });
    </script>
    <script>
        // Function to export table data to Excel
        function exportToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/lead/export-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
        }

        // Event listener for Excel export button
        $('#export_excel').on('click', function(e) {
            e.preventDefault();
            exportToExcel();
        });

        function sampleToExcel() {
            // Replace with your server endpoint for exporting to Excel
            let url = '/lead/sample-excel';

            // Example AJAX call to trigger export
            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    // Handle success, such as downloading the file
                    window.location.href = url; // Redirect to download link

                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error('Error exporting to Excel:', error);
                }
            });
            //  location.reload();
        }

        // Event listener for Excel export button
        $('#sample_excel').on('click', function(e) {
            // e.preventDefault();
            // alert('dgsdgsdgsd')
            sampleToExcel();
            setTimeout(function() {
                console.log('This message will appear after 2 seconds');
                location.reload();
            }, 1000); // 2000 milliseconds = 2 seconds           
        });
    </script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: "{{ route('lead_source') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('select[name="lead_source_id"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Lead source</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.lead_source_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
        });
    </script>
    <script>
        document.getElementById('leadImportForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            const form = event.target;
            const formData = new FormData(form);
            fetch('{{ route('post_sale_lead_import') }}', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: formData
                })
                .then(response => response.json()) // assuming the backend returns a JSON response
                .then(data => {
                    // Handle success or error response
                    let modalMessage = '';
                    if (data.status === 'success') {
                        modalMessage = `<span class="text-success">${data.message}</span>`;
                    } else if (data.status === 'partial_success') { // Handle partial success
                        modalMessage =
                            `<span class="text-warnings">${data.message}<br>${data.error_msg.join(', ')}</span>`; // Join error messages
                    } else if (data.status === 'error') { // Make sure to define error handling on the backend
                        modalMessage = `<span class="text-dangers">${data.error_msg}</span>`;
                    }

                    // Set the modal message content
                    document.getElementById('modalMessageContent').innerHTML = modalMessage;

                    // Close the import modal in case of error as well
                    var importModal = bootstrap.Modal.getInstance(document.getElementById(
                        'kt_modal_lead_import'));
                    if (importModal) {
                        importModal.hide();
                    }
                    // Show the message modal
                    var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
                    messageModal.show();

                    // Reload the page after a short delay
                    // setTimeout(() => {
                    //     location.reload();
                    // }, 8000); // 2-second delay to allow the user to read the message
                })
                .catch(error => {
                    // Handle any errors
                    console.error('Error:', error);
                    document.getElementById('modalMessageContent').innerHTML =
                        '<span class="text-danger">An error occurred while importing leads.</span>';

                    // Close the import modal in case of error as well
                    var importModal = bootstrap.Modal.getInstance(document.getElementById(
                        'kt_modal_lead_import'));
                    if (importModal) {
                        importModal.hide();
                    }

                    // Show the error message in the message modal
                    var messageModal = new bootstrap.Modal(document.getElementById('messageModal'));
                    messageModal.show();

                    // Reload the page after a short delay
                    // setTimeout(() => {
                    //     location.reload();
                    // }, 8000); // 2-second delay to allow the user to read the error message
                });
        });
        // Reload the page when the close button is clicked
        document.getElementById('closeModalButton').addEventListener('click', function() {
            location.reload(); // Reload the page when the close button is clicked
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector("form#leadDropzone").addEventListener("submit", function(e) {
                e.preventDefault();
                e.stopPropagation();

                let formData = new FormData(this);
                formData.append("_token", document.querySelector('meta[name="csrf-token"]').getAttribute(
                    'content'));

                fetch("{{ route('lead_import') }}", {
                        method: "POST",
                        body: formData,
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            toastr.success(data.message); // Display success message
                            // setTimeout(() => {
                            //     window.location.reload(); // Refresh page to show success message
                            // }, 1500);
                        } else {
                            // Handle error response
                            if (data.status === 401 || data.status === 400) {
                                if (data.error_msg) {
                                    toastr.error(data.error_msg.join(
                                        "<br>")); // Join and display validation errors
                                } else {
                                    toastr.error(data.message); // General error message
                                }
                            } else {
                                toastr.error("An unexpected error occurred.");
                            }
                        }
                    })
                    .catch(error => {
                        toastr.error("An error occurred while processing the request: " + error
                            .message);
                    });
            });
        });
    </script>
    <!--begin::Modal - Add Lead-->
    <div class="modal fade" id="kt_modal_add_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Post Sale Lead</h3>
                    </div>
                    <form id="leadAddForm" action="{{ route('add_post_sale_lead') }}" method="POST" novalidate
                        autocomplete="off">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Lead Name"
                                    id="lead_name_create" name="lead_name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                    maxlength="70" />
                                <div class="text-danger" id="lead_name_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"
                                        id="inlineRadio1" value="1" checked />
                                    <label class="form-check-label" for="inlineRadio1">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"
                                        id="inlineRadio2" value="2" />
                                    <label class="form-check-label" for="inlineRadio2">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"
                                        id="inlineRadio3" value="3" />
                                    <label class="form-check-label" for="inlineRadio3">Others</label>
                                </div>
                                <div class="text-danger" id="lead_gender_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="cllt_cl_dt" name="lead_dob" placeholder="Select Date"
                                        class="form-control common_date_class">
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="mb-1">
                                    <input class="form-check-input" type="checkbox" checked id="mobile_no_chk"
                                        value="1" name="mobile_check" onclick="mobile_no_func();" />
                                    <label class="text-black fs-6 fw-semibold">Mobile Number<span class="text-danger"
                                            style="display: none ;" id="mob_req">*</span></label>
                                </div>
                                <div id="mob_no" style="display: none ;">
                                    <div class="input-group">
                                        <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i"
                                            type="button" data-bs-toggle="dropdown" aria-expanded="false"
                                            id="countryDropdownButton" name="countryDropdownButton">Phn Code</button>
                                        <ul class="dropdown-menu" id="countryDropdownMenu" name="countryDropdownMenu"
                                            style="max-height: 250px; overflow-y: auto;">
                                            <li>
                                                <input type="text" id="countrySearch" name="countrySearch"
                                                    class="form-control border-1" placeholder="Search Country/Code"
                                                    style="width: 100%; border: none; padding: 5px;">
                                            </li>
                                        </ul>
                                        <input type="text" class="form-control" id="lead_mobile_create"
                                            name="lead_mobile_create" maxlength="10" onkeyup="mobile_chk(this.value)"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                            placeholder="Enter Mobile Number">
                                        <input type="hidden" id="country_code_name" name="country_code_name"
                                            value="" />
                                    </div>
                                </div>

                                <div class="text-danger" id="lead_mobile_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="mb-1">
                                    <input class="form-check-input" type="checkbox" id="email_chk" value="1"
                                        name="email_check" onclick="email_func();" />
                                    <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger"
                                            style="display: none ;" id="email_req">*</span></label>
                                </div>
                                <div id="email_tbox" style="display: none ;">
                                    <input type="text" class="form-control me-2" placeholder="Enter Email ID"
                                        id="lead_email_create" name="lead_email_id" onkeyup="email_chk_validate(this.value)"
                                        oninput=" this.value = this.value.toLowerCase();" />
                                </div>
                                <div class="text-danger" id="lead_email_create_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                                <input type="text" class="form-control me-2" maxlength="10"
                                    placeholder="Enter Alternate Mobile Number"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="lead_alternate_create" name="lead_alternate_mobile" />
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                                <select class="select3 form-select" id="countryId" name="country">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="text-danger" id="lead_country_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                                <select class="select3 form-select" id="stateId" name="state">
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="lead_state_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                                <select class="select3 form-select" id="cityId" name="city">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="lead_city_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                                <input type="text" class="form-control me-2" id="lead_door_no" name="door_no"
                                    placeholder="Enter Door No / Flat No">
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                                <input type="text" class="form-control me-2" id="address" name="address"
                                    placeholder="Enter Area / Street" />
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                                <input type="text" class="form-control me-2" id="lead_pincode" name="pincode"
                                    placeholder="Enter Pincode">
                            </div>
                            <!--<div class="col-lg-4 mb-3">-->
                            <!--    <label class="text-black mb-1 fs-6 fw-semibold">Product Category<span-->
                            <!--            class="text-danger">*</span></label>-->
                            <!--    <select class="select3 form-select" id="service_category_id" name="service_category_id">-->
                            <!--        <option value="">Select Product Category</option>-->
                            <!--    </select>-->
                            <!--    <div class="text-danger" id="service_category_id_err"></div>-->
                            <!--</div>-->
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Product<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="service_id" multiple name="service_id[]">
                                    <option value="">Select Product</option>
                                </select>
                                <div class="text-danger" id="service_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">University</label>
                                <select class="select3 form-select" id="university_id" name="university_id">
                                    <option value="">Select University</option>
                                </select>
                                <div class="text-danger" id="university_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Potential Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="potential_type_id" name="potential_type_id">
                                    <option value="">Select Potential Type</option>

                                </select>
                                <div class="text-danger" id="potential_type_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="lead_type_id" name="lead_type_id">
                                    <option value="">Select Lead Type</option>
                                </select>
                                <div class="text-danger" id="lead_type_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="lead_source_id" name="lead_source_id">
                                    <option value="">Select Lead Source</option>
                                </select>
                                <div class="text-danger" id="lead_source_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Comments</label>
                                <textarea class="form-control" rows="1" name="lead_comments" placeholder="Enter Comments"
                                    oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_lead_add"
                                onclick="AddvalidateForm()">Create Lead</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Lead-->
    <!-- Lead Add  -->
    <script>
        function AddvalidateForm() {
            var err = 0;

            // Validate knowledge Name
            var lead_name_create = document.getElementById("lead_name_create").value.trim();
            if (lead_name_create === "") {
                document.getElementById('lead_name_create_err').innerHTML = 'Lead Name is required...!';
                err++;
            } else {
                document.getElementById('lead_name_create_err').innerHTML = '';
            }

            var mobile_no_chk = document.getElementById("mobile_no_chk");
            var email_chk = document.getElementById("email_chk");
            var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();

            if (mobile_no_chk.checked || email_chk.checked) {
                document.getElementById('lead_mobile_create_err').innerHTML = '';
            } else {
                document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile Number or Email Id is Required !';
                err++;
            }


            if (mobile_no_chk.checked) {

                var countryDropdownMenu_valid = $('#country_code_name');

                if (countryDropdownMenu_valid == 'IN - +91') {

                    var mobilePattern = /^\d{10}$/;

                    if (lead_mobile_create === "") {
                        document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                        err++;
                    } else if (!mobilePattern.test(lead_mobile_create)) {
                        document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number must be 10 digits...!';
                        err++;
                    } else {
                        document.getElementById('lead_mobile_create_err').innerHTML = '';
                    }
                } else {
                    if (lead_mobile_create === "") {
                        document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                        err++;
                    } else {
                        document.getElementById('lead_mobile_create_err').innerHTML = '';
                    }
                }

                var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();

                if (lead_mobile_create === "") {
                    document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                    err++;
                } else {
                    document.getElementById('lead_mobile_create_err').innerHTML = '';
                }


            }

            if (email_chk.checked) {
                var lead_email_create = document.getElementById("lead_email_create").value.trim();
                if (lead_email_create === "") {
                    document.getElementById('lead_email_create_err').innerHTML = 'Email is required...!';
                    err++;
                } else {
                    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
                    if (filter.test(lead_email_create)) {
                        document.getElementById('lead_email_create_err').innerHTML = '';
                    } else {
                        document.getElementById('lead_email_create_err').innerHTML =
                            'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
                        err++;

                    }
                }

            }else{
                document.getElementById('lead_email_create_err').innerHTML = '';
            }
            var service_id = document.getElementById("service_id").value.trim();
            if (service_id === "") {
                document.getElementById('service_id_err').innerHTML = 'Product is required...!';

                err++;
            } else {

                document.getElementById('service_id_err').innerHTML = '';
            }
            var potential_type_id = document.getElementById("potential_type_id").value.trim();
            if (potential_type_id === "") {
                document.getElementById('potential_type_id_err').innerHTML = 'Potential Type is required...!';

                err++;
            } else {

                document.getElementById('potential_type_id_err').innerHTML = '';
            }

            var lead_type_id = document.getElementById("lead_type_id").value.trim();
            if (lead_type_id === "") {
                document.getElementById('lead_type_id_err').innerHTML = 'Lead Type is required...!';

                err++;
            } else {

                document.getElementById('lead_type_id_err').innerHTML = '';
            }

            // Validate 
            var lead_source_id = document.getElementById("lead_source_id").value.trim();
            if (lead_source_id === "") {
                document.getElementById('lead_source_id_err').innerHTML = 'Lead Source is required...!';

                err++;
            } else {

                document.getElementById('lead_source_id_err').innerHTML = '';
            }

            if (err === 0) {
                $('#leadAddForm').submit();
                $('#submit_lead_add').prop('disabled', true);
            } else {
                $('#submit_lead_add').prop('disabled', false);
            }
        }
    </script>
    <script>
        mobile_no_func()

        function mobile_no_func() {
            var mobile_no_chk = document.getElementById("mobile_no_chk");
            var mob_no = document.getElementById("mob_no");
            var mob_req = document.getElementById("mob_req");
            if (mobile_no_chk.checked) {
                mob_no.style.display = "block";
                mob_req.style.display = "inline";
            } else {
                mob_no.style.display = "none";
                mob_req.style.display = "none";
            }
        }
        email_func()

        function email_func() {
            var email_chk = document.getElementById("email_chk");
            var email_tbox = document.getElementById("email_tbox");
            var email_req = document.getElementById("email_req");
            if (email_chk.checked) {
                email_tbox.style.display = "block";
                email_req.style.display = "inline";
            } else {
                email_tbox.style.display = "none";
                email_req.style.display = "none";
            }
        }
    </script>
    <!-- setting dropdown -->
    <script>
        $(document).ready(function() {

            $.ajax({
                url: "{{ route('lead_source') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#lead_source_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Lead source</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.lead_source_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
        });

        $(document).ready(function() {
            $.ajax({
                url: "{{ route('lead_type') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#lead_type_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Lead Type</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.lead_type_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
            $.ajax({
                url: "{{ route('university_list') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#university_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select University</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.university_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });
            $.ajax({
                url: "{{ route('potential_type_list') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#potential_type_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select  Potential Type</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.potential_type_name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching course categories:', error);
                }
            });



        });
    </script>

    <!-- country and code  -->
    <script>
        $(document).ready(function() {
            $(".common_time_class_new").flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                defaultHour: new Date().getHours(),
                defaultMinute: new Date().getMinutes()
            });

            $('#country_id_edit').on('change', function() {
                const selectedCountryId = $(this).val();
                if (selectedCountryId) {
                    $.ajax({
                        url: "{{ route('country') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var countryDropdownMenu = $('#countryDropdownMenu_edit');
                                countryDropdownMenu.empty();
                                // console.log(response.data);

                                // Add the search input to the dropdown menu
                                countryDropdownMenu.append(
                                    '<li><input type="text" id="countrySearch_edit" name="countrySearch_edit" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>'
                                );

                                // Loop through the countries and add them to the dropdown
                                response.data.forEach(function(country) {
                                    countryDropdownMenu.append(
                                        $('<li></li>').append(
                                            $('<a></a>')
                                            .addClass('dropdown-item waves-effect')
                                            .attr('href', 'javascript:void(0);')
                                            .data('id', country.id)
                                            .data('phonecode', country.phonecode)
                                            .text(country.sortname + ' - ' + '+' +
                                                country.phonecode
                                            ) // Display country name and phone code
                                        )
                                    );
                                });


                                if (selectedCountryId) {
                                    // Find the country matching the phone code
                                    var selectedCountry = response.data.find(function(country) {
                                        return country.id === Number(
                                            selectedCountryId
                                        ); // Match based on the phone code
                                    });

                                    if (selectedCountry) {
                                        // Set the initial country/phone code in the dropdown button
                                        $('#countryDropdownButton_edit').text(selectedCountry
                                            .sortname + ' - +' + selectedCountry.phonecode);
                                        $('#country_code_name_edit').val(selectedCountry
                                            .phonecode
                                        ); // Ensure the hidden input gets updated as well
                                        $('#lead_mobile_edit').attr('maxlength',
                                            10); // Set maxlength based on country
                                    }
                                }

                                // Search functionality
                                $('#countrySearch_edit').on('input', function() {
                                    var searchValue = $(this).val().toLowerCase();
                                    $('#countryDropdownMenu_edit li a').each(
                                        function() {
                                            var countryText = $(this).text()
                                                .toLowerCase();
                                            if (countryText.indexOf(searchValue) ===
                                                -1) {
                                                $(this).parent()
                                                    .hide(); // Hide countries that don't match the search term
                                            } else {
                                                $(this).parent()
                                                    .show(); // Show countries that match
                                            }
                                        });
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });


                }
            });

            $('#countryId').on('change', function() {
                const selectedCountryId = $(this).val();
                if (selectedCountryId) {
                    // console.log(selectedCountryId)
                    $.ajax({
                        url: "{{ route('country') }}", // Assuming this is your server-side route to fetch countries
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var countryDropdownMenu = $('#countryDropdownMenu');
                                countryDropdownMenu.empty();


                                // Add the search input to the dropdown menu
                                countryDropdownMenu.append(
                                    '<li><input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>'
                                );

                                // Loop through the countries and add them to the dropdown
                                response.data.forEach(function(country) {
                                    countryDropdownMenu.append(
                                        $('<li></li>').append(
                                            $('<a></a>')
                                            .addClass('dropdown-item waves-effect')
                                            .attr('href', 'javascript:void(0);')
                                            .data('id', country.id)
                                            .data('phonecode', country.phonecode)
                                            .text(country.sortname + ' - ' + '+' +
                                                country.phonecode
                                            ) // Display country name and phone code
                                        )
                                    );
                                });


                                var initialPhoneCode = '';
                                if (selectedCountryId) {

                                    var selectedCountry = response.data.find(function(country) {
                                        return country.id === Number(selectedCountryId);
                                    });

                                    if (selectedCountry) {

                                        $('#countryDropdownButton').text(selectedCountry
                                            .sortname + ' - +' + selectedCountry.phonecode
                                        ); // Set the initial country/phone code
                                        initialPhoneCode = selectedCountry.phonecode;
                                        $('#lead_mobile_create').attr('maxlength', 10);
                                        $('#country_code_name').val(initialPhoneCode);
                                    }
                                }

                                $('#countrySearch').on('input', function() {
                                    var searchValue = $(this).val().toLowerCase();
                                    $('#countryDropdownMenu li a').each(function() {
                                        var countryText = $(this).text()
                                            .toLowerCase();
                                        if (countryText.indexOf(searchValue) ===
                                            -1) {
                                            $(this).parent()
                                                .hide(); // Hide countries that don't match the search term
                                        } else {
                                            $(this).parent()
                                                .show(); // Show countries that match
                                        }
                                    });
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });

                }
            });

            $.ajax({
                url: "{{ route('country') }}", // Assuming this is your server-side route to fetch countries
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdownMenu = $('#countryDropdownMenu');
                        countryDropdownMenu.empty();
                        // console.log(response.data);

                        // Add the search input to the dropdown menu
                        countryDropdownMenu.append(
                            '<li><input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>'
                        );

                        // Loop through the countries and add them to the dropdown
                        response.data.forEach(function(country) {
                            countryDropdownMenu.append(
                                $('<li></li>').append(
                                    $('<a></a>')
                                    .addClass('dropdown-item waves-effect')
                                    .attr('href', 'javascript:void(0);')
                                    .data('id', country.id)
                                    .data('phonecode', country.phonecode)
                                    .text(country.sortname + ' - ' + '+' + country
                                        .phonecode) // Display country name and phone code
                                )
                            );
                        });

                        // Pre-select country based on the initial selection (if any)
                        var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                        var initialPhoneCode = '';
                        if (selectedCountryId) {
                            var selectedCountry = response.data.find(function(country) {
                                return country.id === selectedCountryId;
                            });
                            if (selectedCountry) {
                                $('#countryDropdownButton').text(selectedCountry.sortname + ' - +' +
                                    selectedCountry.phonecode); // Set the initial country/phone code
                                initialPhoneCode = selectedCountry.phonecode;
                                $('#lead_mobile_create').attr('maxlength', 10);
                                $('#country_code_name').val(initialPhoneCode);
                            }
                        }

                        $('#countrySearch').on('input', function() {
                            var searchValue = $(this).val().toLowerCase();
                            $('#countryDropdownMenu li a').each(function() {
                                var countryText = $(this).text().toLowerCase();
                                if (countryText.indexOf(searchValue) === -1) {
                                    $(this).parent()
                                        .hide(); // Hide countries that don't match the search term
                                } else {
                                    $(this).parent()
                                        .show(); // Show countries that match
                                }
                            });
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            // Handle country selection from the dropdown
            $(document).on('click', '.dropdown-item', function() {
                var countryId = $(this).data('id');
                var phoneCode = $(this).data('phonecode');
                var countryName = $(this).text();

                $('#countryDropdownButton').text(countryName);
                $('#country_code_name').val(phoneCode);

                // Handle max length if needed based on country
                var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                if (countryId === selectedCountryId) {
                    $('#lead_mobile_create').attr('maxlength', 10); // Set max length for a specific country
                } else {
                    $('#lead_mobile_create').removeAttr(
                        'maxlength'); // Remove max length if country changes
                }
            });

            $.ajax({
                url: "{{ route('product_category_list') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#service_category_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Product Category</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.product_category_name));
                        });

                    }
                },
                error: function(error) {
                    console.error('Error fetching Product categories:', error);
                }
            })




            $.ajax({
                url: "{{ route('product_list_by_branch') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#service_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Product</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level
                                    .sno)
                                .text(level.product_name));
                        });


                    }
                },
                error: function(error) {
                    console.error('Error fetching Product categories:', error);
                }
            });




        });
        $(document).ready(function() {
            var selectedCountryId = null;
            var selectedStateId = null;
            var selectedCityId = null;


            // Fetch and populate countries for Add
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="country"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                        countryDropdown.val(selectedCountryId).trigger(
                            'change'); // Set the selected country and trigger change

                        $('select[name="country"]').val({{ $login_branch_data->country_id ?? 0 }})
                            .change();
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            // Event listener for country change for Add
            $('select[name="country"]').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('select[name="state"]');
                var cityDropdown = $('select[name="city"]');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country for Add
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: {
                            country_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.id).text(state.name));
                                });
                                stateDropdown.val(selectedStateId).trigger(
                                    'change'); // Set the selected state and trigger change

                                $('select[name="state"]').val(
                                    {{ $login_branch_data->state_id ?? 0 }}).change();
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // Event listener for state change for Add
            $('select[name="state"]').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('select[name="country"]').val();
                var cityDropdown = $('select[name="city"]');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country for Add
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr(
                                        'value', city.id).text(city.name));
                                });
                                cityDropdown.val(selectedCityId); // Set the selected city
                                // console.log('{{ $login_branch_data->city_id ?? 0 }}')
                                $('select[name="city"]').val(
                                    '{{ $login_branch_data->city_id ?? 0 }}').change();
                            }

                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });

            // Fetch and populate countries for Edit
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('select[name="country_edit"]');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                        countryDropdown.val(selectedCountryId).trigger(
                            'change'); // Set the selected country and trigger change
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });


            // Event listener for country change for Edit
            $('select[name="country_edit"]').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('select[name="state_edit"]');
                var cityDropdown = $('select[name="city_edit"]');

                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country for Edit
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: {
                            country_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.id).text(state.name));
                                });
                                stateDropdown.val(selectedStateId).trigger(
                                    'change'); // Set the selected state and trigger change
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });

            // Event listener for state change for Edit
            $('select[name="state_edit"]').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('select[name="country_edit"]').val();
                var cityDropdown = $('select[name="city_edit"]');

                cityDropdown.empty().append('<option value="">Select City</option>');

                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country for Edit
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr(
                                        'value', city.id).text(city.name));
                                });
                                cityDropdown.val(selectedCityId); // Set the selected city
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });

        });
    </script>
    {{-- mobile unique check --}}
    <script>
        function mobile_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('postleadCheckMobileExist') }}",
                    type: 'GET',
                    data: {
                        mobile: val,
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#lead_mobile_create_err').text('Lead Mobile Number is already assigned!');
                            $('#submit_lead_add').prop('disabled', true); // Disable submit button
                        } else {
                            $('#lead_mobile_create_err').text('');
                            $('#submit_lead_add').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }
        }

        function mobile_chk_edit(val) {
            var id = $('#lead_id_edit').val()
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('postleadCheckMobileExistsEdit') }}",
                    type: 'GET',
                    data: {
                        mobile: val,
                        id: id
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#lead_mobile_edit_err').text('Lead Mobile Number is already assigned!');
                            $('#submit_lead_edit').prop('disabled', true); // Disable submit button
                        } else {
                            $('#lead_mobile_edit_err').text('');
                            $('#submit_lead_edit').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }
        }
    </script>

    {{-- Email unique check --}}
    <script>
        function email_chk_validate(val) {
            // alert(val)
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('postleadCheckEmailExist') }}",
                    type: 'GET',
                    data: {
                        mobile: val,
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#lead_email_create_err').text('Lead Email Id is already assigned!');
                            $('#submit_lead_add').prop('disabled', true); // Disable submit button
                        } else {
                            $('#lead_email_create_err').text('');
                            $('#submit_lead_add').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }
        }

        function email_chk_edit(val) {
            var id = $('#lead_id_edit').val()
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });

                $.ajax({
                    url: "{{ route('postleadCheckEmailExistsEdit') }}",
                    type: 'GET',
                    data: {
                        mobile: val,
                        id: id
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#lead_email_edit_err').text('Lead Email Id is already assigned!');
                            $('#submit_lead_edit').prop('disabled', true); // Disable submit button
                        } else {
                            $('#lead_email_edit_err').text('');
                            $('#submit_lead_edit').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }
        }
    </script>
@endsection
