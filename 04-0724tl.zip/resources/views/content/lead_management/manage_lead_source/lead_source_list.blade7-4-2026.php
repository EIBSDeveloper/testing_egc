@extends('layouts/layoutMaster')

@section('title', 'Lead Source')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
'resources/assets/vendor/libs/apex-charts/apex-charts.scss',

])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
 'resources/assets/vendor/libs/apex-charts/apexcharts.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite(['resources/assets/js/charts-apex.js'])
@endsection
@section('content')
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
<!-- Customer List Table -->
<style>
    .lead_source thead th,
    .lead_source tbody td {
        padding: 15px !important;
        border: 1px solid rgb(0, 0, 0) !important;
    }

    .sticky_table {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
        border: 1px solid rgb(0, 0, 0) !important;
    }

    .sticky_table thead th,
    .sticky_table tfoot th,
    .sticky_table tbody td {
        position: relative;
        z-index: 1;
        padding: 8px;
        border: 1px solid rgb(0, 0, 0) !important;
    }

    .sticky_table thead th {
        position: sticky;
        top: 0;
        background: #099DDA;
        border: 1px solid rgb(0, 0, 0) !important;
        color: #fff;
        z-index: 3;
    }

    .sticky_table tfoot th {
        position: sticky;
        /* top: 0; */
        bottom: 0;
        background: #099DDA;
        border: 1px solid rgb(0, 0, 0) !important;
        color: #fff;
        z-index: 3;
    }

    .sticky_table tbody td {
        background: #fff;
        color: #000;
        border: 1px solid rgb(0, 0, 0) !important;
    }

    .sticky_table thead th:first-child,
    .sticky_table tfoot th:first-child,
    .sticky_table thead th:last-child,
    .sticky_table tfoot th:last-child {
        position: sticky;
        background: #099DDA;
        border: 1px solid rgb(0, 0, 0) !important;
        z-index: 4;
    }

    .sticky_table tbody td:first-child,
    .sticky_table tbody td:last-child {
        position: sticky;
        background: #fff;
        z-index: 4;
    }

    .sticky_table tbody td:first-child {
        background-color: rgb(216, 216, 216) !important;
    }

    .sticky_table thead th:first-child,
    .sticky_table tfoot th:first-child,
    .sticky_table tbody td:first-child {
        left: 0;
    }

    .sticky_table thead th:last-child,
    .sticky_table tfoot th:last-child,
    .sticky_table tbody td:last-child {
        right: 0;
    }
</style>


<div class="card">
    <div class="card-header border-bottom pb-1 ">
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            $user_id = auth()->user()->user_id;
            $user_data=$helper->get_staff_data($user_id);
            $document_send_count = $helper->general_setting_data()->max_document_send_limit ?? 7;
            $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
        @endphp
        
         <div class="row">
          
            <div class="col-lg-6">
              <h5 class="card-title mb-1">Lead Source</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-chevron-double-right fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            
            <div class="col-lg-6">
                
                
              <ul class="nav nav-pills justify-content-end" role="tablist">
                    <li class="nav-item me-1">
                        <a href="javascript:;" class="nav-link px-3" title="Graph" id="lead_graph" data-bs-toggle="modal" data-bs-target="#kt_modal_graph_view" >
                            <div class="text-center">
                                <i class="mdi mdi-finance fs-1"></i>
                            </div>
                        </a>
                    </li>
                  @php
                      $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
                      $currentYear  =  request()->get('year', date('Y')); // Default to current year if not provided
                      $currentYear_lab  =  request()->get('year', date('Y')); // Default to current year if not provided
                      
                      // Calculate previous month and year
                      $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
                      $previousYear = $currentYear ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January
                      
                      // Calculate next month and year
                      $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
                      $nextYear  = $currentYear ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December
                  @endphp
    
                  <!-- Previous Month Button -->
                  <li class="nav-item me-1">
                      <a class="nav-link px-3"
                          href="{{ route('lead-management-manage-lead-source', ['year' => $previousYear]) }}">
                          <div class="text-center">
                            <span class="mdi mdi-arrow-left-circle-outline  fs-2"></span>
                          </div>
                      </a>
                  </li>
    
                  <!-- Current Month Button (Active) -->
                  <li class="nav-item me-1">
                      <a class="nav-link active px-3 border border-dashed border-info"
                          href="{{ route('lead-management-manage-lead-source', ['year' => $currentYear]) }}">
                          <div class="text-center">
                              
                              <span class="fs-4 fw-semibold text-capitalize">{{$currentYear}}</span>
                          </div>
                      </a>
                  </li>
                  <!-- Next Month Button -->
                  <!--{{ $nextYear }}-->
                  <!--{{ $nextMonth }}-->
                  @if ($year_chk)
                  <li class="nav-item me-1">
                      <a class="nav-link px-3"
                          href="{{ route('lead-management-manage-lead-source', [ 'year' => $nextYear]) }}">
                          <div class="text-center">
                            <span class="mdi mdi-arrow-right-circle-outline  fs-2"></span>
                          </div>
                      </a>
                  </li>
                  @endif
              </ul>
            </div>
        </div>
    </div>
    <div class="card-body">        
        <div class="row">
            <div class="col-lg-12">
                <table class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px text-start fs-5 text-white fw-bold" style="background-color: #6D788D !important;">Lead Source</th>
                            @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                <th class="min-w-200px text-center">{{ $month }}</th>
                            @endforeach
                            <th class="min-w-100px text-center bg-dark text-white">Overall Total</th>
                        </tr>                
                    </thead>
                       
                   <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                    @php 
                        $overallTotal = [];
                        $overallTotalcus = [];
                    @endphp
                
                    @if (isset($results) && $results->count() > 0)
                        @foreach ($results->groupBy('lead_source_name') as $leadSource => $leads)
                            <tr>
                                <td >
                                    <label class="fs-6 fw-bold">{{ $leadSource }}</label>
                                </td>
                                @php 
                                    $sourceTotal = 0; 
                                    $sourceTotalCus = 0;
                                    $sourceTotalCus_per = 0;
                                    $sourceTotalCus_per_sing = 0;
                                @endphp
                
                                @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                @php
                                    $leadData = $leads->firstWhere('month_name', $month);
                                
                                    $leadCount = $leadData->total_lead ?? 0;
                                    $cusCount = $leadData->customer_count ?? 0;
                                
                                    // Source-wise total accumulation
                                    $sourceTotal += $leadCount;
                                    $sourceTotalCus += $cusCount;
                                
                                    // Monthly-wise overall total accumulation
                                    $overallTotal[$month] = ($overallTotal[$month] ?? 0) + $leadCount;
                                    $overallTotalcus[$month] = ($overallTotalcus[$month] ?? 0) + $cusCount;
                                
                                    // Percentage calculations
                                    $sourceTotalCus_per = ($sourceTotal > 0) ? round(($sourceTotalCus / $sourceTotal) * 100, 2) : 0;
                                    $sourceTotalCus_per_sing = ($leadCount > 0) ? round(($cusCount / $leadCount) * 100, 2) : 0;
                                @endphp

                
                                    <td class="text-center">
                                        @if($leadCount > 0 || $cusCount>0)
                                            <label class="badge bg-info rounded-pill fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Leads">{{ sprintf("%02d", $leadCount) }}</label> <span class="text-black fw-semibold fs-5"> /</span>
                                            <label class="badge bg-success text-black rounded-pill fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Customers">{{ sprintf("%02d", $cusCount) }}</label> <span class="text-black fw-semibold fs-5"> /</span> 
                                            <label class="badge bg-secondary rounded-pill fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Conversion Percentage">{{ sprintf("%.2f", $sourceTotalCus_per_sing) }}%</label>
                                        @else
                                            <label class=" fs-6" style="min-width: 50px;">-</label>
                                        @endif
                                    </td>
                                @endforeach
                
                                <td class="text-center text-white fs-5" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Leads / Customers / Conversion Percentage" style="background-color: @if($sourceTotal ??0 > 1) #50cd89 @else #ff7676 @endif;">
                                    <strong>{{ sprintf("%02d",$sourceTotal) }} / {{sprintf("%02d",$sourceTotalCus)}}</strong> <br>
                                    <strong>{{ sprintf("%.2f", $sourceTotalCus_per) }}%</strong>
                                </td>
                            </tr>
                        @endforeach
                
                        <!-- Overall Total Row -->
                        <tr class="">
                            <td class="min-w-200px fs-5 text-white fw-bold" style="background-color: #6D788D !important;">Overall Totals</td>
                            @php 
                                $grandTotal = 0; 
                                $grandTotalCus = 0;
                                $grandTotalCusper = 0;
                                $grandTotalCusper_single = 0;
                            @endphp
                
                            @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                @php 
                                    $grandTotal += $overallTotal[$month] ?? 0; 
                                    $grandTotalCus += $overallTotalcus[$month] ?? 0;
                                @endphp
                                 @php 
                                    // Calculate the percentage after looping through all the months
                                    $grandTotalCusper_single = ($overallTotalcus[$month] > 0) ? round(($overallTotalcus[$month]  / $overallTotal[$month]) * 100, 2) : 0;
                                @endphp
                                <td class="text-center bg-primary text-white fw-semibold fs-4" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Total Leads / Customers / Conversion Percentage" >
                                    <strong>{{ sprintf("%02d", $overallTotal[$month] ?? 0) }}</strong> <span class="text-black fw-semibold fs-5"> /</span>
                                    <strong>{{ sprintf("%02d", $overallTotalcus[$month] ?? 0) }}</strong> <span class="text-black fw-semibold fs-5"> /</span> 
                                    <strong>{{ sprintf("%.2f", $grandTotalCusper_single ?? 0) }}%</strong>
                                </td>
                            @endforeach
                
                            @php 
                                // Calculate the percentage after looping through all the months
                                $grandTotalCusper = ($grandTotal > 0) ? round(($grandTotalCus / $grandTotal) * 100, 2) : 0;
                            @endphp
                
                            <td class="text-center bg-success text-white fs-5" >
                                <strong>{{ sprintf("%02d", $grandTotal) }}</strong> /
                                <strong>{{ sprintf("%02d", $grandTotalCus) }}</strong> <br>
                                <strong>{{ sprintf("%.2f", $grandTotalCusper) }}%</strong>
                            </td>
                        </tr>
                
                    @endif
                </tbody>



                </table>
            </div>
        </div>
    </div>
</div>

<!--begin::Modal - View Graph-->
<div class="modal fade" id="kt_modal_graph_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
        <!--begin::Modal header-->
        <div class="modal-header justify-content-end border-0 pb-0">
          <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
        <!--end::Modal header-->
        <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
          <div class="mb-6">
            <h3 class="text-center text-black">Overall Lead Source Graph - <span class="text-danger" > ({{$currentYear}}) </span></h3>
          </div>
          <div class="row">
            <div class="col-lg-12" id="graph_lead_cal_view">
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<!--end::Modal - View Graph-->




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>

// Function to show full image in modal
function showFullImage(imageUrl) {
    document.getElementById('fullImage').src = imageUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}

function showFullTextAvatar(letter, bgColor) {
    let encodedSvg = encodeURIComponent(`
        <svg xmlns="http://www.w3.org/2000/svg" width="400" height="400">
            <rect width="100%" height="100%" fill="${bgColor}"/>
            <text x="50%" y="50%" font-size="150" fill="white" font-family="Arial" text-anchor="middle" dy=".3em">${letter}</text>
        </svg>
    `);

    let dataUrl = `data:image/svg+xml,${encodedSvg}`;

    document.getElementById('fullImage').src = dataUrl;
    new bootstrap.Modal(document.getElementById('imageModal')).show();
}
function fsc_sts_func(val) {

    if (val == "reject") {
        document.getElementById("rejct_tbox").style.display = "block";
        document.getElementById("smt_butt").innerHTML = "Rejected";
    } else if (val == "accept") {
        document.getElementById("rejct_tbox").style.display = "none";
        document.getElementById("smt_butt").innerHTML = "Approved";
    } else {
        document.getElementById("rejct_tbox").style.display = "none";
        document.getElementById("smt_butt").innerHTML = "Approved";
    }
}
</script>
<script>
// Pass PHP data to JavaScript
var callLogData = {!! json_encode($results->groupBy('lead_source_name')->map(function($leads) {
    return $leads->mapWithKeys(function($lead) {
        return [
            $lead->month_name => [
                'total_lead' => $lead->total_lead ?? 0,
                'customer_count' => $lead->customer_count ?? 0
            ]
        ];
    });
})) !!};
</script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('kt_modal_graph_view');
    if (modal) {
        modal.addEventListener('shown.bs.modal', function () {
            renderGraph();
        });
    }
});

function getRandomColor() {
    return `#${Math.random().toString(16).slice(2, 8).padEnd(6, '0')}`;
}

function renderGraph() {
    if (!callLogData || Object.keys(callLogData).length === 0) {
        console.error("No data available for the graph.");
        return;
    }

    const leadSources = Object.keys(callLogData);
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    let seriesData = [];
    let colorArray = [];

    leadSources.forEach((source) => {
        let leadColor = getRandomColor();
        let customerColor = getRandomColor();
        let conversionColor = getRandomColor();

        seriesData.push({
            name: `${source} - Leads`,
            type: 'column',
            data: months.map(month => callLogData[source]?.[month]?.total_lead || 0)
        });
        seriesData.push({
            name: `${source} - Customers`,
            type: 'area',
            data: months.map(month => callLogData[source]?.[month]?.customer_count || 0)
        });
        seriesData.push({
            name: `${source} - Conversion %`,
            type: 'line',
            data: months.map(month => {
                let total_lead = callLogData[source]?.[month]?.total_lead || 0;
                let customer_count = callLogData[source]?.[month]?.customer_count || 0;
                return total_lead > 0 ? ((customer_count / total_lead) * 100).toFixed(2) : 0;
            })
        });

        colorArray.push(leadColor, customerColor, conversionColor);
    });

    const chartContainer = document.querySelector("#graph_lead_cal_view");
    if (!chartContainer) {
        console.error("Graph container not found!");
        return;
    }

    // Destroy old chart if exists
    if (chartContainer.innerHTML.trim() !== "") {
        chartContainer.innerHTML = "";
    }

    const mixedChartConfig = {
        chart: {
            type: 'line',
            stacked: false
        },
        series: seriesData,
        xaxis: {
            categories: months
        },
        colors: colorArray,
        legend: {
            position: 'bottom',
            horizontalAlign: 'center',
        }
    };

    const chart = new ApexCharts(chartContainer, mixedChartConfig);
    chart.render();
}
</script>


<script>
  // Display Toastr messages
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
  toastr[type](message);
  @endif
</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
    $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.customer_tbox').slideToggle('fast');
                $('.filter_tbox').slideToggle('fast');
                // });
            @endif
        });
</script>

<script>
    $(".list_page").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
  $(".list_page2").DataTable({
        //   "ordering": false,
          "paging": false,
            "sorting": true,
          // "aaSorting":[],
          "language": {
              "lengthMenu": "Show _MENU_"
          , }
          ,"dom": "<'row mb-3'" +
              // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
              // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
              ">" +

              "<'table-responsive'tr>" +

              "<'row'" +
              // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
              // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
              ">"
      });
</script>
<script>
    function sort_filter(val) {
      if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
      } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
      }
    }
</script>


@endsection
