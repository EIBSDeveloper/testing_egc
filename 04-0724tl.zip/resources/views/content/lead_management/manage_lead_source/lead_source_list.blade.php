@extends('layouts/layoutMaster')

@section('title', 'Lead Source')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss', 'resources/assets/vendor/libs/apex-charts/apex-charts.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/sweetalert2/sweetalert2.js', 'resources/assets/vendor/libs/apex-charts/apexcharts.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite(['resources/assets/js/charts-apex.js'])
@endsection

@section('content')
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp

    <style>
        .lead_source thead th,
        .lead_source tbody td {
            padding: 15px !important;
            border: 1px solid rgb(0, 0, 0) !important;
        }

        .table-container {
            position: relative;
            max-width: 100%;
            overflow-x: auto;
            overflow-y: auto;
            max-height: 70vh;
            border: 1px solid #dee2e6;
            border-radius: 0.375rem;
        }

        .sticky_table {
            width: max-content;
            min-width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background-color: #fff;
        }

        /* Base cell styles */
        .sticky_table thead th,
        .sticky_table tbody td,
        .sticky_table tfoot th {
            border: 1px solid #000 !important;
            padding: 12px 8px;
            vertical-align: middle;
            white-space: nowrap;
        }

        /* Header styling */
        .sticky_table thead th {
            background-color: #099DDA;
            color: #fff;
            font-weight: 600;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        /* Footer styling */
        .sticky_table tfoot th {
            background-color: #099DDA;
            color: #fff;
            font-weight: 600;
            position: sticky;
            bottom: 0;
            z-index: 10;
        }

        /* Left column (Lead Source) - Sticky */
        .sticky_table thead th:first-child,
        .sticky_table tbody td:first-child,
        .sticky_table tfoot th:first-child {
            position: sticky;
            left: 0;
            z-index: 15;
            background-color: #f8f9fa;
            font-weight: 700;
        }

        .sticky_table thead th:first-child {
            background-color: #6D788D;
            z-index: 20;
        }

        .sticky_table tfoot th:first-child {
            background-color: #6D788D;
            z-index: 20;
        }

        /* Right column (Overall Total) - Sticky */
        .sticky_table thead th:last-child,
        .sticky_table tbody td:last-child,
        .sticky_table tfoot th:last-child {
            position: sticky;
            right: 0;
            z-index: 15;
            background-color: #fff;
        }

        .sticky_table thead th:last-child {
            background-color: #343a40;
            z-index: 20;
        }

        .sticky_table tfoot th:last-child {
            background-color: #28a745;
            z-index: 20;
        }

        /* Ensure proper layering on hover */
        .sticky_table tbody td:first-child {
            background-color: #f8f9fa;
        }

        .sticky_table tbody td:last-child {
            background-color: #fff;
        }

        /* Scrollbar styling */
        .table-container::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }

        .table-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }

        .table-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }

        /* Data cell min width */
        .data-cell {
            min-width: 180px;
        }

        .clickable-badge {
            cursor: pointer;
            transition: transform 0.2s;
        }

        .clickable-badge:hover {
            transform: scale(1.05);
            opacity: 0.9;
        }

        .modal-details-list {
            max-height: 500px;
            overflow-y: auto;
        }

        .detail-item {
            transition: background-color 0.2s;
        }

        .detail-item:hover {
            background-color: #f8f9fa;
        }

        @media (min-width: 768px) {
            .border-end-md {
                border-right: 1px solid rgba(0, 0, 0, 0.1);
            }
        }
    </style>

    <div class="card">
        <div class="card-header border-bottom pb-1">
            @php
                $helper = new \App\Helpers\Helpers();
                $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
                $user_id = auth()->user()->user_id;
                $user_data = $helper->get_staff_data($user_id);
                $document_send_count = $helper->general_setting_data()->max_document_send_limit ?? 7;
                $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
            @endphp

            <div class="row">
                <div class="col-lg-6">
                    <h5 class="card-title mb-1">Lead Source</h5>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="{{ url('/dashboards') }}" class="d-flex align-items-center">
                                    <i class="mdi mdi-home text-body fs-4"></i>
                                </a>
                            </li>
                            <span class="text-dark opacity-75 me-1 ms-1">
                                <i class="mdi mdi-chevron-double-right fs-4"></i>
                            </span>
                            <li class="breadcrumb-item">
                                <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                            </li>
                        </ol>
                    </nav>
                </div>

                <div class="col-lg-6">
                    <ul class="nav nav-pills justify-content-end" role="tablist">
                        <li class="nav-item me-1">
                            <a href="javascript:;" class="nav-link px-3" title="Graph" id="lead_graph"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_graph_view">
                                <div class="text-center">
                                    <i class="mdi mdi-finance fs-1"></i>
                                </div>
                            </a>
                        </li>
                        @php
                            $currentMonth = request()->get('month', date('m'));
                            $currentYear = request()->get('year', date('Y'));
                            $currentYear_lab = request()->get('year', date('Y'));
                            $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12;
                            $previousYear = $currentYear ? $currentYear - 1 : $currentYear;
                            $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1;
                            $nextYear = $currentYear ? $currentYear + 1 : $currentYear;
                        @endphp

                        <li class="nav-item me-1">
                            <a class="nav-link px-3"
                                href="{{ route('lead-management-manage-lead-source', ['year' => $previousYear]) }}">
                                <div class="text-center">
                                    <span class="mdi mdi-arrow-left-circle-outline fs-2"></span>
                                </div>
                            </a>
                        </li>

                        <li class="nav-item me-1">
                            <a class="nav-link active px-3 border border-dashed border-info"
                                href="{{ route('lead-management-manage-lead-source', ['year' => $currentYear]) }}">
                                <div class="text-center">
                                    <span class="fs-4 fw-semibold text-capitalize">{{ $currentYear }}</span>
                                </div>
                            </a>
                        </li>

                        @if ($year_chk)
                            <li class="nav-item me-1">
                                <a class="nav-link px-3"
                                    href="{{ route('lead-management-manage-lead-source', ['year' => $nextYear]) }}">
                                    <div class="text-center">
                                        <span class="mdi mdi-arrow-right-circle-outline fs-2"></span>
                                    </div>
                                </a>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </div>

        <div class="card-body">
            <div class="table-container">
                <table
                    class="table sticky_table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px text-start fs-5 text-white fw-bold"
                                style="background-color: #6D788D !important;">Lead Source</th>
                            @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                <th class="min-w-150px text-center">{{ $month }}</th>
                            @endforeach
                            <th class="min-w-200px text-center bg-dark text-white">Overall Total</th>
                        </tr>
                    </thead>

                    <tbody class="text-black fw-semibold fs-7" id="payment-table-body">
                        @php
                            $overallTotal = [];
                            $overallTotalcus = [];
                            $grandTotal = 0;
                            $grandTotalCus = 0;
                        @endphp

                        @if (isset($results) && $results->count() > 0)
                            @foreach ($results->groupBy('lead_source_name') as $leadSource => $leadsCollection)
                                @php
                                    // Convert to collection once at the beginning
                                    $leadsCollection = collect($leadsCollection);
                                    $sourceTotal = 0;
                                    $sourceTotalCus = 0;
                                @endphp

                                <tr>
                                    <td class="min-w-150px text-start fs-6 fw-bold" style="background-color: #f8f9fa;">
                                        {{ $leadSource }}
                                    </td>

                                    @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                        @php
                                            $leadData = $leadsCollection->firstWhere('month_name', $month);
                                            $uniqueId = uniqid();
                                            $leadCount =
                                                $leadData && isset($leadData->total_lead)
                                                    ? (int) $leadData->total_lead
                                                    : 0;
                                            $cusCount =
                                                $leadData && isset($leadData->customer_count)
                                                    ? (int) $leadData->customer_count
                                                    : 0;

                                            $conversionPercentage =
                                                $leadCount > 0 ? round(($cusCount / $leadCount) * 100, 2) : 0;

                                            $sourceTotal += $leadCount;
                                            $sourceTotalCus += $cusCount;

                                            $overallTotal[$month] = ($overallTotal[$month] ?? 0) + $leadCount;
                                            $overallTotalcus[$month] = ($overallTotalcus[$month] ?? 0) + $cusCount;

                                            $grandTotal += $leadCount;
                                            $grandTotalCus += $cusCount;
                                        @endphp

                                        <td class="text-center data-cell">
                                            @if ($leadCount > 0 || $cusCount > 0)
                                                <div class="d-flex flex-column align-items-center gap-1">
                                                    <div
                                                        class="d-flex align-items-center gap-2 flex-wrap justify-content-center">
                                                        <!-- Lead Count Badge - Clickable -->
                                                        <span class="badge bg-info fs-7 clickable-badge"
                                                            data-bs-toggle="modal" data-bs-target="#leadModal"
                                                            data-lead-source="{{ $leadSource }}"
                                                            data-month="{{ $month }}"
                                                            data-lead-count="{{ $leadCount }}"
                                                            data-lead-details='@json($leadData->leaddata_details ?? [])'
                                                            style="cursor: pointer;">
                                                            <i class="mdi mdi-account-multiple me-1"></i>
                                                            {{ sprintf('%02d', $leadCount) }}
                                                        </span>

                                                        <span class="text-dark fw-semibold fs-6">/</span>

                                                        <!-- Customer Count Badge - Clickable -->
                                                        <span class="badge bg-success fs-7 clickable-badge"
                                                            data-bs-toggle="modal" data-bs-target="#customerModal"
                                                            data-customer-source="{{ $leadSource }}"
                                                            data-customer-month="{{ $month }}"
                                                            data-customer-count="{{ $cusCount }}"
                                                            data-customer-details='@json($leadData->customer_details ?? [])'
                                                            style="cursor: pointer;">
                                                            <i class="mdi mdi-account-check me-1"></i>
                                                            {{ sprintf('%02d', $cusCount) }}
                                                        </span>

                                                        <span class="text-dark fw-semibold fs-6">/</span>
                                                        <span class="badge bg-secondary fs-7" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom"
                                                            data-bs-original-title="Conversion Percentage">
                                                            <i class="mdi mdi-percent me-1"></i>
                                                            {{ sprintf('%.2f', $conversionPercentage) }}%
                                                        </span>
                                                    </div>
                                                </div>
                                            @else
                                                <span class="text-muted">-</span>
                                            @endif
                                        </td>
                                    @endforeach

                                    @php
                                        $sourceConversionPercentage =
                                            $sourceTotal > 0 ? round(($sourceTotalCus / $sourceTotal) * 100, 2) : 0;
                                    @endphp

                                    <td class="text-center text-white fs-5"
                                        style="background-color: {{ ($sourceTotal ?? 0) > 0 ? '#50cd89' : '#ff7676' }};">
                                        <strong>{{ sprintf('%02d', $sourceTotal) }} /
                                            {{ sprintf('%02d', $sourceTotalCus) }}</strong>
                                        <br>
                                        <strong>{{ sprintf('%.2f', $sourceConversionPercentage) }}%</strong>
                                    </td>
                                </tr>
                            @endforeach
                        @else
                            <tr>
                                <td colspan="14" class="text-center text-muted py-5">
                                    <i class="mdi mdi-database-search fs-1"></i>
                                    <p class="mt-2">No data available for the selected year</p>
                                </td>
                            </tr>
                        @endif
                    </tbody>

                    <!-- tfoot with Overall Totals - Sticky at bottom -->
                    <tfoot>
                        <tr style="background-color: #6D788D;">
                            <th class="min-w-200px fs-5 text-white fw-bold text-start"
                                style="background-color: #6D788D !important;">
                                Overall Totals
                            </th>
                            @foreach (['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'] as $month)
                                @php
                                    $monthTotal = $overallTotal[$month] ?? 0;
                                    $monthTotalCus = $overallTotalcus[$month] ?? 0;
                                    $monthConversion =
                                        $monthTotal > 0 ? round(($monthTotalCus / $monthTotal) * 100, 2) : 0;
                                @endphp
                                <th class="text-center bg-primary text-white fw-semibold fs-4">
                                    <strong>{{ sprintf('%02d', $monthTotal) }}</strong>
                                    <span class="text-white-50 fs-6">/</span>
                                    <strong>{{ sprintf('%02d', $monthTotalCus) }}</strong>
                                    <span class="text-white-50 fs-6">/</span>
                                    <strong>{{ sprintf('%.2f', $monthConversion) }}%</strong>
                                </th>
                            @endforeach

                            @php
                                $grandTotalConversion =
                                    $grandTotal > 0 ? round(($grandTotalCus / $grandTotal) * 100, 2) : 0;
                            @endphp
                            <th class="text-center bg-success text-white fs-5">
                                <strong>{{ sprintf('%02d', $grandTotal) }}</strong> /
                                <strong>{{ sprintf('%02d', $grandTotalCus) }}</strong>
                                <br>
                                <strong>{{ sprintf('%.2f', $grandTotalConversion) }}%</strong>
                            </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>

    <!-- Lead Details Modal -->
    <div class="modal fade" id="leadModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                    <h5 class="modal-title text-white">
                        <i class="mdi mdi-account-multiple me-2"></i>Lead Details
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <div class="text-muted mb-2">Lead Source:
                                <span id="leadSourceName" class="text-dark fw-bold">Direct Call</span>
                            </div>
                            <div class="text-muted mb-2">Month:
                                <span id="leadMonthName" class="text-dark fw-bold">January</span>
                            </div>
                        </div>
                        <div class="alert alert-info">
                            <i class="mdi mdi-information-outline me-2"></i>
                            Total Leads: <strong id="totalLeadCount" class="fs-5"></strong>
                        </div>
                    </div>

                    <div class="modal-details-list" id="leadDetailsList">
                        <!-- Lead details will be populated here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Details Modal -->
    <div class="modal fade" id="customerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);">
                    <h5 class="modal-title text-white">
                        <i class="mdi mdi-account-group me-2"></i>Customer Details
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <div class="d-flex justify-content-between">
                            <div class="text-muted mb-2">Lead Source:
                                <span id="customerSourceName" class="text-dark fw-bold">Direct Call</span>
                            </div>
                            <div class="text-muted mb-2">Month:
                                <span id="customerMonthName" class="text-dark fw-bold">January</span>
                            </div>
                        </div>
                        <div class="alert alert-success mb-3">
                            <div class="row text-center">
                                <div class="col-md-2 border-end-md">
                                    <i class="mdi mdi-account-check fs-3 me-2"></i>
                                    <div class="text-muted small mb-1">Total Customers</div>
                                    <div id="totalCustomerCount" class="fs-4 fw-bold">0</div>
                                </div>
                                <div class="col-md-3 border-end-md">
                                    <i class="mdi mdi-cash-multiple fs-3 me-2"></i>
                                    <div class="text-muted small mb-1">Total BV</div>
                                    <div id="totalBusiness" class="fs-4 fw-bold">0</div>
                                </div>
                                <div class="col-md-3 border-end-md">
                                    <i class="mdi mdi-chart-line  fs-3 me-2"></i>
                                    <div class="text-muted small mb-1">Avg BV</div>
                                    <div id="totalBusinessvalue" class="fs-4 fw-bold">₹0</div>
                                </div>
                                <div class="col-md-2 border-end-md">
                                    <i class="mdi mdi-cash-100  fs-3 me-2"></i>
                                    <div class="text-muted small mb-1">Avg CV</div>
                                    <div id="totalCollectionvalue" class="fs-4 fw-bold">₹0</div>
                                </div>
                                <div class="col-md-2 d-flex flex-column">
                                    <div class="d-flex align-items-center justify-content-between gap-3">
                                        <div class="text-muted small">ODC</div>
                                        <div id="onDay" class="fs-4 fw-bold">0</div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between gap-3">
                                        <div class="text-muted small">OMC</div>
                                        <div id="onMonth" class="fs-4 fw-bold">0</div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-between gap-3">
                                        <div class="text-muted small">OLC</div>
                                        <div id="oldMonth" class="fs-4 fw-bold">0</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-details-list" id="customerDetailsList">
                        <!-- Customer details will be populated here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal - View Graph -->
    <div class="modal fade" id="kt_modal_graph_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <div class="modal-dialog modal-xl">
            <div class="modal-content rounded">
                <div class="modal-header justify-content-end border-0 pb-0">
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </div>
                </div>
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="mb-6">
                        <h3 class="text-center text-black">Overall Lead Source Graph - <span class="text-danger">
                                ({{ $currentYear ?? date('Y') }}) </span></h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12" id="graph_lead_cal_view">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script>
        var callLogData = {!! json_encode(
            isset($results) && $results->count() > 0
                ? $results->groupBy('lead_source_name')->map(function ($leads) {
                    return $leads->mapWithKeys(function ($lead) {
                        return [
                            $lead->month_name => [
                                'total_lead' => $lead->total_lead ?? 0,
                                'customer_count' => $lead->customer_count ?? 0,
                            ],
                        ];
                    });
                })
                : [],
        ) !!};
    </script>

    <script>
        // Lead Modal Handler
        document.addEventListener('DOMContentLoaded', function() {

            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }
            // Handle Lead Modal
            const leadModal = document.getElementById('leadModal');
            if (leadModal) {
                leadModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    const leadSource = button.getAttribute('data-lead-source');
                    const month = button.getAttribute('data-month');
                    const leadCount = button.getAttribute('data-lead-count');
                    const leadDetails = JSON.parse(button.getAttribute('data-lead-details') || '[]');

                    document.getElementById('leadSourceName').textContent = leadSource;
                    document.getElementById('leadMonthName').textContent = month;
                    document.getElementById('totalLeadCount').textContent = leadCount;

                    const leadDetailsList = document.getElementById('leadDetailsList');
                    leadDetailsList.innerHTML = '';

                    if (leadDetails && leadDetails.length > 0) {
                        leadDetails.forEach((lead, index) => {
                            const detailHtml = `
                                <div class="detail-item p-3 mb-2 border rounded">
                                    <div class="d-flex align-items-start gap-3">
                                        <div class="bg-light-info rounded-circle d-flex align-items-center justify-content-center"
                                             style="width: 50px; height: 50px; min-width: 50px;">
                                            <i class="mdi mdi-account-convert text-info fs-3"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="fw-bold mb-2">${escapeHtml(lead.lead_name || 'N/A')}</h6>
                                            <div class="row g-2">
                                                <div class="col-md-6">
                                                    <small class="text-muted d-block">
                                                        <i class="mdi mdi-email me-1"></i> 
                                                        ${escapeHtml(lead.lead_email_id || 'No Email')}
                                                    </small>
                                                </div>
                                                <div class="col-md-6">
                                                    <small class="text-muted d-block">
                                                        <i class="mdi mdi-phone me-1"></i> 
                                                        ${escapeHtml(lead.lead_mobile || 'No Mobile')}
                                                    </small>
                                                </div>
                                                <div class="col-md-6">
                                                    <small class="text-muted d-block">
                                                        <i class="mdi mdi-identifier me-1"></i> 
                                                        Lead ID: ${escapeHtml(lead.lead_id || 'N/A')}
                                                    </small>
                                                </div>
                                                <div class="col-md-6">
                                                    <small class="text-muted d-block">
                                                        <i class="mdi mdi-source-branch me-1"></i> 
                                                        Source: ${escapeHtml(lead.lead_source_name || 'N/A')}
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                            leadDetailsList.insertAdjacentHTML('beforeend', detailHtml);
                        });
                    } else {
                        leadDetailsList.innerHTML = `
                            <div class="text-center text-muted py-5">
                                <i class="mdi mdi-account-off fs-1"></i>
                                <p class="mb-0 mt-2">No lead details available</p>
                            </div>
                        `;
                    }
                });
            }

            // Handle Customer Modal
            const customerModal = document.getElementById('customerModal');
            if (customerModal) {
                customerModal.addEventListener('show.bs.modal', function(event) {
                    const button = event.relatedTarget;
                    const customerSource = button.getAttribute('data-customer-source');
                    const month = button.getAttribute('data-customer-month');
                    const customerCount = button.getAttribute('data-customer-count');

                    // Parse the customer details object
                    const customerData = JSON.parse(button.getAttribute('data-customer-details') || '{}');

                    // Extract customers (all numeric keys) and totals
                    const customerDetails = [];
                    let totalBusinessValue = null;
                    let totalCollectionValue = null;
                    let totalBusiness = null;
                    let ODC = null;
                    let OMC = null;
                    let OLC = null;

                    // Loop through the object to separate customers from totals
                    for (let key in customerData) {
                        if (customerData.hasOwnProperty(key)) {
                            if (key === 'TotalaverageBusinessValue') {
                                totalBusinessValue = customerData[key];
                            } else if (key === 'TotalaveragCollectionValue') {
                                totalCollectionValue = customerData[key];
                            } else if (key === 'TotalBusiness') {
                                totalBusiness = customerData[key];
                            } else if (key === 'ODC') {
                                ODC = customerData[key];
                            } else if (key === 'OMC') {
                                OMC = customerData[key];
                            } else if (key === 'OLC') {
                                OLC = customerData[key];
                            } else if (!isNaN(parseInt(key))) {
                                // This is a customer record (numeric key)
                                customerDetails.push(customerData[key]);
                            }
                        }
                    }

                    document.getElementById('customerSourceName').textContent = customerSource;
                    document.getElementById('customerMonthName').textContent = month;
                    document.getElementById('totalCustomerCount').textContent = customerCount;

                    // Display total values if elements exist
                    const totalBusinessValueElement = document.getElementById('totalBusinessvalue');
                    const totalCollectionElement = document.getElementById('totalCollectionvalue');
                    const totalBusinessElement = document.getElementById('totalBusiness');
                    const ODCElement = document.getElementById('onDay');
                    const OMCElement = document.getElementById('onMonth');
                    const OLCElement = document.getElementById('oldMonth');

                    if (totalBusinessValueElement) {
                        totalBusinessValueElement.textContent = totalBusinessValue !== null ?
                            totalBusinessValue.toFixed(2) :
                            'N/A';
                    }

                    if (totalCollectionElement) {
                        totalCollectionElement.textContent = totalCollectionValue !== null ?
                            totalCollectionValue.toFixed(2) :
                            'N/A';
                    }

                    if (totalBusinessElement) {
                        totalBusinessElement.textContent = totalBusiness !== null ?
                            totalBusiness.toFixed(2) :
                            'N/A';
                    }

                    if (ODCElement) {
                        ODCElement.textContent = ODC !== null ?
                            ODC :
                            'N/A';
                    }

                    if (OMCElement) {
                        OMCElement.textContent = OMC !== null ?
                            OMC :
                            'N/A';
                    }

                    if (OLCElement) {
                        OLCElement.textContent = OLC !== null ?
                            OLC :
                            'N/A';
                    }

                    const customerDetailsList = document.getElementById('customerDetailsList');
                    customerDetailsList.innerHTML = '';

                    // Check if we have customers
                    if (customerDetails.length > 0) {
                        customerDetails.forEach((customer, index) => {
                            const detailHtml = `
                    <div class="detail-item p-3 mb-2 border rounded">
                        <div class="d-flex align-items-start gap-3">
                            <div class="bg-light-success rounded-circle d-flex align-items-center justify-content-center"
                                 style="width: 50px; height: 50px; min-width: 50px;">
                                <i class="mdi mdi-account text-success fs-3"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="fw-bold mb-2">${escapeHtml(customer.cus_name || 'N/A')}</h6>
                                <div class="row g-2">
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-email me-1"></i> 
                                            ${escapeHtml(customer.cus_email_id || 'No Email')}
                                        </small>
                                    </div>
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-phone me-1"></i> 
                                            ${escapeHtml(customer.cus_mobile || 'No Mobile')}
                                        </small>
                                    </div>
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-identifier me-1"></i> 
                                            Customer ID: ${escapeHtml(customer.customer_id || 'N/A')}
                                        </small>
                                    </div>
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-source-branch me-1"></i> 
                                            Registered Date: ${formatDate(customer.registered_date || '')}
                                        </small>
                                    </div>
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-chart-line me-1"></i> 
                                            ABV: ${escapeHtml(customer.averageBusinessValue?.toFixed(2) || 'N/A')}
                                        </small>
                                    </div>
                                    <div class="col-md-6">
                                        <small class="text-muted d-block">
                                            <i class="mdi mdi-cash-100 me-1"></i> 
                                            ACV: ${escapeHtml(customer.averageCollectionValue?.toFixed(2) || 'N/A')}
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                            customerDetailsList.insertAdjacentHTML('beforeend', detailHtml);
                        });
                    } else {
                        customerDetailsList.innerHTML = `
                <div class="text-center text-muted py-5">
                    <i class="mdi mdi-account-off fs-1"></i>
                    <p class="mb-0 mt-2">No customer details available</p>
                </div>
            `;
                    }
                });
            }

            // Helper function to escape HTML and prevent XSS
            function escapeHtml(str) {
                if (!str) return '';
                return str.toString()
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#39;');
            }
        });

        // Helper function to escape HTML
        function escapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('kt_modal_graph_view');
            if (modal) {
                modal.addEventListener('shown.bs.modal', function() {
                    renderGraph();
                });
            }
        });

        function getRandomColor() {
            return `#${Math.random().toString(16).slice(2, 8).padEnd(6, '0')}`;
        }

        function renderGraph() {
            if (!callLogData || Object.keys(callLogData).length === 0) {
                document.querySelector("#graph_lead_cal_view").innerHTML =
                    '<div class="text-center text-muted py-5">No data available to display graph</div>';
                return;
            }

            const leadSources = Object.keys(callLogData);
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September',
                'October', 'November', 'December'
            ];

            let seriesData = [];
            let colorArray = [];

            leadSources.forEach((source) => {
                let leadColor = getRandomColor();
                let customerColor = getRandomColor();
                let conversionColor = getRandomColor();

                seriesData.push({
                    name: `${source} - Leads`,
                    type: 'column',
                    data: months.map(month => callLogData[source]?.[month]?.total_lead || 0)
                });
                seriesData.push({
                    name: `${source} - Customers`,
                    type: 'area',
                    data: months.map(month => callLogData[source]?.[month]?.customer_count || 0)
                });
                seriesData.push({
                    name: `${source} - Conversion %`,
                    type: 'line',
                    data: months.map(month => {
                        let total_lead = callLogData[source]?.[month]?.total_lead || 0;
                        let customer_count = callLogData[source]?.[month]?.customer_count || 0;
                        return total_lead > 0 ? ((customer_count / total_lead) * 100).toFixed(2) :
                            0;
                    })
                });

                colorArray.push(leadColor, customerColor, conversionColor);
            });

            const chartContainer = document.querySelector("#graph_lead_cal_view");
            if (!chartContainer) return;

            chartContainer.innerHTML = "";

            const mixedChartConfig = {
                chart: {
                    type: 'line',
                    stacked: false,
                    height: 500,
                    toolbar: {
                        show: true
                    }
                },
                series: seriesData,
                xaxis: {
                    categories: months,
                    title: {
                        text: 'Months'
                    }
                },
                yaxis: {
                    title: {
                        text: 'Count / Percentage'
                    }
                },
                colors: colorArray,
                legend: {
                    position: 'bottom',
                    horizontalAlign: 'center'
                },
                tooltip: {
                    shared: true,
                    intersect: false
                },
                stroke: {
                    width: [0, 2, 3],
                    curve: 'smooth'
                },
                plotOptions: {
                    bar: {
                        columnWidth: '50%'
                    }
                }
            };

            const chart = new ApexCharts(chartContainer, mixedChartConfig);
            chart.render();
        }
    </script>

    <script>
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
        $(document).ready(function() {
            $(".list_page").DataTable({
                "paging": false,
                "language": {
                    "lengthMenu": "Show _MENU_"
                },
                "dom": "<'row mb-3'" +
                    ">" +
                    "<'table-responsive'tr>" +
                    "<'row'" +
                    "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    ">"
            });
        });

        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
@endsection
