@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
<style>
    .lead_list thead th,
    .lead_list tbody td {
        padding: 7px !important;
    }

    .list_page_1 thead th,
    .list_page_1 tbody td {
        padding: 7px !important;
    }

    .boom-animate {
        animation: boom 0.6s ease-out;
        z-index: 9999;
    }

    @keyframes boom {
        0% {
            transform: scale(0.7);
            opacity: 1;
        }

        /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }
</style>
@php
$helper = new \App\Helpers\Helpers();
$common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
$user_id = auth()->user()->user_id;
$user_data=$helper->get_staff_data($user_id);
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Dead Lead</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body px-4 pb-0 pt-2">
        @php
            $module_name = 'Lead Management';
            $menu_name = 'Manage Dead Lead';
        @endphp
        <div class="row mt-2">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="tab-content p-0">
                        <div class="tab-pane fade show active" id="tab_spam_lead" role="tabpanel">
                            <div class="d-flex align-items-center flex-wrap mb-2">
                                <a href="#" class="text-center border border-2 p-2 me-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Verified Dead Lead">
                                    <div class="text-dark fw-semibold fs-6 mb-1">Verified Dead Lead</div>
                                    <div class="mb-3">
                                        <img src="{{ asset('assets/phdizone_images/lead/user_verify.png') }}"
                                            alt="Verified Dead Lead Icon" class="w-55px h-50px text-black fw-bold">
                                    </div>
                                    <div class="d-block mt-2">
                                        <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ sprintf("%02d",$verified_drop_count) }}</div>
                                    </div>
                                </a>
                                <a href="#" class="text-center border border-2 p-2" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Not Verified Dead Lead">
                                    <div class="text-dark fw-semibold fs-6 mb-1">Not Verify Dead Lead</div>
                                    <div class="mb-3">
                                        <img src="{{ asset('assets/phdizone_images/lead/user_not_verify.png') }}"
                                            alt="Not Verified Dead Lead Icon"
                                            class="w-55px h-50px text-black fw-bold">
                                    </div>
                                    <div class="d-block mt-2">
                                        <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ sprintf("%02d",$not_verified_drop_count) }}</div>
                                    </div>
                                </a>
                            </div>
                            <div class="row">
                                <div class="row mb-2 mt-2">
                                    <div class="col-lg-2">
                                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                        <div>
                                            <span>Show</span>
                                            <br>
                                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                            @php
                                            $options = [10, 25, 100, 500]; // Define available options
                                            @endphp
                                            @php foreach ($options as $option): @endphp
                                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                @php echo $option; @endphp
                                                </option>
                                            @php endforeach; @endphp
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                        <div class="ms-auto">
                                            
                                                <a href="javascript:;" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_bulk_convert_to_lead"
                                                    id="bulkConversionBtn" style="display:none"   onclick="openBulkConvertModal()">
                                                    <span class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2 "><i
                                                            class="mdi mdi-transfer fs-5"></i> Bulk
                                                        Transfer</span>
                                                </a>
                                        </div>
                                        <form id="search_form" method="POST" action="/lead_management/drop_lead">
                                        @csrf
                                        <div class="d-flex align-items-center gap-2">
                                        <div class="">
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input
                                            type="text"
                                            class="form-control"
                                            id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? '' }}" placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                                            />
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                                         <a href="{{ url('/lead_management/drop_lead') }}" type="button"
                                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                                                    </a>
                                        </div>
                                        </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <input type="hidden" id="view_edit_id" />
                                        <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-25px">

                                                            <input class="form-check-input border border-gray-300 me-1"
                                                                type="checkbox" name="all" id="bulk_checkall"
                                                                onchange="showConversionBtn()">

                                                            <span class="fs-7">All</span>
                                                        </th>
                                                    <th class="min-w-100px">Lead</th>
                                                    <th class="min-w-100px">Mobile</th>
                                                    <th class="min-w-80px">Sales Person </th>
                                                    <th class="min-w-100px">Reason / Comments</th>
                                                    <th class="min-w-100px">TL Verification</th>
                                                    <th class="min-w-100px">BH Verification</th>
                                                    <!-- <th class="min-w-100px">Action</th> -->
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                @if (count($leads) > 0)
                                                @foreach ($leads as $i => $category)
                                                @php
                                                   $encryptLeadMobile = $helper->encrypt_decrypt($category->lead_mobile, 'encrypt');
                                                @endphp
                                                <tr>
                                                     <td>

                                                            @php
                                                                $encryptLeadId = $helper->encrypt_decrypt(
                                                                    $category->sno,
                                                                    'encrypt',
                                                                );
                                                            @endphp
                                                            
                                                            <input class="form-check-input bulk_chk 1"
                                                             type="checkbox"
                                                             id="checked<?php echo $i; ?>"
                                                            value="{{ $category->sno }}"
                                                            data-created-by="{{ $category->created_by }}"
                                                            data-staff-name="{{ $category->staff_name }}"
                                                             data-lead-name="{{ $category->lead_name }}"
                                                            onchange="singleShowConversionBtn()">
                                                        </td>
                                                    <td>
                                                        <div class="mb-0 align-items-center">
                                                            <label>                                                               
                                                                <span class="fs-7 me-2">{{ $category->lead_name }}</span>              
                                                            </label>
                                                             <div class="d-block text-black fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Registered Date">{{ date($common_date_format, strtotime($category->registered_date)) }}</div>
                                                            <div class="d-block text-black fs-8" title="{{ $category->lead_email_id }}">{{ $category->lead_email_id }}</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                      <label title="Mobile No"> 
                                                          {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }} {{ $category->status == 1 ? "XXXXXXXXXX" : $category->lead_mobile }}
                                                        </label>
                                                    </td>
                                                    <td>
                                                          @if( $category->status == 8)
                                                          <label  data-bs-toggle="tooltip" data-bs-placement="bottom" title="EAPL">EAPL</label>
                                                          @else
                                                          <label class="text-capitalize" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->nick_name ?? '-'}}">{{ $category->staff_name ?? '-'}}</label>
                                                          @endif
              
                                                        <div class="d-block">
                                                            <label class="badge bg-warning text-black rounded fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">{{ $category->lead_source_name ?? 'Direct Dead Lead' }}</label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="{{ $category->drop_reason ?? " - "  }}">{{ $category->drop_reason ?? " - "  }}</div>
                                                        @if($category->drop_comments)
                                                        <div class="text-truncate max-w-200px text-dark fw-semibold fs-8"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $category->drop_comments ?? " - "  }}">
                                                            [ {{ $category->drop_comments ?? " - "  }} ]
                                                        </div>
                                                        @endif                                                      
                                                    </td>
                                                    <td>
                                                        @if($category->drop_tl_verified == 1)
                                                        <label class="badge bg-success text-white rounded fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->spam_tl_reason }}">
                                                            Approved
                                                        </label>
                                                        @elseif($category->drop_tl_verified != 1)
                                                            @if($user_data->role_id != 12)
                                                            <label class="badge bg-secondary text-white rounded fw-bold fs-8">
                                                                Waiting for Approval
                                                            </label>
                                                            @elseif($user_data->role_id == 12)
                                                                <a href="javascript:;" class="badge bg-info text-white rounded fw-bold fs-8" id=""
                                                                @if($user_data->role_id == 12) data-bs-toggle="dropdown" @endif 
                                                                aria-haspopup="true" aria-expanded="false">
                                                                    Waiting for Approval
                                                                </a> 
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" 
                                                                       class="dropdown-item" 
                                                                       data-bs-toggle="modal" 
                                                                       data-bs-target="#kt_modal_verify_spam"
                                                                       data-id="{{ $category->sno }}"
                                                                       data-name="{{ $category->lead_name }}"
                                                                       data-mobile="{{ $category->lead_mobile }}"
                                                                       data-reason="{{ $category->drop_reason }}"
                                                                       data-val="1"
                                                                       onclick="verifyDropFromData(this)">
                                                                       <span>Verify Drop</span>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_covert_lead" onclick="convertLeadModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->sales_name }}','{{ $category->staff_id }}')"> <span>Convert Lead</span></a>
                                                                </div> 
                                                            @endif
                                                        @endif
                                                      </td>
                                                      <td>
                                                        <div class="d-flex">
                                                        @if($category->drop_verified == 1)
                                                        <label class="badge bg-success text-white rounded fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->drop_bh_reason }}">
                                                            Approved 
                                                        </label>
                                                        @if($user_data->role_id == 9 || $user_data->role_id == 18 || $user_data->role_id == 20 || $user_data->role_id == 21)
                                                        <!--data-bs-toggle="modal" data-bs-target="#kt_modal_verify_spam" onclick="verifyDrop('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}', '{{ $category->drop_reason }}', '2')"-->
                                                            <a href="javascript:;" class="ms-2"  data-bs-toggle="modal" data-bs-target="#kt_modal_dead_to_lead" onclick="dead_to_lead('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}', '{{ $category->drop_reason }}', '{{ $category->drop_tl_reason }}', '{{ $category->drop_bh_reason }}')">
                                                               <i class="mdi mdi-sync fs-4"></i>
                                                            </a>
                                                        @endif
                                                         </div>
                                                        @elseif($category->drop_tl_verified == 1 && $category->drop_verified != 1)
                                                            @if($user_data->role_id == 18 || $user_data->role_id == 20 || $user_data->role_id == 21)
                                                                <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" @if($user_data->role_id == 18 || $user_data->role_id == 20 || $user_data->role_id == 21) data-bs-toggle="dropdown" @endif  aria-haspopup="true" aria-expanded="false">
                                                                    Waiting for Approval
                                                                </a>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" 
                                                                       class="dropdown-item" 
                                                                       data-bs-toggle="modal" 
                                                                       data-bs-target="#kt_modal_verify_spam"
                                                                       data-id="{{ $category->sno }}"
                                                                       data-name="{{ $category->lead_name }}"
                                                                       data-mobile="{{ $category->lead_mobile }}"
                                                                       data-reason="{{ $category->drop_reason }}"
                                                                       data-val="2"
                                                                       onclick="verifyDropFromData(this)">
                                                                       <span>Verify Drop</span>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_covert_lead" onclick="convertLeadModal('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->sales_name }}','{{ $category->staff_id }}')"> <span>Convert Lead</span></a>
                                                                </div>
                                                            @elseif($user_data->role_id != 18 || $user_data->role_id != 20 || $user_data->role_id != 21)
                                                                <label class="badge bg-secondary text-white rounded fw-bold fs-8">
                                                                    Waiting for Approval
                                                                </label>
                                                            @endif
                                                        @elseif($category->drop_verified != 1 && $category->drop_tl_verified != 1)
                                                            <label class="badge bg-secondary text-white rounded fw-bold fs-8">
                                                                Waiting for TL Approval
                                                            </label>
                                                        @endif
                                                      </td>
                                                        <!-- <td>
                                                            <a href="javascript:;" onclick="convertDropToLeadTransfer('{{ $category->sno }}','{{ $category->lead_name }}');" class="btn btn-sm fw-bold btn-label-primary border border-gray-400i fs-7 px-3 py-0" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_drop_to_lead">
                                                                <span class="me-1"><i class="mdi mdi-account-arrow-right fs-3"></i></span>
                                                                Lead Transfer
                                                            </a>
                                                        </td> -->
                                                </tr>
                                                @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-4">
                                    {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                                  </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal -Lead internal_call-->
    <div class="modal fade" id="kt_modal_lead_bank_trans" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Convert to Lead Bank ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead_bank_name"></label>
                </div>
                <form id="lead_bank_reason_form" method="POST" action="{{ url('/submit_lead_bank_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_lead_bank_select" name="reason_lead_bank_select" class="select3 form-select"
                            onchange="toggleInputField_lead_bank(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_lead_bank) && count($reasonList_lead_bank) > 0)
                                @foreach ($reasonList_lead_bank as $bres)
                                <option value="{{ $bres->reason_name }}" data-comments-check="{{ $bres->comments_check }}">{{ $bres->reason_name }}
                                @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_lead_bank_select_err"></div>
                        <div class="mt-4" id="lead_bank_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="lead_bank_reason_text"
                                id="lead_bank_reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="lead_bank_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="lead_bank_comments_text"
                                id="lead_bank_comments_text" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="lead_bank_reason_text_err"></div>
                        <div class="text-danger" id="lead_bank_comments_text_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_lead_bank" id="lead_id_lead_bank">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
<!--end::Modal - Lead internal_call-->



 <!--begin::Modal - verify sapm-->
 <div class="modal fade" id="kt_modal_verify_spam" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Verify Dead Lead - @if(auth()->user()->role_id== 12) Team Lead @elseif(auth()->user()->role_id== 9) Business Head @endif</h3>
                </div>
                <form method="POST" action="{{ route('confirm_drop') }}" autocomplete="off" onsubmit="return validateAndSubmitForm()">
                    @csrf
                    <div class="row">
                        <input type="hidden" name="lead_id" id="lead_id_cus" value="">
                        <div class="col-lg-12 mt-4">
                            <h5 class="text-dark mb-1 fw-semibold text-center">Are you sure want to confirm this lead is Dead Lead?</h5>
                            <div class="text-center">
                                <label class="fw-bold fs-5 text-danger" id="lead-name" ></label>
                                <span class="fw-bold fs-5 text-danger" id="lead-mobile">[]</span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-bold fs-5" ><u>Reason</u> :</label>
                                <span class="fw-bold fs-5" id="lead_drop_reason"></span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-bold fs-5">Verification Reason<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="verify_reason_drop" name="verify_reason_drop" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                                <div class="text-danger" id="verify_reason_drop_err"></div>
                            </div>
                            <input type="hidden" id="verified_by" name="verified_by" value="">
                        </div>
                        <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                            <button type="submit" class="btn btn-primary me-3" >Yes</button>
                            <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Verify Spam-->

<!--begin::Modal - verify sapm-->
 <div class="modal fade" id="kt_modal_dead_to_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Convert Dead Lead to Lead</h3>
                </div>
                <form method="POST" action="{{ route('confirm_drop_lead') }}" autocomplete="off">
                    @csrf
                    <div class="row">
                        <input type="hidden" name="lead_id" id="lead_id_cus_dl" value="">
                        <div class="col-lg-12 mt-4">
                            <h5 class="text-dark mb-1 fw-semibold text-center">Are you sure want to Convert this Dead Lead to Lead ?</h5>
                            <div class="text-center">
                                <label class="fw-bold fs-5 text-danger" id="lead-name_dl" ></label>
                                <span class="fw-bold fs-5 text-danger" id="lead-mobile_dl">[]</span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-semibold fs-5" ><u>Reason</u> :</label><br>
                                <span class="fw-bold fs-6" id="lead_drop_reason_dl"></span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-semibold fs-5" ><u>TL Reason</u> :</label><br>
                                <span class="fw-bold fs-6" id="tllead_drop_reason_dl"></span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-semibold fs-5" ><u>BH Reason</u> :</label><br>
                                <span class="fw-bold fs-6" id="bhlead_drop_reason_dl"></span>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                            <button type="submit" class="btn btn-primary me-3" >Yes,convert</button>
                            <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Verify Spam-->

<!--begin::Modal - Convert lead -->
<div class="modal fade" id="kt_modal_covert_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Convert Lead - @if(auth()->user()->role_id== 12) Team Lead @elseif(auth()->user()->role_id== 9) Business Head @endif</h3>
                    <h5>Lead - [<span class="text-danger" id="covert_lead_name"></span>]</h5>
                </div>
                <form id="convertLeadForm">
                    <div class="row mt-4">
                        <div class="col-lg-12 mb-3">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Before Staff</label>
                        <div class="text-dark mb-1 fs-5 fw-bold" > <span class="text-white badge bg-info" id="old_staff_name"></span></div>
                        <input type="hidden"  name="old_staff_id" id="old_staff_id" />
                    </div>
                        <div class="col-lg-12 mb-3">
                            <input type="hidden" class="form-control" name="covert_lead_id"
                                id="covert_lead_id" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Convert Staff<span class="text-danger">*</span></label>
                            <select id="convert_staff_id" name="convert_staff" class="select3 form-select">
                                <option value="">Select Staff</option>
                            </select>
                            <div class="text-danger" id="convert_staff_id_err"></div>

                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Convert Lead</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Convert lead -->

    <!--begin::Modal - Convert Drop to Lead-->
        <div class="modal fade" id="kt_modal_convert_drop_to_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
            data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-m">
                <!--begin::Modal content-->
                <div class="modal-content rounded p-2">
                    <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                    <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Transfer Dead Lead to Lead ?</div>
                    <div class="text-center mt-2 mb-4">
                        <label class="text-danger fw-bold fs-5 lead_trans_name"></label>
                    </div>
                    <form id="DropLeadForm_Lead" action="{{ route('trans_drop_to_lead') }}" method="POST" novalidate autocomplete="off">
                        @csrf
                        <input type="hidden" id="lead_id_convert_lead" name="lead_id">
                        <div class="container" id="swal2-html-container" style="display: block;">
                            {{-- <div class="row mb-4 align-items-center d-flex justify-content-center" style="display: none !important;">
                                <div class="col-lg-10">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="assg_staff_add_lead" name="assg_staff_add" class="select3 form-select">
                                    </select>
                                    <div class="text-danger" id="assg_staff_add_lead_err"></div>
                                </div>
                            </div> --}}
                            <div class="text-center mt-2">
                                <button type="submit" class="btn btn-sm btn-danger me-3" id="single_convert_btn_lead">Yes, Transfer</button>
                                <button type="reset" class="btn  btn-sm btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                            </div>
                        </div>
                        <br>
                    </form>
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
    <!--end::Modal - Convert Drop to Lead-->


<div class="modal fade" id="kt_modal_bulk_convert_to_lead"
    tabindex="-1"
    aria-hidden="true"
    data-bs-keyboard="false"
    data-bs-backdrop="static">

    <div class="modal-dialog modal-md">
        <div class="modal-content rounded p-4">

            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold m-0">Bulk Convert Dead Leads</h3>

                <button type="button"
                    class="btn btn-sm btn-icon btn-active-color-primary"
                    data-bs-dismiss="modal">
                    ✕
                </button>
            </div>

            <div class="table-responsive">

                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 ">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th>#</th>
                            <th>Lead Name</th>
                            <th>Old Sales Staff</th>
                        </tr>

                    </thead>

                    <tbody id="selected_old_staffs"></tbody>

                </table>

            </div>

            <div class="mb-4">
                <label class="fw-bold mb-2">
                    Convert Staff
                    <span class="text-danger">*</span>
                </label>

                <select id="bulk_assign_staff_conver"
                    class="form-select">

                    <option value="">Select Staff</option>
                </select>

                <div class="text-danger mt-1"
                    id="bulk_assign_staff_conver_err"></div>
            </div>

            <div class="text-center">
                <button type="button"
                    class="btn btn-primary"
                    id="bulk_convert_btn"
                    onclick="bulkConvertLead()">

                    Convert Leads
                </button>

                <button type="button"
                    class="btn btn-secondary"
                    data-bs-dismiss="modal">

                    Cancel
                </button>
            </div>

        </div>
    </div>
</div>
<!-- ------------------------------------------------------------------------------------------------------------------------- -->
<!-- end Bootstrap old Modal for showing messages -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
<script>
    function sort_filter(val) {
        if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
        } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
 <script>
  function LeadbankCalls(id, leadName) {
      $('#kt_modal_lead_bank_trans').modal('show');
      $('#kt_modal_lead_bank_trans .lead_bank_name').text(leadName);

      $('#lead_id_lead_bank').val(id);

      $('#kt_modal_lead_bank_trans .btn-primary').off('click').on('click', function() {
          // Validate the reason selection
          const reason = $('#reason_lead_bank_select').val();
          const otherReason = $('#lead_bank_reason_text').val();
          const comments = $('#lead_bank_comments_text').val();

          if (!reason) {
              $('#reason_lead_bank_select_err').text('Reason is Required');
              return false;
          }else {
              $('#reason_lead_bank_select_err').text('');
          }
          // Check if the selected reason's comments_check is 1 before validating comments
          const selectedReasonOption = $('#reason_lead_bank_select option:selected');
          const commentsCheck = selectedReasonOption.data('comments-check');

          if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
              $('#lead_bank_comments_text_err').text('Comments are required');
              return false;
          }else {
              $('#lead_bank_comments_text_err').text('');
          }

          if (reason == '1' && !otherReason.trim()) {
              $('#lead_bank_reason_text_err').text('Other Reason is required');
              return false;
          }else {
              $('#lead_bank_reason_text_err').text('');
          }
      });
  }
  
    function toggleInputField_lead_bank(value) {
        var internalReasonDiv = document.getElementById('lead_bank_reason_div');
        var internalReasonText = document.getElementById('lead_bank_reason_text');
        var internalCommentsDiv = document.getElementById('lead_bank_comments_div');
        var selectedOption = document.querySelector('#reason_lead_bank_select option:nth-child(' + (document.getElementById('reason_lead_bank_select').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;
        if (value == '1') {
          internalReasonDiv.style.display = 'block';
          internalReasonText.setAttribute('required', 'required');
        } else {
          internalReasonDiv.style.display = 'none';
          internalReasonText.removeAttribute('required');
        }
        
        if (commentsCheck == '1') {
          internalCommentsDiv.style.display = 'block';
        } else {
          internalCommentsDiv.style.display = 'none';
        }
    }
  
</script>
{{-- verified drop --}}
<script>
    function verifyDrop(id, leadName, mobile, reason, val) {
        $('#verify_reason_drop_err').text("");

        document.getElementById('lead_id_cus').value = id;
        document.getElementById('lead-name').innerText = leadName;
        document.getElementById('lead-mobile').innerText = `[${mobile}]`;
        document.getElementById('lead_drop_reason').innerText = reason;
        document.getElementById('verified_by').value = val;
    }
    function verifyDropFromData(el) {
        // Read data attributes from clicked element
        const id = el.getAttribute('data-id');
        const leadName = el.getAttribute('data-name');
        const mobile = el.getAttribute('data-mobile');
        const reason = el.getAttribute('data-reason');
        const val = el.getAttribute('data-val');
    
        // Clear error text
        document.getElementById('verify_reason_drop_err').textContent = "";
    
        // Set values into modal
        document.getElementById('lead_id_cus').value = id;
        document.getElementById('lead-name').innerText = leadName;
        document.getElementById('lead-mobile').innerText = `[${mobile}]`;
        document.getElementById('lead_drop_reason').innerText = reason;
        document.getElementById('verified_by').value = val;
    }
    function dead_to_lead(id, leadName, mobile, reason, reason2, reason3) {
        document.getElementById('lead_id_cus_dl').value = id;
        document.getElementById('lead-name_dl').innerText = leadName;
        document.getElementById('lead-mobile_dl').innerText = `[${mobile}]`;
        document.getElementById('lead_drop_reason_dl').innerText = reason;
        document.getElementById('bhlead_drop_reason_dl').innerText = reason3;
        document.getElementById('tllead_drop_reason_dl').innerText = reason2;
    }
    function validateAndSubmitForm() {
        var verify_tl_reason = document.getElementById('verify_reason_drop').value;
        var err = 0;
        
        if (verify_tl_reason.trim() == "") {
            $('#verify_reason_drop_err').text("Reason is Required..!");
            err++;
        }

        if (err > 0) {
            return false; 
        } else {
            return true;
        }
    }
</script>

{{-- convert drop to lead --}}
<script>
function convertLeadModal(id,lead_name,staff_name,staff_id){
$('#covert_lead_id').val(id)
$('#covert_lead_name').text(lead_name)
$('#old_staff_name').text(staff_name)
$('#old_staff_id').val(staff_id)
if (staff_id) {
    $.ajax({
            url: "{{ route('sales_staff') }}",
            type: "GET",
            success: function(response) {
                const select = document.getElementById('convert_staff_id');
                select.innerHTML = ''; // Clear existing options
        
                // Define and append default options
                const defaultOptions = [
                    { value: '', text: 'Select Assigned Staff' },
                    { value: '0', text: 'Old Staff' }
                ];
        
                defaultOptions.forEach(optData => {
                    const option = document.createElement('option');
                    option.value = optData.value;
                    option.textContent = optData.text;
                    select.appendChild(option);
                });
        
                if (response.status === 200 && Array.isArray(response.data)) {
                    response.data.forEach(staff => {
                        const option = document.createElement('option');
                        option.value = staff.sno;
                        option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                        select.appendChild(option);
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX error:", status, error);
                const select = document.getElementById('convert_staff_id');
                select.innerHTML = '';
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = 'Select Assigned Staff';
                select.appendChild(defaultOption);
            }
        });
     } else {
         $('#convert_staff_id').empty().append(
             '<option value="">Select Staff</option>');
     }
}
</script>
{{-- covert drop to confirm lead --}}
<script>
$(document).ready(function() {
    // Event listener for the form submission
    document.getElementById('convertLeadForm').addEventListener('submit', function(event) {
        event.preventDefault();  // Prevent form submission

        // Clear previous error
        $('#convert_staff_id_err').text("");

        const id = document.getElementById('covert_lead_id').value;
        const staff_id = document.getElementById('old_staff_id').value;
        const convert_staff_id = document.getElementById('convert_staff_id').value;
        
        let err = 0;

        // Validate if convert_staff_id is provided
        if (convert_staff_id === "") {
            $('#convert_staff_id_err').text("Staff is Required..!");
            err++;
        }

        if (err > 0) {
            return false; // Prevent the form submission if there's an error
        } else {
            // Call the function to convert drop to lead
            convertDropToLead(id, convert_staff_id, staff_id);
            return true; // Allow form submission if no errors
        }
    });
});

// Function to convert drop to lead
function convertDropToLead(id, convert_staff_id, staff_id) {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    fetch(`/convert_drop_to_lead/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        body: JSON.stringify({
            convert_staff_id: convert_staff_id,
            old_staff_id: staff_id  // Ensure consistency of the variable name
        }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Failed to convert the lead');
        }
        return response.json();  // Parse the response as JSON
    })
    .then(data => {
        if (data.status === 200) {
            toastr.success('Lead Converted successfully!');
            location.reload();
        } else {
            toastr.error('Lead Failed to Convert!');
        }
    })
    .catch(error => {
        console.error('Error updating category:', error);
        toastr.error('An error occurred: ' + error.message);
    });
}
</script>

<script>
    

    function convertDropToLeadTransfer(leadId,leadName) {

        // $.ajax({
        //     url: "{{ route('sales_staff') }}",
        //     type: "GET",
        //     success: function(response) {
        //         const select = document.getElementById('assg_staff_add_lead');
        //         select.innerHTML = ''; // Clear existing options
        
        //         // Add default options
        //         const defaultOptions = [
        //             { value: '', text: 'Select Assigned Staff' },
        //             // { value: '0', text: 'Old Staff' }
        //         ];
        
        //         defaultOptions.forEach(optData => {
        //             const option = document.createElement('option');
        //             option.value = optData.value;
        //             option.textContent = optData.text;
        //             select.appendChild(option);
        //         });
        
        //         if (response.status === 200 && Array.isArray(response.data)) {
        //             response.data.forEach(staff => {
        //                 const option = document.createElement('option');
        //                 option.value = staff.sno;
        //                 option.textContent = `${staff.staff_name} - ${staff.position_name}`;
        //                 select.appendChild(option);
        //             });
        //         }
        //     },
        //     error: function(xhr, status, error) {
        //         console.error("AJAX error:", status, error);
        //         const select = document.getElementById('assg_staff_add_lead');
        //         select.innerHTML = '';
        //         const defaultOption = document.createElement('option');
        //         defaultOption.value = '';
        //         defaultOption.textContent = 'Select Assigned Staff';
        //         select.appendChild(defaultOption);
        //     }
        // });

        $('#lead_id_convert_lead').val(leadId); 
        $('.lead_trans_name').html(leadName); 
        $('#assg_staff_add_lead_err').text('');

        $('#DropLeadForm_Lead').off('submit').on('submit', function(event) {
            // var assg_staff_add = $('#assg_staff_add_lead').val();

            // if (assg_staff_add === "") { 
            //     event.preventDefault();  
            //     $('#assg_staff_add_lead_err').text('Staff is required...!');
            // } else {
            //     $('#single_convert_btn_lead').prop('disabled', false); 
            //     $('#assg_staff_add_lead_err').text(""); 
            //     $('#kt_modal_convert_drop_to_lead').modal('hide');
            // }

            $('#single_convert_btn_lead').prop('disabled', false); 
            // $('#assg_staff_add_lead_err').text(""); 
            $('#kt_modal_convert_drop_to_lead').modal('hide');
        });
        
        
    }
</script>



    <script>
        $('#bulk_checkall').change(function() {
            $('.bulk_chk').prop('checked', this.checked);
        });

        $('.bulk_chk').change(function() {
            if ($('.bulk_chk:checked').length == $('.bulk_chk').length) {
                $('#bulk_checkall').prop('checked', true);
            } else {
                $('#bulk_checkall').prop('checked', false);
            }
        });

        function showConversionBtn() {

            var bulkCheckAll = document.getElementById('bulk_checkall');

            if (bulkCheckAll.checked) {
                $('#bulkConversionBtn').show();
            } else {
                $('#bulkConversionBtn').hide();
            }

        }

        function singleShowConversionBtn() {
            var checkboxes = document.querySelectorAll('.bulk_chk');
            var isAnyChecked = false;
            checkboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    isAnyChecked = true;
                }
            });

            if (isAnyChecked) {
                $('#bulkConversionBtn').show();
            } else {
                $('#bulkConversionBtn').hide();
            }
        }
    </script>
    <script>
        function openBulkConvertModal() {

    let html = '';

    let count = 1;

    $('.bulk_chk:checked').each(function () {

        let leadName = $(this).data('lead-name');
        let staffName = $(this).data('staff-name');

        html += `
            <tr>
                <td>${count}</td>

                <td>
                    <span class="fw-bold text-dark">
                        ${leadName}
                    </span>
                </td>

                <td>
                    <span class="badge bg-info">
                        ${staffName}
                    </span>
                </td>
            </tr>
        `;

        count++;
    });

    if (html == '') {

        html = `
            <tr>
                <td colspan="3" class="text-center text-danger">
                    No Leads Selected
                </td>
            </tr>
        `;
    }

    $('#selected_old_staffs').html(html);

    // fetch staff list
    $.ajax({

        url: "{{ route('sales_staff') }}",

        type: "GET",

        success: function(response) {

            let select = $('#bulk_assign_staff_conver');

            select.empty();

            select.append(`
                <option value="">
                    Select Staff
                </option>
            `);

            if (response.status == 200) {

                response.data.forEach(function(staff) {

                    select.append(`
                        <option value="${staff.sno}">
                            ${staff.staff_name} - ${staff.position_name}
                        </option>
                    `);

                });
            }
        },

        error: function() {

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Unable to fetch staff list'
            });

        }
    });
}
        function bulkConvertLead() {

            $('#bulk_assign_staff_conver_err').text('');

            let convert_staff_id = $('#bulk_assign_staff_conver').val();

            if (convert_staff_id == '') {

                $('#bulk_assign_staff_conver_err')
                    .text('Staff is required');

                return false;
            }

            let leads = [];

            $('.bulk_chk:checked').each(function () {

                leads.push({
                    lead_id: $(this).val(),
                    old_staff_id: $(this).data('created-by')
                });

            });

            if (leads.length == 0) {

                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Please select at least one lead'
                });

                return false;
            }

            $('#bulk_convert_btn').prop('disabled', true);

            $.ajax({

                url: "{{ route('bulk_convert_drop_to_lead') }}",

                type: "POST",

                data: {
                    _token: "{{ csrf_token() }}",
                    convert_staff_id: convert_staff_id,
                    leads: leads
                },

                success: function(response) {

                    $('#bulk_convert_btn').prop('disabled', false);

                    if (response.status == 200) {

                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: response.message
                        });

                        location.reload();

                    } else {

                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: response.message
                        });
                    }
                },

                error: function(xhr) {

                    $('#bulk_convert_btn').prop('disabled', false);

                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Something went wrong'
                    });
                }
            });
        }
    </script>
@endsection