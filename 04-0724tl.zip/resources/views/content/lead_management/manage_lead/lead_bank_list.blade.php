@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Bank</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                            <div class="scroll-container" id="scrollContainer">
                                @php
                                    $module_name = 'Lead Management';
                                    $menu_name = 'Manage Lead';
                                @endphp
                                @if(auth()->user()->hasPermission($module_name, 'Raw Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                                alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Raw Lead</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalLeadCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Lead Bank', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/lead_bank')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active">
                                            <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                                alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Lead Bank</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadbankCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/manage_lead')}}"
                                            class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                                class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Lead</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadOriginalCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Spam Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        @if($not_verified_spam_count>0)
                                        <a href="{{url('/spam_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                           <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Spam Lead</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_spam_count??0) }}</span>
                                        </a>
                                        @else
                                        <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                           <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2 text-white">Spam Lead</span>
                                        </a>
                                        @endif
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Dead lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        @if($not_verified_drop_count>0)
                                        <a href="{{url('/drop_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Dead Lead</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_drop_count??0) }}</span>
                                        </a>
                                        @else
                                        <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                            <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2 text-white">Dead Lead</span>
                                        </a>
                                        @endif
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Internal Calls Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/internal_calls_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                                alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Internal Calls</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $internal_calls_count??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Today Followup', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/today_followup_lead')}}"
                                            class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                            style="background-color: #FCFF66 !important;">
                                            <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                                alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Today Followup</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalFollowup??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                            </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_lead_bank" role="tabpanel">
                                <div class="d-flex justify-content-between align-items-center flex-wrap my-1">
                                    <div class="text-center border border-gray-500 rounded px-3 py-1">
                                        <div class="text-black fs-6 fw-semibold mb-1">Your Lead Credit <span
                                                class="text-info">( <?php echo date('M-Y'); ?> )</span></div>
                                        <div class="text-dark fs-2 fw-bold mb-1">{{ sprintf('%02d', $leadbankCount??0) }}</div>
                                    </div>
                                    <div  id="bulk_convert_raw_btn" style="display:none;">
                                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_bulk_convert_bank_to_lead">
                                        <span class="me-1"><i class="mdi mdi-transfer fs-5"></i></span> Bulk Conversion
                                    </a>
                                    </div>
                                </div>
                                <div class="row mb-4">
                                    @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                    <div class="col-lg-2">
                                        <span>Show</span>
                                        <br>
                                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                            onchange="sort_filter(this.value);">
                                            @php
                                            $options = [10, 25, 100, 500]; // Define available options
                                            @endphp
                                            @php foreach ($options as $option): @endphp
                                            <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                                                @php echo $option; @endphp
                                            </option>
                                            @php endforeach; @endphp
                                        </select>
                                    </div>
                                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                        <form id="search_form" method="POST" action="/lead_bank">
                                            @csrf
                                            <div class="d-flex align-items-center gap-2 mt-2">
                                                <div>
                                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                    <input type="hidden" name="filter_on" value="1">
                                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                                        value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                    <input type="text" class="form-control" id="lead_grp_fill" name="lead_grp_fill"
                                                        value="{{ $lead_grp_fill ?? "" }}" placeholder="Enter Lead - Name/ Date/ Lead group" />
                                                </div>
                                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                                    onclick="search_filter_func()">Search</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <input type="hidden" id="view_edit_id" />
                                        <form id="bulk_request_pay_form" method="POST">
                                            @csrf
                                            <input type="hidden" name="bulk_lead_source_id" id="bulk_lead_source_id">
                                            <input type="hidden" name="bulk_assign_staff_id" id="bulk_assign_staff_id">
                                            <table
                                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                                <thead>
                                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                        <!--@ if(auth()->user()->role_id!=11) -->
                                                        <!--<th data-sortable="false" class="min-w-80px">-->
                                                        <!--    <input class="form-check-input me-1" type="checkbox" name="all"-->
                                                        <!--        id="bulk_checkall">-->
                                                        <!--    <span class="fs-7">All</span>-->
                                                        <!--</th>-->
                                                        <!-- @ endif-->
                                                        <th data-sortable="true" class="min-w-100px">Lead</th>
                                                        <th data-sortable="false" class="min-w-100px">Mobile</th>
                                                        <th data-sortable="false" class="min-w-80px">Source</th>
                                                        <th data-sortable="false" class="min-w-80px">Lead Group</th>
                                                        <th data-sortable="false" class="min-w-80px">Reason / Comments</th>
                                                        @if($staff_check->lead_bank_count > 0)
                                                        <th data-sortable="false" class="min-w-80px">Action</th>
                                                        @endif
                                                    </tr>
                                                </thead>
                                                <tbody class="text-gray-600 fw-semibold fs-7">
                                                    @if (count($rawLeads) > 0)
                                                    @foreach ($rawLeads as $i=> $category)
                                                    <tr>
                                                        <!-- @ if(auth()->user()->role_id!=11) -->
                                                        <!--<td>-->
                                                        <!--    <input class="form-check-input bulk_chk" type="checkbox"-->
                                                        <!--        id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]"-->
                                                        <!--        value="{{ $category->sno }}">-->
                                                        <!--</td>-->
                                                        <!-- @ endif-->
                                                        <td>
                                                            <div class="mb-0 align-items-center">
                                                                <label>
                                                                    <span class="fs-7 me-2">{{ $category->lead_name }}</span>
                                                                    <div class="d-block text-primary fs-8" title="Registered Date">{{
                                                                        isset($category->registered_date) ? date($common_date_format,
                                                                        strtotime($category->registered_date)) :''}}</div>
                                                                </label>
                    
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label title="Mobile No">{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}</label>
                                                        </td>
                                                        
                                                        <td>
                                                            <div>
                                                                    <span class="fs-7 me-2">@if($category->lead_type == 0 ) Raw Lead @else Lead @endif</span>
                                                            </div>
                                                            <div class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="Lead Source">{{ $category->lead_source_name }}</div>
                                                        </td>
                                                        <td>
                                                            <label title="Lead Type">{{ $category->lead_group ?? '-'}}</label>
                                                        </td>
                                                        <td>
                                                            <div class="text-truncate max-w-200px text-black fw-semibold fs-7"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="{{ $category->transfer_reason ?? " - "  }}">{{ $category->transfer_reason ?? " - "  }}</div>
                                                            @if($category->transfer_comment)
                                                            <div class="text-truncate max-w-200px text-dark fw-semibold fs-8"
                                                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->transfer_comment ?? " - "  }}">
                                                                [ {{ $category->transfer_comment ?? " - "  }} ]
                                                            </div>
                                                            @endif  
                                                        </td>
                                                        @if($staff_check->lead_bank_count > 0)
                                                            <td>
                                                                <span class="text-end">
                                                                    @if($category->lead_type == 0) 
                                                                    <a href="javascript:;" onclick="bulk_request_single_lead('{{ $category->lead_id }}');" class="btn btn-sm fw-bold btn-label-primary border border-gray-400i fs-7 px-3 py-0" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_raw_to_lead">
                                                                        <span class="me-1"><i class="mdi mdi-account-arrow-right fs-3"></i></span>
                                                                        Lead Transfer
                                                                    </a>
                                                                    @else
                                                                        <a href="javascript:;" onclick="bulk_request_single_lead_to_lead('{{ $category->lead_id }}');" class="btn btn-sm fw-bold btn-label-primary border border-gray-400i fs-7 px-3 py-0" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_raw_to_lead_to_lead">
                                                                            <span class="me-1"><i class="mdi mdi-account-arrow-right fs-3"></i></span>
                                                                            Lead Transfer
                                                                        </a>
                                                                    @endif
                                                                </span>
                                                            </td>
                                                        @endif
                                                    </tr>
                                                    @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                    <div class="mt-4">
                                        {{ $rawLeads->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    <!--begin::Modal - Edit Lead-->
    <div class="modal fade" id="kt_modal_edit_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl" id="editModal">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                    fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Credit</h3>
                    </div>
                    <form id="leadEditForm" action="{{ route('convert_bank_to_lead') }}" method="POST" novalidate
                        autocomplete="off">
                        @csrf
                        <input type="hidden" id="lead_id_edit" name="lead_id">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_name_edit" name="lead_name"
                                    placeholder="Enter Lead Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                                <div class="text-danger" id="lead_name_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold d-block">Gender<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio1edit"
                                        value="1" checked />
                                    <label class="form-check-label" for="inlineRadio1edit">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio2edit"
                                        value="2" />
                                    <label class="form-check-label" for="inlineRadio2edit">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio3edit"
                                        value="3" />
                                    <label class="form-check-label" for="inlineRadio3edit">Others</label>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Date of Birth<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_dob_up" name="lead_dob" placeholder="Select Date"
                                        class="form-control" />
                                </div>
                                <div class="text-danger" id="lead_dob_up_err"></div>
                            </div>
                            {{-- <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_mobile_edit" name="lead_mobile"
                                    placeholder="Enter Mobile Number" value="" maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                                <div class="text-danger" id="lead_mobile_edit_err"></div>
                            </div> --}}
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span
                                        class="text-danger">*</span></label>
                                <div class="input-group">
                                    <button class="btn btn-outline-primary dropdown-toggle waves-effect" type="button"
                                        data-bs-toggle="dropdown" aria-expanded="false" id="countryDropdownButton_edit"
                                        name="countryDropdownButton">Phn Code</button>
                                    <ul class="dropdown-menu" id="countryDropdownMenu_edit" name="countryDropdownMenu"
                                        style="max-height: 250px; overflow-y: auto; position: relative;">
                                        <li>
                                            <input type="text" id="countrySearch_edit" name="countrySearch"
                                                class="form-control border-1" placeholder="Search Country/Code"
                                                style="width: 100%; border: none; padding: 5px;">
                                        </li>
                                    </ul>
                                    <input type="text" class="form-control" id="lead_mobile_edit" name="lead_mobile"
                                        maxlength="10" placeholder="Enter Mobile Number"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                                    <input type="hidden" id="country_code_name_edit" name="country_code_name_edit" value="">
                                </div>
                                <div class="text-danger" id="lead_mobile_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                                <input type="text" class="form-control me-2" id="lead_alternate_edit"
                                    placeholder="Enter Alternate Mobile Number" name="lead_alternate_mobile" maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Marital Status</label>
                                <select id="lead_marital_edit" name="lead_marital_status"
                                    class="select3 form-select selectoption">
                                    <option value="">Select Marital Status</option>
                                    <option value="1">Married</option>
                                    <option value="2">Un Married</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Email ID</label>
                                <input type="text" class="form-control" name="lead_email_id" id="lead_email_edit"
                                    placeholder="Enter E-Mail ID" oninput=" this.value = this.value.toLowerCase();" />
                                <div class="text-danger" id="lead_email_edit_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Country</label>
                                <select id="country_id_edit" name="country_edit" class="select3 form-select selectoption">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="text-danger" id="country_id_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">State</label>
                                <select id="state_edit" name="state_edit" class="select3 form-select selectoption">
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="state_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">City</label>
                                <select id="city_edit" name="city_edit" class="select3 form-select selectoption">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="city_edit_err"></div>
                            </div>

                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Area / Street</label>
                                <input type="text" class="form-control me-2" id="lead_address_edit" name="address"
                                    placeholder="Enter Area / Street" />
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Type</label>
                                <select id="lead_type_edit" name="lead_type_id_edit"
                                    class="select3 form-select selectoption">


                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source<span
                                        class="text-danger">*</span></label>
                                <select id="lead_source_edit" name="lead_source_id_edit"
                                    class="select3 form-select selectoption">

                                </select>
                                <div class="text-danger" id="lead_source_edit_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Comments</label>
                                <textarea class="form-control" rows="1" id="comments_edit" name="lead_comments"
                                    placeholder="Enter Comments"></textarea>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Course Name<span
                                        class="text-danger">*</span></label>
                                <select id="lead_course_edit" name="course_id_edit[]"
                                    class="select3 form-select selectoption" multiple>


                                </select>
                                <div class="text-danger" id="lead_course_edit_err"></div>
                            </div>
                            <div class="row mt-4">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Knowledge Tag<span
                                        class="text-danger">*</span></label>
                                <div class="form-floating form-floating-outline">
                                    <input id="lead_Knowledge_edit_tag" name="lead_Knowledge_edit_tag"
                                        class="form-control h-auto selectoption" placeholder="Select Knowledge Tags"
                                        value="">
                                </div>
                                <div class="text-danger" id="lead_Knowledge_edit_tag_err"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_lead_edit"
                                onclick="EditvalidateForm()">Update Lead</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit Lead-->

    <!--begin::Modal - Bulk Convert Raw Lead-->
    <div class="modal fade" id="kt_modal_bulk_convert_bank_to_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                <h3 class="my-4 text-center  fw-bold ">Bulk Lead Transfer</h3>
                <div class="container" id="swal2-html-container" style="display: block;">
                    <div class="mb-4 fw-bold fs-6">
                        <span id="bulk_convert_message"></span>
                    </div>
                    <div class="row mb-4 align-items-center d-flex justify-content-center">
                        <div class="col-lg-10">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select id="bulk_assign_staff_conver" name="bulk_assign_staff_conver"
                                class="select3 form-select">
                            </select>
                            <div class="text-danger" id="bulk_assign_staff_conver_err"></div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="button" id="bulk_convert_btn" class="btn btn-sm btn-danger me-3" onclick="bulk_request_pay();">Yes, Transfer</button>
                        <button type="reset" class="btn btn-sm btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                    </div>

                </div><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Bulk Convert Raw Lead-->   
    <!--begin::Modal - Convert Raw Lead-->
    <div class="modal fade" id="kt_modal_convert_raw_to_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                <h3 class="my-4 text-center fs-4 fw-bold text-danger">Lead Transfer</h3>
                <form id="convertLeadForm" action="{{ route('bank_lead') }}" method="POST" novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_convert" name="lead_id">
                    <div class="container" id="swal2-html-container" style="display: block;">
                        <div class="row mb-4 align-items-center d-flex justify-content-center">
                            <div class="col-lg-10">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                        class="text-danger">*</span></label>
                                <select id="assg_staff_add" name="assg_staff_add" class="select3 form-select">
                                </select>
                                <div class="text-danger" id="assg_staff_add_err"></div>
                            </div>
                        </div>
                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-sm btn-danger me-3" id="single_convert_btn">Yes, Transfer</button>
                            <button type="reset" class="btn  btn-sm btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                        </div>
                    </div><br>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Raw Lead-->
    
    <!--begin::Modal - Convert Raw Lead-->
    <div class="modal fade" id="kt_modal_convert_raw_to_lead_to_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                <h3 class="my-4 text-center fs-4 fw-bold text-danger">Lead Transfer</h3>
                <form id="convertLeadForm_Lead" action="{{ route('bank_lead_to_lead') }}" method="POST" novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_convert_lead" name="lead_id">
                    <div class="container" id="swal2-html-container" style="display: block;">
                        <div class="row mb-4 align-items-center d-flex justify-content-center">
                            <div class="col-lg-10">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                        class="text-danger">*</span></label>
                                <select id="assg_staff_add_lead" name="assg_staff_add" class="select3 form-select">
                                </select>
                                <div class="text-danger" id="assg_staff_add_lead_err"></div>
                            </div>
                        </div>
                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-sm btn-danger me-3" id="single_convert_btn_lead">Yes, Transfer</button>
                            <button type="reset" class="btn  btn-sm btn-secondary" data-bs-dismiss="modal">No, cancel</button>
                        </div>
                    </div><br>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Raw Lead-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <style>
        /* Blinking text animation */
        .blink {
            animation: blinker 1.5s linear infinite;
            /* font-weight: bold; */
            color: white;
            /* White text for better contrast */
        }
    
        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }
    
        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9;
            /* Soft pink color */
            padding: 4px 8px;
            border-radius: 12px;
            /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            /* Soft shadow for depth */
            font-size: 0.3rem;
            /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }
    
        /* Adding a cute icon or star effect */
        .new-label::before {
            content: '✨';
            /* You can replace this with any icon or emoji */
            position: absolute;
            top: -8px;
            right: -10px;
            /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }
    
    
        /* Bounce animation for cute effect */
        @keyframes bounce {
    
            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }
    
            40% {
                transform: translateY(-8px);
            }
    
            60% {
                transform: translateY(-4px);
            }
        }
    </style>
    <style>
        #modalMessageContent {
            font-size: 1.2rem;
            /* Make font larger */
            padding: 10px;
            /* Add padding */
            border-radius: 5px;
            /* Rounded corners */
        }
    
        /* Example styles for success, warning, and error */
        .text-successs {
            background-color: #d4edda;
            color: #155724;
        }
    
        .text-dangers {
            background-color: #f8d7da;
            color: #721c24;
        }
    
        .text-warnings {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }
    
        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    
        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important;
            /* Ensure it is higher than the modal's z-index */
        }
    </style>
    
    <script>
        $(document).ready(function() {
            $.ajax({
                url: "{{ route('sales_staff') }}",
                type: "GET",
                success: function(response) {
                    const select = document.getElementById('assg_staff_add');
                    select.innerHTML = ''; // Clear existing options
            
                    // Add default options
                    const defaultOptions = [
                        { value: '', text: 'Select Assigned Staff' },
                        { value: '0', text: 'Old Staff' }
                    ];
            
                    defaultOptions.forEach(optData => {
                        const option = document.createElement('option');
                        option.value = optData.value;
                        option.textContent = optData.text;
                        select.appendChild(option);
                    });
            
                    if (response.status === 200 && Array.isArray(response.data)) {
                        response.data.forEach(staff => {
                            const option = document.createElement('option');
                            option.value = staff.sno;
                            option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                            select.appendChild(option);
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    const select = document.getElementById('assg_staff_add');
                    select.innerHTML = '';
                    const defaultOption = document.createElement('option');
                    defaultOption.value = '';
                    defaultOption.textContent = 'Select Assigned Staff';
                    select.appendChild(defaultOption);
                }
            });

            // bulk assign staff
           $.ajax({
                url: "{{ route('sales_staff') }}",
                type: "GET",
                success: function(response) {
                    const select = document.getElementById('bulk_assign_staff_conver');
                    select.innerHTML = ''; // Clear existing options
            
                    // Define and append default options
                    const defaultOptions = [
                        { value: '', text: 'Select Assigned Staff' },
                        { value: '0', text: 'Old Staff' }
                    ];
            
                    defaultOptions.forEach(optData => {
                        const option = document.createElement('option');
                        option.value = optData.value;
                        option.textContent = optData.text;
                        select.appendChild(option);
                    });
            
                    if (response.status === 200 && Array.isArray(response.data)) {
                        response.data.forEach(staff => {
                            const option = document.createElement('option');
                            option.value = staff.sno;
                            option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                            select.appendChild(option);
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    const select = document.getElementById('bulk_assign_staff_conver');
                    select.innerHTML = '';
                    const defaultOption = document.createElement('option');
                    defaultOption.value = '';
                    defaultOption.textContent = 'Select Assigned Staff';
                    select.appendChild(defaultOption);
                }
            });
               
        });
        $(document).ready(function() {
            $.ajax({
                url: "{{ route('sales_staff') }}",
                type: "GET",
                success: function(response) {
                    const select = document.getElementById('assg_staff_add_lead');
                    select.innerHTML = ''; // Clear existing options
            
                    // Add default options
                    const defaultOptions = [
                        { value: '', text: 'Select Assigned Staff' },
                        { value: '0', text: 'Old Staff' }
                    ];
            
                    defaultOptions.forEach(optData => {
                        const option = document.createElement('option');
                        option.value = optData.value;
                        option.textContent = optData.text;
                        select.appendChild(option);
                    });
            
                    if (response.status === 200 && Array.isArray(response.data)) {
                        response.data.forEach(staff => {
                            const option = document.createElement('option');
                            option.value = staff.sno;
                            option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                            select.appendChild(option);
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    const select = document.getElementById('assg_staff_add');
                    select.innerHTML = '';
                    const defaultOption = document.createElement('option');
                    defaultOption.value = '';
                    defaultOption.textContent = 'Select Assigned Staff';
                    select.appendChild(defaultOption);
                }
            });
        });
    </script>
    <script>
        // Display Toastr messages
          @if(Session::has('toastr'))
          var type = "{{ Session::get('toastr')['type'] }}";
          var message = "{{ Session::get('toastr')['message'] }}";
          toastr[type](message);
          @endif
    </script>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: "{{ route('sales_staff') }}",
                type: "GET",
                success: function(response) {
                    const select = document.getElementById('assg_staff_add');
                    select.innerHTML = ''; // Clear existing options
            
                    // Add default options
                    const defaultOptions = [
                        { value: '', text: 'Select Assigned Staff' },
                        { value: '0', text: 'Old Staff' }
                    ];
            
                    defaultOptions.forEach(optData => {
                        const option = document.createElement('option');
                        option.value = optData.value;
                        option.textContent = optData.text;
                        select.appendChild(option);
                    });
            
                    if (response.status === 200 && Array.isArray(response.data)) {
                        response.data.forEach(staff => {
                            const option = document.createElement('option');
                            option.value = staff.sno;
                            option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                            select.appendChild(option);
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", status, error);
                    const select = document.getElementById('assg_staff_add');
                    select.innerHTML = '';
                    const defaultOption = document.createElement('option');
                    defaultOption.value = '';
                    defaultOption.textContent = 'Select Assigned Staff';
                    select.appendChild(defaultOption);
                }
            });

            // bulk assign staff
           $.ajax({
            url: "{{ route('sales_staff') }}",
            type: "GET",
            success: function(response) {
                const select = document.getElementById('bulk_assign_staff_conver');
                select.innerHTML = ''; // Clear existing options
        
                // Define and append default options
                const defaultOptions = [
                    { value: '', text: 'Select Assigned Staff' },
                    { value: '0', text: 'Old Staff' }
                ];
        
                defaultOptions.forEach(optData => {
                    const option = document.createElement('option');
                    option.value = optData.value;
                    option.textContent = optData.text;
                    select.appendChild(option);
                });
        
                if (response.status === 200 && Array.isArray(response.data)) {
                    response.data.forEach(staff => {
                        const option = document.createElement('option');
                        option.value = staff.sno;
                        option.textContent = `${staff.staff_name} - ${staff.position_name}`;
                        select.appendChild(option);
                    });
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX error:", status, error);
                const select = document.getElementById('bulk_assign_staff_conver');
                select.innerHTML = '';
                const defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = 'Select Assigned Staff';
                select.appendChild(defaultOption);
            }
        });
            });
    </script>
    <script>
        $('#bulk_checkall').change(function () {
                $('.bulk_chk').prop('checked', this.checked);
                    // Show button if at least one checkbox is checked
                    if ($('.bulk_chk:checked').length > 0) {
                        $('#bulk_convert_raw_btn').show();
                    } else {
                        $('#bulk_convert_raw_btn').hide();
                    }
                });
    
                $('.bulk_chk').change(function () {
                    // Show button if at least one checkbox is checked
                    if ($('.bulk_chk:checked').length > 0) {
                        $('#bulk_convert_raw_btn').show();
                    } else {
                        $('#bulk_convert_raw_btn').hide();
                    }
    
                    // Update the "select all" checkbox based on individual checkboxes
                    if ($('.bulk_chk:checked').length == $('.bulk_chk').length) {
                        $('#bulk_checkall').prop('checked', true);
                    } else {
                        $('#bulk_checkall').prop('checked', false);
                    }
                });
                // function bulk_lead_sourx
                // function bulk_lead_sourx
                function bulk_request_pay() {
        
                  $('#bulk_convert_btn').prop('disabled', true);
        
                  var bulk_assign_staff_conver=$('#bulk_assign_staff_conver').val();
        
                  $('#bulk_assign_staff_id').val(bulk_assign_staff_conver);
        
                  var bulk_assign_staff_hidden=$('#bulk_assign_staff_id').val();
        
        
                  if ($('.bulk_chk:checked').length>0){
                    if(bulk_assign_staff_hidden == ""){
                      $('#bulk_convert_btn').prop('disabled', false);
                      document.getElementById('bulk_assign_staff_conver_err').innerHTML = 'Staff is required...!';
        
                    }
                    else{
                      $('#bulk_convert_btn').prop('disabled', true);
                      $('#bulk_request_pay_form').attr('action', "{{ route('bulk_bank_lead') }}");
                      $("#bulk_request_pay_form").submit();
                      e.preventDefault();
                    }
                  }else{
                    // $('#bulk_convert_btn').prop('disabled', false);
                    Swal.fire({
                        title: 'Error!',
                        text:  'Please Check Any one of the checkbox...',
                        icon:  'error',
                        customClass: {
                                    confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                    $('#kt_modal_bulk_convert_bank_to_lead').modal('hide');
                    
                  }
                  $('#bulk_convert_btn').prop('disabled', false);
        
                }
    </script>
    
    <script>
        function bulk_request_single_lead(leadId) {
            $('#lead_id_convert').val(leadId); 
    
            $('#single_convert_btn').prop('disabled', false); 
    
            $('#assg_staff_add_err').text('');
    
            $('#convertLeadForm').off('submit').on('submit', function(event) {
                var assg_staff_add = $('#assg_staff_add').val();
    
                if (assg_staff_add === "") { 
                    event.preventDefault();  
                    $('#assg_staff_add_err').text('Staff is required...!');
                } else {
                    $('#assg_staff_add_err').text(""); 
                    $('#kt_modal_convert_raw_to_lead').modal('hide');
                }
            });
        }
        function bulk_request_single_lead_to_lead(leadId) {
            $('#lead_id_convert_lead').val(leadId); 
    
           
    
            $('#assg_staff_add_lead_err').text('');
    
            $('#convertLeadForm_Lead').off('submit').on('submit', function(event) {
                var assg_staff_add = $('#assg_staff_add_lead').val();
    
                if (assg_staff_add === "") { 
                    event.preventDefault();  
                    $('#assg_staff_add_lead_err').text('Staff is required...!');
                } else {
                     $('#single_convert_btn_lead').prop('disabled', false); 
                    $('#assg_staff_add_lead_err').text(""); 
                    $('#kt_modal_convert_raw_to_lead_to_lead').modal('hide');
                }
            });
        }
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
    
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
