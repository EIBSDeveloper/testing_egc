@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
    @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Internal Calls</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            @php
                                $module_name = 'Lead Management';
                                $menu_name = 'Manage Lead';
                            @endphp
                            @if(auth()->user()->hasPermission($module_name, 'Raw Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                            alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Raw Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalLeadCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Lead Bank', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/lead_bank')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                            alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead Bank</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadbankCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/manage_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                            class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadOriginalCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Spam Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_spam_count>0)
                                    <a href="{{url('/spam_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Spam Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_spam_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Spam Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Dead lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_drop_count>0)
                                    <a href="{{url('/drop_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Dead Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_drop_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Dead Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Internal Calls Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/internal_calls_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active">
                                        <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                            alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Internal Calls</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $internal_calls_count??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Today Followup', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/today_followup_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        style="background-color: #FCFF66 !important;">
                                        <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                            alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Today Followup</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalFollowup??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_internal_calls" role="tabpanel">
                                <div class="row">
                                    <div class="row mb-4">
                                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                        <div class="col-lg-2">
                                            <span>Show</span>
                                            <br>
                                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                                @php
                                                $options = [10, 25, 100, 500]; // Define available options
                                                @endphp
                                                @php foreach ($options as $option): @endphp
                                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                    @php echo $option; @endphp
                                                </option>
                                                @php endforeach; @endphp
                                            </select>
                                        </div>
                                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                            <form id="search_form" method="POST" action="/internal_calls_lead">
                                                @csrf
                                              <div class="d-flex align-items-center gap-2 mt-2">
                                                <div>
                                                  <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                  <input type="hidden" name="filter_on" value="1">
                                                  <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                  <input
                                                    type="text"
                                                    class="form-control"
                                                    id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                                    placeholder="Enter Lead - Name/ Date/ Lead group"
                                                  />
                                                </div>
                                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                                              </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <input type="hidden" id="view_edit_id" />
                                            <table
                                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                                <thead>
                                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                        <th class="min-w-100px">Lead</th>
                                                        <th class="min-w-100px">Mobile / L.F.D</th>
                                                        <th class="min-w-80px">Sales Person </th>
                                                        <th class="min-w-100px">Reason / Comments</th>
                                                        <th class="min-w-100px">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="text-gray-600 fw-semibold fs-7">
                                                    @if (count($leads) > 0)
                                                    @foreach ($leads as $category)
                
                                                    <tr style="background-color: {{ $category->lead_bg_color }};">
                                                        <td>
                                                            <div class="mb-0 align-items-center">
                                                                <label>
                                                                    @if( $category->lead_appointment_status == 1)
                                                                    <i class="animation-blink mdi mdi-phone-clock text-danger fs-4"
                                                                        title="Appointment"></i>
                                                                    @endif
                                                                    <span class="fs-7 me-2">{{ $category->lead_name }}</span>
                                                                    @if( $category->lead_gender == 1)
                                                                    <span><i class="mdi mdi-face-man text-info"></i></span>
                                                                    @elseif( $category->lead_gender == 2)
                                                                    <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                                                    @elseif( $category->lead_gender == 3)
                
                                                                    @endif
                                                                    @if ($category->lead_dob == date('Y-m-d'))
                                                                    <span><i
                                                                            class="mdi mdi-cake-variant-outline animation-blink text-black fs-4"></i></span>
                                                                    @endif
                
                                                                </label>
                                                                <div class="d-block text-black fs-8" title="Registered date">{{
                                                                    isset($category->registered_date) ? date($common_date_format,strtotime($category->registered_date)) :''}}</div>
                                                                <div class="d-block text-black fs-8" title="{{ $category->lead_email_id }}">{{ $category->lead_email_id}}</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label title="Mobile No"> 
                                                                {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }} {{ $category->status == 1 ? "XXXXXXXXXX" : $category->lead_mobile }}
                                                            </label>
                                                        </td>
                                                        <td>
                                                            @if( $category->status == 8)
                                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="EAPL">EAPL</label>
                                                            @else
                                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->nick_name ?? 'Old Staff'}}">{{ $category->staff_name??'Old Staff'}}</label>
                
                                                            @endif
                                                            <div class="d-block">
                                                                <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">{{ $category->lead_source_name }}</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label class="text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->internal_reason }}">{{ $category->internal_reason }}</label>
                                                            <div class="d-block">
                                                                [ <label title="{{ $category->internal_comments }}" data-bs-toggle="tooltip" data-bs-placement="bottom">{{ $category->internal_comments }}</label> ]
                                                            </div>
                                                        </td>
                                                        <td>
                                                            @if($category->internal_status == 1 && $category->internal_verify == 0)
                                                            <a href="javascript:;" class="badge bg-secondary text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                Waiting for Approval
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-end">
                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_internal" 
                                                                onclick="approveInternals('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->lead_mobile }}', '{{ $category->internal_reason }}')">Approve</a>
                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_reject_internal" 
                                                                onclick="rejectInternals('{{ $category->sno }}','{{ $category->lead_name }}','{{ $category->nick_name }}','{{ $category->staff_id }}')">Reject</a>
                                                            </div>
                                                            @elseif($category->internal_verify == 1)
                                                            <label class="badge bg-success text-white rounded fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->internal_veri_reason }}">
                                                                Approved
                                                            </label>
                                                            <a href="javascript:;" class="fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->internal_veri_reason }}">
                                                                <i class="mdi mdi-information-slab-circle text-dark"></i>
                                                            </a>
                                                            @elseif($category->internal_verify == 2)
                                                            <label class="badge bg-danger text-white rounded fw-bold fs-8">
                                                                Rejected
                                                            </label>
                                                            <a href="javascript:;" class="fw-semibold fs-7"
                                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->internal_reject_reason }}">
                                                                <i class="mdi mdi-information-slab-circle text-dark"></i>
                                                            </a>
                                                            @endif
                                                        </td>
                                                    </tr>
                                                    @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="mt-4">
                                            {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--begin::Modal - Approve Internal Calls-->
    <div class="modal fade" id="kt_modal_approve_internal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Approve Internal Calls</h3>
                    </div>
                    <form method="POST" action="{{ route('confirm_internal_calls') }}" autocomplete="off" onsubmit="return validateAndSubmitForm()">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="lead_id" id="lead_id_cus" value="">
                            <div class="col-lg-12 mt-4">
                                <h5 class="text-dark mb-1 fw-semibold text-center">Are you sure want to approve this lead as Internal Call?</h5>
                                <div class="text-center">
                                    <label class="fw-bold fs-5 text-danger" id="lead-name"></label>
                                    <span class="fw-bold fs-5 text-danger" id="lead-mobile">[]</span>
                                </div>
                                <div class="d-block mt-2">
                                    <label class="fw-bold fs-5"><u>Reason</u> :</label>
                                    <span class="fw-bold fs-5" id="lead_spam_reason"></span>
                                </div>
                                <div class="d-block mt-2">
                                    <label class="fw-bold fs-5">Verification Reason<span class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="1" id="verify_reason_spam" name="verify_reason_spam" placeholder="Enter Reason"></textarea>
                                    <div class="text-danger" id="verify_reason_spam_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                <button type="submit" class="btn btn-primary me-3">Yes</button>
                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>                                     
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Approve Internal Calls-->

    
    <!--begin::Modal - Reject Internal Calls -->
    <div class="modal fade" id="kt_modal_reject_internal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Reject Internal Calls</h3>
                        <h5>Lead - [<span class="text-danger" id="covert_lead_name"></span>]</h5>
                    </div>
                    <form id="convertLeadForm">
                        <div class="row mt-4">
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Sales Staff&nbsp;&nbsp;:</label>
                                <span class="text-white badge bg-info fs-7" id="old_staff_name"></span>
                            </div>
                            <div class="d-block mt-2">
                                <label class="fw-bold fs-5">Rejected Reason<span class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="reject_reason_spam" name="reject_reason_spam" placeholder="Enter Reason"></textarea>
                                <div class="text-danger" id="reject_reason_spam_err"></div>
                            </div>
                            <input type="hidden"  name="old_staff_id" id="old_staff_id" />
                            <input type="hidden" class="form-control" name="covert_lead_id"
                                id="covert_lead_id" />
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Reject</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Internal Calls -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
        function populateStatusModal(id){
          $('#lead_status_id').val(id)
        }
    </script>

    <script>
        function approveInternals(id, leadName, mobile, reason, val) {
            
            $('#verify_reason_spam_err').text("");
            
            // Set values on the form inputs
            document.getElementById('lead_id_cus').value = id;
            document.getElementById('lead-name').innerText = leadName;
            document.getElementById('lead-mobile').innerText = `[${mobile}]`;
            document.getElementById('lead_spam_reason').innerText = reason;
        }

        function validateAndSubmitForm() {
            var verify_tl_reason = document.getElementById('verify_reason_spam').value;
            var err = 0;
            
            // Trim the input to prevent spaces from being counted as valid input
            if (verify_tl_reason.trim() == "") {
                $('#verify_reason_spam_err').text("Reason is Required..!");
                err++;
            }

            if (err > 0) {
                return false; // Prevent form submission if validation fails
            } else {
                return true; // Allow form submission if validation passes
            }
        }
    </script>

    <script>
        function rejectInternals(id,lead_name,staff_name='Old Staff',staff_id){
            $('#covert_lead_id').val(id)
            $('#covert_lead_name').text(lead_name)
            $('#old_staff_name').text(staff_name||'Old Staff')
            $('#old_staff_id').val(staff_id)
        }

        $(document).ready(function() {
            // Now this function is already defined, so we can safely add the event listener
            document.getElementById('convertLeadForm').addEventListener('submit', function(event) {
                event.preventDefault();
                $('#reject_reason_spam_err').text("");
                const id = document.getElementById('covert_lead_id').value;
                const staff_id = document.getElementById('old_staff_id').value;
                const reject_reason_spam = document.getElementById('reject_reason_spam').value;
                var err=0;
                if(reject_reason_spam==""){
                    $('#reject_reason_spam_err').text("Reason is Required..!");
                    err++;
                }
                if(err>0){
                    return false;
                }else{
                    convertSpamToLead(id,reject_reason_spam, staff_id);

                    return true;
                }
            });
        });

        function convertSpamToLead(id,reject_reason_spam, staff_id) {
            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            fetch(`/convert_internal_to_leads/${id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                    old_staff_id: staff_id, 
                    reject_reason_spam: reject_reason_spam  
                }),
            })
            .then(response => response.json())  // Ensure you parse the JSON response
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Lead Converted successfully!');
                    location.reload();
                } else {
                    toastr.error('Lead Failed to Convert!');
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);
                toastr.error('An error occurred: ' + error.message);
            });
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
            }
        }
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
