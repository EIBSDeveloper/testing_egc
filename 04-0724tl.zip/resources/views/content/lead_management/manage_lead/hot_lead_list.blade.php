@extends('layouts/layoutMaster')

@section('title', 'Manage Lead Basket')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead-card {
            width: 160px;
            height: 200px;
            padding-bottom: 20px !important;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            text-align: center;
            cursor: pointer;
        }

        .lead-card img {
            width: 100px;
            height: auto;
            object-fit: contain;
            image-rendering: crisp-edges;
        }

        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 2;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                                                                    transform: scale(1.2);
                                                                    opacity: 0.7;
                                                                } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .highlight-row {
            position: relative;
            width: 200px;
            height: 50px;
            overflow: hidden;

        }
    </style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data = $helper->get_staff_data($user_id);
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Hot Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            @php
                $module_name = 'Lead Management';
                $menu_name = 'Manage Lead Baseket';

                $module_name = 'Lead Management';
                $menu_name = 'Manage Lead';
            @endphp
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_spam_lead" role="tabpanel">
                                <div class="row">
                                    <div class="row mb-2 mt-2">
                                        <div class="col-lg-2">
                                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                            <div>
                                                <span>Show</span>
                                                <br>
                                                <select id="perpage" name="perpage"
                                                    class="form-select form-select-sm w-60px"
                                                    onchange="sort_filter(this.value);">
                                                    @php
                                                        $options = [10, 25, 100, 500]; // Define available options
                                                    @endphp
                                                    @foreach ($options as $option)
                                                        <option value="{{ $option }}"
                                                            @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                            @php echo $option; @endphp
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                            <form id="search_form" method="POST" action="/hot_lead">
                                                @csrf
                                                <div class="d-flex align-items-center gap-2">
                                                    <div class="">
                                                        <input type="hidden" name="page"
                                                            value="{{ request('page', 1) }}">
                                                        <input type="hidden" name="filter_on" value="1">
                                                        <input type="hidden" class="sorting_filter_class"
                                                            name="sorting_filter" id="sorting_filter"
                                                            value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                        <input type="text" class="form-control" id="lead_fill"
                                                            name="lead_fill" value="{{ $lead_fill ?? '' }}"
                                                            placeholder="Enter Lead - Name/ Mob. No/ Email Id" />
                                                    </div>
                                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                                        onclick="search_filter_func()">Search</button>
                                                    <a href="{{ url('/hot_lead') }}" type="button"
                                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span
                                                            class="mdi mdi-refresh fs-6"></span>
                                                    </a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <input type="hidden" id="view_edit_id" />
                                        <table
                                            class="table align-top table-row-dashed table-striped table-hover gy-1 gs-2 lead_list list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-150px">Lead</th>
                                                    <th class="min-w-100px"><span data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Registered Date">RD
                                                        </span><span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Last Followup Date"> / LFD</th>
                                                    <th class="min-w-80px">Sales Person</th>
                                                    <th data-sortable="false" class="min-w-80px">Life Span </th>
                                                    <th class="min-w-50px">Potential</th>
                                                    <th class="min-w-100px">Status</th>
                                                    <th class="min-w-80px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                {{-- @if (auth()->user()->hasPermission($module_name, 'List', $menu_name)) --}}
                                                @if (count($leads) > 0)
                                                    @foreach ($leads as $i => $category)
                                                        <tr class="{{ $category->just_dial_id > 0 && $category->lead_status_id == 1 ? 'highlight-row' : '' }}"
                                                            style="background-color: 
                                        
                                                            @if ($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8) lightpink;@elseif($category->status != 4 && $category->is_hot_lead == 1)#6fd1fb;@else{{ $category->lead_bg_color }} {{-- Use the existing color otherwise --}} @endif;">
                                                            <td>
                                                                <div class="d-flex align-items-center gap-1">
                                                                    @if ($category->is_hot_lead == 2)
                                                                        <div data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Hot Lead Star">
                                                                            <img src="{{ asset('assets/phdizone_images/lead/Star_animate.gif') }}"
                                                                                alt="Hot Lead Star"
                                                                                class="w-50px h-50px text-black fw-bold">
                                                                        </div>
                                                                    @endif
                                                                    @if ($category->lead_appointment_status == 1)
                                                                        <div class="animation-blink"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Appointment Onprogress">
                                                                            <img src="{{ asset('assets/phdizone_images/lead/appointment.ico') }}"
                                                                                alt="Appointment Onprogress Icon"
                                                                                class="w-30px h-30px text-black fw-bold">
                                                                        </div>
                                                                    @endif
                                                                    <div class="ms-1 mb-0">
                                                                        <div class="d-flex align-items-center gap-2">
                                                                            <label
                                                                                class="fs-7 text-nowrap text-black fw-semibold">{{ trim($category->lead_name) }}</label>

                                                                            @if (isset($category->productsData) && count($category->productsData) > 0)
                                                                                <span
                                                                                    class="text-dark fs-8 fw-semibold cursor-pointer"
                                                                                    data-bs-toggle="dropdown"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"><span
                                                                                        class="mdi mdi mdi-information fs-8"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="Product"></span></span>
                                                                                <div
                                                                                    class="dropdown-menu dropdown-menu-start w-350px">
                                                                                    <div
                                                                                        class="text-dark fs-6 text-center my-2 fw-semibold">
                                                                                        Products</div>
                                                                                    <hr class="mt-0 mb-2 border-dark">
                                                                                    <div
                                                                                        class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                                        @if (isset($category->productsData))
                                                                                            @foreach ($category->productsData as $product)
                                                                                                <div
                                                                                                    class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                                                    <div
                                                                                                        class="text-black mb-1 fw-semibold fs-5 me-2">
                                                                                                        &#9733;</div>
                                                                                                    <div class="d-block">
                                                                                                        <div
                                                                                                            class="text-black fw-semibold text-justify fs-7">
                                                                                                            {{ $product->product_name }}
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="fw-semibold text-info fs-8">
                                                                                                            {{ $product->product_category_name }}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            @endforeach
                                                                                        @endif
                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                            <span id=""
                                                                                class="d-block boom badge text-black rounded-circle fw-semibold fs-8 p-1  mt-1 leadBoom"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_transfer_log"
                                                                                onclick="leadTransfer('{{ $category->sno }}', '{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $category->lead_source_name }}', '{{ $category->registered_date }}')"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Transfer"
                                                                                style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                                T</span>
                                                                            @if ($category->transfer_status == 1)
                                                                            @elseif (
                                                                                $category->lead_status_id == 1 &&
                                                                                    $category->lead_score == null &&
                                                                                    ($category->lead_condition == 1 || ($category->lead_condition == 2 && $category->status != 1)))
                                                                                <span id=""
                                                                                    class="d-block boom badge text-black rounded fw-semibold fs-8 py-0 mt-1 leadBoom"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="New Lead"
                                                                                    style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                                    New Lead</span>
                                                                            @endif
                                                                        </div>
                                                                        <div class="d-block">
                                                                            <div class="d-flex align-items-center mb-0">
                                                                                @if ($category->lead_mobile)
                                                                                    @if ($category->status != 7)
                                                                                        <label
                                                                                            class="fs-7 text-dark fw-semibold me-1 text-nowrap">
                                                                                            @php
                                                                                                $call_chk = isset(
                                                                                                    $category->inter_calls,
                                                                                                )
                                                                                                    ? $category->inter_calls
                                                                                                    : 0;
                                                                                                $countryCode =
                                                                                                    $call_chk == 0
                                                                                                        ? '+91'
                                                                                                        : '+' .
                                                                                                            $category->inter_calls;
                                                                                                $mobileNumber =
                                                                                                    $category->status ==
                                                                                                    1
                                                                                                        ? 'XXXXXXXXXX'
                                                                                                        : $category->lead_mobile;
                                                                                            @endphp
                                                                                            {{ $countryCode }}
                                                                                            {{ $mobileNumber }}
                                                                                        </label>
                                                                                    @endif
                                                                                    @if ($category->status == 7)
                                                                                        <label
                                                                                            class="fs-7 text-black fw-semibold me-1 text-nowrap"
                                                                                            title="Mobile No">
                                                                                            {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}
                                                                                        </label>
                                                                                    @endif
                                                                                    @php
                                                                                        $phoneVerifyContent = json_decode(
                                                                                            $category->phone_verify_content,
                                                                                            true,
                                                                                        );
                                                                                    @endphp
                                                                                    @if ($category->phone_verify_status == 1)
                                                                                        <a href="javascript:;"
                                                                                            class="fs-7 text-black fw-semibold me-1"
                                                                                            onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                            <span data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Mobile No Verified"><i
                                                                                                    class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                                                        </a>
                                                                                    @elseif($category->phone_verify_status == 2)
                                                                                        <a href="javascript:;"
                                                                                            class="fs-7 text-black fw-semibold me-1"
                                                                                            onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                            <span data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Mobile No. Not Verified">
                                                                                                <svg class="w-20px h-20px"
                                                                                                    enable-background="new 0 0 500 500"
                                                                                                    viewBox="0 0 500 500"
                                                                                                    id="hand-draw-white-cross-mark-on-red-circle">
                                                                                                    <rect id="Layer_1"
                                                                                                        fill="#fff0f0"
                                                                                                        display="none">
                                                                                                    </rect>
                                                                                                    <g id="Layer_2">
                                                                                                        <circle
                                                                                                            cx="250"
                                                                                                            cy="250"
                                                                                                            r="200"
                                                                                                            fill="#f32f45">
                                                                                                        </circle>
                                                                                                        <path
                                                                                                            fill="#f32f45"
                                                                                                            d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                            l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                            c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                            c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                            c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                            c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                            C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                                        </path>
                                                                                                        <path
                                                                                                            fill="#fff"
                                                                                                            d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                                        </path>
                                                                                                    </g>
                                                                                                </svg>
                                                                                            </span>
                                                                                        </a>
                                                                                    @endif
                                                                                @endif
                                                                            </div>
                                                                            <div class="d-flex align-items-center mb-0">
                                                                                @if ($category->lead_email_id)
                                                                                    <label
                                                                                        class="fs-7 text-dark fw-semibold me-1 text-truncate max-w-170px"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="{{ $category->lead_email_id }}">
                                                                                        {{ $category->lead_email_id }}</label>
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-block text-dark fs-8 mb-2 fw-semibold"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="Lead Id">
                                                                            {{ $category->lead_id ?? '' }}</div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div
                                                                    class="d-flex align-items-center justify-content-start mb-2 gap-2">
                                                                    <div>
                                                                        <label class="badge text-black fw-semibold fs-8"
                                                                            style="background-color:rgb(78, 202, 94);"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Registered Date">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) : date($common_date_format, strtotime($category->created_at)) }}</label>

                                                                        @if (isset($category->appointment_date))
                                                                            <hr class="mt-1 mb-1">
                                                                            <div class="d-block mt-1">
                                                                                <label
                                                                                    class="badge bg-body text-danger fw-semibold fs-8"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Last Follow Up Date">
                                                                                    {{ $category->appointment_date ? date($common_date_format, strtotime($category->appointment_date)) : '' }}</label>
                                                                            </div>
                                                                        @endif
                                                                        <hr class="mt-1 mb-1">
                                                                        <div class="d-block mt-1">
                                                                            <a href="javascript:;"
                                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1">
                                                                                <span data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Lead Life Time">{{ $category->formattedDifference ?? '0 day' }}</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>


                                                                </div>

                                                            </td>
                                                            <td>
                                                                <div class="d-flex gap-2">
                                                                    <span
                                                                        class="text-truncate max-w-125px fw-semibold fs-7 text-black"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="{{ $category->nick_name ?? 'Old Staff' }}">{{ $category->staff_name ?? 'Old Staff' }}</span>
                                                                    <div class="avatar avatar-sm me-1">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            onclick="openCallHistoryModal('{{ $category->sno }}','Outgoing','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}' ,'{{ $category->incoming_count }}','{{ $category->outgoing_count }}','{{ $category->missed_reject_count }}','{{ $category->dialed_count }}')"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_call_log">
                                                                            <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Outgoing Calls Count">
                                                                                <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                                    alt="Outgoing Call Icon"
                                                                                    class="w-15px h-15px text-black fw-bold">
                                                                            </div>
                                                                            @if ($category->outgoing_count > 0)
                                                                                <span
                                                                                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                                    style="background-color: #FFA500 !important;">{{ $category->outgoing_count }}</span>
                                                                            @endif
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="d-block">
                                                                    @if ($category->just_dial_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-6 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span class="jd-blue">Just</span><span
                                                                                class="jd-orange">dial</span>
                                                                        </label>
                                                                    @elseif($category->cloud_call_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <i class="fas fa-cloud cc-icon"></i><span
                                                                                class="cc-purple">Cloud</span><span
                                                                                class="cc-purple">Call</span>
                                                                        </label>
                                                                    @elseif($category->call_tracker_id > 0)
                                                                        <label
                                                                            class="badge ct-orange text-white rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span>Tra<i
                                                                                    class="mdi mdi-phone-in-talk ct-icon"></i>cker</span>
                                                                        </label>
                                                                    @elseif($category->website_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span class="text-primary">Web</span><span
                                                                                class="text-primary">Site</span>
                                                                        </label>
                                                                    @elseif($category->lead_source_id == 20)
                                                                        <span
                                                                            class="qr-badge d-inline-flex align-items-center gap-1 fs-7"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <i
                                                                                class="mdi mdi-qrcode-scan fs-7"></i>{{ $category->lead_source_name ?? '-' }}
                                                                        </span>
                                                                    @else
                                                                        <label
                                                                            class="badge bg-secondary text-white rounded fw-semibold fs-8 "
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            {{ $category->lead_source_name ?? '-' }}
                                                                        </label>
                                                                    @endif
                                                                </div>
                                                            </td>
                                                            @php
                                                                $badgeClass = 'bg-success';

                                                                if ($category->hot_lead_days_left < 10) {
                                                                    $badgeClass = 'bg-danger';
                                                                } elseif ($category->hot_lead_days_left <= 20) {
                                                                    $badgeClass = 'bg-info';
                                                                } else {
                                                                    $badgeClass = 'bg-success';
                                                                }
                                                            @endphp

                                                            <td>
                                                                <span class="badge {{ $badgeClass }} rounded fs-8 fw-semibold text-white"
                                                                    data-bs-toggle="tooltip"
                                                                    data-bs-placement="bottom"
                                                                    title="Hot Lead Life Time">
                                                                    {{ $category->hot_lead_days_left }} days
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex align-items-center mt-2 gap-1">

                                                                    @if (
                                                                        $category->potential_type_image != '' &&
                                                                            file_exists(public_path('potential_image/' . $category->potential_type_image)))
                                                                        <img src="{{ asset('potential_image/' . $category->potential_type_image) }}"
                                                                            alt="Image" class="w-35px h-35px"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="{{ $category->potential_type_name ?? '' }}">
                                                                        
                                                                    @else
                                                                        <img src="{{ asset('assets/phdizone_images/def_img.png') }}"
                                                                            alt="Image" class="w-35px h-35px"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="No Potential">
                                                                    @endif
                                                                    @if ($category->status != 7 && $category->spam_verified != 1)
                                                                            @if ($category->appointment_status == 1 && $category->status !== 4 && $category->status !== 10)
                                                                                <div class="avatar avatar-sm me-2">
                                                                                    <a href="javascript:;"
                                                                                        class="dropdown-item"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#kt_modal_follow_up_lead_schedule"
                                                                                        onclick="openResheduleModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                        <div class="border border-gray-500i rounded"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup">
                                                                                            <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                                                alt="Premium Potential Icon"
                                                                                                class="w-30px h-30px text-black fw-bold">
                                                                                        </div>
                                                                                        <span
                                                                                            class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup Count"
                                                                                            style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                        <span
                                                                                            class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup Pending">!</span>
                                                                                    </a>
                                                                                </div>
                                                                            @elseif($category->appointment_status == 4 && $category->status !== 4 && $category->status !== 10)
                                                                                <!--<div class="avatar avatar-sm me-2">-->
                                                                                <!--    <a href="javascript:;"-->
                                                                                <!--        class="dropdown-item"-->
                                                                                <!--        data-bs-toggle="modal"-->
                                                                                <!--        data-bs-target="#kt_modal_again_follow_up_lead_schedule"-->
                                                                                <!--        onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">-->
                                                                                <!--        <div class="border border-gray-500i rounded"-->
                                                                                <!--            data-bs-toggle="tooltip"-->
                                                                                <!--            data-bs-placement="bottom"-->
                                                                                <!--            title="Followup">-->
                                                                                <!--            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"-->
                                                                                <!--                alt="Premium Potential Icon"-->
                                                                                <!--                class="w-30px h-30px text-black fw-bold">-->
                                                                                <!--        </div>-->
                                                                                <!--        <span-->
                                                                                <!--            class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"-->
                                                                                <!--            data-bs-toggle="tooltip"-->
                                                                                <!--            data-bs-placement="bottom"-->
                                                                                <!--            title="Followup Count"-->
                                                                                <!--            style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>-->
                                                                                <!--    </a>-->
                                                                                <!--</div>-->

                                                                                @if ($category->not_closed == 1)
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_not_closed"
                                                                                            onclick="openNotClosedModal('{{ $category->created_by }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                            <span
                                                                                                class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup Count"
                                                                                                style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                        </a>
                                                                                    </div>
                                                                                @else
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_again_follow_up_lead_schedule"
                                                                                            onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                            <span
                                                                                                class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup Count"
                                                                                                style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                        </a>
                                                                                    </div>
                                                                                @endif
                                                                            @elseif($category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                                                <!--<div class="avatar avatar-sm me-2">-->
                                                                                <!--    <a href="javascript:;"-->
                                                                                <!--        class="dropdown-item"-->
                                                                                <!--        data-bs-toggle="modal"-->
                                                                                <!--        data-bs-target="#kt_modal_follow_up_lead"-->
                                                                                <!--        onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">-->
                                                                                <!--        <div class="border border-gray-500i rounded"-->
                                                                                <!--            data-bs-toggle="tooltip"-->
                                                                                <!--            data-bs-placement="bottom"-->
                                                                                <!--            title="Not Yet Followed">-->
                                                                                <!--            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"-->
                                                                                <!--                alt="Premium Potential Icon"-->
                                                                                <!--                class="w-30px h-30px text-black fw-bold">-->
                                                                                <!--        </div>-->
                                                                                <!--    </a>-->
                                                                                <!--</div>-->

                                                                                @if ($category->not_closed == 1)
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_not_closed"
                                                                                            onclick="openNotClosedModal('{{ $category->created_by }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Not Yet Followed">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                        </a>
                                                                                    </div>
                                                                                @else
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_follow_up_lead"
                                                                                            onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Not Yet Followed">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                        </a>
                                                                                    </div>
                                                                                @endif
                                                                            @elseif($category->status == 5)
                                                                            @endif
                                                                        @endif
                                                                </div>
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;"
                                                                        class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_premium_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                                                    alt="Premium Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Premium Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;"
                                                                        class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_high_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                                    alt="High Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>High Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;"
                                                                        class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_good_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                                                                    alt="Good Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Good Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;"
                                                                        class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_medium_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                                    alt="Medium Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Medium Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;"
                                                                        class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_critical_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/critical.png') }}"
                                                                                    alt="Critical Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Critical Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_low_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                                                                    alt="Low Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Low Potential</div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                @if ($category->status == 0)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-info text-white rounded fw-bold fs-8"
                                                                        aria-haspopup="true" aria-expanded="false">
                                                                        Active
                                                                    </a>
                                                                @elseif($category->status == 1)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                        aria-haspopup="true" aria-expanded="false">
                                                                        In Active
                                                                    </a>
                                                                @elseif($category->status == 4)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-success text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false">
                                                                        Customer
                                                                    </a>
                                                                @elseif($category->status == 5 && ($category->drop_verified == 0 || $category->drop_tl_verified == 0))
                                                                    <a href="javascript:;"
                                                                        class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false"> Dead Lead Awaiting </a>
                                                                @elseif($category->status == 5 && $category->drop_verified == 1)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false"> Dead Lead </a>
                                                                @elseif($category->status == 5 && $category->drop_verified == 1)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-danger text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false"> Dead Lead Awaiting </a>
                                                                @elseif($category->status == 7 && ($category->spam_verified == 0 || $category->spam_tl_verified == 0))
                                                                    <a href="javascript:;"
                                                                        class="badge bg-dark text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false"> Spam Awaiting </a>
                                                                @elseif($category->status == 7 && $category->spam_verified == 1)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-dark text-white rounded fw-bold fs-8 mb-2"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false"> Spam </a>
                                                                @endif
                                                                @php
                                                                    $hot_lead_followup = $helper->getFollowupCount(
                                                                        $category->sno,
                                                                    );
                                                                @endphp
                                                                @if ($category->status == 0)
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <!--<a href="javascript:;" class="dropdown-item"-->
                                                                        <!--    data-bs-toggle="modal"-->
                                                                        <!--    data-bs-target="#kt_modal_lead_inactivate" onclick="inactiveModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Inactivate</a>-->
                                                                        @if ($hot_lead_followup >= 2)
                                                                            @if ($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)
                                                                                <a href="javascript:;"
                                                                                    class="dropdown-item d-none"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_hot_lead"
                                                                                    onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot
                                                                                    Lead</a>
                                                                            @elseif($category->lead_status_id != 3)
                                                                                <a href="javascript:;"
                                                                                    class="dropdown-item"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_hot_lead"
                                                                                    onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot
                                                                                    Lead</a>
                                                                            @endif
                                                                        @endif
                                                                        @if ($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_drop"
                                                                                onclick="dropModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">Dead
                                                                                Lead</a>
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_spam"
                                                                                onclick="spamModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->created_by }}')">Spam
                                                                                Lead</a>
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_potential"
                                                                                onclick="PotentialModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">Potential
                                                                                Baseket</a>
                                                                        @elseif($category->appointment_status != 4)
                                                                            <label
                                                                                class="text-danger fs-8 fw-bold dropdown-item">Pending
                                                                                Follow-up</label>
                                                                        @elseif($category->lead_appointment_status == 1)
                                                                            <label class="dropdown-item"
                                                                                class="text-danger fs-8 fw-bold dropdown-item">Pending
                                                                                Appointment</label>
                                                                        @endif
                                                                    </div>
                                                                @elseif($category->status == 1)
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_activate"onclick="activeModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Activate</a>
                                                                    </div>
                                                                @elseif($category->status == 4)
                                                                @endif
                                                            </td>
                                                            <td>
                                                                
                                                                @if ($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                                    <span class="text-end">
                                                                        <a class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false">
                                                                            <i
                                                                                class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                                        </a>
                                                                        <div class="dropdown-menu dropdown-menu-end">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_view_lead"
                                                                                onclick="populateViewModal('{{ $category->sno }}')">
                                                                                <span><i
                                                                                        class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                                <span>View</span>
                                                                            </a>
                                                                            <a href="javascript:;" data-bs-toggle="modal"
                                                                                class="dropdown-item"
                                                                                data-bs-target="#kt_modal_lead_transfer_log"
                                                                                onclick="leadTransfer('{{ $category->sno }}', '{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $category->lead_source_name }}', '{{ $category->registered_date }}')">
                                                                                <span><i
                                                                                        class="mdi mdi-history fs-3 text-black me-1"></i></span>
                                                                                <span>HIstory</span>
                                                                            </a>
                                                                        </div>
                                                                    </span>
                                                                @endif
                                                                <button type="button"
                                                                    class="me-2 btn btn-sm btn-secondary fw-semibold mb-1  waves-effect waves-light"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_unmark_hot_lead"
                                                                    onclick="unMarkHotLead('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->lead_mobile }}')">UnMark</button>
                                                                @if (auth()->user()->hasPermission($module_name, 'Call Summary', $menu_name))
                                                                    @if ($category->outgoing_count == $category->total_appointments && $category->status != 4)
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_succ_sum"
                                                                            onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','The number of outgoing calls matches the follow-ups', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-check-mark-on-green-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="236.5" cy="250"
                                                                                        r="200" fill="#39ba77"></circle>
                                                                                    <path fill="#39ba77"
                                                                                        d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                            c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                            c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                            c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                            c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                            c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                            c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @elseif(
                                                                        $category->outgoing_count == $category->total_appointments ||
                                                                            ($category->total_appointments >= 5 && $category->status != 4))
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_succ_sum"
                                                                            onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed!', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-check-mark-on-green-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="236.5" cy="250"
                                                                                        r="200" fill="#39ba77"></circle>
                                                                                    <path fill="#39ba77"
                                                                                        d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                                c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                                c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                                c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                                c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                                c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                                c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                        {{-- Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed! --}}
                                                                    @elseif($category->outgoing_count != $category->total_appointments && $category->status != 4)
                                                                        <a href="javascript:;" class="btn btn-icon btn-sm"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_fail_sum"
                                                                            onclick="failSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}', 'Outgoing calls and follow-ups are mismatched. Please review the call and follow-up details', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                            {{-- data-bs-toggle="modal" data-bs-target="#kt_modal_lead_wallet" onclick="leadWallet('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')"> --}}
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                enable-background="new 0 0 500 500"
                                                                                viewBox="0 0 500 500"
                                                                                id="hand-draw-white-cross-mark-on-red-circle"
                                                                                style="width:76%!important">
                                                                                <rect id="Layer_1" width="500"
                                                                                    height="500" fill="#fff0f0"
                                                                                    display="none"></rect>
                                                                                <g id="Layer_2">
                                                                                    <circle cx="250" cy="250"
                                                                                        r="200" fill="#f32f45"></circle>
                                                                                    <path fill="#f32f45"
                                                                                        d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                    </path>
                                                                                    <path fill="#fff"
                                                                                        d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @endif
                                                                    @php
                                                                        $currentDate = \Carbon\Carbon::now();
                                                                        $registeredDate = \Carbon\Carbon::parse(
                                                                            $category->registered_date,
                                                                        );
                                                                        $diffInDays = $registeredDate->diffInDays(
                                                                            $currentDate,
                                                                        );

                                                                        $expectedOutgoingCount = 0;
                                                                        if ($diffInDays >= 15) {
                                                                            $expectedOutgoingCount = 5;
                                                                        } elseif ($diffInDays >= 7) {
                                                                            $expectedOutgoingCount = 4;
                                                                        } elseif ($diffInDays >= 3) {
                                                                            $expectedOutgoingCount = 3;
                                                                        } elseif ($diffInDays >= 2) {
                                                                            $expectedOutgoingCount = 2;
                                                                        } elseif ($diffInDays >= 1) {
                                                                            $expectedOutgoingCount = 1;
                                                                        }
                                                                    @endphp
                                                                    @if ($category->outgoing_count != $expectedOutgoingCount && $category->status != 4)
                                                                        <a href="javascript:;"
                                                                            class="btn btn-icon btn-sm animate__animated animate__pulse animate__infinite"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_lead_danger_sum"
                                                                            onclick="dangerSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','{{ $diffInDays }}', '{{ $category->outgoing_count }}', '{{ $expectedOutgoingCount }}', '{{ $category->total_appointments }}')">
                                                                            {{-- Insert your SVG or button content here --}}
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                viewBox="0 0 33.5 31.25"
                                                                                id="ExclamationSign"
                                                                                style="width:76%!important">
                                                                                <defs>
                                                                                    <linearGradient id="a"
                                                                                        x1="27.59" x2="8.53"
                                                                                        y1="6.27" y2="33.97"
                                                                                        gradientUnits="userSpaceOnUse">
                                                                                        <stop offset="0"
                                                                                            stop-color="#ff8383"></stop>
                                                                                        <stop offset="1"
                                                                                            stop-color="#fa1818"></stop>
                                                                                    </linearGradient>
                                                                                </defs>
                                                                                <g fill="#ef1818">
                                                                                    <path fill="url(#a)"
                                                                                        d="m16.75,31.25c-7.48,0-11.22,0-13.38-1.57C1.49,28.31.27,26.2.03,23.88c-.28-2.66,1.59-5.9,5.33-12.37C9.1,5.04,10.97,1.8,13.41.71c2.13-.95,4.56-.95,6.69,0,2.44,1.09,4.31,4.33,8.05,10.8,3.74,6.48,5.61,9.71,5.33,12.37-.25,2.32-1.46,4.42-3.35,5.79-2.16,1.57-5.9,1.57-13.38,1.57Z">
                                                                                    </path>
                                                                                    <line x1="16.75" x2="16.75"
                                                                                        y1="8.22" y2="18.09"
                                                                                        fill="none" stroke="#ffffff"
                                                                                        stroke-linecap="round"
                                                                                        stroke-width="3"></line>
                                                                                    <path fill="#ffffff"
                                                                                        d="m18.4,23.02c0,.91-.74,1.64-1.64,1.64s-1.64-.74-1.64-1.64.74-1.64,1.64-1.64,1.64.74,1.64,1.64Z">
                                                                                    </path>
                                                                                </g>
                                                                            </svg>
                                                                        </a>
                                                                    @endif
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @endif

                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-4">
                                        {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!--begin::Modal - Convert Drop to Lead-->
    <div class="modal fade" id="kt_modal_convert_potential_to_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content"><i class="mdi mdi-account-convert fs-1 animation-blink-smooth"></i>
                    </div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to convert this potential basket lead into your lead ?</div>
                <div class="text-center mt-2 mb-4">
                    <label class="text-success fw-bold fs-5 lead_trans_name"></label>
                </div>
                <form id="PotentialLeadForm_Lead" action="{{ route('trans_potential_to_lead') }}" method="POST"
                    novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_convert_lead" name="lead_id">
                    <div class="container" id="swal2-html-container" style="display: block;">
                        {{-- <div class="row mb-4 align-items-center d-flex justify-content-center" style="display: none !important;">
                                <div class="col-lg-10">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="assg_staff_add_lead" name="assg_staff_add" class="select3 form-select">
                                    </select>
                                    <div class="text-danger" id="assg_staff_add_lead_err"></div>
                                </div>
                            </div> --}}
                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-sm btn-success me-3" id="single_convert_btn_lead">Yes,
                                Convert</button>
                            <button type="reset" class="btn  btn-sm btn-secondary" data-bs-dismiss="modal">No,
                                cancel</button>
                        </div>
                    </div>
                    <br>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Drop to Lead-->


    <!--begin::Modal - Lead Transfer Log-->
    <div class="modal fade" id="kt_modal_lead_transfer_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer Log Details</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" id="lead_id_transfer" name="lead_id_transfer">
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_name_transfer"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_src_transfer"></label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_mobile_transfer"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Registered Date">Registered DT</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 fs-6 fw-bold text-black" id="lead_reg_date_transfer"></label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Staff</th>
                                        <th class="min-w-150px">Transfered From</th>
                                        <th class="min-w-150px">End Date</th>
                                        <th class="min-w-50px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="transfer_log_div">
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Transfer Log-->

    <!--begin::Modal - View Lead-->
    <div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">
                            <label>View Lead</label>
                            <label class="ms-1 me-1">-</label>
                            <label class="badge bg-info rounded fw-semibold fs-4">Active</label>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 text-black fs-5 fw-bold">Basic Information</div>
                        <div class="col-lg-6 text-end">
                            <div class="badge bg-secondary text-end fs-6 text-white fw-semibold rounded"
                                id="view_lead_auto_id">LD-0003/24</div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_created" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_name_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_gender_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_dob_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="lead_email_view"
                                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="priya@gmail.com">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_address" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_mobile_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_alternate_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="lead_marital_view" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="text-black fs-5 fw-bold">Product Information</label>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Category</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_category" class="col-7 text-black fs-6 fw-bold">Development
                                    Services</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Product</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_service" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 text-black fs-5 fw-bold">Lead Information</div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"><span id="view_leadtype"></span></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Potential Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7 text-black fs-6 fw-bold">
                                    <div class="d-flex align-items-center">
                                        <div class="me-1">
                                            <img id="potential_image_view" src="" alt="Premium Potential Icon"
                                                class="w-25px h-25px text-black fw-bold">
                                        </div>
                                        <label id="view_potentialtype" class="text-black fs-6 fw-bold"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_leadsource" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">University</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label id="view_university" class="col-7 text-black fs-6 fw-bold"></label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <label class="text-dark fs-6 fw-semibold mb-2">Comments</label>
                            <div class="d-block">
                                <label id="view_comments" class="text-black fs-7 fw-bold">&emsp;&emsp;</label>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Lead-->

    <!--begin::Modal -  Call Log-->
    <div class="modal fade" id="kt_modal_call_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-5 px-5 px-xl-10">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center mb-4 text-black">
                            <span><span id="call_lead_name">Priya</span> [ </span>
                            <span class="text-info" id="call_lead_mobile">+91 9876543210</span>
                            <span>] Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="nav-align-top mb-2">
                                <ul class="nav nav-pills flex-nowrap call_navbar" role="tablist">

                                </ul>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane call_log fade show active" id="tab_incoming_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Incoming Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_outgoing_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Outgoing Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_missed_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Missed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_dailled_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Dialed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -  Call Log-->

    <!--begin::Modal - Incoming Call Log-->
    <div class="modal fade" id="kt_modal_call_lead_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span><span>Priya</span> [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] <span>Incoming Call History</span></span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                        <th class="min-w-125px px-1">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="call-history-data">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Outgoing Call Log-->
    <div class="modal fade" id="kt_modal_outgoing_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Outgoing Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">02:20:00 PM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">02:21:20 PM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:20</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:02 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:08</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Missed Call Log-->
    <div class="modal fade" id="kt_modal_missed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Missed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ecc093 !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:05 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:07 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:02</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Reject Call Log-->
    <div class="modal fade" id="kt_modal_reject_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Reject Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ff00004f !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:10</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Dialed Call Log-->
    <div class="modal fade" id="kt_modal_dialed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Dialed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Dialed Call Log-->


    <!--begin::Modal - Success Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_succ_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="succ_lead_name"></label>
                            [<label id="succ_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_succ_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_succ_count"></span>
                            </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_succ_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Success Lead Call Summmary-->

    <!--begin::Modal - Fail Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_fail_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="fail_lead_name"></label>
                            [<label id="fail_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_fail_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_fail_count"></span>
                            </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_fail_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Fail Lead Call Summmary-->

    <!--begin::Modal - Danger Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_danger_sum" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary</h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="danger_lead_name"></label>
                            [<label id="danger_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_danger_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_danger_count"></span>
                            </label>
                        </div>
                        <!-- Properly aligned section -->
                        <div class="text-center mt-4">
                            <label class="fw-bold fs-5 text-primary bg-warning px-2" id="danger_lead_msg"></label>
                            <table class="table table-borderless text-primary fw-semibold fs-5 mx-auto"
                                style="width: auto;">
                                <tbody>
                                    <tr>
                                        <td class="text-end pe-3">Days since registration:</td>
                                        <td class="text-start"><label id="lead_danger_days"></label> days</td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Expected Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_expected"></label></td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Actual Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_call_count_actual"></label></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Danger Lead Call Summmary-->


        <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_date">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_time">
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_rep_count">00</span>
                                </div>
                            </div>
                            {{-- <div class="col-lg-12 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="1" name="progressed" onclick="progress_func('yes');" checked />
                                    <label class="form-check-label">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="2" name="progressed" onclick="progress_func('no');" />
                                    <label class="form-check-label">No</label>
                                </div>
                            </div> --}}
                        </div>
                        {{-- <div id="message" name="message">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                            class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="1" checked />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="-1" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="0" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="convo_message"
                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                        placeholder="Enter Conversation Message"></textarea>
                                    <div class="text-danger" id="convo_message_err"></div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div id="reason" name="reason" style="display: none !important;">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="app_reason" name="app_reason"
                                        onchange="toggleInputField_followup(this.value)">
                                        <option value="">Select Reason</option>
                                        @if (isset($followupReasonList))
                                            @foreach ($followupReasonList as $s_reason)
                                                <option value="{{ $s_reason->reason_name }}"
                                                    data-comments-check-followup="{{ $s_reason->comments_check }}">
                                                    {{ $s_reason->reason_name }}
                                                </option>
                                            @endforeach
                                        @endif
                                        <option value="1">Others</option>
                                    </select>
                                    <div class="text-danger" id="app_reason_select_err"></div>
                                    <div class="mt-4" id="followup_reason_div" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="followup_reason_text"
                                            id="followup_reason_text" value="" placeholder="Enter Reason">
                                        <div class="text-danger" id="followup_comments_text_err"></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                                class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date"
                                                class="form-control" value="" name="appointment_date" />

                                        </div>
                                        <div class="text-danger" id="re_app_date_err"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control common_time_class_new"
                                            placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                            value="" />
                                        <div class="text-danger" id="re_app_time_err"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div> --}}
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2 active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                                data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                                aria-controls="accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="headingPopoutTwo">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#accordionPopoutTwo"
                                                aria-expanded="false" aria-controls="accordionPopoutTwo">
                                                <span class="text-black fw-semibold fs-6">Appointment History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="apptmnt_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutTwo" class="accordion-collapse collapse"
                                            aria-labelledby="headingPopoutTwo" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-100px">Date / Time</th>
                                                                    <th class="min-w-100px">Category</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                    <th class="min-w-100px">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="appointmentLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{-- <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id='rescheduleBtn' class="btn btn-primary"
                                    onclick="updateReshedule()">Submit
                                    Report</button>
                            </div> --}}
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->


    <!--begin::Modal - Again Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_again_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form action="{{ route('add_appointment_pb_daily') }}" method="POST" autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id_again">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_app_again">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_app_again">
                                </div>
                            </div>
                            
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_count_again">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="again_flw_headingPopoutOne">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutOne"
                                                aria-expanded="false" aria-controls="again_flw_accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count_again">00</span>
                                            </button>
                                        </h2>
                                        <div id="again_flw_accordionPopoutOne" class="accordion-collapse collapse"
                                            aria-labelledby="again_flw_headingPopoutOne">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBodyAgain">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="again_flw_headingPopoutTwo">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutTwo"
                                                aria-expanded="false" aria-controls="again_flw_accordionPopoutTwo">
                                                <span class="text-black fw-semibold fs-6">Appointment History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="apptmnt_count_again">0</span>
                                            </button>
                                        </h2>
                                        <div id="again_flw_accordionPopoutTwo" class="accordion-collapse collapse"
                                            aria-labelledby="again_flw_headingPopoutTwo">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-100px">Date / Time</th>
                                                                    <th class="min-w-100px">Category</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                    <th class="min-w-100px">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="appointmentLeadIdsTableBodyAgain">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            {{-- <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" id="schdule_btn" class="btn btn-primary">Schedule</button>
                            </div> --}}
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Again Followup Lead Schedule-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->
    <!-- end Bootstrap old Modal for showing messages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .animation-blink-smooth {
            animation: smoothBlink 1.5s ease-in-out infinite;
        }

        @keyframes smoothBlink {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.3;
            }
        }
    </style>
    <style>
        .source-label {
            position: relative;
            /* Ensure the label is positioned relative for absolute positioning of ::before */
            display: inline-block;
        }

        .source-label::before {
            /*content: '\1F31F'; */
            content: '\2728';
            /* ðŸŒŸ Sparkles */
            position: absolute;
            top: -12px;
            /* Move it further up */
            left: 90%;
            /* Center it horizontally */
            transform: translateX(-50%);
            /* Adjust horizontal alignment */
            font-size: 1rem;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }


        .jd-blue {
            color: #1976d2;
            /* Justdial Blue */
            font-weight: bold;
        }

        .jd-orange {
            color: #f16522;
            /* Justdial Orange */
            font-weight: bold;
        }

        .jd-blue,
        .jd-orange {
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }

        .cc-purple {
            color: #5c2d91;
            /* CloudCall Purple */
            font-weight: bold;
        }

        .cc-orange {
            color: #f58220;
            /* CloudCall Orange */
            font-weight: bold;
        }

        /* Cloud Icon Styling */
        .cc-icon {
            color: #5c2d91;
            /* Matching CloudCall Purple */
            margin-right: 5px;
        }


        .ct-black {
            color: #000000;
            /* Call in Black */
            font-weight: bold;
        }

        .ct-orange {
            background-color: #f16522;
            /* Justdial Orange */
            color: #ffffff;
            /* White text inside */
            /*font-weight: bold;*/
            padding: 2px 6px;
            border-radius: 4px;
        }

        /* Call Icon Styling */
        .ct-icon {
            color: #000000;
            /* Black Call Icon */
            font-size: 14px;
            margin-left: 3px;
        }


        /* Loading Dots */
        .loading-dots {
            display: flex;
            gap: 8px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Individual Balls */
        .loading-dots span {
            width: 15px;
            height: 15px;
            background-color: rgb(32, 32, 34);
            border-radius: 50%;
            opacity: 0;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }

        /* Add More Balls with Delay */
        .loading-dots span:nth-child(1) {
            animation-delay: 0s;
        }

        .loading-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }

        .loading-dots span:nth-child(4) {
            animation-delay: 0.6s;
        }

        .loading-dots span:nth-child(5) {
            animation-delay: 0.8s;
        }

        .loading-dots span:nth-child(6) {
            animation-delay: 1s;
        }

        /* Animation */
        @keyframes fadeInOut {

            0%,
            100% {
                opacity: 0;
                transform: scale(0.8);
            }

            50% {
                opacity: 1;
                transform: scale(1);
            }
        }


        /* Stylish Fade Effect Box */
        .fade-effect {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #dbdd47, #ccce43);
            color: rgb(255, 255, 255);
            font-weight: bold;
            font-size: 18px;
            text-align: center;
            line-height: 60px;
            border-radius: 10px;
            text-shadow: 0 0 5px rgba(137, 92, 219, 0.5),
                0 0 10px rgba(137, 92, 219, 0.5),
                0 0 20px rgba(137, 92, 219, 0.5);
            /* Intense Neon Glow */
            box-shadow: 0 0 15px rgba(137, 92, 219, 0.5),
                0 0 25px rgba(16, 168, 185, 0.8),
                0 0 35px rgba(137, 92, 219, 0.5);
            /* Red & Black Glow */
            letter-spacing: 2px;
            opacity: 0;
            /* Initially hidden */
            transition: all 0.5s ease-in-out;
            animation: shimmer 3s infinite alternate, runText 12s linear infinite, fadeEffect 3s infinite alternate;
        }

        /* Hover Glow Effect */
        .fade-effect:hover {
            box-shadow: 0 0 15px rgba(135, 0, 0, 0.7),
                0 0 25px rgba(25, 10, 5, 0.8),
                0 0 35px rgba(135, 0, 0, 0.6);
            /* Red & Black Glow */
            transform: scale(1.05);
            /* Slight Zoom */
        }

        /* Running Text Animation */
        @keyframes runText {
            from {
                left: 100%;
            }

            to {
                left: -100%;
            }
        }

        /* Fade Effect Animation */
        @keyframes fadeEffect {
            0% {
                opacity: 0.3;
            }

            100% {
                opacity: 1;
            }
        }

        @keyframes shimmer {
            0% {
                background-position: -200%;
            }

            100% {
                background-position: 200%;
            }
        }

        /* Blinking text animation */
        .blink {
            /*animation: blinker 1.5s linear infinite;*/
            /* font-weight: bold; */
            color: white;
            /* White text for better contrast */
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9;
            /* Soft pink color */
            padding: 0px 8px;
            border-radius: 12px;
            /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            /* Soft shadow for depth */
            font-size: 0.3rem;
            /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }

        /* Adding a cute icon or star effect */
        .new-label::before {
            content: 'ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨';
            /* You can replace this with any icon or emoji */
            position: absolute;
            top: -8px;
            right: -10px;
            /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }


        /* Bounce animation for cute effect */
        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-8px);
            }

            60% {
                transform: translateY(-4px);
            }
        }
    </style>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .tags-inline.tagify__dropdown {
            z-index: 9999 !important;
            /* Ensure it is higher than the modal's z-index */
        }
    </style>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    {{-- verified drop --}}
    <!-- lead transfer Log -->
    <script>
        function formatDateTransfer(dateString) {
            let date = new Date(dateString);
            let day = String(date.getDate()).padStart(2, '0');
            let monthIndex = date.getMonth();
            let year = date.getFullYear();

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex];

            return `${day}-${month}-${year}`;
        }

        function leadTransfer(id, name, mobile_no, lead_src, reg_date = '') {
            $('#lead_id_transfer').val(id);
            $('#lead_name_transfer').html(name);
            $('#lead_mobile_transfer').html(mobile_no);
            $('#lead_src_transfer').html(lead_src);
            if (reg_date != '') {
                $('#lead_reg_date_transfer').html(formatDateTransfer(reg_date));
            } else {
                $('#lead_reg_date_transfer').html('-');
            }


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/lead_transfer/${id}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken,
                    },
                    body: JSON.stringify({})
                })
                .then(response => response.json())
                .then(data => {
                    // console.log('Data', data);

                    if (data && data.data && Array.isArray(data.data)) {
                        const transferLogDiv = document.getElementById('transfer_log_div');
                        transferLogDiv.innerHTML = '';

                        const transferredFromMapping = {
                            0: 'Direct Lead',
                            1: 'Bulk Raw Lead - Lead',
                            2: 'Lead - Spam Lead',
                            3: 'Lead - Dead Lead',
                            4: 'Raw Lead - Lead',
                            5: 'Bulk Raw Lead - Lead',
                            6: 'Bank Raw Lead - Lead',
                            7: 'Bulk Bank Raw Lead - Lead',
                            8: 'Cloud Call - Lead',
                            9: 'Cloud Call - Spam Lead',
                            10: 'Call Tracker - Lead',
                            11: 'Call Tracker - Spam Lead',
                            12: 'Justdial - Lead',
                            13: 'Website - Lead ',
                            14: 'Spam Lead - Lead',
                            15: 'Dead Lead - Lead',
                            16: 'Lead - Potential Lead',
                            17: 'Potential Lead - Lead'
                        };


                        data.data.forEach(item => {
                            // let staffName =  item.end_date ? item.current_staff_name : item.change_staff_name;
                            let staffName = item.current_staff_name;

                            // Map transferred_from to human-readable text
                            let transferredFromText = transferredFromMapping[item.transferred_from] ||
                                '-'; // Default to '-' if value is not found

                            const row = document.createElement('tr');
                            row.innerHTML = `
                            <td>${staffName || ''}</td>
                            <td>${transferredFromText}</td>
                            <td>${item.end_date ? formatDateTransfer(item.end_date) : '-'}</td> 
                            <td>${item.days_difference || ''}</td>
                        `;
                            transferLogDiv.appendChild(row);
                        });
                    } else {
                        // If no transfer data is available, display a message
                        const transferLogDiv = document.getElementById('transfer_log_div');
                        transferLogDiv.innerHTML =
                            '<tr><td></td><td colspan="4">There is no transfer of staff for the lead</td><td></td><td></td></tr>';
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);
                    toastr.error('An error occurred: ' + error.message);
                });
        }
    </script>

    <!-- call history -->
    <script>
        function openCallHistoryModal(leadId, status, name = '', mobile = '', incomingCount, outgoingCount, missedCount,
            dialedCount) {
            $('#call_lead_name').text(name);
            $('#call_lead_mobile').text(mobile);

            let tabHtml = `
        <li class="nav-item me-2 mb-2">
            <a href="#tab_incoming_calls" class="nav-link call_log_link text-capitalize active" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Incoming', '#tab_incoming_calls')">
                <img src="/assets/phdizone_images/calls/incoming_call.ico" class="w-20px h-25px fw-bold me-2"> Incoming Calls
                <span class="badge bg-label-info fs-6 rounded ms-2">${incomingCount >= 10 ? incomingCount : '0'+incomingCount }</span>
            </a>
        </li>
        <li class="nav-item me-2 mb-2">
            <a href="#tab_outgoing_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Outgoing', '#tab_outgoing_calls')">
                <img src="/assets/phdizone_images/calls/outgoing_call.ico" class="w-20px h-25px fw-bold me-2"> Outgoing Calls
                <span class="badge bg-label-info fs-6 rounded ms-2">${outgoingCount >= 10 ? outgoingCount : '0'+outgoingCount }</span>
            </a>
        </li>
        <li class="nav-item me-2 mb-2">
            <a href="#tab_missed_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Missed & Rejected', '#tab_missed_calls')">
                <img src="/assets/phdizone_images/calls/reject_call.ico" class="w-20px h-25px fw-bold me-2"> Missed & Rejected
                <span class="badge bg-label-info fs-6 rounded ms-2">${missedCount >= 10 ? missedCount : '0'+missedCount }</span>
            </a>
        </li>
        <li class="nav-item me-2 mb-2">
            <a href="#tab_dailled_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Dialed', '#tab_dailled_calls')">
                <img src="/assets/phdizone_images/calls/dialed_call.ico" class="w-20px h-25px fw-bold me-2"> Dialed Calls
                <span class="badge bg-label-info fs-6 rounded ms-2">${dialedCount >= 10 ? dialedCount : '0'+dialedCount }</span>
            </a>
        </li>
    `;

            $(".call_navbar").html(tabHtml);

            // Clear existing table content to avoid leftover data
            $('#tab_incoming_calls tbody').html('');
            $('#tab_outgoing_calls tbody').html('');
            $('#tab_missed_calls tbody').html('');
            $('#tab_dailled_calls tbody').html('');

            // Reset tab to default (Incoming)
            $('.call_log_link').removeClass('active');
            $('.call_log_link[href="#tab_incoming_calls"]').addClass('active');

            // Optionally hide all tabs and show only active
            $('.call_log').removeClass('active show');
            $('#tab_incoming_calls').addClass('active show');

            // Show modal and load default tab
            $('#kt_modal_call_log').modal('show');
            callHistoryTable(leadId, 'Incoming', '#tab_incoming_calls');
        }

        function callHistoryTable(leadId, status, tabSelector) {

            const $tbody = $(tabSelector).find("tbody");

            $.ajax({
                url: "{{ route('get_call_history') }}",
                type: "GET",
                data: {
                    lead_id: leadId,
                    status: status
                },
                beforeSend: function() {
                    $tbody.html('<tr><td colspan="6" class="text-center">Loading...</td></tr>');
                },
                success: function(response) {
                    let rows = '';

                    if (response.calls.length > 0) {
                        response.calls.forEach(call => {
                            let img = "outgoing_call.ico";
                            let statusText = "Outgoing Call";
                            let bgColor = "";
                            let statusColor = "#7594E8";

                            switch (call.call_status) {
                                case 0:
                                    img = "outgoing_call.ico";
                                    statusText = "Outgoing Call";
                                    statusColor = "#7594E8";
                                    break;
                                case 1:
                                    img = "incoming_call.ico";
                                    statusText = "Incoming Call";
                                    statusColor = "#FFBF66";
                                    break;
                                case 2:
                                    img = "missed_call.ico";
                                    bgColor = "#ecc093";
                                    statusText = "Missed Call";
                                    statusColor = "#FFA500";
                                    break;
                                case 3:
                                    img = "reject_call.ico";
                                    bgColor = "#ff00004f";
                                    statusText = "Rejected Call";
                                    statusColor = "#FF7979";
                                    break;
                                default:
                                    img = "dialed_call.ico";
                                    statusText = "Dialed Call";
                                    statusColor = "#7594E8";
                                    break;
                            }

                            rows += `
                        <tr style="background: ${bgColor}">
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-35px border bg-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/calls/') }}/${img}" class="w-20px h-20px" />
                                    </div>
                                    <div>
                                        <label class="fs-7 me-1">${call.staff_name}</label>
                                        <div class="text-primary fs-8">${call.staff_phone_no}</div>
                                    </div>
                                </div>
                            </td>
                            <td>${call.call_start_date ? formatDateTransfer(call.call_start_date) : '-'}</td>
                            <td><label class="text-info fs-7 fw-semibold">${call.call_start_time}</label></td>
                            <td><label class="text-danger fs-7 fw-semibold">${call.call_end_time || '-'}</label></td>
                            <td><label class="badge bg-warning text-black fs-7 fw-bold">${call.call_duration || '-'}</label></td>
                            <td><label class="badge rounded text-white fs-7 fw-semibold" style="background-color: ${statusColor}">${statusText}</label></td>
                        </tr>
                    `;
                        });
                    } else {
                        rows = '<tr><td colspan="6" class="text-center">No call history found</td></tr>';
                    }

                    $tbody.html(rows);
                }
            });
        }
    </script>
    <script>
        let reshedule_id;

        function openResheduleModal(categoryId, name, mobile) {
            $('#lead_name_reop').html(name);
            $('#lead_phone_reop').html(mobile);
            reshedule_id = categoryId;
            // Function to format date to '10-Jun-2024'
            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/edit_appointment/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;



                        document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                        document.getElementById('app_time').innerText = lead.appointment_time;
                        $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                        // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                        //   console.log('Appointment Count:', data.data.appointmentCount);
                        $('#app_count').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBody');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Followup Date">${formatTime(category.appointment_time)}</label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="text-black fw-semibold fs-7">${category.staff_name}</label>
                                </td>
                                <td>
                                    <div class="text-black fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="${category.convo_message ?? '-'}">
                                        ${category.convo_message ?? '-'}
                                    </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ?? '-'}"> ${category.reason ?? '-'}</div>
                                </td>
                            </tr>`;

                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                       
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });

            fetch(`/appointment_history/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        //   console.log(data)
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        $('#apptmnt_count').html(data.data.appointmentCount);
                        const historicalTableBodyAppt = document.getElementById('appointmentLeadIdsTableBody');
                        historicalTableBodyAppt.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];

                                const row = `<tr>
                                    <td>
                                        <div class="mb-0 align-items-center">
                                            <label>
                                                <span class="fs-7 me-2">${index + 1}</span>
                                            </label>
                                        </div>
                                    </td>
                                     <td>
                                        <label
                                            class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                        <div class="d-block">
                                            <label class="text-dark fs-8"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                        </div>
                                    </td>
                                    <td>
                                        <label
                                            class="text-black fw-semibold fs-7">${category.appointment_category}</label>
                                    </td>
                                    <td>
                                    
                                        <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_reason || '-'}">
                                             ${category.appointment_reason || '-'}</div>
                                    </td>
                                    <td>
                                      <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                             ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                    </td>
                                    <td>
                                      ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                            category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                            category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                            '<span>-</span>'}
                                    </td>
                                    
                                </tr>`;

                                historicalTableBodyAppt.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBodyAppt.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });


        }

        function updateReshedule() {
            const resheduleid = reshedule_id;
            const progressed = document.querySelector('input[name="progressed"]:checked').value;

            // Initialize variables
            let app_score = null;
            let convo_message = null;
            let hot_lead = null;
            let reason = null;
            let appointment_date = null;
            let appointment_time = null;
            var err = 0;
            if (progressed == 1) {
                app_score = document.querySelector('input[name="app_score"]:checked').value;
                convo_message = document.getElementById('convo_message').value;
                if (convo_message == '') {
                    $('#convo_message_err').text('Conversation Message is Required')
                    err++
                } else {
                    $('#convo_message_err').text('');
                }
                // hot_lead = document.getElementById('hot_lead').value;
            } else {
                reason = document.getElementById('app_reason').value;
                var other_reason = document.getElementById('followup_reason_text').value;
                appointment_date = document.getElementById('re_app_date').value;
                appointment_time = document.getElementById('re_app_time').value;
                if (reason == '') {
                    $('#app_reason_select_err').text('Reason is Required');
                    err++;
                } else {
                    $('#app_reason_select_err').text('');
                }
                if (reason == 1) {
                    if (other_reason == "") {
                        $('#followup_comments_text_err').text('Other Reason is Required');
                        err++;
                    } else {
                        reason = other_reason;
                    }
                }
                if (appointment_date == '') {
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                } else {
                    $('#re_app_date_err').text('');
                }

                if (appointment_time == '') {
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                } else {
                    $('#re_app_time_err').text('');
                }

                // appointment_date = document.querySelector('input[name="appointment_date"]').value;
                // appointment_time = document.querySelector('input[name="appointment_time"]').value;
            }


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            // if(document.getElementById('hot_lead').checked){
            //   hot_lead=1;
            // }else{
            //   hot_lead=0;
            // }

            if (err == 0) {
                $('#rescheduleBtn').prop('disabled', true);
                fetch(`/appointment_update_pb/${resheduleid}`, {
                        method: 'post',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            progressed: progressed,
                            app_score: app_score,
                            convo_message: convo_message,
                            // hot_lead: hot_lead,
                            reason: reason,
                            appointment_date: appointment_date,
                            appointment_time: appointment_time,
                            pb: 1,
                        }),
                    })

                    .then(data => {
                        if (data.status === 200) {
                            toastr.success('Appointment Updated successfully!');
                            $('#rescheduleBtn').prop('disabled', true);
                            location.reload();
                        } else {
                            toastr.error('Appointment Failed to update!');
                            $('#rescheduleBtn').prop('disabled', false);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating category:', error);
                        $('#rescheduleBtn').prop('disabled', false);

                    });
            } else {
                $('#rescheduleBtn').prop('disabled', false);
            }

        }
        // new appointment
        let resheduleagain_id;

        function openResheduleModalAgain(categoryId, name, mobile) {
            $('#lead_name_app_again').html(name);
            $('#lead_phone_app_again').html(mobile);
            resheduleagain_id = categoryId;
            // Function to format date to '10-Jun-2024'
            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/edit_appointment/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;
                        document.getElementById('lead_id_again').value = lead.lead_id;
                        $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                        // document.getElementById('lead_id_again').value = formatDate(lead.lead_id);
                        // document.getElementById('app_time_again').value = lead.appointment_time;
                        // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                        // console.log('Appointment Count:', data.data.appointmentCount);
                        $('#app_count_again').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                if (category.app_score === 1) {
                                    var score =
                                        `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === -1) {
                                    var score =
                                        `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === 0) {
                                    var score =
                                        `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else {
                                    var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                                }
                                const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block text-dark fs-8"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="Last Followup Date">${formatTime(category.appointment_time)}</div>
                                </td>
                                <td>
                                    <label
                                        class="text-black fw-semibold fs-7">${category.staff_name}</label>
                                </td>
                                <td>
                                <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}
                                        </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ? category.reason : '-'}">${category.reason ? category.reason : '-'}
                                        </div>
                                </td>
                            </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                        $('[data-bs-toggle="tooltip"]').tooltip();


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                    $('[data-bs-toggle="tooltip"]').tooltip();
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });

            fetch(`/appointment_history/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        //   console.log(data)
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        $('#apptmnt_count_again').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('appointmentLeadIdsTableBodyAgain');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                const row = `<tr>
                                <td>${index + 1}</td>
                               <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="text-truncate max-w-100px" title="${category.appointment_category}">${category.appointment_category !== null ? category.appointment_category : '-'}</label>
                                </td>
                                 <td>
                                    
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_reason || '-'}">
                                         ${category.appointment_reason || '-'}</div>
                                </td>
                               <td>
                                  <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                         ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                </td>
                                <td>
                                  ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                        category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                        category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                        '<span>-</span>'}
                            </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                    $('[data-bs-toggle="tooltip"]').tooltip();
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });
        }

        function toggleInputField_followup(value) {
            var followupReasonDiv = document.getElementById('followup_reason_div');
            var followupReasonText = document.getElementById('followup_reason_text');
            // var followupCommentsDiv = document.getElementById('followup_comments_div');
            var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById(
                'app_reason').selectedIndex + 1) + ')');
            // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

            if (value == '1') {
                followupReasonDiv.style.display = 'block';
                followupReasonText.setAttribute('required', 'required');
            } else {
                followupReasonDiv.style.display = 'none';
                followupReasonText.removeAttribute('required');
            }

            // if (commentsCheck == '1') {
            //     followupCommentsDiv.style.display = 'block';
            // } else {
            //     followupCommentsDiv.style.display = 'none';
            // }
        }
    </script>
    <script>
        function create_proposal_func(id, name, leadId) {
            $('#proposal_lead_name').text(name)
            $('#proposal_lead_genrate_id').text(leadId)
            $('#proposal_lead_id').val(id)
        }

        function createProposal() {

            var lead_id = $('#proposal_lead_id').val();

            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            if (lead_id) {
                $.ajax({
                    url: '/create_lead_proposal', // Your encryption route
                    type: 'POST',
                    data: {
                        lead_id: lead_id,
                        _token: csrfToken // Include CSRF token here
                    },
                    success: function(encrypted_lead_id) {
                        // Redirect to the desired route with the encrypted ID
                        window.location.href = '/manage_proposal/proposal_add/' + encrypted_lead_id;
                    },
                    error: function(xhr) {
                        toastr.error('Please Try Again Later');
                    }
                })
            } else {
                toastr.error('Lead Id is Missing');
            }

            ;
        }

        function revised_proposal_func(id, name, leadId, proposal) {
            $('#proposal_lead_name').text(name)
            $('#proposal_lead_genrate_id').text(leadId)
            $('#proposal_lead_id').val(id)
            $('#proposal_list').html('')

            var html = ""
            if (proposal.length > 0) {
                proposal.forEach(function(data, index) {
                    var printurl = 'manage_proposal/print_proposal/' + data.encrypt_id;
                    var viewurl = 'manage_proposal/proposal_view/' + data.encrypt_id;


                    html = `
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count"> ${(proposal.length - index) > 10 ? (proposal.length - index) : ('0' + (proposal.length - index))}</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">${data.proposal_id}</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.estimate_date)}</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.due_date)}</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; ${formatCurrency(data.grant_total_amount)}</label>
                                            </div>
                                            <div class="d-block text-end">
                                            
                                                 <a href="{{ url('${viewurl}') }}" target="_blank" class="btn btn-icon btn-sm me-2" title="View Proposal" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                               
                                               
                                                
                                                <a href="{{ url('${printurl}') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                `;
                    $('#proposal_list').append(html)
                })
            }

        }

        function formatCurrency(amt) {
            var roundedAmt = parseFloat(amt);
            var isWhole = Number.isInteger(roundedAmt);

            return roundedAmt.toLocaleString('en-IN', {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2
            });
        }

        function reviseProposal(id) {

            var proposal_id = id;

            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            if (proposal_id) {
                $.ajax({
                    url: '/revise_lead_proposal', // Your encryption route
                    type: 'POST',
                    data: {
                        proposal_id: proposal_id,
                        _token: csrfToken // Include CSRF token here
                    },
                    success: function(encrypted_lead_id) {
                        // Redirect to the desired route with the encrypted ID
                        window.location.href = '/manage_proposal/proposal_revise/' + encrypted_lead_id;
                    },
                    error: function(xhr) {
                        toastr.error('Please Try Again Later');
                    }
                })
            } else {
                toastr.error('Lead Id is Missing');
            }

            ;
        }
    </script>
    <script>
        function dropModal(id, leadName, staffId) {
            $('#kt_modal_lead_drop').modal('show');
            $('#kt_modal_lead_drop .lead-name').text(leadName);
            $('#staff_id_drop').val(staffId);

            $('#lead_id_drop').val(id);

            $('#kt_modal_lead_drop .btn-primary').off('click').on('click', function() {
                const reason = $('#reason_edit').val();
                const otherReason = $('#drop_reason_text').val();
                const comments = $('#drop_comments_text').val();

                if (!reason) {
                    $('#reason_edit_select_err').text('Reason is Required');
                    return false;
                } else {
                    $('#reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
                    $('#drop_comments_edit_err').text('Comments are required');
                    return false;
                } else {
                    $('#drop_comments_edit_err').text('');
                }

                if (reason == '1' && !otherReason.trim()) {
                    $('#reason_edit_err').text('Other Reason is required');
                    return false;
                } else {
                    $('#reason_edit_err').text('');
                }
            });
        }

        function toggleInputField(value) {
            var dropReasonDiv = document.getElementById('drop_reason_div');
            var dropReasonText = document.getElementById('drop_reason_text');
            var dropCommentsDiv = document.getElementById('drop_comments_div');
            var selectedOption = document.querySelector('#reason_edit option:nth-child(' + (document.getElementById(
                'reason_edit').selectedIndex + 1) + ')');
            var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

            if (value == '1') {
                dropReasonDiv.style.display = 'block';
                dropReasonText.setAttribute('required', 'required');
            } else {
                dropReasonDiv.style.display = 'none';
                dropReasonText.removeAttribute('required');
            }

            if (commentsCheck == '1') {
                dropCommentsDiv.style.display = 'block';
            } else {
                dropCommentsDiv.style.display = 'none';
            }
        }
    </script>
    <script>
        function successSummary(name, mobile, message, count, call_count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("succ_lead_name").innerText = name;
            document.getElementById("succ_lead_mobile").innerText = mobile;
            document.getElementById("lead_succ_msg").innerText = message;
            document.getElementById("lead_succ_count").innerHTML = formattedCount;
            document.getElementById("lead_succ_call_count").innerHTML = formattedCallCount;
        }

        function failSummary(name, mobile, message, count, call_count) {

            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("fail_lead_name").innerText = name;
            document.getElementById("fail_lead_mobile").innerText = mobile;
            document.getElementById("lead_fail_msg").innerText = message;
            document.getElementById("lead_fail_count").innerHTML = formattedCount;
            document.getElementById("lead_fail_call_count").innerHTML = formattedCallCount;
        }

        function dangerSummary(name, mobile, daysDiff, expectedCount, outgoingCount, count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedOutgoingCount = outgoingCount.toString().padStart(2, '0');
            let formattedExpectedCount = expectedCount.toString().padStart(2, '0');
            let message = `Outgoing calls are mismatched!`;

            document.getElementById("danger_lead_name").innerText = name;
            document.getElementById("danger_lead_mobile").innerText = mobile;
            document.getElementById("lead_danger_days").innerText = daysDiff;
            document.getElementById("danger_lead_msg").innerText = message;
            document.getElementById("lead_danger_expected").innerText = formattedOutgoingCount;
            document.getElementById("lead_danger_call_count").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_call_count_actual").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_count").innerHTML = formattedCount;
        }
    </script>
    <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
        $(document).ready(function() {
            $(".common_time_class_new").flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                defaultHour: new Date().getHours(),
                defaultMinute: new Date().getMinutes()
            });
        });
    </script>
    <script>
        function followupSchedule(leadId, name, phone) {
            $('#lead_id').val(leadId); // Set the lead ID in the hidden input field
            $('#lead_name_app').html(name);
            $('#lead_phone_app').html(phone);
            $('#kt_modal_follow_up_lead').modal('show'); // Show the modal
        }

        function FollowupvalidateForm() {
            var err = 0;

            // Validate knowledge Name
            var lead_apt_sch = document.getElementById("lead_apt_sch").value.trim();
            if (lead_apt_sch === "") {
                document.getElementById('apt_date_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('lead_apt_sch').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('lead_apt_sch').classList.remove('error_msg');
                document.getElementById('apt_date_err').innerHTML = '';
            }
            // Validate knowledge Name
            var apt_time_followp = document.getElementById("apt_time_followp").value.trim();
            if (apt_time_followp === "") {
                document.getElementById('apt_time_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('apt_time_followp').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('apt_time_followp').classList.remove('error_msg');
                document.getElementById('apt_time_err').innerHTML = '';
            }
            if (err === 0) {
                $('#followupForm').submit();
                $('#followupBtn').prop('disabled', true);
            } else {
                $('#followupBtn').prop('disabled', false);
            }
        }
        // Add event listeners to clear error messages on input
        document.getElementById('lead_apt_sch').addEventListener('input', function() {
            document.getElementById('apt_date_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
        // Add event listeners to clear error messages on input
        document.getElementById('apt_time_followp').addEventListener('input', function() {
            document.getElementById('apt_time_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
    </script>
    <script>
        function populateViewModal(categoryId) {
            fetch(`/lead_view/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data;
                        // console.log(lead);

                        // Function to format date to '10-Jun-2024'
                        function formatDate(dateString) {
                            if (!dateString) return '-'; // Handle null or undefined dates
                            const date = new Date(dateString);
                            const day = date.getDate().toString().padStart(2, '0');
                            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct",
                                "Nov", "Dec"
                            ];
                            const month = monthNames[date.getMonth()];
                            const year = date.getFullYear();
                            return `${day}-${month}-${year}`;
                        }


                        $('#lead_id_view').html(lead.lead_id || '-');
                        $('#lead_created').html(formatDate(lead.created_at));
                        $('#lead_name_view').html(lead.lead_name || '-');
                        $('#lead_mobile_view').html(lead.lead_mobile || '-');
                        $('#lead_alternate_view').html(lead.lead_alternate_mobile || '-');
                        $('#lead_email_view').html(lead.lead_email_id || '-');

                        const gender = lead.lead_gender === 1 ? 'Male' : (lead.lead_gender === 2 ? 'Female' : 'Other');
                        $('#lead_gender_view').html(gender);

                        $('#lead_dob_view').html(formatDate(lead.lead_dob));

                        const maritalStatus = lead.lead_marital_status === 1 ? 'Married' : (lead.lead_marital_status ===
                            2 ? 'Unmarried' : '-');
                        $('#lead_marital_view').html(maritalStatus);


                        let imageUrl = lead.potential_type_image ?
                            `{{ asset('potential_image/') }}/${lead.potential_type_image}` : '';

                        document.getElementById('potential_image_view').src = imageUrl;

                        $('#view_lead_auto_id').html(lead.lead_id || '-');
                        $('#lead_type_view').html(lead.lead_type_name || '-');
                        $('#lead_source_view_h').html(lead.lead_source_name || '-');
                        $('#view_leadsource').html(lead.leadsourcename || '-');
                        $('#view_university').html(lead.universityname || '-');
                        $('#lead_potential_view').html(lead.potential_type_name || '-');
                        // $('#view_edit_id').val(lead.sno || '');
                        $('#view_address').html((lead.address || '') + ' ' + lead.citiesname + ' ' + lead.statename +
                            ' ' + lead.name);
                        $('#view_leadtype').html(lead.leadtypename || '-');
                        $('#view_potentialtype').html(lead.potential_type_name || '-');
                        $('#view_comments').html(lead.lead_comments || '-');
                        $('#view_category').html(lead.product_category_name || '-');
                        $('#view_service').html(lead.product_name || '-');

                        // if(lead.status == 4) {
                        //     $('#edit_icon').hide();
                        // } else {
                        //     $('#edit_icon').show();
                        // }

                        // Assuming lead.lead_knowledge_tags is your JSON array or string
                        let tagsString = '-';
                        if (lead.lead_knowledge_tags) {
                            const tagsArray = Array.isArray(lead.lead_knowledge_tags) ? lead.lead_knowledge_tags : JSON
                                .parse(lead.lead_knowledge_tags);
                            tagsString = tagsArray.map(tag => tag.value).join(', ');
                        }
                        $('#lead_tag_view').html(tagsString);

                    } else {
                        console.error('Error fetching category:', data.message);
                        // Optionally, show an alert or update the UI to reflect the error.
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                    // Optionally, show an alert or update the UI to reflect the error.
                });
        }
    </script>

     <!--begin::Modal - Reset Call -->
    <div class="modal fade" id="kt_modal_unmark_hot_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">
                <span id="unmark_message"></span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-danger me-3" onclick="resetFunc()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reset Call -->

    <script>
        function unMarkHotLead(id, name, phone) {

            document.querySelector('#kt_modal_unmark_hot_lead .btn-danger').setAttribute('data-id', id);
            $('#unmark_message').html(
                `Are you sure you want to Unmark Hot Lead ?
                <br><br>
                <b class="text-success fw-bold fs-4">${name}</b><br>
                <b class="text-black fw-bold fs-6">${phone}</b>`);
        }

        function resetFunc() {
            var categoryId = document.querySelector('#kt_modal_unmark_hot_lead .btn-danger').getAttribute('data-id');

            fetch('/unmark_hot_lead/' + categoryId, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        location.reload();
                        toastr.success(data.message);
                    } else {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {

                });
        }
    </script>

@endsection
