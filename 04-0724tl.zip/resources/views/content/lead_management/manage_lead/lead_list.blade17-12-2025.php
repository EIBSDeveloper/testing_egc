@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
    .qr-badge {
          background: linear-gradient(135deg, #e0f7fa, #b2ebf2);
          color: #006064;
          padding: 2px 6px;
          border: 2px dashed #0097a7;
          border-radius: 8px;
          font-weight: 600;
          font-size: 0.85rem;
          box-shadow: 0 2px 6px rgba(0,0,0,0.1);
          transition: all 0.3s ease-in-out;
        }
        
        .qr-badge i {
          color: #006064;
        }
        .qr-badge2 {
            background: linear-gradient(135deg, #e0f7fa, #717fbf);
            color: #cd11ab;
            padding: 2px 12px;
            /* border: 2px dashed #0097a7; */
            border-radius: 8px;
            font-weight: 600;
            /* font-size: 0.85rem; */
            /* box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1); */
            /* transition: all 0.3s ease-in-out;*/
        }
        .qr-badge2 i {
          color: #cd11ab;
        }
       .source-label {
        position: relative; /* Ensure the label is positioned relative for absolute positioning of ::before */
        display: inline-block;
        }
     .lead-card {
            width: 160px;
            height: 200px;
            padding-bottom: 20px !important;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            text-align: center;
            cursor: pointer;
        }
    
        .lead-card img {
            width: 100px;
            height: auto;
            object-fit: contain;
            image-rendering: crisp-edges;
        }
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 2;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
        .highlight-row {
            position: relative;
            width: 200px;
            height: 50px;
            overflow: hidden;
    
        }
    </style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #c2fbb6 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Customer</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #fcff66 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #6fd1fb !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Hot Lead</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: lightpink !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Followup Pending</label>
                    </div>
                    <div class="btn-group">
                        <button class="btn btn-label-warning btn-sm fs-7 border border-gray-400i dropdown-toggle"
                            type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false" style="color: #000000 !important;">
                            <span>Potential Type</span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end w-225px px-3 pt-2 pb-1"
                            aria-labelledby="dropdownMenuButton">
                            @if(isset($potential_list))
                            @foreach($potential_list as $plist)
                            <li>
                                <div class="d-flex align-items-center border-bottom mb-1 pb-1">
                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                        @if ($plist->potential_type_image != '' && file_exists(public_path('potential_image/' . $plist->potential_type_image)))
                                        <img src="{{ asset('potential_image/' . $plist->potential_type_image) }}"
                                            alt="Premium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                        @endif
                                    </div>
                                    <div>{{ $plist->potential_type_name}}</div>
                                </div>
                            </li>
                            @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                        <div class="scroll-container" id="scrollContainer">
                            @php
                                $module_name = 'Lead Management';
                                $menu_name = 'Manage Lead';
                            @endphp
                            @if(auth()->user()->hasPermission($module_name, 'Raw Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 ">
                                        <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                            alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Raw Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $rawLeadCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Lead Bank', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/lead_bank')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                            alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead Bank</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadbankCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/manage_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active">
                                        <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                            class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Lead</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadOriginalCount??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Spam Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_spam_count>0)
                                    <a href="{{url('/spam_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Spam Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_spam_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Spam Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Dead lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_drop_count>0)
                                    <a href="{{url('/drop_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Dead Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_drop_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Dead Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Internal Calls Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/internal_calls_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                            alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Internal Calls</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $internal_calls_count??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Today Followup', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    <a href="{{url('/today_followup_lead')}}"
                                        class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                        style="background-color: #FCFF66 !important;">
                                        <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                            alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Today Followup</span>
                                        <span
                                            class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalFollowup??0) }}</span>
                                    </a>
                                </li>
                            </div>
                            @endif
                        </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                           
                            <div class="tab-pane fade show active" id="tab_lead" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-8 d-flex flex-wrap align-items-center mb-2">
                                        <a href="javascript:;" class="lead-card border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total Number of Leads">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Total Leads</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/lead.gif') }}" alt="Lead Icon" class="img-fluid">
                                            </div>
                                            <div class="d-block">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ sprintf('%02d',$leadOriginalCount) }}</div>
                                            </div>
                                        </a>
                                        
                                        <a href="javascript:;" class="lead-card border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Current Month Leads" onclick="current_month_lead_func()">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Leads (
                                                <?php echo date('M'); ?>)
                                            </div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/appointment.gif') }}" alt="Current Month Lead Icon" class="img-fluid">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ sprintf('%02d',$currentMonthLeadCount) }}</div>
                                            </div>
                                        </a>
                                        <form id="month_lead_form" method="POST" action="/manage_lead"> @csrf <input type="hidden" name="month_lead_filt" value="1"></form>
                                        <a href="javascript:;" class="lead-card border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Average Conversion Rate">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Total ACR</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/calendar.gif') }}" alt="Avg. Conversion Icon"
                                                    class="img-fluid">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ $percentageover }}</div>
                                            </div>
                                        </a>
                                        
                                        <a href="javascript:;" class="lead-card border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Current Month Conversion">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Conversion (
                                                <?php echo date('M'); ?>)
                                            </div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/convertion.gif') }}" alt="Current Month Conversion Icon"
                                                    class="img-fluid">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ $percentagecurrentmonth }}</div>
                                            </div>
                                        </a>
                                        
                                        <a href="javascript:;" class="lead-card border border-2 p-2" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Pending Followup" onclick="pending_followup_func()">
                                            <div class="text-dark fw-semibold fs-6 mb-1">Pending Followup</div>
                                            <div class="mb-3">
                                                <img src="{{ asset('assets/phdizone_images/lead/pending_followup.gif') }}" alt="Pending Followup Icon"
                                                    class="img-fluid">
                                            </div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-gray-600i rounded fw-bold fs-5">{{ sprintf('%02d',$follwup_count) }}</div>
                                            </div>
                                        </a>   
                                        <form id="pending_followup_form" method="POST" action="/manage_lead"> @csrf <input type="hidden" name="pending_followUp_fill" value="1"></form>
                                    </div>
                                    <div class="col-lg-4 mb-2">
                                        <div class="d-flex align-items-center justify-content-end flex-wrap">
                                             @if(auth()->user()->hasPermission($module_name, 'Add Spam', $menu_name))
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_add_spam_lead">
                                                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Spam
                                            </a>
                                             @endif
                                              @if(auth()->user()->hasPermission($module_name, 'Add Lead', $menu_name))
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead">
                                                <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Lead
                                            </a>
                                             @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Export', $menu_name))
                                            <!--<a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2" id="export_excel">-->
                                            <!--    <span data-bs-toggle="tooltip" data-bs-placement="bottom"-->
                                            <!--        title="Export"><i class="mdi mdi-calendar-export-outline"></i></span>-->
                                            <!--</a> -->
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                                            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2"
                                                id="filter">
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Filter"><i
                                                        class="mdi mdi-filter-outline text-center"></i></span>
                                            </a>
                                            @endif
                                        </div>
                                        
                                    </div>
                                </div>
                                <div class="filter_tbox" style="display: none;">
                                    <form id="filter_form" method="POST" action="/manage_lead">
                                    @csrf
                                    <div class="row py-1">
                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                        <input type="hidden" name="filter_on" value="1">
                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                       
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Gender</label>
                                            <select class="select3 form-select" name="gender_fill" id="gender_fill">
                                                <option value="" >All</option>
                                                <option value="1" @if($gender_fill =="1") selected @endif>Male</option>
                                                <option value="2" @if($gender_fill =="2") selected @endif>Female</option>
                                                <option value="3" @if($gender_fill =="3") selected @endif>Others</option>
                                            </select>
                                        </div>
                                       
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Source</label>
                                            <select class="select3 form-select" id="lead_source_fill" name="lead_source_fill">
                                                <option value="" >All</option>
                                                    @if (isset($CourseCategory))
                                                      @foreach ($CourseCategory as $course_ty_fill)
                                                      <option value="{{ $course_ty_fill->sno }}" @if($course_ty_fill->sno == $lead_source_fill) selected @endif>{{ $course_ty_fill->lead_source_name }}</option>
                                                      @endforeach
                                                  @endif
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Potential Type</label>
                                            <select class="select3 form-select" id="potential_type_fill" name="potential_type_fill">
                                                <option value="" >All</option>
                                                 @if (isset($PotentialType))
                                                  @foreach ($PotentialType as $course_ty_fill)
                                                  <option value="{{ $course_ty_fill->sno }}" @if($course_ty_fill->sno== $potential_type_fill) selected @endif>{{ $course_ty_fill->potential_type_name }}</option>
                                                  @endforeach
                                                  @endif
                                            </select>
                                        </div><div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Sales Person</label>
                                            <select id="staff_fill" name="staff_fill"
                                                class="select3 form-select">
                                                <option value="">Select Sales Person</option>
                                                @if (isset($staff_filter_list))
                                                @foreach ($staff_filter_list as $staff_li)
                                                <option value="{{ $staff_li->sno }}" @if($staff_li->sno==$staff_fill) selected @endif>{{ $staff_li->nick_name }} - {{ $staff_li->staff_name }}</option>
                                                @endforeach
                                                @endif
                                                <option value="0">Old Staff</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                                            <select class="select3 form-select" name="lead_status_fill" id="lead_status_fill">
                                                <option value="">All</option>
                                                <option value="0" @if($lead_status_fill==0) selected @endif>Active</option>
                                                <!--<option value="1" @if($lead_status_fill==1) selected @endif>Inactive</option>-->
                                                <option value="4" @if($lead_status_fill==4) selected @endif>Customer</option>
                                                <option value="5" @if($lead_status_fill==5) selected @endif>Dead</option>
                                                <option value="7" @if($lead_status_fill==7) selected @endif>Spam</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Products</label>
                                            <select class="select3 form-select" id="product_fill" name="product_fill[]" multiple>
                                                <option value="" >All</option>
                                                    @if (isset($product_list))
                                                      @foreach ($product_list as $product)
                                                      <option value="{{ $product->sno }}" @if($product->sno == $product_fill) selected @endif>{{ $product->product_name }}</option>
                                                      @endforeach
                                                  @endif
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
                                            <select class="select3 form-select" name="dt_fill_issue_rpt"
                                                id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                                                <option value="all" @if($date_filter =="all") selected @endif>All</option>
                                                <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                                                <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                                                <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                                                <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text bg-gray-200"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                                                    class="form-control" value="<?php echo date('d-M-Y'); ?>" disabled />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_this_month_dt_fill"
                                                    placeholder="Select Date" class="form-control this_month_dt_fill"
                                                    value="<?php echo date('M-Y'); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_custom_from_dt_fill"
                                                    placeholder="Select Date" readonly name="from_date_fillter_textbox"  class="form-control common_date_class"
                                                    value="<?php echo date('d-M-Y'); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                            <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                            <div class="input-group input-group-merge">
                                                <span class="input-group-text"><i
                                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                <input type="text" id="lead_custom_to_dt_fill"
                                                    placeholder="Select Date" class="form-control common_date_class" readonly name="to_date_fillter_textbox"
                                                    value="<?php echo date('d-M-Y'); ?>" />
                                            </div>
                                        </div>
                                        <div class="col-lg-3 mb-2">
                                             <label></label>
                                             <div><input class="form-check-input me-1"
                                                            type="checkbox" name="tranfer_order" id="tranfer_order" value="1" {{$tranfer_order == 1 ? 'checked' :''}} >
                                                            <span class="text-dark mb-1 fs-6 fw-semibold">Order By Transfer</span>
                                              </div>
                                        </div>
                                      
                                    </div> 
                                  <div class="d-flex justify-content-end mb-2">
                                        <a href="{{ url('/manage_lead') }}" type="button"
                                            class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
                                        </a>
                                        <button type="submit"
                                            class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                                    </div>
                                   
                                    </form>
                                </div>
                                <div class="row">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="mb-4">
                                            @php $perpage_count = $perpage ? $perpage : 25; @endphp
                                            <div>
                                                <span>Show</span>
                                                <br>
                                                <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                                    @php
                                                    $options = [10, 25, 100, 500]; // Define available options
                                                    @endphp
                                                    @php foreach ($options as $option): @endphp
                                                    <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                        @php echo $option; @endphp
                                                    </option>
                                                    @php endforeach; @endphp
                                                </select>
                                            </div>
                                        </div>
                                        <div class="ms-auto">
                                              @if(auth()->user()->hasPermission($module_name, 'Bulk Transfer', $menu_name))
                                            <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_bulk_convert_sales_person"  id="bulkConversionBtn" style="display:none">
                                                <span class="btn btn-sm fw-bold btn-primary fs-7 me-2 mb-2 "><i class="mdi mdi-transfer fs-5"></i> Bulk
                                                Transfer</span>
                                            </a>
                                            @endif
                                        </div>
                                        <div class="mb-2">
                                            <form id="filter_form" method="POST" action="/manage_lead">
                                                @csrf
                                                <div class="d-flex align-items-center gap-2">
                                                    <div class="mb-1">
                                                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                        <input type="hidden" name="filter_on" value="0">
                                                        <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />      
                                                        <input
                                                        type="text"
                                                        class="form-control"
                                                        id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                                        placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                                                        />
                                                    </div>
                                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1" onclick="search_filter_func()">Search</button>
                                                     <a href="{{ url('/manage_lead') }}" type="button"
                                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                                                    </a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                      <input type="hidden" id="view_edit_id" />
                                      <form id="bulk_request_pay_form" method="POST">
                                      @csrf
                                      <input type="hidden" name="bulk_assign_staff_id" id="bulk_assign_staff_id">
                                        <table
                                            class="table align-top table-row-dashed table-striped table-hover gy-1 gs-2 lead_list list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                     @if(auth()->user()->hasPermission($module_name, 'Bulk Transfer', $menu_name))
                                                    <th class="min-w-25px">
                                                       
                                                        <input class="form-check-input border border-gray-300 me-1"
                                                            type="checkbox" name="all" id="bulk_checkall" onchange="showConversionBtn()">
                                                        
                                                        <span class="fs-7">All</span>
                                                    </th>
                                                    @endif
                                                    <th class="min-w-150px">Lead</th>
                                                    <th class="min-w-100px"><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">RD </span><span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Followup Date"> / LFD</th>
                                                    <!--<th class="min-w-100px text-center">Mobile / LFD / Calls</th>-->
                                                    <th class="min-w-80px">Sales Person</th>
                                                    <th class="min-w-100px">Potential Type</th>
                                                    <th class="min-w-100px text-center">Proposal</th>
                                                    <th class="min-w-100px">Status</th>
                                                    <th class="min-w-80px">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                                @if (count($leads) > 0)
                                                    @foreach ($leads as $i=> $category)
                                                        <tr class="{{ ($category->just_dial_id > 0 && $category->lead_status_id == 1) ? 'highlight-row' : '' }}" style="background-color: 
                                        
                                                            @if($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)lightpink;@elseif($category->status != 4 && $category->is_hot_lead == 1)#6fd1fb;@else{{ $category->lead_bg_color }} {{-- Use the existing color otherwise --}}
                                                            @endif;">
                                                            @if(auth()->user()->hasPermission($module_name, 'Bulk Transfer', $menu_name))
                                                            <td>
                                                                
                                                                @php
                                                                    $encryptLeadId = $helper->encrypt_decrypt($category->sno, 'encrypt');
                                                                @endphp
                                                                @if($category->lead_status_id == 3)
                                                                    @if(intval($hot_lead_days <= $category->formattedDayDifference))
                                                                        <input class="form-check-input bulk_chk 1" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}"  data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                                    @endif
                                                                @elseif( $category->status == 0 )
                                                                    @if($category->lead_status_id != 3)
                                                                        <input class="form-check-input bulk_chk 2" type="checkbox" id="checked<?php echo $i; ?>" name="checked[<?php echo $i; ?>]" value="{{ $category->sno }}" data-created-by="{{ $category->created_by }}"  onchange="singleShowConversionBtn()">
                                                                    @endif
                                                                @endif
                                                               
                                                            </td> 
                                                            @endif
                                                            <td>
                                                                <div class="d-flex align-items-center gap-1">
                                                                    @if($category->is_hot_lead == 2)
                                                                    <div data-bs-toggle="tooltip" data-bs-placement="bottom" title="Hot Lead Star">
                                                                         <img src="{{ asset('assets/phdizone_images/lead/Star_animate.gif') }}" alt="Hot Lead Star" class="w-50px h-50px text-black fw-bold">
                                                                    </div>
                                                                    @endif
                                                                    @if( $category->lead_appointment_status == 1)
                                                                    <div class="animation-blink" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Appointment Onprogress">
                                                                         <img src="{{ asset('assets/phdizone_images/lead/appointment.ico') }}" alt="Appointment Onprogress Icon" class="w-30px h-30px text-black fw-bold">
                                                                    </div>
                                                                     @endif
                                                                    <div class="ms-1 mb-0">
                                                                        <div class="d-flex align-items-center gap-2">
                                                                            <label class="fs-7 text-nowrap text-black fw-semibold">{{ trim($category->lead_name) }}</label>
                                                                            
                                                                             @if (isset($category->productsData) && count($category->productsData) > 0)
                                                                            <span class="text-dark fs-8 fw-semibold cursor-pointer" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="mdi mdi mdi-information fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product"></span></span>
                                                                            <div class="dropdown-menu dropdown-menu-start w-350px">
                                                                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Products</div>
                                                                                <hr class="mt-0 mb-2 border-dark">
                                                                                <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                                    @if (isset($category->productsData))
                                                                                    @foreach ($category->productsData as $product)
                                                                                         <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                                                <div class="text-black mb-1 fw-semibold fs-5 me-2">&#9733;</div>
                                                                                                <div class="d-block">
                                                                                                    <div class="text-black fw-semibold text-justify fs-7">{{$product->product_name}}</div>
                                                                                                    <div class="fw-semibold text-info fs-8">{{$product->product_category_name}}</div>
                                                                                                </div>
                                                                                            </div>
                                                                                    @endforeach
                                                                                    @endif
                                                                                </div>
                                                                            </div>
                                                                             @endif
                                                                             @if($category->transfer_status == 1)
                                                                           <span id="" class="d-block boom badge text-black rounded-circle fw-semibold fs-8 p-1  mt-1 leadBoom"  data-bs-toggle="modal" data-bs-target="#kt_modal_lead_transfer_log" onclick="leadTransfer('{{ $category->sno }}', '{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $category->lead_source_name }}', '{{ $category->registered_date }}')"
                                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                        title="Transfer"
                                                                                        style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                                        T</span>
                                                                            @elseif ($category->lead_status_id == 1 && $category->lead_score == null && ($category->lead_condition == 1 || $category->lead_condition == 2 && $category->status != 1))
                                                                            <span id="" class="d-block boom badge text-black rounded fw-semibold fs-8 py-0 mt-1 leadBoom"
                                                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                        title="New Lead"
                                                                                        style="background-color: #55e531 !important;border:1px dashed #7239ea !important;">
                                                                                        New Lead</span>
                                                                            @endif
                                                                        </div>
                                                                        <div class="d-block">
                                                                            <div class="d-flex align-items-center mb-0">
                                                                                @if($category->lead_mobile)
                                                                                     @if($category->status != 7)
                                                                                        <label class="fs-7 text-dark fw-semibold me-1 text-nowrap">
                                                                                        @php
                                                                                            $call_chk = isset($category->inter_calls)? $category->inter_calls:0 ;
                                                                                            $countryCode = $call_chk == 0 ? '+91' : '+' . $category->inter_calls;
                                                                                            $mobileNumber = $category->status == 1 ? 'XXXXXXXXXX' : $category->lead_mobile;
                                                                                        @endphp
                                                                                        {{ $countryCode }} {{ $mobileNumber }} 
                                                                                    </label>
                                                                                     @endif
                                                                                     @if($category->status == 7)
                                                                                        <label class="fs-7 text-black fw-semibold me-1 text-nowrap" title="Mobile No">
                                                                                            {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}
                                                                                        </label>
                                                                                     @endif
                                                                                    @php
                                                                                        $phoneVerifyContent = json_decode($category->phone_verify_content, true);
                                                                                    @endphp
                                                                                    @if ($category->phone_verify_status==1)
                                                                                    <a href="javascript:;"
                                                                                        class="fs-7 text-black fw-semibold me-1"
                                                                                        onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                            title="Mobile No Verified"><i
                                                                                                class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                                                    </a>
                                                                                    
                                                                                    @elseif ($category->phone_verify_status==2)
                                                                                    <a href="javascript:;"
                                                                                        class="fs-7 text-black fw-semibold me-1"
                                                                                        onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                        <span data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Mobile No. Not Verified">
                                                                                            <svg class="w-20px h-20px"
                                                                                                enable-background="new 0 0 500 500"
                                                                                                viewBox="0 0 500 500"
                                                                                                id="hand-draw-white-cross-mark-on-red-circle">
                                                                                                <rect id="Layer_1" fill="#fff0f0"
                                                                                                    display="none"></rect>
                                                                                                <g id="Layer_2">
                                                                                                    <circle cx="250" cy="250"
                                                                                                        r="200" fill="#f32f45"></circle>
                                                                                                    <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                                                    <path fill="#fff"
                                                                                                        d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                                    </path>
                                                                                                </g>
                                                                                            </svg>
                                                                                        </span>
                                                                                    </a>
                                                                                    @endif
                                                                                @endif
                                                                            </div>
                                                                            <div class="d-flex align-items-center mb-0">
                                                                                @if($category->lead_email_id)
                                                                                 <label class="fs-7 text-dark fw-semibold me-1 text-truncate max-w-170px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$category->lead_email_id}}"> {{$category->lead_email_id}}</label>
                                                                                @endif
                                                                            </div>
                                                                        </div>
                                                                         <div class="d-block text-dark fs-8 mb-2 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Id">{{$category->lead_id??''}}</div>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex align-items-center justify-content-start mb-2 gap-2">
                                                                    <div>
                                                                         @if(auth()->user()->user_id > 2)
                                                                        <label class="badge text-black fw-semibold fs-8" style="background-color:rgb(78, 202, 94);" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Registered Date">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) :date($common_date_format, strtotime($category->created_at))}}</label>
                                                                        @else
                                                                        <label class="badge text-black fw-semibold fs-8 cursor-pointer" style="background-color:rgb(78, 202, 94);"  data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) :date($common_date_format, strtotime($category->created_at))}}</label>
                                                                        <div class="dropdown-menu dropdown-menu-end">
                                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_register_date_change" onclick="confirmChangeDate('{{ $category->sno }}','{{$category->lead_name}}','{{$category->registered_date}}')">Change Date</a>
                                                                        </div>
                                                                        @endif
                                                                        
                                                                        @if(isset($category->appointment_date))
                                                                        <hr class="mt-1 mb-1">
                                                                        <div class="d-block mt-1">
                                                                            <label class="badge bg-body text-danger fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Last Follow Up Date"> {{ $category->appointment_date ? date($common_date_format, strtotime($category->appointment_date)) :'' }}</label>
                                                                        </div>
                                                                        @endif
                                                                    </div>
                                                                    
                                                                    <!--<div class="avatar avatar-sm ">-->
                                                                        <a href="javascript:;" class="badge bg-info fs-8 rounded text-white fw-semibold me-1" >
                                        
                                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Life Time">{{ $category->formattedDifference ?? '0 day' }}</span>
                                                                            
                                                                            <!--<span-->
                                                                            <!--    class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-info fs-8 mt-n1"-->
                                                                            <!--    style="background-color: white !important;">{{ $category->outgoing_count }}</span>-->
                                                                              
                                                                        </a>
                                                                    <!--</div>-->
                                                                    
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div class="d-flex gap-2">
                                                                    <span class="text-truncate max-w-125px fw-semibold fs-7 text-black" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $category->nick_name ?? 'Old Staff' }}">{{ $category->staff_name ?? 'Old Staff' }}</span>
                                                                    <div class="avatar avatar-sm me-1">
                                                                        <a href="javascript:;" class="dropdown-item" onclick="openCallHistoryModal('{{ $category->sno }}','Outgoing','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}' ,'{{ $category->incoming_count }}','{{ $category->outgoing_count }}','{{ $category->missed_reject_count }}','{{ $category->dialed_count }}')"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_call_log">
                                                                            <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Outgoing Calls Count">
                                                                                <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                                    alt="Outgoing Call Icon"
                                                                                    class="w-15px h-15px text-black fw-bold">
                                                                            </div>
                                                                            @if($category->outgoing_count >0)
                                                                            <span
                                                                                class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                                style="background-color: #FFA500 !important;">{{ $category->outgoing_count }}</span>
                                                                                @endif
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                 <div class="d-block">
                                                                    @if($category->just_dial_id > 0)
                                                                        <label class="badge bg-white text-primary rounded fw-bold fs-6 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                                            <span class="jd-blue">Just</span><span class="jd-orange">dial</span>
                                                                        </label>
                                                                    @elseif($category->cloud_call_id > 0)
                                                                        <label class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                                            <i class="fas fa-cloud cc-icon"></i><span class="cc-purple">Cloud</span><span class="cc-purple">Call</span>
                                                                        </label>
                                                                    @elseif($category->call_tracker_id > 0)
                                                                        <label class="badge ct-orange text-white rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                                                <span>Tra<i class="mdi mdi-phone-in-talk ct-icon"></i>cker</span>
                                                                        </label>
                                                                    @elseif($category->website_id > 0)
                                                                        <label class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Lead Source">
                                                                            <span class="text-primary">Web</span><span class="text-primary">Site</span>
                                                                        </label>
                                                                    @elseif($category->lead_source_id == 20)
                                                                        <span class="qr-badge d-inline-flex align-items-center gap-1 fs-7" data-bs-toggle="tooltip"  data-bs-placement="bottom" title="Lead Source">
                                                                            <i class="mdi mdi-qrcode-scan fs-7"></i>{{ $category->lead_source_name ?? '-' }}
                                                                        </span>
                                                                    @else
                                                                        <label class="badge bg-secondary text-white rounded fw-semibold fs-8 "
                                                                            data-bs-toggle="tooltip" 
                                                                            data-bs-placement="bottom" 
                                                                            title="Lead Source">
                                                                            {{ $category->lead_source_name ??'-' }}
                                                                        </label>
                                                                     @endif
                                                                </div>
                                                            </td>
                                                            <td>
                                                                 <div class="d-flex align-items-center mt-2 gap-1">
                                                                     
                                                                  @if ($category->potential_type_image != '' && file_exists(public_path('potential_image/' . $category->potential_type_image)))
                                                                      <img src="{{ asset('potential_image/' . $category->potential_type_image) }}"
                                                                          alt="Image" class="w-35px h-35px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{$category->potential_type_name ?? ''}}">
                                                                  @else
                                                                        <a href="javascript:;"
                                                                            class="badge bg-label-danger border border-gray-400 rounded text-white fw-semibold fs-8 px-1 py-0"
                                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                                            aria-expanded="false"
                                                                            style="background-color: #F0913D !important;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Potential Type">
                                                                            <span><i class="mdi mdi-plus fs-5"></i></span>
                                                                        </a>
                                                                        <div class="dropdown-menu dropdown-menu-end">
                                                                             @if(isset($potential_list))
                                                                             @foreach($potential_list as $plist)
                                                                            <a href="javascript:;" class="dropdown-item border-bottom" data-bs-toggle="modal" data-bs-target="#kt_modal_premium_potential_type" onclick="potentialUpdate('{{$category->sno}}','{{$plist->sno}}')">
                                                                                <div class="d-flex align-items-center">
                                                                                    @if ($plist->potential_type_image != '' && file_exists(public_path('potential_image/' . $plist->potential_type_image)))
                                                                                    <div class="border border-primary rounded px-1 py-1 me-2">
                                                                                        <img src="{{ asset('potential_image/' . $plist->potential_type_image) }}" alt="Premium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                                                                    </div>
                                                                                    @endif
                                                                                    <div>{{$plist->potential_type_name}}</div>
                                                                                </div>
                                                                            </a>
                                                                            @endforeach
                                                                            @endif
                                                                        </div>
                                                                        
                                                                  @endif
                                                                  @if( $category->status != 7 && $category->spam_verified != 1)
                                                                  
                                                                      @if( $category->appointment_status == 1 && $category->status !== 4 && $category->status !== 10)
                                                                      <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_follow_up_lead_schedule" onclick="openResheduleModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom" title="Followup">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                                <span
                                                                                    class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup Count"
                                                                                    style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                <span
                                                                                    class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Followup Pending">!</span>
                                                                            </a>
                                                                        </div>
                                                                      @elseif( $category->appointment_status == 4 && $category->status !== 4 && $category->status !== 10)
                                                                        <div class="avatar avatar-sm me-2">
                                                                                <a href="javascript:;" class="dropdown-item"
                                                                                    data-bs-toggle="modal"
                                                                                    data-bs-target="#kt_modal_again_follow_up_lead_schedule" onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                    <div class="border border-gray-500i rounded"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom" title="Followup">
                                                                                        <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                            alt="Premium Potential Icon"
                                                                                            class="w-30px h-30px text-black fw-bold">
                                                                                    </div>
                                                                                    <span
                                                                                        class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="Followup Count"
                                                                                        style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                </a>
                                                                            </div>
                                                                      @elseif( $category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                                        <div class="avatar avatar-sm me-2">
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_follow_up_lead" onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                <div class="border border-gray-500i rounded"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Not Yet Followed">
                                                                                    <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                        alt="Premium Potential Icon"
                                                                                        class="w-30px h-30px text-black fw-bold">
                                                                                </div>
                                                                            </a>
                                                                        </div>
                                                                     @elseif( $category->status == 5)
                                                                     @endif
                                                                 @endif
                                                                    
                                                                 </div>
                                                                 
                                                                <!--<a href="javascript:;"-->
                                                                <!--    class="badge bg-label-danger border border-gray-400 rounded text-white fw-semibold fs-8 px-1 py-0"-->
                                                                <!--    data-bs-toggle="dropdown" aria-haspopup="true"-->
                                                                <!--    aria-expanded="false"-->
                                                                <!--    style="background-color: #F0913D !important;">-->
                                                                <!--    <span><i class="mdi mdi-plus fs-5"></i></span>-->
                                                                <!--    <span>Add Potential</span>-->
                                                                <!--</a>-->
                                                                <div class="dropdown-menu dropdown-menu-end">
                                                                    <a href="javascript:;" class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_premium_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/premium.png') }}"
                                                                                    alt="Premium Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Premium Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_high_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/high.png') }}"
                                                                                    alt="High Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>High Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_good_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/good.png') }}"
                                                                                    alt="Good Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Good Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_medium_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/medium.png') }}"
                                                                                    alt="Medium Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Medium Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item border-bottom"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_critical_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/critical.png') }}"
                                                                                    alt="Critical Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Critical Potential</div>
                                                                        </div>
                                                                    </a>
                                                                    <a href="javascript:;" class="dropdown-item"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_low_potential_type">
                                                                        <div class="d-flex align-items-center">
                                                                            <div
                                                                                class="border border-primary rounded px-1 py-1 me-2">
                                                                                <img src="{{ asset('assets/phdizone_images/potential/low.png') }}"
                                                                                    alt="Low Potential Icon"
                                                                                    class="w-25px h-25px text-black fw-bold">
                                                                            </div>
                                                                            <div>Low Potential</div>
                                                                        </div>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <td class="text-center">
                                                                  @if($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                                 @if(count($category->proposal_list)>0)
                                                                  <a href="javascript:;" class="d-inline-flex position-relative btn btn-icon btn-sm mt-2 text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_view_quotation" onclick="revised_proposal_func('{{$category->sno}}','{{trim($category->lead_name)}}','{{$category->lead_id}}',{{$category->proposal_list}})"><i class="mdi mdi-note-plus-outline fs-3"></i>
                                                                    <div class="position-absolute top-0 start-100 translate-middle badge badge-center border rounded-pill bg-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count"><span class="fs-9">{{count($category->proposal_list)}}</span></div>
                                                                </a>
                                                                @else 
                                                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_quotation" onclick="create_proposal_func('{{$category->sno}}','{{trim($category->lead_name)}}','{{$category->lead_id}}')">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal"><i class="mdi mdi-note-plus-outline fs-3"></i></span>
                                                                    </a>
                                                                @endif
                                                                @else
                                                                <div>-</div>
                                                                @endif
                                                            </td>
                                                            <td>
                                                                @if( $category->status == 0)
                                                                    <a href="javascript:;" class="badge bg-info text-white rounded fw-bold fs-8" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        Active
                                                                    </a>
                                                                    @elseif( $category->status == 1)
                                                                    <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        In Active
                                                                    </a>
                                                                    @elseif( $category->status == 4)
                                                                    <a href="javascript:;" class="badge bg-success text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                                        Customer
                                                                    </a>
                                                                    @elseif($category->status == 5 && ($category->drop_verified == 0 || $category->drop_tl_verified == 0) )
                                                                    <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead Awaiting </a>
                                                                    @elseif($category->status == 5 && $category->drop_verified == 1) 
                                                                    <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead </a> 
                                                                    @elseif($category->status == 5 && $category->drop_verified == 1 ) 
                                                                    <a href="javascript:;" class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Dead Lead Awaiting </a> 
                                                                    @elseif( $category->status == 7 && ($category->spam_verified == 0 || $category->spam_tl_verified == 0) ) 
                                                                    <a href="javascript:;" class="badge bg-dark text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Spam Awaiting </a> 
                                                                    @elseif($category->status == 7 && $category->spam_verified == 1) 
                                                                    <a href="javascript:;" class="badge bg-dark text-white rounded fw-bold fs-8 mb-2" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Spam </a> 
                                                                    @endif
                                                                    @php
                                                                        $hot_lead_followup = $helper->getFollowupCount($category->sno)
                                                                    @endphp
                                                                    @if( $category->status == 0)
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <!--<a href="javascript:;" class="dropdown-item"-->
                                                                        <!--    data-bs-toggle="modal"-->
                                                                        <!--    data-bs-target="#kt_modal_lead_inactivate" onclick="inactiveModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Inactivate</a>-->
                                                                            @if($hot_lead_followup >= 2)
                                                                            @if($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8)
                                                                                <a href="javascript:;" class="dropdown-item d-none" data-bs-toggle="modal" data-bs-target="#kt_modal_hot_lead" onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot Lead</a>
                                                                            @elseif($category->lead_status_id != 3)
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_hot_lead" onclick="hotLeadModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Hot Lead</a>
                                                                            @endif
                                                                            @endif
                                                                            @if($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_drop" onclick="dropModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">Dead Lead</a>
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_spam" onclick="spamModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->created_by }}')">Spam Lead</a>
                                                                                
                                                                                    {{-- When productsData is not set OR empty --}}
                                                                                    @if ($category->outgoing_count > 0)
                                                                                        @if(count($category->proposal_list) == 0)
                                                                                       
                                                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_potential" onclick="PotentialModal('{{ $category->sno }}','{{ trim($category->lead_name) }}', '{{ $category->created_by }}')">
                                                                                            Lead Basket
                                                                                        </a>
                                                                                        @endif
                                                                                    @endif
                                                                            @elseif($category->appointment_status != 4)
                                                                                <label  class="text-danger fs-8 fw-bold dropdown-item">Pending Follow-up</label>
                                                                            @elseif($category->lead_appointment_status == 1)
                                                                                <label class="dropdown-item" class="text-danger fs-8 fw-bold dropdown-item">Pending Appointment</label>
                                                                            @endif
                                                                    </div>
                                                                    @elseif( $category->status == 1)
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_activate"onclick="activeModal('{{ $category->sno }}','{{ trim($category->lead_name) }}')">Activate</a>
                                                                    </div>
                                                                    @elseif( $category->status == 4)

                                                                @endif
                                                            </td>
                                                            <td>
                                                                @if($category->status !== 1 && $category->status !== 7 && $category->status !== 5)
                                                                <span class="text-end">
                                                                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown"
                                                                        aria-haspopup="true" aria-expanded="false">
                                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                                    </a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                         @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_view_lead" onclick="populateViewModal('{{ $category->sno }}')" >
                                                                                <span><i
                                                                                        class="mdi mdi-eye-outline fs-3 text-black me-1"></i></span>
                                                                                <span>View</span>
                                                                            </a>
                                                                         @endif
                                                                            <!--<a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_lead_to_intern" onclick="ConvertIntern('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')" style="background-color: #b6f1fb !important;">-->
                                                                            <!--    <span><i class="mdi mdi-account-arrow-right-outline fs-3 text-black me-1"></i>Intern</span>-->
                                                                            <!--</a>-->
                                                                        @if($category->status !== 4 && $category->status !== 10)
                                                                            @if( $category->lead_appointment_status != 1)
                                                                            @if(auth()->user()->hasPermission($module_name, 'Add Appoinment', $menu_name))
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_appointment" onclick="lead_appointment_func('{{ $category->sno }}','{{ trim($category->lead_name) }}')"><span> <i class="mdi mdi-clipboard-account-outline fs-3 text-black me-1"></i>Appointment </span></a></a>
                                                                            @endif
                                                                            @endif
                                                                            @if(auth()->user()->hasPermission($module_name, 'Add Internal Calls', $menu_name))
                                                                            @if($category->lead_appointment_status != 1 && $category->appointment_status == 4)
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_internal_call_lead" onclick="internalCalls('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_id }}')">
                                                                                    <span><i class="mdi mdi-call-split fs-3 text-black me-1"></i>Internal Calls</span>
                                                                                </a>
                                                                            @endif
                                                                            @if($hot_lead_followup >= 2)
                                                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"  data-bs-target="#kt_modal_lead_bank_trans" onclick="LeadbankCalls('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_id }}')">
                                                                                    <span><i class="mdi mdi-bank-transfer-out fs-3 text-black me-1"></i>Lead Bank</span>
                                                                                </a>
                                                                            @endif
                                                                            @endif
                                                                             @if(auth()->user()->hasPermission($module_name, 'Add Requirement', $menu_name))
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_assign_requirements" onclick="openRequirement('{{$category->sno}}')">
                                                                                <span><i
                                                                                        class="mdi mdi-file-chart-check-outline fs-3 text-black me-1"></i></span>
                                                                                <span>Requirments</span>
                                                                            </a>
                                                                            @endif
                                                                             @if(auth()->user()->hasPermission($module_name, 'Edit', $menu_name))
                                                                            <a href="javascript:;" class="dropdown-item"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_edit_lead" onclick="populateEditModal('{{ $category->sno }}')">
                                                                                <span><i
                                                                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i></span>
                                                                                <span>Edit</span>
                                                                            </a>
                                                                                @endif
                                                                        @endif
                                                                    </div>
                                                                </span>
                                                                @endif
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                @endif
                                                @else
                                                <tr>
                                                  @if(auth()->user()->hasPermission($module_name, 'Bulk Transfer', $menu_name))
                                                  <td></td>
                                                  @endif
                                                  <td>Unauthorized Access</td>
                                                  <td></td>
                                                  <td></td>
                                                  <td></td>
                                                  <td></td>
                                                  <td></td>
                                                  <td></td>
                                                </tr>
                                                @endif
                                                
                                            </tbody>
                                        </table>
                                      </form>
                                    </div>
                                    <div class="mt-4">
                                    {{ $leads->appends(request()->except(['page', '_token']))->links() }}
            
                                     </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    
     <!--begin::Modal - Transfer Lead to Customer-->
    <div class="modal fade" id="kt_modal_lead_to_intern" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead To Intern</h3>
                    </div>
                    <form method="POST" action="{{ route('convert_intern') }}" autocomplete="off">
                        @csrf
                        <div class="row">
                            <input type="hidden" name="lead_id" id="lead_id_intern" value="">
                            <div class="col-lg-12 mt-4">
                                <h5 class="text-dark mb-1 fw-semibold">Are You Sure Want To Convert Lead To Intern?</h5>
                                <div class="text-center">
                                    <label class="fw-bold fs-5 text-danger" id="lead-name_intern" ></label>
                                    <span class="fw-bold fs-5 text-danger" id="lead-mobile_intern">[]</span>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                <button type="submit" class="btn btn-primary me-3" >Yes</button>
                                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Transfer Lead to Customer-->

   <!--begin::Modal - Convert bulk staff-->
    <div class="modal fade" id="kt_modal_bulk_convert_sales_person" tabindex="-1" aria-hidden="true"   data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                    <h3 class="my-4 text-center  fw-bold ">Bulk Transfer</h3>
                    <div class="container" id="swal2-html-container" style="display: block;">
                        <div class="mb-4 fw-bold fs-6">
                        <span id="bulk_convert_message"></span>
                        </div>
                        <div class="row d-flex justify-content-center mb-4">
                        <div class="col-lg-8">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Convert Staff<span class="text-danger">*</span></label>
                            <select id="bulk_assign_staff_conver" name="bulk_assign_staff_conver" class="select3 form-select">
                            </select>
                            <div class="text-danger" id="bulk_assign_staff_conver_err"></div>
                        </div>
                        </div>
                    <div class="text-center">
                        <button type="button" id="bulk_convert_btn" class="btn btn-danger me-3" onclick="bulk_request_pay();">
                        Convert</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                    </div>

                </div><br><br>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert bulk staff-->



    <!--begin::Modal - Import Raw Lead-->
    <div class="modal fade" id="kt_modal_raw_lead_import" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-1 text-black">Import Raw Lead</h3>
                    </div>
                    <div class="text-end">
                        <a href="{{ asset('assets/phdizone_images/lead_sample_import.xlsx') }}" download>
                            <span>Sample Download For Lead Import</span>
                            <span><i class="mb-1 mdi mdi-download-circle fs-3 text-danger"
                                    title="Click Here to Download"></i></span>
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Group<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Group" />
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Whatsapp</option>
                                <option value="2">Facebook</option>
                                <option value="3">Google Business</option>
                                <option value="4">Reference</option>
                            </select>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <form action="/upload" class="dropzone needsclick" id="dropzone-basic">
                                <div class="dz-message needsclick justify-content-center align-items-center">
                                    <span class="note needsclick">
                                        <h4>Click Here To Upload The Lead Data</h4>
                                    </span>
                                </div>
                                <div class="d-block text-muted fs-6">
                                    Max File Size(5 MB)
                                </div>
                                <div class="fallback">
                                    <input name="file" type="file" accept=".xls" />
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Import</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Import Raw Lead-->

    <!--begin::Modal - Convert Lead-->
    <div class="modal fade" id="kt_modal_convert_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Convert To Lead</h3>
                    </div>
                    <div class="text-dark mb-4 fs-6 fw-bold text-center">Are you sure you want to Convert<span
                            class="text-danger ms-1 me-1">Ravi Kumar R</span> Raw Lead ?</div>
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Lead Source</option>
                                <option value="1">Email</option>
                                <option value="2">Website</option>
                                <option value="2">Facebook</option>
                            </select>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" >Convert Lead</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead-->

    <!--begin::Modal - Spam Lead-->
    <div class="modal fade" id="kt_modal_spam_lead" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Convert to Spam Lead ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="row px-10">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Reason</option>
                            <option value="1">No Enquiry From Lead</option>
                            <option value="2">Irrelevant Call</option>
                            <option value="3">Competitor</option>
                            <option value="4">Fake Enquiry</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" >Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Spam Lead-->

    <!--begin::Modal - Lead Bank-->
    <div class="modal fade" id="kt_modal_lead_bank" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Move Raw Lead to Lead Bank ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" >Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Bank-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Lead Bank to Convert Lead-->
    <div class="modal fade" id="kt_modal_lead_bank_to_lead_transfer" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" >Lead Transfer</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Bank to Convert Lead-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Add Spam Lead-->
    <div class="modal fade" id="kt_modal_add_spam_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Spam Lead</h3>
                    </div>
                    <form id="spamAddForm" action="{{ route('add_spam') }}" method="POST" novalidate
                        autocomplete="off">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>
                                <input type="text" class="form-control" id="lead_name_spam" name="lead_name_spam"
                                    placeholder="Enter Lead Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <label class="text-dark mb-1 fs-6 fw-semibold">Mobile Number<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="lead_mobile_spam" maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    name="lead_mobile_spam" placeholder="Enter Mobile Number" />
                                <div class="text-danger" id="lead_mobile_spam_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                {{-- {{ $reasonList }} --}}
                                <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span class="text-danger">*</span></label>
                                <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleAddSpam(this.value)">
                                    <option value="">Select Reason</option>
                                    @if (isset($reasonList) && count($reasonList) > 0)
                                    @foreach ($reasonList as $reason_spam)
                                    <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                                        {{ $reason_spam->reason_name }}
                                    </option>
                                    @endforeach
                                    @endif
                                    <option value="1">Others</option>
                                </select>
                                <div class="text-danger" id="reason_select_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                <div class="text-danger" id="reason_text_err"></div>
                            </div>
                            <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                <div class="text-danger" id="spam_comments_err"></div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_spam_add"
                                onclick="spamAddvalidateForm()">Create Spam</button>
                        </div>
                    </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Spam Lead-->


    <!--begin::Modal - Add Lead-->
    <div class="modal fade" id="kt_modal_add_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Create Lead</h3>
                    </div>
                    <form id="leadAddForm" action="{{ route('add_lead') }}" method="POST" novalidate autocomplete="off">
                        @csrf
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Lead Name" id="lead_name_create" name="lead_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="70" />
                                <div class="text-danger" id="lead_name_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio1" value="1"  checked />
                                    <label class="form-check-label" for="inlineRadio1">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio2" value="2" />
                                    <label class="form-check-label" for="inlineRadio2">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender" id="inlineRadio3" value="3" />
                                    <label class="form-check-label" for="inlineRadio3">Others</label>
                                </div>
                                <div class="text-danger" id="lead_gender_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="cllt_cl_dt"  name="lead_dob" placeholder="Select Date" 
                                        class="form-control common_date_class">
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="mb-1">
                                     <input class="form-check-input" type="checkbox" checked  id="mobile_no_chk" value="1" name="mobile_check" onclick="mobile_no_func();" /> 
                                    <label class="text-black fs-6 fw-semibold">Mobile Number<span class="text-danger" style="display: none ;"  id="mob_req">*</span></label>
                                </div>
                                <div id="mob_no" style="display: none ;">
                                    <div class="input-group">
                                        <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="countryDropdownButton" name="countryDropdownButton">Phn Code</button>
                                        <ul class="dropdown-menu" id="countryDropdownMenu" name="countryDropdownMenu" style="max-height: 250px; overflow-y: auto;">
                                            <li>
                                                <input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;">
                                            </li>
                                        </ul>
                                        <input type="text" class="form-control" id="lead_mobile_create" name="lead_mobile_create" maxlength="10" onkeyup="mobile_chk(this.value)" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                            placeholder="Enter Mobile Number">
                                            <input type="hidden" id="country_code_name" name="country_code_name" value=""/>
                                    </div>
                                </div>
                                
                                <div class="text-danger" id="lead_mobile_create_err"></div> 
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="mb-1">
                                    <input class="form-check-input" type="checkbox" id="email_chk" value="1" name="email_check" onclick="email_func();" />
                                    <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: none ;" id="email_req">*</span></label>
                                </div>
                                <div id="email_tbox" style="display: none ;">
                                    <input type="text" class="form-control me-2" placeholder="Enter Email ID"  id="lead_email_create"  name="lead_email_id" onkeyup="email_chk(this.value)"
                                    oninput=" this.value = this.value.toLowerCase();" />
                                </div>
                                 <div class="text-danger" id="lead_email_create_err"></div>
                            </div>
                          
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                                <input type="text" class="form-control me-2" maxlength="10"
                                    placeholder="Enter Alternate Mobile Number" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" id="lead_alternate_create"   name="lead_alternate_mobile" />
                            </div>
                            
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                                <select class="select3 form-select" id="countryId" name="country">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="text-danger" id="lead_country_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                                <select class="select3 form-select" id="stateId" name="state">
                                    <option value="">Select State</option>
                                </select>
                                <div class="text-danger" id="lead_state_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                                <select class="select3 form-select" id="cityId" name="city">
                                    <option value="">Select City</option>
                                </select>
                                <div class="text-danger" id="lead_city_create_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                                <input type="text" class="form-control me-2" id="lead_door_no" name="door_no"  placeholder="Enter Door No / Flat No">
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                                <input type="text" class="form-control me-2" id="address" name="address" placeholder="Enter Area / Street" />
                            </div>
                                
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                                <input type="text" class="form-control me-2" id="lead_pincode" name="pincode" placeholder="Enter Pincode">
                            </div>
                            <!--<div class="col-lg-4 mb-3">-->
                            <!--    <label class="text-black mb-1 fs-6 fw-semibold">Product Category<span-->
                            <!--            class="text-danger">*</span></label>-->
                            <!--    <select class="select3 form-select" id="service_category_id" name="service_category_id">-->
                            <!--        <option value="">Select Product Category</option>-->
                            <!--    </select>-->
                            <!--    <div class="text-danger" id="service_category_id_err"></div>-->
                            <!--</div>-->
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Product<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="service_id" multiple name="service_id[]">
                                    <option value="">Select Product</option>
                                </select>
                                <div class="text-danger" id="service_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">University</label>
                                <select class="select3 form-select" id="university_id" name="university_id">
                                    <option value="">Select University</option>
                                </select>
                                <div class="text-danger" id="university_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Potential Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="potential_type_id" name="potential_type_id">
                                    <option value="">Select Potential Type</option>
                                   
                                </select>
                                <div class="text-danger" id="potential_type_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="lead_type_id" name="lead_type_id">
                                    <option value="">Select Lead Type</option>
                                </select>
                                <div class="text-danger" id="lead_type_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="lead_source_id" name="lead_source_id">
                                    <option value="">Select Lead Source</option>
                                </select>
                                <div class="text-danger" id="lead_source_id_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Comments</label>
                                <textarea class="form-control" rows="1" name="lead_comments" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="submit_lead_add" onclick="AddvalidateForm()">Create Lead</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add Lead-->

     <!--begin::Modal - Edit Lead-->
    <div class="modal fade" id="kt_modal_edit_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Update Lead</h3>
                    </div>
                    <form id="leadEditForm" action="{{ route('lead_update') }}" method="POST" novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_edit" name="lead_id">
                    <div class="row">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Lead Name"
                            id="lead_name_edit" name="lead_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="70" />
                            <div class="text-danger" id="lead_name_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Gender<span
                                    class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio1edit" value="1" checked />
                                    <label class="form-check-label" for="inlineRadio1edit">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio2edit" value="2"  />
                                    <label class="form-check-label" for="inlineRadio2edit">Female</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="lead_gender"  id="inlineRadio3edit" value="3" />
                                    <label class="form-check-label" for="inlineRadio3edit">Others</label>
                                </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="lead_dob_up" name="lead_dob" placeholder="Select Date"
                                    class="form-control" >
                                  
                            </div>
                            <div class="text-danger" id="lead_dob_up_err"></div>
                        </div>
                        
                        <div class="col-lg-4 mb-3">
                            <div class="mb-1">
                                 <input class="form-check-input" type="checkbox"  id="mobile_no_chk_edit" value="1" name="mobile_check" onclick="mobile_no_func_edit();" /> 
                                <label class="text-black fs-6 fw-semibold">Mobile Number<span class="text-danger" style="display: none ;"  id="mob_req_edit">*</span></label>
                            </div>
                            <div id="mob_no_edit" style="display: none ;">
                                <div class="input-group">
                                    <button class="btn btn-outline-primary dropdown-toggle border border-gray-400i"
                                        type="button" data-bs-toggle="dropdown" aria-expanded="false"
                                        id="countryDropdownButton_edit" name="countryDropdownButton">IN - +91</button>
                                    <ul class="dropdown-menu" id="countryDropdownMenu_edit"
                                        name="countryDropdownMenu_edit" style="max-height: 250px; overflow-y: auto;">
                                        <li>
                                            <input type="text" id="countrySearch_edit" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;">
                                        </li>
                                    </ul>
                                    <input type="text" class="form-control" id="lead_mobile_edit" name="lead_mobile" maxlength="10" onkeyup="mobile_chk_edit(this.value)" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                        placeholder="Enter Mobile Number">
                                        <input type="hidden" id="country_code_name_edit" name="country_code_name_edit" value="91">
                                </div>
                            </div>
                            
                            <div class="text-danger" id="lead_mobile_edit_err"></div> 
                        </div>
                        <div class="col-lg-4 mb-3">
                            <div class="mb-1">
                                <input class="form-check-input" type="checkbox" id="email_chk_edit" value="1" name="email_check" onclick="email_func_edit();" />
                                <label class="text-black fs-6 fw-semibold">Email ID<span class="text-danger" style="display: none ;" id="email_req_edit">*</span></label>
                            </div>
                            <div id="email_tbox_edit" style="display: none ;">
                                <input type="text" class="form-control me-2" placeholder="Enter Email ID"  name="lead_email_id" id="lead_email_edit" onkeyup="email_chk_edit(this.value)"
                                oninput=" this.value = this.value.toLowerCase();" />
                            </div>
                             <div class="text-danger" id="lead_email_edit_err"></div>
                        </div>
                        
                     
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Alternate Mobile Number</label>
                            <input type="text" class="form-control me-2" id="lead_alternate_edit"
                                placeholder="Enter Alternate Mobile Number" name="lead_alternate_mobile" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"  />
                        </div>
                     
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country</label>
                            <select class="select3 form-select" id="country_id_edit" name="country_edit">
                                <option value="">Select Country</option>
                            </select>
                            <div class="text-danger" id="country_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State</label>
                            <select class="select3 form-select" id="state_edit" name="state_edit">
                                <option value="">Select State</option>
                                
                            </select>
                            <div class="text-danger" id="state_edit_err"></div>
                            
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City</label>
                            <select class="select3 form-select" id="city_edit" name="city_edit">
                                <option value="">Select City</option>
                                
                            </select>
                            <div class="text-danger" id="city_edit_err"></div>
                        </div>
                         <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door No / Flat No</label>
                            <input type="text" class="form-control me-2" id="lead_door_no_edit" name="door_no"  placeholder="Enter Door No / Flat No">
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street</label>
                            <input type="text" class="form-control me-2" id="lead_address_edit" name="address" placeholder="Enter Area / Street"
                                 />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode</label>
                            <input type="text" class="form-control me-2" id="lead_pincode_edit" name="pincode" placeholder="Enter Pincode">
                        </div>
                        
                        <!--<div class="col-lg-4 mb-3">-->
                        <!--    <label class="text-black mb-1 fs-6 fw-semibold">Product Category<span-->
                        <!--            class="text-danger">*</span></label>-->
                        <!--    <select class="select3 form-select" id="service_category_id_edit" name="service_category_id">-->
                        <!--        <option value="">Select Product Category</option>-->
                        <!--    </select>-->
                        <!--    <div class="text-danger" id="service_category_id_edit_err"></div>-->
                        <!--</div>-->
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Product<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="service_id_edit" name="service_id[]" multiple>
                                <option value="">Select Product</option>
                            </select>
                            <div class="text-danger" id="service_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">University</label>
                            <select class="select3 form-select" id="university_id_edit" name="university_id">
                                <option value="">Select University</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Potential Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="potential_type_id_edit" name="potential_type_id">
                                <option value="">Select Potential Type</option>
                            </select>
                            <div class="text-danger" id="potential_type_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="lead_type_edit" name="lead_type_id_edit">
                                <option value="">Select Lead Type</option>
                            </select>
                            <div class="text-danger" id="lead_type_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Source<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="lead_source_edit" name="lead_source_id_edit">
                                <option value="">Select Lead Source</option>
                            </select>
                            <div class="text-danger" id="lead_source_id_edit_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold" >Comments</label>
                            <textarea class="form-control"  rows="1" id="comments_edit"  name="lead_comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });" placeholder="Enter Comments"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="submit_lead_edit" onclick="EditvalidateForm()">Update Lead</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit Lead-->

   <!--begin::Modal - View Lead-->
<div class="modal fade" id="kt_modal_view_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <label>View Lead</label>
                        <label class="ms-1 me-1">-</label>
                        <label class="badge bg-info rounded fw-semibold fs-4">Active</label>
                    </h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 text-black fs-5 fw-bold">Basic Information</div>
                    <div class="col-lg-6 text-end">
                        <div class="badge bg-secondary text-end fs-6 text-white fw-semibold rounded" id="view_lead_auto_id">LD-0003/24</div>
                    </div>
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label  id="lead_created" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="lead_name_view" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Gender</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="lead_gender_view" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">DOB</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="lead_dob_view" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <div class="text-truncate max-w-75 text-black fs-6 fw-bold" id="lead_email_view" data-bs-toggle="tooltip" data-bs-placement="bottom" title="priya@gmail.com"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-2">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="view_address" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label  id="lead_mobile_view" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Alternate Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label   id="lead_alternate_view"  class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Marital Status</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label  id="lead_marital_view" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <label class="text-black fs-5 fw-bold">Product Information</label>
                    </div>
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Category</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="view_category" class="col-7 text-black fs-6 fw-bold">Development Services</label>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Product</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="view_service" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 text-black fs-5 fw-bold">Lead Information</div>
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Lead Type</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label  class="col-7 text-black fs-6 fw-bold"><span id="view_leadtype"></span></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Potential Type</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7 text-black fs-6 fw-bold">
                                <div class="d-flex align-items-center">
                                    <div class="me-1">
                                        <img id="potential_image_view" src="" alt="Premium Potential Icon" class="w-25px h-25px text-black fw-bold">
                                    </div>
                                    <label id="view_potentialtype" class="text-black fs-6 fw-bold"></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-4">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="view_leadsource" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">University</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label id="view_university" class="col-7 text-black fs-6 fw-bold"></label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <label class="text-dark fs-6 fw-semibold mb-2">Comments</label>
                        <div class="d-block">
                            <label id="view_comments" class="text-black fs-7 fw-bold">&emsp;&emsp;</label>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Lead-->


    <!--begin::Modal - Lead Appointment-->
    <!--<div class="modal fade" id="kt_modal_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"-->
    <!--    data-bs-backdrop="static" data-bs-focus="false">-->
        <!--begin::Modal dialog-->
    <!--    <div class="modal-dialog modal-xl">-->
            <!--begin::Modal content-->
    <!--        <div class="modal-content rounded">-->
                <!--begin::Modal header-->
    <!--            <div class="modal-header justify-content-end border-0 pb-0">-->
                    <!--begin::Close-->
    <!--                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">-->
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
    <!--                    <span class="svg-icon svg-icon-1">-->
    <!--                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"-->
    <!--                            xmlns="http://www.w3.org/2000/svg">-->
    <!--                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"-->
    <!--                                transform="rotate(-45 6 17.3137)" fill="currentColor" />-->
    <!--                            <rect x="7.41422" y="6" width="16" height="2" rx="1"-->
    <!--                                transform="rotate(45 7.41422 6)" fill="currentColor" />-->
    <!--                        </svg>-->
    <!--                    </span>-->
                        <!--end::Svg Icon-->
    <!--                </div>-->
                    <!--end::Close-->
    <!--            </div>-->
                <!--end::Modal header-->
                <!--begin::Modal body-->
    <!--            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">-->
                    <!--begin::Heading-->
    <!--                <div class="mb-4 text-center">-->
    <!--                    <h3 class="text-center mb-4 text-black">-->
    <!--                        <span>Create Appointment</span>-->
    <!--                        <span class="ms-1 me-1">-</span>-->
    <!--                        <span class="badge bg-info rounded fs-5" id="search_lead_name">Priya</span>-->
    <!--                    </h3>-->
    <!--                </div>-->
    <!--                <form id="addLeadAppointmentForm" action="{{ route('lead_appointment_add') }}" method="POST" autocomplete="off">-->
    <!--                  @csrf-->
    <!--                    <div class="row">-->
    <!--                    <input type="hidden" name="lead_id_add" id="lead_id_add">-->
    <!--                        <div class="col-lg-4 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Category<span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <select class="select3 form-select" id="aptment" name="appt_catg_add" onchange="apmt_func();">-->
    <!--                                <option value="">Select Appointment Category</option>-->
    <!--                                <option value="Walk-in">Walk-In</option>-->
    <!--                                <option value="Online">Online</option>-->
    <!--                                <option value="Offline">Offline</option>-->
    <!--                                <option value="Video">Video</option>-->
    <!--                                <option value="Payment">Payment</option>-->
    <!--                            </select>-->
    <!--                            <div class="text-danger" id="aptment_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Date<span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <div class="input-group input-group-merge">-->
    <!--                                <span class="input-group-text"><i-->
    <!--                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>-->
    <!--                                <input type="text" id="ld_appt_dt_add" name="ld_appt_dt_add" placeholder="Select Date" class="form-control">-->
                                    
    <!--                            </div>-->
    <!--                            <div class="text-danger" id="ld_appt_dt_add_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Department <span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <select class="select3 form-select" id="assg_dept_add" name="assg_dept_add" onchange="depat_staff_func(this.value)">-->
    <!--                                <option value="">Select Department </option>-->
    <!--                            </select>-->
    <!--                            <div class="text-danger" id="assg_dept_add_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <select class="select3 form-select" id="assg_staff_add" name="assg_staff_add">-->
    <!--                                <option value="">Select Assigned Staff</option>-->
    <!--                            </select>-->
    <!--                            <div class="text-danger" id="assg_staff_add_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Appointment Reason<span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <textarea class="form-control" rows="1" id="appt_reason_add" name="appt_reason_add" placeholder="Enter Appointment Reason"></textarea>-->
    <!--                            <div class="text-danger" id="appt_reason_add_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3" id="onl_link_tbox" style="display: none;">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Meeting Link<span-->
    <!--                                    class="text-danger">*</span></label>-->
    <!--                            <input type="text" class="form-control" placeholder="Enter Meeting Link" id="appt_meeting_add" name="appt_meeting_add" value="" />-->
    <!--                            <div class="text-danger" id="appt_meeting_add_err"></div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-4 mb-3" id="onl_link_pw_tbox" style="display: none;">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Meeting Password</label>-->
    <!--                            <div class="form-password-toggle">-->
    <!--                                <div class="input-group input-group-merge">-->
    <!--                                    <input type="password" class="form-control" id="password"-->
    <!--                                        placeholder="Enter Password" aria-describedby="password" id="appt_meeting_pass" name="appt_meeting_pass"/>-->
    <!--                                    <span class="input-group-text cursor-pointer"><i-->
    <!--                                            class="mdi mdi-eye-off-outline fs-4"></i></span>-->
    <!--                                </div>-->
    <!--                            </div>-->
    <!--                        </div>-->
    <!--                        <div class="col-lg-8 mb-3">-->
    <!--                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
    <!--                            <textarea class="form-control" rows="1" placeholder="Enter Description" id="appt_descrp" name="appt_descrp"></textarea>-->
    <!--                        </div>-->

    <!--                    </div>-->
    <!--                    <div class="d-flex justify-content-end align-items-center mt-4">-->
    <!--                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>-->
    <!--                        <button type="button" id="addSubmit" onclick="addLeadvalidateForm()" class="btn btn-primary">Create Appointment</button>-->
    <!--                    </div>-->
    <!--                </form>-->
    <!--            </div>-->
                <!--end::Modal body-->
    <!--        </div>-->
            <!--end::Modal content-->
    <!--    </div>-->
        <!--end::Modal dialog-->
    <!--</div>-->
     <div class="modal fade" id="kt_modal_appointment" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Create Appointment</span>
                            <span class="ms-1 me-1">-</span>
                            <span class="badge bg-info rounded fs-5" id="search_lead_name">Priya</span>
                        </h3>
                    </div>
                    <form id="addLeadAppointmentForm" action="{{ route('lead_appointment_add') }}" method="POST" autocomplete="off">
                      @csrf
                        <div class="row">
                        <input type="hidden" name="lead_id_add" id="lead_id_add">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Appointment Category<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="aptment" name="appt_catg_add" onchange="apmt_func();">
                                    <option value="">Select Appointment Category</option>
                                    @foreach ($categories as $cat)
                                        <option value="{{ $cat->sno }}">{{ $cat->appointment_category }}</option>
                                    @endforeach
                                </select>
                                <div class="text-danger" id="aptment_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Appointment Date<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="ld_appt_dt_add" name="ld_appt_dt_add" placeholder="Select Date" class="form-control">
                                    
                                </div>
                                <div class="text-danger" id="ld_appt_dt_add_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Department <span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="assg_dept_add" name="assg_dept_add" onchange="depat_staff_func(this.value)">
                                    <option value="">Select Department </option>
                                </select>
                                <div class="text-danger" id="assg_dept_add_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">
                                    <span id="assign_staff_or_pc">Assigned Staff</span>
                                    <span class="text-danger">*</span>
                                </label>
                                <select class="select3 form-select" id="assg_staff_add" name="assg_staff_add">
                                    <option value="">Select Assigned Staff</option>
                                </select>
                                <div class="text-danger" id="assg_staff_add_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Appointment Reason<span
                                        class="text-danger">*</span></label>
                                <textarea class="form-control" rows="1" id="appt_reason_add" name="appt_reason_add" placeholder="Enter Appointment Reason"></textarea>
                                <div class="text-danger" id="appt_reason_add_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3" id="onl_link_tbox" style="display: none;">
                                <label class="text-black mb-1 fs-6 fw-semibold">Meeting Link<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Meeting Link" id="appt_meeting_add" name="appt_meeting_add" value="" />
                                <div class="text-danger" id="appt_meeting_add_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3" id="onl_link_pw_tbox" style="display: none;">
                                <label class="text-black mb-1 fs-6 fw-semibold">Meeting Password</label>
                                <div class="form-password-toggle">
                                    <div class="input-group input-group-merge">
                                        <input type="password" class="form-control" id="password"
                                            placeholder="Enter Password" aria-describedby="password" id="appt_meeting_pass" name="appt_meeting_pass"/>
                                        <span class="input-group-text cursor-pointer"><i
                                                class="mdi mdi-eye-off-outline fs-4"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control" rows="1" placeholder="Enter Description" id="appt_descrp" name="appt_descrp"></textarea>
                            </div>

                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="addSubmit" onclick="addLeadvalidateForm()" class="btn btn-primary">Create Appointment</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Appointment-->

    <!--begin::Modal -  Internal Calls-->
    <div class="modal fade" id="kt_modal_internal_calls" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want to
                    Convert to Internal Calls ?
                    <div class="d-block fw-bold fs-5 text-danger py-2">
                        <label>Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label>9876543210</label>
                    </div>
                </div>
                <div class="row px-10">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Reason</option>
                            <option value="1">Embedded School</option>
                            <option value="2">Elysian Skill</option>
                            <option value="3">Academy Placements</option>
                            <option value="4">Projects</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3" >Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls-->
        <!--begin::Modal -  Internal Calls-->
        
        <div class="modal fade" id="kt_modal_lead_register_date_change" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black"> <i class="mdi mdi-calendar-month-outline fs-3 me-2"></i> Lead Registered Date Update</h3>
                    </div>
                 
                    <div class="row mb-2">
                        <div class="col-lg-6">Name</div>
                        <div class="col-lg-6">Registerd Date</div>
                    </div>
                    <div class="row mb-2 fw-bold">
                        <div class="col-lg-6 fs-6">
                            <span id="staus_event_name">Kumar</span> 
                        </div>
                        <div class="col-lg-6 fs-6">
                            <span id="registered_date_change">13-Aug-2025</span> 
                        </div>
                    </div>
                    <input type="hidden" name="status_lead_id" id="status_lead_id">
                    <!-- Date input --> 
                    <div class="mb-2"> 
                            <label for="register_date_edit" class="form-label fw-bold">New Register Date</label> 
                            <div class="input-group"> 
                                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span> 
                                <input type="text" id="register_date_edit" name="register_date_edit" placeholder="Select Date" class="form-control common_date_class" readonly  /> 
                            </div> 
                            <div id="date_error" class="text-danger small mt-1 d-none"> <span id="register_date_error" >Date cannot be in the future.</span></div> 
                             
                            <!-- Warning message --> 
                            <div class="alert alert-warning d-flex align-items-start mt-2"> 
                                <i class="mdi mdi-alert-circle fs-4 me-2"></i> 
                                <div> 
                                <strong>Important:</strong> Changing the <u>Lead Registered Date</u> after entry will 
                                        <span class="fw-bold">directly affect reporting and performance metrics.</span> 
                                </div> 
                            </div> 
                            <!-- Confirmation checkbox --> 
                            <div class="form-check mt-3"> 
                                <input class="form-check-input" type="checkbox" id="confirm_checkbox"> 
                                <label class="form-check-label fw-bold" for="confirm_checkbox"> I confirm the new date is accurate. </label> 
                            </div> 
                            <div class="d-flex justify-content-center align-items-center pt-8 pb-4">
                                <button type="button" id="btn_confirm_change" class="btn btn-primary me-3" onclick="statusUpdate()" disabled>Yes</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            </div>
                            
                        </div> 
                </div>
                 
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

<!--begin::Modal - Assign Requirements-->
<div class="modal fade" id="kt_modal_assign_requirements" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <form id="requirementForm" enctype="multipart/form-data" action="{{ route('requirements_add_update') }}" method="POST" novalidate autocomplete="off">
             @csrf
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <input type="hidden" name="requirement_lead_id" id="requirement_lead_id">
                <input type="hidden" name="requirement_status" id="requirement_status">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Assign Requirments</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="requirement_lead_name"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead Mobile</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="requirement_lead_mobile"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="requirement_service_category"></label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold" id="requirement_service"></label>
                </div>
                
                <div class="form-repeater_reqts mt-6">
                    <div data-repeater-list="group-a_led_question" id="">
                        <div data-repeater-item>
                            <div class="row mt-4" id="default_repeater">
                                <div class="col-lg-7 mb-3"  id="default_requirement">
                                    <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_1">Requirements Point 1<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter Requirement Point 1" id="requirement_name_1" name="requirement_name[]" />
                                    <div class="text-danger err_mssg" id="requirement_name_1_err"></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                    <div class="d-flex align-items-sm-center">
                                        <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_1" />
                                        <div class="ms-1 button-wrapper" id="defalt_filediv">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <button type="button" id="default_doc" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="document.getElementById('document_upload_1').click();">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" id="document_upload_1" name="document_upload[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)"  />
                                                </button>
                                                <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document"  id="uploaded_reset_1">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                                            <div class="small text-success fs-8" id="upload_file_name_1"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_1" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                            <div id="repeater_req"></div>
                        </div>
                    </div>
                </div>
                <div class="mb-1 mt-1">
                    <button type="button" class="btn btn-sm btn-primary staff_reqts_add px-2 py-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Add More" data-repeater-create>
                        <i class="mdi mdi-plus me-1"></i>Add More
                    </button>
                </div>

                <div class="d-flex justify-content-end align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="submit_requirements" class="btn btn-primary me-3" >
                        Assign Requirements
                    </button>
                </div>
            </div>
           </form>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Assign Requirements- -->

    <!--begin::Modal - Mobile No Verified-->
    <div class="modal fade" id="kt_modal_mob_no_verify" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20" id="">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Mobile Number Verification Details</h3>
                    </div>
                    <div id="phone_verify_modal_content">

                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Mobile No Verified-->

    <!--begin::Modal - Mobile No Not Verified-->
    <div class="modal fade" id="kt_modal_mob_no_not_verify" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Mobile Number Verification Details</h3>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">Priya</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Mobile</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-bold">+91 9876543210</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Status</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 fs-5 fw-bold text-danger">IN-Valid Number</label>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Mobile No Not Verified-->

    <!--begin::Modal - Lead Transfer Log-->
    <div class="modal fade" id="kt_modal_lead_transfer_log" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Transfer Log Details</h3>
                    </div>
                    <div class="row">
                    <input type="hidden" id="lead_id_transfer" name="lead_id_transfer">
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_name_transfer"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Lead Source</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_src_transfer"></label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="lead_mobile_transfer"></label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Registered Date">Registered Dt</label>
                                <label class="col-1 text-black fs-6 fw-bold" >:</label>
                                <label class="col-7 fs-6 fw-bold text-black" id="lead_reg_date_transfer"></label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Staff</th>
                                        <th class="min-w-150px">Transfered From</th>
                                        <th class="min-w-150px">End Date</th>
                                        <th class="min-w-50px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="transfer_log_div">
                                    <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead Transfer Log-->
    
    <!--begin::Modal -  Call Log-->
    <div class="modal fade" id="kt_modal_call_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-5 px-5 px-xl-10">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center mb-4 text-black">
                            <span><span id="call_lead_name">Priya</span> [ </span>
                            <span class="text-info" id="call_lead_mobile">+91 9876543210</span>
                            <span>] Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="nav-align-top mb-2">
                                <ul class="nav nav-pills flex-nowrap call_navbar" role="tablist" >
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane call_log fade show active" id="tab_incoming_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Incoming Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_outgoing_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Outgoing Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                 <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_missed_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Missed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                 <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_dailled_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Dialed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                 <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -  Call Log-->

    <!--begin::Modal - Incoming Call Log-->
    <div class="modal fade" id="kt_modal_call_lead_history" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span><span >Priya</span> [ </span>
                            <span class="text-info" >+91 9876543210</span>
                            <span>] <span >Incoming Call History</span></span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                        <th class="min-w-125px px-1">Status</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7" id="call-history-data">
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Outgoing Call Log-->
    <div class="modal fade" id="kt_modal_outgoing_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Outgoing Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">02:20:00 PM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">02:21:20 PM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:20</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                        alt="Outgoing Call Icon"
                                                        class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:02 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:01:08</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Incoming Call Log-->

    <!--begin::Modal - Missed Call Log-->
    <div class="modal fade" id="kt_modal_missed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Missed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ecc093 !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:05 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:07 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:02</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Reject Call Log-->
    <div class="modal fade" id="kt_modal_reject_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Reject Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr style="background-color: #ff00004f !important;">
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/reject_call.ico') }}"
                                                        alt="Reject Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-info text-white fs-7 fw-semibold">10:40:10 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-danger text-white fs-7 fw-semibold">10:40:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:10</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Reject Call Log-->

    <!--begin::Modal - Dialed Call Log-->
    <div class="modal fade" id="kt_modal_dialed_call" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <span>Priya [ </span>
                            <span class="text-info">+91 9876543210</span>
                            <span>] Dialed Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Communicator</th>
                                        <th class="min-w-100px">Call Date</th>
                                        <th class="min-w-100px">Start Time</th>
                                        <th class="min-w-100px">End Time</th>
                                        <th class="min-w-100px">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:03:21 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:01:20 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="border border-gray-400i rounded px-2 py-1 me-2">
                                                    <img src="{{ asset('assets/phdizone_images/calls/dialed_call.ico') }}"
                                                        alt="Dialed Call Icon" class="w-20px h-25px text-black fw-bold">
                                                </div>
                                                <div class="mb-0">
                                                    <div class="text-truncate fs-7 fw-semibold max-w-125px"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Aarav">Aarav</div>
                                                    <div class="fs-8 text-dark fw-semibold">9788184348</div>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fs-7 fw-semibold">08-Mar-2025</div>
                                        </td>
                                        <td>
                                            <div class="text-info fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="text-danger fs-7 fw-semibold">11:00:04 AM</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black fs-7 fw-semibold">00:00:00</div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Dialed Call Log-->

    <!--begin::Modal - Appointment Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Schedule</h3>
                    </div>
                    <form id="followupForm" action="{{ route('add_appointment') }}" method="POST" novalidate autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id">
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_name_app">
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_phone_app"></div>
                        </div>
                         
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date<span
                                    class="text-danger">*</span></label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="lead_apt_sch"  name="appointment_date" placeholder="Select Date"
                                    class="form-control" value="" />
                            </div>
                            <div class="text-danger" id="apt_date_err"></div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control common_time_class" placeholder="HH:MM" id="apt_time_followp" name="appointment_time" />
                            <div class="text-danger" id="apt_time_err"></div>
                        </div>
                        <div class="d-flex justify-content-center align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="followupBtn" class="btn btn-primary" onclick="FollowupvalidateForm()" >Schedule</button>
                        </div>
                    </div>
                    </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Appointment Schedule-->

    <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_name_reop">
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_phone_reop">
                                </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"  id="app_date">
                                </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="app_time">
                            </div>
                        </div>
                        <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                            <div class="text-black fs-5 fw-semibold">
                                <span>Reschedule Count</span>
                                <span class="badge bg-danger fs-6 text-white rounded" id="followup_reschedule_rep_count">00</span>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                    class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="progressed" id="progressed" value="1" name="progressed"
                                    onclick="progress_func('yes');" checked />
                                <label class="form-check-label">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="progressed" id="progressed" value="2" name="progressed"
                                    onclick="progress_func('no');" />
                                <label class="form-check-label">No</label>
                            </div>
                        </div>
                    </div>
                    <div id="message" name="message">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="app_score" onclick="onlyOne(this)" value="1" checked  />
                                    <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="app_score" onclick="onlyOne(this)" value="-1" />
                                    <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="app_score" onclick="onlyOne(this)" value="0"/>
                                    <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-3">
                                <textarea class="form-control" rows="3" id="convo_message" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });" placeholder="Enter Conversation Message"></textarea>
                                 <div class="text-danger" id="convo_message_err"></div>
                            </div>
                        </div>
                        <div class="border-bottom mb-3 mt-2"></div>
                    </div>
                    <div id="reason" name="reason" style="display: none !important;">
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="app_reason" name="app_reason" onchange="toggleInputField_followup(this.value)">
                                    <option value="">Select Reason</option>
                                     @if (isset($followupReasonList))
                                      @foreach ($followupReasonList as $s_reason)
                                      <option value="{{ $s_reason->reason_name }}"
                                          data-comments-check-followup="{{ $s_reason->comments_check }}">
                                          {{ $s_reason->reason_name }}
                                      </option>
                                      @endforeach
                                      @endif
                                      <option value="1">Others</option>
                                </select>
                                <div class="text-danger" id="app_reason_select_err"></div>
                                 <div class="mt-4" id="followup_reason_div" style="display: none;">
                                    <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="followup_reason_text" id="followup_reason_text"
                                        value="" placeholder="Enter Reason">
                                         <div class="text-danger" id="followup_comments_text_err"></div>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span class="text-danger">*</span></label>
                                    <div class="input-group input-group-merge">
                                        <span class="input-group-text"><i
                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                        <input type="text" id="re_app_date" placeholder="Select Date"
                                            class="form-control" value="" name="appointment_date" />
                                            
                                    </div> 
                                    <div class="text-danger" id="re_app_date_err"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control common_time_class_new" placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                        value="" />  
                                <div class="text-danger" id="re_app_time_err"></div>
                                </div>
                            </div>
                        </div>
                        <div class="border-bottom mb-3 mt-2"></div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="accordion">
                                <div class="accordion-item mb-2 active">
                                    <h2 class="accordion-header" id="headingPopoutOne">
                                        <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                            data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                            aria-controls="accordionPopoutOne">
                                            <span class="text-black fw-semibold fs-6">Followup History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6" id="app_count">00</span>
                                        </button>
                                    </h2>
                                    <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                        aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-50px">S.No</th>
                                                                <th class="min-w-125px">Last Followup<br>Date / Time</th>
                                                                <th class="min-w-125px">Followed By</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8" id="historicalLeadIdsTableBody">
                                                           
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="headingPopoutTwo">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#accordionPopoutTwo"
                                            aria-expanded="false" aria-controls="accordionPopoutTwo">
                                            <span class="text-black fw-semibold fs-6">Appointment History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6" id="apptmnt_count">00</span>
                                        </button>
                                    </h2>
                                    <div id="accordionPopoutTwo" class="accordion-collapse collapse"
                                        aria-labelledby="headingPopoutTwo" data-bs-parent="#accordionPopout">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-50px">S.No</th>
                                                                <th class="min-w-100px">Date / Time</th>
                                                                <th class="min-w-100px">Category</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                                <th class="min-w-100px">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8" id="appointmentLeadIdsTableBody">
                                                            
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id='rescheduleBtn' class="btn btn-primary" onclick="updateReshedule()" >Submit
                                Report</button>
                        </div>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->

    <!--begin::Modal - Again Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_again_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">New Followup</h3>
                    </div>
                    <form action="{{ route('add_appointment') }}" method="POST"  autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id_again">
                    <div class="row mt-4">
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold" >Lead</label>
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_name_app_again">
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold" >Lead Mobile</label> 
                            <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2" id="lead_phone_app_again">
                                </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i
                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                <input type="text" id="app_date_again" name="appointment_date" placeholder="Select Date"
                                    class="form-control cus_date_doj" value="{{date('d-M-Y')}}" />
                            </div>
                        </div>
                        <div class="col-lg-6 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                            <input type="text" class="form-control app_new_time_class" placeholder="HH:MM" id="app_time_again" name="appointment_time" />
                        </div>
                        <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                            <div class="text-black fs-5 fw-semibold">
                                <span>Reschedule Count</span>
                                <span class="badge bg-danger fs-6 text-white rounded" id="followup_reschedule_count_again">0</span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="accordion">
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="again_flw_headingPopoutOne">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutOne"
                                            aria-expanded="false" aria-controls="again_flw_accordionPopoutOne">
                                            <span class="text-black fw-semibold fs-6">Followup History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6" id="app_count_again">00</span>
                                        </button>
                                    </h2>
                                    <div id="again_flw_accordionPopoutOne" class="accordion-collapse collapse"
                                        aria-labelledby="again_flw_headingPopoutOne">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                 <th class="min-w-50px">S.No</th>
                                                                <th class="min-w-125px">Last Followup<br>Date / Time</th>
                                                                <th class="min-w-125px">Followed By</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8" id="historicalLeadIdsTableBodyAgain">
                                                           
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item mb-2">
                                    <h2 class="accordion-header" id="again_flw_headingPopoutTwo">
                                        <button type="button" class="accordion-button collapsed"
                                            data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutTwo"
                                            aria-expanded="false" aria-controls="again_flw_accordionPopoutTwo">
                                            <span class="text-black fw-semibold fs-6">Appointment History</span>
                                            <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                            <span class="badge bg-info rounded text-white fw-semibold fs-6" id="apptmnt_count_again">0</span>
                                        </button>
                                    </h2>
                                    <div id="again_flw_accordionPopoutTwo" class="accordion-collapse collapse"
                                        aria-labelledby="again_flw_headingPopoutTwo">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <div class="col-lg-12 mb-0">
                                                    <table
                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                <th class="min-w-50px">S.No</th>
                                                                <th class="min-w-100px">Date / Time</th>
                                                                <th class="min-w-100px">Category</th>
                                                                <th class="min-w-100px">Conversation</th>
                                                                <th class="min-w-100px">Reason</th>
                                                                <th class="min-w-100px">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-black fw-semibold fs-8" id="appointmentLeadIdsTableBodyAgain">
                                                            
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3"
                                data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">Schedule</button>
                        </div>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Again Followup Lead Schedule-->

    <!--begin::Modal - Customer Inactivate-->
    <div class="modal fade" id="kt_modal_lead_inactivate" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Inactivate?
                    <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer Inactivate-->
    <!--begin::Modal - Customer HotLead-->
    <div class="modal fade" id="kt_modal_hot_lead" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Change Status to Hot Lead?</div>
                <div class="text-center">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="/manage_lead" class="btn btn-primary me-3">
                        Yes
                    </a>
                    <!-- <button type="submit" class="btn btn-primary me-3" data-bs-dismiss="modal">Yes</button> -->
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer HotLead-->

    <!--begin::Modal - Generate Quotation-->
    <div class="modal fade" id="kt_modal_lead_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You  Want
                    To Generate Proposal?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label id="proposal_lead_name">Priya</label>
                        <span class="ms-2 me-2">-</span>
                        <label id="proposal_lead_genrate_id">LD-0006/24</label>
                        <input type="hidden" name="proposal_lead_id" id="proposal_lead_id">
                    </div>
                </div>

                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button"  onclick="createProposal()" class="btn btn-primary me-3">
                        Yes
                     </button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Generate Quotation-->

    <!--begin::Modal - Lead Drop-->
    <div class="modal fade" id="kt_modal_lead_drop" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">

        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Change Status Lead to Dead Lead ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="drop_reason_form" method="POST" action="{{ url('/submit_drop_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <input type="hidden" name="staff_id_drop" id="staff_id_drop">

                        <select id="reason_edit" name="reason_edit" class="select3 form-select"
                            onchange="toggleInputField(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_drop) && count($reasonList_drop) > 0)
                            @foreach ($reasonList_drop as $d_reason)
                            <option value="{{ $d_reason->reason_name }}"
                                data-comments-check="{{ $d_reason->comments_check }}">
                                {{ $d_reason->reason_name }}
                            </option>
                            @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_edit_select_err"></div>
                        <div class="mt-4" id="drop_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="drop_reason_text" id="drop_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                <div class="text-danger" id="reason_edit_err"></div>
                        </div>
                        <div class="mt-4" id="drop_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="drop_comments_text" id="drop_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="drop_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_drop" id="lead_id_drop">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>

        {{-- <div class="modal-dialog modal-m">
            <div class="modal-content rounded">

                <!-- Warning Icon -->
                <div class="swal2-icon swal2-danger swal2-icon-show d-flex">
                    <div class="swal2-icon-content">?</div>
                </div>

                <!-- Modal Body Text -->
                <div class="swal2-html-container" style="display: block;">
                    Are You Sure Want To Change Status to Drop?

                    <div class="text-center mt-2">
                        <label class="text-danger fw-bold fs-5 lead-name"></label>
                    </div>

                    <!-- Form -->
                    <form id="drop_reason_form" method="POST" action="{{ url('/submit_drop_reason') }}">
                        @csrf

                        <div class="">

                            <input type="hidden" name="staff_id_drop" id="staff_id_drop">

                            <!-- Reason dropdown -->
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Reason
                                <span class="text-danger">*</span>
                            </label>

                            <select id="reason_edit" name="reason_edit" class="select3 form-select"
                                onchange="toggleInputField(this.value)">
                                <option value="">Select Reason</option>

                                @if(isset($reasonList_drop) && count($reasonList_drop) > 0)
                                    @foreach($reasonList_drop as $d_reason)
                                        <option value="{{ $d_reason->reason_name }}"
                                            data-comments-check="{{ $d_reason->comments_check }}">
                                            {{ $d_reason->reason_name }}
                                        </option>
                                    @endforeach
                                @endif

                                <option value="1">Others</option>
                            </select>

                            <div class="text-danger" id="reason_edit_select_err"></div>

                            <!-- Other Reason -->
                            <div class="mt-4" id="drop_reason_div" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" name="drop_reason_text" id="drop_reason_text"
                                    placeholder="Enter Reason"
                                    oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, t => t.toUpperCase());">
                            </div>

                            <div class="text-danger" id="reason_edit_err"></div>

                            <!-- Comments -->
                            <div class="mt-4" id="drop_comments_div" style="display: none;">
                                <label class="text-dark mb-1 fs-6 fw-semibold required">Comments
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control" name="drop_comments_text" id="drop_comments_text"
                                    placeholder="Enter Comments"
                                    oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, t => t.toUpperCase());">
                            </div>

                            <div class="text-danger" id="drop_comments_edit_err"></div>

                        </div>

                        <input type="hidden" name="lead_id_drop" id="lead_id_drop">

                        <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                            <button type="submit" class="btn btn-primary me-3">Yes</button>
                            <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        </div>

                    </form>
                    <!-- End Form -->

                </div>
                <!-- End Modal Body -->

            </div>
        </div> --}}

    </div>
    <!--end::Modal - Lead Drop-->


    <!--begin::Modal - Lead potential-->
    <div class="modal fade" id="kt_modal_lead_potential" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Move Lead to Lead Baseket ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="potential_reason_form" method="POST" action="{{ url('/submit_potential_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <input type="hidden" name="staff_id_potential" id="staff_id_potential">

                        <select id="potential_reason_edit" name="potential_reason_edit" class="select3 form-select"
                            onchange="toggleInputField_potential(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_potential) && count($reasonList_potential) > 0)
                            @foreach ($reasonList_potential as $p_reason)
                            <option value="{{ $p_reason->reason_name }}" data-comments-check-potential="{{ $p_reason->comments_check }}">
                                {{ $p_reason->reason_name }}
                            </option>
                            @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="potential_reason_edit_select_err"></div>
                        <div class="mt-4" id="potential_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="potential_reason_text" id="potential_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                                <div class="text-danger" id="reason_edit_err"></div>
                        </div>
                        <div class="mt-4" id="potential_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="potential_comments_text" id="potential_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="potential_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_potential" id="lead_id_potential">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
    </div>
    <!--end::Modal - Lead potential-->

    <!--end::Modal - Lead Drop-->

    <!--begin::Modal - Activate Lead-->
    <div class="modal fade" id="kt_modal_lead_activate" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want
                    To Change Status to Activate?
                    <div class="text-center mt-2">
                        <label class="text-danger fw-bold fs-5 lead-name"></label>
                    </div>
                </div>
                <form id="updateStatusForm" action="{{ route('lead_status') }}" method="POST" >
                    @csrf
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Activate Lead-->

    <!--begin::Modal - Customer Spam-->
    <div class="modal fade" id="kt_modal_lead_spam" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Change Status Lead to Spam Lead ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead-name"></label>
                </div>
                <form id="drop_reason_form" method="POST" action="{{ url('/submit_spam_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="spam_reason_edit" name="spam_reason_edit" class="select3 form-select"
                            onchange="toggleInputField_spam(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList) && count($reasonList) > 0)
                            @foreach ($reasonList as $s_reason)
                            <option value="{{ $s_reason->reason_name }}"
                                data-comments-check="{{ $s_reason->comments_check }}">
                                {{ $s_reason->reason_name }}
                            </option>
                            @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="spam_reason_edit_select_err"></div>
                        <div class="mt-4" id="spam_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_reason_text" id="spam_reason_text"
                                value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="spam_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_comments_text" id="spam_comments_text"
                                value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="spam_reason_edit_err"></div>
                        <div class="text-danger" id="spam_comments_edit_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_spam" id="lead_id_spam">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Customer Spam-->
    <!--begin::Modal -Lead internal_call-->
    <div class="modal fade" id="kt_modal_internal_call_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Convert to Internal Calls?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 internal_name"></label>
                </div>
                <form id="internal_reason_form" method="POST" action="{{ url('/submit_internal_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_internal_select" name="reason_internal_select" class="select3 form-select"
                            onchange="toggleInputField_internal(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_internal) && count($reasonList_internal) > 0)
                            @foreach ($reasonList_internal as $i_reason)
                            <option value="{{ $i_reason->reason_name }}"
                                data-comments-check="{{ $i_reason->comments_check }}">
                                {{ $i_reason->reason_name }}
                                @endforeach
                                @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_internal_select_err"></div>
                        <div class="mt-4" id="internal_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_reason_text"
                                id="internal_reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="internal_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="internal_comments_text"
                                id="internal_comments_text" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="internal_reason_text_err"></div>
                        <div class="text-danger" id="internal_comments_text_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_internal" id="lead_id_internal">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead internal_call-->
    
    <!--begin::Modal -Lead internal_call-->
    <div class="modal fade" id="kt_modal_lead_bank_trans" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To
                    Convert to Lead Bank ?</div>
                <div class="text-center mt-2">
                    <label class="text-danger fw-bold fs-5 lead_bank_name"></label>
                </div>
                <form id="lead_bank_reason_form" method="POST" action="{{ url('/submit_lead_bank_reason') }}">
                    @csrf
                    <div class="d-block mx-4 my-4">
                        <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_lead_bank_select" name="reason_lead_bank_select" class="select3 form-select"
                            onchange="toggleInputField_lead_bank(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_lead_bank) && count($reasonList_lead_bank) > 0)
                                @foreach ($reasonList_lead_bank as $bres)
                                <option value="{{ $bres->reason_name }}" data-comments-check="{{ $bres->comments_check }}">{{ $bres->reason_name }}
                                @endforeach
                            @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_lead_bank_select_err"></div>
                        <div class="mt-4" id="lead_bank_reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="lead_bank_reason_text"
                                id="lead_bank_reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="mt-4" id="lead_bank_comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="lead_bank_comments_text"
                                id="lead_bank_comments_text" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                        </div>
                        <div class="text-danger" id="lead_bank_reason_text_err"></div>
                        <div class="text-danger" id="lead_bank_comments_text_err"></div>
                    </div>
                    <!-- Hidden field for lead ID -->
                    <input type="hidden" name="lead_id_lead_bank" id="lead_id_lead_bank">
                    <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                        <button type="submit" class="btn btn-primary me-3">Yes</button>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Lead internal_call-->

    <!--begin::Modal - Proposal Details-->
    <div class="modal fade" id="kt_modal_view_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row" id="proposal_list">
                        
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Proposal Details-->

    <!--begin::Modal - View Only Proposal Details-->
    <div class="modal fade" id="kt_modal_view_only_quotation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Proposal Detail
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="bg-label-success rounded-circle fw-semibold"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Proposal Accepted"><i
                                                class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">02</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003670/04/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">02-Apr-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">07-Apr-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,21,068</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                                <a href="{{ url('/manage_proposal/proposal_print') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count">01</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">PRO-003669/03/2025</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">27-Mar-2025</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">31-Mar-2025</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; 1,36,998</label>
                                            </div>
                                            <div class="d-block text-end">
                                                <a href="{{ url('/manage_proposal/proposal_view') }}" target="_blank"
                                                    class="btn btn-icon btn-sm me-2" title="View Proposal"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                                <!-- <a href="{{ url('/manage_invoice/quote_to_invoice') }}" target="_blank" class="btn btn-icon btn-sm me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generate Invoice">
                                                        <i class="mdi mdi-invoice-text-plus-outline fs-3 text-dark"></i>
                                                    </a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Only Proposal Details-->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Spam Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_spm_verify_spam" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Verify Spam - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to confirm this lead is
                        spam ?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">Irrelevant Call [ Looking for job related to
                        washing machine, fridge service ]</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3">Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Spam Lead (Verify Status)- -->

    <!--begin::Modal - Convert Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_spm_convert_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Convert Lead - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to convert this lead ?
                    </div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Before Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" >Convert Lead</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead (Verify Status)- -->


    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Dead Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_dd_verify_dead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Verify Drop - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to confirm this lead is
                        Drop ?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Mahalakshmi [ +91 9894075505 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">No Response from Lead</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3" >Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Dead Lead (Verify Status)- -->

    <!--begin::Modal - Convert Lead (Verify Status)-->
    <div class="modal fade" id="kt_modal_dd_convert_dead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Convert Lead - Team Lead</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to convert this lead ?
                    </div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Suman [ +91 7428502897 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Before Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assigned Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Assigned Staff</option>
                                <option value="1">Aarav - Sales Executive</option>
                                <option value="2">Varathan - Sales Executive</option>
                                <option value="3">Vishnu - Sales Executive</option>
                                <option value="3">Jothi - Sales Team Lead</option>
                            </select>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" >Convert Lead</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Lead (Verify Status)- -->

    <!-- ------------------------------------------------------------------------------------------------------------------------- -->

    <!--begin::Modal - Internal Calls (Approve Status)-->
    <div class="modal fade" id="kt_modal_int_call_approve" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Approve Internal Calls</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to approve this lead as
                        Internal Call?</div>
                    <div class="text-center text-danger mb-4 fs-5 fw-semibold">Yogalakshmi [ +91 8122374265 ]</div>
                    <div class="text-dark mb-1 fs-5 fw-semibold"><u>Reason</u> &nbsp; :</div>
                    <div class="text-black mb-6 fs-6 fw-semibold ms-4">No Response from Lead</div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Verification Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Verification Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <a href="javascript:;" class="btn btn-primary me-3" >Yes</a>
                        <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls (Approve Status) -->

    <!--begin::Modal - Internal Calls (Reject Status)-->
    <div class="modal fade" id="kt_modal_int_call_reject" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Reject Internal Calls</h3>
                    </div>
                    <div class="text-center text-dark mb-2 fs-5 fw-semibold">Are you sure want to reject this call ?</div>
                    <div class="text-center text-danger mb-6 fs-5 fw-semibold">Yogalakshmi [ +91 8122374265 ]</div>
                    <div class="row mb-2">
                        <label class="col-4 text-dark fs-5 fw-semibold">Sales Staff &emsp; : &emsp;</label>
                        <label class="col-7 text-info fs-4 fw-semibold">Aarav</label>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Rejected Reason<span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3" placeholder="Enter Rejected Reason"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" >Reject</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Internal Calls (Reject Status)- -->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <style>
        .dataTables_scroll3 {
            position: relative;
            overflow: auto;
            max-height: 400px;
            /*the maximum height you want to achieve*/
            width: 100%;
        }

        .dataTables_scroll3 thead {

            position: -webkit-sticky;
            position: sticky;
            top: 0;
            background-color: #fff;
            z-index: 2;
        }
    </style>

    <style>

       .source-label {
        position: relative; /* Ensure the label is positioned relative for absolute positioning of ::before */
        display: inline-block;
        }
    
        .source-label::before {
            /*content: '\1F31F'; */
            content: '\2728'; /* ðŸŒŸ Sparkles */
            position: absolute;
            top: -12px; /* Move it further up */
            left: 90%; /* Center it horizontally */
            transform: translateX(-50%); /* Adjust horizontal alignment */
            font-size: 1rem;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }
        
        
         .jd-blue {
       color: #1976d2; /* Justdial Blue */
        font-weight: bold;
        }

        .jd-orange {
            color: #f16522; /* Justdial Orange */
            font-weight: bold;
        }
        .jd-blue, .jd-orange {
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }
        .cc-purple {
        color: #5c2d91; /* CloudCall Purple */
        font-weight: bold;
        }

        .cc-orange {
            color: #f58220; /* CloudCall Orange */
            font-weight: bold;
        }

        /* Cloud Icon Styling */
        .cc-icon {
            color: #5c2d91; /* Matching CloudCall Purple */
            margin-right: 5px;
        }


        .ct-black {
        color: #000000; /* Call in Black */
        font-weight: bold;
        }

        .ct-orange {
            background-color: #f16522; /* Justdial Orange */
            color: #ffffff; /* White text inside */
            /*font-weight: bold;*/
            padding: 2px 6px;
            border-radius: 4px;
        }

        /* Call Icon Styling */
        .ct-icon {
            color: #000000; /* Black Call Icon */
            font-size: 14px;
            margin-left: 3px;
        }

            
        /* Loading Dots */
        .loading-dots {
            display: flex;
            gap: 8px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Individual Balls */
        .loading-dots span {
            width: 15px;
            height: 15px;
            background-color: rgb(32, 32, 34);
            border-radius: 50%;
            opacity: 0;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }

        /* Add More Balls with Delay */
        .loading-dots span:nth-child(1) { animation-delay: 0s; }
        .loading-dots span:nth-child(2) { animation-delay: 0.2s; }
        .loading-dots span:nth-child(3) { animation-delay: 0.4s; }
        .loading-dots span:nth-child(4) { animation-delay: 0.6s; }
        .loading-dots span:nth-child(5) { animation-delay: 0.8s; }
        .loading-dots span:nth-child(6) { animation-delay: 1s; }

        /* Animation */
        @keyframes fadeInOut {
            0%, 100% {
                opacity: 0;
                transform: scale(0.8);
            }
            50% {
                opacity: 1;
                transform: scale(1);
            }
        }
            
        
            /* Stylish Fade Effect Box */
            .fade-effect {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: linear-gradient(45deg, #dbdd47, #ccce43);
                color: rgb(255, 255, 255);
                font-weight: bold;
                font-size: 18px;
                text-align: center;
                line-height: 60px;
                border-radius: 10px;
                text-shadow: 0 0 5px rgba(137, 92, 219, 0.5),
                            0 0 10px rgba(137, 92, 219, 0.5),
                            0 0 20px rgba(137, 92, 219, 0.5); /* Intense Neon Glow */
                box-shadow: 0 0 15px rgba(137, 92, 219, 0.5),
                        0 0 25px rgba(16, 168, 185, 0.8),
                        0 0 35px rgba(137, 92, 219, 0.5); /* Red & Black Glow */
                letter-spacing: 2px;
                opacity: 0; /* Initially hidden */
                transition: all 0.5s ease-in-out;
                animation: shimmer 3s infinite alternate, runText 12s linear infinite, fadeEffect 3s infinite alternate;
            }
        
            /* Hover Glow Effect */
            .fade-effect:hover {
            box-shadow: 0 0 15px rgba(135, 0, 0, 0.7),
                        0 0 25px rgba(25, 10, 5, 0.8),
                        0 0 35px rgba(135, 0, 0, 0.6); /* Red & Black Glow */
                transform: scale(1.05); /* Slight Zoom */
            }
        
            /* Running Text Animation */
            @keyframes runText {
                from {
                    left: 100%;
                }
                to {
                    left: -100%;
                }
            }
        
            /* Fade Effect Animation */
            @keyframes fadeEffect {
                0% {
                    opacity: 0.3;
                }
                100% {
                    opacity: 1;
                }
            }
            @keyframes shimmer {
                0% {
                    background-position: -200%;
                }
                100% {
                    background-position: 200%;
                }
            }
        
            /* Blinking text animation */
            .blink {
                /*animation: blinker 1.5s linear infinite;*/
                /* font-weight: bold; */
                color: white; /* White text for better contrast */
            }

            @keyframes blinker {
                50% {
                    opacity: 0;
                }
            }

            /* Cute background and style for the 'New!' label */
            .new-label {
                background-color: #ff7eb9; /* Soft pink color */
                padding: 0px 8px;
                border-radius: 12px; /* Rounded corners */
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Soft shadow for depth */
                font-size: 0.3rem; /* Slightly larger text */
                text-transform: uppercase;
                position: relative;
            }

            /* Adding a cute icon or star effect */
            .new-label::before {
                content: 'ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨'; /* You can replace this with any icon or emoji */
                position: absolute;
                top: -8px;
                right: -10px; /* Changed from left to right */
                font-size: 0.9rem;
                animation: bounce 2s infinite;
            }


            /* Bounce animation for cute effect */
            @keyframes bounce {
                0%, 20%, 50%, 80%, 100% {
                    transform: translateY(0);
                }
                40% {
                    transform: translateY(-8px);
                }
                60% {
                    transform: translateY(-4px);
                }
            }
    </style>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    
     <script>
      function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#filter_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#filter_form').submit();
        }
      }
    </script>

    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>
    
<script>
        function ConvertIntern(id, leadName, mobile) {
            document.getElementById('lead_id_intern').value = id;
            document.getElementById('lead-name_intern').innerText = leadName;
            document.getElementById('lead-mobile_intern').innerText = `[${mobile}]`;
        }
      function toggleAddSpam(value) {
          var ReasonDiv = document.getElementById('reason_div');
          var ReasonText = document.getElementById('reason_text');
          var CommentsDiv = document.getElementById('comments_div');
          var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
          var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;
    
          if (value == '1') {
              ReasonDiv.style.display = 'block';
              ReasonText.setAttribute('required', 'required');
          } else {
              ReasonDiv.style.display = 'none';
              ReasonText.removeAttribute('required');
          }
    
          if (commentsCheck == '1') {
              CommentsDiv.style.display = 'block';
          } else {
              CommentsDiv.style.display = 'none';
          }
      }
</script>
    <script>
  function spamAddvalidateForm() {
      var err = 0;

      // Get mobile number and validate
      var lead_mobile_spam = document.getElementById("lead_mobile_spam").value.trim();
      var mobilePattern = /^\d{10}$/; // Regular expression to match exactly 10 digits

      if (lead_mobile_spam === "") {
          document.getElementById('lead_mobile_spam_err').innerHTML = 'Mobile number is required...!';
          err++;
      } else if (!mobilePattern.test(lead_mobile_spam)) {
          document.getElementById('lead_mobile_spam_err').innerHTML = 'Mobile number must be 10 digits...!';
          err++;
      } else {
          document.getElementById('lead_mobile_spam_err').innerHTML = '';
      }

     // Get other fields and validate
      var spam_reason = document.getElementById("spam_reason");
      var reason_text = document.getElementById("reason_text");
      var spam_comments = document.getElementById("spam_comments");

      // Clear error messages for reason and comments
      document.getElementById('reason_text_err').innerHTML = '';
      document.getElementById('spam_comments_err').innerHTML = '';

      // Check if spam reason is provided
      if (!spam_reason || spam_reason.value === "") {
          // alert('reason valid');
          document.getElementById('reason_select_err').innerHTML = 'Reason is required...!';
          err++;
      } else if (spam_reason.value === "1") {
          // alert('other reason valid');
          if (!reason_text || reason_text.value.trim() === "") {
              document.getElementById('reason_text_err').innerHTML = 'Other reason is required...!';
              err++;
          }
      }

      // Check if the selected reason's comments_check is 1 before validating comments
      var selectedReasonOption = spam_reason.options[spam_reason.selectedIndex];
      var commentsCheck = selectedReasonOption ? selectedReasonOption.getAttribute('data-comments-check') : null;

      if (commentsCheck == "1" && (!spam_comments || spam_comments.value.trim() === "")) {
          // alert('comments valid');
          document.getElementById('spam_comments_err').innerHTML = 'Comments are required...!';
          err++;
      }

      // If no errors, submit the form
      if (err === 0) {
          $('#spamAddForm').submit();
          $('#submit_spam_add').prop('disabled', true);
      } else {
          $('#submit_spam_add').prop('disabled', false);
      }
  }
</script>

<script>

      function populateViewModal(categoryId) {
        fetch(`/lead_view/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data;
                    // console.log(lead);

                    // Function to format date to '10-Jun-2024'
                    function formatDate(dateString) {
                        if (!dateString) return '-'; // Handle null or undefined dates
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }


                    $('#lead_id_view').html(lead.lead_id || '-');
                    $('#lead_created').html(formatDate(lead.created_at));
                    $('#lead_name_view').html(lead.lead_name || '-');
                    $('#lead_mobile_view').html(lead.lead_mobile || '-');
                    $('#lead_alternate_view').html(lead.lead_alternate_mobile || '-');
                    $('#lead_email_view').html(lead.lead_email_id || '-');

                    const gender = lead.lead_gender === 1 ? 'Male' : (lead.lead_gender === 2 ? 'Female' : 'Other');
                    $('#lead_gender_view').html(gender);

                    $('#lead_dob_view').html(formatDate(lead.lead_dob));

                    const maritalStatus = lead.lead_marital_status === 1 ? 'Married' : (lead.lead_marital_status === 2 ? 'Unmarried' : '-');
                    $('#lead_marital_view').html(maritalStatus);

                    
                    let imageUrl =lead.potential_type_image ?  `{{ asset('potential_image/') }}/${lead.potential_type_image}` : '';

                    document.getElementById('potential_image_view').src = imageUrl;
                
                    $('#view_lead_auto_id').html(lead.lead_id || '-');
                    $('#lead_type_view').html(lead.lead_type_name || '-');
                    $('#lead_source_view_h').html(lead.lead_source_name || '-');
                    $('#view_leadsource').html(lead.leadsourcename || '-');
                    $('#view_university').html(lead.universityname || '-');
                    $('#lead_potential_view').html(lead.potential_type_name || '-');
                    // $('#view_edit_id').val(lead.sno || '');
                    $('#view_address').html((lead.address || '') + ' '+ lead.citiesname + ' '+  lead.statename +' '+  lead.name);
                    $('#view_leadtype').html(lead.leadtypename ||'-');
                    $('#view_potentialtype').html(lead.potential_type_name ||'-');
                    $('#view_comments').html(lead.lead_comments ||'-');
                    $('#view_category').html(lead.product_category_name ||'-');
                    $('#view_service').html(lead.product_name ||'-');

                    // if(lead.status == 4) {
                    //     $('#edit_icon').hide();
                    // } else {
                    //     $('#edit_icon').show();
                    // }

                    // Assuming lead.lead_knowledge_tags is your JSON array or string
                    let tagsString = '-';
                    if (lead.lead_knowledge_tags) {
                        const tagsArray = Array.isArray(lead.lead_knowledge_tags) ? lead.lead_knowledge_tags : JSON.parse(lead.lead_knowledge_tags);
                        tagsString = tagsArray.map(tag => tag.value).join(', ');
                    }
                    $('#lead_tag_view').html(tagsString);

                } else {
                    console.error('Error fetching category:', data.message);
                    // Optionally, show an alert or update the UI to reflect the error.
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
                // Optionally, show an alert or update the UI to reflect the error.
            });
      }
      
      
</script>
<script>
  function toggleInputField_internal(value) {
      var internalReasonDiv = document.getElementById('internal_reason_div');
      var internalReasonText = document.getElementById('internal_reason_text');
      var internalCommentsDiv = document.getElementById('internal_comments_div');
      var selectedOption = document.querySelector('#reason_internal_select option:nth-child(' + (document.getElementById('reason_internal_select').selectedIndex + 1) + ')');
      var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

      if (value == '1') {
          internalReasonDiv.style.display = 'block';
          internalReasonText.setAttribute('required', 'required');
      } else {
          internalReasonDiv.style.display = 'none';
          internalReasonText.removeAttribute('required');
      }

      if (commentsCheck == '1') {
          internalCommentsDiv.style.display = 'block';
      } else {
          internalCommentsDiv.style.display = 'none';
      }
  }
  

</script>
<script>
  function internalCalls(id, leadName) {
      $('#kt_modal_internal_call_lead').modal('show');
      $('#kt_modal_internal_call_lead .internal_name').text(leadName);

      $('#lead_id_internal').val(id);

      $('#kt_modal_internal_call_lead .btn-primary').off('click').on('click', function() {
          // Validate the reason selection
          const reason = $('#reason_internal_select').val();
          const otherReason = $('#internal_reason_text').val();
          const comments = $('#internal_comments_text').val();

          if (!reason) {
              $('#reason_internal_select_err').text('Reason is Required');
              return false;
          }else {
              $('#reason_internal_select_err').text('');
          }
          // Check if the selected reason's comments_check is 1 before validating comments
          const selectedReasonOption = $('#reason_internal_select option:selected');
          const commentsCheck = selectedReasonOption.data('comments-check');

          if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
              $('#internal_comments_text_err').text('Comments are required');
              return false;
          }else {
              $('#internal_comments_text_err').text('');
          }

          if (reason == '1' && !otherReason.trim()) {
              $('#internal_reason_text_err').text('Other Reason is required');
              return false;
          }else {
              $('#internal_reason_text_err').text('');
          }
      });
  }
  </script>
<script>
  function LeadbankCalls(id, leadName) {
      $('#kt_modal_lead_bank_trans').modal('show');
      $('#kt_modal_lead_bank_trans .lead_bank_name').text(leadName);

      $('#lead_id_lead_bank').val(id);

      $('#kt_modal_lead_bank_trans .btn-primary').off('click').on('click', function() {
          // Validate the reason selection
          const reason = $('#reason_lead_bank_select').val();
          const otherReason = $('#lead_bank_reason_text').val();
          const comments = $('#lead_bank_comments_text').val();

          if (!reason) {
              $('#reason_lead_bank_select_err').text('Reason is Required');
              return false;
          }else {
              $('#reason_lead_bank_select_err').text('');
          }
          // Check if the selected reason's comments_check is 1 before validating comments
          const selectedReasonOption = $('#reason_lead_bank_select option:selected');
          const commentsCheck = selectedReasonOption.data('comments-check');

          if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
              $('#lead_bank_comments_text_err').text('Comments are required');
              return false;
          }else {
              $('#lead_bank_comments_text_err').text('');
          }

          if (reason == '1' && !otherReason.trim()) {
              $('#lead_bank_reason_text_err').text('Other Reason is required');
              return false;
          }else {
              $('#lead_bank_reason_text_err').text('');
          }
      });
  }
  
    function toggleInputField_lead_bank(value) {
        var internalReasonDiv = document.getElementById('lead_bank_reason_div');
        var internalReasonText = document.getElementById('lead_bank_reason_text');
        var internalCommentsDiv = document.getElementById('lead_bank_comments_div');
        var selectedOption = document.querySelector('#reason_lead_bank_select option:nth-child(' + (document.getElementById('reason_lead_bank_select').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;
        if (value == '1') {
          internalReasonDiv.style.display = 'block';
          internalReasonText.setAttribute('required', 'required');
        } else {
          internalReasonDiv.style.display = 'none';
          internalReasonText.removeAttribute('required');
        }
        
        if (commentsCheck == '1') {
          internalCommentsDiv.style.display = 'block';
        } else {
          internalCommentsDiv.style.display = 'none';
        }
    }
  
</script>

    <!-- show bulk conversion button -->
    <script>
         $('#bulk_checkall').change(function () {
            $('.bulk_chk').prop('checked',this.checked);
        });

        $('.bulk_chk').change(function () {
        if ($('.bulk_chk:checked').length == $('.bulk_chk').length){
          $('#bulk_checkall').prop('checked',true);
        }
        else {
          $('#bulk_checkall').prop('checked',false);
        }
        });
        function showConversionBtn() {
            
            var bulkCheckAll = document.getElementById('bulk_checkall');

            if(bulkCheckAll.checked){
                $('#bulkConversionBtn').show();
            }else {
                $('#bulkConversionBtn').hide();
            }

        }
        function singleShowConversionBtn() {
            var checkboxes = document.querySelectorAll('.bulk_chk');
            var isAnyChecked = false;
            checkboxes.forEach(function(checkbox) {
                if (checkbox.checked) {
                    isAnyChecked = true;
                }
            });

            if(isAnyChecked) {
                $('#bulkConversionBtn').show();
            } else {
                $('#bulkConversionBtn').hide();
            }
        }

    </script>

    <!-- phone number verify details -->
    <script>
        function phoneVerifyDetails(leadName, leadMobile, validStatus, carrier, lineType, location) {
            let statusMessage = validStatus ? "<span class='text-success'>Valid Number</span>" : "<span class='text-danger'>IN-Valid Number</span>";
            
            // Construct the message
            let message = `<div class="row mb-4">`;
            message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Lead</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 text-black fs-6 mb-2 fw-bold">${leadName}</label>`;

            message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Lead Mobile</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 text-black fs-6 mb-2 fw-bold">${leadMobile}</label>`;

            message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Status</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 fs-6 mb-2 fw-bold">${statusMessage}</label>`;

            if (carrier) message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Carrier</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 text-black fs-6 mb-2 fw-bold">${carrier}</label>`;

            if (lineType) message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Line Type</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 text-black fs-6 mb-2 fw-bold">${lineType}</label>`;

            if (location) message += `
                <label class="col-3 text-dark fs-6 mb-2 fw-semibold">Location</label>
                <label class="col-1 text-black fs-6 mb-2 fw-bold">:</label>
                <label class="col-8 text-black fs-6 mb-2 fw-bold">${location}</label>`;

            message += `</div>`;

            // Set content in the modal
            document.getElementById("phone_verify_modal_content").innerHTML = message;

            // Show modal
            var phoneVerifyModal = new bootstrap.Modal(document.getElementById("kt_modal_mob_no_verify"));
            phoneVerifyModal.show();
        }

 </script>
 <script>
  document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      // Small delay to allow modal animation to finish
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>


 <!-- lead transfer Log -->
    <script>
        function formatDateTransfer(dateString) {
            let date = new Date(dateString); 
            let day = String(date.getDate()).padStart(2, '0'); 
            let monthIndex = date.getMonth();
            let year = date.getFullYear(); 

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex]; 

            return `${day}-${month}-${year}`;
        }
        function leadTransfer(id, name, mobile_no, lead_src, reg_date = '') {
            $('#lead_id_transfer').val(id);
            $('#lead_name_transfer').html(name);
            $('#lead_mobile_transfer').html(mobile_no);
            $('#lead_src_transfer').html(lead_src);
            if(reg_date != ''){
                $('#lead_reg_date_transfer').html(formatDateTransfer(reg_date)); 
            } else {
                $('#lead_reg_date_transfer').html('-'); 
            }
            

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/lead_transfer/${id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken,
                },
                body: JSON.stringify({})
            })
            .then(response => response.json())
            .then(data => {
                // console.log('Data', data);

                if (data && data.data && Array.isArray(data.data)) {
                    const transferLogDiv = document.getElementById('transfer_log_div');
                    transferLogDiv.innerHTML = '';

                    const transferredFromMapping = {
                        0:  'Direct Lead',
                        1:  'Bulk Raw Lead - Lead',
                        2:  'Lead - Spam Lead',
                        3:  'Lead - Dead Lead',
                        4:  'Raw Lead - Lead',
                        5:  'Bulk Raw Lead - Lead',
                        6:  'Bank Raw Lead - Lead',
                        7:  'Bulk Bank Raw Lead - Lead',
                        8:  'Cloud Call - Lead',
                        9:  'Cloud Call - Spam Lead',
                        10: 'Call Tracker - Lead',
                        11: 'Call Tracker - Spam Lead',
                        12: 'Justdial - Lead',
                        13: 'Website - Lead ',
                        14: 'Spam Lead - Lead',
                        15: 'Dead Lead - Lead',
                        16: 'Lead - Potential Lead',
                        17: 'Potential Lead - Lead'
                    };


                    data.data.forEach(item => {
                        // let staffName =  item.end_date ? item.current_staff_name : item.change_staff_name;
                        let staffName =  item.current_staff_name;

                        // Map transferred_from to human-readable text
                        let transferredFromText = transferredFromMapping[item.transferred_from] || '-'; // Default to '-' if value is not found

                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${staffName || ''}</td>
                            <td>${transferredFromText}</td>
                            <td>${item.end_date ? formatDateTransfer(item.end_date) : '-'}</td> 
                            <td>${item.days_difference || ''}</td>
                        `;
                        transferLogDiv.appendChild(row);
                    });
                } else {
                        // If no transfer data is available, display a message
                    const transferLogDiv = document.getElementById('transfer_log_div');
                    transferLogDiv.innerHTML = '<tr><td></td><td colspan="4">There is no transfer of staff for the lead</td><td></td><td></td></tr>';
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);
                toastr.error('An error occurred: ' + error.message);
            });
        }
    </script>

<!-- status Change Function -->
 <script>
        function leadstatusupdate(statusId, status) {

            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            fetch(`/hot_lead_status_update/${statusId}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                    status: status

                }),
            })
            .then(data => {
                if (data.status === 200) {
                    toastr.success('Status Updated successfully!');
                    location.reload();
                } else {
                    toastr.error('Status Failed to update!');
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);

            });
        }


        function updatestatus(statusId, status) {
            // const statusId = status_id;
            // const status = document.getElementById('status_id').value;


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                fetch(`/status_update/${statusId}`, {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        status: status

                    }),
                })

                .then(data => {
                    if (data.status === 200) {
                        // alert(data.status);
                        toastr.success('Status Updated successfully!');
                        location.reload();
                    } else {
                        // toastr.error('Status Failed to update!');
                    }
                })
                .catch(error => {
                    console.error('Error updating category:', error);

                });
        }


        function inactiveModal(id, leadName) {
            $('#kt_modal_lead_inactivate').modal('show');
            $('#kt_modal_lead_inactivate .lead-name').text(leadName);
            $('#kt_modal_lead_inactivate .btn-primary').off('click').on('click', function() {
                updatestatus(id, 1); // Assuming status 1 is Inactive
                $('#kt_modal_lead_inactivate').modal('hide');
            });
            }
            //hot lead modal
            function hotLeadModal(id, leadName) {
            $('#kt_modal_hot_lead').modal('show');
            $('#kt_modal_hot_lead .lead-name').text(leadName);
            $('#kt_modal_hot_lead .btn-primary').off('click').on('click', function() {
            leadstatusupdate(id, 3); // Assuming status 1 is Inactive
                $('#kt_modal_hot_lead').modal('hide');
            });
        }

        function dropModal(id, leadName,staffId) {
            $('#kt_modal_lead_drop').modal('show');
            $('#kt_modal_lead_drop .lead-name').text(leadName);
            $('#staff_id_drop').val(staffId);

            $('#lead_id_drop').val(id);

            $('#kt_modal_lead_drop .btn-primary').off('click').on('click', function() {
                const reason = $('#reason_edit').val();
                const otherReason = $('#drop_reason_text').val();
                const comments = $('#drop_comments_text').val();

                if (!reason) {
                    $('#reason_edit_select_err').text('Reason is Required');
                    return false;
                }else {
                    $('#reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {  
                    $('#drop_comments_edit_err').text('Comments are required');
                    return false;
                }else {
                    $('#drop_comments_edit_err').text('');
                }

                if (reason == '1' && !otherReason.trim()) {
                    $('#reason_edit_err').text('Other Reason is required');
                    return false;
                }else {
                    $('#reason_edit_err').text('');
                }
            });
        }


        function PotentialModal(id, leadName,staffId) {
            $('#kt_modal_lead_potential').modal('show');
            $('#kt_modal_lead_potential .lead-name').text(leadName);
            $('#staff_id_potential').val(staffId);

            $('#lead_id_potential').val(id);

            $('#kt_modal_lead_potential .btn-primary').off('click').on('click', function() {
                const potential_reason = $('#potential_reason_edit').val();
                // alert(potential_reason)
                const otherReason = $('#potential_reason_text').val();
                const comments = $('#potential_comments_text').val();

                if (!potential_reason) {
                    $('#potential_reason_edit_select_err').text('Reason is Required');
                    return false;
                }else {
                    $('#potential_reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#potential_reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {  
                    $('#potential_comments_edit_err').text('Comments are required');
                    return false;
                }else {
                    $('#potential_comments_edit_err').text('');
                }

                if (potential_reason == '1' && !otherReason.trim()) {
                    $('#potential_reason_edit_err').text('Other Reason is required');
                    return false;
                }else {
                    $('#potential_reason_edit_err').text('');
                }
            });
        }

        function spamModal(id, leadName) {
            $('#kt_modal_lead_spam').modal('show');
            $('#kt_modal_lead_spam .lead-name').text(leadName);

            $('#lead_id_spam').val(id);

            $('#kt_modal_lead_spam .btn-primary').off('click').on('click', function() {            
                // Validate the reason selection
                const reason = $('#spam_reason_edit').val();
                const otherReason = $('#spam_reason_text').val();
                const comments = $('#spam_comments_text').val();

                if (!reason) {
                    $('#spam_reason_edit_select_err').text('Reason is Required');
                    return false;
                }else {
                    $('#spam_reason_edit_select_err').text('');
                }
                // Check if the selected reason's comments_check is 1 before validating comments
                const selectedReasonOption = $('#spam_reason_edit option:selected');
                const commentsCheck = selectedReasonOption.data('comments-check');

                if (commentsCheck == 1 && (!comments || comments.trim() === "")) {  
                    $('#spam_comments_edit_err').text('Comments are required');
                    return false;
                }else {
                    $('#spam_comments_edit_err').text('');
                }

                if (reason == '1' && !otherReason.trim()) {
                    $('#spam_reason_edit_err').text('Other Reason is required');
                    return false;
                }else {
                    $('#spam_reason_edit_err').text('');
                }
            });
        }

        function activeModal(id, leadName) {
            $('#kt_modal_lead_activate').modal('show');
            $('#kt_modal_lead_activate .lead-name').text(leadName);
            $('#kt_modal_lead_activate .btn-primary').off('click').on('click', function() {
                updatestatus(id, 0); // Assuming status 0 is Active
                $('#kt_modal_lead_activate').modal('hide');
            });
        }

        document.getElementById('updateStatusForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const statusId = document.getElementById('status_id').value;
            const status = document.getElementById('status_id').value;
            updatestatus(statusId, status);
            leadstatusupdate(statusId, status);
        });

 </script>

<!-- appointment -->
 <script>
        function lead_appointment_func(id,name){
            $('#search_lead_name').text(name);
            $('#lead_id_add').val(id);
            $.ajax({
                url: "{{ route('department') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="assg_dept_add"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                        response.data.forEach(function(dept) {
                            if(dept.sno == 1 || dept.sno ==2){
                            selectDropdown.append($('<option></option>').attr('value', dept
                                    .sno)
                                .text(dept.department_name));
                            }
                        });
                    }
                },
                error: function(error) {
                selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                    // console.error('Error fetching course Brand:', error);
                }
            });

        }

        function depat_staff_func(dept_id) {
          if (dept_id) {

            if(dept_id == 2){
                $('#assign_staff_or_pc').html('Assign PC');
            } else {
                $('#assign_staff_or_pc').html('Assign Staff');
            }

              $.ajax({
                  url: "{{ route('dept_staff') }}",
                  type: "GET",
                  data: {
                      dept_id: dept_id
                  },
                  success: function(response) {
                      if (response.status === 200 && response.data) {
                          var selectDropdown = $('#assg_staff_add');
                          selectDropdown.empty();
                          if(dept_id == 2){
                            selectDropdown.append(
                            '<option value="">Select PC</option>');
                          } else {
                            selectDropdown.append(
                            '<option value="">Select Staff</option>');
                          }
                          
                          if(dept_id == 2) {
                            response.data.forEach(function(staff) {
                                
                                if(Number(staff.role_id) === 15) {

                                    var option = $('<option></option>')
                                    .attr('value', staff.sno)
                                    .text(staff.staff_name + " - " + staff.position_name);
                                    selectDropdown.append(option);
                                }
                            });
                          } else {
                            response.data.forEach(function(staff) {
                                var option = $('<option></option>')
                                .attr('value', staff
                                .sno)
                                .text(staff.staff_name + " - "+staff.position_name);
                                selectDropdown.append(option);                                
                            });
                          }                                                          
                      }
                  },
                  error: function(error) {
                      console.error('Error fetching Staff:', error);
                  }
              });
          } else {
              $('#assg_staff_add').empty().append(
                  '<option value="">Select Staff</option>');
          }
        }

        function addLeadvalidateForm() {
              var err = 0;

              $('#addSubmit').prop('disabled', true);
              // Validate Lead Name
              var ld_name_add = document.getElementById("lead_id_add").value.trim();
              if (ld_name_add === "") {
                  document.getElementById('appt_reason_add_err').innerHTML = 'Lead Name is required...!';
                  document.getElementById('lead_id_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('lead_id_add').classList.remove('error_msg');
                  document.getElementById('appt_reason_add_err').innerHTML = '';
              }
            // Validate appointment category
              var aptment = document.getElementById("aptment").value.trim();
              if (aptment === "") {
                  document.getElementById('aptment_err').innerHTML = 'Appointment Category is required...!';
                  document.getElementById('aptment').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('aptment').classList.remove('error_msg');
                  document.getElementById('aptment_err').innerHTML = '';
              }

              // Validate Appointment date
              var ld_appt_dt_add = document.getElementById("ld_appt_dt_add").value.trim();
              if (ld_appt_dt_add === "") {
                  document.getElementById('ld_appt_dt_add_err').innerHTML = 'Appointment Date is required...!';
                  document.getElementById('ld_appt_dt_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('ld_appt_dt_add').classList.remove('error_msg');
                  document.getElementById('ld_appt_dt_add_err').innerHTML = '';
              }

              // Validate Reason message
              var appt_reason_add = document.getElementById("appt_reason_add").value.trim();
              if (appt_reason_add === "") {
                  document.getElementById('appt_reason_add_err').innerHTML = 'Reason is required...!';
                  document.getElementById('appt_reason_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('appt_reason_add').classList.remove('error_msg');
                  document.getElementById('appt_reason_add_err').innerHTML = '';
              }

              if(aptment == 'Online'){

              }

              // Validate Staff
              var assg_dept_add = document.getElementById("assg_dept_add").value.trim();
              if (assg_dept_add === "") {
                  document.getElementById('assg_dept_add_err').innerHTML = 'Department is required...!';
                  document.getElementById('assg_dept_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('assg_staff_add').classList.remove('error_msg');
                  document.getElementById('assg_dept_add_err').innerHTML = '';
              }

              var assg_staff_add = document.getElementById("assg_staff_add").value.trim();
              if (assg_staff_add === "") {
                  document.getElementById('assg_staff_add_err').innerHTML = 'Staff is required...!';
                  document.getElementById('assg_staff_add').classList.add('error_msg');
                  err++;
              } else {
                  document.getElementById('assg_staff_add').classList.remove('error_msg');
                  document.getElementById('assg_staff_add_err').innerHTML = '';
              }

              if(err==0){
                  $('#addLeadAppointmentForm').submit();
              }else{
                  $('#addSubmit').prop('disabled', false);
              }

        }

 </script>

 <!-- call history -->
   <script>
    function openCallHistoryModal(leadId, status, name = '', mobile = '',incomingCount,outgoingCount,missedCount,dialedCount) {
        $('#call_lead_name').text(name);
        $('#call_lead_mobile').text(mobile);

        let tabHtml = `
            <li class="nav-item me-2 mb-2">
                <a href="#tab_incoming_calls" class="nav-link call_log_link text-capitalize active" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Incoming', '#tab_incoming_calls')">
                    <img src="/assets/phdizone_images/calls/incoming_call.ico" class="w-20px h-25px fw-bold me-2"> Incoming Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${incomingCount >= 10 ? incomingCount : '0'+incomingCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_outgoing_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Outgoing', '#tab_outgoing_calls')">
                    <img src="/assets/phdizone_images/calls/outgoing_call.ico" class="w-20px h-25px fw-bold me-2"> Outgoing Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${outgoingCount >= 10 ? outgoingCount : '0'+outgoingCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_missed_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Missed & Rejected', '#tab_missed_calls')">
                    <img src="/assets/phdizone_images/calls/reject_call.ico" class="w-20px h-25px fw-bold me-2"> Missed & Rejected
                    <span class="badge bg-label-info fs-6 rounded ms-2">${missedCount >= 10 ? missedCount : '0'+missedCount }</span>
                </a>
            </li>
            <li class="nav-item me-2 mb-2">
                <a href="#tab_dailled_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Dialed', '#tab_dailled_calls')">
                    <img src="/assets/phdizone_images/calls/dialed_call.ico" class="w-20px h-25px fw-bold me-2"> Dialed Calls
                    <span class="badge bg-label-info fs-6 rounded ms-2">${dialedCount >= 10 ? dialedCount : '0'+dialedCount }</span>
                </a>
            </li>
        `;

      $(".call_navbar").html(tabHtml);

        // Clear existing table content to avoid leftover data
        $('#tab_incoming_calls tbody').html('');
        $('#tab_outgoing_calls tbody').html('');
        $('#tab_missed_calls tbody').html('');
        $('#tab_dailled_calls tbody').html('');

        // Reset tab to default (Incoming)
        $('.call_log_link').removeClass('active');
        $('.call_log_link[href="#tab_incoming_calls"]').addClass('active');

        // Optionally hide all tabs and show only active
        $('.call_log').removeClass('active show');
        $('#tab_incoming_calls').addClass('active show');

        // Show modal and load default tab
        $('#kt_modal_call_log').modal('show');
        callHistoryTable(leadId, 'Incoming', '#tab_incoming_calls');
    }

    function callHistoryTable(leadId, status, tabSelector) {
        
        const $tbody = $(tabSelector).find("tbody");

        $.ajax({
            url: "{{ route('get_call_history') }}",
            type: "GET",
            data: { lead_id: leadId, status: status },
            beforeSend: function () {
                $tbody.html('<tr><td colspan="6" class="text-center">Loading...</td></tr>');
            },
            success: function (response) {
                let rows = '';

                if (response.calls.length > 0) {
                    response.calls.forEach(call => {
                        let img = "outgoing_call.ico";
                        let statusText = "Outgoing Call";
                        let bgColor = "";
                        let statusColor = "#7594E8";

                        switch (call.call_status) {
                            case 0:
                                img = "outgoing_call.ico";
                                statusText = "Outgoing Call";
                                statusColor = "#7594E8";
                                break;
                            case 1:
                                img = "incoming_call.ico";
                                statusText = "Incoming Call";
                                statusColor = "#FFBF66";
                                break;
                            case 2:
                                img = "missed_call.ico";
                                bgColor = "#ecc093";
                                statusText = "Missed Call";
                                statusColor = "#FFA500";
                                break;
                            case 3:
                                img = "reject_call.ico";
                                bgColor = "#ff00004f";
                                statusText = "Rejected Call";
                                statusColor = "#FF7979";
                                break;
                            default:
                                img = "dialed_call.ico";
                                statusText = "Dialed Call";
                                statusColor = "#7594E8";
                                break;
                        }

                        rows += `
                            <tr style="background: ${bgColor}">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="symbol symbol-35px border bg-primary rounded px-1 py-1 me-2">
                                            <img src="{{ asset('assets/phdizone_images/calls/') }}/${img}" class="w-20px h-20px" />
                                        </div>
                                        <div>
                                            <label class="fs-7 me-1">${call.staff_name}</label>
                                            <div class="text-primary fs-8">${call.staff_phone_no}</div>
                                        </div>
                                    </div>
                                </td>
                                <td>${call.call_start_date ? formatDateTransfer(call.call_start_date) : '-'}</td>
                                <td><label class="text-info fs-7 fw-semibold">${call.call_start_time}</label></td>
                                <td><label class="text-danger fs-7 fw-semibold">${call.call_end_time || '-'}</label></td>
                                <td><label class="badge bg-warning text-black fs-7 fw-bold">${call.call_duration || '-'}</label></td>
                                <td><label class="badge rounded text-white fs-7 fw-semibold" style="background-color: ${statusColor}">${statusText}</label></td>
                            </tr>
                        `;
                    });
                } else {
                    rows = '<tr><td colspan="6" class="text-center">No call history found</td></tr>';
                }

                $tbody.html(rows);
            }
        });
    }

  </script>

  <!-- Lead Add  -->
  <script>
      function AddvalidateForm() {
          var err = 0;

          // Validate knowledge Name
          var lead_name_create = document.getElementById("lead_name_create").value.trim();
          if (lead_name_create === "") {
              document.getElementById('lead_name_create_err').innerHTML = 'Lead Name is required...!';
              err++;
          } else {
              document.getElementById('lead_name_create_err').innerHTML = '';
          }

        var mobile_no_chk = document.getElementById("mobile_no_chk");
        var email_chk = document.getElementById("email_chk");
         var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();
        
        if(mobile_no_chk.checked || email_chk.checked){
             document.getElementById('lead_mobile_create_err').innerHTML = '';
        }else{
             document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile Number or Email Id is Required !';
             err++;
        }
        
       
        if(mobile_no_chk.checked){

            var countryDropdownMenu_valid = $('#country_code_name');
           
            if(countryDropdownMenu_valid == 'IN - +91'){
               
                var mobilePattern = /^\d{10}$/;
    
                if (lead_mobile_create === "") {
                    document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                    err++;
                } else if (!mobilePattern.test(lead_mobile_create)) {
                    document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number must be 10 digits...!';
                    err++;
                } else {
                    document.getElementById('lead_mobile_create_err').innerHTML = '';
                }
            }else{
                if (lead_mobile_create === "") {
                    document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                    err++;
                }else {
                    document.getElementById('lead_mobile_create_err').innerHTML = '';
                }
            }
            
            var lead_mobile_create = document.getElementById("lead_mobile_create").value.trim();
    
            if (lead_mobile_create === "") {
                document.getElementById('lead_mobile_create_err').innerHTML = 'Mobile number is required...!';
                err++;
            } else {
                document.getElementById('lead_mobile_create_err').innerHTML = '';
            }
        
        
       }

       if(email_chk.checked){
          var lead_email_create = document.getElementById("lead_email_create").value.trim();
          if (lead_email_create === "") {
               document.getElementById('lead_email_create_err').innerHTML = 'Email is required...!';
               err++;
          } else {
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
            if (filter.test(lead_email_create)) {
              document.getElementById('lead_email_create_err').innerHTML = '';

            } else {
              document.getElementById('lead_email_create_err').innerHTML = 'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
              err++;

            }
          }
          
       }

          
          // Validate 
        //   var service_category_id = document.getElementById("service_category_id").value.trim();
        //   if (service_category_id === "") {
        //       document.getElementById('service_category_id_err').innerHTML = 'Product Category is required...!';

        //       err++;
        //   } else {

        //       document.getElementById('service_category_id_err').innerHTML = '';
        //   }

          var service_id = document.getElementById("service_id").value.trim();
          if (service_id === "") {
              document.getElementById('service_id_err').innerHTML = 'Product is required...!';

              err++;
          } else {

              document.getElementById('service_id_err').innerHTML = '';
          }
          var potential_type_id = document.getElementById("potential_type_id").value.trim();
          if (potential_type_id === "") {
              document.getElementById('potential_type_id_err').innerHTML = 'Potential Type is required...!';

              err++;
          } else {

              document.getElementById('potential_type_id_err').innerHTML = '';
          }

          var lead_type_id = document.getElementById("lead_type_id").value.trim();
          if (lead_type_id === "") {
              document.getElementById('lead_type_id_err').innerHTML = 'Lead Type is required...!';

              err++;
          } else {

              document.getElementById('lead_type_id_err').innerHTML = '';
          }

          // Validate 
          var lead_source_id = document.getElementById("lead_source_id").value.trim();
          if (lead_source_id === "") {
              document.getElementById('lead_source_id_err').innerHTML = 'Lead Source is required...!';

              err++;
          } else {

              document.getElementById('lead_source_id_err').innerHTML = '';
          }

        if (err === 0) {
            $('#leadAddForm').submit();
            $('#submit_lead_add').prop('disabled', true);
        } else {
                $('#submit_lead_add').prop('disabled', false);
        }
      }
  </script>


<!-- country and code  -->
<script>
    $(document).ready(function() {
       $(".common_time_class_new").flatpickr({
            enableTime: true,
            noCalendar: true,
            dateFormat: "H:i",
            defaultHour: new Date().getHours(),
            defaultMinute: new Date().getMinutes()
        });
        
        $('#country_id_edit').on('change', function () {
            const selectedCountryId = $(this).val();
            if (selectedCountryId) {
                 $.ajax({
                    url: "{{ route('country') }}", 
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var countryDropdownMenu = $('#countryDropdownMenu_edit');
                            countryDropdownMenu.empty();
                            // console.log(response.data);

                            // Add the search input to the dropdown menu
                            countryDropdownMenu.append('<li><input type="text" id="countrySearch_edit" name="countrySearch_edit" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');

                            // Loop through the countries and add them to the dropdown
                            response.data.forEach(function(country) {
                                countryDropdownMenu.append(
                                    $('<li></li>').append(
                                        $('<a></a>')
                                            .addClass('dropdown-item waves-effect')
                                            .attr('href', 'javascript:void(0);')
                                            .data('id', country.id)
                                            .data('phonecode', country.phonecode)
                                            .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                    )
                                );
                            });

    
                            if (selectedCountryId) {
                                // Find the country matching the phone code
                                var selectedCountry = response.data.find(function(country) {
                                    return country.id === Number(selectedCountryId);  // Match based on the phone code
                                });

                                if (selectedCountry) {
                                    // Set the initial country/phone code in the dropdown button
                                    $('#countryDropdownButton_edit').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode);
                                    $('#country_code_name_edit').val(selectedCountry.phonecode); // Ensure the hidden input gets updated as well
                                    $('#lead_mobile_edit').attr('maxlength', 10); // Set maxlength based on country
                                }
                            }

                            // Search functionality
                            $('#countrySearch_edit').on('input', function() {
                                var searchValue = $(this).val().toLowerCase();
                                $('#countryDropdownMenu_edit li a').each(function() {
                                    var countryText = $(this).text().toLowerCase();
                                    if (countryText.indexOf(searchValue) === -1) {
                                        $(this).parent().hide(); // Hide countries that don't match the search term
                                    } else {
                                        $(this).parent().show(); // Show countries that match
                                    }
                                });
                            });
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching countries:', error);
                    }
                });
         
                
            }
        });
        
          $('#countryId').on('change', function () {
            const selectedCountryId = $(this).val();
            if (selectedCountryId) {
                // console.log(selectedCountryId)
                  $.ajax({
                url: "{{ route('country') }}", // Assuming this is your server-side route to fetch countries
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdownMenu = $('#countryDropdownMenu');
                        countryDropdownMenu.empty();
                       

                        // Add the search input to the dropdown menu
                        countryDropdownMenu.append('<li><input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');

                        // Loop through the countries and add them to the dropdown
                        response.data.forEach(function(country) {
                            countryDropdownMenu.append(
                                $('<li></li>').append(
                                    $('<a></a>')
                                        .addClass('dropdown-item waves-effect')
                                        .attr('href', 'javascript:void(0);')
                                        .data('id', country.id)
                                        .data('phonecode', country.phonecode)
                                        .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                )
                            );
                        });

                        
                        var initialPhoneCode = '';
                        if (selectedCountryId) {
                           
                            var selectedCountry = response.data.find(function(country) {
                                return country.id === Number(selectedCountryId);
                            });
                            
                            if (selectedCountry) {
                                
                                $('#countryDropdownButton').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode); // Set the initial country/phone code
                                initialPhoneCode = selectedCountry.phonecode;
                                $('#lead_mobile_create').attr('maxlength', 10);  
                                $('#country_code_name').val(initialPhoneCode);  
                            }
                        }

                        $('#countrySearch').on('input', function() {
                            var searchValue = $(this).val().toLowerCase();
                            $('#countryDropdownMenu li a').each(function() {
                                var countryText = $(this).text().toLowerCase();
                                if (countryText.indexOf(searchValue) === -1) {
                                    $(this).parent().hide(); // Hide countries that don't match the search term
                                } else {
                                    $(this).parent().show(); // Show countries that match
                                }
                            });
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
                
            }
        });
        
        $.ajax({
                url: "{{ route('country') }}", // Assuming this is your server-side route to fetch countries
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdownMenu = $('#countryDropdownMenu');
                        countryDropdownMenu.empty();
                        // console.log(response.data);

                        // Add the search input to the dropdown menu
                        countryDropdownMenu.append('<li><input type="text" id="countrySearch" name="countrySearch" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');

                        // Loop through the countries and add them to the dropdown
                        response.data.forEach(function(country) {
                            countryDropdownMenu.append(
                                $('<li></li>').append(
                                    $('<a></a>')
                                        .addClass('dropdown-item waves-effect')
                                        .attr('href', 'javascript:void(0);')
                                        .data('id', country.id)
                                        .data('phonecode', country.phonecode)
                                        .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                )
                            );
                        });

                        // Pre-select country based on the initial selection (if any)
                        var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                        var initialPhoneCode = '';
                        if (selectedCountryId) {
                            var selectedCountry = response.data.find(function(country) {
                                return country.id === selectedCountryId;
                            });
                            if (selectedCountry) {
                                $('#countryDropdownButton').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode); // Set the initial country/phone code
                                initialPhoneCode = selectedCountry.phonecode;
                                $('#lead_mobile_create').attr('maxlength', 10);  
                                $('#country_code_name').val(initialPhoneCode);  
                            }
                        }

                        $('#countrySearch').on('input', function() {
                            var searchValue = $(this).val().toLowerCase();
                            $('#countryDropdownMenu li a').each(function() {
                                var countryText = $(this).text().toLowerCase();
                                if (countryText.indexOf(searchValue) === -1) {
                                    $(this).parent().hide(); // Hide countries that don't match the search term
                                } else {
                                    $(this).parent().show(); // Show countries that match
                                }
                            });
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });

            // Handle country selection from the dropdown
            $(document).on('click', '.dropdown-item', function() {
                var countryId = $(this).data('id');
                var phoneCode = $(this).data('phonecode');
                var countryName = $(this).text();

                $('#countryDropdownButton').text(countryName);
                $('#country_code_name').val(phoneCode); 

                // Handle max length if needed based on country
                var selectedCountryId = {{ $login_branch_data->country_id ?? 0 }};
                if (countryId === selectedCountryId) {
                    $('#lead_mobile_create').attr('maxlength', 10);  // Set max length for a specific country
                } else {
                    $('#lead_mobile_create').removeAttr('maxlength'); // Remove max length if country changes
                }
            });
            
                    $.ajax({
                        url: "{{ route('product_category_list') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                // Populate the select dropdown with fetched course categories
                                var selectDropdown = $('#service_category_id');
                                selectDropdown.empty();
                                selectDropdown.append($(
                                    '<option value="">Select Product Category</option>'));
                                response.data.forEach(function(level) {
                                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                                        .text(level.product_category_name));
                                });

                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Product categories:', error);
                        }
                    })
            
             
       
           
            $.ajax({
                url: "{{ route('product_list_by_branch') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        // Populate the select dropdown with fetched course categories
                        var selectDropdown = $('#service_id');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Product</option>'));
                        response.data.forEach(function(level) {
                            selectDropdown.append($('<option></option>').attr('value', level.sno)
                                                .text(level.product_name ));
                        });
                         
                        
                    }
                },
                error: function(error) {
                    console.error('Error fetching Product categories:', error);
                }
            });
       
            
    });
    $(document).ready(function() {
        var selectedCountryId = null;
        var selectedStateId = null;
        var selectedCityId = null;
        
        
          // Fetch and populate countries for Add
          $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change

                    $('select[name="country"]').val({{ $login_branch_data->country_id ?? 0 }}).change();
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });

        // Event listener for country change for Add
        $('select[name="country"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state"]');
            var cityDropdown = $('select[name="city"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country for Add
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change

                            $('select[name="state"]').val({{ $login_branch_data->state_id ?? 0}}).change();
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change for Add
        $('select[name="state"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country"]').val();
            var cityDropdown = $('select[name="city"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country for Add
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                            });
                            cityDropdown.val(selectedCityId); // Set the selected city
                            // console.log('{{ $login_branch_data->city_id ?? 0}}')
                            $('select[name="city"]').val('{{ $login_branch_data->city_id ?? 0}}').change();
                        }

                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });

        // Fetch and populate countries for Edit
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('select[name="country_edit"]');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                    });
                    countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });


        // Event listener for country change for Edit
        $('select[name="country_edit"]').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('select[name="state_edit"]');
            var cityDropdown = $('select[name="city_edit"]');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country for Edit
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: { country_id: countryId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                            });
                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });

        // Event listener for state change for Edit
        $('select[name="state_edit"]').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('select[name="country_edit"]').val();
            var cityDropdown = $('select[name="city_edit"]');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country for Edit
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: { country_id: countryId, state_id: stateId },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                            });
                            cityDropdown.val(selectedCityId); // Set the selected city
                        }
                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });
        
    });
</script>

<!-- setting dropdown -->
<script>

$(document).ready(function() {

    $.ajax({
        url: "{{ route('lead_source') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('#lead_source_id');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select Lead source</option>'));
                response.data.forEach(function(level) {
                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                        .text(level.lead_source_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
});

$(document).ready(function() {
    $.ajax({
        url: "{{ route('lead_type') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('#lead_type_id');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select Lead Type</option>'));
                response.data.forEach(function(level) {
                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                        .text(level.lead_type_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
     $.ajax({
        url: "{{ route('university_list') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('#university_id');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select University</option>'));
                response.data.forEach(function(level) {
                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                        .text(level.university_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
     $.ajax({
        url: "{{ route('potential_type_list') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                // Populate the select dropdown with fetched course categories
                var selectDropdown = $('#potential_type_id');
                selectDropdown.empty();
                selectDropdown.append($(
                    '<option value="">Select  Potential Type</option>'));
                response.data.forEach(function(level) {
                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                        .text(level.potential_type_name));
                });
            }
        },
        error: function(error) {
            console.error('Error fetching course categories:', error);
        }
    });
    
    

});
</script>

<!--followup script-->
<script>
    function followupSchedule(leadId,name,phone) {
            $('#lead_id').val(leadId); // Set the lead ID in the hidden input field
            $('#lead_name_app').html(name);
            $('#lead_phone_app').html(phone);
            $('#kt_modal_follow_up_lead').modal('show'); // Show the modal
    }
</script>

<script>
        function FollowupvalidateForm() {
            var err = 0;

            // Validate knowledge Name
            var lead_apt_sch = document.getElementById("lead_apt_sch").value.trim();
            if (lead_apt_sch === "") {
                document.getElementById('apt_date_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('lead_apt_sch').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('lead_apt_sch').classList.remove('error_msg');
                document.getElementById('apt_date_err').innerHTML = '';
            }
                // Validate knowledge Name
            var apt_time_followp = document.getElementById("apt_time_followp").value.trim();
            if (apt_time_followp === "") {
                document.getElementById('apt_time_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('apt_time_followp').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('apt_time_followp').classList.remove('error_msg');
                document.getElementById('apt_time_err').innerHTML = '';
            }
            if (err === 0) {
                $('#followupForm').submit();
                $('#followupBtn').prop('disabled', true);
            } else {
                    $('#followupBtn').prop('disabled', false);
            }
        }

        // Add event listeners to clear error messages on input
        document.getElementById('lead_apt_sch').addEventListener('input', function() {
            document.getElementById('apt_date_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
        // Add event listeners to clear error messages on input
        document.getElementById('apt_time_followp').addEventListener('input', function() {
            document.getElementById('apt_time_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
</script>

<script>
    
      let reshedule_id;

    function openResheduleModal(categoryId,name,mobile) {
        $('#lead_name_reop').html(name);
        $('#lead_phone_reop').html(mobile);
        reshedule_id = categoryId;
            // Function to format date to '10-Jun-2024'
                  function formatDate(dateString) {
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }
                    function formatTime(timeString) {
                        const date = new Date(`1970-01-01T${timeString}Z`);
                        let hours = date.getUTCHours();
                        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                        const ampm = hours >= 12 ? 'PM' : 'AM';
                        hours = hours % 12;
                        hours = hours ? hours : 12; // the hour '0' should be '12'
                        return `${hours}:${minutes} ${ampm}`;
                    }
        fetch(`/edit_appointment/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;



                    document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                    document.getElementById('app_time').innerText = lead.appointment_time;
                     $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                     $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                     $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);
                     
                     
                    // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                //   console.log('Appointment Count:', data.data.appointmentCount);
                    $('#app_count').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('historicalLeadIdsTableBody');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Followup Date">${formatTime(category.appointment_time)}</label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="text-black fw-semibold fs-7">${category.staff_name}</label>
                                </td>
                                <td>
                                    <div class="text-black fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="${category.convo_message ?? '-'}">
                                        ${category.convo_message ?? '-'}
                                    </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ?? '-'}"> ${category.reason ?? '-'}</div>
                                </td>
                            </tr>`;

                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                       
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }


                } else {
                    console.error('Error fetching category:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });

        fetch(`/appointment_history/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                //   console.log(data)
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;

                    $('#apptmnt_count').html(data.data.appointmentCount);
                    const historicalTableBodyAppt = document.getElementById('appointmentLeadIdsTableBody');
                    historicalTableBodyAppt.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
           
                            const row = `<tr>
                                    <td>
                                        <div class="mb-0 align-items-center">
                                            <label>
                                                <span class="fs-7 me-2">${index + 1}</span>
                                            </label>
                                        </div>
                                    </td>
                                     <td>
                                        <label
                                            class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                        <div class="d-block">
                                            <label class="text-dark fs-8"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                        </div>
                                    </td>
                                    <td>
                                        <label
                                            class="text-black fw-semibold fs-7">${category.appointment_category}</label>
                                    </td>
                                    <td>
                                    
                                        <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_reason || '-'}">
                                             ${category.appointment_reason || '-'}</div>
                                    </td>
                                    <td>
                                      <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                             ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                    </td>
                                    <td>
                                      ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                            category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                            category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                            '<span>-</span>'}
                                    </td>
                                    
                                </tr>`;

                            historicalTableBodyAppt.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        
                                    </tr>`;
                        historicalTableBodyAppt.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }

                } else {
                    console.error('Error fetching category:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });


    }

     function updateReshedule() {
        const resheduleid = reshedule_id;
        const progressed = document.querySelector('input[name="progressed"]:checked').value;

        // Initialize variables
        let app_score = null;
        let convo_message = null;
        let hot_lead = null;
        let reason = null;
        let appointment_date = null;
        let appointment_time = null;
        var err=0;
        if(progressed == 1){
            app_score = document.querySelector('input[name="app_score"]:checked').value;
            convo_message = document.getElementById('convo_message').value;
            if(convo_message == ''){
                $('#convo_message_err').text('Conversation Message is Required')
                err++
            }else{
                 $('#convo_message_err').text('');
            }
            // hot_lead = document.getElementById('hot_lead').value;
        } else {
            reason = document.getElementById('app_reason').value;
            var other_reason = document.getElementById('followup_reason_text').value;
            appointment_date = document.getElementById('re_app_date').value;
            appointment_time = document.getElementById('re_app_time').value;
            if(reason == ''){
                $('#app_reason_select_err').text('Reason is Required');
                err++;
            }else{
                 $('#app_reason_select_err').text('');
            }
              if(reason==1){
                if(other_reason == ""){
                    $('#followup_comments_text_err').text('Other Reason is Required');
                    err++;
                }else{
                  reason=other_reason;
                }
              }
                if(appointment_date == ''){
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                }else{
                     $('#re_app_date_err').text('');
                }
                
                if(appointment_time == ''){
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                }else{
                     $('#re_app_time_err').text('');
                }
          
            // appointment_date = document.querySelector('input[name="appointment_date"]').value;
            // appointment_time = document.querySelector('input[name="appointment_time"]').value;
        }


        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        // if(document.getElementById('hot_lead').checked){
        //   hot_lead=1;
        // }else{
        //   hot_lead=0;
        // }

      if(err==0){
          $('#rescheduleBtn').prop('disabled', true);
        fetch(`/appointment_update/${resheduleid}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({
                    progressed: progressed,
                    app_score: app_score,
                    convo_message: convo_message,
                    // hot_lead: hot_lead,
                    reason: reason,
                    appointment_date: appointment_date,
                    appointment_time: appointment_time,
                }),
            })

            .then(data => {
                if (data.status === 200) {
                    toastr.success('Appointment Updated successfully!');
                    $('#rescheduleBtn').prop('disabled', true);
                    location.reload();
                } else {
                    toastr.error('Appointment Failed to update!');
                    $('#rescheduleBtn').prop('disabled', false);
                }
            })
            .catch(error => {
                console.error('Error updating category:', error);
                $('#rescheduleBtn').prop('disabled', false);

        });
      }else{
           $('#rescheduleBtn').prop('disabled', false);
      }
      
    }

    // new appointment
    let resheduleagain_id;

    function openResheduleModalAgain(categoryId,name,mobile) {
         $('#lead_name_app_again').html(name);
        $('#lead_phone_app_again').html(mobile);
        resheduleagain_id = categoryId;
        // Function to format date to '10-Jun-2024'
                    function formatDate(dateString) {
                        const date = new Date(dateString);
                        const day = date.getDate().toString().padStart(2, '0');
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                        const month = monthNames[date.getMonth()];
                        const year = date.getFullYear();
                        return `${day}-${month}-${year}`;
                    }
                    function formatTime(timeString) {
                        const date = new Date(`1970-01-01T${timeString}Z`);
                        let hours = date.getUTCHours();
                        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                        const ampm = hours >= 12 ? 'PM' : 'AM';
                        hours = hours % 12;
                        hours = hours ? hours : 12; // the hour '0' should be '12'
                        return `${hours}:${minutes} ${ampm}`;
                    }
          fetch(`/edit_appointment/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;
                    document.getElementById('lead_id_again').value = lead.lead_id;
                    $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                    $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                      $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                    // document.getElementById('lead_id_again').value = formatDate(lead.lead_id);
                    // document.getElementById('app_time_again').value = lead.appointment_time;
                    // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                    // console.log('Appointment Count:', data.data.appointmentCount);
                    $('#app_count_again').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            if(category.app_score === 1){
                                var score =  `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }else if(category.app_score === -1){
                               var score = `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }
                            else if(category.app_score === 0){
                               var score = `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                            }else{
                                var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                            }
                            const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block text-dark fs-8"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="Last Followup Date">${formatTime(category.appointment_time)}</div>
                                </td>
                                <td>
                                    <label
                                        class="text-black fw-semibold fs-7">${category.staff_name}</label>
                                </td>
                                <td>
                                <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}
                                        </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ? category.reason : '-'}">${category.reason ? category.reason : '-'}
                                        </div>
                                </td>
                            </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }
                    
                     $('[data-bs-toggle="tooltip"]').tooltip();


                } else {
                    console.error('Error fetching category:', data.message);
                }
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                console.error('Error fetching category:', error);
          });

          fetch(`/appointment_history/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                //   console.log(data)
                    const lead = data.data.latestAppointment;
                    const historicalLeadIds = data.data.historicalLeadIds;

                    $('#apptmnt_count_again').html(data.data.appointmentCount);
                    const historicalTableBody = document.getElementById('appointmentLeadIdsTableBodyAgain');
                    historicalTableBody.innerHTML = '';

                    if (historicalLeadIds.length > 0) {
                        for (let index = 0; index < historicalLeadIds.length; index++) {
                            const category = historicalLeadIds[index];
                            const row = `<tr>
                                <td>${index + 1}</td>
                               <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="text-truncate max-w-100px" title="${category.appointment_category}">${category.appointment_category !== null ? category.appointment_category : '-'}</label>
                                </td>
                                 <td>
                                    
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_reason || '-'}">
                                         ${category.appointment_reason || '-'}</div>
                                </td>
                               <td>
                                  <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                         ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                </td>
                                <td>
                                  ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                        category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                        category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                        '<span>-</span>'}
                            </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }
                    } else {
                        const row = `<tr>
                                        
                                    </tr>`;
                        historicalTableBody.innerHTML += row;
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }

                } else {
                    console.error('Error fetching category:', data.message);
                }
                 $('[data-bs-toggle="tooltip"]').tooltip();
            })
            .catch(error => {
                console.error('Error fetching category:', error);
        });
    }
    
     function toggleInputField_followup(value) {
          var followupReasonDiv = document.getElementById('followup_reason_div');
          var followupReasonText = document.getElementById('followup_reason_text');
          // var followupCommentsDiv = document.getElementById('followup_comments_div');
          var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById('app_reason').selectedIndex + 1) + ')');
          // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;
    
          if (value == '1') {
              followupReasonDiv.style.display = 'block';
              followupReasonText.setAttribute('required', 'required');
          } else {
              followupReasonDiv.style.display = 'none';
              followupReasonText.removeAttribute('required');
          }
    
          // if (commentsCheck == '1') {
          //     followupCommentsDiv.style.display = 'block';
          // } else {
          //     followupCommentsDiv.style.display = 'none';
          // }
      }

    
</script>
{{-- bulk conversion --}}
    <script>
      $('#bulk_checkall').change(function () {
          $('.bulk_chk').prop('checked',this.checked);
      });

      $('.bulk_chk').change(function () {
      if ($('.bulk_chk:checked').length == $('.bulk_chk').length){
        $('#bulk_checkall').prop('checked',true);
      }
      else {
        $('#bulk_checkall').prop('checked',false);
      }
      });
    
      function bulk_request_pay() {
        $('#bulk_convert_btn').prop('disabled', true);
        
        var bulk_assign_staff_conver = $('#bulk_assign_staff_conver').val();
        $('#bulk_assign_staff_id').val(bulk_assign_staff_conver);
        // alert(bulk_assign_staff_conver);

        var bulk_assign_staff_hidden = $('#bulk_assign_staff_id').val();

        if ($('.bulk_chk:checked').length > 0) {
            if (bulk_assign_staff_hidden == "") {
                $('#bulk_convert_btn').prop('disabled', false);
                document.getElementById('bulk_assign_staff_conver_err').innerHTML = 'Staff is required...!';
            } else {
                $('#bulk_convert_btn').prop('disabled', true);
                
                var createdByData = [];
                $('.bulk_chk:checked').each(function () {
                    var createdBy = $(this).data('created-by');
                    createdByData.push(createdBy);
                });

                // Create hidden input fields for each `created_by` value
                createdByData.forEach(function (createdBy, index) {
                    var input = $('<input>').attr({
                        type: 'hidden',
                        name: 'created_by[' + index + ']', // You can use the index for unique names
                        value: createdBy
                    });
                    $('#bulk_request_pay_form').append(input);
                });

                // Submit the form
                $('#bulk_request_pay_form').attr('action', "{{ route('bulk_sales_staff_convert') }}");
                $("#bulk_request_pay_form").submit();
            }
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'Please Check Any one of the checkbox...',
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            $('#kt_modal_bulk_convert_sales_person').modal('hide');
        }
        
        $('#bulk_convert_btn').prop('disabled', false);
    }    
    </script>
    <script>
     // bulk assign staff
     $.ajax({
                  url: "{{ route('sales_staff') }}",
                  type: "GET",
                  success: function(response) {
                      if (response.status === 200 && response.data) {
                        let select = document.getElementById('bulk_assign_staff_conver');
                        select.innerHTML = ''; // Clear existing options
                        // Add the empty option
                        let defaultOption = document.createElement('option');
                        defaultOption.value = '';
                        defaultOption.textContent = 'Select Convert Staff';
                        select.appendChild(defaultOption);
                      response.data.forEach(staff => {

                        let option = document.createElement('option');
                        option.value = staff.sno;
                        var staffName = (staff.staff_name + "-" + staff.position_name);
                        option.textContent = staffName;
                        select.appendChild(option);
                    });
                      } else {
                          let select = document.getElementById('bulk_assign_staff_conver');
                          select.innerHTML = ''; // Clear existing options
                          // Add the empty option
                          let defaultOption = document.createElement('option');
                          defaultOption.value = '';
                          defaultOption.textContent = 'Select Convert Staff';
                          select.appendChild(defaultOption);
                      }
                  }

            });
    </script>

<script>
    function onlyOne(checkbox) {
        var checkboxes = document.getElementsByName('app_score')
        checkboxes.forEach((item) => {
            if (item !== checkbox) item.checked = false
        })
    }
</script>






    <script>
        function apmt_func() {
            var aptment = document.getElementById('aptment').value;
            var onl_link_tbox = document.getElementById('onl_link_tbox');
            var onl_link_pw_tbox = document.getElementById('onl_link_pw_tbox');

            if (aptment == 'Online') {
                onl_link_tbox.style.display = "block";
                onl_link_pw_tbox.style.display = "block";
            } else {
                onl_link_tbox.style.display = "none";
                onl_link_pw_tbox.style.display = "none";
            }
        }
    </script>
    
    <script>
        const leadBoomElements = document.querySelectorAll('.leadBoom'); // Get all elements with the class 'leadBoom'

        setInterval(() => {
            leadBoomElements.forEach(leadBoom => { // Loop through each element
                leadBoom.classList.add('boom-animate');

                setTimeout(() => {
                    leadBoom.classList.remove('boom-animate');
                }, 500); // Remove animation after 500ms
            });
        }, 2000); 
    </script>
    <script>
        document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function(event) {
                const tdy_flwup = document.getElementById("tdy_flwup");

                if (tdy_flwup.classList.contains('active')) {
                    document.getElementById("tdy_flwup_txt").setAttribute("style",
                        "Color:rgb(0, 0, 0) !important;");
                    tdy_flwup.setAttribute("style", "background-color: #faff00 !important;");
                } else {
                    document.getElementById("tdy_flwup_txt").setAttribute("style",
                        "Color:#4b4b4b !important;");
                    tdy_flwup.setAttribute("style", "background-color: #FCFF66 !important;");
                }
            });
        });
    </script>
    <script>
    $(document).ready(function() {
        @if ($filter_on ?? '')
            $('.filter_tbox').slideToggle('fast');
        @endif
    });
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>
    
    <script>
    function EditvalidateForm() {
        var err = 0;

        // Validate knowledge Name
        var lead_name_edit = document.getElementById("lead_name_edit").value.trim();
        if (lead_name_edit === "") {
            document.getElementById('lead_name_edit_err').innerHTML = 'Lead Name is required...!';
            err++;
        } else {
            document.getElementById('lead_name_edit_err').innerHTML = '';
        }

        // Validate Gender
        // var lead_dob_up = document.getElementById("lead_dob_up").value.trim();
        // if (!lead_dob_up) {
        //     document.getElementById('lead_dob_up_err').innerHTML = 'Date of Birth is required...!';
        //     err++;
        // } else {
        //     document.getElementById('lead_dob_up_err').innerHTML = '';
        // }
    
        
       var mobile_no_chk_edit = document.getElementById("mobile_no_chk_edit");
        var email_chk_edit = document.getElementById("email_chk_edit");
        var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();
        
        if(mobile_no_chk_edit.checked || email_chk_edit.checked){
             document.getElementById('lead_mobile_edit_err').innerHTML = '';
        }else{
             document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile Number or Email Id is Required !';
             err++;
        }
       
       if(mobile_no_chk_edit.checked){

        var countryDropdownMenu = $('#country_code_name_edit');
       
        if(countryDropdownMenu == 'IN - +91'){
            var lead_mobile_edit = document.getElementById("lead_mobile_edit").value.trim();
            var mobilePattern = /^\d{10}$/;

            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';

                err++;
            } else if (!mobilePattern.test(lead_mobile_edit)) {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number must be 10 digits...!';

                err++;
            } else {

                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }else{
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';
                err++;
            }else {
                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        }
          
    
            if (lead_mobile_edit === "") {
                document.getElementById('lead_mobile_edit_err').innerHTML = 'Mobile number is required...!';
                err++;
            } else {
                document.getElementById('lead_mobile_edit_err').innerHTML = '';
            }
        
       }
        
      
        if(email_chk_edit.checked){

        var lead_email_edit = document.getElementById("lead_email_edit").value.trim();
          if (lead_email_edit === "") {
               document.getElementById('lead_email_edit_err').innerHTML = 'Email is required...!';
               err++;
          } else {
            var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z]{2,4})+$/;
            if (filter.test(lead_email_edit)) {
              document.getElementById('lead_email_edit_err').innerHTML = '';
            } else {
              document.getElementById('lead_email_edit_err').innerHTML = 'Enter a valid email address <br> (e.g., lead@gmail.com)..!';
              err++;

            }
          }
        }else{
            document.getElementById('lead_email_edit_err').innerHTML = '';
        }

        // var country_id_edit = document.getElementById("country_id_edit").value.trim();
        // if (country_id_edit === "") {
        //     document.getElementById('country_id_edit_err').innerHTML = 'Country is required...!';
        //     err++;
        // } else {
        //     document.getElementById('country_id_edit_err').innerHTML = '';
        // }

        // var state_edit = document.getElementById("state_edit").value.trim();
        // if (state_edit === "") {
        //     document.getElementById('state_edit_err').innerHTML = 'State is required...!';

        //     err++;
        // } else {

        //     document.getElementById('state_edit_err').innerHTML = '';
        // }
        // var city_edit = document.getElementById("city_edit").value.trim();
        // if (city_edit === "") {
        //     document.getElementById('city_edit_err').innerHTML = 'City is required...!';

        //     err++;
        // } else {

        //     document.getElementById('city_edit_err').innerHTML = '';
        // }



        // Validate knowledge Name

        // var service_category_id_edit = document.getElementById("service_category_id_edit").value.trim();
        // if (service_category_id_edit === "") {
        //     document.getElementById('service_category_id_edit_err').innerHTML = 'Product Category is required...!';

        //     err++;
        // } else {

        //     document.getElementById('service_category_id_edit_err').innerHTML = '';
        // }
        var service_id_edit = document.getElementById("service_id_edit").value.trim();
        if (service_id_edit === "") {
            document.getElementById('service_id_edit_err').innerHTML = 'Product is required...!';

            err++;
        } else {

            document.getElementById('service_id_edit_err').innerHTML = '';
        }

        var potential_type_id_edit = document.getElementById("potential_type_id_edit").value.trim();
        if (potential_type_id_edit === "") {
            document.getElementById('potential_type_id_edit_err').innerHTML = 'Potential Type is required...!';

            err++;
        } else {

            document.getElementById('potential_type_id_edit_err').innerHTML = '';
        }
   
   
        var lead_type_id_edit = document.getElementById("lead_type_edit").value.trim();
          if (lead_type_id_edit === "") {
              document.getElementById('lead_type_id_edit_err').innerHTML = 'Lead Type is required...!';

              err++;
          } else {

              document.getElementById('lead_type_id_edit_err').innerHTML = '';
          }

          // Validate 
          var lead_source_id_edit = document.getElementById("lead_source_edit").value.trim();
          if (lead_source_id_edit === "") {
              document.getElementById('lead_source_id_edit_err').innerHTML = 'Lead Source is required...!';

              err++;
          } else {

              document.getElementById('lead_source_id_edit_err').innerHTML = '';
          }


        if (err === 0) {
            $('#leadEditForm').submit();
            $('#submit_lead_edit').prop('disabled', true);
        } else {
            $('#submit_lead_edit').prop('disabled', false);
        }
    }
</script>

<script>
     function populateEditModal(id) {
        var categoryId = id;
        fetch(`/lead_edit/${categoryId}`)
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    const lead = data.data;
    
                    if(lead.lead_mobile){
                        $('#mobile_no_chk_edit').prop('checked',true);
                    }
                     if(lead.lead_email_id){
                        $('#email_chk_edit').prop('checked',true);
                    }
                    // Populate input fields
                    $('#lead_id_edit').val(lead.sno);
                    $('#lead_name_edit').val(lead.lead_name);
                    $('#lead_mobile_edit').val(lead.lead_mobile);
                    $('#lead_alternate_edit').val(lead.lead_alternate_mobile);
                    $('#lead_email_edit').val(lead.lead_email_id);
                    $('#lead_dob_up').val(lead.lead_dob);
                    $('#lead_reg_date_up').val(lead.registered_date);
                    $('#lead_address_edit').val(lead.address);
                    $('#lead_door_no_edit').val(lead.door_no || '');
                    $('#lead_pincode_edit').val(lead.pincode || '');
                    $('#lead_comments_edit').val(lead.lead_comments);
                    mobile_no_func_edit()
                    email_func_edit()
                   
                    $('#lead_marital_edit').val(lead.lead_marital_status).trigger('change');
                   
                    $('#service_id_edit').val(lead.service_id).trigger('change');
                    // $('#service_category_id_edit').val(lead.service_category_id).trigger('change');
                   
    
                    // Initialize country code dropdown and selection
                    const selectedCountryId = lead.country || {{ $login_branch_data->country_id ?? 0 }};
                    const selectedStateId = lead.state || {{ $login_branch_data->state_id ?? 0 }};
                    const selectedCityId = lead.city || '{{ $login_branch_data->city_id ?? 0 }}';
    
                    // Fetch and populate countries for Edit
                    $.ajax({
                        url: "{{ route('country') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                const countryDropdown = $('#country_id_edit');
                                countryDropdown.empty().append('<option value="">Select Country</option>');
                                response.data.forEach(function(country) {
                                    countryDropdown.append($('<option></option>').attr('value', country.id).text(country.name));
                                });
                                countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
    
                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state') }}",
                                    type: "GET",
                                    data: { country_id: selectedCountryId },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            const stateDropdown = $('#state_edit');
                                            stateDropdown.empty().append('<option value="">Select State</option>');
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($('<option></option>').attr('value', state.id).text(state.name));
                                            });
                                            stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
    
                                            // Fetch and populate cities based on selected state
                                            $.ajax({
                                                url: "{{ route('city') }}",
                                                type: "GET",
                                                data: { country_id: selectedCountryId, state_id: selectedStateId },
                                                success: function(response) {
                                                    if (response.status === 200 && response.data) {
                                                        const cityDropdown = $('#city_edit');
                                                        cityDropdown.empty().append('<option value="">Select City</option>');
                                                        response.data.forEach(function(city) {
                                                            cityDropdown.append($('<option></option>').attr('value', city.id).text(city.name));
                                                        });
                                                        cityDropdown.val(selectedCityId); // Set the selected city
                                                    }
                                                },
                                                error: function(error) {
                                                    console.error('Error fetching cities:', error);
                                                }
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });
    
                    var country_code = $('#country_code_name_edit').val(); 
    
                    $.ajax({
                        url: "{{ route('country') }}", 
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var countryDropdownMenu = $('#countryDropdownMenu_edit');
                                countryDropdownMenu.empty();
                                // console.log(response.data);
    
                                // Add the search input to the dropdown menu
                                countryDropdownMenu.append('<li><input type="text" id="countrySearch_edit" name="countrySearch_edit" class="form-control border-1" placeholder="Search Country/Code" style="width: 100%; border: none; padding: 5px;"></li>');
    
                                // Loop through the countries and add them to the dropdown
                                response.data.forEach(function(country) {
                                    countryDropdownMenu.append(
                                        $('<li></li>').append(
                                            $('<a></a>')
                                                .addClass('dropdown-item waves-effect')
                                                .attr('href', 'javascript:void(0);')
                                                .data('id', country.id)
                                                .data('phonecode', country.phonecode)
                                                .text(country.sortname + ' - ' + '+' + country.phonecode) // Display country name and phone code
                                        )
                                    );
                                });
    
                                // Pre-select country based on the initial selection (if any)
                                var selectedCountryId = country_code; 
                                if(country_code == 0){
                                  country_code = 91;
                                }
                                $('#countryDropdownButton_edit').text('+' + country_code);
                                $('#country_code_name_edit').val(country_code);
                                
                                if (selectedCountryId) {
                                    // Find the country matching the phone code
                                    var selectedCountry = response.data.find(function(country) {
                                        return country.phonecode === selectedCountryId;  // Match based on the phone code
                                    });
    
                                    if (selectedCountry) {
                                        // Set the initial country/phone code in the dropdown button
                                        $('#countryDropdownButton_edit').text(selectedCountry.sortname + ' - +' + selectedCountry.phonecode);
                                        $('#country_code_name_edit').val(selectedCountry.phonecode); // Ensure the hidden input gets updated as well
                                        $('#lead_mobile_edit').attr('maxlength', 10); // Set maxlength based on country
                                    }
                                }
    
                                // Search functionality
                                $('#countrySearch_edit').on('input', function() {
                                    var searchValue = $(this).val().toLowerCase();
                                    $('#countryDropdownMenu_edit li a').each(function() {
                                        var countryText = $(this).text().toLowerCase();
                                        if (countryText.indexOf(searchValue) === -1) {
                                            $(this).parent().hide(); // Hide countries that don't match the search term
                                        } else {
                                            $(this).parent().show(); // Show countries that match
                                        }
                                    });
                                });
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching countries:', error);
                        }
                    });
                    $('#countryDropdownButton_edit').text('+' +country_code);
    
                    $('#countryDropdownMenu_edit').on('click', '.dropdown-item', function() {
                        var countryId = $(this).data('id');
                        var phoneCode = $(this).data('phonecode');
                        var countryName = $(this).text();
    
                        // Update dropdown button text with selected country
                        $('#countryDropdownButton_edit').text(countryName);
                        // Update the country code hidden input
                        $('#country_code_name_edit').val(phoneCode); 
    
                        // Handle max length if needed based on country
                        var selectedCountryId = country_code;
                        if (countryId === selectedCountryId) {
                            $('#lead_mobile_edit').attr('maxlength', 10);  // Set max length for a specific country
                        } else {
                            $('#lead_mobile_edit').removeAttr('maxlength'); // Remove max length if country changes
                        }
                    });
    
    
                    // Gender radio button selection
                    $('input[name="lead_gender_edit"]').prop('checked', false); // Uncheck all
                    if (lead.lead_gender === 1) {
                        $('#inlineRadio1edit').prop('checked', true);
                    } else if (lead.lead_gender === 2) {
                        $('#inlineRadio2edit').prop('checked', true);
                    } else {
                        $('#inlineRadio3edit').prop('checked', true);
                    }
                    
                    $.ajax({
                        url: "{{ route('lead_source') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                // Populate the select dropdown with fetched course categories
                                var selectDropdown = $('#lead_source_edit');
                                selectDropdown.empty();
                                selectDropdown.append($(
                                    '<option value="">Select Lead source</option>'));
                                response.data.forEach(function(level) {
                                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                                        .text(level.lead_source_name));
                                });
                                 $('#lead_source_edit').val(lead.lead_source_id).trigger('change');
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching course categories:', error);
                        }
                    });
                    
                    // $.ajax({
                    //     url: "{{ route('product_category_list') }}",
                    //     type: "GET",
                    //     success: function(response) {
                    //         if (response.status === 200 && response.data) {
                    //             // Populate the select dropdown with fetched course categories
                    //             var selectDropdown = $('#service_category_id_edit');
                    //             selectDropdown.empty();
                    //             selectDropdown.append($(
                    //                 '<option value="">Select Product Category</option>'));
                    //             response.data.forEach(function(level) {
                    //                 selectDropdown.append($('<option></option>').attr('value', level.sno)
                    //                     .text(level.product_category_name));
                    //             });
                    //              $('#service_category_id_edit').val(lead.service_category_id).trigger('change');
                                
                    //         }
                    //     },
                    //     error: function(error) {
                    //         console.error('Error fetching Product categories:', error);
                    //     }
                    // });
                    
           
            
                    // $('#service_category_id_edit').on('change', function() {
                    //         var category_id_edit=$(this).val()
                             
                            
                    //     });
                        
                        var selectDropdownPr = $('#service_id_edit');
                                        selectDropdownPr.empty();
                        $.ajax({
                                url: "{{ route('product_list_by_branch') }}",
                                type: "GET",
                                success: function(response) {
                                    if (response.status === 200 && response.data) {
                                        // Populate the select dropdown with fetched course categories
                                       
                                        selectDropdownPr.append($(
                                            '<option value="">Select Product</option>'));
                                        response.data.forEach(function(level) {
                                            selectDropdownPr.append($('<option></option>').attr('value', level.sno)
                                                .text(level.product_name));
                                        });
                                        $('#service_id_edit').val(lead.service_id).trigger('change');
                                    }
                                },
                                error: function(error) {
                                    console.error('Error fetching Product categories:', error);
                                }
                            });
                    
                    
                       $.ajax({
                            url: "{{ route('lead_type') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    // Populate the select dropdown with fetched course categories
                                    var selectDropdown = $('#lead_type_edit');
                                    selectDropdown.empty();
                                    selectDropdown.append($(
                                        '<option value="">Select Lead Type</option>'));
                                    response.data.forEach(function(level) {
                                        selectDropdown.append($('<option></option>').attr('value', level.sno)
                                            .text(level.lead_type_name));
                                    });
                                     $('#lead_type_edit').val(lead.lead_type_id).trigger('change');
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching course categories:', error);
                            }
                        });
                        
                     $.ajax({
                        url: "{{ route('university_list') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                // Populate the select dropdown with fetched course categories
                                var selectDropdown = $('#university_id_edit');
                                selectDropdown.empty();
                                selectDropdown.append($(
                                    '<option value="">Select University</option>'));
                                response.data.forEach(function(level) {
                                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                                        .text(level.university_name));
                                });
                                 $('#university_id_edit').val(lead.university_id).trigger('change');
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching course categories:', error);
                        }
                    });
                    
                     $.ajax({
                        url: "{{ route('potential_type_list') }}",
                        type: "GET",
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                // Populate the select dropdown with fetched course categories
                                var selectDropdown = $('#potential_type_id_edit');
                                selectDropdown.empty();
                                selectDropdown.append($(
                                    '<option value="">Select  Potential Type</option>'));
                                response.data.forEach(function(level) {
                                    selectDropdown.append($('<option></option>').attr('value', level.sno)
                                        .text(level.potential_type_name));
                                });
                                $('#potential_type_id_edit').val(lead.lead_potential_type_id).trigger('change');
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching course categories:', error);
                        }
                    });
                    
    
                  
                    // Populate marital status dropdown
                    $('#lead_marital_edit, #lead_course_edit, #lead_type_edit, #lead_source_edit, .trigerchange').trigger('change');
                } else {
                    console.error('Error fetching lead data:', data.message);
                }
            })
            .catch(error => {
                console.error('Error fetching lead data:', error);
            });
}

</script>
    
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>
    <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
     <script>
	$(".list_page_scroll3").DataTable({
		// "ordering": false,
		"aaSorting": [],
		// "pagingType": 'simple_numbers',
		"pagingType": "full_numbers",
		"sorting": false,
		"paging": false,
		// "info": false,
		// "buttons": [
		//             'copy', 'csv', 'excel', 'pdf', 'print'
		//         ],
		"language": {
			"lengthMenu": "Show _MENU_",
		},
		// "pageLength": 5,
		"dom": "<'row'" +
			// "<'col-sm-6 d-flex align-items-center justify-conten-start my-3'l>" +
			//   "<'col-sm-12 d-flex align-items-center justify-content-end my-3'f>" +
			">" +

			"<'table-responsive'tr>" +

			"<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
			// "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
			">"
	});
	$('.list_page_scroll3').wrap('<div class="dataTables_scroll3" />');
</script>


<script>

$(document).ready(function() {
   // Track dynamic fields

    // Initially hide the delete button for the first requirement

    // Add more requirement fields dynamically
    $('.staff_reqts_add').on('click', function() {
        // Increment the counter

        // Create the new requirement row dynamically
        var newRequirementHtml = `
            <div class="row mt-4 form-repeater_reqts" id="requirement_row_${requirementCounter}">
                <div class="col-lg-7 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_${requirementCounter}">
                        Requirements Point ${requirementCounter} <span class="text-danger">*</span>
                    </label>
                    <input type="text" class="form-control" placeholder="Enter Requirement Point ${requirementCounter}" id="requirement_name_${requirementCounter}" name="requirement_name[]" />
                    <div class="text-danger err_mssg" id="requirement_name_${requirementCounter}_err"></div>
                </div>
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                    <div class="d-flex align-items-sm-center">
                        <img src="{{asset('assets/phdizone_images/Document.jpg')}}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_${requirementCounter}" />
                        <div class="ms-1 button-wrapper">
                            <div class="d-flex align-items-start mt-2 mb-2">
                                <button type="button" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="document.getElementById('document_upload_${requirementCounter}').click();">
                                    <i class="mdi mdi-tray-arrow-up"></i>
                                    <input type="file"id="document_upload_${requirementCounter}" name="document_upload[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)"  />
                                </button>
                                <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document" id="uploaded_reset_${requirementCounter}">
                                    <i class="mdi mdi-reload"></i>
                                </button>
                            </div>
                            <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                            <div class="small text-success fs-8" id="upload_file_name_${requirementCounter}"></div>

                        </div>
                    </div>
                </div>
                <div class="col-lg-1">
                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_${requirementCounter}">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
            </div>
        `;

        // Append the new requirement row
        $('#repeater_req').first().parent().append(newRequirementHtml);
        requirementCounter++;

        // Show the delete button for the new row
        $('#staff_reqts_del_' + requirementCounter).show();

        // Hide delete button for the first requirement
       
    });

    // Delete a requirement row
    $(document).on('click', '.staff_reqts_del', function(e) {
        var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
        var index = deleteId.split('_')[3];  // Extract the counter from the id (e.g., 'staff_reqts_del_2' -> 2)

        // Remove the row
        $('#requirement_row_' + index).slideUp(400, function() {
            $(this).remove(); // Remove the row
            requirementCounter--; // Decrement counter

            // Hide the delete button for the first row if there is only one remaining row
            if (requirementCounter === 1) {
                $('#staff_reqts_del_1').hide();
            }
        });
    });

    $('#submit_requirements').on('click', function () {
    var valid = true;

    $('input[name^="requirement_name"]:visible:enabled').each(function () {
        let requirement_name = $(this).val();
        let errDiv = $(this).siblings('.err_mssg');

        if (!requirement_name || requirement_name.trim() === '') {
            valid = false;
            errDiv.text('Requirement Point is required');
        } else {
            errDiv.text('');
        }
    });

    if (valid) {
        $('#requirementForm').submit();
        $('#submit_requirements').prop('disabled', true);
    } else {
        $('#submit_requirements').prop('disabled', false);
    }
});
});



var requirementCounter = 1; 
function openRequirement(id) {
   requirementCounter = 1; 
    $('#requirement_lead_id').val(id);
    // Reset the form before filling it
    $('.form-repeater_reqts').not(':first').remove();

    $.ajax({
        url: '/requirements_details/' + id, // Adjust with your route
        type: 'GET',
        success: function(response) {
            $('#requirement_lead_name').text(response.lead.lead_name);
            $('#requirement_lead_mobile').text(response.lead.lead_mobile);
            $('#requirement_service_category').text(response.lead.product_category_name || '-');
            $('#requirement_service').text(response.lead.product_name || '-');
            
            if (response.data.length > 0) {
                $('#default_repeater').hide();
                $('#default_requirement input').hide().prop('disabled', true);
                $('#default_doc input').hide().prop('disabled', true);
                $('#defalt_filediv #upload_file_name_1').hide();
                $('#default_repeater #uploaded_reset_1').hide();
                $('#default_repeater #uploadedlogo_1').hide();
                $('#requirement_status').val('update');

                response.data.forEach(function(requirement, index) {
                    let currentIndex = index + 1;
                    $('#default_repeater').hide();

                    let img_src = '{{ asset('assets/phdizone_images/Document.jpg') }}';
                    if (requirement.document_url) {
                        const fileExt = requirement.document_url.split('.').pop().toLowerCase();
                        const imageExts = ['jpg', 'jpeg', 'png'];

                        if (imageExts.includes(fileExt)) {
                            img_src = `{{ asset('requirement_documents') }}/${requirement.document_url}`;
                        }
                    }
           

                    var newRequirementHtml = `
                        <div class="row mt-4 form-repeater_reqts" id="requirement_row_${requirementCounter}">
                            <div class="col-lg-7 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold" id="requirement_label_${requirementCounter}">
                                    Requirements Point ${requirementCounter} <span class="text-danger">*</span>
                                </label>
                                <input type="hidden" name="require_doc_id[]" value="${requirement.sno}" />
                                <input type="hidden" name="old_document${requirement.sno}[]" value="${requirement.document_url}" />
                                <input type="text" class="form-control" placeholder="Enter Requirement Point ${requirementCounter}" id="requirement_name_${requirementCounter}" name="requirement_name_${requirement.sno}[]" value="${requirement.requirement_name}" />
                                <div class="text-danger err_mssg" id="requirement_name_${requirementCounter}_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Attachments</label>
                                <div class="d-flex align-items-sm-center">
                                    <img src="${img_src}" alt="user-avatar" class="d-block w-px-100 h-px-100 rounded border border-gray-600 border-solid" id="uploadedlogo_${requirementCounter}" />
                                    <div class="ms-1 button-wrapper">
                                        <div class="d-flex align-items-start mt-2 mb-2">
                                             <button type="button" class="btn btn-sm btn-primary me-2" tabindex="0" data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Document" onclick="triggerFileUpload(${requirementCounter});">
                                                <i class="mdi mdi-tray-arrow-up"></i>
                                                <input type="file" id="document_upload_${requirementCounter}" name="document_upload_${requirement.sno}[]" class="file-in" hidden accept="image/png, image/jpeg, application/pdf, text/csv"   onchange="fileChange(event)" />
                                            </button>
                                            <button type="button" class="btn btn-sm btn-outline-danger file-reset" data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Document" id="uploaded_reset_${requirementCounter}">
                                                <i class="mdi mdi-reload"></i>
                                            </button>
                                        </div>
                                        <div class="small fs-8">Allowed JPG, PNG, PDF, CSV. Max size 5MB</div>
                                        <div class="small text-success fs-8" id="upload_file_name_${requirementCounter}">${requirement.document_url || ''}</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-1">
                                <a href="javascript:;" class="btn btn-outline-danger mt-6 px-1 py-2 staff_reqts_del" id="staff_reqts_del_${requirementCounter}">
                                    <i class="mdi mdi-delete fs-4"></i>
                                </a>
                            </div>
                        </div>
                    `;

                    $('#staff_reqts_del_1').attr('style', 'display: none !important');

                    if (index > 0) {
                        $('#staff_reqts_del_1').attr('style', 'display: none !important');
                    }

                    $('#repeater_req').first().parent().append(newRequirementHtml);
                    $('#staff_reqts_del_' + requirementCounter).show();

                    
                   

                    if (requirementCounter === 1) {
                        $('#staff_reqts_del_1').attr('style', 'display: none !important');
                    }

                    requirementCounter++;
                });
            } else {
                $('#requirement_status').val('add');
                requirementCounter = 2;
            }
        },
        error: function(xhr, status, error) {
            console.log('Error fetching requirements.');
        }
    });
}

function triggerFileUpload(counter) {
    // This dynamically targets the file input using the counter
    const visibleFileInput = document.querySelector(`#document_upload_${counter}:not([style*="display: none"])`);
    if (visibleFileInput) {
        visibleFileInput.click();
    }
}

function fileChange(e) {
    const inputId = e.target.id;
    const requirementId = inputId.split('_')[2];
    const file = e.target.files[0];

    if (file) {
        const fileName = file.name;
        const fileType = file.type;
        const allowedImageTypes = ['image/jpeg', 'image/png'];

        const docImg = document.querySelector(`#uploadedlogo_${requirementId}:not([style*="display: none"])`);
        const resetBtn =document.querySelector(`#uploaded_reset_${requirementId}:not([style*="display: none"])`);
        const fileNameDisplay = document.querySelector(`#upload_file_name_${requirementId}:not([style*="display: none"])`);
        const defaultImageSrc = "{{asset('assets/phdizone_images/Document.jpg')}}";
        const defaultFileText = fileNameDisplay.innerText;

        // Update file name text
        if (fileNameDisplay) {
            fileNameDisplay.innerText = fileName;
        }

        // Show image preview only for image files
        if (docImg) {
            if (allowedImageTypes.includes(fileType)) {
                docImg.src = URL.createObjectURL(file);
            } else {
                docImg.src = defaultImageSrc;
            }
        }

        // Reset logic
        if (resetBtn) {
            resetBtn.onclick = () => {
                e.target.value = ''; // Clear input
                if (docImg) docImg.src = defaultImageSrc;
                if (fileNameDisplay) fileNameDisplay.innerText = defaultFileText;
            };
        }
    }
}



</script>
<script>
    // Function to export table data to Excel
      function exportToExcel(filters) {
        $.ajax({
            url: '/lead/export-excel'
            , type: 'GET'
            , data: filters, // Pass filters as query parameters
            success: function(response) {
                window.location.href = '/lead/export-excel?' + $.param(filters); // Trigger file download
            }
            , error: function(xhr, status, error) {
                console.error('Error exporting to Excel:', error);
            }
        });
    }
    $('#export_excel').on('click', function(e) {
        e.preventDefault();
        let filters = {
            course_fill: $('#course_fill').val()
            , potential_type_fill: $('#potential_type_fill').val()
            , lead_source_fill: $('#lead_source_fill').val()
            , lead_status_fill: $('#lead_status_fill').val()
            , staff_fill: $('#staff_fill').val()
            , date_filter: $('#dt_fill_issue_rpt').val()
            , from_date_fillter_textbox: $('#from_date_fillter_textbox').val()
            , to_date_fillter_textbox: $('#to_date_fillter_textbox').val()
        };
        exportToExcel(filters);
            setTimeout(function() {
                // console.log('This message will appear after 2 seconds');
            location.reload();
            }, 2000); // 2000 milliseconds = 2 seconds
    });
</script>

<script>
      function potentialUpdate(id, type) {
          const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

          fetch(`/lead_potential_update/${id}`, {
              method: 'POST',
              headers: {
                  'Content-Type': 'application/json',
                  'X-CSRF-TOKEN': csrfToken
              },
              body: JSON.stringify({
                  potential_type_id: type
              }),
          })
          .then(response => response.json())  // Ensure you parse the JSON response
          .then(data => {
              if (data.status === 200) {
                  toastr.success('Potential Updated successfully!');
                  location.reload();
              } else {
                  toastr.error('Potential Failed to update!');
              }
          })
          .catch(error => {
              console.error('Error updating category:', error);
              toastr.error('An error occurred: ' + error.message);
          });
    }
</script>

<script>
     mobile_no_func()
    function mobile_no_func() {
        var mobile_no_chk = document.getElementById("mobile_no_chk");
        var mob_no = document.getElementById("mob_no");
        var mob_req = document.getElementById("mob_req");
        if (mobile_no_chk.checked) {
            mob_no.style.display = "block";
            mob_req.style.display = "inline";
        } else {
            mob_no.style.display = "none";
            mob_req.style.display = "none";
        }
    }
    email_func()
    function email_func() {
        var email_chk = document.getElementById("email_chk");
        var email_tbox = document.getElementById("email_tbox");
        var email_req = document.getElementById("email_req");
        if (email_chk.checked) {
            email_tbox.style.display = "block";
            email_req.style.display = "inline";
        } else {
            email_tbox.style.display = "none";
            email_req.style.display = "none";
        }
    }
</script>

<script>

    function mobile_no_func_edit() {
        var mobile_no_chk_edit = document.getElementById("mobile_no_chk_edit");
        var mob_no_edit = document.getElementById("mob_no_edit");
        var mob_req_edit = document.getElementById("mob_req_edit");
        if (mobile_no_chk_edit.checked) {
            mob_no_edit.style.display = "block";
            mob_req_edit.style.display = "inline";
        } else {
            mob_no_edit.style.display = "none";
            mob_req_edit.style.display = "none";
        }
    }

    function email_func_edit() {
        var email_chk_edit = document.getElementById("email_chk_edit");
        var email_tbox_edit = document.getElementById("email_tbox_edit");
        var email_req_edit = document.getElementById("email_req_edit");
        if (email_chk_edit.checked) {
            email_tbox_edit.style.display = "block";
            email_req_edit.style.display = "inline";
        } else {
            email_tbox_edit.style.display = "none";
            email_req_edit.style.display = "none";
        }
    }
</script>

{{-- mobile unique check --}}
<script>
  function mobile_chk(val) {
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('leadCheckMobileExists') }}",
                type: 'GET',
                data: {
                    mobile: val,
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#lead_mobile_create_err').text('Lead Mobile Number is already assigned!');
                        $('#submit_lead_add').prop('disabled', true); // Disable submit button
                    } else {
                            $('#lead_mobile_create_err').text('');
                        $('#submit_lead_add').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
    
  function mobile_chk_edit(val) {
        var id = $('#lead_id_edit').val()
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('leadCheckMobileExistsEdit') }}",
                type: 'GET',
                data: {
                    mobile: val,
                    id: id
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#lead_mobile_edit_err').text('Lead Mobile Number is already assigned!');
                        $('#submit_lead_edit').prop('disabled', true); // Disable submit button
                    } else {
                            $('#lead_mobile_edit_err').text('');
                        $('#submit_lead_edit').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
</script>

{{-- Email unique check --}}
<script>
  function email_chk(val) {
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('leadCheckEmailExist') }}",
                type: 'GET',
                data: {
                    mobile: val,
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#lead_email_create_err').text('Lead Email Id is already assigned!');
                        $('#submit_lead').prop('disabled', true); // Disable submit button
                    } else {
                            $('#lead_email_create_err').text('');
                        $('#submit_lead').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
    
  function email_chk_edit(val) {
        var id = $('#lead_id_edit').val()
        if (val != "") {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            });

            $.ajax({
                url: "{{ route('leadCheckEmailExistsEdit') }}",
                type: 'GET',
                data: {
                    mobile: val,
                    id: id
                },
                dataType: 'json', // Expect JSON response from server
                success: function(response) {
                    if (response.data !== 0) {
                        $('#lead_email_edit_err').text('Lead Email Id is already assigned!');
                        $('#submit_lead_edit').prop('disabled', true); // Disable submit button
                    } else {
                            $('#lead_email_edit_err').text('');
                        $('#submit_lead_edit').prop('disabled', false); // Enable submit button
                    }
                },
                error: function(xhr, status, error) {
                    // alert("Error: " + error); // Display error message
                }
            });
        }
    }
</script>

<!-- proposal -->

<script>
    function create_proposal_func(id,name,leadId){
        $('#proposal_lead_name').text(name)
        $('#proposal_lead_genrate_id').text(leadId)
        $('#proposal_lead_id').val(id)
    }

    function createProposal(){

        var lead_id =$('#proposal_lead_id').val();

        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        if(lead_id){
            $.ajax({
                url: '/create_lead_proposal', // Your encryption route
                type: 'POST',
                data: {
                    lead_id: lead_id,
                    _token: csrfToken // Include CSRF token here
                },
                success: function(encrypted_lead_id) {
                    // Redirect to the desired route with the encrypted ID
                    window.location.href = '/manage_proposal/proposal_add/' + encrypted_lead_id;
                },
                error: function(xhr) {
                    toastr.error('Please Try Again Later');
                }
            })
        }else{
            toastr.error('Lead Id is Missing');
        }

      ;
    }
    
   function revised_proposal_func(id,name,leadId,proposal){
        $('#proposal_lead_name').text(name)
        $('#proposal_lead_genrate_id').text(leadId)
        $('#proposal_lead_id').val(id)
        $('#proposal_list').html('')
        
        var html =""
        if(proposal.length > 0){
            proposal.forEach(function(data,index){
                var printurl ='manage_proposal/print_proposal/' + data.encrypt_id;
                var viewurl ='manage_proposal/proposal_view/' + data.encrypt_id;
                
                
                html=`
                        <div class="col-lg-12 mb-3">
                            <div class="bg-label-secondary border border-gray-400 rounded px-3 pt-2 pb-0">
                                <div class="d-flex align-items-start justify-content-between flex-wrap">
                                    <div class="mb-4">
                                        <label class="badge bg-info fw-semibold fs-6 mb-1" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Proposal Count"> ${(proposal.length - index) > 10 ? (proposal.length - index) : ('0' + (proposal.length - index))}</label>
                                        <label class="text-black fs-5 fw-semibold ms-2 mb-1">${data.proposal_id}</label>
                                        <div class="d-block mb-1">
                                            <label class="fs-6 text-black fw-semibold">Proposal Date &nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-success fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.estimate_date)}</label>
                                        </div>
                                        <div class="d-block">
                                            <label class="fs-6 text-black fw-semibold">Validity Date
                                                &nbsp;&nbsp;&nbsp;-&nbsp;</label>
                                            <label
                                                class="badge bg-danger fs-7 text-white rounded fw-semibold">${formatDateTransfer(data.due_date)}</label>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start justify-content-end mb-4">
                                        <div class="mb-0">
                                            <div class="d-block mb-1">
                                                <label class="fs-4 text-black fw-semibold">Total Amount
                                                    &nbsp;-&nbsp;</label>
                                                <label class="fs-4 text-black rounded fw-bold">&#8377; ${formatCurrency(data.grant_total_amount)}</label>
                                            </div>
                                            <div class="d-block text-end">
                                            
                                                 <a href="{{url('${viewurl}')}}" target="_blank" class="btn btn-icon btn-sm me-2" title="View Proposal" data-bs-toggle="tooltip" data-bs-placement="bottom">
                                                    <i class="mdi mdi-eye-outline fs-3 text-dark"></i>
                                                </a>
                                               
                                               
                                                
                                                <a href="{{ url('${printurl}') }}" target="_blank"
                                                    class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Print">
                                                    <span> <i
                                                            class="mdi mdi-printer-pos-outline fs-3 text-dark"></i></span>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                `;
                $('#proposal_list').append(html)
            })
        }
        
    }
     function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
    
     function reviseProposal(id){

        var proposal_id =id;

        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        if(proposal_id){
            $.ajax({
                url: '/revise_lead_proposal', // Your encryption route
                type: 'POST',
                data: {
                    proposal_id: proposal_id,
                    _token: csrfToken // Include CSRF token here
                },
                success: function(encrypted_lead_id) {
                    // Redirect to the desired route with the encrypted ID
                    window.location.href = '/manage_proposal/proposal_revise/' + encrypted_lead_id;
                },
                error: function(xhr) {
                    toastr.error('Please Try Again Later');
                }
            })
        }else{
            toastr.error('Lead Id is Missing');
        }

      ;
    }
    
        

</script>
<script>
    function toggleInputField_spam(value) {
        var spamReasonDiv = document.getElementById('spam_reason_div');
        var spamReasonText = document.getElementById('spam_reason_text');
        var spamCommentsDiv = document.getElementById('spam_comments_div');
        var selectedOption = document.querySelector('#spam_reason_edit option:nth-child(' + (document.getElementById('spam_reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            spamReasonDiv.style.display = 'block';
            spamReasonText.setAttribute('required', 'required');
        } else {
            spamReasonDiv.style.display = 'none';
            spamReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            spamCommentsDiv.style.display = 'block';
        } else {
            spamCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>
    function toggleInputField(value) {
        var dropReasonDiv = document.getElementById('drop_reason_div');
        var dropReasonText = document.getElementById('drop_reason_text');
        var dropCommentsDiv = document.getElementById('drop_comments_div');
        var selectedOption = document.querySelector('#reason_edit option:nth-child(' + (document.getElementById('reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (value == '1') {
            dropReasonDiv.style.display = 'block';
            dropReasonText.setAttribute('required', 'required');
        } else {
            dropReasonDiv.style.display = 'none';
            dropReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            dropCommentsDiv.style.display = 'block';
        } else {
            dropCommentsDiv.style.display = 'none';
        }
    }
    function toggleInputField_potential(value) {
        var potentialReasonDiv = document.getElementById('potential_reason_div');
        var potentialReasonText = document.getElementById('potential_reason_text');
        var potentialCommentsDiv = document.getElementById('potential_comments_div');
        var selectedOption = document.querySelector('#potential_reason_edit option:nth-child(' + (document.getElementById('potential_reason_edit').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-potential') : null;

        if (value == '1') {
            potentialReasonDiv.style.display = 'block';
            potentialReasonText.setAttribute('required', 'required');
        } else {
            potentialReasonDiv.style.display = 'none';
            potentialReasonText.removeAttribute('required');
        }

        if (commentsCheck == '1') {
            potentialCommentsDiv.style.display = 'block';
        } else {
            potentialCommentsDiv.style.display = 'none';
        }
    }
</script>
<script>  
   function pending_followup_func(){
         $('#pending_followup_form').submit();
    }
     function current_month_lead_func(){
         $('#month_lead_form').submit();
    }
</script>
<script>
     function formatDateLead(dateString) { 
        const date = new Date(dateString); 
        if (isNaN(date.getTime())) return '-'; 
        return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); 
    } 
    function confirmChangeDate(id, lead_name, register_date) { 
        $('#status_lead_id').val(id); 
        $('#staus_event_name').text(lead_name); 
        $('#registered_date_change').text(formatDateLead(register_date)); 
        $('#register_date_edit').val(formatDateLead(register_date)); // Reset state 
        $('#confirm_checkbox').prop('checked', false); 
        $('#btn_confirm_change').prop('disabled', true); 
        $('#date_error').addClass('d-none'); 
        console.log(formatDateLead(register_date))
    } // Checkbox enables/disables button 
    $('#confirm_checkbox').on('change', function () { 
        $('#btn_confirm_change').prop('disabled', !this.checked); 
    }); 
        // Validation before save 
    function statusUpdate() { 
        const inputDate = new Date($('#register_date_edit').val()); 
        const register_date = $('#register_date_edit').val(); 
        const lead_id = $('#status_lead_id').val(); 
        const today = new Date(); 
        
        if(register_date == ''){
            $('#date_error').removeClass('d-none'); return false; 
            $('#register_date_error').text('Lead Register Date is Required');
        }else if (inputDate > today) { 
            $('#date_error').removeClass('d-none'); return false; 
            $('#register_date_error').text('Date cannot be in the future.');
        } 
        $('#date_error').addClass('d-none'); 
        // ✅ proceed with your save logic (AJAX or form submit) 
        var err=0;
         if(err == 0){
              $('#btn_confirm_change').prop('disabled', true);
               $('#btn_confirm_change').text('Updating...');
                const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            $.ajax({
                url: '/registered_date_update',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    lead_id: lead_id,
                    register_date: register_date,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        // console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to Update the Register Date.');
                         $('#btn_confirm_change').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to Update the Register Date.';
                    toastr.error(errorMsg);
                     $('#btn_confirm_change').prop('disabled', true);
                      resetButton();
                }
            });
        }
        // console.log('Date change confirmed!'); 
    } 
        function resetButton() {
            $('#btn_confirm_change').prop('disabled', false);
            $('#btn_confirm_change').text('Yes');
        }
</script>



@endsection
