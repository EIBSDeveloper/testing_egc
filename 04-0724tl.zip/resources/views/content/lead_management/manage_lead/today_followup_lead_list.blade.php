@extends('layouts/layoutMaster')

@section('title', 'Manage Lead')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 9999;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            /* 50% {
                transform: scale(1.2);
                opacity: 0.7;
            } */

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }
    </style>
     @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
       
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Lead</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Today Followup ( <span class="text-info fw-bold">{{date('d-M-Y')}}</span>  )</a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            <div class="nav-align-top mb-2">
                <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                    <div class="scroll-container-wrapper">
                        <button class="scroll-btn left" id="scrollLeftBtn"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                            <div class="scroll-container" id="scrollContainer">
                                @php
                                    $module_name = 'Lead Management';
                                    $menu_name = 'Manage Lead';
                                @endphp
                                @if(auth()->user()->hasPermission($module_name, 'Raw Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a   href="{{url('/raw_lead')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/raw_lead.ico') }}"
                                                alt="Raw Lead Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Raw Lead</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalLeadCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Lead Bank', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/lead_bank')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/lead_bank.ico') }}"
                                                alt="Lead Bank Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Lead Bank</span>
                                            <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadbankCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/manage_lead')}}"
                                            class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/lead_icn.ico') }}" alt="Lead Icon"
                                                class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Lead</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $leadOriginalCount??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Spam Lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_spam_count>0)
                                    <a href="{{url('/spam_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Spam Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_spam_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                       <img src="{{ asset('assets/phdizone_images/lead/spam_lead.ico') }}" alt="Spam Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Spam Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                            @if(auth()->user()->hasPermission($module_name, 'Dead lead', $menu_name))
                            <div class="item">
                                <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                    @if($not_verified_drop_count>0)
                                    <a href="{{url('/drop_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2">Dead Lead</span>
                                        <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $not_verified_drop_count??0) }}</span>
                                    </a>
                                    @else
                                    <a href="javascript:;" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" style="background-color: #56dd90 !important;">
                                        <img src="{{ asset('assets/phdizone_images/lead/dead_lead.ico') }}" alt="Dead Lead Icon" class="w-30px h-30px text-black fw-bold">
                                        <span class="ms-2 text-white">Dead Lead</span>
                                    </a>
                                    @endif
                                </li>
                            </div>
                            @endif
                                @if(auth()->user()->hasPermission($module_name, 'Internal Calls Lead', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/internal_calls_lead')}}" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1">
                                            <img src="{{ asset('assets/phdizone_images/lead/internal_call.ico') }}"
                                                alt="Internal Calls Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Internal Calls</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $internal_calls_count??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                                @if(auth()->user()->hasPermission($module_name, 'Today Followup', $menu_name))
                                <div class="item">
                                    <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                        <a href="{{url('/today_followup_lead')}}"
                                            class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1"
                                            style="background-color: #FCFF66 !important;">
                                            <img src="{{ asset('assets/phdizone_images/lead/today_followup.ico') }}"
                                                alt="Today Followup Icon" class="w-30px h-30px text-black fw-bold">
                                            <span class="ms-2">Today Followup</span>
                                            <span
                                                class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf('%02d', $totalFollowup??0) }}</span>
                                        </a>
                                    </li>
                                </div>
                                @endif
                            </div>
                        <button class="scroll-btn right" id="scrollRightBtn"><i
                                class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                    </div>
                </ul>
            </div>
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade  show active" id="tab_today_followup" role="tabpanel">
                                <div class="row">
                                    <div class="row mb-4">
                                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                        <div class="col-lg-2">
                                            <span>Show</span>
                                            <br>
                                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                                @php
                                                $options = [10, 25, 100, 500]; // Define available options
                                                @endphp
                                                @php foreach ($options as $option): @endphp
                                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                    @php echo $option; @endphp
                                                </option>
                                                @php endforeach; @endphp
                                            </select>
                                        </div>
                                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                            <form id="search_form" method="POST" action="/today_followup_lead">
                                                @csrf
                                              <div class="d-flex align-items-center gap-2 mt-2">
                                                <div>
                                                  <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                  <input type="hidden" name="filter_on" value="1">
                                                  <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                  <input
                                                    type="text"
                                                    class="form-control"
                                                    id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                                    placeholder="Enter Lead - Name/ Date/ Lead group"
                                                  />
                                                </div>
                                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                                              </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <input type="hidden" id="view_edit_id" />
                                            <table
                                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                                <thead>
                                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                        <th class="min-w-200px">Lead</th>
                                                        <th class="min-w-150px">Mobile</th>
                                                        <th class="min-w-150px">Sales Person</th>
                                                        <th class="min-w-80px">Followup Time</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="text-gray-600 fw-semibold fs-7">
                                                    @if (count($leads) > 0)
                                                    @foreach ($leads as $category)
                                                    <tr  style="background: #fcff66;">
                                                        <td>
                                                            <div class="mb-0 align-items-center">
                                                                <label>
                                                                    @if( $category->lead_appointment_status == 1)
                                                                    <i class="animation-blink mdi mdi-phone-clock text-danger fs-4"
                                                                        title="Appointment"></i>
                                                                    @endif
                                                                    <span class="fs-7 me-2">{{ $category->lead_name }}</span>
                                                                    @if( $category->lead_gender == 1)
                                                                    <span><i class="mdi mdi-face-man text-info"></i></span>
                                                                    @elseif( $category->lead_gender == 2)
                                                                    <span><i class="mdi mdi-face-woman text-danger"></i></span>
                                                                    @elseif( $category->lead_gender == 3)
                
                                                                    @endif
                                                                    @if ($category->lead_dob == date('Y-m-d'))
                                                                    <span><i
                                                                            class="mdi mdi-cake-variant-outline animation-blink text-black fs-4"></i></span>
                                                                    @endif
                
                                                                </label>
                                                                <div class="d-block text-black fs-8" title="Registered date">{{
                                                                    isset($category->registered_date) ? date($common_date_format,
                                                                    strtotime($category->registered_date)) :''}}</div>
                                                                <div class="d-block text-black fs-8"
                                                                    title="{{ $category->lead_email_id }}">{{ $category->lead_email_id
                                                                    }}</div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label title="Mobile No"> 
                                                                {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }} {{ $category->status == 1 ? "XXXXXXXXXX" : $category->lead_mobile }}
                                                            </label>
                                                        </td>
                                                        <td>
                                                            @if( $category->status == 8)
                                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="EAPL">EAPL</label>
                                                            @else
                                                            <label data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="{{ $category->nick_name ?? '-'}}">{{ $category->staff_name ??
                                                                '-'}}</label>
                
                                                            @endif
                
                                                            <div class="d-block">
                                                                <label class="badge bg-warning text-black rounded fw-bold fs-8"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Lead Source">{{ $category->lead_source_name }}</label>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <label> {{ date('h:i A', strtotime($category->appointment_time)) }}</label>
                                                        </td>
                                                    </tr>
                                                    @endforeach
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="mt-4">
                                            {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
        function populateStatusModal(id){
          $('#lead_status_id').val(id)
        }
    </script>
    <script>
        function sort_filter(val) {
            if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
            } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
            }
        }
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
