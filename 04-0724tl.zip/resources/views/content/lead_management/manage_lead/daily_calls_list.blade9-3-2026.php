@extends('layouts/layoutMaster')

@section('title', 'Manage Lead Basket')


@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
    <style>
        .lead-card {
            width: 160px;
            height: 200px;
            padding-bottom: 20px !important;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            text-align: center;
            cursor: pointer;
        }

        .lead-card img {
            width: 100px;
            height: auto;
            object-fit: contain;
            image-rendering: crisp-edges;
        }

        .lead_list thead th,
        .lead_list tbody td {
            padding: 7px !important;
        }

        .list_page_1 thead th,
        .list_page_1 tbody td {
            padding: 7px !important;
        }

        .boom-animate {
            animation: boom 0.6s ease-out;
            z-index: 2;
        }

        @keyframes boom {
            0% {
                transform: scale(0.7);
                opacity: 1;
            }

            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        .highlight-row {
            position: relative;
            width: 200px;
            height: 50px;
            overflow: hidden;

        }
    </style>
    <!-- Optional: Custom CSS for enhanced styling -->
    <style>
        /* Bootstrap 5 toggle switch customization */
        .form-switch .form-check-input {
            width: 3em;
            height: 1.5em;
            cursor: pointer;
            margin-right: 0.5em;
        }

        .form-switch .form-check-input:checked {
            background-color: #28a745;
            /* Success green */
            border-color: #28a745;
        }

        .form-switch .form-check-input:not(:checked) {
            background-color: #dc3545;
            /* Danger red */
            border-color: #dc3545;
        }

        .switch-status {
            font-weight: 600;
            font-size: 0.9rem;
            transition: color 0.3s ease;
        }

        /* Optional: Add slide animation */
        .form-switch .form-check-input {
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
    </style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data = $helper->get_staff_data($user_id);
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="col-xl-3 card-action-title">
                <h5 class="card-title mb-1">Schedule Daily Call</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="col-xl-9 ">
                <div class="d-flex align-items-end justify-content-end">
                    @if (in_array(auth()->user()->role_id, [1, 20]))
                        <a href="/lead_management/potential_lead" class="text-center border border-2 p-2 me-2"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            data-bs-original-title="Potentials Basket Leads Count">
                            <div class="text-dark fw-semibold fs-6">PB Leads</div>
                            <div class="d-block">
                                <div class="badge rounded fw-bold text-black fs-6"
                                    style="background-color: #4CD2FC !important;">{{ $pb_counts ?? 0 }}</div>
                            </div>
                        </a>
                        <button class=" btn btn-primary waves-effect waves-light" id="dailyCallBtn">Daily Call
                            Setup</button>
                        {{-- <a href="/daily_call_unfollow_lead" class="ms-2 btn btn-danger waves-effect waves-light">
                            UnFollow List
                        </a> --}}
                        <button class=" btn btn-primary waves-effect waves-light ms-2" id="dailyPerformanceBtn">Daily Call
                            Performance</button>
                        @if (in_array(auth()->user()->role_id, [1, 20]))
                            <button type="button" class="ms-2 btn btn-primary waves-effect waves-light"
                                onclick="dailyCallHistoryBtn()" data-bs-toggle="modal"
                                data-bs-target="#dailyCallHistoryModal">
                                Daily Call History
                            </button>

                            <!-- Toggle Switch Container -->
                            <div class="form-check form-switch ms-2">
                                <input class="form-check-input" type="checkbox" role="switch" id="dailyCallSwitch"
                                    {{ $monitor->status == 0 ? 'checked' : '' }}>
                                <label class="form-check-label" for="dailyCallSwitch">
                                    <span
                                        class="switch-status {{ $monitor->status == 0 ? 'text-success' : 'text-danger' }}">
                                        {{ $monitor->status == 0 ? 'ON' : 'OFF' }}
                                    </span>
                                </label>
                            </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
        <div class="card-body px-4 pb-0 pt-2">
            @php
                $module_name = 'Lead Management';
                $menu_name = 'Manage Lead Baseket';

                $module_name = 'Lead Management';
                $menu_name = 'Manage Lead';
            @endphp
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="tab-content p-0">
                            <div class="tab-pane fade show active" id="tab_spam_lead" role="tabpanel">
                                <div class="row">
                                    <div class="row mb-2 mt-2">
                                        <div class="col-lg-2">
                                            @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                            <div>
                                                <span>Show</span>
                                                <br>
                                                <select id="perpage" name="perpage"
                                                    class="form-select form-select-sm w-60px"
                                                    onchange="sort_filter(this.value);">
                                                    @php
                                                        $options = [10, 25, 100, 500]; // Define available options
                                                    @endphp
                                                    @foreach ($options as $option)
                                                        <option value="{{ $option }}"
                                                            @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                            @php echo $option; @endphp
                                                        </option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-10 d-flex align-items-end justify-content-end">
                                            <form id="search_form" method="POST" action="/daily_call_lead">
                                                @csrf
                                                <div class="d-flex align-items-center gap-2">
                                                    <div class="">
                                                        <input type="hidden" name="page"
                                                            value="{{ request('page', 1) }}">
                                                        <input type="hidden" name="filter_on" value="1">
                                                        <input type="hidden" class="sorting_filter_class"
                                                            name="sorting_filter" id="sorting_filter"
                                                            value="@php echo $perpage ? $perpage : 10; @endphp" />
                                                        <input type="text" class="form-control" id="lead_fill"
                                                            name="lead_fill" value="{{ $lead_fill ?? '' }}"
                                                            placeholder="Enter Lead - Name/ Mob. No/ Email Id" />
                                                    </div>
                                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                                        onclick="search_filter_func()">Search</button>
                                                    <a href="{{ url('/daily_call_lead') }}" type="button"
                                                        class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span
                                                            class="mdi mdi-refresh fs-6"></span>
                                                    </a>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <input type="hidden" id="view_edit_id" />
                                        <table
                                            class="table align-top table-row-dashed table-striped table-hover gy-1 gs-2 lead_list list_page">
                                            <thead>
                                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                    <th class="min-w-150px">Lead</th>
                                                    <th class="min-w-100px"><span data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom" title="Registered Date">RD
                                                        </span><span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                            title="Last Followup Date"> / LFD</th>
                                                    <th class="min-w-80px">Sales Person</th>
                                                    <th class="min-w-80px">Assign Person</th>
                                                    <th class="min-w-100px">Follow Up</th>
                                                    {{-- <th class="min-w-100px">Basket Reason / Comments</th> --}}
                                                    @if (auth()->user()->hasPermission($module_name, 'Call Summary', $menu_name))
                                                        <th class="min-w-80px">Summary</th>
                                                    @endif
                                                </tr>
                                            </thead>
                                            <tbody class="text-gray-600 fw-semibold fs-7">
                                                {{-- @if (auth()->user()->hasPermission($module_name, 'List', $menu_name)) --}}
                                                @if (count($leads) > 0)
                                                    @foreach ($leads as $i => $category)
                                                        <tr class="{{ $category->just_dial_id > 0 && $category->lead_status_id == 1 ? 'highlight-row' : '' }}"
                                                            style="background-color: 
                                        
                                                            @if ($category->alert_status == 1 && $category->status == 0 && $category->status !== 10 && $category->status != 8) lightpink;@elseif($category->status != 4 && $category->is_hot_lead == 1)#6fd1fb;@else{{ $category->lead_bg_color }} {{-- Use the existing color otherwise --}} @endif;">
                                                            <td>
                                                                <div class="d-flex align-items-center gap-1">
                                                                    @if ($category->is_hot_lead == 2)
                                                                        <div data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Hot Lead Star">
                                                                            <img src="{{ asset('assets/phdizone_images/lead/Star_animate.gif') }}"
                                                                                alt="Hot Lead Star"
                                                                                class="w-50px h-50px text-black fw-bold">
                                                                        </div>
                                                                    @endif
                                                                    @if ($category->lead_appointment_status == 1)
                                                                        <div class="animation-blink"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Appointment Onprogress">
                                                                            <img src="{{ asset('assets/phdizone_images/lead/appointment.ico') }}"
                                                                                alt="Appointment Onprogress Icon"
                                                                                class="w-30px h-30px text-black fw-bold">
                                                                        </div>
                                                                    @endif
                                                                    <div class="ms-1 mb-0">
                                                                        <div class="d-flex align-items-center gap-2">
                                                                            @if (in_array(auth()->user()->role_id, [1, 20]))
                                                                                <label
                                                                                    class="fs-7 text-truncate w-200px text-black fw-semibold"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="top"
                                                                                    title="{{ trim($category->lead_name) }}">{{ trim($category->lead_name) }}</label>
                                                                            @else
                                                                                @if ($i == 0)
                                                                                    <label
                                                                                        class="fs-7 text-truncate w-200px text-black fw-semibold"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="top"
                                                                                        title="{{ trim($category->lead_name) }}">{{ trim($category->lead_name) }}</label>
                                                                                @else
                                                                                    -
                                                                                @endif
                                                                            @endif

                                                                            @if (isset($category->productsData) && count($category->productsData) > 0)
                                                                                <span
                                                                                    class="text-dark fs-8 fw-semibold cursor-pointer"
                                                                                    data-bs-toggle="dropdown"
                                                                                    aria-haspopup="true"
                                                                                    aria-expanded="false"><span
                                                                                        class="mdi mdi mdi-information fs-8"
                                                                                        data-bs-toggle="tooltip"
                                                                                        data-bs-placement="bottom"
                                                                                        title="Product"></span></span>
                                                                                <div
                                                                                    class="dropdown-menu dropdown-menu-start w-350px">
                                                                                    <div
                                                                                        class="text-dark fs-6 text-center my-2 fw-semibold">
                                                                                        Products</div>
                                                                                    <hr class="mt-0 mb-2 border-dark">
                                                                                    <div
                                                                                        class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                                        @if (isset($category->productsData))
                                                                                            @foreach ($category->productsData as $product)
                                                                                                <div
                                                                                                    class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                                                                                    <div
                                                                                                        class="text-black mb-1 fw-semibold fs-5 me-2">
                                                                                                        &#9733;</div>
                                                                                                    <div class="d-block">
                                                                                                        <div
                                                                                                            class="text-black fw-semibold text-justify fs-7">
                                                                                                            {{ $product->product_name }}
                                                                                                        </div>
                                                                                                        <div
                                                                                                            class="fw-semibold text-info fs-8">
                                                                                                            {{ $product->product_category_name }}
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            @endforeach
                                                                                        @endif
                                                                                    </div>
                                                                                </div>
                                                                            @endif
                                                                        </div>
                                                                        @if (in_array(auth()->user()->role_id, [1, 20]))
                                                                            <div class="d-block">
                                                                                <div
                                                                                    class="d-flex align-items-center mb-0">

                                                                                    @if ($category->lead_mobile)
                                                                                        @if ($category->status != 7)
                                                                                            <label
                                                                                                class="fs-7 text-dark fw-semibold me-1 text-nowrap">
                                                                                                @php
                                                                                                    $call_chk = isset(
                                                                                                        $category->inter_calls,
                                                                                                    )
                                                                                                        ? $category->inter_calls
                                                                                                        : 0;
                                                                                                    $countryCode =
                                                                                                        $call_chk == 0
                                                                                                            ? '+91'
                                                                                                            : '+' .
                                                                                                                $category->inter_calls;
                                                                                                    $mobileNumber =
                                                                                                        $category->status ==
                                                                                                        1
                                                                                                            ? 'XXXXXXXXXX'
                                                                                                            : $category->lead_mobile;
                                                                                                @endphp
                                                                                                {{ $countryCode }}
                                                                                                {{ $mobileNumber }}
                                                                                            </label>
                                                                                        @endif
                                                                                        @if ($category->status == 7)
                                                                                            <label
                                                                                                class="fs-7 text-black fw-semibold me-1 text-nowrap"
                                                                                                title="Mobile No">
                                                                                                {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}
                                                                                            </label>
                                                                                        @endif
                                                                                        @php
                                                                                            $phoneVerifyContent = json_decode(
                                                                                                $category->phone_verify_content,
                                                                                                true,
                                                                                            );
                                                                                        @endphp
                                                                                        @if ($category->phone_verify_status == 1)
                                                                                            <a href="javascript:;"
                                                                                                class="fs-7 text-black fw-semibold me-1"
                                                                                                onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                                <span
                                                                                                    data-bs-toggle="tooltip"
                                                                                                    data-bs-placement="bottom"
                                                                                                    title="Mobile No Verified"><i
                                                                                                        class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                                                            </a>
                                                                                        @elseif($category->phone_verify_status == 2)
                                                                                            <a href="javascript:;"
                                                                                                class="fs-7 text-black fw-semibold me-1"
                                                                                                onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                                <span
                                                                                                    data-bs-toggle="tooltip"
                                                                                                    data-bs-placement="bottom"
                                                                                                    title="Mobile No. Not Verified">
                                                                                                    <svg class="w-20px h-20px"
                                                                                                        enable-background="new 0 0 500 500"
                                                                                                        viewBox="0 0 500 500"
                                                                                                        id="hand-draw-white-cross-mark-on-red-circle">
                                                                                                        <rect
                                                                                                            id="Layer_1"
                                                                                                            fill="#fff0f0"
                                                                                                            display="none">
                                                                                                        </rect>
                                                                                                        <g id="Layer_2">
                                                                                                            <circle
                                                                                                                cx="250"
                                                                                                                cy="250"
                                                                                                                r="200"
                                                                                                                fill="#f32f45">
                                                                                                            </circle>
                                                                                                            <path
                                                                                                                fill="#f32f45"
                                                                                                                d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                                            </path>
                                                                                                            <path
                                                                                                                fill="#fff"
                                                                                                                d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                                            </path>
                                                                                                        </g>
                                                                                                    </svg>
                                                                                                </span>
                                                                                            </a>
                                                                                        @endif
                                                                                    @endif
                                                                                </div>
                                                                                <div
                                                                                    class="d-flex align-items-center mb-0">
                                                                                    @if ($category->lead_email_id)
                                                                                        <label
                                                                                            class="fs-7 text-dark fw-semibold me-1 text-truncate max-w-170px"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="{{ $category->lead_email_id }}">
                                                                                            {{ $category->lead_email_id }}</label>
                                                                                    @endif
                                                                                </div>
                                                                            </div>
                                                                            <div class="d-block text-dark fs-8 mb-2 fw-semibold"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Lead Id">
                                                                                {{ $category->lead_id ?? '' }}
                                                                            </div>
                                                                        @else
                                                                            @if ($i == 0)
                                                                                <div class="d-block">
                                                                                    <div
                                                                                        class="d-flex align-items-center mb-0">

                                                                                        @if ($category->lead_mobile)
                                                                                            @if ($category->status != 7)
                                                                                                <label
                                                                                                    class="fs-7 text-dark fw-semibold me-1 text-nowrap">
                                                                                                    @php
                                                                                                        $call_chk = isset(
                                                                                                            $category->inter_calls,
                                                                                                        )
                                                                                                            ? $category->inter_calls
                                                                                                            : 0;
                                                                                                        $countryCode =
                                                                                                            $call_chk ==
                                                                                                            0
                                                                                                                ? '+91'
                                                                                                                : '+' .
                                                                                                                    $category->inter_calls;
                                                                                                        $mobileNumber =
                                                                                                            $category->status ==
                                                                                                            1
                                                                                                                ? 'XXXXXXXXXX'
                                                                                                                : $category->lead_mobile;
                                                                                                    @endphp
                                                                                                    {{ $countryCode }}
                                                                                                    {{ $mobileNumber }}
                                                                                                </label>
                                                                                            @endif
                                                                                            @if ($category->status == 7)
                                                                                                <label
                                                                                                    class="fs-7 text-black fw-semibold me-1 text-nowrap"
                                                                                                    title="Mobile No">
                                                                                                    {{ ($category->inter_calls ?? 0) == 0 ? '+91 ' : '+' . $category->inter_calls }}{{ substr($category->lead_mobile, 0, 5) . 'XXXXX' }}
                                                                                                </label>
                                                                                            @endif
                                                                                            @php
                                                                                                $phoneVerifyContent = json_decode(
                                                                                                    $category->phone_verify_content,
                                                                                                    true,
                                                                                                );
                                                                                            @endphp
                                                                                            @if ($category->phone_verify_status == 1)
                                                                                                <a href="javascript:;"
                                                                                                    class="fs-7 text-black fw-semibold me-1"
                                                                                                    onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}', '{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                                    <span
                                                                                                        data-bs-toggle="tooltip"
                                                                                                        data-bs-placement="bottom"
                                                                                                        title="Mobile No Verified"><i
                                                                                                            class="mdi mdi-check-decagram fs-4 text-primary"></i></span>
                                                                                                </a>
                                                                                            @elseif($category->phone_verify_status == 2)
                                                                                                <a href="javascript:;"
                                                                                                    class="fs-7 text-black fw-semibold me-1"
                                                                                                    onclick="phoneVerifyDetails('{{ trim($category->lead_name) }}', '{{ $category->lead_mobile }}','{{ $phoneVerifyContent['valid'] ?? false }}','{{ $phoneVerifyContent['carrier'] ?? '' }}','{{ $phoneVerifyContent['line_type'] ?? '' }}','{{ $phoneVerifyContent['location'] ?? '' }}')">
                                                                                                    <span
                                                                                                        data-bs-toggle="tooltip"
                                                                                                        data-bs-placement="bottom"
                                                                                                        title="Mobile No. Not Verified">
                                                                                                        <svg class="w-20px h-20px"
                                                                                                            enable-background="new 0 0 500 500"
                                                                                                            viewBox="0 0 500 500"
                                                                                                            id="hand-draw-white-cross-mark-on-red-circle">
                                                                                                            <rect
                                                                                                                id="Layer_1"
                                                                                                                fill="#fff0f0"
                                                                                                                display="none">
                                                                                                            </rect>
                                                                                                            <g
                                                                                                                id="Layer_2">
                                                                                                                <circle
                                                                                                                    cx="250"
                                                                                                                    cy="250"
                                                                                                                    r="200"
                                                                                                                    fill="#f32f45">
                                                                                                                </circle>
                                                                                                                <path
                                                                                                                    fill="#f32f45"
                                                                                                                    d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                                                        l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                                                        c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                                                        c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                                                        c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                                                        c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                                                        C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                                                </path>
                                                                                                                <path
                                                                                                                    fill="#fff"
                                                                                                                    d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                                                        c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                                                        c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                                                        c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                                                </path>
                                                                                                            </g>
                                                                                                        </svg>
                                                                                                    </span>
                                                                                                </a>
                                                                                            @endif
                                                                                        @endif
                                                                                    </div>
                                                                                    <div
                                                                                        class="d-flex align-items-center mb-0">
                                                                                        @if ($category->lead_email_id)
                                                                                            <label
                                                                                                class="fs-7 text-dark fw-semibold me-1 text-truncate max-w-170px"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="{{ $category->lead_email_id }}">
                                                                                                {{ $category->lead_email_id }}</label>
                                                                                        @endif
                                                                                    </div>
                                                                                </div>
                                                                                <div class="d-block text-dark fs-8 mb-2 fw-semibold"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Lead Id">
                                                                                    {{ $category->lead_id ?? '' }}
                                                                                </div>
                                                                            @else
                                                                                -
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <div
                                                                    class="d-flex align-items-center justify-content-start mb-2 gap-2">
                                                                    <div>
                                                                        <label class="badge text-black fw-semibold fs-8"
                                                                            style="background-color:rgb(78, 202, 94);"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Registered Date">{{ isset($category->registered_date) ? date($common_date_format, strtotime($category->registered_date)) : date($common_date_format, strtotime($category->created_at)) }}</label>

                                                                        @if (isset($category->appointment_date))
                                                                            <hr class="mt-1 mb-1">
                                                                            <div class="d-block mt-1">
                                                                                <label
                                                                                    class="badge bg-body text-danger fw-semibold fs-8"
                                                                                    data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Last Follow Up Date">
                                                                                    {{ $category->appointment_date ? date($common_date_format, strtotime($category->appointment_date)) : '' }}</label>
                                                                            </div>
                                                                        @endif
                                                                        <hr class="mt-1 mb-1">
                                                                        <div class="d-block mt-1">
                                                                            <a href="javascript:;"
                                                                                class="badge bg-info fs-8 rounded text-white fw-semibold me-1">
                                                                                <span data-bs-toggle="tooltip"
                                                                                    data-bs-placement="bottom"
                                                                                    title="Lead Life Time">{{ $category->formattedDifference ?? '0 day' }}</span>
                                                                            </a>
                                                                        </div>
                                                                    </div>


                                                                </div>

                                                            </td>
                                                            <td>
                                                                <div class="d-flex gap-2">
                                                                    <span
                                                                        class="text-truncate max-w-125px fw-semibold fs-7 text-black"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        title="{{ $category->nick_name ?? 'Old Staff' }}">{{ $category->staff_name ?? 'Old Staff' }}</span>
                                                                    <div class="avatar avatar-sm me-1">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            onclick="openCallHistoryModal('{{ $category->sno }}','Outgoing','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}' ,'{{ $category->incoming_count }}','{{ $category->outgoing_count }}','{{ $category->missed_reject_count }}','{{ $category->dialed_count }}')"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_call_log">
                                                                            <div class="rounded bg-label-success border border-gray-400i fs-5 px-1 py-0 text-center"
                                                                                data-bs-toggle="tooltip"
                                                                                data-bs-placement="bottom"
                                                                                title="Outgoing Calls Count">
                                                                                <img src="{{ asset('assets/phdizone_images/calls/outgoing_call.ico') }}"
                                                                                    alt="Outgoing Call Icon"
                                                                                    class="w-15px h-15px text-black fw-bold">
                                                                            </div>
                                                                            @if ($category->outgoing_count > 0)
                                                                                <span
                                                                                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill border text-black fs-8 mt-n1"
                                                                                    style="background-color: #FFA500 !important;">{{ $category->outgoing_count }}</span>
                                                                            @endif
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                                <div class="d-block">
                                                                    @if ($category->just_dial_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-6 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span class="jd-blue">Just</span><span
                                                                                class="jd-orange">dial</span>
                                                                        </label>
                                                                    @elseif($category->cloud_call_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <i class="fas fa-cloud cc-icon"></i><span
                                                                                class="cc-purple">Cloud</span><span
                                                                                class="cc-purple">Call</span>
                                                                        </label>
                                                                    @elseif($category->call_tracker_id > 0)
                                                                        <label
                                                                            class="badge ct-orange text-white rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span>Tra<i
                                                                                    class="mdi mdi-phone-in-talk ct-icon"></i>cker</span>
                                                                        </label>
                                                                    @elseif($category->website_id > 0)
                                                                        <label
                                                                            class="badge bg-white text-primary rounded fw-bold fs-8 blink source-label"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <span class="text-primary">Web</span><span
                                                                                class="text-primary">Site</span>
                                                                        </label>
                                                                    @elseif($category->lead_source_id == 20)
                                                                        <span
                                                                            class="qr-badge d-inline-flex align-items-center gap-1 fs-7"
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            <i
                                                                                class="mdi mdi-qrcode-scan fs-7"></i>{{ $category->lead_source_name ?? '-' }}
                                                                        </span>
                                                                    @else
                                                                        <label
                                                                            class="badge bg-secondary text-white rounded fw-semibold fs-8 "
                                                                            data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Lead Source">
                                                                            {{ $category->lead_source_name ?? '-' }}
                                                                        </label>
                                                                    @endif
                                                                </div>
                                                            </td>
                                                            <td>
                                                                @php
                                                                    $dc_staff_details = $helper->staff_details(
                                                                        $category->dc_staff_id,
                                                                    );
                                                                @endphp
                                                                <span
                                                                    class="text-truncate max-w-125px fw-semibold fs-7 text-black"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="{{ $dc_staff_details->nick_name ?? 'Old Staff' }}">
                                                                    {{ $dc_staff_details->staff_name ?? 'Old Staff' }}
                                                                </span>
                                                            </td>
                                                            <td>
                                                                @if (in_array(auth()->user()->role_id, [1, 20]))
                                                                    <div class="d-flex align-items-center mt-2 gap-1">
                                                                        @if ($category->status != 7 && $category->spam_verified != 1)
                                                                            @if ($category->appointment_status == 1 && $category->status !== 4 && $category->status !== 10)
                                                                                <div class="avatar avatar-sm me-2">
                                                                                    <a href="javascript:;"
                                                                                        class="dropdown-item"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#kt_modal_follow_up_lead_schedule"
                                                                                        onclick="openResheduleModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}', '{{ $category->sch_sno }}')">
                                                                                        <div class="border border-gray-500i rounded"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup">
                                                                                            <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                                                alt="Premium Potential Icon"
                                                                                                class="w-30px h-30px text-black fw-bold">
                                                                                        </div>
                                                                                        <span
                                                                                            class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup Count"
                                                                                            style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                        <span
                                                                                            class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup Pending">!</span>
                                                                                    </a>
                                                                                </div>
                                                                            @elseif($category->appointment_status == 4 && $category->status !== 4 && $category->status !== 10)
                                                                                <div class="avatar avatar-sm me-2">
                                                                                    <a href="javascript:;"
                                                                                        class="dropdown-item"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#kt_modal_again_follow_up_lead_schedule"
                                                                                        onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}', '{{ $category->sch_sno }}')">
                                                                                        <div class="border border-gray-500i rounded"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup">
                                                                                            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                alt="Premium Potential Icon"
                                                                                                class="w-30px h-30px text-black fw-bold">
                                                                                        </div>
                                                                                        <span
                                                                                            class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Followup Count"
                                                                                            style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                    </a>
                                                                                </div>
                                                                            @elseif($category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                                                <div class="avatar avatar-sm me-2">
                                                                                    <a href="javascript:;"
                                                                                        class="dropdown-item"
                                                                                        data-bs-toggle="modal"
                                                                                        data-bs-target="#kt_modal_follow_up_lead"
                                                                                        onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                        <div class="border border-gray-500i rounded"
                                                                                            data-bs-toggle="tooltip"
                                                                                            data-bs-placement="bottom"
                                                                                            title="Not Yet Followed">
                                                                                            <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                alt="Premium Potential Icon"
                                                                                                class="w-30px h-30px text-black fw-bold">
                                                                                        </div>
                                                                                    </a>
                                                                                </div>
                                                                            @elseif($category->status == 5)
                                                                            @endif
                                                                        @endif
                                                                    </div>
                                                                @else
                                                                    @if ($i == 0)
                                                                        <div class="d-flex align-items-center mt-2 gap-1">
                                                                            @if ($category->status != 7 && $category->spam_verified != 1)
                                                                                @if ($category->appointment_status == 1 && $category->status !== 4 && $category->status !== 10)
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_follow_up_lead_schedule"
                                                                                            onclick="openResheduleModal('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}', '{{ $category->sch_sno }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/on_followup.gif') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                            <span
                                                                                                class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup Count"
                                                                                                style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                            <span
                                                                                                class="position-absolute animation-blink top-100 start-100 translate-middle badge badge-center rounded-pill border bg-danger text-white ms-1"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup Pending">!</span>
                                                                                        </a>
                                                                                    </div>
                                                                                @elseif($category->appointment_status == 4 && $category->status !== 4 && $category->status !== 10)
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_again_follow_up_lead_schedule"
                                                                                            onclick="openResheduleModalAgain('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}', '{{ $category->sch_sno }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                            <span
                                                                                                class="position-absolute top-0 start-100 translate-middle badge badge-center rounded-pill border text-black ms-1"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Followup Count"
                                                                                                style="background-color: #10ff00 !important;">{{ $category->total_appointments }}</span>
                                                                                        </a>
                                                                                    </div>
                                                                                @elseif($category->status !== 5 && $category->status !== 4 && $category->status !== 10)
                                                                                    <div class="avatar avatar-sm me-2">
                                                                                        <a href="javascript:;"
                                                                                            class="dropdown-item"
                                                                                            data-bs-toggle="modal"
                                                                                            data-bs-target="#kt_modal_follow_up_lead"
                                                                                            onclick="followupSchedule('{{ $category->sno }}','{{ trim($category->lead_name) }}','{{ $category->lead_mobile }}')">
                                                                                            <div class="border border-gray-500i rounded"
                                                                                                data-bs-toggle="tooltip"
                                                                                                data-bs-placement="bottom"
                                                                                                title="Not Yet Followed">
                                                                                                <img src="{{ asset('assets/phdizone_images/lead/followup.png') }}"
                                                                                                    alt="Premium Potential Icon"
                                                                                                    class="w-30px h-30px text-black fw-bold">
                                                                                            </div>
                                                                                        </a>
                                                                                    </div>
                                                                                @elseif($category->status == 5)
                                                                                @endif
                                                                            @endif
                                                                        </div>
                                                                    @else
                                                                        -
                                                                    @endif
                                                                @endif
                                                            </td>

                                                            @if (auth()->user()->hasPermission($module_name, 'Call Summary', $menu_name))
                                                                <td>
                                                                    @if (auth()->user()->hasPermission($module_name, 'Call Summary', $menu_name))
                                                                        @if ($category->outgoing_count == $category->total_appointments && $category->status != 4)
                                                                            <a href="javascript:;"
                                                                                class="btn btn-icon btn-sm"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_succ_sum"
                                                                                onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','The number of outgoing calls matches the follow-ups', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                                    enable-background="new 0 0 500 500"
                                                                                    viewBox="0 0 500 500"
                                                                                    id="hand-draw-white-check-mark-on-green-circle"
                                                                                    style="width:76%!important">
                                                                                    <rect id="Layer_1" width="500"
                                                                                        height="500" fill="#fff0f0"
                                                                                        display="none"></rect>
                                                                                    <g id="Layer_2">
                                                                                        <circle cx="236.5"
                                                                                            cy="250" r="200"
                                                                                            fill="#39ba77"></circle>
                                                                                        <path fill="#39ba77"
                                                                                            d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                                                    c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                                                    c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                                                    c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                                                    c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                        </path>
                                                                                        <path fill="#fff"
                                                                                            d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                                                    c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                                                    c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                        </path>
                                                                                    </g>
                                                                                </svg>
                                                                            </a>
                                                                        @elseif(
                                                                            $category->outgoing_count == $category->total_appointments ||
                                                                                ($category->total_appointments >= 5 && $category->status != 4))
                                                                            <a href="javascript:;"
                                                                                class="btn btn-icon btn-sm"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_succ_sum"
                                                                                onclick="successSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed!', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                                    enable-background="new 0 0 500 500"
                                                                                    viewBox="0 0 500 500"
                                                                                    id="hand-draw-white-check-mark-on-green-circle"
                                                                                    style="width:76%!important">
                                                                                    <rect id="Layer_1" width="500"
                                                                                        height="500" fill="#fff0f0"
                                                                                        display="none"></rect>
                                                                                    <g id="Layer_2">
                                                                                        <circle cx="236.5"
                                                                                            cy="250" r="200"
                                                                                            fill="#39ba77"></circle>
                                                                                        <path fill="#39ba77"
                                                                                            d="M220.8,379.9c-7.9-0.4-28.3-4.9-48.3-39.7l-0.2-0.4c-1.3-2.4-32.6-59.8-53-102.2l-0.6-1.3l-0.4-1.3
                                                                                                                                                        c-4-12.6-5.3-37.3,15.5-49.9c6.5-3.9,13.8-5.8,21.2-5.5c19.5,0.9,32.8,16.4,35.3,19.4l0.3,0.4l26.7,37.1
                                                                                                                                                        c24.6-43.5,78.6-124.3,165.2-176.5c3.2-2,17-9.9,34.4-9.1c13.7,0.6,25.9,6.5,35.4,17.1c3.3,3.5,12.7,15.3,11.1,33.8
                                                                                                                                                        c-1.8,20.9-17.1,41.3-45.5,60.6l-0.2,0.1c-0.6,0.4-66.6,44.8-117,117.9c-10.9,15.8-21.3,34.1-31.7,55.9
                                                                                                                                                        c-14.3,29.7-29.6,44-47,43.8l-0.2,0L220.8,379.9z">
                                                                                        </path>
                                                                                        <path fill="#fff"
                                                                                            d="M220.1,274.6c0,0,56.1-127.3,172.9-197.6c0,0,26-16.6,44.6,4.5c0,0,26.2,25.4-30.9,64.3
                                                                                                                                                        c0,0-69,45.8-122.4,123.2c-12.8,18.5-23.6,38.3-33.3,58.6c-5.8,12.2-17.5,32.9-29,32.4c0,0-14.8,0.4-32.1-29.7
                                                                                                                                                        c0,0-32.1-58.9-52.6-101.3c0,0-6-19,6.8-26.8c15.5-9.4,30.6,9.4,30.6,9.4L220.1,274.6z">
                                                                                        </path>
                                                                                    </g>
                                                                                </svg>
                                                                            </a>
                                                                            {{-- Outgoing calls and follow-ups are in sync. However, follow-ups are higher than expected. Please review if needed! --}}
                                                                        @elseif($category->outgoing_count != $category->total_appointments && $category->status != 4)
                                                                            <a href="javascript:;"
                                                                                class="btn btn-icon btn-sm"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_fail_sum"
                                                                                onclick="failSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}', 'Outgoing calls and follow-ups are mismatched. Please review the call and follow-up details', '{{ $category->total_appointments }}', '{{ $category->outgoing_count }}')">
                                                                                {{-- data-bs-toggle="modal" data-bs-target="#kt_modal_lead_wallet" onclick="leadWallet('{{ $category->sno }}','{{ $category->lead_name }}', '{{ $category->created_by }}')"> --}}
                                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                                    enable-background="new 0 0 500 500"
                                                                                    viewBox="0 0 500 500"
                                                                                    id="hand-draw-white-cross-mark-on-red-circle"
                                                                                    style="width:76%!important">
                                                                                    <rect id="Layer_1" width="500"
                                                                                        height="500" fill="#fff0f0"
                                                                                        display="none"></rect>
                                                                                    <g id="Layer_2">
                                                                                        <circle cx="250"
                                                                                            cy="250" r="200"
                                                                                            fill="#f32f45"></circle>
                                                                                        <path fill="#f32f45"
                                                                                            d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                                                                                                            l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                                                                                                            c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                                                                                                            c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                                                                                                            c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                                                                                                            c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                                                                                                            C345.6,381.2,345.6,381.2,345.6,381.2z">
                                                                                        </path>
                                                                                        <path fill="#fff"
                                                                                            d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                                                                                                            c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                                                                                                            c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                                                                                                            c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                                        </path>
                                                                                    </g>
                                                                                </svg>
                                                                            </a>
                                                                        @endif
                                                                        @php
                                                                            $currentDate = \Carbon\Carbon::now();
                                                                            $registeredDate = \Carbon\Carbon::parse(
                                                                                $category->registered_date,
                                                                            );
                                                                            $diffInDays = $registeredDate->diffInDays(
                                                                                $currentDate,
                                                                            );

                                                                            $expectedOutgoingCount = 0;
                                                                            if ($diffInDays >= 15) {
                                                                                $expectedOutgoingCount = 5;
                                                                            } elseif ($diffInDays >= 7) {
                                                                                $expectedOutgoingCount = 4;
                                                                            } elseif ($diffInDays >= 3) {
                                                                                $expectedOutgoingCount = 3;
                                                                            } elseif ($diffInDays >= 2) {
                                                                                $expectedOutgoingCount = 2;
                                                                            } elseif ($diffInDays >= 1) {
                                                                                $expectedOutgoingCount = 1;
                                                                            }
                                                                        @endphp
                                                                        @if ($category->outgoing_count != $expectedOutgoingCount && $category->status != 4)
                                                                            <a href="javascript:;"
                                                                                class="btn btn-icon btn-sm animate__animated animate__pulse animate__infinite"
                                                                                data-bs-toggle="modal"
                                                                                data-bs-target="#kt_modal_lead_danger_sum"
                                                                                onclick="dangerSummary('{{ $category->lead_name }}', '{{ $category->lead_mobile }}','{{ $diffInDays }}', '{{ $category->outgoing_count }}', '{{ $expectedOutgoingCount }}', '{{ $category->total_appointments }}')">
                                                                                {{-- Insert your SVG or button content here --}}
                                                                                <svg xmlns="http://www.w3.org/2000/svg"
                                                                                    viewBox="0 0 33.5 31.25"
                                                                                    id="ExclamationSign"
                                                                                    style="width:76%!important">
                                                                                    <defs>
                                                                                        <linearGradient id="a"
                                                                                            x1="27.59" x2="8.53"
                                                                                            y1="6.27" y2="33.97"
                                                                                            gradientUnits="userSpaceOnUse">
                                                                                            <stop offset="0"
                                                                                                stop-color="#ff8383">
                                                                                            </stop>
                                                                                            <stop offset="1"
                                                                                                stop-color="#fa1818">
                                                                                            </stop>
                                                                                        </linearGradient>
                                                                                    </defs>
                                                                                    <g fill="#ef1818">
                                                                                        <path fill="url(#a)"
                                                                                            d="m16.75,31.25c-7.48,0-11.22,0-13.38-1.57C1.49,28.31.27,26.2.03,23.88c-.28-2.66,1.59-5.9,5.33-12.37C9.1,5.04,10.97,1.8,13.41.71c2.13-.95,4.56-.95,6.69,0,2.44,1.09,4.31,4.33,8.05,10.8,3.74,6.48,5.61,9.71,5.33,12.37-.25,2.32-1.46,4.42-3.35,5.79-2.16,1.57-5.9,1.57-13.38,1.57Z">
                                                                                        </path>
                                                                                        <line x1="16.75"
                                                                                            x2="16.75" y1="8.22"
                                                                                            y2="18.09" fill="none"
                                                                                            stroke="#ffffff"
                                                                                            stroke-linecap="round"
                                                                                            stroke-width="3"></line>
                                                                                        <path fill="#ffffff"
                                                                                            d="m18.4,23.02c0,.91-.74,1.64-1.64,1.64s-1.64-.74-1.64-1.64.74-1.64,1.64-1.64,1.64.74,1.64,1.64Z">
                                                                                        </path>
                                                                                    </g>
                                                                                </svg>
                                                                            </a>
                                                                        @endif
                                                                    @endif
                                                                </td>
                                                            @endif
                                                        </tr>
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-4">
                                        {{ $leads->appends(request()->except(['page', '_token']))->links() }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Confirmation Modal -->
    <div class="modal fade" id="switchConfirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Confirm Action</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="switchMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No, Cancel</button>
                    <button type="button" class="btn btn-primary" id="confirmSwitchBtn">Yes, Confirm</button>
                </div>
            </div>
        </div>
    </div>



    <!--begin::Modal - Convert Drop to Lead-->
    <div class="modal fade" id="kt_modal_convert_potential_to_lead" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded p-2">
                <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content"><i class="mdi mdi-account-convert fs-1 animation-blink-smooth"></i>
                    </div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to convert this potential basket lead into your lead ?</div>
                <div class="text-center mt-2 mb-4">
                    <label class="text-success fw-bold fs-5 lead_trans_name"></label>
                </div>
                <form id="PotentialLeadForm_Lead" action="{{ route('trans_potential_to_lead') }}" method="POST"
                    novalidate autocomplete="off">
                    @csrf
                    <input type="hidden" id="lead_id_convert_lead" name="lead_id">
                    <div class="container" id="swal2-html-container" style="display: block;">
                        {{-- <div class="row mb-4 align-items-center d-flex justify-content-center" style="display: none !important;">
                                <div class="col-lg-10">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="assg_staff_add_lead" name="assg_staff_add" class="select3 form-select">
                                    </select>
                                    <div class="text-danger" id="assg_staff_add_lead_err"></div>
                                </div>
                            </div> --}}
                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-sm btn-success me-3" id="single_convert_btn_lead">Yes,
                                Convert</button>
                            <button type="reset" class="btn  btn-sm btn-secondary" data-bs-dismiss="modal">No,
                                Cancel</button>
                        </div>
                    </div>
                    <br>
                </form>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Convert Drop to Lead-->



    <!--begin::Modal - Appointment Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Schedule</h3>
                    </div>
                    <form id="followupForm" action="{{ route('daily_call_lead_followup') }}" method="POST" novalidate
                        autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_app">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_app"></div>
                            </div>

                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="lead_apt_sch" name="appointment_date"
                                        placeholder="Select Date" class="form-control" value="" />
                                </div>
                                <div class="text-danger" id="apt_date_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control common_time_class" placeholder="HH:MM"
                                    id="apt_time_followp" name="appointment_time" />
                                <div class="text-danger" id="apt_time_err"></div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="followupBtn" class="btn btn-primary"
                                    onclick="FollowupvalidateForm()">Schedule</button>
                            </div>
                        </div>
                    </form>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Appointment Schedule-->

    <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_date">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_time">
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_rep_count">00</span>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="1" name="progressed" onclick="progress_func('yes');" checked />
                                    <label class="form-check-label">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="2" name="progressed" onclick="progress_func('no');" />
                                    <label class="form-check-label">No</label>
                                </div>
                            </div>
                        </div>
                        <div id="message" name="message">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">
                                        Follow Through <span class="text-danger">*</span>
                                    </label>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="direct_call" value="1" checked />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="direct_call">Direct Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_chat" value="2" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_chat">Whatsapp Chat</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="whatsapp_call" value="3" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="whatsapp_call">Whatsapp Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through"
                                            id="email" value="4" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold"
                                            for="email">E-Mail</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                            class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="1" checked />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="-1" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="0" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="convo_message"
                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                        placeholder="Enter Conversation Message"></textarea>
                                    <div class="text-danger" id="convo_message_err"></div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div id="reason" name="reason" style="display: none !important;">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="app_reason" name="app_reason"
                                        onchange="toggleInputField_followup(this.value)">
                                        <option value="">Select Reason</option>
                                        @if (isset($followupReasonList))
                                            @foreach ($followupReasonList as $s_reason)
                                                <option value="{{ $s_reason->reason_name }}"
                                                    data-comments-check-followup="{{ $s_reason->comments_check }}">
                                                    {{ $s_reason->reason_name }}
                                                </option>
                                            @endforeach
                                        @endif
                                        <option value="1">Others</option>
                                    </select>
                                    <div class="text-danger" id="app_reason_select_err"></div>
                                    <div class="mt-4" id="followup_reason_div" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="followup_reason_text"
                                            id="followup_reason_text" value="" placeholder="Enter Reason">
                                        <div class="text-danger" id="followup_comments_text_err"></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                                class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date"
                                                class="form-control" value="" name="appointment_date" />

                                        </div>
                                        <div class="text-danger" id="re_app_date_err"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control common_time_class_new"
                                            placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                            value="" />
                                        <div class="text-danger" id="re_app_time_err"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2 active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                                data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                                aria-controls="accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="headingPopoutTwo">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#accordionPopoutTwo"
                                                aria-expanded="false" aria-controls="accordionPopoutTwo">
                                                <span class="text-black fw-semibold fs-6">Appointment History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="apptmnt_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutTwo" class="accordion-collapse collapse"
                                            aria-labelledby="headingPopoutTwo" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-100px">Date / Time</th>
                                                                    <th class="min-w-100px">Category</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                    <th class="min-w-100px">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="appointmentLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id='rescheduleBtn' class="btn btn-primary"
                                    onclick="updateReshedule()">Submit
                                    Report</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->


    <!--begin::Modal - Again Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_again_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">New Followup</h3>
                    </div>
                    <form action="{{ route('add_appointment_pb_daily') }}" id="newfollowupForm" method="POST"
                        autocomplete="off">
                        @csrf
                        <input type="hidden" name="lead_id" id="lead_id_again">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_app_again">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_app_again">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="app_date_again" name="appointment_date"
                                        placeholder="Select Date" class="form-control cus_date_doj"
                                        value="{{ date('d-M-Y') }}" />
                                </div>
                                <div class="text-danger" id="app_date_again_err"></div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                                <input type="text" class="form-control app_new_time_class" placeholder="HH:MM"
                                    id="app_time_again" name="appointment_time" />
                                <div class="text-danger" id="app_time_again_err"></div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_count_again">0</span>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="again_flw_headingPopoutOne">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutOne"
                                                aria-expanded="false" aria-controls="again_flw_accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count_again">00</span>
                                            </button>
                                        </h2>
                                        <div id="again_flw_accordionPopoutOne" class="accordion-collapse collapse"
                                            aria-labelledby="again_flw_headingPopoutOne">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBodyAgain">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="again_flw_headingPopoutTwo">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#again_flw_accordionPopoutTwo"
                                                aria-expanded="false" aria-controls="again_flw_accordionPopoutTwo">
                                                <span class="text-black fw-semibold fs-6">Appointment History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="apptmnt_count_again">0</span>
                                            </button>
                                        </h2>
                                        <div id="again_flw_accordionPopoutTwo" class="accordion-collapse collapse"
                                            aria-labelledby="again_flw_headingPopoutTwo">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-100px">Date / Time</th>
                                                                    <th class="min-w-100px">Category</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                    <th class="min-w-100px">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="appointmentLeadIdsTableBodyAgain">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="newfollowupBtn" class="btn btn-primary"
                                    onclick="NewFollowupvalidateForm()">Schedule</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Again Followup Lead Schedule-->

    <!--begin::Modal - Success Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_succ_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="succ_lead_name"></label>
                            [<label id="succ_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_succ_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_succ_count"></span>
                            </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_succ_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Success Lead Call Summmary-->

    <!--begin::Modal - Fail Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_fail_sum" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary </h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="fail_lead_name"></label>
                            [<label id="fail_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_fail_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_fail_count"></span>
                            </label>
                        </div>
                        <div class="text-center mt-4">
                            <label id="lead_fail_msg" class="fw-bold fs-5 text-primary"></label>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Fail Lead Call Summmary-->

    <!--begin::Modal - Danger Lead Call Summmary-->
    <div class="modal fade" id="kt_modal_lead_danger_sum" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black">Lead Call Summary</h3>
                    </div>
                    <div class="row">
                        <div class="text-danger fw-semibold fs-5 d-flex align-items-center justify-content-center">
                            <label id="danger_lead_name"></label>
                            [<label id="danger_lead_mobile"></label>]
                        </div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <label class="fs-6 text-black me-2 fw-semibold">Outgoing Call Count
                                <span class="badge bg-info fs-5 text-white rounded" id="lead_danger_call_count"></span>
                            </label>
                            <label class="fs-6 text-black fw-semibold">Follow-ups Count
                                <span class="badge bg-success fs-5 text-white rounded" id="lead_danger_count"></span>
                            </label>
                        </div>
                        <!-- Properly aligned section -->
                        <div class="text-center mt-4">
                            <label class="fw-bold fs-5 text-primary bg-warning px-2" id="danger_lead_msg"></label>
                            <table class="table table-borderless text-primary fw-semibold fs-5 mx-auto"
                                style="width: auto;">
                                <tbody>
                                    <tr>
                                        <td class="text-end pe-3">Days since registration:</td>
                                        <td class="text-start"><label id="lead_danger_days"></label> days</td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Expected Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_expected"></label></td>
                                    </tr>
                                    <tr>
                                        <td class="text-end pe-3">Actual Outgoing Calls:</td>
                                        <td class="text-start"><label id="lead_danger_call_count_actual"></label></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Danger Lead Call Summmary-->


    <!-- Modal HTML -->
    <div class="modal fade" id="dailyCallHistoryModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Daily Call History</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <!-- Filter Section -->
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="staffFilter" class="form-label">Filter by Staff</label>
                            <select class="form-select" id="staffFilter">
                                <option value="">All Staff</option>
                            </select>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button class="btn btn-primary me-2" onclick="applyFilter()">Apply Filter</button>
                            <button class="btn btn-secondary" onclick="resetFilter()">Reset</button>
                        </div>
                    </div>

                    <!-- Records Info -->
                    <div class="row mb-2">
                        <div class="col-md-6">
                            <div id="recordsInfo" class="text-muted"></div>
                        </div>
                        <div class="col-md-6 text-end">
                            <select class="form-select form-select-sm d-inline-block w-auto" id="perPageSelect"
                                onchange="changePerPage(this.value)">
                                <option value="10">10 per page</option>
                                <option value="25">25 per page</option>
                                <option value="50">50 per page</option>
                                <option value="100">100 per page</option>
                            </select>
                        </div>
                    </div>

                    <!-- Table -->
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th style="min-width: 150px;">Sch.Date</th>
                                    <th style="min-width: 150px;">Lead</th>
                                    <th style="min-width: 120px;">Sales Person</th>
                                    <th style="min-width: 120px;">Assign Person</th>
                                    <th style="min-width: 130px;">Follow Up Status</th>
                                    <th style="min-width: 250px;">Conversion Message</th>
                                </tr>
                            </thead>
                            <tbody id="FollowUpHistoryTable">
                                <tr>
                                    <td colspan="5" class="text-center">Click the button to load data</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <nav aria-label="Page navigation">
                        <ul class="pagination justify-content-center" id="pagination">
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>



    <div class="modal fade" id="dailyCallModal" tabindex="-1"aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Daily Call Setup</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <table class="table table-bordered align-middle">
                        <thead>
                            <tr class="table bg-primary">
                                <th>Sales Staff</th>
                                <th class="text-center">Check</th>
                                <th class="text-center">Call Count</th>
                            </tr>
                        </thead>
                        <tbody id="salesStaffTable">
                            <!-- AJAX DATA LOAD HERE -->
                        </tbody>
                    </table>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary" id="updateDailyCall">Update</button>
                </div>

            </div>
        </div>
    </div>

    <!--begin::Modal -  Call Log-->
    <div class="modal fade" id="kt_modal_call_log" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-5 px-5 px-xl-10">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center mb-4 text-black">
                            <span><span id="call_lead_name">Priya</span> [ </span>
                            <span class="text-info" id="call_lead_mobile">+91 9876543210</span>
                            <span>] Call History</span>
                        </h3>
                    </div>
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="nav-align-top mb-2">
                                <ul class="nav nav-pills flex-nowrap call_navbar" role="tablist">

                                </ul>
                            </div>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane call_log fade show active" id="tab_incoming_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Incoming Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_outgoing_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Outgoing Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_missed_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Missed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="tab-pane fade call_log" id="tab_dailled_calls" role="tabpanel">
                                <div class="col-lg-12 mb-1">
                                    <label class="fw-bold fs-5 text-black">Dialed Calls</label>
                                </div>
                                <div class="col-lg-12">
                                    <table
                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                        <thead>
                                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                                <th class="min-w-150px">Communicator</th>
                                                <th class="min-w-100px">Call Date</th>
                                                <th class="min-w-100px">Start Time</th>
                                                <th class="min-w-100px">End Time</th>
                                                <th class="min-w-100px">Duration</th>
                                                <th class="min-w-100px">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-black fw-semibold fs-7">
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal -  Call Log-->

    <script>
        document.getElementById('dailyCallBtn').addEventListener('click', function() {

            var modal = new bootstrap.Modal(document.getElementById('dailyCallModal'));
            modal.show();

            fetch("{{ route('sales_staff_list') }}")
                .then(response => response.json())
                .then(data => {

                    let html = '';

                    data.forEach(function(staff) {

                        let imagePath = staff.staff_image ?
                            '/staff_images/' + staff.staff_image :
                            '/assets/phdizone_images/Super-Admin.png';

                        let isChecked = staff.call_check == 1 ? 'checked' : '';
                        let isDisabled = staff.call_check == 1 ? '' : 'disabled';
                        let callValue = staff.call_check == 1 ? staff.call_count : '';

                        html += `
                      <tr>
                          <td>
                                <div class="d-flex align-items-center">
                                    <img src="${imagePath}"
                                        class="rounded-circle me-2"
                                        width="40" height="40">
                                    <div class="d-flex flex-column">
                                        <div>${staff.staff_name}</div>
                                        <div class="badge bg-info">${staff.job_position_name}</div>
                                        <div class="text-dark fs-8 mt-1" title="Date of joining">D.O.J:${formatDateTransfer(staff.date_of_joining)}</div>
                                    </div>
                                </div>
                            </td>
 
                          <td class="text-center">
                              <input class="form-check-input staff-check"
                                    type="checkbox"
                                    data-id="${staff.sno}"
                                    ${isChecked}>
                          </td>
 
                          <td class="text-center">
                              <input type="number"
                                    class="form-control form-control-sm text-center call-input"
                                    data-id="${staff.sno}"
                                    min="0"
                                    value="${callValue}"
                                    ${isDisabled}
                                    style="width:80px; display:inline-block;">
                          </td>
                      </tr>
                      `;
                    });

                    document.getElementById('salesStaffTable').innerHTML = html;

                });
        });

        document.addEventListener('change', function(e) {
            if (e.target.classList.contains('staff-check')) {

                let staffId = e.target.getAttribute('data-id');
                let inputBox = document.querySelector('.call-input[data-id="' + staffId + '"]');

                if (e.target.checked) {
                    inputBox.disabled = false;
                    inputBox.focus();
                } else {
                    inputBox.disabled = true;
                    inputBox.value = '';
                }
            }
        });

        document.getElementById('updateDailyCall').addEventListener('click', function() {

            let payload = [];

            document.querySelectorAll('#salesStaffTable tr').forEach(function(row) {

                let checkbox = row.querySelector('.staff-check');
                let input = row.querySelector('.call-input');

                if (checkbox) {

                    payload.push({
                        staff_id: checkbox.getAttribute('data-id'),
                        checked: checkbox.checked ? 1 : 0,
                        call_count: input.value ? input.value : 0
                    });

                }
            });

            fetch("{{ route('sales_staff_update') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "{{ csrf_token() }}"
                    },
                    body: JSON.stringify({
                        staff_data: payload
                    })
                })
                .then(response => response.json())
                .then(res => {
                    alert(res.message);
                    location.reload();
                });

        });
    </script>


    <!-- ------------------------------------------------------------------------------------------------------------------------- -->
    <!-- end Bootstrap old Modal for showing messages -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        .animation-blink-smooth {
            animation: smoothBlink 1.5s ease-in-out infinite;
        }

        @keyframes smoothBlink {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.3;
            }
        }
    </style>
    <style>
        .source-label {
            position: relative;
            /* Ensure the label is positioned relative for absolute positioning of ::before */
            display: inline-block;
        }

        .source-label::before {
            /*content: '\1F31F'; */
            content: '\2728';
            /* ðŸŒŸ Sparkles */
            position: absolute;
            top: -12px;
            /* Move it further up */
            left: 90%;
            /* Center it horizontally */
            transform: translateX(-50%);
            /* Adjust horizontal alignment */
            font-size: 1rem;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }


        .jd-blue {
            color: #1976d2;
            /* Justdial Blue */
            font-weight: bold;
        }

        .jd-orange {
            color: #f16522;
            /* Justdial Orange */
            font-weight: bold;
        }

        .jd-blue,
        .jd-orange {
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
        }

        .cc-purple {
            color: #5c2d91;
            /* CloudCall Purple */
            font-weight: bold;
        }

        .cc-orange {
            color: #f58220;
            /* CloudCall Orange */
            font-weight: bold;
        }

        /* Cloud Icon Styling */
        .cc-icon {
            color: #5c2d91;
            /* Matching CloudCall Purple */
            margin-right: 5px;
        }


        .ct-black {
            color: #000000;
            /* Call in Black */
            font-weight: bold;
        }

        .ct-orange {
            background-color: #f16522;
            /* Justdial Orange */
            color: #ffffff;
            /* White text inside */
            /*font-weight: bold;*/
            padding: 2px 6px;
            border-radius: 4px;
        }

        /* Call Icon Styling */
        .ct-icon {
            color: #000000;
            /* Black Call Icon */
            font-size: 14px;
            margin-left: 3px;
        }


        /* Loading Dots */
        .loading-dots {
            display: flex;
            gap: 8px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        /* Individual Balls */
        .loading-dots span {
            width: 15px;
            height: 15px;
            background-color: rgb(32, 32, 34);
            border-radius: 50%;
            opacity: 0;
            animation: fadeInOut 1.5s infinite ease-in-out;
        }

        /* Add More Balls with Delay */
        .loading-dots span:nth-child(1) {
            animation-delay: 0s;
        }

        .loading-dots span:nth-child(2) {
            animation-delay: 0.2s;
        }

        .loading-dots span:nth-child(3) {
            animation-delay: 0.4s;
        }

        .loading-dots span:nth-child(4) {
            animation-delay: 0.6s;
        }

        .loading-dots span:nth-child(5) {
            animation-delay: 0.8s;
        }

        .loading-dots span:nth-child(6) {
            animation-delay: 1s;
        }

        /* Animation */
        @keyframes fadeInOut {

            0%,
            100% {
                opacity: 0;
                transform: scale(0.8);
            }

            50% {
                opacity: 1;
                transform: scale(1);
            }
        }


        /* Stylish Fade Effect Box */
        .fade-effect {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, #dbdd47, #ccce43);
            color: rgb(255, 255, 255);
            font-weight: bold;
            font-size: 18px;
            text-align: center;
            line-height: 60px;
            border-radius: 10px;
            text-shadow: 0 0 5px rgba(137, 92, 219, 0.5),
                0 0 10px rgba(137, 92, 219, 0.5),
                0 0 20px rgba(137, 92, 219, 0.5);
            /* Intense Neon Glow */
            box-shadow: 0 0 15px rgba(137, 92, 219, 0.5),
                0 0 25px rgba(16, 168, 185, 0.8),
                0 0 35px rgba(137, 92, 219, 0.5);
            /* Red & Black Glow */
            letter-spacing: 2px;
            opacity: 0;
            /* Initially hidden */
            transition: all 0.5s ease-in-out;
            animation: shimmer 3s infinite alternate, runText 12s linear infinite, fadeEffect 3s infinite alternate;
        }

        /* Hover Glow Effect */
        .fade-effect:hover {
            box-shadow: 0 0 15px rgba(135, 0, 0, 0.7),
                0 0 25px rgba(25, 10, 5, 0.8),
                0 0 35px rgba(135, 0, 0, 0.6);
            /* Red & Black Glow */
            transform: scale(1.05);
            /* Slight Zoom */
        }

        /* Running Text Animation */
        @keyframes runText {
            from {
                left: 100%;
            }

            to {
                left: -100%;
            }
        }

        /* Fade Effect Animation */
        @keyframes fadeEffect {
            0% {
                opacity: 0.3;
            }

            100% {
                opacity: 1;
            }
        }

        @keyframes shimmer {
            0% {
                background-position: -200%;
            }

            100% {
                background-position: 200%;
            }
        }

        /* Blinking text animation */
        .blink {
            /*animation: blinker 1.5s linear infinite;*/
            /* font-weight: bold; */
            color: white;
            /* White text for better contrast */
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

        /* Cute background and style for the 'New!' label */
        .new-label {
            background-color: #ff7eb9;
            /* Soft pink color */
            padding: 0px 8px;
            border-radius: 12px;
            /* Rounded corners */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            /* Soft shadow for depth */
            font-size: 0.3rem;
            /* Slightly larger text */
            text-transform: uppercase;
            position: relative;
        }

        /* Adding a cute icon or star effect */
        .new-label::before {
            content: 'ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã‚Â¦ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã¢â‚¬Å“ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â¨';
            /* You can replace this with any icon or emoji */
            position: absolute;
            top: -8px;
            right: -10px;
            /* Changed from left to right */
            font-size: 0.9rem;
            animation: bounce 2s infinite;
        }


        /* Bounce animation for cute effect */
        @keyframes bounce {

            0%,
            20%,
            50%,
            80%,
            100% {
                transform: translateY(0);
            }

            40% {
                transform: translateY(-8px);
            }

            60% {
                transform: translateY(-4px);
            }
        }
    </style>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .tags-inline.tagify__dropdown {
            z-index: 9999 !important;
            /* Ensure it is higher than the modal's z-index */
        }
    </style>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>
    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-6 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-6 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    {{-- verified drop --}}
    <!-- lead transfer Log -->
    <script>
        function formatDateTransfer(dateString) {
            let date = new Date(dateString);
            let day = String(date.getDate()).padStart(2, '0');
            let monthIndex = date.getMonth();
            let year = date.getFullYear();

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex];

            return `${day}-${month}-${year}`;
        }
    </script>
    <!-- call history -->
    <script>
        function openCallHistoryModal(leadId, status, name = '', mobile = '', incomingCount, outgoingCount, missedCount,
            dialedCount) {
            $('#call_lead_name').text(name);
            $('#call_lead_mobile').text(mobile);

            let tabHtml = `
                            <li class="nav-item me-2 mb-2">
                                <a href="#tab_incoming_calls" class="nav-link call_log_link text-capitalize active" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Incoming', '#tab_incoming_calls')">
                                    <img src="/assets/phdizone_images/calls/incoming_call.ico" class="w-20px h-25px fw-bold me-2"> Incoming Calls
                                    <span class="badge bg-label-info fs-6 rounded ms-2">${incomingCount >= 10 ? incomingCount : '0'+incomingCount }</span>
                                </a>
                            </li>
                            <li class="nav-item me-2 mb-2">
                                <a href="#tab_outgoing_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Outgoing', '#tab_outgoing_calls')">
                                    <img src="/assets/phdizone_images/calls/outgoing_call.ico" class="w-20px h-25px fw-bold me-2"> Outgoing Calls
                                    <span class="badge bg-label-info fs-6 rounded ms-2">${outgoingCount >= 10 ? outgoingCount : '0'+outgoingCount }</span>
                                </a>
                            </li>
                            <li class="nav-item me-2 mb-2">
                                <a href="#tab_missed_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Missed & Rejected', '#tab_missed_calls')">
                                    <img src="/assets/phdizone_images/calls/reject_call.ico" class="w-20px h-25px fw-bold me-2"> Missed & Rejected
                                    <span class="badge bg-label-info fs-6 rounded ms-2">${missedCount >= 10 ? missedCount : '0'+missedCount }</span>
                                </a>
                            </li>
                            <li class="nav-item me-2 mb-2">
                                <a href="#tab_dailled_calls" class="nav-link call_log_link text-capitalize" style="border: 2px solid #eb6315" data-bs-toggle="tab" role="tab" onclick="callHistoryTable(${leadId}, 'Dialed', '#tab_dailled_calls')">
                                    <img src="/assets/phdizone_images/calls/dialed_call.ico" class="w-20px h-25px fw-bold me-2"> Dialed Calls
                                    <span class="badge bg-label-info fs-6 rounded ms-2">${dialedCount >= 10 ? dialedCount : '0'+dialedCount }</span>
                                </a>
                            </li>
                        `;

            $(".call_navbar").html(tabHtml);

            // Clear existing table content to avoid leftover data
            $('#tab_incoming_calls tbody').html('');
            $('#tab_outgoing_calls tbody').html('');
            $('#tab_missed_calls tbody').html('');
            $('#tab_dailled_calls tbody').html('');

            // Reset tab to default (Incoming)
            $('.call_log_link').removeClass('active');
            $('.call_log_link[href="#tab_incoming_calls"]').addClass('active');

            // Optionally hide all tabs and show only active
            $('.call_log').removeClass('active show');
            $('#tab_incoming_calls').addClass('active show');

            // Show modal and load default tab
            $('#kt_modal_call_log').modal('show');
            callHistoryTable(leadId, 'Incoming', '#tab_incoming_calls');
        }

        function callHistoryTable(leadId, status, tabSelector) {

            const $tbody = $(tabSelector).find("tbody");

            $.ajax({
                url: "{{ route('get_call_history') }}",
                type: "GET",
                data: {
                    lead_id: leadId,
                    status: status
                },
                beforeSend: function() {
                    $tbody.html('<tr><td colspan="6" class="text-center">Loading...</td></tr>');
                },
                success: function(response) {
                    let rows = '';

                    if (response.calls.length > 0) {
                        response.calls.forEach(call => {
                            let img = "outgoing_call.ico";
                            let statusText = "Outgoing Call";
                            let bgColor = "";
                            let statusColor = "#7594E8";

                            switch (call.call_status) {
                                case 0:
                                    img = "outgoing_call.ico";
                                    statusText = "Outgoing Call";
                                    statusColor = "#7594E8";
                                    break;
                                case 1:
                                    img = "incoming_call.ico";
                                    statusText = "Incoming Call";
                                    statusColor = "#FFBF66";
                                    break;
                                case 2:
                                    img = "missed_call.ico";
                                    bgColor = "#ecc093";
                                    statusText = "Missed Call";
                                    statusColor = "#FFA500";
                                    break;
                                case 3:
                                    img = "reject_call.ico";
                                    bgColor = "#ff00004f";
                                    statusText = "Rejected Call";
                                    statusColor = "#FF7979";
                                    break;
                                default:
                                    img = "dialed_call.ico";
                                    statusText = "Dialed Call";
                                    statusColor = "#7594E8";
                                    break;
                            }

                            rows += `
                        <tr style="background: ${bgColor}">
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-35px border bg-primary rounded px-1 py-1 me-2">
                                        <img src="{{ asset('assets/phdizone_images/calls/') }}/${img}" class="w-20px h-20px" />
                                    </div>
                                    <div>
                                        <label class="fs-7 me-1">${call.staff_name}</label>
                                        <div class="text-primary fs-8">${call.staff_phone_no}</div>
                                    </div>
                                </div>
                            </td>
                            <td>${call.call_start_date ? formatDateTransfer(call.call_start_date) : '-'}</td>
                            <td><label class="text-info fs-7 fw-semibold">${call.call_start_time}</label></td>
                            <td><label class="text-danger fs-7 fw-semibold">${call.call_end_time || '-'}</label></td>
                            <td><label class="badge bg-warning text-black fs-7 fw-bold">${call.call_duration || '-'}</label></td>
                            <td><label class="badge rounded text-white fs-7 fw-semibold" style="background-color: ${statusColor}">${statusText}</label></td>
                        </tr>
                    `;
                        });
                    } else {
                        rows = '<tr><td colspan="6" class="text-center">No call history found</td></tr>';
                    }

                    $tbody.html(rows);
                }
            });
        }
    </script>
    <!--followup script-->
    <script>
        function followupSchedule(leadId, name, phone) {
            $('#lead_id').val(leadId); // Set the lead ID in the hidden input field
            $('#lead_name_app').html(name);
            $('#lead_phone_app').html(phone);
            $('#kt_modal_follow_up_lead').modal('show'); // Show the modal
        }

        function FollowupvalidateForm() {
            var err = 0;

            // Validate knowledge Name
            var lead_apt_sch = document.getElementById("lead_apt_sch").value.trim();
            if (lead_apt_sch === "") {
                document.getElementById('apt_date_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('lead_apt_sch').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('lead_apt_sch').classList.remove('error_msg');
                document.getElementById('apt_date_err').innerHTML = '';
            }
            // Validate knowledge Name
            var apt_time_followp = document.getElementById("apt_time_followp").value.trim();
            if (apt_time_followp === "") {
                document.getElementById('apt_time_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('apt_time_followp').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('apt_time_followp').classList.remove('error_msg');
                document.getElementById('apt_time_err').innerHTML = '';
            }
            $('#followupBtn').prop('disabled', true);

            if (err === 0) {
                $('#followupForm').submit();
                $('#followupBtn').prop('disabled', true);
            } else {
                $('#followupBtn').prop('disabled', false);
            }
        }

        function NewFollowupvalidateForm() {
            var err = 0;
            $('#newfollowupBtn').prop('disabled', true);
            // Validate knowledge Name
            var app_date_again = document.getElementById("app_date_again").value.trim();
            if (app_date_again === "") {
                document.getElementById('app_date_again_err').innerHTML = 'Appointment Date is required...!';
                document.getElementById('app_date_again').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('app_date_again').classList.remove('error_msg');
                document.getElementById('app_date_again_err').innerHTML = '';
            }
            // Validate knowledge Name
            var app_time_again = document.getElementById("app_time_again").value.trim();
            if (app_time_again === "") {
                document.getElementById('app_time_again_err').innerHTML = 'Appointment Time is required...!';
                document.getElementById('app_time_again').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('app_time_again').classList.remove('error_msg');
                document.getElementById('app_time_again_err').innerHTML = '';
            }
            if (err === 0) {
                $('#newfollowupBtn').prop('disabled', true);
                $('#newfollowupForm').submit();
            } else {
                $('#newfollowupBtn').prop('disabled', false);
            }
        }
        // Add event listeners to clear error messages on input
        document.getElementById('lead_apt_sch').addEventListener('input', function() {
            document.getElementById('apt_date_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
        // Add event listeners to clear error messages on input
        document.getElementById('apt_time_followp').addEventListener('input', function() {
            document.getElementById('apt_time_err').innerHTML = '';
            this.classList.remove('error_msg');
        });
    </script>
    <script>
        let reshedule_id;
        let schno;

        function openResheduleModal(categoryId, name, mobile, sch_no) {
            $('#lead_name_reop').html(name);
            $('#lead_phone_reop').html(mobile);
            reshedule_id = categoryId;
            schno = sch_no;
            // Function to format date to '10-Jun-2024'
            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/edit_appointment/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;



                        document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                        document.getElementById('app_time').innerText = lead.appointment_time;
                        $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                        // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                        //   console.log('Appointment Count:', data.data.appointmentCount);
                        $('#app_count').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBody');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                const FollowThough = [
                                    'Unknown', // 0
                                    'Direct Call', // 1
                                    'Whatsapp Chat', // 2
                                    'Whatsapp Call', // 3
                                    'E-Mail', // 4
                                ];
                                const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Followup Date">${formatTime(category.appointment_time)}</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="text-black fw-semibold fs-7 mb-1">${category.staff_name}</div>
                                        <div> <span class="bg-info text-white text-center p-1 rounded" title="Follow though">${FollowThough[category.follow_through ?? 0]}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-black fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="${category.convo_message ?? '-'}">
                                        ${category.convo_message ?? '-'}
                                    </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ?? '-'}"> ${category.reason ?? '-'}</div>
                                </td>
                            </tr>`;

                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                       
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });

            fetch(`/appointment_history/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        //   console.log(data)
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        $('#apptmnt_count').html(data.data.appointmentCount);
                        const historicalTableBodyAppt = document.getElementById('appointmentLeadIdsTableBody');
                        historicalTableBodyAppt.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];

                                const row = `<tr>
                                    <td>
                                        <div class="mb-0 align-items-center">
                                            <label>
                                                <span class="fs-7 me-2">${index + 1}</span>
                                            </label>
                                        </div>
                                    </td>
                                     <td>
                                        <label
                                            class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                        <div class="d-block">
                                            <label class="text-dark fs-8"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                        </div>
                                    </td>
                                    <td>
                                        <label
                                            class="text-black fw-semibold fs-7">${category.appointment_category}</label>
                                    </td>
                                    <td>
                                    
                                        <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_reason || '-'}">
                                             ${category.appointment_reason || '-'}</div>
                                    </td>
                                    <td>
                                      <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                             ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                    </td>
                                    <td>
                                      ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                            category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                            category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                            '<span>-</span>'}
                                    </td>
                                    
                                </tr>`;

                                historicalTableBodyAppt.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBodyAppt.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });


        }

        function updateReshedule() {
            const resheduleid = reshedule_id;
            const schsno = schno;
            const progressed = document.querySelector('input[name="progressed"]:checked').value;

            // Initialize variables
            let app_score = null;
            let follow_through = null;
            let convo_message = null;
            let hot_lead = null;
            let reason = null;
            let appointment_date = null;
            let appointment_time = null;
            var err = 0;
            if (progressed == 1) {
                app_score = document.querySelector('input[name="app_score"]:checked').value;
                follow_through = document.querySelector('input[name="follow_through"]:checked').value;
                convo_message = document.getElementById('convo_message').value;
                if (convo_message == '') {
                    $('#convo_message_err').text('Conversation Message is Required')
                    err++
                } else {
                    $('#convo_message_err').text('');
                }
                // hot_lead = document.getElementById('hot_lead').value;
            } else {
                reason = document.getElementById('app_reason').value;
                var other_reason = document.getElementById('followup_reason_text').value;
                appointment_date = document.getElementById('re_app_date').value;
                appointment_time = document.getElementById('re_app_time').value;
                if (reason == '') {
                    $('#app_reason_select_err').text('Reason is Required');
                    err++;
                } else {
                    $('#app_reason_select_err').text('');
                }
                if (reason == 1) {
                    if (other_reason == "") {
                        $('#followup_comments_text_err').text('Other Reason is Required');
                        err++;
                    } else {
                        reason = other_reason;
                    }
                }
                if (appointment_date == '') {
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                } else {
                    $('#re_app_date_err').text('');
                }

                if (appointment_time == '') {
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                } else {
                    $('#re_app_time_err').text('');
                }

                // appointment_date = document.querySelector('input[name="appointment_date"]').value;
                // appointment_time = document.querySelector('input[name="appointment_time"]').value;
            }


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            // if(document.getElementById('hot_lead').checked){
            //   hot_lead=1;
            // }else{
            //   hot_lead=0;
            // }

            if (err == 0) {
                $('#rescheduleBtn').prop('disabled', true);
                fetch(`/add_appointment_daily_update/${resheduleid}`, {
                        method: 'post',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            schsno: schsno,
                            progressed: progressed,
                            app_score: app_score,
                            follow_through: follow_through,
                            convo_message: convo_message,
                            // hot_lead: hot_lead,
                            reason: reason,
                            appointment_date: appointment_date,
                            appointment_time: appointment_time,
                            pb: 1,
                        }),
                    })

                    .then(data => {
                        if (data.status === 200) {
                            toastr.success('Follow-up Updated successfully!');
                            $('#rescheduleBtn').prop('disabled', true);
                            location.reload();
                        } else {
                            toastr.error('Follow-up Failed to update!');
                            $('#rescheduleBtn').prop('disabled', false);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating category:', error);
                        $('#rescheduleBtn').prop('disabled', false);

                    });
            } else {
                $('#rescheduleBtn').prop('disabled', false);
            }

        }
        // new appointment
        let resheduleagain_id;

        function openResheduleModalAgain(categoryId, name, mobile) {
            $('#lead_name_app_again').html(name);
            $('#lead_phone_app_again').html(mobile);
            resheduleagain_id = categoryId;
            // Function to format date to '10-Jun-2024'
            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/edit_appointment/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;
                        document.getElementById('lead_id_again').value = lead.lead_id;
                        $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                        // document.getElementById('lead_id_again').value = formatDate(lead.lead_id);
                        // document.getElementById('app_time_again').value = lead.appointment_time;
                        // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                        // console.log('Appointment Count:', data.data.appointmentCount);
                        $('#app_count_again').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                if (category.app_score === 1) {
                                    var score =
                                        `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === -1) {
                                    var score =
                                        `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else if (category.app_score === 0) {
                                    var score =
                                        `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                } else {
                                    var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                                }
                                const FollowThough = [
                                    'Unknown', // 0
                                    'Direct Call', // 1
                                    'Whatsapp Chat', // 2
                                    'Whatsapp Call', // 3
                                    'E-Mail', // 4
                                ];
                                const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block text-dark fs-8"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="Last Followup Date">${formatTime(category.appointment_time)}</div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="text-black fw-semibold fs-7 mb-1">${category.staff_name}</div>
                                        <div> <span class="bg-info text-white text-center p-1 rounded" title="Follow though">${FollowThough[category.follow_through ?? 0]}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}
                                        </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ? category.reason : '-'}">${category.reason ? category.reason : '-'}
                                        </div>
                                </td>
                            </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                        $('[data-bs-toggle="tooltip"]').tooltip();


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                    $('[data-bs-toggle="tooltip"]').tooltip();
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });

            fetch(`/appointment_history/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        //   console.log(data)
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        $('#apptmnt_count_again').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('appointmentLeadIdsTableBodyAgain');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                const row = `<tr>
                                <td>${index + 1}</td>
                               <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="text-truncate max-w-100px" title="${category.appointment_category}">${category.appointment_category !== null ? category.appointment_category : '-'}</label>
                                </td>
                                 <td>
                                    
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_reason || '-'}">
                                         ${category.appointment_reason || '-'}</div>
                                </td>
                               <td>
                                  <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                         ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                </td>
                                <td>
                                  ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                        category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                        category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                        '<span>-</span>'}
                            </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                    $('[data-bs-toggle="tooltip"]').tooltip();
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });
        }

        function toggleInputField_followup(value) {
            var followupReasonDiv = document.getElementById('followup_reason_div');
            var followupReasonText = document.getElementById('followup_reason_text');
            // var followupCommentsDiv = document.getElementById('followup_comments_div');
            var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById(
                'app_reason').selectedIndex + 1) + ')');
            // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

            if (value == '1') {
                followupReasonDiv.style.display = 'block';
                followupReasonText.setAttribute('required', 'required');
            } else {
                followupReasonDiv.style.display = 'none';
                followupReasonText.removeAttribute('required');
            }

            // if (commentsCheck == '1') {
            //     followupCommentsDiv.style.display = 'block';
            // } else {
            //     followupCommentsDiv.style.display = 'none';
            // }
        }
    </script>

    <script>
        function successSummary(name, mobile, message, count, call_count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("succ_lead_name").innerText = name;
            document.getElementById("succ_lead_mobile").innerText = mobile;
            document.getElementById("lead_succ_msg").innerText = message;
            document.getElementById("lead_succ_count").innerHTML = formattedCount;
            document.getElementById("lead_succ_call_count").innerHTML = formattedCallCount;
        }

        function failSummary(name, mobile, message, count, call_count) {

            let formattedCount = count.toString().padStart(2, '0');
            let formattedCallCount = call_count.toString().padStart(2, '0');

            document.getElementById("fail_lead_name").innerText = name;
            document.getElementById("fail_lead_mobile").innerText = mobile;
            document.getElementById("lead_fail_msg").innerText = message;
            document.getElementById("lead_fail_count").innerHTML = formattedCount;
            document.getElementById("lead_fail_call_count").innerHTML = formattedCallCount;
        }

        function dangerSummary(name, mobile, daysDiff, expectedCount, outgoingCount, count) {
            let formattedCount = count.toString().padStart(2, '0');
            let formattedOutgoingCount = outgoingCount.toString().padStart(2, '0');
            let formattedExpectedCount = expectedCount.toString().padStart(2, '0');
            let message = `Outgoing calls are mismatched!`;

            document.getElementById("danger_lead_name").innerText = name;
            document.getElementById("danger_lead_mobile").innerText = mobile;
            document.getElementById("lead_danger_days").innerText = daysDiff;
            document.getElementById("danger_lead_msg").innerText = message;
            document.getElementById("lead_danger_expected").innerText = formattedOutgoingCount;
            document.getElementById("lead_danger_call_count").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_call_count_actual").innerText = formattedExpectedCount;
            document.getElementById("lead_danger_count").innerHTML = formattedCount;
        }
    </script>
    <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
        $(document).ready(function() {
            $(".common_time_class_new").flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                defaultHour: new Date().getHours(),
                defaultMinute: new Date().getMinutes()
            });
        });
    </script>
    <!-- Place the script at the end of the body or in a separate file -->
    <script>
        // Make sure all functions are defined in the global scope
        (function() {
            // State management
            let currentPage = 1;
            let currentStaffFilter = '';
            let currentPerPage = 10;

            // Define all functions in the global scope
            window.dailyCallHistoryBtn = function() {
                console.log('dailyCallHistoryBtn called'); // Debug log
                loadStaffList();
                loadDailyCallHistory();
            };

            window.loadStaffList = function() {
                const staffFilter = document.getElementById('staffFilter');
                if (!staffFilter) {
                    console.error('Staff filter element not found');
                    return;
                }

                // Show loading state
                staffFilter.innerHTML = '<option value="">Loading...</option>';
                staffFilter.disabled = true;

                // Get the correct route URL - make sure this is properly rendered by Laravel
                const url = '{{ route('daily_call_history') }}?staff_list_only=1';

                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        staffFilter.disabled = false;

                        if (data.status && data.staff_list && data.staff_list.length > 0) {
                            staffFilter.innerHTML = '<option value="">All Staff</option>';
                            data.staff_list.forEach(staff => {
                                const option = document.createElement('option');
                                option.value = staff.sno;
                                option.textContent = staff.staff_name;
                                staffFilter.appendChild(option);
                            });
                        } else {
                            staffFilter.innerHTML = '<option value="">No staff available</option>';
                        }
                    })
                    .catch(error => {
                        console.error('Error loading staff:', error);
                        staffFilter.disabled = false;
                        staffFilter.innerHTML = '<option value="">Error loading staff</option>';
                    });
            };

            window.loadDailyCallHistory = function(page = 1) {
                showLoading();

                // Get the correct route URL
                let url = `{{ route('daily_call_history') }}?page=${page}&per_page=${currentPerPage}`;

                if (currentStaffFilter) {
                    url += `&staff_id=${currentStaffFilter}`;
                }

                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        if (data.status) {
                            displayHistoryData(data);
                            if (data.pagination) {
                                updatePagination(data.pagination);
                                updateRecordsInfo(data.pagination);
                            }
                        } else {
                            throw new Error(data.message || 'Error loading data');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        const tableBody = document.getElementById('FollowUpHistoryTable');
                        if (tableBody) {
                            tableBody.innerHTML = `
                        <tr>
                            <td colspan="5" class="text-center text-danger">
                                Error loading data: ${error.message}
                            </td>
                        </tr>
                    `;
                        }
                    });
            };
            window.formatDate = function(dateString) {
                if (!dateString) return 'N/A';

                try {
                    const date = new Date(dateString);
                    if (isNaN(date.getTime())) return 'N/A'; // Invalid date

                    const day = date.getDate().toString().padStart(2, '0');
                    const month = date.toLocaleString('en-US', {
                        month: 'short'
                    });
                    const year = date.getFullYear();

                    return `${day}-${month}-${year}`;
                } catch (error) {
                    console.error('Date formatting error:', error);
                    return 'N/A';
                }
            };

            window.displayHistoryData = function(data) {
                const tableBody = document.getElementById('FollowUpHistoryTable');
                if (!tableBody) return;

                let historyhtml = '';

                if (data.data && data.data.length > 0) {
                    data.data.forEach(function(his) {
                        let status = 'Pending';
                        if (his.status == 0) {
                            status = 'Pending';
                        } else if (his.status == 1) {
                            status = 'Completed';
                        }
                        if (his.status == 2) {
                            status = 'Incomplete';
                        }

                        // Sanitize and truncate message if needed
                        const message = his.convo_message || 'No message';
                        const truncatedMessage = message.length > 100 ? message.substring(0, 100) + '...' :
                            message;

                        historyhtml += `
                    <tr>
                        <td>
                            <div><strong>${escapeHtml(formatDate(his.sch_date)) || 'N/A'}</strong></div>
                        </td>
                        <td>
                            <div><strong>${escapeHtml(his.lead_name) || 'N/A'}</strong></div>
                            <div><small class="text-muted">${escapeHtml(his.lead_mobile) || 'N/A'}</small></div>
                        </td>
                        <td>
                            <div>${escapeHtml(his.sales_staff_name) || 'N/A'}</div>
                        </td>
                        <td>
                            <div>${escapeHtml(his.assign_staff) || 'N/A'}</div>
                        </td>
                        <td>
                            <span class="badge ${getStatusBadgeClass(status)}">
                                ${escapeHtml(status)}
                            </span>
                        </td>
                        <td>
                            <div class="text-wrap" title="${escapeHtml(message)}">
                                ${escapeHtml(truncatedMessage)}
                            </div>
                        </td>
                    </tr>
                `;
                    });
                } else {
                    historyhtml = '<tr><td colspan="5" class="text-center">No records found</td></tr>';
                }

                tableBody.innerHTML = historyhtml;
            };

            // Helper function to escape HTML
            window.escapeHtml = function(text) {
                if (!text) return text;
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            };



            window.getStatusBadgeClass = function(status) {
                const statusLower = status;
                const classes = {
                    'Completed': 'bg-success',
                    'Pending': 'bg-warning text-dark',
                    'Incomplete': 'bg-danger animation-blink'
                };
                return classes[statusLower] || 'bg-secondary';
            };

            window.updatePagination = function(pagination) {
                const paginationElement = document.getElementById('pagination');
                if (!paginationElement) return;

                let paginationHtml = '';

                if (pagination.last_page > 1) {
                    // Previous button
                    paginationHtml += `
                <li class="page-item ${pagination.current_page === 1 ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${pagination.current_page - 1}); return false;" ${pagination.current_page === 1 ? 'tabindex="-1" aria-disabled="true"' : ''}>
                        Previous
                    </a>
                </li>
            `;

                    // Page numbers
                    for (let i = 1; i <= pagination.last_page; i++) {
                        if (i === 1 || i === pagination.last_page ||
                            (i >= pagination.current_page - 2 && i <= pagination.current_page + 2)) {
                            paginationHtml += `
                        <li class="page-item ${pagination.current_page === i ? 'active' : ''}" ${pagination.current_page === i ? 'aria-current="page"' : ''}>
                            <a class="page-link" href="#" onclick="changePage(${i}); return false;">${i}</a>
                        </li>
                    `;
                        } else if (i === pagination.current_page - 3 || i === pagination.current_page + 3) {
                            paginationHtml +=
                                `<li class="page-item disabled"><span class="page-link">...</span></li>`;
                        }
                    }

                    // Next button
                    paginationHtml += `
                <li class="page-item ${pagination.current_page === pagination.last_page ? 'disabled' : ''}">
                    <a class="page-link" href="#" onclick="changePage(${pagination.current_page + 1}); return false;" ${pagination.current_page === pagination.last_page ? 'tabindex="-1" aria-disabled="true"' : ''}>
                        Next
                    </a>
                </li>
            `;
                }

                paginationElement.innerHTML = paginationHtml;
            };

            window.updateRecordsInfo = function(pagination) {
                const recordsInfo = document.getElementById('recordsInfo');
                if (recordsInfo) {
                    if (pagination.total > 0) {
                        recordsInfo.innerHTML =
                            `Showing ${pagination.from} to ${pagination.to} of ${pagination.total} records`;
                    } else {
                        recordsInfo.innerHTML = 'No records found';
                    }
                }
            };

            window.changePage = function(page) {
                if (page > 0) {
                    currentPage = page;
                    loadDailyCallHistory(page);
                }
            };

            window.changePerPage = function(perPage) {
                currentPerPage = parseInt(perPage);
                currentPage = 1;
                loadDailyCallHistory(1);
            };

            window.applyFilter = function() {
                const staffFilter = document.getElementById('staffFilter');
                currentStaffFilter = staffFilter ? staffFilter.value : '';
                currentPage = 1;
                loadDailyCallHistory(1);
            };

            window.resetFilter = function() {
                const staffFilter = document.getElementById('staffFilter');
                if (staffFilter) {
                    staffFilter.value = '';
                }
                currentStaffFilter = '';
                currentPage = 1;
                loadDailyCallHistory(1);
            };

            window.showLoading = function() {
                const tableBody = document.getElementById('FollowUpHistoryTable');
                if (tableBody) {
                    tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div class="mt-2">Loading data...</div>
                    </td>
                </tr>
            `;
                }
            };

            // Initialize tooltips when document is ready
            document.addEventListener('DOMContentLoaded', function() {
                // Initialize tooltips
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl);
                });
            });

        })(); // End of IIFE
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let currentStatus = {{ $monitor->status ?? 0 }};
            const switchCheckbox = document.getElementById('dailyCallSwitch');
            const statusLabel = document.querySelector('.switch-status');
            const confirmBtn = document.getElementById('confirmSwitchBtn');
            const messageBox = document.getElementById('switchMessage');

            if (!switchCheckbox) return;

            // Handle checkbox click (show modal)
            switchCheckbox.addEventListener('click', function(e) {
                e.preventDefault(); // Prevent immediate toggle

                let modal = new bootstrap.Modal(
                    document.getElementById('switchConfirmModal')
                );

                if (currentStatus == 1) {
                    messageBox.innerText = "Are you sure you want to turn OFF Schedule Daily Call?";
                } else {
                    messageBox.innerText = "Are you sure you want to turn ON Schedule Daily Call?";
                }
                modal.show();
            });

            // Handle confirmation
            confirmBtn.addEventListener('click', function() {
                fetch("{{ route('daily_call_switch_update') }}", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": "{{ csrf_token() }}"
                        },
                        body: JSON.stringify({
                            status: currentStatus == 1 ? 0 : 1
                        })
                    })
                    .then(response => response.json())
                    .then(res => {
                        if (res.status) {
                            // Update current status
                            currentStatus = res.new_status;

                            // Update checkbox
                            switchCheckbox.checked = (currentStatus == 1);

                            // Update label text and color
                            if (currentStatus == 1) {
                                statusLabel.innerText = "ON";
                                statusLabel.classList.remove('text-danger');
                                statusLabel.classList.add('text-success');
                            } else {
                                statusLabel.innerText = "OFF";
                                statusLabel.classList.remove('text-success');
                                statusLabel.classList.add('text-danger');
                            }

                            // Hide modal
                            bootstrap.Modal.getInstance(
                                document.getElementById('switchConfirmModal')
                            ).hide();

                            // Show success message
                            toastr.success('Daily Call Status Updated');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        toastr.error('Failed to update status');
                    });
            });
        });
    </script>
    {{-- performance --}}
    <!-- Modal HTML -->
    <div class="modal fade" id="dailyCallPerformanceModal" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">

        <div class="modal-dialog modal-xl">

            <div class="modal-content">

                <!-- HEADER -->
                <div class="modal-header">

                    <h5 class="modal-title fw-bold">
                        Daily Call Performance
                    </h5>

                    <div class="d-flex align-items-end gap-2 ms-auto">

                        <!-- Type -->
                        <div>
                            <label class="text-dark mb-1 fs-7 fw-semibold">Type</label>
                            <select id="performanceType" class="form-select form-select-sm">
                                <option value="day">Day</option>
                                <option value="month">Month</option>
                            </select>
                        </div>

                        <!-- Day Picker -->
                        <div id="datePickerBox">
                            <label class="text-dark mb-1 fs-7 fw-semibold">
                                Select Date <span class="text-danger">*</span>
                            </label>

                            <div class="input-group input-group-sm">
                                <span class="input-group-text">
                                    <i class="mdi mdi-calendar-month-outline"></i>
                                </span>

                                <input type="text" id="performanceDate" autocomplete="off"
                                    placeholder="Select Date" class="form-control">
                            </div>
                        </div>

                        <!-- Month Picker -->
                        <div id="monthPickerBox" style="display:none;">
                            <label class="text-dark mb-1 fs-7 fw-semibold">
                                Select Month
                            </label>

                            <div class="input-group input-group-sm">
                                <span class="input-group-text">
                                    <i class="mdi mdi-calendar"></i>
                                </span>

                                <input type="text" id="ovr_month_fill" autocomplete="off"
                                    placeholder="Select Month" class="form-control">
                            </div>
                        </div>

                        <!-- Button -->
                        <div>
                            <button class="btn btn-primary btn-sm" id="loadPerformance">
                                Apply
                            </button>
                        </div>

                    </div>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    </button>

                </div>


                <!-- BODY (AJAX CONTENT WILL LOAD HERE) -->
                <div class="modal-body">

                    <div class="text-center p-4">
                        <div class="spinner-border text-primary"></div>
                        <div class="mt-2">Loading performance...</div>
                    </div>

                </div>

            </div>

        </div>

    </div>
    <script>
        $(document).ready(function() {

            // Day picker
            $('#performanceDate').datepicker({
                todayHighlight: true,
                autoclose: true,
                format: 'dd-M-yyyy'
            });

            // Month picker
            $('#ovr_month_fill').datepicker({
                format: 'M-yyyy',
                showButtonPanel: true,
                viewMode: "months",
                minViewMode: "months",
                todayHighlight: true,
                autoclose: true,
                orientation: 'right',
                endDate: new Date()
            });

            // Set default current date
            let today = new Date();
            $('#performanceDate').datepicker('setDate', today);

            // Set default current month
            $('#ovr_month_fill').datepicker('setDate', today);

        });

        $('#performanceType').change(function() {

            let type = $(this).val();

            if (type === 'month') {
                $('#datePickerBox').hide();
                $('#monthPickerBox').show();
            } else {
                $('#datePickerBox').show();
                $('#monthPickerBox').hide();
            }

        });

        $('#dailyPerformanceBtn').click(function() {

            $('#dailyCallPerformanceModal').modal('show');

            loadPerformanceData();
        });

        $('#loadPerformance').click(function() {

            loadPerformanceData();
        });

        function loadPerformanceData() {

            let type = $('#performanceType').val();
            let date = '';

            if (type === 'day') {
                date = $('#performanceDate').val();
            } else {
                date = $('#ovr_month_fill').val();
            }

            let skeleton = `
          <table class="table table-bordered align-middle">
          <thead class="table bg-primary text-center">
          <tr>
          <th>Staffs</th>
          <th>Target Call</th>
          <th>Actual Call</th>
          <th>Percentage</th>
          <th>Performance</th>
          <th>Failure</th>
          </tr>
          </thead>
          <tbody>
          `;

            for (let i = 0; i < 5; i++) {
                skeleton += `
              <tr>
                  <td>
                      <div class="d-flex align-items-center">
                          <div class="skeleton skeleton-circle me-2"></div>
                          <div class="skeleton skeleton-text"></div>
                      </div>
                  </td>

                  <td class="text-center">
                      <div class="skeleton skeleton-box"></div>
                  </td>

                  <td>
                      <div class="skeleton skeleton-bar"></div>
                  </td>
                  <td>
                      <div class="skeleton skeleton-bar"></div>
                  </td>

                  <td class="text-center">
                      <div class="skeleton skeleton-badge"></div>
                  </td>

                  <td class="text-center">
                      <div class="skeleton skeleton-box"></div>
                  </td>
              </tr>
              `;
            }

            skeleton += `</tbody></table>`;

            $('#dailyCallPerformanceModal .modal-body').html(skeleton);
            $.ajax({
                url: "/daily-performance",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    type: type,
                    date: date
                },
                success: function(response) {

                    let html = `
                  <table class="table table-bordered table-hover align-middle">

                      <thead class="table bg-primary text-center">
                          <tr>
                              <th>Staffs</th>
                              <th>Target Call</th>
                              <th>Actual Call</th>
                              <th>Percentage</th>
                              <th>Performance</th>
                              <th>Failure</th>
                          </tr>
                      </thead>

                      <tbody>
                  `;

                    response.forEach(function(staff) {

                        let badge = '';
                        let color = '';

                        if (staff.percentage <= 60) {
                            badge = "Worst Closed";
                            color = "danger";
                        } else if (staff.percentage <= 90) {
                            badge = "Moderate Closed";
                            color = "warning";
                        } else {
                            badge = "Perfect Closed";
                            color = "success";
                        }

                        let imagePath = staff.staff_image ?
                            '/staff_images/' + staff.staff_image :
                            '/default-avatar.png';

                        html += `
                      <tr>

                          <td>
                              <div class="d-flex align-items-center">

                                  <img src="${imagePath}"
                                      class="rounded-circle me-2"
                                       width="40" height="40">

                                  <div>

                                      <div class="fw-bold">
                                          ${staff.staff_name}
                                      </div>

                                      <span class="badge bg-info">
                                          ${staff.job_position_name ?? ''}
                                      </span>

                                  </div>

                              </div>
                          </td>
                           <td class="text-center fw-bold">
                              ${staff.call_count ?? 0}
                          </td>
                          <td class="text-center fw-bold">
                              ${staff.total_calls}
                          </td>
                         

                          <td class="text-center">

                              <div class="progress rounded position-relative" style="height:18px">

                                  <div class="progress-bar bg-${color}"
                                      style="width:${staff.percentage}%">
                                  </div>

                                  <span class="position-absolute top-50 start-50 translate-middle fw-bold text-dark">
                                      ${staff.percentage}%
                                  </span>

                              </div>

                          </td>

                          <td class="text-center">
                              <span class="badge bg-${color}">
                                  ${badge}
                              </span>
                          </td>

                          <td class="text-center">

                              ${
                                  staff.failure_count > 0
                                  ?
                                  `<span class="badge bg-danger"
                                              title="${staff.reason ?? ''}">
                                              ${staff.failure_count}
                                          </span>`
                                  :
                                  `<span class="badge bg-success">0</span>`
                              }

                          </td>

                      </tr>
                      `;
                    });

                    html += `</tbody></table>`;

                    $('#dailyCallPerformanceModal .modal-body').html(html);
                }
            });
        }
    </script>
    <style>
        .skeleton {
            background: #e2e5e7;
            border-radius: 6px;
            animation: skeleton-loading 1s linear infinite alternate;
        }

        @keyframes skeleton-loading {
            0% {
                opacity: 0.7
            }

            100% {
                opacity: 1
            }
        }

        .skeleton-text {
            width: 120px;
            height: 14px;
        }

        .skeleton-circle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }

        .skeleton-box {
            width: 40px;
            height: 20px;
            margin: auto;
        }

        .skeleton-bar {
            width: 100%;
            height: 16px;
        }

        .skeleton-badge {
            width: 90px;
            height: 20px;
            margin: auto;
        }
    </style>
@endsection
