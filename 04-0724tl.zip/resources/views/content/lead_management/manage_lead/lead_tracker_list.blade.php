@extends('layouts/layoutMaster')

@section('title', 'Manage Lead Tracker')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',

])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')
<style>
    .lead_list thead th,
    .lead_list tbody td {
        padding: 7px !important;
    }

    .list_page_1 thead th,
    .list_page_1 tbody td {
        padding: 7px !important;
    }

    .boom-animate {
        animation: boom 0.6s ease-out;
        z-index: 9999;
    }

    @keyframes boom {
        0% {
            transform: scale(0.7);
            opacity: 1;
        }

        /* 50% {
            transform: scale(1.2);
            opacity: 0.7;
        } */

        100% {
            transform: scale(1);
            opacity: 1;
        }
    }

    .shiny-glow-badge {
        position: relative;
        animation: softShakePulse 1.2s infinite ease-in-out;
    }

    .shiny-glow-badge::before {
        content: '';
        position: absolute;
        top: 0;
        left: -75%;
        width: 50%;
        height: 100%;
        background: linear-gradient(
            120deg,
            rgba(255, 255, 255, 0.05) 0%,
            rgba(255, 255, 255, 0.4) 50%,
            rgba(255, 255, 255, 0.05) 100%
        );
        pointer-events: none;
        animation: wiggle 0.8s infinite, shine 2s infinite;
    }
     .jd-orange {
        color: #f16522; /* Justdial Orange */
        font-weight: bold;
    }
    .jd-blue, .jd-orange {
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.2);
    }


        @keyframes shine {
            0% {
                left: -75%;
            }
            100% {
                left: 125%;
            }
        }

    @keyframes softShakePulse {
        0%, 100% {
            transform: translate(0, 0);
        }
        20% {
            transform: translate(1px, -1px);
        }
        40% {
            transform: translate(-1px, 1px);
        }
        60% {
            transform: translate(1px, 1px);
        }
        80% {
            transform: translate(-1px, -1px);
        }
    }

    .empty-state {
        opacity: 0.7;
        transition: 0.3s;
    }
    .empty-state:hover {
        opacity: 1;
    }
</style>


<style>
    .scroll-x {
        overflow-x: auto;
        overflow-y: hidden;
        white-space: nowrap;
    }

    .scroll-x > div {
        flex: 0 0 auto;
    }

    /* Top scrollbar */
    .top-scroll {
        overflow-x: auto;
        overflow-y: hidden;
        height: 16px;
    }

    .top-scroll div {
        height: 1px; /* invisible content */
    }
</style>

<style>
  .filter-bar {
    background: linear-gradient(135deg, #f7fbfd, #dfeef4);
    border: 1px solid #e1e8eb;
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 12px;
    padding: 12px;
  }

  /* pill style */
  .filter-pill {
      display: flex;
      align-items: center;
      gap: 6px;
      background: #fff;
      border: 1px solid #e3eaec;
      border-radius: 30px;
      padding: 6px 12px;
      transition: 0.2s;
      /* Remove comment and adjust as needed */
      min-width: 140px;
  }



  .filter-pill:hover {
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
      transform: translateY(-1px);
  }

  /* inputs inside pill */
  .filter-pill input,
  .filter-pill select {
      border: none !important;
      outline: none !important;
      font-size: 13px;
      background: transparent;
      box-shadow: none !important;
  }

  /* Control select width */
  .filter-pill select {
      width: auto;
      min-width: 90px;
      cursor: pointer;
  }

  /* If using Select2 */
  .filter-pill .select2-container {
      min-width: 100px;
      width: auto !important;
  }

  /* Remove select2 specific borders */
  .filter-pill .select2-container--default .select2-selection--single {
      border: none !important;
      background: transparent !important;
  }

  .filter-pill .select2-container .select2-selection--single {
      height: auto !important;
  }

  /* search - takes remaining space */
  .filter-search {
      display: flex;
      align-items: center;
      background: #fff;
      border-radius: 30px;
      padding: 6px 12px;
      border: 1px solid #e0e3f5;
      flex: 1; /* Takes remaining space */
      min-width: 200px;
  }

  .filter-search input {
      border: none;
      outline: none;
      margin-left: 6px;
      width: 100%;
  }

  /* icons */
  .filter-pill i,
  .filter-search i {
      font-size: 16px;
      color: #099dda;
  }



  /* Title section full width */
  .d-flex.justify-content-between.align-items-center.navbar.mb-3 {
      width: 50%;
  }

  /* Responsive adjustments */
  @media (max-width: 768px) {
      .filter-pill {
          min-width: auto;
          flex: 1 0 auto;
      }

      .filter-search {
          min-width: 100%;
          flex: auto;
      }
  }
</style>

<div class="card card-action">
    <div class="card-header border-bottom pb-2 d-flex justify-content-between">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Lead Tracker</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-1 mb-2" id="filter">
                    <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Filter"><i
                            class="mdi mdi-filter-outline text-center"></i></span>
                </a>
            </div>
        
    </div>
    
    <div class="filter_tbox px-2 pt-2" style="display: none;">
        <div class="filter-bar d-flex flex-wrap align-items-center gap-2 p-2 rounded">
            <!-- VALUE FILTER -->
            <div class="filter-pill" style="min-width: 285px;">
                <i class="mdi mdi-currency-inr"></i>

                <select id="value-operator" class="border-0 bg-transparent select3">
                    <option value="">Any</option>
                    <option value=">">Greater</option>
                    <option value="<">Less</option>
                    <option value="=">Equal</option>
                    <option value="between">Between</option>
                </select>

                <input type="number" id="value1" placeholder="Value">

                <input type="number" id="value2" placeholder="Max" class="d-none">
            </div>
            <!-- MONTH -->
            <div class="filter-pill">
                <i class="mdi mdi-calendar-month"></i>
                <input type="text" id="ovr_month_fill" class="month_filter_common_class">
            </div>

            <!-- SEARCH -->
            <div class="filter-search" style="min-width: 285px;">
                <i class="mdi mdi-magnify"></i>
                <input type="text" id="lead-filter"
                        placeholder="Search lead...">
            </div>

            <!-- PRODUCT -->
            <div class="filter-pill" style="min-width: 250px;">
                <i class="mdi mdi-package-variant"></i>
                <select id="product-filter" class="select3" style="width: 250px;">
                    <option value="">Select Product</option>
                </select>
            </div>

            <!-- SOURCE -->
            <div class="filter-pill" style="min-width: 210px;" >
                <i class="mdi mdi-source-branch"></i>
                <select id="source-filter" class="select3" style="width: 250px;">
                    <option value="">Select Source</option>
                </select>
            </div>

            <!-- STAFF -->
            <div class="filter-pill" style="min-width: 230px;">
                <i class="mdi mdi-account"></i>
                <select id="staff-filter" class="select3" style="width: 250px;">
                    <option value="">Select Staff</option>
                </select>
            </div>

            <!-- Quick Reset -->
            <button class="btn btn-sm btn-outline-danger" onclick="resetFilters()">
                <i class="mdi mdi-refresh"></i> Reset
            </button>
        </div>
    </div>

    <div class="card-body px-4 pb-0 pt-2">


        <div class="row g-3 mt-2">
            <div class="col-lg-12 d-flex align-items-center justify-content-between mb-3">
                <div class="">
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:250px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#FDEBD2;">
                           <label class="fw-semibold"> TA </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold text-secondary" style=" font-size:13px;">Total Amount</span>
                            <span id="total-value" class="fw-bold text-dark fs-4">&#8377; 00</span>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:200px;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#e4dbff;">
                             <label class="fw-semibold"> QL </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold text-secondary" style="font-size:13px;">Qualified Lead</span>
                            <span id="qualified-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:200px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#d5dffb;">
                             <label class="fw-semibold"> FL </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span  class="fw-semibold text-secondary" style="font-size:13px;">Follow Up Lead</span>
                            <span id="followup-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:150px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#cff9db;">
                             <label class="fw-semibold"> L3 </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span  class="fw-semibold text-secondary" style="font-size:13px;">Level 3</span>
                            <span id="level3-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
                <div class="">
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:150px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#ffe6da;">
                             <label class="fw-semibold"> L2 </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span  class="fw-semibold text-secondary" style="font-size:13px;">Level 2</span>
                            <span id="level2-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
                <div class="" >
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:150px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#ced0fd;">
                             <label class="fw-semibold"> L1 </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span  class="fw-semibold text-secondary" style="font-size:13px;">Level 1</span>
                            <span id="level1-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
                <div class="" >
                    <div class="d-flex align-items-center px-3 py-2 rounded border" style="background:#F8F9FA; width:150px; ">
                        <div class="d-flex align-items-center justify-content-center rounded-circle" style="width:42px; height:42px; background:#b2f3a5;">
                             <label class="fw-semibold"> CL </label>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span  class="fw-semibold text-secondary" style="font-size:13px;">Closing</span>
                            <span id="closing-count" class="fw-bold text-dark fs-4">00</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="top-scroll" id="topScroll">
                <div></div>
                </div>
                <div class="d-flex flex-nowrap gap-3  py-3 mb-4 scroll-x" id="bottomScroll">
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #c3b3ef; ">
                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#c3b3ef;">
                                <label class="text-black fw-semibold fs-6">Qualified Lead</label>
                                <label id="qualified-value" class="badge bg-white px-3 text-black fw-semibold fs-6">&#8377; 0 </label>
                            </div>
                            <div id="qualified-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">
                                <div class="border p-2 " style="border-radius:4px;">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Arun Kumar</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Sri Venkateswara Technologies</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6 text-wrap">Local SEO Service</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 8,000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-2 " style="border-radius:4px;">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Karthik Raj</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Madurai Digital Solutions</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6 text-wrap">Generic Engine Optimization & AI SEO</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 35,000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-2 " style="border-radius:4px;">

                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Suresh Babu</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Thanjai Software Systems</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6">AI Services & Automation Solutions</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 11,000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-2 " style="border-radius:4px;">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Arun Kumar</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Sri Venkateswara Technologies</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6 text-wrap">Local SEO Service</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 8,000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-2 " style="border-radius:4px;">
                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Karthik Raj</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Madurai Digital Solutions</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6 text-wrap">Generic Engine Optimization & AI SEO</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 35,000</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="border p-2 " style="border-radius:4px;">

                                    <div class="d-flex flex-column">
                                        <div class="d-flex align-items-center gap-2 justify-content-between">
                                            <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">Suresh Babu</label>
                                            <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="9712485967"></span>
                                        </div>
                                        <label class="text-secondary fw-semibold fs-8 text-truncate" style="max-width:250px;">Thanjai Software Systems</label>
                                    </div>
                                    <hr class="my-2">
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex align-items-start flex-column">
                                            <label class="text-secondary fw-semibold fs-8">Service</label>
                                            <label class="text-black fw-semibold fs-6">AI Services & Automation Solutions</label>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-between">
                                            <label class="text-secondary fw-semibold fs-8">Costing</label>
                                            <label class="bg-label-warning px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 11,000</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #a5bbf7; ">
                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#a5bbf7;">
                                <label class="text-black fw-semibold fs-6">Follow Up Lead</label>
                                <label id="followup-value" class="bg-white px-3 py-1  text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; 00</label>
                            </div>
                            <div id="followup-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">

                            </div>
                        </div>
                    </div>
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #a1e3b3; ">

                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#a1e3b3;">
                                <label class="text-black fw-semibold fs-6">Level 3</label>
                                <label id="level3-value" class="badge bg-white px-3 text-black fw-semibold fs-6">&#8377; 00 </label>
                            </div>
                            <div id="level3-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">

                            </div>
                        </div>
                    </div>
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #f7c4ab; ">

                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#f7c4ab;">
                                <label class="text-black fw-semibold fs-6">Level 2</label>
                                <label id="level2-value" class="badge bg-white px-3 text-black fw-semibold fs-6">&#8377; 00 </label>
                            </div>
                            <div id="level2-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">

                            </div>
                        </div>
                    </div>
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #a5a8f3; ">
                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#a5a8f3;">
                                <label class="text-black fw-semibold fs-6">Level 1</label>
                                <label id="level1-value" class="badge bg-white px-3 text-black fw-semibold fs-6">&#8377; 00 </label>
                            </div>
                            <div id="level1-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">

                            </div>
                        </div>
                    </div>
                    <div class="" style="width:350px;">
                        <div class="card " style="box-shadow:none; border:1px solid #b2f3a5; ">
                            <div class="card-header  py-3 d-flex align-items-center justify-content-between" style="background:#b2f3a5;">
                                <label class="text-black fw-semibold fs-6">Closing</label>
                                <label id="closing-value"class="badge bg-white px-3 text-black fw-semibold fs-6">&#8377; 00 </label>
                            </div>
                            <div id="closing-list" class="card-body d-flex flex-column px-3 gap-3 scroll-y" style="max-height:558px;">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

    </style>

<script>
    const topScroll = document.getElementById('topScroll');
    const bottomScroll = document.getElementById('bottomScroll');

    // Match width
    topScroll.firstElementChild.style.width = bottomScroll.scrollWidth + 'px';

    // Sync scrolling
    topScroll.addEventListener('scroll', () => {
        bottomScroll.scrollLeft = topScroll.scrollLeft;
    });

    bottomScroll.addEventListener('scroll', () => {
        topScroll.scrollLeft = bottomScroll.scrollLeft;
    });
</script>

<script>
  // Make sure everything runs after DOM is ready
  $(document).ready(function() {
      // Initialize month value
      $('#ovr_month_fill').val(new Date().toLocaleDateString('en-US', {
          month: 'short',
          year: 'numeric'
      }));

      // Load all dropdowns first
      loadProductDropdown();
      loadStaffDropdown();
      loadSourceDropdown();

      // Setup event listeners
      setupEventListeners();

      // Load kanban after dropdowns are loaded
      setTimeout(function() {
          loadKanban();
      }, 500);
  });

  function loadProductDropdown() {
      let productDropdown = $('#product-filter');

      $.ajax({
          url: "/lead_tracker_product_List",
          type: "GET",
          dataType: 'json',
          success: function (response) {
              console.log("PRODUCT API RESPONSE:", response);
              productDropdown.empty().append('<option value="">Select Product</option>');

              if (response.status === 200 && response.data && response.data.length > 0) {
                  response.data.forEach(function (p) {
                      productDropdown.append(`<option value="${p.sno}">${p.product_name}</option>`);
                  });
              } else {
                  productDropdown.append('<option value="">No Products Found</option>');
              }
          },
          error: function(xhr, status, error) {
              console.log("Product API Error:", error);
              productDropdown.html('<option value="">Error loading products</option>');
          }
      });
  }

  function loadStaffDropdown() {
      let staffDropdown = $('#staff-filter');

      $.ajax({
          url: "/lead_tracker_staff_List",
          type: "GET",
          dataType: 'json',
          success: function (response) {
              console.log("Staff API RESPONSE:", response);
              staffDropdown.empty().append('<option value="">Select Staff</option>');

              if (response.status === 200 && response.data && response.data.length > 0) {
                  response.data.forEach(function (p) {
                      staffDropdown.append(`<option value="${p.sno}">${p.staff_name}</option>`);
                  });
              } else {
                  staffDropdown.append('<option value="">No Staff Found</option>');
              }
          },
          error: function(xhr, status, error) {
              console.log("Staff API Error:", error);
              staffDropdown.html('<option value="">Error loading staff</option>');
          }
      });
  }

  function loadSourceDropdown() {
      let sourceDropdown = $('#source-filter');

      $.ajax({
          url: "/lead_tracker_source_List",
          type: "GET",
          dataType: 'json',
          success: function (response) {
              console.log("Source API RESPONSE:", response);
              sourceDropdown.empty().append('<option value="">Select Source</option>');

              if (response.status === 200 && response.data && response.data.length > 0) {
                  response.data.forEach(function (p) {
                      sourceDropdown.append(`<option value="${p.sno}">${p.lead_source}</option>`);
                  });
              } else {
                  sourceDropdown.append('<option value="">No Source Found</option>');
              }
          },
          error: function(xhr, status, error) {
              console.log("Source API Error:", error);
              sourceDropdown.html('<option value="">Error loading sources</option>');
          }
      });
  }

  function setupEventListeners() {
    $('#value-operator').on('change', function () {
        $('#value2').toggleClass('d-none', $(this).val() !== 'between');
        loadKanban();
    });

    $('#product-filter, #source-filter, #staff-filter, #value1, #value2, #ovr_month_fill')
        .on('change', function() {
            console.log("Filter changed:", this.id);
            loadKanban();
        });

    $('#ovr_month_fill').on('keyup', function() {
        clearTimeout(window.monthTimer);
        window.monthTimer = setTimeout(loadKanban, 500);
    });

    let timer;
    $('#lead-filter').on('keyup', function () {
        clearTimeout(timer);
        timer = setTimeout(loadKanban, 500);
    });
  }

  function loadKanban() {
      console.log("Loading kanban...");
      ['qualified','followup','level3','level2','level1','closing'].forEach(showSkeleton);
      $('#searchSpinner').removeClass('d-none');

      let monthValue = $('#ovr_month_fill').val();
      console.log("Sending month value:", monthValue);

      let requestData = {
          search: $('#lead-filter').val(),
          product_id: $('#product-filter').val(),
          source_id: $('#source-filter').val(),
          staff_id: $('#staff-filter').val(),
          month: monthValue,
          value_operator: $('#value-operator').val(),
          value1: $('#value1').val(),
          value2: $('#value2').val()
      };

      console.log("Request data:", requestData);

      fetch('/lead-tracker', {
          method: 'POST',
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
              'Accept': 'application/json'
          },
          body: JSON.stringify(requestData)
      })
      .then(response => {
          console.log("Response status:", response.status);
          if (!response.ok) {
              // Try to get the error message from response
              return response.text().then(text => {
                  console.error("Server error response:", text);
                  throw new Error(`HTTP error! status: ${response.status} - ${text.substring(0, 200)}`);
              });
          }
          return response.json();
      })
      .then(res => {
          console.log("Response data:", res);
          $('#searchSpinner').addClass('d-none');
          if (res.status === 200) {
              renderKanban(res.data, res.summary, res.total);
          } else {
              console.error("Server error:", res);
          }
      })
      .catch(error => {
          console.error("Error loading kanban:", error);
          $('#searchSpinner').addClass('d-none');
          // Show error to user for debugging
          toastr.error('Error: ' + error.message);
      });
  }

  function renderKanban(data, summary, total) {
      renderColumn('qualified', data.qualified, summary.qualified);
      renderColumn('followup', data.followup, summary.followup);
      renderColumn('level3', data.level3, summary.level3);
      renderColumn('level2', data.level2, summary.level2);
      renderColumn('level1', data.level1, summary.level1);
      renderColumn('closing', data.closing, summary.closing);

      if (document.getElementById('total-value')) {
          document.getElementById('total-value').innerText = '₹ ' + formatCurrency(total);
      }
  }

  function formatCurrency(num) {
      return Number(num || 0).toLocaleString('en-IN');
  }



  function escapeHtml(str) {
      // Handle non-string values
      if (str === null || str === undefined) return '';
      // Convert to string if it's not already
      if (typeof str !== 'string') str = String(str);
      return str.replace(/[&<>]/g, function(m) {
          if (m === '&') return '&amp;';
          if (m === '<') return '&lt;';
          if (m === '>') return '&gt;';
          return m;
      });
  }

  function renderColumn(type, items, summary) {
      const container = document.getElementById(type + '-list');
      if (!container) {
          console.error(type + '-list NOT FOUND');
          return;
      }
      let html = '';

      if (!items || items.length === 0) {
          html = `
          <div class="empty-state d-flex flex-column align-items-center justify-content-center text-center py-5">
              <div style="font-size:40px;">📭</div>
              <div class="fw-semibold text-secondary mt-2">No Leads Found</div>
              <small class="text-muted">No data available in this stage</small>
          </div>`;
      } else {
          items.forEach(item => {
              // Safely get values and convert to string if needed
              const leadName = item.lead_name ? String(item.lead_name) : '-';
              const leadMobile = item.lead_mobile ? String(item.lead_mobile) : '';
            //   const companyName = item.company_name ? String(item.company_name) : '-';
              const productName = item.product_name ? String(item.product_name) : '-';
              const staffName = item.staff_name ? String(item.staff_name) : '0';
              const itemValue = item.value ?? 0;

              html += `
              <div class="border p-2">
                  <div class="d-flex flex-column">
                      <div class="d-flex align-items-center gap-2 justify-content-between">
                          <label class="text-black fw-semibold fs-6 text-truncate" style="max-width:250px;">${escapeHtml(leadName)}</label>
                          <span class="mdi mdi-phone fs-6" data-bs-toggle="tooltip" data-bs-placement="top" title="${escapeHtml(leadMobile)}"></span>
                      </div>
                    
                  </div>
                  <hr class="my-2">
                  <div>
                      <label class="text-secondary fw-semibold fs-8">Service</label>
                      <div class="text-black fw-semibold fs-6 text-wrap">${escapeHtml(productName)}</div>
                  </div>
                  <div class="d-flex justify-content-between mt-2">
                      <label class="text-secondary fw-semibold fs-8">Costing</label>
                      <label class="bg-label-warning px-3 py-1 text-black fw-semibold fs-6" style="border-radius:5px;">&#8377; ${itemValue}</label>
                  </div>
                  <div class="d-flex justify-content-between mt-2">
                      <label class="text-secondary fw-semibold fs-8">Sales</label>
                      <label class="bg-label-info px-2 text-black fw-semibold fs-8" style="border-radius:5px;">${escapeHtml(staffName)}</label>
                  </div>
              </div>`;
          });
      }

      container.innerHTML = html;

      if (document.getElementById(type + '-count')) {
          document.getElementById(type + '-count').innerText = summary.count ?? 0;
      }
      if (document.getElementById(type + '-value')) {
          document.getElementById(type + '-value').innerText = '₹ ' + formatCurrency(summary.value ?? 0);
      }
  }

  function showSkeleton(type) {
      let html = '';
      for (let i = 0; i < 5; i++) {
          html += `<div class="placeholder-glow p-3 border mb-2">
                      <span class="placeholder col-6"></span>
                      <span class="placeholder col-4"></span>
                  </div>`;
      }
      const container = document.getElementById(type + '-list');
      if (container) {
          container.innerHTML = html;
      }
  }

  function resetFilters() {
      console.log("Resetting filters...");
      $('#value-operator, #product-filter, #source-filter, #staff-filter').val('');
      $('#value1, #value2, #lead-filter').val('');
      $('#ovr_month_fill').val(new Date().toLocaleDateString('en-US', {
          month: 'short',
          year: 'numeric'
      }));
      $('#value2').addClass('d-none');
      loadKanban();
  }
</script>

<script>
  // Initialize select2 if you're using it
  $(document).ready(function() {
      // Initialize select2 with custom styling to remove borders
      $('.select3').select2({
          dropdownCssClass: 'no-border-dropdown',
          minimumResultsForSearch: -1 // Remove search if you want
      });

      // Apply custom styles to select2 elements inside filter-pill
      $('.filter-pill .select3').next('.select2-container').find('.select2-selection').css({
          'border': 'none',
          'background': 'transparent',
          'box-shadow': 'none'
      });
  });
</script>

{{-- <style>
  /* Additional select2 border removal */
  .select2-container--default .select2-selection--single {
      border: none !important;
      background: transparent !important;
  }

  .select2-container--default .select2-selection--single .select2-selection__arrow {
      top: 50% !important;
      transform: translateY(-50%);
  }

  .select2-container--default .select2-selection--single .select2-selection__rendered {
      line-height: normal !important;
      padding-left: 0 !important;
  }
</style> --}}
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
@endsection
