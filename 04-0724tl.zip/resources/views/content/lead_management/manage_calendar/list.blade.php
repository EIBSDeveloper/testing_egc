@extends('layouts/layoutMaster')

@section('title', 'Lead Calendar')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<style>
    .lead_calendar thead th,
    .lead_calendar tbody td {
        padding: 7px !important;
        border: 1px solid rgb(150, 149, 149) !important;
    }

    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }

    .lead_calendar tbody td {
        height: 140px !important;
    }

    .emboss-effect {
        padding: 20px;
        border-radius: 10px;
        transition: box-shadow 0.3s ease, transform 0.3s ease;
    }

    .emboss-effect:hover {
        /* box-shadow: inset 0px 0rem 1rem 2px rgba(0, 0, 0, 0.1); */
        box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0);
        transform: translateX(0px) scale(1.03);
        /* transform: scale(1.1); */
        padding: 10px !important;
        background-color: #abffbb;
        border: 1px solid rgb(105, 105, 105) !important;
        z-index: 9999 !important;
    }

    .emboss-effect:hover .invis {
        visibility: visible !important;
    }

    .invis {
        visibility: hidden !important;
    }

    .cur_dt {
        border: 4px solid rgb(0, 255, 136);
        background-color: #63ffb6 !important;
        animation: borderBlink 1s steps(1, start) infinite;
    }

    @keyframes borderBlink {
        50% {
            border-color: transparent;
        }
    }

    .dataTables_scroll {
        max-height: 300px;
    }
</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $cloud_call_access = $helper->get_branch_id(auth()->user()->branch_id)->cloud_call_api_key ?? '';
@endphp
@php
    $dayCounter = 1;
    $emptyDays = $startDayOfWeek;
    // Extract month and year properly
    $currentMonth = $currentMonth; // numeric month (1-12)
    $currentYear  = $currentYear;

    // Calculate the first day of the month
    $firstDayOfMonth = Carbon\Carbon::createFromDate($currentYear, $currentMonth, 1);
    // Get the number of days in the current month
    $daysInMonth = $firstDayOfMonth->daysInMonth;

    // Get the day of the week for the 1st of the month (0 = Sunday, 1 = Monday, etc.)
    $startDayOfWeek = $firstDayOfMonth->dayOfWeek;

    // Calculate previous month and year
    $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
    $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January

    // Calculate next month and year
    $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
    $nextYear = $currentMonth == 12 ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December
    $currentDate = '2025-' . str_pad($currentMonth, 2, '0', STR_PAD_LEFT) . '-' . str_pad($dayCounter, 2, '0', STR_PAD_LEFT);
@endphp
<!-- Lead List Table -->
<div class="card">
    <div class="d-flex align-items-center justify-content-between border-bottom flex-wrap mb-0 gap-3 px-6 pt-3 pb-2">
        <div class="mb-1">
            <h5 class="card-title mb-1">Lead Calendar</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center">
                            <i class="mdi mdi-home-outline text-body fs-4"></i>
                        </a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="d-flex flex-wrap align-items-center mb-1">
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Leads">
                <div class="text-dark fw-semibold fs-6 mb-2">Leads</div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #1C9151 !important;">{{ sprintf("%02d", $monthLeadCount??0) }}</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Customers">
                <div class="text-dark fw-semibold fs-6 mb-2">Customers</div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-black fs-6" style="background-color: #4CD2FC !important;">{{  sprintf("%02d", $monthCustomerCount??0) }}</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Spam Leads">
                <div class="text-dark fw-semibold fs-6 mb-2">Spam</div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #6D788D !important;">{{  sprintf("%02d", $monthSpamCount??0) }}</div>
                </div>
            </a>
            @if(isset($cloud_call_access) && $cloud_call_access!='')
            <a href="javascript:;" class="text-center border border-2 p-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Cloud Call Leads">
                <div class="text-dark fw-semibold fs-6 mb-2">Cloud Call</div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #FF6563 !important;">{{  sprintf("%02d", $monthCallLog??0) }}</div>
                </div>
            </a>
            @endif
        </div>
        <div class="d-flex align-items-center justify-content-end mb-1">
            <!-- <a href="javascript:;" class="nav-link px-3 waves-effect waves-light me-2" title="Graph" data-bs-toggle="modal" data-bs-target="#kt_modal_graph_view">
                <div class="text-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Graph">
                    <i class="mdi mdi-finance fs-1"></i>
                </div>
            </a> -->
            <div class="w-60 mb-1">
                <div class="cursor-pointer input-group input-group-merge">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo $month_filter ?? date("M-Y"); ?>" readonly onchange="month_filter(this.value)">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body px-4 pb-3 pt-2">
        <div class="row">
            <div class="col-lg-12">
                <div class="px-3 table-responsive">
                    <table class="table align-top table-row-dashed gy-1 gs-2 lead_calendar">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px text-center">Sunday</th>
                                <th class="min-w-100px text-center">Monday</th>
                                <th class="min-w-100px text-center">Tuesday</th>
                                <th class="min-w-100px text-center">Wednesday</th>
                                <th class="min-w-100px text-center">Thursday</th>
                                <th class="min-w-100px text-center">Friday</th>
                                <th class="min-w-100px text-center">Saturday</th>                                
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @php
                                $dayCounter = 1;
                                $emptyDays = $startDayOfWeek;
                            @endphp
                            @for ($row = 0; $row < 5; $row++) <!-- Assuming at most 5 rows for any month -->
                            
                            <tr>
                                @foreach (['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as $day)
                                @php
                                      // Check if we still have empty days to fill
                                      if ($emptyDays > 0) {
                                          echo '<td></td>';
                                          $emptyDays--;
                                      } else {
                                          // Stop rendering if we have exceeded the number of days in the current month
                                          if ($dayCounter > $daysInMonth) {
                                              break;
                                          }
                                          
                                          // Match the current day with the lead count and conversion data
                                          $leadCount = 0;
                                          $leadDate = '';
                                          $convertCount = 0;
                                          $convertDate = '';
                                          $cloudDate = '';
                                          $cloudCount = 0;
                                          $spamCountValue = 0;
                                          $spamDate = 0;
                                          $leadDetails = [];
                                          $convertDetails = [];
                                          $dailySpamDetails = [];
                                          $cloudCallDetail = [];
                                          
                                          // Search for the corresponding lead count and details for the current day
                                          foreach ($totalLeadCount as $lead) {
                                              if (Carbon\Carbon::parse($lead['Date'])->day == $dayCounter) {
                                                  $leadCount = $lead['TotalLeads'];
                                                  $leadDate = $lead['Date'];
                                                  // Get the details for that day
                                                  foreach ($LeadDetail as $leadDetail) {
                                                      if ($leadDetail['Date'] == $lead['Date']) {
                                                          $leadDetails = $leadDetail['LeadDetails'];
                                                          break;
                                                      }
                                                  }
                                                  break;
                                              }
                                          }
                  
                                          // Search for the corresponding conversion count and details for the current day
                                          foreach ($leadConvert as $convert) {
                                              if (Carbon\Carbon::parse($convert['Date'])->day == $dayCounter) {
                                                  $convertCount = $convert['LeadConvert'];
                                                  $convertDate = $convert['Date'];
                                                  // Get the details for that day
                                                  foreach ($LeadConvertDetail as $convertDetail) {
                                                      if ($convertDetail['Date'] == $convert['Date']) {
                                                          $convertDetails = $convertDetail['LeadConvertDetails'];
                                                          break;
                                                          // return $convertDetails;
                                                      }
                                                  }
                                                  break;
                                              }
                                          }

                                          foreach ($callLog as $cloud) {
                                              if (Carbon\Carbon::parse($cloud['Date'])->day == $dayCounter) {
                                                  $cloudCount = $cloud['callLog'];
                                                  $cloudDate = $cloud['Date'];
                                                  // Get the details for that day
                                                  foreach ($callLogDetail as $cloudCallDetail) {
                                                      if ($cloudCallDetail['Date'] == $cloud['Date']) {
                                                          $cloudCallDetail = $cloudCallDetail['callLogDetail'];
                                                          break;
                                                          // return $convertDetails;
                                                      }
                                                  }
                                                  break;
                                              }
                                          }

                                          if (is_array($spamCount)) {
                                            foreach ($spamCount as $spam) {
                                                if (Carbon\Carbon::parse($spam['Date'])->day == $dayCounter) {
                                                    // Use a new variable to store the spam count for the day
                                                    $spamCountValue = $spam['spamCount'];
                                                    $spamDate = $spam['Date'];
                                                    if(!empty($spamCountDetails)) {
                                                        // Get the details for that day
                                                        foreach ($spamCountDetails as $spamDetail) {
                                                            if ($spamDetail['Date'] == $spam['Date']) {
                                                                $dailySpamDetails  = $spamDetail['spamCountDetails'];
                                                                break;  // Return or process $spamDetails if necessary
                                                            }
                                                        }
                                                        break;
                                                    }
                                                }
                                            }
                                        }   
                                        $color='';
                                        if (date('d') == $dayCounter && $currentMonth == date('m')) { 
                                            $color = 'style="background-color: #ffe4e4;"'; 
                                        }
                                        if (date('d') >= $dayCounter && $currentMonth == date('m')) {                                          
                                         echo '<td class="emboss-effect" '.$color.'>
                                                    <div class="d-flex justify-content-start align-items-center mb-2">
                                                        <div class="badge bg-body text-black border border-gray-400i rounded-pill fw-bold">' . sprintf("%02d", $dayCounter) . '</div>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Lead</div>
                                                        <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #1C9151 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_total_lead_view"  data-leads="' . htmlspecialchars(json_encode($leadDetails), ENT_QUOTES, 'UTF-8'). '" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($leadDate))), ENT_QUOTES, 'UTF-8'). '"  onclick="showLeadDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d", $leadCount). '</span>
                                                        </a>
                                                    </div>
                                                    <hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis">
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Customer</div>
                                                        <a href="javascript:;" class="badge text-black fs-6 fw-semibold rounded" style="background-color: #4CD2FC !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_lead_view" data-leads="' . htmlspecialchars(json_encode($convertDetails), ENT_QUOTES, 'UTF-8') . '" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($convertDate))), ENT_QUOTES, 'UTF-8'). '" onclick="showConvertDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d",$convertCount) . '</span>
                                                        </a>
                                                    </div>
                                                    <hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis">
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Spam</div>
                                                        <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #6D788D !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_spam_lead_view" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($spamDate))), ENT_QUOTES, 'UTF-8'). '"  data-leads="' . htmlspecialchars(json_encode($dailySpamDetails), ENT_QUOTES, 'UTF-8') . '" onclick="showSpamDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d",$spamCountValue) . '</span>
                                                        </a>
                                                    </div>';
                                                    
                                                    if(isset($cloud_call_access) && $cloud_call_access!=''){  
                                                        echo '<hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis"><div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                            <div class="fs-7 text-black fw-semibold invis">Cloud Call</div>
                                                            <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #FF6563 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_cloud_lead_view" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($cloudDate))), ENT_QUOTES, 'UTF-8'). '" data-leads="' . htmlspecialchars(json_encode($cloudCallDetail), ENT_QUOTES, 'UTF-8') . '" onclick="showCloudDetails(this)">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details"> ' . sprintf("%02d",$cloudCount) . '</span>
                                                            </a>
                                                        </div>';
                                                    }
                                            
                                          echo '</td>';
                                           
                                        }
                                        else if (date('d') < $dayCounter && $currentMonth == date('m')) { 
                                            echo '<td>';
                                            echo '<div class="d-flex justify-content-end align-items-start">
                                                  <label class="text-black fw-bold fs-8">' . sprintf("%02d", $dayCounter) . '</label>
                                                </div>';
                                            echo '<div class="text-center" style="margin-top: 3rem !important;">-</div>';
                                            echo '</td>';
                                                
                                        }
                                        else{
                                             echo '<td class="emboss-effect" '.$color.'>
                                                    <div class="d-flex justify-content-start align-items-center mb-2">
                                                        <div class="badge bg-body text-black border border-gray-400i rounded-pill fw-bold">' . sprintf("%02d", $dayCounter) . '</div>
                                                    </div>
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Lead</div>
                                                        <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #1C9151 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_total_lead_view"  data-leads="' . htmlspecialchars(json_encode($leadDetails), ENT_QUOTES, 'UTF-8'). '" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($leadDate))), ENT_QUOTES, 'UTF-8'). '"  onclick="showLeadDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d", $leadCount). '</span>
                                                        </a>
                                                    </div>
                                                    <hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis">
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Customer</div>
                                                        <a href="javascript:;" class="badge text-black fs-6 fw-semibold rounded" style="background-color: #4CD2FC !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_convert_lead_view" data-leads="' . htmlspecialchars(json_encode($convertDetails), ENT_QUOTES, 'UTF-8') . '" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($convertDate))), ENT_QUOTES, 'UTF-8'). '" onclick="showConvertDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d",$convertCount) . '</span>
                                                        </a>
                                                    </div>
                                                    <hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis">
                                                    <div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                        <div class="fs-7 text-black fw-semibold invis">Spam</div>
                                                        <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #6D788D !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_spam_lead_view" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($spamDate))), ENT_QUOTES, 'UTF-8'). '"  data-leads="' . htmlspecialchars(json_encode($dailySpamDetails), ENT_QUOTES, 'UTF-8') . '" onclick="showSpamDetails(this)">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details">' . sprintf("%02d",$spamCountValue) . '</span>
                                                        </a>
                                                    </div>';
                                                    
                                                    if(isset($cloud_call_access) && $cloud_call_access!=''){  
                                                        echo '<hr class="border-bottom border-dashed border-gray-400i mt-2 mb-2 invis invis"><div class="d-flex align-items-center justify-content-between gap-2 mb-1">
                                                            <div class="fs-7 text-black fw-semibold invis">Cloud Call</div>
                                                            <a href="javascript:;" class="badge text-white fs-6 fw-semibold rounded" style="background-color: #FF6563 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_cloud_lead_view" data-date="' . htmlspecialchars(json_encode(date('d-M-Y', strtotime($cloudDate))), ENT_QUOTES, 'UTF-8'). '" data-leads="' . htmlspecialchars(json_encode($cloudCallDetail), ENT_QUOTES, 'UTF-8') . '" onclick="showCloudDetails(this)">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Details"> ' . sprintf("%02d",$cloudCount) . '</span>
                                                            </a>
                                                        </div>';
                                                    }
                                            
                                          echo '</td>';
                                        }
                                        
                                          $dayCounter++;
                                      }
                                  @endphp
                                @endforeach
                            </tr>
                            @endfor
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - View Lead-->
    <div class="modal fade" id="kt_modal_total_lead_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                <span class="svg-icon svg-icon-1">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                </svg>
                </span>
            </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
            <div class="mb-6">
                <h3 class="text-center text-black">Lead List - [<span class="text-danger" id="date_lead"></span>]</h3>
            </div>
            <div class="row">
                <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px text-center">Lead</th>
                            <th class="min-w-200px text-center">Lead Source</th>
                            <th class="min-w-200px text-center">Sales Person</th>
                        </tr>
                    </thead>
                    @php
                        $currentDate = date('Y-m-d'); // Get current date in YYYY-MM-DD format
                    @endphp
                    <tbody class="text-gray-600 fw-semibold fs-7" id="total_lead_div">
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
<!--end::Modal - View Lead-->  
<!--begin::Modal - View Customer-->
    <div class="modal fade" id="kt_modal_convert_lead_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
        <!--begin::Modal header-->
        <div class="modal-header justify-content-end border-0 pb-0">
            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
            <span class="svg-icon svg-icon-1">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                </svg>
            </span>
            </div>
        </div>
        <!--end::Modal header-->
        <!--begin::Modal body-->
        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
            <div class="mb-6">
            <h3 class="text-center text-black">Customer List - [<span class="text-danger" id="date_cus"></span>]</h3>
            </div>
            <div class="row">
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                <thead>
                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                        <th class="min-w-150px text-center">Customer</th>
                        <th class="min-w-150px text-center">Sales Person</th>
                    </tr>
                </thead>
                @php
                    $currentDate = date('Y-m-d'); // Get current date in YYYY-MM-DD format
                @endphp
                <tbody class="text-gray-600 fw-semibold fs-7" id="lead_convert_div">
                </tbody>
                </table>
            </div>
            </div>
        </div>
        </div>
    </div>
    </div>
<!--end::Modal - View Customer-->  
<!--begin::Modal - View Spam Lead-->
    <div class="modal fade" id="kt_modal_spam_lead_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                <span class="svg-icon svg-icon-1">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                </svg>
                </span>
            </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
            <div class="mb-6">
                <h3 class="text-center text-black">Spam Lead List - [<span class="text-danger" id="date_spam"></span>]</h3>
            </div>
            <div class="row">
                <div class="col-lg-12">
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px text-center">Lead</th>
                            <th class="min-w-200px text-center">Lead Source</th>
                            <th class="min-w-200px text-center">Sales Person</th>
                        </tr>
                    </thead>
                    @php
                        $currentDate = date('Y-m-d'); // Get current date in YYYY-MM-DD format
                    @endphp
                    <tbody class="text-gray-600 fw-semibold fs-7" id="lead_spam_div">
                    </tbody>
                </table>
                </div>
            </div>
            </div>
        </div>
        </div>
    </div>
<!--end::Modal - View Spam Lead-->
<!--begin::Modal - View Cloud Lead-->
    <div class="modal fade" id="kt_modal_cloud_lead_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                </span>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <div class="mb-6">
                <h3 class="text-center text-black">Cloud Call Lead List - [<span class="text-danger" id="date_cloud"></span>]</h3>
                </div>
                <div class="row">
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page_scroll3">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-200px text-center">Lead</th>
                            <th class="min-w-100px text-center">Lead Status</th>
                            <th class="min-w-200px text-center">What</th>
                            <th class="min-w-150px text-center">Start / End Time</th>
                            <th class="min-w-200px text-center">Sales Person / Duration</th>
                        </tr>
                    </thead>
                    @php
                        $currentDate = date('Y-m-d'); // Get current date in YYYY-MM-DD format
                    @endphp
                    <tbody class="text-gray-600 fw-semibold fs-7" id="lead_cloud_div">
                    </tbody>
                    </table>
                </div>
                </div>
            </div>
            </div>
        </div>
    </div>
<!--end::Modal - View Cloud Lead-->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    {{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script> --}}
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
      function month_filter(val) {
        var url = "{{ url('/') }}";
        window.location = url + '/lead_calendar/?month_filter=' + val;
        
    }

    </script>
    <script>
        // Function to display lead details in the modal
        function showLeadDetails(element) {
            const leadDetails = JSON.parse(element.getAttribute('data-leads'));
            const date = JSON.parse(element.getAttribute('data-date'));
            console.log("Lead Details:", leadDetails);  // Log to check the data passed to this modal
            console.log("Lead Date:", date);  // Log to check the data passed to this modal
            
            const leadTableBody = document.querySelector('#total_lead_div');
            let content = '';
            
            // Pass the date into the <span id="date_lead"></span>
            document.querySelector('#date_lead').innerHTML = date;
            leadTableBody.innerHTML = '';
            if (leadDetails.length > 0) {
                leadDetails.forEach(lead => {
                    const staffName = lead.staff_name || 'Old Staff';
                    const sourceName = lead.lead_source_name || 'Direct Spam';
                    content += `
                        <tr>
                            <td>
                                ${lead.lead_name} 
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary"><span class="badge text-white" style="background-color: #0290cf;">${lead.lead_mobile}</span></label>
                                </div>
                            </td>
                            <td class="text-center">
                                ${sourceName} 
                            </td>
                            <td class="text-center">
                                ${staffName}
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary"><span class="badge text-black bg-warning">${lead.job_position_name|| 'Old Staff'}</span></label>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                content = '<tr><td></td><td colspan="2">No leads for this day.</td></td></tr>';
            }
    
            leadTableBody.innerHTML = content;
        }
    
        // Function to display conversion details in the modal
        function showConvertDetails(element) {
            const convertDetails = JSON.parse(element.getAttribute('data-leads'));
            const date = JSON.parse(element.getAttribute('data-date'));
            console.log("Convert Details:", convertDetails);  // Log to check the data passed to this modal
    
            const leadTableBody = document.querySelector('#lead_convert_div');
            let content = '';
            document.querySelector('#date_cus').innerHTML = date;
    
            leadTableBody.innerHTML = '';
            if (convertDetails.length > 0) {
                convertDetails.forEach(lead => {
                    const staffName = lead.staff_name || '-';
                    content += `
                        <tr>
                            <td class="text-center">
                                ${lead.cus_name} 
                                <div class="d-block">
                                <label class="fw-semibold fs-6 text-primary"><span class="badge text-white" style="background-color: #0290cf;">${lead.cus_mobile||'-'}</span></label>
                                </div>
                            </td>
                            <td class="text-center">
                                ${staffName}
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary"><span class="badge text-black bg-warning">${lead.job_position_name||'-'}</span></label>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                content = '<tr><td></td><td colspan="2">No Customers for this day.</td><td></td></tr>';
            }
    
            leadTableBody.innerHTML = content;
        }
    
        function showSpamDetails(element) {
            const spamDetails = JSON.parse(element.getAttribute('data-leads'));
            const date = JSON.parse(element.getAttribute('data-date'));
            console.log("Spam Details:", spamDetails);  // Log to check the data passed to this modal
    
            const spamableBody = document.querySelector('#lead_spam_div');
            let content = '';
            document.querySelector('#date_spam').innerHTML = date;
            spamableBody.innerHTML = '';
            if (spamDetails.length > 0) {
                spamDetails.forEach(lead => {
                    const staffName = lead.staff_name || '-';
                    const sourceName = lead.lead_source_name || 'Direct Spam';
                    content += `
                        <tr>
                            <td>
                                ${lead.lead_name} 
                                <div class="d-block">
                                <label class="fw-semibold fs-6 text-primary"><span class="badge text-white" style="background-color: #0290cf;">${lead.lead_mobile}</span></label>
                                </div>
                            </td>
                            <td class="text-center">
                                ${sourceName} 
                            </td>
                            <td class="text-center">
                                ${staffName}
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary"><span class="badge text-black bg-warning">${lead.job_position_name}</span></label>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                content = '<tr><td></td><td colspan="2">No Spam leads for this day.</td></tr>';
            }
    
            spamableBody.innerHTML = content;
        }
    
        var userRoleId = @json(auth()->user()->role_id);
    
        function showCloudDetails(element) {
            const cloudDetails = JSON.parse(element.getAttribute('data-leads'));
            const date = JSON.parse(element.getAttribute('data-date'));
            console.log("Cloud Details:", cloudDetails);  // Log to check the data passed to this modal
    
            const cloudTableBody = document.querySelector('#lead_cloud_div');
            let content = '';
            document.querySelector('#date_cloud').innerHTML = date;
            cloudTableBody.innerHTML = '';
            if (cloudDetails.length > 0) {
                cloudDetails.forEach(lead => {
                    const staffName = lead.staff_name || '-';
                    const leadName = lead.lead_name || '-';
                    let leadStatusLabel = '';
    
                    // Determine lead status label
                    if (lead.lead_status === 0) {
                        leadStatusLabel = '<label class="badge bg-info text-white rounded fw-bold fs-8 mb-2">Active</label>';
                    } else if (lead.lead_status === 1) {
                        leadStatusLabel = '<label class="badge bg-warning text-white rounded fw-bold fs-8 mb-2">In Active</label>';
                    } else if (lead.lead_status === 4) {
                        leadStatusLabel = '<label class="badge bg-success text-white rounded fw-bold fs-8 mb-2">Customer</label>';
                    } else if (lead.lead_status === 10) {
                        leadStatusLabel = '<label class="badge bg-success text-white rounded fw-bold fs-8 mb-2">Old Customer</label>';
                    } else if (lead.lead_status === 5) {
                        if (lead.drop_verified === 0 || lead.drop_tl_verified === 0) {
                            leadStatusLabel = '<label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2">Dead Lead Awaiting</label>';
                        } else if (lead.drop_verified === 1 && [12, 18, 20, 21].includes(userRoleId)) { // Use userRoleId here
                            leadStatusLabel = '<label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2">Dead Lead</label>';
                        } else {
                            leadStatusLabel = '<label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2">Dead Lead Awaiting</label>';
                        }
                    } else if (lead.lead_status === 7) {
                        if (lead.spam_verified === 0 || lead.spam_tl_verified === 0) {
                            leadStatusLabel = '<label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2">Spam Awaiting</label>';
                        } else if (lead.spam_verified === 1 && [12, 18, 20, 21].includes(userRoleId)) { // Use userRoleId here
                            leadStatusLabel = '<label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2">Spam</label>';
                        } else {
                            leadStatusLabel = '<label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2">Spam Awaiting</label>';
                        }
                    } else if (lead.lead_status === 8) {
                        leadStatusLabel = '<label class="badge bg-warning text-primary rounded fw-bold fs-8 mb-2">OLD Lead</label>';
                    }
    
                    content += `
                        <tr>
                            <td>
                                ${leadName}
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary">
                                        <span class="badge text-white" style="background-color: #0290cf;">${lead.caller_number}</span>
                                    </label>
                                </div>
                            </td>
                            <td class="text-center">
                                ${leadStatusLabel}
                            </td>
                            <td>
                                <label class="fs-7">
                                    ${lead.action ? `Call ${lead.action ?? '-'} by ${lead.received_by ?? '-'} at (${lead.department_name})` : '-'}
                                </label>
                            </td>
                            <td>
                                <label class="fw-semibold fs-6 text-primary mb-1">
                                    <span class="badge bg-success text-white">${lead.start_time}</span>
                                </label>
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary">
                                        <span class="badge bg-danger text-white">${lead.end_time}</span>
                                    </label>
                                </div>
                            </td>
                            <td class="text-center">
                                ${staffName}
                                <div class="d-block">
                                    <label class="fw-semibold fs-6 text-primary">
                                        <span class="badge text-black bg-warning">${lead.duration}</span>
                                    </label>
                                </div>
                            </td>
                        </tr>
                    `;
                });
            } else {
                content = '<tr><td></td><td colspan="5">No Cloud leads for this day.</td></tr>';
            }
    
            cloudTableBody.innerHTML = content;
        }
    </script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const areaChartE2 = document.querySelector('#graph_lead_cal_view');
            const borderColor = '#ddd'; // Define borderColor
    
            // PHP data passed to JavaScript via JSON
            const dateData = @json($dateData_garph);
    
            const leadCounts = dateData.map(item => item.lead_count);
            const customerCounts = dateData.map(item => item.customer_count);
            const dropCounts = dateData.map(item => item.spam_count);
            const cloudCounts = dateData.map(item => item.cloud_count);
            const formattedDates = dateData.map(item => {
                const date = new Date(item.Date);
                const options = { day: '2-digit' };
                return date.toLocaleDateString('en-GB', options); // 'en-GB' format ensures day-month-year
            });
    
            const areaChartConfig_1 = {
            chart: {
                height: 400,
                fontFamily: 'Inter',
                type: 'area',
                toolbar: {
                show: false
                }
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                curve: 'smooth',
                style: {
                colors: 'black',
                }
            },
            legend: {
                show: true,
                position: 'bottom',
                horizontalAlign: 'right',
                labels: {
                colors: 'black',
                fontSize: '14px',
                fontWeight: 'bold',
                useSeriesColors: false
                },
            },
            grid: {
                borderColor: borderColor,
                xaxis: {
                lines: {
                    show: true
                }
                }
            },
            series: [
                {
                name: 'Cloud Call Lead',
                data: cloudCounts,
                color: '#fd5957',
                },
                {
                name: 'Total Lead', 
                data: leadCounts,
                color: '#1c9151',
                },
                {
                name: 'Converted Customer',
                data: customerCounts,
                color: '#39c0ea',
                },
                {
                name: 'Spam Lead',
                data: dropCounts,
                color: '#6d788d',
                }
            ],
            xaxis: {
                categories: formattedDates,
                axisBorder: {
                show: false
                },
                axisTicks: {
                show: false
                },
                labels: {
                style: {
                    colors: 'black',
                    fontSize: '9px',
                    fontWeight: 'bold'
                }
                }
            },
            yaxis: {
                labels: {
                style: {
                    colors: 'black',
                    fontSize: '10px',
                    fontWeight: 'bold'
                },
                formatter: function(value) {
                    return value;
                }
                },
            },
            fill: false,
            tooltip: {
                shared: true,
                followCursor: true,
                y: {
                formatter: function(value, { seriesIndex }) {
                    const seriesName = seriesIndex === 0 ? 'Total Lead' : seriesIndex === 1 ? 'Converted Customer' : seriesIndex === 2 ? 'Spam Lead' : 'Cloud Call Lead';
                    return `${value}`;
                }
                },
                theme: 'light',
            }
            };
    
            if (areaChartE2) {
            const areaChart = new ApexCharts(areaChartE2, areaChartConfig_1);
            areaChart.render();
            }
        });
    </script>
@endsection