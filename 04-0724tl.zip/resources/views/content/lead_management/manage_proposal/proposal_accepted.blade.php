@extends('layouts/blankLayout')

@section('title', 'Proposal Confirmation')
@section('content')

<style>
    /* page[size="A4"] {
        width: 210mm !important;
        height: 297mm !important;
        box-sizing: border-box;
        margin: 0 auto;
        margin-bottom: 0.5cm;
    } */

    @media print {

        /* @page {
            margin-top: 10px;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            /* padding-top: 100px !important; */
        }

        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            z-index: 1000;
        } */

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            break-inside: avoid !important;
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }










    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
</style>
   @php 
        $helper = new \App\Helpers\Helpers();
        $encryptedValue = $helper->encrypt_decrypt($encrypt_id,'encrypt',);
    @endphp
<center>
    <div class="p-5 mt-0 w-lg-45 w-md-100 w-sm-100">
        <div class="border border-gray-500i rounded p-10" style="background: linear-gradient(#70e1f5,white);">
            <h6 class="text-center text-black fw-bold fs-1">Thank You for Accepting the Proposal!</h6>
            <div class="mb-0">
                <img src="{{ asset('assets/phdizone_images/handshake.gif') }}" alt="congrats logo" class="image-input-wrapper w-375px h-300px" id="showlogo">
            </div>
            <div class="text-center">
                <h6 class="text-black fs-3 fw-bold"><span class="me-2">Proposal ID</span> :<span class="fs-3 ms-3">{{$proposal->proposal_id}}</span></h6>
            </div>
            <div class="">
                <span class="text-black text-center fs-5">We appreciate your trust and look forward to working with you. </span>
            </div>
            <div class="">
                <span class="text-info text-center fs-5"> Redirect to Payment in <span id="timer">05</span> </span>
            </div>
        </div>
    </div>
</center>


<script>
  let timeLeft = 5; // seconds
  const encrypted_lead_id = '{{$encryptedValue}}'; // seconds
  const timerElement = document.getElementById('timer');

  const countdown = setInterval(() => {
    timeLeft--;
    // Display leading zero for single digit numbers
    timerElement.textContent = timeLeft < 10 ? '0' + timeLeft : timeLeft;

    if (timeLeft <= 0) {
      clearInterval(countdown);
    //   window.close();
    //  window.location.href = 'https://www.google.com/'; 
      window.location.href = '/manage_proposal/payments/' + encrypted_lead_id;
    //  window.location.replace('https://www.google.com/');
    }
  }, 1000);
</script>
<!-- <script>
    window.onload = function() {
        setTimeout(function() {
            window.close();
        }, 5000);
    };
</script> -->
@endsection