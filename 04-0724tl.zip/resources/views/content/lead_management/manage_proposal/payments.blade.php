@extends('layouts/blankLayout')

<title>Invoice | {{$proposal->lead_name }} | PhDiZone | {{$invoice_id}}</title>
@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
])
@endsection

@section('page-script')
@endsection
@section('content')

<style>
    /* page[size="A4"] {
        width: 210mm !important;
        height: 297mm !important;
        box-sizing: border-box;
        margin: 0 auto;
        margin-bottom: 0.5cm;
    } */
         /* FIXED HEADER & FOOTER */
    .page-header {
        position: relative;
        left: 50%;
        transform: translateX(-50%);
        width: 210mm;
        background: white;
        height: 100px;
        border-bottom: 1px solid #ccc;
    }

    .desktop_view{
        display: block !important;
    }

    .desktop_view > img{
        width:200mm;
    }

    .mobile_view{
        display: none !important;
    }
    
    .payment-options {
      display: flex;
      gap: 10px;
      justify-content: center;
      margin-top: 8px;
      flex-direction: row; /* default for desktop */
    }

    .page-header {
        top: 0;
        height: 100px;
        border-bottom: 1px solid #ccc;
    }
    .responsive-img {
        width: 400px;
    }

    @media (max-width: 425px) {
        .responsive-img {
            display:block;
        }

        .image_div{
            display: none;
        }
    }

    @media print {

        /* @page {
            margin-top: 10px;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            /* padding-top: 100px !important; */
        }

        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            z-index: 1000;
        } */

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        .page-header {
            position: fixed;
            left: 50%;
            transform: translateX(-50%);
            width: 100%;
            background: white;
            z-index: 10;
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            break-inside: avoid !important;
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }
      .content-wrapper {
        width: 100%;
        max-width: 210mm;
        margin: 0 auto;
        background-color: #ffffff;
        padding: 0 10px;
        box-sizing: border-box;
    }

    .bank_label {
        width: 20%;
    }

    .bank_colon {
        width: 5%;
    }

    .bank_value_label {
        width: 65%;
    }

    /* Optional: Align items horizontally */
    .bank_row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        margin-bottom: 5px;
    }


    @media (max-width: 768px) {
        .proposal-header,
        .payment-section {
            flex-direction: row !important;
            align-items: flex-start !important;
        }

        .page-header {
            width: 100% !important;
            left: 0 !important;
            transform: none !important;
            height: auto !important;
        }

        .responsive-img{
            width: 350px;
            height: 260px;
        }

        .proposal-header > div,
        .payment-section > div {
            width: 100% !important;
        }

        .a4-content {
            padding: 10px !important;
        }

        .a4-content label,
        .a4-content span,
        .a4-content td,
        .a4-content th {
            font-size: 13px !important;
        }

        .a4-content img {
            max-width: 100%;
            height: auto;
        }
        
        .proposal-id-value {
            width: 15% !important;
        }

        .content-wrapper {
            padding: 0 5px;
        }

        .desktop_view{
            display: block !important;
            width: 200mm;
        }

        .bank_label {
            width: 20%;
        }

        .bank_colon {
            width: 5%;
        }

        .bank_value_label {
            width: 65%;
        }

        /* Optional: Align items horizontally */
        .bank_row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 6px;
            margin-bottom: 5px;
        }

        .mobile_view{
            display: none !important;
        }
        
         .payment-options {
          display: flex;
          gap: 10px;
          justify-content: center;
          margin-top: 8px;
          flex-direction: row; /* default for desktop */
        }
    }
    /* Default styles */
    .label-row {
        display: flex;
        align-items: flex-start;
        justify-content: flex-start;
        gap: 4px;
    }

    .label-row label {
        font-size: 14px;
        font-weight: 600;
        color: rgb(41, 41, 41);
    }

    .label-title {
        color: #000000;
        width: 45%;
    }

    .label-separator {
        width: 3%;
    }

    .label-value {
        width: 80%;
    }
    /* Mobile responsiveness for 425px and below */
    @media (max-width: 425px) {
        .proposal-header,
        .payment-section {
            flex-direction: column !important;
            gap: 5px 20px;
            align-items: flex-start !important;
        }

        .label-row {
            align-items: center;
            justify-content: space-between;
        }

        .label-title,
        .label-separator,
        .label-value {
            width: auto !important;
        }

        .desktop_view{
            display: none !important;
        }

        .mobile_view{
            display: block !important;
        }
        
         .payment-options {
            flex-direction: column;
            align-items: flex-start;
            justify-content: center;
          }

        .bank_label {
            width: 10%;
        }

        .bank_colon {
           display:none;
        }

        .bank_value_label {
            width: 90%;
        }

        /* Optional: Align items horizontally */
        .bank_row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 6px;
            margin-bottom: 5px;
        }
        .payment-section {
        padding: 10px !important;
    }

    .payment-section > div {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
    }
    }

</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
@endphp
<center>
    <input type="hidden" name="slot_id_hidden" id="slot_id_hidden" value="{{$slot_id_hidden ?? 0}}">
    <input type="hidden" name="slot_amount_hidden" id="slot_amount_hidden" value="{{$converted_amount ?? $slot_amount_hidden}}">
    <input type="hidden" name="proposal_id_hidden" id="proposal_id_hidden" value="{{$proposal_hidden_id ?? 0}}">
    <input type="hidden" name="proposal_id_hidden" id="proposal_id_hidden" value="{{$proposal_hidden_id ?? 0}}">
    <input type="hidden" name="branch_upi_id" id="branch_upi_id" value="{{$branch_data->bank_upi_id ?? ""}}">
    <div class="content-wrapper rounded" style="border: 1px solid gray;background-color:#e0f3f9;">
        <div class="header" style="margin-bottom: 0px;">
            <div class="mobile_view" style="font-size:30px; font-weight:bold;color:black;margin:20px;">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
                    <span class="bg-white px-2">
                    <label style="font-size: 18px; font-weight: 600;color: #000000;">
                        <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" class="" width="80px" height="50px" alt="EIBS Logo">
                    </label>
                    </span>
                    <label style="font-size: 18px; font-weight: 600;color: #000000;"> Proposal Payment</label>
              </div>
            
              <div style="display: flex; align-items: center; color: black; font-size: 24px; font-weight: medium;">
                    <hr style="flex: 1; border: none; border-top: 2px solid #000; margin-right: 10px;">
                </div>

                  <div style="border: 1px solid #ccc; border-radius: 8px; background-color: white; overflow: hidden; width: 100%;">

                    <!-- Row 1: Proposal ID -->
                    <div style="border-bottom: 1px solid #ccc; padding: 12px; text-align: center;">
                        <label style="font-size: 16px; font-weight: 700; color: black;">
                            #{{ $proposal->proposal_id }} - {{ $proposal->lead_name }}
                        </label>
                    </div>

                    <!-- Row 2: Estimated Date & Validity Date -->
                    <div style="display: flex; flex-wrap: wrap; ">
                        
                        <!-- Estimated Date -->
                        <div style="flex: 1 1 50%; border-right: 1px solid #ccc; padding: 12px; text-align: center;">
                            <div style="font-size: 13px; font-weight: 500; color: black;">Estimated Date</div>
                            <div style="font-size: 12px; font-weight: 700; color: black;">
                                {{ $proposal->estimate_date ? date($common_date_format, strtotime($proposal->estimate_date)) : '-' }}
                            </div>
                        </div>

                        <!-- Validity Date -->
                        <div style="flex: 1 1 50%; padding: 12px; text-align: center;">
                            <div style="font-size: 13px; font-weight: 500; color: black;">Validity Date</div>
                            <div style="font-size: 12px; font-weight: 700; color: red;">
                                {{ $proposal->due_date ? date($common_date_format, strtotime($proposal->due_date)) : '-' }}
                            </div>
                        </div>
                    </div>

                </div>

            </div>
          <div class="desktop_view">
              <div style='display:flex;align-items:start !important;flex-wrap:wrap;padding-left:10px;padding-right:10px;padding-top:10px;'>
                <div class="table-responsive" style="width:100% !important;padding-left: 10px !important;padding-right: 10px !important; ">
                    <table style='width:100% !important;background-color:white;'>
                        <thead>
                            <tr>
                                <th rowspan="2" style="width: 10% !important;">
                                    <img src="{{asset('assets/phdizone_images/phdizone_logo.png')}}" style="height: 80px;width: 180px;">
                                </th>
                                <th style="text-align: center; width: 90% !important;" colspan="2">
                                    <label style="font-size:16px;font-weight:700;margin-left:50px;color:black;"># {{$proposal->proposal_id}} -  {{$proposal->lead_name }}</label>
                                </th>
                            </tr>
                            <tr>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Estimated Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:black;">{{ $proposal->estimate_date ? date($common_date_format, strtotime($proposal->estimate_date)) :'-' }}</label>
                                    </div>
                                </th>
                                <th style="text-align: center !important;width: 20% !important;">
                                    <label style="font-size:14px;font-weight:500;color:black;">Validity Date</label>
                                    <div style="display: block !important;">
                                        <label style="font-size:13px;font-weight:700;color:red;">{{ $proposal->due_date ? date($common_date_format, strtotime($proposal->due_date)) :'-' }}</label>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
              </div>
              <div style="display: flex; align-items: center; color: black; font-size: 24px; font-weight: medium;">
                  <hr style="flex: 1; border: none; border-top: 2px solid #000; margin-right: 10px;">
                  Proposal Payment
                  <hr style="flex: 1; border: none; border-top: 2px solid #000; margin-left: 10px;">
              </div>
          </div>
            <div class="proposal-header" style="display:flex;justify-content:space-between;align-items:center;gap:10px 30px;margin-right:20px;margin-left:20px;padding-top:5px">
                
            </div>
        </div>
        <div style="margin-right:20px;margin-left:20px;margin-top:0px;margin-bottom:20px;">
            <div class="payment-section" style="
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 10px;
                align-items: center;
                justify-content: center;
                padding: 10px;
                margin-bottom:10px;
            ">

                <!-- Payment Card -->
                <div style="flex: 1;min-width: 300px;">
                    <div class="card" style="height: 100%;background-color: white; border-radius: 12px; text-align: center; padding: 20px;">
                        <h3 style="margin-bottom: 15px; font-size: 22px; color: #333;">Complete Your Payment</h3>
                        <div style="margin-bottom: 10px; font-size: 24px; font-weight: bold; color: #e60000;">
                            <span  style="padding-right: 5px; ">{{$proposal->currency_symbol }}</span>{{$converted_amount ? number_format($converted_amount, 2, '.', '') : $slot_amount_hidden}} /-
                        </div>
                        
                        <div id="payment_mode_container">
                          <label style="font-weight: 600; color: #000000; margin-bottom: 8px; font-size: 18px;">Select Payment Mode:</label><br>
                          <div class="payment-options">
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" id="pay_online" value="1" name="paymt_md" onchange="payment_mode_func('online');" checked/>
                              <label class="form-check-label" for="pay_online">Online</label>
                            </div>
                            <div class="form-check form-check-inline">
                              <input class="form-check-input" type="radio" id="pay_offline" value="1" name="paymt_md" onchange="payment_mode_func('offline');"/>
                              <label class="form-check-label" for="pay_offline">Offline</label>
                            </div>
                            <!--<div class="form-check form-check-inline">-->
                            <!--  <input class="form-check-input" type="radio" id="pay_later" value="1" name="paymt_md" onchange="payment_mode_func('pay_later');"/>-->
                            <!--  <label class="form-check-label text-nowrap" for="pay_later">Pay Later</label>-->
                            <!--</div>-->
                          </div>
                        </div>
                        
                        <div id="online_Button" style="width:100%;display:flex; align-items:center;justify-content:center;">
                        <button type="button"  class="btn btn-primary bg-primary  fs-4 gap-1 fw-bold d-flex align-item-center" style="background-color: white;" onclick="confirm_func()">
                            <span>Pay Now</span>
                            <img src="{{asset('assets/phdizone_images/proposal/rotate_coin.gif')}}" style="width: 50px;">
                        </button>
                        </div>
                    </div>
                </div>
                <!-- QR Code Box -->
                 @if(!empty($branch_data->bank_upi_id))
                <div class="offline_box " style="flex: 1;min-width: 300px;">
                    <div style="height: 100%;max-width: 100%; display:flex;flex-direction:column; align-items:center; justify-content:center; text-align: center; padding: 10px; border-radius: 8px; background: white; box-shadow: 0px 2px 4px rgba(0,0,0,0.2);" class="image_div">
                        <span style="font-size: 12px; font-weight: 600;">Scan Qr to Pay</span>
                        <span style="font-size: 14px; font-weight: 600;" class="text-primary" >ELYSIUM TECHNOLOGIES PRIVATE LIMITED</span>
                        <img
                            style="width: 150px; height:150px; padding: 10px;border:1px solid black;border-radius:4px;"
                            src=""
                            alt="QR"
                            class="responsive-img"
                            id="upi_qrImage"
                        />
                        <div style="font-size: 11px; margin: 4px 0; font-weight: 600; display: flex; align-items: center; justify-content: center; gap: 3px; flex-wrap: nowrap;">
                            <span >UPI ID: <span class="text-truncate w-140px" id="upiText">{{$branch_data->bank_upi_id ?? ""}}</span></span>
                            <span class="mdi mdi-content-copy cursor-pointer" style="font-size: 10px; font-weight: 600;" onclick="copyUPI()"></span>
                        </div>
                    </div>  
                </div>
                @endif
                
            </div>

             <div class="card" id="bank_details" style="text-align:start;display: none;background-color: white;padding: 20px;">
                <h7 style="font-weight:600;font-size:16px;color: #000000;"><strong>Bank Transfer</strong></h7>
                <div style="margin-top: 5px; border-radius: 5px;">
                    <!-- bank detail rows as you provided -->
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>Bank Name</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Bank Name"><i class="mdi mdi-bank fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label" style="font-weight:400; font-size:14px;text-transform: Uppercase;color: green;"><strong>{{$branch_data->bank_name ??''}}</strong></label>
                    </div>
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>Account Holder</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Account Holder Name"><i class="mdi mdi-account-circle-outline fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label"  style="font-weight:400; font-size:14px;text-transform: Uppercase;text-wrap:wrap; color: green;"><strong>ELYSIUM TECHNOLOGIES PRIVATE LIMITED</strong></label>
                    </div>
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>Account No</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Account Number"><i class="mdi mdi-card-account-details-outline fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label"  style="font-weight:400; font-size:14px;color: green;"><strong>{{$branch_data->bank_account_no ??''}}</strong></label>
                    </div>
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>Branch</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Branch"><i class="mdi mdi-credit-card-edit-outline fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label"  style="font-weight:400; font-size:14px;color: green;"><strong>{{$branch_data->bank_branch ??''}}</strong></label>
                    </div>
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>IFSC Code</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="IFSC Code"><i class="mdi mdi-bank-check fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label"  style="font-weight:400; font-size:14px;color: green;"><strong>{{$branch_data->bank_ifsc ??''}}</strong></label>
                    </div>
                    <div class="bank_row">
                        <label class="desktop_view bank_label" style="font-weight:500; font-size:14px;color: #000000;"><strong>SWIFT Code</strong></label>
                        <label class="mobile_view bank_label" data-bs-toggle="tooltip" data-bs-placement="bottom" title="SWIFT Code"><i class="mdi mdi-airplane fs-4 text-black"></i></label>
                        <label class="desktop_view bank_colon" style="font-weight:500; font-size:14px;"><strong>:</strong></label>
                        <label class="bank_value_label"  style="font-weight:400; font-size:14px;color: green;"><strong>{{$branch_data->bank_swift_code ??''}}</strong></label>
                    </div>
                </div>
            </div>

            <div class="card offline_box" style="text-align:start; margin-top:10px; background-color: white; padding: 20px;">
                <!-- Description -->
                <!--<div class="mb-3" style="">-->
                <!--    <label for="description" style="font-weight:500; font-size:14px; color:#000000;"><strong>Description</strong></label>-->
                <!--    <textarea class="form-control" id="description" name="description" rows="2" placeholder="Enter payment description..."></textarea>-->
                <!--</div>-->

                <!-- File Upload -->
                <!--<div class="mb-3">-->
                <!--    <label for="fileUpload" style="font-weight:500; font-size:14px; color:#000000;"><strong>Upload Payment Screenshot</strong></label>-->
                <!--    <div id="dropZone" style="-->
                <!--        border: 2px dashed #099dda;-->
                <!--        border-radius: 8px;-->
                <!--        padding: 20px;-->
                <!--        text-align: center;-->
                <!--        background-color: #f9f9f9;-->
                <!--        cursor: pointer;-->
                <!--        transition: background-color 0.2s ease;-->
                <!--    ">-->
                <!--        <p style="margin: 0; color: #333;">Drag and drop a file here, or click to select</p>-->
                <!--        <input type="file" id="fileUpload" name="payment_proof" style="display: none;" onchange="handleFileSelect(this)">-->
                <!--    </div>-->
                <!--    <div id="fileName" style="margin-top: 10px; font-size: 14px; font-weight: 500; color: green;"></div>-->
                <!--</div>-->

                <!-- Submit Button -->
                <button type="button" class="btn btn-primary bg-primary  mt-2" onclick="confirm_func()">
                    Submit
                </button>
            </div>
            
            <div class="card " id="paylater_box" style="text-align:start; margin-top:10px; background-color: white; padding: 20px;">
                <!-- Description -->
                <div class="mb-3" style="">
                    <label for="description" style="font-weight:500; font-size:14px; color:#000000;"><strong>Reason</strong><span class="text-danger">*</span></label>
                    <textarea class="form-control" id="reason_later" name="reason_later" rows="2" placeholder="Enter Reason..."></textarea>
                </div>
                    <div class="text-danger" id="reason_later_err"></div>
                <!-- Submit Button -->
                <button type="button" class="btn btn-primary bg-primary  mt-2" onclick="paylater_func()">
                    Pay Later
                </button>
            </div>

           
           
        </div>
    </div>
</center>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        
    </style>
     <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>

<script>
   payment_mode_func('online');
     function payment_mode_func(val) {
        const bankDetails = document.getElementById("bank_details");
        const online_Button = document.getElementById("online_Button");
        if (val == 'online') {
              bankDetails.style.display = "none";
              $('#online_Button').show();
              $('.offline_box').hide();
               $('#paylater_box').hide();
          
        } else if(val == 'offline'){
            bankDetails.style.display = "block";
            $('#online_Button').hide();
             $('#paylater_box').hide();
            $('.offline_box').show();
           
        }else{
            bankDetails.style.display = "none";
            $('#paylater_box').show();
            $('.offline_box').hide();
            $('#online_Button').hide();
        }

        
        
    }


    function close_tab() {
        window.close();
    }
</script>

<script>

     function confirm_func() {

        let err = 0;

        var pay_mode ='';
        var offlineCheck = $('#pay_offline');
        var onlineCheck = $('#pay_online');

        const transaction_id = $('#transaction_id').val();
        const description = $('#description').val();
        // const fileInput = document.getElementById('fileUpload');
        // const file = fileInput.files[0];

        if (offlineCheck.is(':checked')) {
            pay_mode = 'Offline';
            // if (transaction_id === '') {
            //     $('#transaction_id_err').text('Please Enter Transaction ID.');
            //     err++;
            // } else {
            //     $('#transaction_id_err').text('');
            // }
            
            // if (file) {
            //     const maxSizeMB = 5;
            //     const maxSizeBytes = maxSizeMB * 1024 * 1024;
            //     if (file.size > maxSizeBytes) {
            //         err++;
            //         toastr.error("File size must be less than 5 MB.");
            //     }
            // }

        }else if(onlineCheck.is(':checked')){
            pay_mode = 'Online';
        }

        // Proceed only if there are no validation errors
        if (err === 0) {
             const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            const formData = new FormData();
            formData.append('slot_id', $('#slot_id_hidden').val());
            formData.append('slot_amount', $('#slot_amount_hidden').val());
            formData.append('proposal_id', $('#proposal_id_hidden').val());
            formData.append('pay_mode', pay_mode);
            formData.append('transaction_id', description);
            // formData.append('payment_proof', file);

            // const slot_id = $('#slot_id_hidden').val();
            // const slot_amount = $('#slot_amount_hidden').val();
            // const proposal_id = $('#proposal_id_hidden').val();

        

            $.ajax({
                url: '/create_transaction',
                 method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                processData: false,
                contentType: false,
                data: formData,
                success: function(response) {
                    if (response.status === 200) {
                        if (response.pay_mode == 'Online') {
                            // Proposal accepted
                            window.location.href = '/invoice_pay/' + response.id;
                        } else {
                            // Proposal rejected or other
                             const newTabUrl = '/offline_payment_success/' + response.id;
                             const newTab = window.open(newTabUrl, '_blank');
                
                                // Show a quick toast before closing current tab
                                toastr.success('Thank you');
                    
                                setTimeout(() => {
                                    // Close current tab (works if it was opened via JS)
                                    window.close();
                                }, 100);
                        }
                    } else {
                        toastr.error(response.message || 'Failed to confirm proposal.');
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to confirm proposal.';
                    toastr.error(errorMsg);
                }
            });
        }
        //  blockExit = false;
    }
</script>

<script>
    function paylater_func() {

        let err = 0;

        var pay_mode ='';
        var pay_later = $('#pay_later');

        const transaction_id = $('#transaction_id').val();
        const description = $('#reason_later').val();

        if (pay_later.is(':checked')) {
            pay_mode = 'pay_later';

        }
        
      
              if (description === '') {
                $('#reason_later_err').text('Please Enter Reason For Pay Later.');
                err++;
            } else {
                $('#reason_later_err').text('');
            }
        

        // Proceed only if there are no validation errors
        if (err === 0) {
             const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

            const formData = new FormData();
            formData.append('slot_id', $('#slot_id_hidden').val());
            formData.append('slot_amount', $('#slot_amount_hidden').val());
            formData.append('proposal_id', $('#proposal_id_hidden').val());
            formData.append('pay_mode', pay_mode);
            formData.append('reason', description);

            $.ajax({
                url: '/pay_later',
                 method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    },
                processData: false,
                contentType: false,
                data: formData,
                success: function(response) {
                    if (response.status === 200) {
                        // if (response.pay_mode == 'Online') {
                        //     // Proposal accepted
                        //     window.location.href = '/invoice_pay/' + response.id;
                        // } else {
                            // Proposal rejected or other
                            toastr.success('Thank you');
                            setTimeout(() => {
                                window.close();
                                window.location.href = 'https://www.google.com/'; 
                            }, 1000);
                        // }
                    } else {
                        toastr.error(response.message || 'Failed to confirm proposal.');
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to confirm proposal.';
                    toastr.error(errorMsg);
                }
            });
        }
        //  blockExit = false;
    }
</script>


<script>
    // const dropZone = document.getElementById('dropZone');
    // const fileInput = document.getElementById('fileUpload');
    // const fileName = document.getElementById('fileName');
    
    // // Click to open file selector
    // dropZone.addEventListener('click', () => fileInput.click());
    
    // // Highlight on drag
    // dropZone.addEventListener('dragover', (e) => {
    //     e.preventDefault();
    //     dropZone.style.backgroundColor = '#e6f2ff';
    // });
    
    // dropZone.addEventListener('dragleave', () => {
    //     dropZone.style.backgroundColor = '#f9f9f9';
    // });
    
    // // Drop file
    // dropZone.addEventListener('drop', (e) => {
    //     e.preventDefault();
    //     fileInput.files = e.dataTransfer.files;
    //     handleFileSelect(fileInput);
    //     dropZone.style.backgroundColor = '#f9f9f9';
    // });
    
    // // Display file name
    // function handleFileSelect(input) {
    //     if (input.files.length > 0) {
    //         fileName.textContent = "Selected File: " + input.files[0].name;
    //     } else {
    //         fileName.textContent = "";
    //     }
    // }
</script>


<!-- <script>
    let blockExit = false;

    $(document).ready(function () {
        $('#pay_offline').on('change', function () {
            if ($(this).is(':checked')) {
                blockExit = true;
            }
        });

        $('#pay_online').on('change', function () {
            if ($(this).is(':checked')) {
                blockExit = false;
            }
        });

        // Prevent closing or navigating away
        window.addEventListener('beforeunload', function (e) {
            if (blockExit) {
                e.preventDefault();
                e.returnValue = ''; // Required for modern browsers
            }
        });
    });

   
</script> -->

<script>
    function copyUPI() {
        const upiText = document.getElementById("upiText").textContent.trim();

        const tempInput = document.createElement("input");
        tempInput.style.position = "absolute";
        tempInput.style.left = "-9999px";
        tempInput.value = upiText;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand("copy");
        document.body.removeChild(tempInput);

        // Optional: Toastr or alert for feedback
        toastr.success("UPI ID copied!");
    }
</script>
<script>
function generateUPIUrl(amount, name, upi) {
    return `upi://pay?pa=${encodeURIComponent(upi)}&pn=${encodeURIComponent(name)}&am=${encodeURIComponent(amount)}&cu=INR`;
}

function setUPIQRImage() {
    const upi_id = $('#branch_upi_id').val();
    const name = 'ELYSIUM TECHNOLOGIES PRIVATE LIMITED';
    const amount = ''; // Optional: leave blank or set a default value

    const upiUrl = generateUPIUrl(amount, name, upi_id);

    // Use QRServer API (Free and works without issues)
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(upiUrl)}&size=200x200`;

    document.getElementById('upi_qrImage').src = qrUrl;

    console.log('UPI URL:', upiUrl);
    console.log('QR Image URL:', qrUrl);
}

setUPIQRImage();
  
</script>

@endsection