@extends('layouts/layoutMaster')

@section('title', 'Create Proposal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
'resources/assets/vendor/libs/tagify/tagify.scss',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
'resources/assets/vendor/libs/tagify/tagify.js',
'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection
@section('content')

 @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
    @endphp

<style>
    
    .select2-container--default .select2-results__option[aria-selected=true] {
      background-color: #F6CF99 !important; /* Light green (Bootstrap-style) */
      color: #B85D00 !important;            /* Dark green text */
    }
    
    /* Hovered + selected option (improves visibility when hovering) */
    .select2-container--default .select2-results__option--highlighted[aria-selected=true] {
      background-color: #f0913d !important; /* Bootstrap's green */
      color: white !important;
    }
   
    .list-group-item {
        background-color: #efdaff;
        color: #333;
        border: 1px solid #5c5c5c;
        transition: background-color 0.3s, color 0.3s;
    }

    .list-group-item:hover {
        background-color: #d1b3ff;
        color: #000;
    }

    .list-group-item.active,
    .list-group-item:active {
        background-color: #099DDA !important;
        color: #fff !important;
        border-color: #099DDA !important;
    }

    .select2-selection__choice {
        text-wrap: wrap !important;
    }
      .bg-label-success_card{
            background-color: rgb(139 234 182) !important;
            color: #50cd89 !important;
        }
        
        .duration_field {
          white-space: nowrap;
          width: 110px; /* adjust as needed */
          display: inline-block;
        }
</style>
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Create Proposal</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Proposal</a> 
                </li>
            </ol>
        </nav>
    </div>
    <form  method="POST" action="{{ route('create_proposal') }}" enctype="multipart/form-data" autocomplete="off" id="addProposalForm">
    @csrf
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{ isset($lead->registered_date) ? date($common_date_format, strtotime($lead->registered_date)) :date($common_date_format, strtotime($lead->created_at))}}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{ $lead->lead_name }}</label>
                </div>
            </div>

            <input type="hidden" name="proposal_hidden_id" id="proposal_hidden_id" value="{{$proposal_id}}">
            <input type="hidden" name="proposal_lead_id" id="proposal_lead_id" value="{{$lead->sno}}">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Mobile No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{ $lead->lead_mobile }}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{ $lead->lead_email_id ?? '-' }}</label>
                </div>
                <!-- <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India - 625012</label>
                </div> -->
            </div>
            <!-- <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Work Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control me-2" placeholder="Enter Work Name" />
            </div>
            <div class="col-lg-4">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                <select id="payment_slot" class="select3 form-select" data-style="btn-default" data-live-search="true">
                    <option value="">Select Payment Slot</option>
                    <option value="1">Single Slot</option>
                    <option value="2">Dual Slot</option>
                </select>
            </div> -->
        </div>
        <div class="divider divider-primary mb-4 mt-0">
            <div class="divider-text fs-3 text-black fw-semibold">Service Details</div>
        </div>
        <div class="row">
            <div class="col-lg-3 d-flex align-items-center flex-wrap gap-3 mb-4">
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px" type="radio" id="serv_prod_chk" value="1" name="serv_prod_pckg_chk" onclick="service_add_func('product');" @if(!isset($packageSlot)) checked @endif />
                    <label class="form-check-label fs-4 fw-semibold text-black">Products</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px" type="radio" id="serv_pckg_chk"  value="2" name="serv_prod_pckg_chk" @if(isset($packageSlot)) checked @endif onclick="service_add_func('package');" />
                    <label class="form-check-label fs-4 fw-semibold text-black">Packages</label>
                </div>
            </div>
            
            <div class="col-lg-8 row">
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service Title<span class="text-danger">*</span></label>
                    <input type="text" class="form-control me-2" placeholder="Enter Service Title" name="prposal_service_title" id="service_title" value="{{$preProposal->service_title ?? ''}}" />
                    <div class="text-danger fs-8 fw-semibold" id="service_title_err"></div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Estimate Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="estimate_date" name="estimate_date" placeholder="Select Date" class="form-control common_date_class" value="{{$preProposal->estimate_date ? date($common_date_format, strtotime($preProposal->estimate_date)) : date('d-M-Y')}}" />
                    </div>
                    <div class="text-danger fs-8 fw-semibold" id="estimate_date_err"></div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Proposal Due Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="prposal_due_date" name="prposal_due_date" placeholder="Select Date" class="form-control common_date_class" value="{{$preProposal->due_date ? date($common_date_format, strtotime($preProposal->due_date)) : date('d-M-Y')}}" />
                    </div>
                    <div class="text-danger fs-8 fw-semibold" id="prposal_due_date_err"></div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                    <select class="select3 form-select" name="prposal_currency" id="prposal_currency" onchange="currency_change()" >
                       <option value="">Select Currency Format</option>
                        @if(isset($currencyList))
                        @foreach($currencyList as $clist)
                        <option  data-code="{{ $clist->currency_code }}" data-symbol="{{ $clist->currency_symbol }}"  value="{{ $clist->sno }}" @if(isset($preProposal->currency_id) && $preProposal->currency_id ==$clist->sno )selected @endif>{{ $clist->currency_code  }} - {{ $clist->currency_symbol  }} ({{$clist->country_name}})</option>
                       @endforeach
                       @endif
                    </select>
                    <div class="text-danger fs-8 fw-semibold" id="prposal_currency_err"></div>
                </div>
                <input type="hidden" name="prposal_currency" id="prposal_currency_hidden" >
                <div class="col-lg-4  mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold duration_field">Delivery Duration Start <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Duration Start" name="delivery_duration" id="delivery_duration" value="{{$preProposal->delivery_duration ?? ''}}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                    <div class="text-danger fs-8 fw-semibold mt-1" id="delivery_duration_err">[ In Days - Ex: 90 (or) 120 ....]</div>
                </div>
                <div class="col-lg-4  mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold duration_field">Delivery Duration End <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Duration End" name="delivery_duration_end" id="delivery_duration_end" value="{{$preProposal->delivery_duration_end ?? ''}}" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                    <div class="text-danger fs-8 fw-semibold mt-1" id="delivery_duration_end_err">[ In Days - Ex: 90 (or) 120 ....]</div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Milestone Count <span class="text-danger">*</span></label> 
                    <input type="text" class="form-control" placeholder="Enter Duration End" name="milestone_count" id="milestone_count" value="{{$preProposal->milestone_count ?? 0 }}" maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                    <div class="text-danger fs-8 fw-semibold" id="milestone_count_err"></div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Assign CRE <span class="text-danger">*</span></label>
                    <select class="select3 form-select" name="proposal_cre" id="proposal_cre"  >
                       <option value="">Select CRE</option>
                        @if(isset($crestaff))
                        @foreach($crestaff as $cre)
                        <option value="{{ $cre->sno }}" @if(isset($preProposal->cre_id) && $preProposal->cre_id == $cre->sno  )selected @endif>{{$cre->staff_name}} - {{$cre->position_name}} </option>
                       @endforeach
                       @endif
                    </select>
                    <div class="text-danger fs-8 fw-semibold" id="proposal_cre_err"></div>
                </div>
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Referral Staff </label>
                    <select class="select3 form-select" name="proposal_referral_staff" id="proposal_referral_staff"  >
                       <option value="">Select Referral Staff</option>
                        @if(isset($referalStaff))
                        @foreach($referalStaff as $cre)
                        <option value="{{ $cre->sno }}" @if(isset($preProposal->referral_id) && $preProposal->referral_id == $cre->sno  )selected @endif>{{$cre->staff_name}} - {{$cre->position_name}} </option>
                       @endforeach
                       @endif
                    </select>
                    <div class="text-danger fs-8 fw-semibold" id="proposal_referral_staff_err"></div>
                </div>
                @php
                    $selectedDomains = $preProposal->domain_ids =='null' ? [] : json_decode($preProposal->domain_ids ?? '[]');
                @endphp
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold">Domains</label>
                    <select class="select3 form-select " name="proposal_domain[]" id="proposal_domain" multiple data-placeholder="Select Domains">
                       <option value="">Select Domains</option>
                        @if(isset($domainList))
                        @foreach($domainList as $dlist)
                        <option value="{{ $dlist->sno }}"
                      @if(in_array($dlist->sno, $selectedDomains))
                            selected
                        @endif>
                        {{ $dlist->domain_name  }}</option>
                       @endforeach
                       @endif
                    </select>
                    <div class="text-danger fs-8 fw-semibold" id="proposal_domain_err"></div>
                </div>
                
                <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Page or Word</label>
                    <div class="d-flex ">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input page_word" type="radio" name="page_word" id="page_word1" value="1" @if($preProposal->page_word !=2 ) checked @endif onchange="page_change_count_func()" />
                            <label class="form-check-label" for="inlineRadio1">Page</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input page_word" type="radio" name="page_word" id="page_word2" value="2" @if($preProposal->page_word ==2 ) checked @endif  onchange="page_change_count_func()"/>
                            <label class="form-check-label" for="inlineRadio2">Word</label>
                        </div>
                    </div>
                </div>
                 <div class="col-lg-4 mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold" id="page_count_label">Page Count </label> 
                    <input type="text" class="form-control" placeholder="Enter count" name="page_word_count" id="page_word_count" value="{{$preProposal->page_word_count ?? 0 }}" maxlength="8" oninput="this.value = this.value.replace(/[^0-9]/g, '')" />
                </div>
               <div class="col-lg-6  mb-1">
                    <label class="text-black mb-1 fs-6 fw-semibold duration_field">Topic</label>
                    <textarea  class="form-control" placeholder="Enter Topic" name="proposal_topic" id="proposal_topic" >{{$preProposal->topic ?? '' }} </textarea>
                    <div class="text-danger fs-8 fw-semibold mt-1" id="proposal_topic_err"></div>
                </div>
               <div class="col-lg-6  mb-1 mt-4">
                    <div class="form-check form-check-inline mt-4">
                         <input class="form-check-input w-25px h-25px mx-1" type="checkbox" id="old_customer_check" value="1"   name="old_customer_check" onclick="old_customer_func();" 
                        @if($preProposal->old_customer == 1) checked @endif
                        />
                        <label class="text-black mb-1 ms-1 fs-6 mt-1 fw-semibold">Old Customer</label>
                    </div>
                </div>
            </div>
           

        </div>
        <div id="serv_product_chk_tbox">
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <div class="nav-align-top mb-2">
                        <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                            <div class="scroll-container-wrapper">
                                <button type="button"  class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                                <div class="scroll-container" id="scrollContainer">
                                    @if(isset($Product_cat_list))
                                    @foreach ($Product_cat_list as $inx => $cat_list)
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 @if($inx==0) active @endif" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_{{$inx}}" aria-controls="tab_cate_{{$inx}}" aria-selected="false">
                                                <span class="ms-2">{{$cat_list->product_category_name}}</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ str_pad($cat_list->product_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</span>
                                            </button>
                                        </li>
                                    </div>
                                     @endforeach
                                     @endif
                                </div>
                                <button type="button"  class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-1">
                    <div class="tab-content p-0">
                        @if($Product_cat_list)
                            @foreach ($Product_cat_list as $inx2 => $cat_list)
                                <div class="tab-content p-0">
                                <div class="tab-pane fade @if($inx2==0) show active @endif" id="tab_cate_{{$inx2}}" role="tabpanel">
                                    <div class="scroll-y border-gray-200i rounded max-h-300px  px-3 py-3">
                                    <div class="row">
                                        @php
                                        $get_product_list = $helper->get_category_based_products($cat_list->sno , auth()->user()->branch_id);
                                        @endphp
                                        @if (isset($get_product_list) && $get_product_list->isNotEmpty())
                                        @foreach ($get_product_list as $pr_inx => $prd_list)
                                            <div class="col-lg-4 mb-3">
                                             <div class="card h-100 chse_me_card_btt rounded product_card" 
                                                 id="card_color_{{$prd_list->sno}}" 
                                                 data-product-id="{{ $prd_list->sno }}">
                                                <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                        <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                    </div>
                                                    </div>
                                                    
                                                    <div class="mb-0">
                                                    <div class="text-black fs-7 fw-semibold text_truncate_class text-wrap"  data-bs-placement="bottom" >{{$prd_list->product_name}}</div>
                                                    </div>
                                                    <div class="ms-auto badge bg-info text-white fs-7" id="product_count_{{$prd_list->sno}}"></div>
                                                </div>

                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                    <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                        <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                    </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                    <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">
                                                        {{$prd_list->duration}} 
                                                        @switch($prd_list->duration_in)
                                                            @case(0)
                                                                Minute
                                                                @break
                                                            @case(1)
                                                                Hour
                                                                @break
                                                            @case(2)
                                                                Days
                                                                @break
                                                        @endswitch
                                                    </label>
                                                    <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                    @php
                                                        $facilities = json_decode($prd_list->facility_ids ?? '[]', true);
                                                        $facilities = is_array($facilities) ? $facilities : [];
                                                        $fac_count  = count($facilities);
                                                    @endphp
                                                    <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">{{ str_pad($fac_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</span>
                                                        <span class="fs-8 text-info"><u>View Info</u></span>
                                                    </label>
                                                    <div class="dropdown-menu dropdown-menu-start w-350px">
                                                        <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                        <hr class="mt-0 mb-2 border-dark">
                                                        <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                        @foreach ($facilities as $FSNO)
                                                        @php $fac_data = $helper->get_product_facility($FSNO); @endphp
                                                        @if ($fac_data)
                                                            <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">{{ $fac_data->facility_name }}</label>
                                                            </div>
                                                        @endif
                                                        @endforeach

                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>
                                                @php
                                                    $tool_name = [];
                                                    $tools_view_name = '';
                                                    $Tools = json_decode($prd_list->tools_ids ?? '[]', true);
                                                    $Tools = is_array($Tools) ? $Tools : [];
                                                    foreach ($Tools as $Tlist) {
                                                        $tools_data = $helper->get_tools_by_id($Tlist);
                                                        if ($tools_data) {
                                                            $name = $tools_data->product_tools_name ?? '';
                                                            $tool_name[] = trim($name, ',');
                                                        }
                                                    }
                                                    if (!empty($tool_name)) {
                                                        $tools_view_name = implode(', ', $tool_name);
                                                    }
                                                @endphp
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold text_truncate_class"  data-bs-placement="bottom" > {{ $tools_view_name ? $tools_view_name: '-' }}</div>
                                                    </div>
                                                </div>

                                                
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">
                                                         <span class="product_base_price" 
                                                                  id="product_base_price_{{$prd_list->sno}}">
                                                                &#8377; {{ number_format($prd_list->base_price) }}
                                                            </span>
                                                    </div>
                                                </div>
                                                <!--<div class="mb-1 chse_me_btt" id="choose_me_button{{$prd_list->sno}}">-->
                                                <!--    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold chse_me_btta" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_{{$prd_list->sno}}">Choose me</a>-->
                                                <!--</div>-->
                                                <div class="mb-1 chse_me_btt" id="choose_me_button{{$prd_list->sno}}">
                                                    <a href="javascript:;" 
                                                       class="d-block btn btn-sm btn-primary fw-semibold chse_me_btta" 
                                                       data-product-id="{{ $prd_list->sno }}">
                                                       Choose me
                                                    </a>
                                                </div>
                                                <!--begin::Modal - Add Product-->
                                                    <input type="hidden" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me_{{$prd_list->sno}}" id="kt_modal_choose_me_triger{{$prd_list->sno}}">
                                                    <div class="modal fade" id="kt_modal_choose_me_{{$prd_list->sno}}" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
                                                    <!--begin::Modal dialog-->
                                                    <div class="modal-dialog modal-lg">
                                                        <!--begin::Modal content-->
                                                        <div class="modal-content rounded">
                                                        <!--begin::Modal header-->
                                                        <div class="modal-header justify-content-end border-0 pb-0">
                                                            <!--begin::Close-->
                                                            <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal"  >
                                                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                                            <span class="svg-icon svg-icon-1">
                                                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                                                                </svg>
                                                            </span>
                                                            <!--end::Svg Icon-->
                                                            </div>
                                                            <!--end::Close-->
                                                        </div>
                                                        <!--end::Modal header-->
                                                        <!--begin::Modal body-->
                                                        <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                                                            <!--begin::Heading-->
                                                            <div class="mb-8 text-center">
                                                            <h3 class="text-center mb-4 text-black" id="add_product_label_{{$prd_list->sno}}">Add Product</h3>
                                                            </div>
                                                            <div class="row mb-4">
                                                            <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                            <div class="col-8 text-black fs-6 fw-bold">{{$prd_list->product_name}}</div>
                                                            </div>
                                                            <div class="row mb-4">
                                                            <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                                                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                            <div class="col-8 text-black fs-6 fw-bold">{{$cat_list->product_category_name}}</div>
                                                            </div>
                                                            <div class="divider mt-1 mb-1">
                                                            <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                                                            </div>
                                                            {{-- <form id="product_add_form_{{$prd_list->sno}}"> --}}
                                                            <input type="hidden" name="Inserted_id_product" id="Inserted_id_product" value="{{$Inserted_id}}">
                                                            <div class="row">
                                                                <div class="col-lg-12 mb-1">
                                                                <div class="bg-gray-200i rounded">
                                                                    <div class="scroll-y max-h-400px py-2 px-3">
                                                                    <div class="row">
                                                                        <div class="col-lg-12 mb-1">
                                                                        <input type="hidden" name="product_id" id="product_id_{{$prd_list->sno}}" value="{{$prd_list->sno}}">
                                                                         <input type="hidden" name="product_amount"  class="product_amount_hidden" id="product_amount_{{$prd_list->sno}}" value="{{$prd_list->base_price}}">
                                                                         <input type="hidden" name="product_min_amount" id="product_min_amount_{{$prd_list->sno}}" value="{{$prd_list->min_amount}}">
                                                                         
                                                                          <input type="hidden" name="product_amount_default"  class="product_amount_default" id="product_amount_default_{{$prd_list->sno}}" value="{{$prd_list->base_price}}">
                                                                          <input type="hidden" name="product_min_amount_default" id="product_min_amount_default_{{$prd_list->sno}}" value="{{$prd_list->min_amount}}">
                                                                        @php
                                                                            $get_variant_data = $helper->get_variant_data_product($prd_list->sno);
                                                                        @endphp
                                                                        @if (isset($get_variant_data) && $get_variant_data->isNotEmpty())
                                                                        @foreach ($get_variant_data as $vrn_inx => $vrn_list)
                                                                            <div class="px-3 pt-1">
                                                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                                                <input class="form-check-input variant_chck_box" type="checkbox" id="variant_check_box_{{$vrn_list->sno}}" onclick="variant_check_func({{$prd_list->sno}},{{$vrn_list->sno}});" />
                                                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">{{$vrn_list->product_variant_name}}</label>
                                                                            </div>
                                                                            <div id="variant_check_div_{{$vrn_list->sno}}" style="display: none;">
                                                                                <div class="row mt-2">
                                                                                @php
                                                                                $get_variable_data = $helper->get_variable_by_variant($vrn_list->sno);
                                                                                @endphp
                                                                                @foreach ($get_variable_data as $vr_inx => $vr_list)
                                                                                <div class="col-lg-4 mb-1">
                                                                                    <div class="form-check">
                                                                                    <input class="form-check-input me-0 variable_radio_{{$vrn_list->sno}}" type="radio" data-amount="{{$vr_list->variable_amount}}" onclick="calculateCheckedAmount({{$prd_list->sno}},{{$vrn_list->sno}})" name="variable_radio_[{{$vrn_list->sno}}]" value="{{$vr_list->sno}}" disabled />
                                                                                    <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                                        <span>{{$vr_list->variable_name}}</span>
                                                                                        <span class="ms-1 me-1">-</span>
                                                                                        <span class="badge bg-label-info rounded fw-semibold fs-7 variant_price"  id="variant_price_{{$vr_list->sno}}">&#8377; {{ number_format($vr_list->variable_amount) }}</span>
                                                                                        <input type="hidden" name="variant_price_default" id="variant_price_default_{{$vr_list->sno}}" value="{{$vr_list->variable_amount}}">
                                                                                    </label>
                                                                                    </div>
                                                                                </div>
                                                                                @endforeach
                                                                                </div>
                                                                                <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                                                            </div>
                                                                            </div>
                                                                        @endforeach
                                                                        @else
                                                                        <label class="row text-center">
                                                                            <span class="text-danger fs-5">No Variant found for this <b class="text-black"> {{$prd_list->product_name}} </b> Product</span>
                                                                        </label>
                                                                        @endif
                                                                        </div>
                                                                    </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                            <div class="d-flex justify-content-end mt-2 px-3">
                                                                <div class="row my-2">
                                                                    <label class="col-4 text-black fs-6 fw-semibold">Total Amount<span class="text-danger">*</span></label>
                                                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                                                    <div class="col-lg-7 mb-1">
                                                                        <input type="text" class="form-control product_amount_edit" placeholder="Enter Product Amount " name="product_amount_edit" id="product_amount_edit_{{$prd_list->sno}}" value="{{$prd_list->base_price ?? 0}}" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  onkeyup="productAmountValidate(this.value,{{$prd_list->sno}})" />
                                                                        <div class="text-danger err_mssg fs-7 product_amount_edit_err" id="product_amount_edit_err_{{$prd_list->sno}}" ></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="d-flex justify-content-center align-items-center mt-8">
                                                                <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                                                                <button type="button" class="btn btn-primary" onclick="add_product({{$prd_list->sno}},{{$prd_list->base_price}})" id="add_product_button_{{$prd_list->sno}}">Add Product</button>
                                                            </div>
                                                            {{-- </form> --}}
                                                        </div>
                                                        <!--end::Modal body-->
                                                        </div>
                                                        <!--end::Modal content-->
                                                    </div>
                                                    <!--end::Modal dialog-->
                                                    </div>
                                                <!--end::Modal - Add Product-->
                                                </div>
                                            </div>
                                            </div>
                                        @endforeach
                                        @else
                                        <label class="row text-center">
                                        <span class="text-danger fs-5">No products found for this <b class="text-black"> {{$cat_list->product_category_name}} </b> category</span>
                                        </label>
                                        @endif
                                    </div>
                                    </div>
                                </div>
                                </div>
                            @endforeach
                        @endif
                    </div>
                </div>
                <div class="col-lg-4 mb-1">
                    <div class="card h-100 rounded">
                        <div class="scroll-y max-h-250px px-2 py-1">
                            <div class="card-body px-1 py-1">
                                <div class="row">
                                    <div class="col-lg-12 px-1">
                                        <div id="selected_product_list_div">
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="mb-10" id="serv_package_chk_tbox" style="display: none;">
            <div class="row mb-3">
                <div class="col-lg-4 mb-3"  onclick="check_currency_func(event)">
                    <label class="text-black mb-1 fs-6 fw-semibold">Packages<span class="text-danger">*</span></label>
                    <select class="select3 form-select" name="package_id" id="package_id">
                        <option value="">Select Packages</option>
                        @if(isset($package_list))
                            @foreach($package_list as $package)
                               <option value="{{$package->sno}}" @if(isset($packageSlot) && $package->sno == $packageSlot->package_id) selected @endif>{{$package->package_name}}</option>
                            @endforeach
                        @endif
                    </select>
                </div>
                <div class="col-lg-8 text-center">
                    <div class="d-flex align-items-start justify-content-between flex-wrap">
                        <div class="mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration</label>
                            <div class="d-block">
                                <label class="badge bg-warning rounded text-black fs-5 fw-semibold" id="package_duration">0 Days</label>
                            </div>
                        </div>
                        <div class="mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Price</label>
                            <div class="d-block">
                                <label class="badge bg-success rounded fs-5 fw-semibold text-white"><span class="currency_symb"></span> <span id="package_amount"></span></label>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-2 mb-1">
                            <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Products</label>
                            <div class="d-block mb-1">
                                <label class="cursor-pointer fs-5 fw-semibold text-black" id="package_product_count">0</label>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-0 mb-1">
                            <div data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Free Add-on</label>
                                <div class="d-block">
                                    <label class="cursor-pointer fs-5 fw-semibold text-black" id="package_free_addon">0</label>
                                </div>
                                <div class="d-block">
                                    <a href="javascript:;" class="fs-8 fw-semibold text-info"><u>View Info</u></a>
                                </div>
                            </div>
                            <div class="dropdown-menu dropdown-menu-end w-25">
                                
                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Free Add-on Products</div>
                                <hr class="mt-0 mb-2 border-dark">
                                <div class="scroll-y max-h-150px px-4 py-1 mb-2" id="viewInfoFree">
                                
                                </div>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-0 mb-1">
                            <div data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Paid Add-on</label>
                                <div class="d-block">
                                    <label class="cursor-pointer fs-5 fw-semibold text-black" id="package_paid_addon">0</label>
                                </div>
                                <div class="d-block">
                                    <a href="javascript:;" class="fs-8 fw-semibold text-info"><u>View Info</u></a>
                                </div>
                            </div>
                            <div class="dropdown-menu dropdown-menu-end w-25">
                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Paid Add-on Products</div>
                                <hr class="mt-0 mb-2 border-dark">
                                <div class="scroll-y max-h-150px px-4 py-1 mb-2" id="viewInfoPaid">
                                 
                                        
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="divider mb-4">
                <div class="text-black mb-0 fs-3 fw-semibold divider-text">Products Details</div>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-1">
                    <div class="scroll-y border-gray-200i rounded max-h-250px px-3 py-3">
                        <div class="row" id="package_product_div">
                          
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-1">
                    <div class="card h-100 rounded">
                        <div class="scroll-y max-h-250px px-2 py-1">
                            <div class="card-body px-1 py-1">
                                <div class="row">
                                    <div class="col-lg-12 px-1">
                                        <div id="selected_pckage_list_div">
                                        </div> 
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mb-2 me-2 gap-2 text-danger">
                <label class="fw-bold fs-5 me-13">Package Amount :</label>
                <div class="fw-bold fs-2">
                    <span class="currency_symb fs-5 fw-bold"></span>
                    <span class="fs-3" id="package_actual_price">0.00</span>
                    <input type="hidden" name="package_actual_price_hidden" id="package_actual_price_hidden">
                </div>
               
            </div>
            <div class="d-flex align-items-center justify-content-end mb-2 me-2 gap-2 text-danger">
                 <small class="text-danger d-block cust_product_amount_error" ></small>
            </div>
        </div>
        
        <div class="row">
            <div class="d-flex justify-content-end align-items-end me-2 ms-6">
                <span class="text-danger text-end row fw-bold fs-5" id="over_all_total_lab"></span>
            </div>
            <div class="d-flex align-items-center mt-4 mb-1" style="">
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px prod_add_on" type="checkbox" id="prod_add_on" value="1"  name="prod_add_on" onclick="product_add_on_func();"   />
                    <label class="text-black mb-1 fs-5 fw-semibold">Add-on Products</label>
                    <label class="text-black mb-1 fs-5 fw-bold me-1 ms-1">-</label>
                    <label class="badge bg-info mb-1 fw-semibold fs-5" ><span class="currency_symb"></span> <span id="addon_total_amount">0</span></label>
                    <span class="ms-2 add-on-setwarning text-danger fs-6 fw-semibold pricebook-warning text-center"></span>
                    <input type="hidden" name="addon_total_amount_value" id="addon_total_amount_value">
                </div>
            </div>
            <div class="mb-4" id="view_product_add_on" style="display:block;">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-label-warning rounded pb-4 pt-4">
                            <div class="scroll-y max-h-275px px-3 py-0">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        @if(isset($addOnProductList))
                                        @foreach($addOnProductList as $idxAdn => $add_on)
                                        <div class="px-3 pt-1">
                                            <input type="hidden" name="addOnProduct_ids[]" id="addOnProduct_id">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input add_on_product" type="checkbox" name="addOn_chk[]" id="addOn_chk_{{$add_on->sno}}" value="{{$add_on->sno}}"  />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">{{ $add_on->addon_name ?? '-'}}</label>
                                                 <span class="text-danger fs-7 fw-semibold pricebook-warning text-center mb-2" style="display:none;">
                                                    Set Amount in Pricebook
                                                </span>
                                            </div>
                                            <div class="row mt-2">
                                                @if(isset($add_on->add_varients))
                                                @foreach($add_on->add_varients as $idxvarient => $varient)
                                                @if($varient->free_paid == 0)
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0 add_on_varient" type="radio"  value="{{$varient->sno}}"  name="addOn_varient_{{$add_on->sno}}"
                                                         id="addOn_varient_{{$varient->sno}}"
                                                           />
                                                           
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>{{ $varient->addon_variablename}}</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-success rounded fw-semibold fs-7"><del><span class="currency_symb"></span> <span id="addon_variant_price_{{$varient->sno}}">{{ number_format($varient->amount) }}</span></del></span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                             
                                                        </label>
                                                        <input type="hidden" name="addon_amount_{{$varient->sno}}"  class="addon_amount" id="addon_amount" value="0" >
                                                    </div>
                                                </div>
                                                @else
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0 add_on_varient" type="radio"  value="{{$varient->sno}}"  name="addOn_varient_{{$add_on->sno}}"
                                                         id="addOn_varient_{{$varient->sno}}" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>{{ $varient->addon_variablename}}</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7"><span class="currency_symb"></span><span id="addon_variant_price_{{$varient->sno}}">{{ number_format($varient->amount) }}</span></span>
                                                          
                                                        </label>
                                                          <input type="hidden" name="addon_amount_{{$varient->sno}}"  class="addon_amount" id="addon_amount" value="{{$varient->amount}}" >
                                                    </div>
                                                </div>
                                                 @endif
                                                 @endforeach
                                                @endif
                                            </div>
                                        </div>
                                        @if(count($addOnProductList)>0)
                                            @if($idxAdn !=(count($addOnProductList)-1) )
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                            @endif
                                        @endif
                                        @endforeach
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
                
                <!--begin:: Default show without value selected -->
                <!-- <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <label class="fw-bold fs-5 me-13">Sub Total</label>
                        <div class="fw-bold fs-2">
                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                            <span class="fs-3">0</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                        <div class="d-flex align-items-center justify-content-between mb-2" id="coup_tbox">
                            <div class="me-13">
                                <label class="fw-bold fs-6">Coupon Code</label>
                                <input type="text" class="form-control w-150px px-2 py-1" placeholder="Enter Code" />
                            </div>
                            <a href="javascript:;" class="btn btn-sm btn-primary fs-8 mt-4" onclick="coupon_code_func();">Apply</a>
                        </div>
                        <div class="d-flex align-items-center justify-content-end gap-5 mb-2" id="coup_label_box" style="display: none !important;">
                            <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                <div class="me-3">
                                    <label>Discount</label>
                                    <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 0% )</label><br>
                                </div>
                                <a href="javascript:;" class="btn btn-sm btn-outline-primary border-dashed fs-8 px-2 py-1" onclick="reset_coupon_func();" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset Coupon Code">
                                    <i class="mdi mdi-rotate-3d-variant text-dark fs-2"></i>
                                </a>
                            </div>
                            <div class="fw-bold fs-2">
                                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                <span class="fs-3">0</span>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <div class="fw-bold fs-5 me-12">
                            <div class="text-dark mb-1 fs-5 fw-semibold">
                                <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                <div class="d-block fw-bold fs-8">[Exclusive]</div>
                            </div>
                        </div>
                        <div class="fw-bold fs-2">
                            <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                            <label class="fs-3">0</label>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <label class="fw-bold fs-3 me-13">Grand Total</label>
                        <div class="fw-bold fs-2">
                            <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                            <label class="fs-2">0</label>
                        </div>
                    </div> -->
                <!--end:: Default show without value selected -->

                <!--begin:: value selected after show -->
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold fs-5 me-13">Sub Total</label>
                    <div class="fw-bold fs-2">
                        <span class="currency_symb fs-4 fw-bold"></span>
                        <span class="fs-3" id="sub_total">0</span>
                    </div>
                     <input type="hidden" name="product_total_amount" id="over_all_total_amount" value="0">
                     <input type="hidden" name="sub_total_amount" id="sub_total_amount">
                     <input type="hidden" class="form-control" name="discounted_amount_hidden" id="discounted_amount_hidden" value="0" />
                     <input type="hidden" class="form-control" name="discount_id_hidden" id="discount_id_hidden" value="0" />
                     <input type="hidden" class="form-control" name="proposal_total_amount" id="proposal_total_amount" value="0" />
                     <input type="hidden" class="form-control" name="grant_total_amount" id="grant_total_amount" value="0" />
                     <input type="hidden" class="form-control" name="gst_amount_hidden" id="gst_amount_hidden" value="0" />
                     <input type="hidden" class="form-control" name="gst_perc_hidden" id="gst_perc_hidden" value="{{$branch_data->gst_percentage ?? '18'}}" />
                </div>
                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                    <div class="d-flex align-items-center justify-content-between mb-2" id="coup_tbox" >
                        <div class="me-13">
                            <label class="fw-bold fs-6">Coupon Code</label>
                            <input type="text" class="form-control w-150px px-2 py-1" value="" id="new_coupon_code" name="new_coupon_code" placeholder="Enter Code" />
                              <div class="new_coupon_code_err text-danger"></div>
                        </div>
                        <a href="javascript:;" class="btn btn-sm btn-primary fs-8 mt-4" onclick="coupon_code_func()">Apply</a>
                    </div>
                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2" id="coup_label_box" style="display: none !important;">
                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                            <div class="me-3">
                                <label>Discount</label>
                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage" id="discount_type_label">( 10% )</label><br>
                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code" id="coupon_code_label">[ A7D9K2L3M0 ]</label>
                            </div>
                            <a href="javascript:;" class="btn btn-sm btn-outline-primary border-dashed fs-8 px-2 py-1" onclick="reset_coupon_func();" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset Coupon Code">
                                <i class="mdi mdi-rotate-3d-variant text-dark fs-2"></i>
                            </a>
                        </div>
                        <div class="fw-bold fs-2">
                            <span class="currency_symb fs-4 fw-bold"></span>
                            <span class="fs-3"  id="discounted_amount_label">0.00</span>
                        </div>
                    </div>
                </div>
                <div class="row" style="display:none !important;">
                    <div class="col-lg-8 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Additional Charges</label>
                        <select class="select3 form-select" name="addtional_charges_id[]" id="addtional_charges_id"  multiple onchange="AdditionalChargeChange()">
                                @if(isset($additional_charges_list))
                                 @foreach($additional_charges_list as $charges)
                                    <option value="{{$charges->sno}}" data-percent="{{ $charges->adc_percentage }}"  >{{$charges->adc_name}} - {{$charges->adc_percentage}}%</option>
                                @endforeach
                                @endif
                        </select>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                            <div class="fw-bold fs-5 me-12">
                                <div class="text-dark text-end mb-1 fs-5 fw-semibold">
                                    <label>Additional Charges<br><span class="text-danger fw-bold">( <span id="additional_charge_perc_label">0</span>% )</span></label>
                                    <input type="hidden" name="additional_charge_perc" id="additional_charge_perc">
                                    <input type="hidden" name="additional_charge_amount" id="additional_charge_amount">
                                </div>
                            </div>
                            <div class="fw-bold fs-2">
                                <label class="currency_symb fs-4 fw-bold"></label>
                                <label class="fs-3" id="additional_charge_amount_label">0</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                    <div class="fw-bold text-black fs-2">
                        <span class="currency_symb fs-3 fw-bold text-black"></span>
                        
                         <label class="fs-2 grant_total_label" id="grant_total_label">0</label>
                    </div>
                </div>
                
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <div class="fw-bold fs-5 me-12">
                        <div class="text-dark mb-1 fs-5 fw-semibold">
                            <label>GST <span class="text-danger fw-bold">( <span id="gstPercentage">18</span>% )</span></label>
                            <div class="d-block fw-bold fs-8">[{{ $branch_data->gst_check == 1 ? 'Inclusive' :'Exclusive' }}]</div>
                            <input type="hidden" name="gst_inclusive" id="gst_inclusive" value="{{$branch_data->gst_check}}"/>
                        </div>
                    </div>
                    <div class="fw-bold fs-2">
                        <label class="currency_symb fs-4 fw-bold"></label>
                        <label class="fs-3" id="gst_maount_out_label">0</label>
                    </div>
                </div>
                <!-- <div class="row d-flex align-items-center justify-content-end mb-2 gap-5">
                    <div class="col-lg-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Additional Charges</label>
                        <input type="text" class="form-control fw-semibold py-1" name="additional_charges" id="additional_charges" placeholder="Enter Charges" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" onkeyup="calculateOverTotal()" />
                    </div>
                </div> -->
                
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                    <div class="fw-bold text-black fs-2">
                        <label class="currency_symb fs-2 fw-bold text-black"></label>
                       <span class="fs-1" id="proposal_total_amount_fetch">0</span>
                    </div>
                </div>
                <!--end:: value selected after show -->
      
        </div>
        
        <div id="pckg_pymt_slot" style="display: none;">
            <div class="divider divider-primary mb-4 mt-0">
                <div class="divider-text fs-3 text-black fw-semibold">Payment Milestone Details</div>
            </div>
            <div class="row" id="package_pay_slot_list">
               
            </div>
        </div>

        <div id="prod_pymt_slot">
            <div class="divider divider-primary mb-4 mt-0">
                <div class="divider-text fs-3 text-black fw-semibold">Payment Milestone Details</div>
            </div>
            <div class="row" id="payment_slot_list">
               
            </div>
        </div>
        <div class="d-flex justify-content-end align-items-center mt-13">
            <a href="/manage_proposal" class="btn btn-secondary me-2">Cancel</a>
            <button type="button" id="verify_proposal" class="btn btn-primary me-2"  onclick="create_proposal_func('{{$proposal_id}}' ,'{{$lead->lead_name}}','{{$lead->lead_id}}')">Create & Verify Proposal</button>
            <div id="customer_send_btn">
                <button type="button" id="send_proposal" class="btn btn-primary"  onclick="create_proposal_send_func('{{$proposal_id}}' ,'{{$lead->lead_name}}','{{$lead->lead_id}}')">Create & Send Proposal</button>
            </div>
            <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal" data-bs-target="#kt_modal_create_proposal">
            <input type="hidden" name="send_communication" id="send_communication" value="0">
        </div>
    </div>
    </form>
</div>






<!--begin::Modal - Create Proposal-->
<div class="modal fade" id="kt_modal_create_proposal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Create Proposal?
                <div class="d-block fw-bold text-black fs-5 py-2 mt-3">
                    <label id="proposal_lead_name">Priya </label>
                    <span class="ms-2 me-2">-</span>
                    <label id="proposal_auto_id">[ PRO-003670/05/2025 ]</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="button" id="proposal_create_button" class="btn btn-primary me-3" onclick="confirm_create_proposal()">Yes</button>
                <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Proposal-->


<!--begin::Modal - Add Product-->
<div class="modal fade" id="kt_modal_choose_me" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Add Product</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Writing Products</div>
                </div>
                <div class="divider mt-1 mb-1">
                    <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-gray-200i rounded">
                            <div class="scroll-y max-h-400px py-2 px-3">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_pg_chk" onclick="pckg_vart_pg_func();" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Pages</label>
                                            </div>
                                            <div id="pckg_cart_pg_chk_tbox" style="display: none;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>100 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 5,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>300 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>500 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                            </div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_dy_chk" onclick="pckg_vart_dy_func();" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Days</label>
                                            </div>
                                            <div id="pckg_vart_dy_chk_tbox" style="display: none;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>1 Day</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>5 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 2,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>10 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 3,500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Add Product</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Product-->

<!--begin::Modal - Update Product-->
<div class="modal fade" id="kt_modal_update_choose_me" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Product</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Writing Products</div>
                </div>
                <div class="divider mt-1 mb-1">
                    <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-gray-200i rounded">
                            <div class="scroll-y max-h-400px py-2 px-3">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_pg_chk_update"  />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Pages</label>
                                            </div>
                                            <div style="display: block;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update"  />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>100 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 5,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>300 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>500 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                            </div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_dy_chk_update" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Days</label>
                                            </div>
                                            <div style="display: block;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>1 Day</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update"  />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>5 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 2,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>10 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 3,500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Update Product</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Product-->



<!--begin::Modal - Add Package Payment slot-->
<div class="modal fade" id="kt_modal_add_payment_slot_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Add Package Payment Milestone</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Packages</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="pay_slot_package_name">Complete Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Products</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">
                        <label class="badge bg-warning text-black fw-semibold fs-7" id="pay_slot_package_pro_count">00</label>
                    </div>
                </div>
                <form method="POST" action="{{ route('add_proposal_payment_slot') }}" enctype="multipart/form-data" autocomplete="off" id="addPaymentSlotformPackg">
                 @csrf
                 <input type="hidden" name="payment_slot_package_id" id="payment_slot_product_id_packg">
                 <input type="hidden" name="package_payment_slot" id="package_payment_slot" value="1">
                 <input type="hidden" name="pay_proposal_id" id="pay_proposal_id_packg" value="{{$proposal_id ?? ''}}">
                 <input type="hidden" name="payment_slot_total_amt" id="payment_slot_total_amt_packg">
                 <input type="hidden" name="payment_slot_total_hidden" id="payment_slot_total_hidden_packg">
                 <input type="hidden" name="slot_balance_amt" id="slot_balance_amt_packg">
                 <input type="hidden" name="curency_format" id="curency_format_package">
                <div class="form-repeater_pymt_slot_pckg_create mt-6">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                            <select class="select3 form-select payment_slot_id_packg" name="payment_slot_id_packg_1" id="payment_slot_id_packg_1">
                                                <option value="">Select Payment Milestone</option>
                                            </select>
                                            <div class="text-danger err_mssg fs-7 payment_slot_id_packg_err" id="payment_slot_id_err_packg_1" ></div>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control payment_slot_amount_packg" placeholder="Enter Slot Amount " name="payment_slot_amount_packg_1" id="payment_slot_amount_packg_1" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" onkeyup="calculationSplitPackg(this.value,1)" />
                                            <div class="text-danger err_mssg fs-7 payment_slot_amount_packg_err" id="payment_slot_amount_packg_err_1" ></div>
                                        </div>
                                         
                                         <div class="col-lg-8 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Select Type<span
                                                    class="text-danger">*</span></label>
                                            <div class="d-flex ">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver_packg" type="radio" name="to_start_deliver_packg_1" id="to_start_deliver_radio_packg1" value="1" checked />
                                                    <label class="form-check-label" for="inlineRadio1">To Start The Work</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver_packg" type="radio" name="to_start_deliver_packg_1" id="to_start_deliver_radio_packg2" value="2" />
                                                    <label class="form-check-label" for="inlineRadio2">To Deliver The Work</label>
                                                </div>
                                            </div>
                                            <div class="text-danger" id="to_start_deliver_packg_err_1"></div>
                                        </div>
                                        
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_deliverables_packg" multiple data-placeholder="Select Deliverables" name="slot_deliverables_packg_1[]" id="slot_deliverables_packg_1">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_deliverables_packg_err" id="slot_deliverables_err_packg_1" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_notes_packg" multiple data-placeholder="Select Milestone Notes" name="slot_notes_packg_1[]" id="slot_notes_packg_1">
                                               
                                            </select>
                                             <div class="text-danger err_mssg fs-7 slot_notes_packg_err" id="slot_notes_packg_err_1" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1" placeholder="Enter Deliverables" name="slot_description_packg_1" id="slot_description_packg_1"></textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_create_del_packg" id="pymt_slot_create_del_packg_1" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="repeater_req_packg"></div>
                </div>
                <div class="text-danger fs-7" id="payment_slot_total_amt_err_packg"></div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button type="button" class="btn btn-sm btn-primary pymt_slot_create_add_packg fs-8 px-2 py-1" data-repeater-create id="pymt_slot_create_add_packg">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Total Amount</div>
                        <div class="d-block">
                            <label class="fs-4 fw-bold"><span class="currency_symb"></span> <span class="split_balance_label_packg" id="split_balance_label_packg"></span></label>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="addPaymentSlotBtnPackg" >Add Package Payment Milestone</button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Package Payment Slot-->





<!--begin::Modal - Add Product Payment slot-->
<div class="modal fade" id="kt_modal_add_payment_slot" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Add Payment Milestone</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="payment_product_name">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="payment_product_cat_name">Writing Products</div>
                </div>
                <form method="POST" action="{{ route('add_proposal_payment_slot') }}" enctype="multipart/form-data" autocomplete="off" id="addPaymentSlotform">
                 @csrf
                 <input type="hidden" name="payment_slot_product_id" id="payment_slot_product_id">
                 <input type="hidden" name="pay_proposal_id" id="pay_proposal_id" value="{{$proposal_id ?? ''}}">
                 <input type="hidden" name="payment_slot_total_amt" id="payment_slot_total_amt">
                 <input type="hidden" name="payment_slot_total_hidden" id="payment_slot_total_hidden">
                 <input type="hidden" name="slot_balance_amt" id="slot_balance_amt">
                 <input type="hidden" name="Pay_index" id="Pay_index">
                 <input type="hidden" name="curency_format" id="curency_format_prdt">
                <div class="form-repeater_pymt_slot_create mt-6">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                            <select class="select3 form-select payment_slot_id" name="payment_slot_id_1" id="payment_slot_id_1">
                                                <option value="">Select Payment Milestone</option>
                                            </select>
                                            <div class="text-danger err_mssg fs-7 payment_slot_id_err" id="payment_slot_id_err_1" ></div>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control payment_slot_amount" placeholder="Enter Milestone Amount " name="payment_slot_amount_1" id="payment_slot_amount_1" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" onkeyup="calculationSplit(this.value,1)" />
                                            <div class="text-danger err_mssg fs-7 payment_slot_amount_err" id="payment_slot_amount_err_1" ></div>
                                        </div>
                                        <div class="col-lg-8 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Select Type<span
                                                    class="text-danger">*</span></label>
                                            <div class="d-flex ">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver" type="radio" name="to_start_deliver_1" id="to_start_deliver_radio1" value="1" checked />
                                                    <label class="form-check-label" for="inlineRadio1">To Start The Work</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver" type="radio" name="to_start_deliver_1" id="to_start_deliver_radio2" value="2" />
                                                    <label class="form-check-label" for="inlineRadio2">To Deliver The Work</label>
                                                </div>
                                            </div>
                                            <div class="text-danger" id="to_start_deliver_err_1"></div>
                                        </div>
                                       
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Products<span class="text-danger">*</span></label>
                                            <select class="select3 form-select product_cart_id" multiple data-placeholder="Select Products" name="product_cart_id_1[]" id="product_cart_id_1"  onchange="ChangeProduct(this)">
                                               
                                            </select>
                                             <div class="text-danger err_mssg fs-7 product_cart_id_err" id="product_cart_id_err_1" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_deliverables" multiple data-placeholder="Select Deliverables" name="slot_deliverables_1[]" id="slot_deliverables_1">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_deliverables_err" id="slot_deliverables_err_1" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_notes" multiple data-placeholder="Select Slot Notes" name="slot_notes_1[]" id="slot_notes_1">
                                               
                                            </select>
                                             <div class="text-danger err_mssg fs-7 slot_notes_err" id="slot_notes_err_1" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1" placeholder="Enter Deliverables" name="slot_description_1" id="slot_description_1"></textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_create_del" id="pymt_slot_create_del_1" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="repeater_req"></div>
                </div>
                 <div class="text-danger fs-7" id="payment_slot_total_amt_err"></div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button type="button" class="btn btn-sm btn-primary pymt_slot_create_add fs-8 px-2 py-1" data-repeater-create id="pymt_slot_create_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Total Amount</div>
                        <div class="d-block">
                            <label class="fs-4 fw-bold"><span class="currency_symb"></span> <span class="split_balance_label" id="split_balance_label"></span></label>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary"  id="addPaymentSlotBtn" >Add Payment Milestone</button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Product Payment Slot-->

<!--begin::Modal - Update Package Payment slot-->
<div class="modal fade" id="kt_modal_update_payment_slot_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Package Payment Milestone</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Packages</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="pay_slot_package_name_edit">Complete Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Products</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">
                        <label class="badge bg-warning text-black fw-semibold fs-7" id="pay_slot_package_pro_count_edit">02</label>
                    </div>
                </div>
                 <form method="POST" action="{{ route('update_proposal_payment_slot') }}" enctype="multipart/form-data" autocomplete="off" id="editPackagePaymentSlotForm">
                 @csrf
                 <input type="hidden" name="payment_slot_package_id" id="payment_slot_product_id_packg_edit">
                 <input type="hidden" name="package_payment_slot" id="package_payment_slot_edit" value="1">
                 <input type="hidden" name="pay_proposal_id" id="pay_proposal_id_packg_edit" value="{{$proposal_id ?? ''}}">
                 <input type="hidden" name="payment_slot_total_amt" id="payment_slot_total_amt_packg_edit">
                 <input type="hidden" name="payment_slot_total_hidden" id="payment_slot_total_hidden_packg_edit">
                 <input type="hidden" name="slot_balance_amt" id="slot_balance_amt_packg_edit">                                   
                <div class="form-repeater_pymt_slot_pckg_update mt-6">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div id="package_addmore"></div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button type="button" class="btn btn-sm btn-primary pymt_slot_pckg_update_add fs-8 px-2 py-1" data-repeater-create id="pymt_slot_pckg_update_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Total Amount</div>
                        <div class="d-block">
                            <lable class="fs-4 fw-bold">&#8377; 0</lable>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" id="editPackagePaymentSlotBtn" >Update Package Payment Milestone</button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Package Payment Slot-->

<!--begin::Modal - Update Product Payment slot-->
<div class="modal fade" id="kt_modal_update_payment_slot" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Payment Milestone</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="payment_product_name_edit">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold" id="payment_product_cat_name_edit">Writing Products</div>
                </div>
                <form method="POST" action="{{ route('update_proposal_payment_slot') }}" enctype="multipart/form-data" autocomplete="off" id="addPaymentSlotform">
                 @csrf
                 <input type="hidden" name="payment_slot_product_id" id="payment_slot_product_id_edit">
                 <input type="hidden" name="pay_proposal_id" id="pay_proposal_id_edit" value="{{$proposal_id ?? ''}}">
                 <input type="hidden" name="payment_slot_total_amt" id="payment_slot_total_amt_edit">
                 <input type="hidden" name="slot_balance_amt" id="slot_balance_amt_edit">
                <div class="form-repeater_pymt_slot_update mt-6">
                    <div data-repeater-list="group-a_led_question">
                         <div id="update_pay_slot_list"></div>
                       
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button type="button" class="btn btn-sm btn-primary pymt_slot_update_add fs-8 px-2 py-1" data-repeater-create id="pymt_slot_update_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Balance Amount</div>
                        <div class="d-block">
                            <lable class="fs-4 fw-bold">&#8377; 0</lable>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="button" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Update Payment Milestone</button>
                </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Product Payment Slot-->

<script>
    const preProposalData = @json($preProposal);
    const couponCode = @json($couponCode);
    var addOnProductList = @json($addOnProductList);
</script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 35;
        const elements = document.querySelectorAll('.text_truncate_class');
        elements.forEach(el => {
            const fullText = el.textContent.trim();
            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.textContent = fullText.slice(0, maxChars) + '...';
                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
</script>





<script>
  function payment_slot_func() {
    document.getElementById("add_payment_slot").style.setProperty('display', 'none', 'important');
    document.getElementById("update_payment_slot").style.setProperty('display', 'block', 'important');
    document.querySelectorAll('.pymt_bg').forEach(el => el.style.backgroundColor = '#7fffd494');
    document.getElementById("aft_pymt_slt").style.setProperty('display', 'block', 'important');
  }
</script>

<script>
  function cal_prod_on_of(id) {
    var cal_prod_tbox  = document.getElementById("cal_prod_tbox_" + id);
    var tooltipElement = document.getElementById("cal_prod_tlp_" + id);

    if (cal_prod_tbox.style.display == "none") {
      document.getElementById("cal_prod_tbox_" + id).style.display = "block";
      document.getElementById("cal_prod_plus_btton_" + id).classList.remove("mdi-plus");
      document.getElementById("cal_prod_plus_btton_" + id).classList.add("mdi-minus");
      document.getElementById("cal_prod_hd_" + id).style.backgroundColor = "#ebebeb";
      document.getElementById("cal_prod_hd_" + id).classList.remove("rounded");
      document.getElementById("cal_prod_hd_" + id).classList.add("rounded-top");
      document.getElementById("cal_prod_az_" + id).classList.add("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Hide");
      tooltipElement.setAttribute("data-bs-original-title", "Hide");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    } else {
      document.getElementById("cal_prod_tbox_" + id).style.display = "none";
      document.getElementById("cal_prod_plus_btton_" + id).classList.remove("mdi-minus");
      document.getElementById("cal_prod_plus_btton_" + id).classList.add("mdi-plus");
      document.getElementById("cal_prod_hd_" + id).style.backgroundColor = "#ffffff";
      document.getElementById("cal_prod_hd_" + id).classList.remove("rounded-top");
      document.getElementById("cal_prod_hd_" + id).classList.add("rounded");
      document.getElementById("cal_prod_az_" + id).classList.remove("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Show");
      tooltipElement.setAttribute("data-bs-original-title", "Show");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    }
  }

  function cal_packg_on_of(id) {
    var cal_packg_tbox  = document.getElementById("cal_packg_tbox_" + id);
    var tooltipElement = document.getElementById("cal_packg_tlp_" + id);

    if (cal_packg_tbox.style.display == "none") {
      document.getElementById("cal_packg_tbox_" + id).style.display = "block";
      document.getElementById("cal_packg_plus_btton_" + id).classList.remove("mdi-plus");
      document.getElementById("cal_packg_plus_btton_" + id).classList.add("mdi-minus");
      document.getElementById("cal_packg_hd_" + id).style.backgroundColor = "#ebebeb";
      document.getElementById("cal_packg_hd_" + id).classList.remove("rounded");
      document.getElementById("cal_packg_hd_" + id).classList.add("rounded-top");
      document.getElementById("cal_packg_az_" + id).classList.add("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Hide");
      tooltipElement.setAttribute("data-bs-original-title", "Hide");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    } else {
      document.getElementById("cal_packg_tbox_" + id).style.display = "none";
      document.getElementById("cal_packg_plus_btton_" + id).classList.remove("mdi-minus");
      document.getElementById("cal_packg_plus_btton_" + id).classList.add("mdi-plus");
      document.getElementById("cal_packg_hd_" + id).style.backgroundColor = "#ffffff";
      document.getElementById("cal_packg_hd_" + id).classList.remove("rounded-top");
      document.getElementById("cal_packg_hd_" + id).classList.add("rounded");
      document.getElementById("cal_packg_az_" + id).classList.remove("border", "border-gray-400i", "rounded");

      tooltipElement.setAttribute("title", "Show");
      tooltipElement.setAttribute("data-bs-original-title", "Show");

      var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
      tooltipInstance.dispose();
      new bootstrap.Tooltip(tooltipElement);
    }
  }
</script>

<script>
  function pckg_vart_dy_func() {
    var pckg_vart_dy_chk = document.getElementById("pckg_vart_dy_chk");
    var pckg_vart_dy_chk_tbox = document.getElementById("pckg_vart_dy_chk_tbox");
    const pckg_vart_days_chk = document.getElementsByName("pckg_vart_days_chk");
    if (pckg_vart_dy_chk.checked) {
      pckg_vart_dy_chk_tbox.style.display = "block";
      for (let i = 0; i < pckg_vart_days_chk.length; i++) {
        pckg_vart_days_chk[i].disabled = false;
      }
    } else {
      pckg_vart_dy_chk_tbox.style.display = "none";
      for (let i = 0; i < pckg_vart_days_chk.length; i++) {
        pckg_vart_days_chk[i].disabled = true;
        pckg_vart_days_chk[i].checked = false;
      }
    }
  }
  
 function variant_check_func(product_id, variant_id) {
    const checkbox = document.getElementById("variant_check_box_" + variant_id);
    const variantDiv = document.getElementById("variant_check_div_" + variant_id);
    const radios = document.querySelectorAll(".variable_radio_" + variant_id);

    if (checkbox.checked) {
        variantDiv.style.display = "block";
        radios.forEach(radio => {
            radio.disabled = false;
        });

        // Auto-check the first radio if available
        if (radios.length > 0) {
            radios[0].checked = true;
        }

        // Calculate amount after auto-selecting first radio
        calculateCheckedAmount(product_id, variant_id);
    } else {
        variantDiv.style.display = "none";
        radios.forEach(radio => {
            radio.disabled = true;
            radio.checked = false;
        });

        // Recalculate when variant is unchecked
        calculateCheckedAmount(product_id, variant_id);
    }
}

function calculateCheckedAmount(product_id, variant_id) {
    const radios = document.querySelectorAll(".variable_radio_" + variant_id);
    let base_amount = parseFloat($('#product_amount_' + product_id).val()) || 0;
    let checked_amount = 0;

    radios.forEach(radio => {
        if (radio.checked) {
            console.log(radio)
            let amount = parseFloat($(radio).attr('data-amount')) || 0;
            console.log('check_amount : ',amount)
            checked_amount += amount;
        }
    });

    $('#product_amount_edit_' + product_id).val(base_amount + checked_amount);
}


  
  function variant_check_func_edit(id) {
    const checkbox = document.getElementById("variant_check_box_edit" + id);
    const variantDiv = document.getElementById("variant_check_div_edit" + id);
    const radios = document.querySelectorAll(".variable_radio_edit" + id);

    if (checkbox.checked) {
      variantDiv.style.display = "block";
      radios.forEach(radio => {
        radio.disabled = false;
      });
    } else {
      variantDiv.style.display = "none";
      radios.forEach(radio => {
        radio.disabled = true;
        radio.checked = false;
      });
    }
  }


  
</script>
<script>
  function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
    
       $(".product_card").on("click", ".chse_me_btta", function (e) {
            e.preventDefault();
        
            const currencySelect = document.getElementById('prposal_currency');
            const currencyId = currencySelect.value;
            const selectedOption = currencySelect.options[currencySelect.selectedIndex];
            const selectedCurrencyCode = selectedOption?.getAttribute('data-code');
        
            if (!currencyId || parseInt(currencyId) < 1) {
                Swal.fire({
                    title: "Set Currency Format",
                    text: "Select Currency Format",
                    icon: "warning",
                    customClass: {
                        confirmButton: "btn btn-primary waves-effect waves-light"
                    },
                    buttonsStyling: false
                });
                return false;
            }
        
            // âœ… Only open modal if currency is set
            const productId = $(this).data("product-id");
            $(`#kt_modal_choose_me_${productId}`).modal("show");
        });
        
    document.getElementById('prod_add_on').addEventListener('click', function(e) {
        const checkbox = e.target;
        const currencySelect = document.getElementById('prposal_currency');
        const currencyId = currencySelect.value;
        const selectedOption = currencySelect.options[currencySelect.selectedIndex];
        const selectedCurrencyCode = selectedOption?.getAttribute('data-code');
    
        if (!currencyId || parseInt(currencyId) < 1) {
            Swal.fire({
                title: "Set Currency Format",
                text: "Select Currency Format",
                icon: "warning",
                customClass: {
                    confirmButton: "btn btn-primary waves-effect waves-light"
                },
                buttonsStyling: false
            });
    
            // ðŸ”¹ Force uncheck if no currency set
            checkbox.checked = false;
             product_add_on_func();
            return false;
        }
    
    });
        
    function check_currency_func(event) {
        var err = 0;
        const currencySelect = document.getElementById('prposal_currency');
        const selectedOption = currencySelect.options[currencySelect.selectedIndex];
        let selectedCurrencyCode = selectedOption ? selectedOption.getAttribute('data-code') : null;
    
        // Check if the selected currency is invalid
        if (!selectedCurrencyCode || selectedCurrencyCode === "") {
            Swal.fire({
                title: "Set Currency Format",
                text: 'Select Currency Format',
                icon: 'warning',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
            err++;
        }
    
        // Prevent dropdown from opening if there is an error
        if (err > 0) {
            event.preventDefault();  // This will prevent the dropdown from opening
        }
    }


    currency_change()
    function currency_change() {
        let selectedCurrencyId = $("#prposal_currency").val();
        let selectedCurrencySymbol = $("#prposal_currency option:selected").data('code'); // optional: fetch via AJAX
        let CurrencySymbol = $("#prposal_currency option:selected").data('symbol'); // optional: fetch via AJAX
        $('.currency_symb').text(CurrencySymbol) 
         let package_id = $("#package_id").val();
         var serv_prod_chk = document.getElementById("serv_prod_chk");
        
        
         if (serv_prod_chk.checked) {
              $(".product_card").each(function() {
                    let productId = $(this).data('product-id');
                    let cardId = $(this).attr('id');
                    let chooseButton = $(this).find(".chse_me_btta");
                    let priceElement = $(this).find(".product_base_price");
                    let modalInput = $("#product_amount_edit_" + productId);
                    let minAmount = $("#product_min_amount_" + productId);
                    let product_amount = $("#product_amount_" + productId);
            
                    if (selectedCurrencyId == 70) {
                        // Restore default base price and variants
                        restoreDefaultPrices(productId);
                        chooseButton.prop('disabled', false).removeClass('disabled');
                        $(this).find(".pricebook-warning").remove();
                        return;
                    }
                    $(this).find(".pricebook-warning").remove();
                    if (selectedCurrencyId != 70 && selectedCurrencyId !="") {
                        $.ajax({
                            url: "/get-product-price",
                            method: "GET",
                            data: { currency_id: selectedCurrencyId, product_id: productId },
                            success: function(res) {
                               
                                if (res && res.found) {
                                    let symbol = res.currency_symbol;
                                    let basePrice = parseFloat(res.base_price).toFixed(2);
                                    let minAmountFetch = parseFloat(res.min_amount).toFixed(2);
                                    priceElement.html(symbol + " " + basePrice);
                                    modalInput.val(basePrice);
                                    minAmount.val(minAmountFetch);
                                    product_amount.val(basePrice);
                                    
                                    
                                   
                
                                    // Update variant prices
                                    // if (res.variant_details) {
                                    //     res.variant_details.forEach(function(v) {
                                    //         let radio = $("input[name='variable_radio_[" + v.variable_id + "]']");
                                    //         radio.closest("label").find(".badge").html(symbol + " " + parseFloat(v.amount).toFixed(2));
                                    //     });
                                    // }
                                    
                                     if (Array.isArray(res.variant_details)) {
                                            res.variant_details.forEach(function (variant) {
                                              
                                                // Update variant price badge
                                               
                                                // $('#variant_price_14').text(symbol + " " + formatNumber(variant.amount));
                                                $("#variant_price_" + variant.variable_id)
                                                    .html(symbol + " " + formatNumber(variant.amount));
                        
                                                // Update data-amount for calculations
                                                $("input[value='" + variant.variable_id + "']")
                                                    .attr("data-amount", variant.amount);
                                            });
                                        }
                
                                    chooseButton.prop('disabled', false).removeClass('disabled');
                                    $(this).find(".pricebook-warning").remove();
                                } else {
                                    // No price found in pricebook
                                    chooseButton.prop('disabled', true).addClass('disabled');
                                    if (!$(this).find(".pricebook-warning").length) {
                                        $(this).append(`<div class="text-danger fs-6 fw-semibold pricebook-warning text-center mb-2 ">Set ${selectedCurrencySymbol} Amount in Pricebook</div>`);
                                    }
                                }
                            }.bind(this)
                        });
                    }
                    
                });
         }
         
       if (selectedCurrencyId != '') {
        $.ajax({
            url: "/get-addon-price",  // Use the same endpoint for add-ons
            method: "GET",
            data: { currency_id: selectedCurrencyId },
            success: function (res) {
                if (res && res.priceDataAddon) {
                    console.log('addon response', res.priceDataAddon);

                    if (selectedCurrencyId != 70) {
                        if (res.priceDataAddon.length <= 0) {
                            $(".add-on-setwarning").text('Set ' + selectedCurrencySymbol + ' Amount in Pricebook');
                            $("#prod_add_on").prop('disabled', true);
                        } else {
                            $(".add-on-setwarning").text('');
                            $("#prod_add_on").prop('disabled', false);
                        }

                        // Loop through each add-on in `addOnProductList` and check if it exists in the response
                        addOnProductList.forEach(function (addOn) {
                            let addonExistsInResponse = res.priceDataAddon.some(function (responseAddon) {
                                return responseAddon.addon_id == addOn.sno; // `addOn.sno` corresponds to addon_id
                            });

                            if (!addonExistsInResponse) {
                                // Disable checkbox if addon is not in the response
                                $("#addOn_chk_" + addOn.sno).prop('disabled', true);
                                if (!$("#addOn_chk_" + addOn.sno).next(".pricebook-warning").length) {
                                    $("#addOn_chk_" + addOn.sno).after(`
                                        <div class="text-danger fs-6 fw-semibold pricebook-warning text-center mb-2">
                                            Set Amount in Pricebook
                                        </div>
                                    `);
                                }
                            } else {
                                // Enable checkbox if addon exists in the response
                                $("#addOn_chk_" + addOn.sno).prop('disabled', false);
                                $("#addOn_chk_" + addOn.sno).next(".pricebook-warning").remove();
                            }
                        });
                    }
                    // Handle price updates for variants (free or paid)
                    res.priceDataAddon.forEach(function (addon) {
                        let addonId = addon.addon_id;
                        let variants = JSON.parse(addon.varient_details);

                        variants.forEach(function (variant) {
                            let price = variant.amount;
                            let varient_id = variant.variant_id;
                            // Handle free addon variants
                            if (variant.free_paid === 0) {
                                $("#addon_variant_price_" + varient_id).text(price);
                                $("input[name='addon_amount_" + varient_id + "']").val(0);
                            } else {
                                $("#addon_variant_price_" + varient_id).text(price);
                                $("input[name='addon_amount_" + varient_id + "']").val(price);
                            }
                        });
                    });
                }
            }
        });
    }

         
             
       
    }
    
    function formatNumber(num) {
        return Number(num).toLocaleString("en-IN");
    }

    

    function restoreDefaultPrices(productId) {
        let defaultPrice = $("#product_amount_default_" + productId).val();
        let defaultMinPrice = $("#product_min_amount_default_" + productId).val();
        
        $("#product_amount_" + productId).val(defaultPrice);
        $("#product_min_amount_" + productId).val(defaultMinPrice);
        $("#product_amount_edit_" + productId).val(defaultPrice);
        $("#product_base_price_" + productId).html("₹ " + defaultPrice);
        
        $(`#product_id_${productId}`)
        .closest(".product_card")
        .find(".variant_price")
        .each(function () {
            let variantId = this.id.replace("variant_price_", ""); // extract ID
            let defaultVariantPrice = $("#variant_price_default_" + variantId).val();
            // console.log(defaultVariantPrice)
            // Update the price label
            $(this).html("₹ " + formatNumber(defaultVariantPrice));

            // Update data-amount for calculation
            $(`input[value='${variantId}']`).attr("data-amount", defaultVariantPrice);
        });
    }

  function product_list() {
      var id = {{$Inserted_id}};
      var currency_id =$('#prposal_currency').val() == '' ? '70' :$('#prposal_currency').val() ;
      fetch('/product_list_proposal/' + id, {
          method: 'GET',
          data:{currency_id:currency_id},
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}'
          }
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === 200) {
              var record = data.data;
              $('#selected_product_list_div').empty().html(record);
              
              $('[data-bs-toggle="tooltip"]').tooltip();
              if (Array.isArray(data.product_ids)) {
                  data.product_ids.forEach(function(product_id) {
                    //   $('#choose_me_button' + product_id).hide();
                      $('#card_color_' + product_id).addClass('bg-label-success_card');

                  });
              }
               if (data.productCounts) {
                    Object.entries(data.productCounts).forEach(([productId, count]) => {
                        $('#product_count_' + productId ).text(String(count).padStart(2, '0'));
                    });
                }
              $('.over_all_total').empty().html(formatCurrency(data.over_all_total));
              $('#over_all_total_amount').val(data.over_all_total);
              $('.overall_totalDuration').empty().html(data.overall_totalDuration).attr('title',data.overall_totalDuration);
              $('#overall_total_Duration').val(data.overall_totalDuration);
              calculateOverTotal()
              payment_slot_list()
              
              if(data.product_cart_count>0){
                 coupon_code_func()
                  $('#prposal_currency').prop('disabled', true);
                  $('#prposal_currency_hidden').val(currency_id);
              }else{
                  $('#prposal_currency').prop('disabled', false);
              }
              
             let temp_id = {{$Inserted_id}}; 
                 $.ajax({
                    url: "/product_cart_List",
                    type: "GET",
                    data:{id:temp_id},
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                                ProductListCache = response.data; // Store it for reuse
                                
                                populateProductDropdowns(0, `#product_cart_id_1`);
                            
                        }
                    },
                    error: function(error) {
                        // console.error('Error fetching course categories:', error);
                    }
                });
           

          } else {
              // console.error(data.error_msg);
          }
      })
      .catch(error => {
          // console.error('Error:', error);
    });
  }
</script>
<script>
  function remove_product(id,product_id){
    // alert(id)
     fetch('/product_list_proposal_delete/' + id, {
          method: 'GET',
          headers: {
              'Content-Type': 'application/json',
              'X-CSRF-TOKEN': '{{ csrf_token() }}'
          }
      })
      .then(response => response.json())
      .then(data => {
          if (data.status === 200) {
             product_list();
            //  $('#choose_me_button' + product_id).show();
             $('#card_color_' + product_id).removeClass('bg-label-success_card');
          } else {
              // console.error(data.error_msg);
          }
      })
      .catch(error => {
          // console.error('Error:', error);
    });
  }
</script>
<script>

  function  add_product(product_id,product_amount) {
    let insertedId = $(`#Inserted_id_product`).val();
    let selectedVariants = [];
    
    let $addBtn = $('#add_product_button_' + product_id);
    $addBtn.prop('disabled', true);
     var currency_id =$('#prposal_currency').val() == '' ? '70' :$('#prposal_currency').val() ;
    
      const product_edit_amount=$(`#product_amount_edit_${product_id}`).val();

   let modal = $(`#kt_modal_choose_me_${product_id}`);
   let total_product_amount = parseFloat(product_amount) || 0; 
   
    modal.find('input[type="checkbox"].form-check-input:checked').each(function () {
      let checkbox = $(this);
      let variantId = checkbox.attr('id').split('_').pop(); // variant sno
      let $selectedVariable = $(`.variable_radio_${variantId}:checked`);
      let variableId = $selectedVariable.val();
      let variableAmount = $selectedVariable.data('amount');

      if (variableId) {
             total_product_amount += variableAmount;
        // Avoid duplicates if needed
        let alreadyAdded = selectedVariants.some(item => item.variant_id === variantId);
        if (!alreadyAdded) {
          selectedVariants.push({
            variant_id: variantId,
            variable_id: variableId
          });
        }
      }
    });

    // Prepare data object
    let payload = {
      inserted_id: insertedId,
      product_id: product_id,
      currency_id: currency_id,
      product_amount: total_product_amount,
      product_edit_amount: product_edit_amount,
      variants: selectedVariants
    };

    $.ajax({
      url: "{{ route('proposal/product_add') }}",
      method: "POST",
      data: JSON.stringify(payload),
      contentType: "application/json",
      headers: {
        'X-CSRF-TOKEN': '{{ csrf_token() }}'
      },
      beforeSend: function () {
        // Optional: Show loader or disable button
      },
      success: function (response) {
        if (response.status === true) {
            $addBtn.prop('disabled', false);
              $(`#product_amount_edit_${product_id}`).val(product_amount);
          Swal.fire({
            title: 'Product Added',
            text: 'The product has been added successfully!',
            icon: 'success',
            customClass: {
              confirmButton: 'btn btn-primary waves-effect waves-light'
            },
            buttonsStyling: false
          });
          product_list();
        //   $('#choose_me_button' + product_id).hide();
          $('#kt_modal_choose_me_triger' + product_id).click();
        } else {
            $addBtn.prop('disabled', false);
          Swal.fire({
            title: "Couldn't Add Product",
            text: 'Something might have gone wrong.',
            icon: 'warning',
            customClass: {
              confirmButton: 'btn btn-primary waves-effect waves-light'
            },
            buttonsStyling: false
          });
          $('#kt_modal_choose_me_triger' + product_id).click();
        }
      },
      error: function (xhr) {
          $addBtn.prop('disabled', false);
        Swal.fire({
          title: "Couldn't Add Product",
          text: 'Something might have gone wrong. Please verify.',
          icon: 'error',
          customClass: {
            confirmButton: 'btn btn-primary waves-effect waves-light'
          },
          buttonsStyling: false
        });
      }
    });
  }
</script>
<script>
  function edit_product(product_id) {
     let modal = $(`#kt_modal_choose_me_edit_${product_id}`);
    let insertedId = $(`#Inserted_id_product_edit`).val();
    let selectedVariants = [];
    
    // Loop through all checked variant checkboxes
     modal.find(`input[id^="variant_check_box_edit"]:checked`).each(function () {
        let variantId = $(this).attr('id').replace('variant_check_box_edit', '');
        let variableId = modal.find(`.variable_radio_edit${variantId}:checked`).val();

        if (variableId) {
            selectedVariants.push({
                variant_id: variantId,
                variable_id: variableId
            });
        }
    });

    // Prepare data object
    let payload = {
        inserted_id: insertedId,
        product_id: product_id,
        variants: selectedVariants
    };

    $.ajax({
        url: "{{ route('proposal/product_add') }}",
        method: "POST",
        data: JSON.stringify(payload),
        contentType: "application/json",
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}'
        },
        beforeSend: function () {
            // Optional: Show loader or disable button
        },
        success: function (response) {
            if (response.status === true) {
                Swal.fire({
                    title: 'Product Update',
                    text: 'The product has been updated successfully!',
                    icon: 'success',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                product_list();
                $(`#kt_modal_choose_me_triger_edit${product_id}`).click();
            } else {
                Swal.fire({
                    title: "Couldn't update Product",
                    text: 'Something might have gone wrong.',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                $(`#kt_modal_choose_me_triger_edit${product_id}`).click();
            }
        },
        error: function () {
            Swal.fire({
                title: "Couldn't update Product",
                text: 'Something might have gone wrong. Please verify.',
                icon: 'error',
                customClass: {
                    confirmButton: 'btn btn-primary waves-effect waves-light'
                },
                buttonsStyling: false
            });
        }
    });
}
</script>

<!-- Add On Total -->
<script>
    function calculateAddonTotal() {
        
        let total = 0;
        $('.add_on_product:checked').each(function () {
            const container = $(this).closest('.px-3');
            const selectedVarient = container.find('.add_on_varient:checked');
             const amount = parseFloat(selectedVarient.closest('.form-check').find('.addon_amount').val()) || 0;
            total += amount;
        });

        // Update display and hidden field
        $('#addon_total_amount').text(total.toFixed(2));
        $('#addon_total_amount_value').val(total.toFixed(2));
    }

        function product_add_on_func() {
            var currency_id =$('#prposal_currency').val() == '' ? '70' :$('#prposal_currency').val() ;
            if ($('#prod_add_on').is(':checked')) {
                $('#view_product_add_on').show();
                  $('#prposal_currency').prop('disabled', true);
                  $('#prposal_currency_hidden').val(currency_id);
                     
            } else {
                 $('#prposal_currency').prop('disabled', false);
                $('#view_product_add_on').hide();

                // Reset totals
                $('#addon_total_amount').text('0.00');
                $('#addon_total_amount_value').val(0);

                // Optionally uncheck all add-ons and variants
                $('.add_on_product').prop('checked', false);
                $('.add_on_varient').prop('checked', false);
            }

            calculateAddonTotal();
            calculateOverTotal()
        }

        $(document).ready(function () {
            
             $(document).on('change', '.prod_add_on', function () {
                if ($(this).is(':checked')) {
                    // âœ… Check first add_on_product
                    const firstProduct = $('.add_on_product').first();
                    firstProduct.prop('checked', true);
        
                    // âœ… Select its first variant
                    const firstVar = firstProduct.closest('.px-3').find('.add_on_varient').first();
                    if (firstVar.length) {
                        firstVar.prop('checked', true);
                    }
                } else {
                    // âœ… Uncheck everything if prod_add_on is unchecked
                    $('.add_on_product').prop('checked', false);
                    $('.add_on_varient').prop('checked', false);
                }
        
                calculateAddonTotal();
                calculateOverTotal();
            });
            // Handle add_on_product checkbox change
            $(document).on('change', '.add_on_product', function () {
                const container = $(this).closest('.px-3');
                if ($(this).is(':checked')) {
                    container.find('.add_on_varient').prop('checked', false);
                    container.find('.add_on_varient').first().prop('checked', true);
                } else {
                    container.find('.add_on_varient').prop('checked', false);
                }
                calculateAddonTotal();
                calculateOverTotal()
            });

            // Handle varient radio change
            $(document).on('change', '.add_on_varient', function () {
                calculateAddonTotal();
                calculateOverTotal()
            });

            // Initial calculation on page load
            product_add_on_func();


            
        });


        function calculateOverTotal() {
            
            let subTotal = 0;
            let product_total=  parseFloat($('#over_all_total_amount').val().replace(/[^0-9.-]+/g, "")) ;
            let addOn_total=  parseFloat($('#addon_total_amount_value').val().replace(/[^0-9.-]+/g, "")) ;

            // var additional_charges =  parseFloat($('#additional_charges').val().replace(/[^0-9.-]+/g, "")) || 0 ;
            
            subTotal =product_total + addOn_total;
           console.log(subTotal)
            $('#sub_total').text(subTotal.toFixed(2));
            $('#sub_total_amount').val(subTotal.toFixed(2));
         

            const gstPercentage = {{ $branch_data->gst_percentage ?? 0 }};
             $('#gstPercentage').text(gstPercentage);

             var discount_amount = $('#discounted_amount_hidden').val();
          
             var proposal_total_amount= discount_amount < subTotal ? subTotal - discount_amount : 0  ;
             
              let totalAdditionalPercent = 0;
                $('#addtional_charges_id option:selected').each(function() {
                    let percent = parseFloat($(this).data('percent')) || 0;
                    totalAdditionalPercent += percent;
                });
                
                 // Calculate additional amount based on grand total and additional percentage
                let additionalAmount = (proposal_total_amount * totalAdditionalPercent) / 100;
                
                 $('#additional_charge_perc_label').text(totalAdditionalPercent)
                $('#additional_charge_amount_label').text(formatCurrency(additionalAmount))
                $('#additional_charge_amount').val(additionalAmount)
                $('#additional_charge_perc').val(totalAdditionalPercent)
                
                
                 proposal_total_amount += additionalAmount
            var gst_check_inclus = $('#gst_inclusive').val();
              const gstPercentBranch = {{ $branch_data->gst_percentage }} ; 
              
              const gstRate = {{ $branch_data->gst_percentage }} / 100; 
               var gstAmount=0;
                var grant_total=0;
               if(gst_check_inclus == 1){
                   const baseAmount = (proposal_total_amount * 100) / (100 + gstPercentBranch);
                    gstAmount = proposal_total_amount - baseAmount;
                    grant_total = baseAmount;
               }else{
                   gstAmount = proposal_total_amount * gstRate;
                    grant_total = proposal_total_amount + gstAmount;
               }
              
  
              
            //   if(gst_check_inclus == 1){
            //          grant_total= proposal_total_amount - gstAmount;
            //   }else{
            //          grant_total= proposal_total_amount + gstAmount;
            //   }
             

             

             

               

                

                // Add additional amount to grand total
                // grant_total += additionalAmount
//  console.log(proposal_total_amount)


            $('#proposal_total_amount').val(proposal_total_amount);
            $('#grant_total_amount').val(grant_total);
          
           $('#payment_slot_total_hidden').val(proposal_total_amount);
            $('#proposal_total_amount_fetch').text(formatCurrency(proposal_total_amount));
            $('#gst_maount_out_label').text(formatCurrency(gstAmount));
            $('#gst_amount_hidden').val(gstAmount);
            $('#grant_total_label').text(formatCurrency(grant_total));

            $('#proposal_total_amount_packg').val(proposal_total_amount);
            $('#grant_total_amount_packg').val(grant_total);
         
           $('#payment_slot_total_hidden_packg').val(proposal_total_amount);
            $('#gst_amount_hidden_packg').val(gstAmount);

            if (!preProposalData.slot_balance) {
               
                $('#payment_slot_total_amt').val(proposal_total_amount);
                $('#payment_slot_total_amt_packg').val(proposal_total_amount);
                $('.split_balance_label').text(formatCurrency(proposal_total_amount));
                $('.split_balance_label_packg').text(formatCurrency(proposal_total_amount));
            }
         
           

        }

        function calculationSplit(val, indx) {
            // Sanitize current value
            let currentVal = parseFloat(val) || 0;
            

            // Get total payment amount
            let totalAmount = parseFloat($('#payment_slot_total_amt').val()) || 0;
           

            // Initialize sum of all entered slot amounts
            let sumOfAllSlots = 0;

            // Loop through all slot amount inputs
            $('.payment_slot_amount').each(function () {
                let amount = parseFloat($(this).val()) || 0;
                sumOfAllSlots += amount;
            });
    
            // Validate the current field individually
           

            // Calculate remaining balance
            let balanceAmount = totalAmount - sumOfAllSlots;
            balanceAmount = balanceAmount < 0 ? 0 : balanceAmount;
            
                 console.log("totalAmount",totalAmount)
               console.log(`currentVal ${sumOfAllSlots} > balanceAmount ${totalAmount} : ${sumOfAllSlots > totalAmount}`);

            var milestone_count = $('#milestone_count').val();
             if (sumOfAllSlots > totalAmount) {
                $(`#payment_slot_amount_err_${indx}`).text('Milestone Amount must be less than or equal to Total Amount.');
                $('#addPaymentSlotBtn').prop('disabled', true);
            }else if(milestone_count != cugAssignCounter){
                $(`#payment_slot_amount_packg_err_${indx}`).text('');
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            } else {
                $(`#payment_slot_amount_err_${indx}`).text('');
                $('#addPaymentSlotBtn').prop('disabled', false);
            }


            // Update the label and hidden balance input
            $('.split_balance_label').text(formatCurrency(balanceAmount));
            $('#slot_balance_amt').val(balanceAmount);
            if(balanceAmount == 0){
                
                $('#pymt_slot_create_add').prop('disabled', true);
            }else{
                 $('#pymt_slot_create_add').prop('disabled', false);
            }
        }


</script>

<script>

        function coupon_code_func() {
            var code = $('#new_coupon_code').val().trim();
            var amount = $('#sub_total_amount').val() 
              console.log(amount)
            if(amount>0){
                if (code !== '') {
                  
                    $.ajax({
                        url: "{{ route('get_couponcode') }}",
                        type: "GET",
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        },
                        data: {
                            couponcode: code
                        },
                        success: function(response) {
                            // Hide error message initially
                            $('.new_coupon_code_err').hide();

                            if (response.status === 200) {
                                $('#discount_id_hidden').val(response.discount_id);
                                const discount_type = response.discount_type; // 0 for percentage, 1 for flat
                                let discount = response.discount;
                                let discount_type_label;
                                // Update fees based on discount
                                const maxPrice = parseFloat($('#sub_total_amount').val().replace(/[^0-9.-]+/g, "")) || 0;
                                let CurrencySymbol = $("#prposal_currency option:selected").data('symbol');

                                if (discount_type === 0) {
                                    discount_type_label = discount + '%';
                                    discount = discount / 100; // Convert percentage to decimal
                                    // Calculate the discount amount
                                    var discountAmount = amount * discount;
                                } else {
                                     discount_type_label = CurrencySymbol+' '+ discount;
                                    discount = discount; // Convert percentage to decimal
                                    var discountAmount = discount;
                                }
                                
                                // Update UI with coupon details
                                $('#discount_type_label').text('(' + discount_type_label + ')');
                                $('#coupon_code_label').text('[' + code + ']');
                                document.getElementById("coup_tbox").style.setProperty("display", "none", "important");
                                document.getElementById("coup_label_box").style.setProperty("display", "flex", "important");
                                updateFees_out(amount,discountAmount);
                                calculateOverTotal() 

                            } else if (response.status === 404) {
                                $('.new_coupon_code_err').text(response.message).show(); // Show error message
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching coupon details:', error);
                            $('.new_coupon_code_err').text('Invaild coupon code.').show();
                        }
                    });
                } 
            }
        }

        function updateFees_out(maxPrice, Discount) {
            // Ensure Discount is a valid number; default to 0 if invalid
            const validDiscount = Discount || 0;
            // Calculate the course fee after discount
            const finalCourseFeeBeforeGst = maxPrice - validDiscount;
            // Add GST (e.g., 18%)
            // Update the UI with the calculated values
            $('#discounted_amount_label').text(formatCurrency(validDiscount));
            $('#discounted_amount_hidden').val(validDiscount);

        }
        
        

    function reset_coupon_func() {

        document.getElementById("coup_label_box").style.setProperty("display", "none", "important");
        document.getElementById("coup_tbox").style.setProperty("display", "flex", "important");
        $('#new_coupon_code').val('');
        $('#discounted_amount_hidden').val(0)
         $('#discount_id_hidden').val('');
        $('.new_coupon_code_err').text('');
        $('#coupon_code_label').text('');
        const maxPrice = 0;
        updateFees_out(maxPrice, 0);calculateOverTotal();
       
    }
</script>
<!-- <script>
    function submit_form() {
            $('#addForm').submit();
        }

        function AddvalidateForm() {
            var err = 0;

            var service_title = $('#service_title').val();
            if (service_title === "") {
                    $('#service_title_err').text('Service Title is required.');
                    err++;
            }else{
                $('#service_title_err').text('');
            }

            var prposal_due_date = $("#prposal_due_date").val().trim();
            if (prposal_due_date === "") {
                $('#prposal_due_date_err').text('Due Date is required.');
                err++;
            }else{
                $('#prposal_due_date_err').text('');
            }

            var prposal_currency = $("#prposal_currency").val().trim();
            if (prposal_currency === "") {
                $('#prposal_currency_err').text('Currency Format is required.');
                err++;
            }else{
                $('#prposal_currency_err').text('');
            }

            if (err == 0) {
                var staff_name = $("#staff_name").val().trim();
                $('#create_staff_label').html(staff_name);
                $('#submit_popup').click();

            }
            
        }
</script> -->

<script>
    var cugAssignCounter = 1;
    var paymentSlotListCache = [];
    var deliverablesListCache = [];
    var notesListCache = [];
    var ProductListCache = [];
    $.ajax({
        url: "/payment_slot_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    paymentSlotListCache = response.data; // Store it for reuse
                populateSlotDropdowns(0, `#payment_slot_id_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });
   function populateSlotDropdowns(val, targetDropdown) {
        var selectedValues = $('.payment_slot_id').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Payment Milestone</option>');

        paymentSlotListCache.forEach(function (slot) {
            if (!selectedValues.includes(slot.sno.toString()) || slot.sno.toString() === currentValue) {
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.payment_slot_name));
            }
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }

    $.ajax({
        url: "/deliverable_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    deliverablesListCache = response.data; 
                    populateDeliverablesDropdowns(0, `#slot_deliverables_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

   function populateDeliverablesDropdowns(val, targetDropdown) {
    var selectedDeliverables = {};

    // Gather all selected deliverables per product across all rows
    $('.slot_deliverables').each(function () {
        var selected = $(this).val();
        if (selected) {
            selected.forEach(function (item) {
                var [prodId, delivId] = item.split('-');
                if (!selectedDeliverables[prodId]) {
                    selectedDeliverables[prodId] = new Set();
                }
                selectedDeliverables[prodId].add(delivId);
            });
        }
    });

    var $dropdown = $(targetDropdown);
    var currentValue = $dropdown.val();
    $dropdown.empty();
    $dropdown.append('<option value="">Select Deliverables</option>');

    // Get the corresponding product select for this dropdown
    var dropdownId = $dropdown.attr('id');
    var index = dropdownId.split('_').pop();
    var $productSelect = $(`#product_cart_id_${index}`);
    var selectedProductIds = $productSelect.val();

    if (!selectedProductIds || selectedProductIds.length === 0) {
        $dropdown.append('<option disabled>Please select products first</option>');
        return;
    }

    selectedProductIds.forEach(function (productId) {
        var productName = $productSelect.find(`option[value="${productId}"]`).text().trim();
        var group = $('<optgroup></optgroup>').attr('label', productName);

        deliverablesListCache.forEach(function (item) {
            var deliverableAlreadyUsed = selectedDeliverables[productId]?.has(item.sno.toString());

            // Check if this deliverable is selected in another row for the same product
            if (!deliverableAlreadyUsed || currentValue?.includes(`${productId}-${item.sno}`)) {
                group.append($('<option></option>')
                    .attr('value', `${productId}-${item.sno}`)
                    .text(`${item.delivarable_name} (${productName})`)
                );
            }
        });

        $dropdown.append(group);
    });

    // Restore previous selection if present
    if (val) {
        $dropdown.val(val).trigger('change');
    } else if (currentValue) {
        $dropdown.val(currentValue);
    }
}



     $.ajax({
        url: "/slot_notes_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    notesListCache = response.data; // Store it for reuse
                 
                    populateNotesDropdowns(0, `#slot_notes_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateNotesDropdowns(val, targetDropdown) {
        var selectedNotes = {};
        
        // Gather all selected deliverables per product across all rows
            $('.slot_notes').each(function () {
                var selected = $(this).val();
                if (selected) {
                    selected.forEach(function (item) {
                        var [prodId, delivId] = item.split('-');
                        if (!selectedNotes[prodId]) {
                            selectedNotes[prodId] = new Set();
                        }
                        selectedNotes[prodId].add(delivId);
                    });
                }
            });
            
            var $dropdown = $(targetDropdown);
            var currentValue = $dropdown.val();
            $dropdown.empty();
            $dropdown.append('<option value="">Select Milestone Notes</option>');
        
            // Get the corresponding product select for this dropdown
            var dropdownId = $dropdown.attr('id');
            var index = dropdownId.split('_').pop();
            var $productSelect = $(`#product_cart_id_${index}`);
            var selectedProductIds = $productSelect.val();
        
            if (!selectedProductIds || selectedProductIds.length === 0) {
                $dropdown.append('<option disabled>Please select products first</option>');
                return;
            }
        
            selectedProductIds.forEach(function (productId) {
                var productName = $productSelect.find(`option[value="${productId}"]`).text().trim();
                var group = $('<optgroup></optgroup>').attr('label', productName);
        
                notesListCache.forEach(function (item) {
                    var deliverableAlreadyUsed = selectedNotes[productId]?.has(item.sno.toString());
        
                    // Check if this deliverable is selected in another row for the same product
                    if (!deliverableAlreadyUsed || currentValue?.includes(`${productId}-${item.sno}`)) {
                        group.append($('<option></option>')
                            .attr('value', `${productId}-${item.sno}`)
                            .text(`${item.slot_notes_name} (${productName})`)
                        );
                    }
                });
        
                $dropdown.append(group);
            });
        
        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }
    
    var temp_id = {{$Inserted_id}}; 
     $.ajax({
        url: "/product_cart_List",
        type: "GET",
        data:{id:temp_id},
        success: function(response) {
            if (response.status === 200 && response.data) {
                    ProductListCache = response.data; // Store it for reuse
                    
                    populateProductDropdowns(0, `#product_cart_id_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateProductDropdowns(val, targetDropdown) {
        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Products</option>');
    
        // Step 1: Group products by `sno`
        var groupedBySno = {};
        ProductListCache.forEach(function (slot) {
            if (!groupedBySno[slot.sno]) {
                groupedBySno[slot.sno] = [];
            }
            groupedBySno[slot.sno].push(slot);
        });
    
        // Step 2: Generate dynamic product labels
        Object.keys(groupedBySno).forEach(function (sno) {
            var group = groupedBySno[sno];
    
            group.forEach(function (slot, index) {
                let label = slot.product_name;
                if (group.length > 1) {
                    label = `${slot.product_name}-${index+1}`;
                }
    
                $dropdown.append($('<option></option>')
                    .attr('value', slot.cart_id)
                    .text(label));
            });
        });
    
        // Restore selection
        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }




     $(document).ready(function() {
        $('.pymt_slot_create_add').on('click', function() {
            
            // Increment the counter
            // Create the new requirement row dynamically
            cugAssignCounter++;
            var newRequirementHtml = `
                    <div data-repeater-list="group-a_led_question" id="assign_row_${cugAssignCounter}">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                            <select class="select3 form-select payment_slot_id" name="payment_slot_id_${cugAssignCounter}" id="payment_slot_id_${cugAssignCounter}">
                                                <option value="">Select Payment Milestone</option>
                                            </select>
                                            <div class="text-danger err_mssg fs-7 payment_slot_id_err" id="payment_slot_id_err_${cugAssignCounter}" ></div>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control payment_slot_amount" placeholder="Enter Milestone Amount " name="payment_slot_amount_${cugAssignCounter}" id="payment_slot_amount_${cugAssignCounter}" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" onkeyup="calculationSplit(this.value,${cugAssignCounter})" />
                                          <div class="text-danger err_mssg fs-7 payment_slot_amount_err" id="payment_slot_amount_err_${cugAssignCounter}" ></div>
                                        </div>
                                        <div class="col-lg-8 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Select Type<span
                                                    class="text-danger">*</span></label>
                                            <div class="d-flex ">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver" type="radio" name="to_start_deliver_${cugAssignCounter}" id="to_start_deliver_radio1" value="1" checked />
                                                    <label class="form-check-label" for="inlineRadio1">To Start The Work</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver" type="radio" name="to_start_deliver_${cugAssignCounter}" id="to_start_deliver_radio2" value="2" />
                                                    <label class="form-check-label" for="inlineRadio2">To Deliver The Work</label>
                                                </div>
                                            </div>
                                            <div class="text-danger" id="to_start_deliver_err_${cugAssignCounter}"></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Products<span class="text-danger">*</span></label>
                                            <select class="select3 form-select product_cart_id" multiple data-placeholder="Select Products" name="product_cart_id_${cugAssignCounter}[]" id="product_cart_id_${cugAssignCounter}"  onchange="ChangeProduct(this)">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 product_cart_id_err" id="product_cart_id_err_${cugAssignCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_deliverables" multiple data-placeholder="Select Deliverables" name="slot_deliverables_${cugAssignCounter}[]" id="slot_deliverables_${cugAssignCounter}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_deliverables_err" id="slot_deliverables_err_${cugAssignCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_notes" multiple data-placeholder="Select Milestone Notes" name="slot_notes_${cugAssignCounter}[]" id="slot_notes_${cugAssignCounter}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_notes_err" id="slot_notes_err_${cugAssignCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1" placeholder="Enter Deliverables" name="slot_description_${cugAssignCounter}" id="slot_description_${cugAssignCounter}"></textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_create_del" id="pymt_slot_create_del_${cugAssignCounter}" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
            `;
            // Append the new requirement row
            $('#repeater_req').first().parent().append(newRequirementHtml);

    
            populateSlotDropdowns(0, `#payment_slot_id_${cugAssignCounter}`);
            populateDeliverablesDropdowns(0, `#slot_deliverables_${cugAssignCounter}`);
            populateNotesDropdowns(0, `#slot_notes_${cugAssignCounter}`);
            populateProductDropdowns(0, `#product_cart_id_${cugAssignCounter}`);

           $(`#payment_slot_id_${cugAssignCounter}`).select2({
                dropdownParent: $(`#payment_slot_id_${cugAssignCounter}`).closest('.col-lg-6'),
                width: '100%',
                
            });

            $(`#slot_deliverables_${cugAssignCounter}`).select2({
                dropdownParent: $(`#slot_deliverables_${cugAssignCounter}`).closest('.col-lg-12'),
                width: '100%',
            });

            $(`#slot_notes_${cugAssignCounter}`).select2({
                dropdownParent: $(`#slot_notes_${cugAssignCounter}`).closest('.col-lg-12'),
                width: '100%',
            });
            
             $(`#product_cart_id_${cugAssignCounter}`).select2({
                dropdownParent: $(`#product_cart_id_${cugAssignCounter}`).closest('.col-lg-12'),
                width: '100%',
            });
            
            $(`#product_cart_id_${cugAssignCounter}`).on('change', function () {
                populateDeliverablesDropdowns(0, `#slot_deliverables_${cugAssignCounter}`);
                 populateNotesDropdowns(0, `#slot_notes_${cugAssignCounter}`);
            });
            
            // Show the delete button for the new row
            $('#pymt_slot_create_del_' + cugAssignCounter).show();
            
            const currencySelect = document.getElementById('prposal_currency');
             const selectedOption = currencySelect.options[currencySelect.selectedIndex];
             let selectedCurrencyCode = selectedOption.getAttribute('data-code');
             
           
            
             var milestone_count = $('#milestone_count').val();
                if(milestone_count <= cugAssignCounter){
                    $('#pymt_slot_create_add').prop('disabled', true);
                }else{
                     $('#pymt_slot_create_add').prop('disabled', false);
                }
                
                if (milestone_count <= cugAssignCounter) {
                    $('#addPaymentSlotBtn').prop('disabled', false);
                }else {
                    $('#addPaymentSlotBtn').prop('disabled', true);
                }

            // Hide delete button for the first requirement
        });

        // Delete a requirement row
        $(document).on('click', '.pymt_slot_create_del', function(e) {
            var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
            var index = deleteId.split('_')[4];  
            // Remove the row
            $('#assign_row_' + index).slideUp(400, function() {
                $(this).remove(); // Remove the row
                calculationSplit(0,index)
                cugAssignCounter--; // Decrement counter
                // Hide the delete button for the first row if there is only one remaining row
                if (cugAssignCounter === 1) {
                    $('#pymt_slot_create_del_1').hide();
                }
                
                if(milestone_count <= cugAssignCounter){
                    $('#pymt_slot_create_add').prop('disabled', true);
                }else{
                     $('#pymt_slot_create_add').prop('disabled', false);
                }
                
                if (milestone_count <= cugAssignCounter) {
                    $('#addPaymentSlotBtn').prop('disabled', false);
                }else {
                    $('#addPaymentSlotBtn').prop('disabled', true);
                }
                
            });
            
        });

       $('#addPaymentSlotBtn').on('click', function () {
            var valid = true;

            // Validate Payment Slot ID
            $('.payment_slot_id').each(function () {
                let slot_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_id_err');

                if (!slot_id_add) {
                    valid = false;
                    errDiv.text('Payment Milestone is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Amount
            $('.payment_slot_amount:visible:enabled').each(function () {
                let slot_amount_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_amount_err');

                if (!slot_amount_add || isNaN(slot_amount_add) || parseFloat(slot_amount_add) <= 0) {
                    valid = false;
                    errDiv.text('Valid Milestone Amount is required');
                } else {
                    errDiv.text('');
                }
            });
            
            const currencySelect = document.getElementById('prposal_currency');
             const selectedOption = currencySelect.options[currencySelect.selectedIndex];
             let selectedCurrencyCode = selectedOption.getAttribute('data-code');
            
             
            
            
            // Validate Products (multi-select)
            $('.product_cart_id:visible:enabled').each(function () {
                let product_cart_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.product_cart_id_err');

                if (!product_cart_id_add || product_cart_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Product is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Deliverables (multi-select)
            $('.slot_deliverables:visible:enabled').each(function () {
                let deliverable_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_deliverables_err');

                if (!deliverable_id_add || deliverable_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Deliverable is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Notes (multi-select)
            $('.slot_notes:visible:enabled').each(function () {
                let notes_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_notes_err');

                if (!notes_id_add || notes_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Note is required');
                } else {
                    errDiv.text('');
                }
            });
            
                 let totalAmount = parseFloat($('#payment_slot_total_amt').val()) || 0;

                // Initialize sum of all entered slot amounts
                let sumOfAllSlots = 0;
    
                // Loop through all slot amount inputs
                $('.payment_slot_amount').each(function () {
                    let amount = parseFloat($(this).val()) || 0;
                    sumOfAllSlots += amount;
                });
                    console.log(sumOfAllSlots >= totalAmount)
                    
                // Validate the current field individually
                if (sumOfAllSlots >= totalAmount) {
                     $('#payment_slot_total_amt_err').text('');
                  }else{
                     valid = false;
                     $('#payment_slot_total_amt_err').text('Milestone Split Amount Balance Must be Zero');
                      
                  }

            // Submit form if valid
            if (valid) {
                saveAccountDetailsToSession() 
                $('#addPaymentSlotform').submit();
                $('#addPaymentSlotBtn').prop('disabled', true);
            } else {
                $('#addPaymentSlotBtn').prop('disabled', false);
            }
        });


    });
   
</script>

<script>
     payment_slot_list()
    function payment_slot_list() {
        var id = {{$Inserted_id}};  // Ensure this is rendered by the backend
        fetch('/paymentSlotDetails/' + id, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            }
        })
        .then(response => response.json())
        .then(data => {
            if(data){
              var total_amount = $('#payment_slot_total_amt').val();
              var slot_amount =total_amount > 0 ? total_amount - data.slot_amount : 0;
               if(preProposalData.slot_balance){}
               else{
                    $('.split_balance_label').text(formatCurrency(slot_amount));
                    $('#slot_balance_amt').val(slot_amount);
                    $('#payment_slot_total_amt').val(slot_amount);
                }
            }
                
            if (data.status === 200 && Array.isArray(data.data)) {
                const records = data.data;
                const productCart = data.productCart;
                const slotUpdate = data.slotUpdate;
                const slotCount = data.slotCount;

                // Clear existing content before appending
                $('#payment_slot_list').empty();
                
                      if (records.length>0) {
            const html = `
                <div class="col-lg-4 mb-3">
                    <div class="card rounded pymt_bg" style="background-color:${slotUpdate > 0 ? '#7fffd494' : ''} !important;">
                        <div class="card-body px-3 pt-3 pb-2">
                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 rounded px-1 py-1">
                                <div class="d-flex align-items-center">
                                    <div class="me-2 cursor-pointer">
                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product & Category">
                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                        </a>
                                    </div>
                                    <div class="mb-0">
                                        <div class="text-black fs-7 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" title="${productCart.product_names || '-'}">${productCart.product_names || '-'}</div>
                                        <div class="text-black fs-8 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" title="${productCart.product_category_names || '-'}">${productCart.product_category_names || '-'}</div>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <a href="javascript:;" class="btn btn-sm btn-primary rounded-3 fw-semibold"
                                        style="display:${slotUpdate > 0 ? 'none' : 'block'} !important;"
                                        onclick="add_paymentSlot('${id}', '${productCart.product_names}', '${productCart.product_category_names}')">
                                        Add Milestone
                                    </a>
                                      <input type="hidden" name="slot_popup" id="slot_popup" data-bs-toggle="modal" data-bs-target="#kt_modal_add_payment_slot">
                                    <button type="button" class="btn btn-sm btn-primary rounded-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment_slot"
                                        style="display:none !important;" disabled
                                        onclick="updatePaymentSlot('${id}', '${productCart.product_name}', '${productCart.product_category_name}', '${JSON.stringify(productCart.update_slot)}')">
                                        Update Milestone
                                    </button>
                                </div>
                                <input type="hidden" class="slot_updated" value="${slotUpdate > 0 ? '1' : '0'}" />
                            </div>
                            <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
                                <div class="cursor-pointer border border-dashed border-gray-600i rounded px-2 py-1" id="aft_pymt_slt"
                                    style="display:${slotUpdate > 0 ? 'block' : 'none'} !important;">
                                    <a href="javascript:;" class="mb-0">
                                        <i class="mdi mdi-cash-clock fs-3 text-dark"></i>
                                    </a>
                                    <label class="ms-1 text-black fs-6 fw-semibold">Total Milestone</label>
                                    <label class="ms-2 text-black fs-6 fw-semibold">-</label>
                                    <label class="badge bg-secondary ms-2 text-white fs-7 fw-semibold">${slotCount || '01'}</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            $('#payment_slot_list').append(html);
        }

                // records.forEach(function(product, index) {
                
                   
                // });
            } else {
                console.warn('No data returned or unexpected format.');
            }
        })
        .catch(error => {
            console.error('Error fetching slot list:', error);
        });
        
         
            let allSlotsUpdated = false;
            $('.slot_updated').each(function() {
                allSlotsUpdated = true
                 
                if ($(this).val() !== '1') {
                    allSlotsUpdated = false;
                    return false; // break loop early
                }
            });
       
            if (allSlotsUpdated) {
                $('#verify_proposal').prop('disabled', false);
                $('#send_proposal').prop('disabled', false);
            } else {
                $('#verify_proposal').prop('disabled', true);
                $('#send_proposal').prop('disabled', true);
            }
      
       
    }

    function add_paymentSlot(cart_id,product_name,category_name){
            var err =0;
            var milestone_count = $('#milestone_count').val();
            var currency_id = $('#prposal_currency').val();
         
         const currencySelect = document.getElementById('prposal_currency');
         const selectedOption = currencySelect.options[currencySelect.selectedIndex];
         let selectedCurrencyCode = selectedOption.getAttribute('data-code');
         
         
        
      
            if (currency_id === "" || currency_id < 1) {
                   Swal.fire({
                    title: "Set Currency Format",
                    text: 'Select Currency Format',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                    err++;
            }
            
            if (milestone_count === "" || milestone_count < 1) {
                   Swal.fire({
                    title: "Set Milestone Count",
                    text: 'Milestone Count Must Be Greater than 0',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                    err++;
            }
            
            
            if(err==0){
                $('#curency_format_prdt').val(currency_id);
                $('#slot_popup').click();
                
            }
           
            
            if(milestone_count == 1){
                $('#pymt_slot_create_add').prop('disabled', true);
            }else if(milestone_count == cugAssignCounter){
                 $('#pymt_slot_create_add').prop('disabled', true);
            }else{
                 $('#pymt_slot_create_add').prop('disabled', false);
            }
            
            if (milestone_count == 1) {
                $('#addPaymentSlotBtn').prop('disabled', false);
            }else if(milestone_count == cugAssignCounter){
                $('#addPaymentSlotBtn').prop('disabled', false);
            } else {
                $('#addPaymentSlotBtn').prop('disabled', true);
            }
        $('#payment_product_name').text(product_name);
        $('#payment_product_cat_name').text(category_name);
        $('#payment_slot_product_id').val(cart_id);
    }

     function updatePaymentSlot(cart_id,product_name,category_name,data){
        $('#payment_product_name_edit').text(product_name);
        $('#payment_product_cat_name_edit').text(category_name);
        $('#payment_slot_product_id_edit').val(cart_id);

    }

</script>
<script>
    function create_proposal_func(proposal_id,lead_name,lead_id){
        var err=0;
       $('#send_communication').val(0);
         var service_title = $('#service_title').val();
            if (service_title === "") {
                    $('#service_title_err').text('Service Title is required.');
                    err++;
            }else{
                $('#service_title_err').text('');
            }
            
             var estimate_date = $('#estimate_date').val();
                if (estimate_date === "") {
                        $('#estimate_date_err').text('Estimate date is required.');
                        err++;
                }else{
                    $('#estimate_date_err').text('');
                }
        
            var prposal_due_date = $('#prposal_due_date').val();
            if (prposal_due_date === "") {
                    $('#prposal_due_date_err').text('proposal Due date is required.');
                    err++;
            }else{
                $('#prposal_due_date_err').text('');
            }
            
            if (estimate_date !== "" && prposal_due_date !== "") {
                // Convert to Date objects
                var estDate = new Date(estimate_date);
                var propDate = new Date(prposal_due_date);
                // console.log(estimated_date)
                // console.log(prposal_due_date)
                if (estDate > propDate) {
                    $('#prposal_due_date_err').text('proposal Due date Must be Greater or Equal to Estimate date.');
                    err++;
                }else{
                     $('#prposal_due_date_err').text('');
                }
            }
           
            
            

            var delivery_duration = $('#delivery_duration').val();
            if (delivery_duration === "") {
                    $('#delivery_duration_err').text('proposal Delivery Duration is required.');
                    err++;
            }else{
                $('#delivery_duration_err').text('');
            }
            
            var delivery_duration_end = $('#delivery_duration_end').val();
            if (delivery_duration_end === "") {
                    $('#delivery_duration_end_err').text('Delivery Duration is required.');
                    err++;
            }else{
                $('#delivery_duration_end').text('');
            }

            var prposal_currency = $('#prposal_currency').val();
            if (prposal_currency === "") {
                    $('#prposal_currency_err').text('Currency Format is required.');
                    err++;
            }else{
                $('#prposal_currency_err').text('');
            }
            
            var proposal_cre = $('#proposal_cre').val();
            if (proposal_cre === "") {
                    $('#proposal_cre_err').text('Cre is required.');
                    err++;
            }else{
                $('#proposal_cre_err').text('');
            }
            
            var milestone_count = $('#milestone_count').val();
            if (milestone_count === "") {
                    $('#milestone_count_err').text('Milestone Count is required.');
                    err++;
            }else{
                $('#milestone_count_err').text('');
            }

            if (err == 0) {
                $('#proposal_lead_name').text(lead_name);
                $('#proposal_auto_id').text(proposal_id);
                $('#submit_popup').click();
            }
        
       
    }
   
    function ChangeProduct(el) {
        var id = $(el).attr('id').split('_').pop();
        populateDeliverablesDropdowns(0, `#slot_deliverables_${id}`);
         populateNotesDropdowns(0, `#slot_notes_${id}`);
    }
    
     function create_proposal_send_func(proposal_id,lead_name,lead_id){
        var err=0;
            $('#send_communication').val(1);
         var service_title = $('#service_title').val();
            if (service_title === "") {
                    $('#service_title_err').text('Service Title is required.');
                    err++;
            }else{
                $('#service_title_err').text('');
            }
            
             var estimate_date = $('#estimate_date').val();
                if (estimate_date === "") {
                        $('#estimate_date_err').text('Estimate date is required.');
                        err++;
                }else{
                    $('#estimate_date_err').text('');
                }
        
            var prposal_due_date = $('#prposal_due_date').val();
            if (prposal_due_date === "") {
                    $('#prposal_due_date_err').text('proposal Due date is required.');
                    err++;
            }else{
                $('#prposal_due_date_err').text('');
            }
            
            if (estimate_date !== "" && prposal_due_date !== "") {
                // Convert to Date objects
                var estDate = new Date(estimate_date);
                var propDate = new Date(prposal_due_date);
                // console.log(estimated_date)
                // console.log(prposal_due_date)
                if (estDate > propDate) {
                    $('#prposal_due_date_err').text('proposal Due date Must be Greater or Equal to Estimate date.');
                    err++;
                }else{
                     $('#prposal_due_date_err').text('');
                }
            }
           
            
            

            var delivery_duration = $('#delivery_duration').val();
            if (delivery_duration === "") {
                    $('#delivery_duration_err').text('proposal Delivery Duration is required.');
                    err++;
            }else{
                $('#delivery_duration_err').text('');
            }
            
            var delivery_duration_end = $('#delivery_duration_end').val();
            if (delivery_duration_end === "") {
                    $('#delivery_duration_end_err').text('Delivery Duration is required.');
                    err++;
            }else{
                $('#delivery_duration_end').text('');
            }

            var prposal_currency = $('#prposal_currency').val();
            if (prposal_currency === "") {
                    $('#prposal_currency_err').text('Currency Format is required.');
                    err++;
            }else{
                $('#prposal_currency_err').text('');
            }
            
             var proposal_cre = $('#proposal_cre').val();
            if (proposal_cre === "") {
                    $('#proposal_cre_err').text('Cre is required.');
                    err++;
            }else{
                $('#proposal_cre_err').text('');
            }
            
            var milestone_count = $('#milestone_count').val();
            if (milestone_count === "") {
                    $('#milestone_count_err').text('Milestone Count is required.');
                    err++;
            }else{
                $('#milestone_count_err').text('');
            }

            if (err == 0) {
                $('#proposal_lead_name').text(lead_name);
                $('#proposal_auto_id').text(proposal_id);
                $('#submit_popup').click();
            }
        
       
    }
    function confirm_create_proposal(){
        let $addBtn = $('#proposal_create_button');
        $addBtn.prop('disabled', true);
        var err=0;
        if(err==0){
            $addBtn.prop('disabled', true);
            $('#addProposalForm').submit();
        }else{
             $addBtn.prop('disabled', false); 
        }
    }

    var packgVal = "{{ isset($packageSlot) ? 'package' : 'product' }}";
    service_add_func(packgVal)
    function service_add_func(val) {
        var serv_product_chk_tbox = document.getElementById("serv_product_chk_tbox");
        var serv_package_chk_tbox = document.getElementById("serv_package_chk_tbox");
        var prod_pymt_slot = document.getElementById("prod_pymt_slot");
        var pckg_pymt_slot = document.getElementById("pckg_pymt_slot");

        if (val == 'package') {
            serv_product_chk_tbox.style.display = "none";
            serv_package_chk_tbox.style.display = "block";
            prod_pymt_slot.style.display = "none";
            pckg_pymt_slot.style.display = "none";
            $('#over_all_total_amount').val(0)
            $('#addon_total_amount_value').val(0)
             calculateOverTotal()
        } else {
            serv_product_chk_tbox.style.display = "block";
            serv_package_chk_tbox.style.display = "none";
            prod_pymt_slot.style.display = "block";
            pckg_pymt_slot.style.display = "none";
        }
    }
</script>
<script>
    function productAmountValidate(val,id) {
        let total_amount = parseFloat($('#product_amount_edit_'+id).val()) || 0;
        let min_amount = parseFloat($('#product_min_amount_'+id).val()) || 0;
    
        let $errorEl = $('#product_amount_edit_err_'+id);
        let $addBtn = $('#add_product_button_' + id);
    
        if (total_amount < min_amount) {
            $errorEl.text('Total Amount Must Be Greater Than Minimum Amount of ' + min_amount);
            $addBtn.prop('disabled', true); // Disable Add Product button
        } else {
            $errorEl.text('');
            $addBtn.prop('disabled', false); // Enable Add Product button
        }
    }

</script>
<script>
page_change_count_func();
function page_change_count_func() {
    let val = $('input[name="page_word"]:checked').val();  // Get selected value

    if (val == 1) {
        $('#page_count_label').text('Page Count');
    } else {
        $('#page_count_label').text('Word Count');
    }
}

$(document).on('input', '.cust_product_amount', function() {
    var value = $(this).val();
    

    // Remove all except digits and max one decimal point
    let sanitized = value.replace(/[^0-9.]/g, '');
    let parts = sanitized.split('.');
    if(parts.length > 2) sanitized = parts[0] + '.' + parts.slice(1).join('');
    $(this).val(sanitized);
});

$(document).on('keyup', '.cust_product_amount', function() {
    var $input = $(this);
    var value = parseFloat($input.val());
     var minValue = parseFloat($input.data('min-value'));
    var $error = $('.cust_product_amount_error');
    var $cartInput = $input.closest('.d-flex').find('.cart_product_amount');
        $error.text("");
    console.log('minValue =',minValue ," value",value ," Ans=",value < minValue)
    if (isNaN(value) || value <= 0 || value < minValue) {
        console.log('minValue true')
        $error.text("Please Enter Product Amount greater than or equal to " + minValue + ".");
        $('#add_payment_slot_pckg').prop('disabled', true);
    } else {
        $error.text("");
         $('#add_payment_slot_pckg').prop('disabled', false);
    }

    updatePackageTotal();
});


function updatePackageTotal() {
    let total = 0;
    $('.cust_product_amount').each(function() {
        var val = parseFloat($(this).val());
        var error = $('.cust_product_amount_error').is(':visible');
        if (!isNaN(val) && val > 0 ) {
            total += val;
        }
    });
    console.log("cusdt",total)
    $('#package_actual_price_hidden').val(total);
    $('#package_actual_price').text(total.toFixed(2)); // Or use your formatCurrency function
    $('#over_all_total_amount').val(total);
    calculateOverTotal();
}

     var packageData = @json($packageData);
$(document).ready(function() {
    
      
     
    
    $('#package_id').on('change', function() {
            $('#pckg_pymt_slot').hide()
            $('#package_duration').text('0 Days');
            $('#package_amount').text(0);
            $('#package_product_count').text(0);
            $('#package_paid_addon').text(0);
            $('#package_free_addon').text(0);
            $('#package_pay_slot_product_count').text(0);
             $('#package_pay_slot_name').text('-').attr('title', '-'); 
            $('#viewInfoFree').html('');
            $('#viewInfoPaid').html('');
            $('#package_pay_slot_list').html('');
            $('#over_all_total_amount').val(0)
            $('#package_actual_price_hidden').val(0);
            $('#package_actual_price').html('');
            calculateOverTotal()
        var package_id=$(this).val()
        var package_name = $("#package_id option:selected").text();
        var proposal_id_hid=$('#proposal_hidden_id').val();
        
        let selectedCurrencyId = $("#prposal_currency").val();
        let selectedCurrencySymbol = $("#prposal_currency option:selected").data('code'); // optional: fetch via AJAX
        let CurrencySymbol = $("#prposal_currency option:selected").data('symbol');
        
        $.ajax({
            url: "{{ route('package_data_by_id') }}",
            type: "GET",
            data:{id:package_id,proposal_id:proposal_id_hid,currency_id:selectedCurrencyId},
            success: function(response) {
                if (response.status === 200 && response.data) {
                    $('#pckg_pymt_slot').show()
                     $('#package_duration').text( response.data.actual_duration);
                     $('#package_amount').text( formatCurrency(response.data.actual_amount));   
                     
                     var product_count = response.data.package_product.length > 0 ? response.data.package_product.length : 0;
                     var free_addon_count = response.data.package_free_addon.length > 0 ? response.data.package_free_addon.length : 0;
                     var paid_addon_count = response.data.package_paid_addon.length > 0 ? response.data.package_paid_addon.length : 0;
                      $('#package_product_count').text( product_count);
                      $('#package_paid_addon').text( paid_addon_count);
                      $('#package_free_addon').text( free_addon_count);
                      $('#viewInfoFree').html('');
                      $('#viewInfoPaid').html('');
                      $('#package_pay_slot_list').html('');
                     $('#over_all_total_amount').val(response.data.actual_amount)
                     $('#package_actual_price_hidden').val(response.data.actual_amount)
                     $('#package_actual_price').text(formatCurrency(response.data.actual_amount))
                     calculateOverTotal()

                      var packageSlot='';
                      var packg_slot_id = "{{ isset($packageSlot) ? $packageSlot->package_id : '0' }}";
                      var packgVal = packg_slot_id == package_id ? '1':'0';

                        
                        packageSlot=  `
                                <div class="col-lg-6 mb-3">
                                    <div class="card rounded pckg_pymt_bg " style="background-color:${packgVal ==1 ? '#7fffd494':''}">
                                        <div class="card-body px-3 pt-3 pb-2">
                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 rounded px-1 py-1">
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2 cursor-pointer">
                                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Packages">
                                                            <i class="mdi mdi-package-variant fs-4"></i>
                                                        </a>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Complete Thesis Writing" id="package_pay_slot_name">${package_name}</div>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8 fw-semibold">Products &nbsp;- &nbsp; <span class="badge bg-warning fs-8 fw-semibold text-black" id="package_pay_slot_product_count">${product_count || 0}</span></label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-0">
                                                 ${packgVal == 1 ? 
                                                   `<button type="button" class="btn btn-sm btn-primary rounded-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment_slot_package" disabled id="" onclick="updatePaymentSlot_packg('${package_name}','${product_count}','${package_id}')">Milestone Updated</button> `
                                                 :
                                                    `<button type="button" class="btn btn-sm btn-primary rounded-3 fw-semibold" id="add_payment_slot_pckg"  onclick="add_paymentSlot_packg('${package_name}','${product_count}','${package_id}')">Add Milestone</button>`
                                                 }
                                                    
                                                    
                                                </div>
                                                <input type="hidden" name="slot_popup_packg" id="slot_popup_packg" data-bs-toggle="modal" data-bs-target="#kt_modal_add_payment_slot_package">
                                                <input type="hidden" class="slot_updated" value="${packgVal == 1 ?  '1':'0'}" />
                                            </div>
                                            <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
                                                <div class="cursor-pointer border border-dashed border-gray-600i rounded px-2 py-1" id="aft_pymt_pckg_slt" style="display: none !important;">
                                                    <a href="javascript:;" class="mb-0">
                                                        <i class="mdi mdi-cash-clock fs-3 text-dark"></i>
                                                    </a>
                                                    <label class="ms-1 text-black fs-6 fw-semibold">Total Milestone</label>
                                                    <label class="ms-2 text-black fs-6 fw-semibold">-</label>
                                                    <label class="badge bg-secondary ms-2 text-white fs-7 fw-semibold">01</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                `;
                        $('#package_pay_slot_list').append(packageSlot);
                        var currency_id =$('#prposal_currency').val() == '' ? '70' :$('#prposal_currency').val() ;
                        coupon_code_func()
                         if(packgVal == 1){
                              
                              $('#prposal_currency').prop('disabled', true);
                              $('#prposal_currency_hidden').val(currency_id);
                          }else{
                              $('#prposal_currency').prop('disabled', false);
                          }

                      if(free_addon_count > 0){
                        response.data.package_free_addon.forEach(function(free_addon, index){
                            var html=  ` 
                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                    <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                    <div class="d-block">
                                        <div class="text-black fw-semibold text-justify fs-7">${free_addon.addon_name}</div>
                                        <div class="text-info fw-semibold fs-8">${free_addon.addon_variablename}</div>
                                    </div>
                                </div>
                                `;
                         $('#viewInfoFree').append(html);
                        })          
                      }
                         
                    if(paid_addon_count > 0){
                        response.data.package_paid_addon.forEach(function(paid, index){
                            var html=  ` 
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#128261;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">${paid.addon_name}</div>
                                            <div class="fw-semibold">
                                                <span class="text-danger fs-8">${paid.addon_variablename}</span>
                                                <span class="text-dark fs-7">( <span class="currency_symb"></span> ${formatCurrency(paid.amount)} )</span>
                                            </div>
                                        </div>
                                    </div>
                                `;
                        $('#viewInfoPaid').append(html);
                        })          
                    }

                    var record = response.html;
                   $('#selected_pckage_list_div').empty().html(record);
                   $('#package_product_div').empty().html( response.productHtml);
                   
                   if (packageData && packageData.length > 0) {
                        $('.cust_product_amount').each(function() {
                            var productId = $(this).data('product-id');
                            var productPackage = packageData.find(pd => pd.product_id == productId);
                            if (productPackage) {
                                $(this).val(productPackage.cust_product_amount); // Set cust_product_amount from packageData
                                // Optionally set original_product_amount in hidden input if needed
                                $(this).closest('.d-flex').find('.cart_product_amount').val(productPackage.original_product_amount);
                            }
                        });
                
                        // Set total package amount globally
                        var total_package_amount = packageData.length > 0 ? packageData[0].total_package_amount : 0;
                        $('#over_all_total_amount').val(total_package_amount);
                        $('#package_actual_price_hidden').val(total_package_amount);
                        $('#package_actual_price').text(formatCurrency(total_package_amount));
                        calculateOverTotal();
                    }
                    
                    
                    let allSlotsUpdated = false;
                    $('.slot_updated').each(function() {
                        allSlotsUpdated = true
                         
                        if ($(this).val() !== '1') {
                            allSlotsUpdated = false;
                            return false; // break loop early
                        }
                    });
               
                    if (allSlotsUpdated) {
                        $('#verify_proposal').prop('disabled', false);
                        $('#send_proposal').prop('disabled', false);
                    } else {
                        $('#verify_proposal').prop('disabled', true);
                        $('#send_proposal').prop('disabled', true);
                    }
                     currency_change()  
                }
            },
            error: function(error) {
                console.error('Error fetching Package Data:', error);
                 $('#pckg_pymt_slot').hide()
            }
        });
    });
      
        
});
</script>

<script>
    var cugAssignCounterPackg = 1;
    var PckgpaymentSlotListCache = [];
    var PckgdeliverablesListCache = [];
    var PckgnotesListCache = [];
    $.ajax({
        url: "/payment_slot_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgpaymentSlotListCache = response.data; // Store it for reuse
                populateSlotDropdownsPckg(0, `#payment_slot_id_packg_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });
   function populateSlotDropdownsPckg(val, targetDropdown) {
        var selectedValues = $('.payment_slot_id_packg').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Payment Milestone</option>');

        PckgpaymentSlotListCache.forEach(function (slot) {
            if (!selectedValues.includes(slot.sno.toString()) || slot.sno.toString() === currentValue) {
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.payment_slot_name));
            }
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }

    $.ajax({
        url: "/deliverable_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgdeliverablesListCache = response.data; 
                    populateDeliverablesDropdownsPckg(0, `#slot_deliverables_packg_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateDeliverablesDropdownsPckg(val, targetDropdown) {
        var selectedValues = $('.slot_deliverables_packg').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Deliverables</option>');

        PckgdeliverablesListCache.forEach(function (slot) {
            
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.delivarable_name));
          
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }


     $.ajax({
        url: "/slot_notes_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgnotesListCache = response.data; // Store it for reuse
                 
                    populateNotesDropdownsPckg(0, `#slot_notes_packg_1`);
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateNotesDropdownsPckg(val, targetDropdown) {
        var selectedValues = $('.slot_notes_packg').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Milestone Notes</option>');

        PckgnotesListCache.forEach(function (slot) {
           
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.slot_notes_name));
        
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }


    
</script>

<script>
    $(document).ready(function() {

        $('.pymt_slot_create_add_packg').on('click', function() {
            // Increment the counter
            // Create the new requirement row dynamically
            cugAssignCounterPackg++;
            var newRequirementHtml = `
                    <div data-repeater-list="group-a_led_question" id="assign_row_packg_${cugAssignCounterPackg}">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                            <select class="select3 form-select payment_slot_id_packg" name="payment_slot_id_packg_${cugAssignCounterPackg}" id="payment_slot_id_packg_${cugAssignCounterPackg}">
                                                <option value="">Select Payment Slot</option>
                                            </select>
                                            <div class="text-danger err_mssg fs-7 payment_slot_id_packg_err" id="payment_slot_id_packg_err_${cugAssignCounterPackg}" ></div>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control payment_slot_amount_packg" placeholder="Enter Milestone Amount " name="payment_slot_amount_packg_${cugAssignCounterPackg}" id="payment_slot_amount_packg_${cugAssignCounterPackg}" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" onkeyup="calculationSplitPackg(this.value,${cugAssignCounterPackg})" />
                                          <div class="text-danger err_mssg fs-7 payment_slot_amount_packg_err" id="payment_slot_amount_packg_err_${cugAssignCounterPackg}" ></div>
                                        </div>
                                        <div class="col-lg-8 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold d-block">Select Type<span
                                                    class="text-danger">*</span></label>
                                            <div class="d-flex ">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver_packg" type="radio" name="to_start_deliver_packg_${cugAssignCounterPackg}" id="to_start_deliver_radio_packg1" value="1" checked />
                                                    <label class="form-check-label" for="inlineRadio1">To Start The Work</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input to_start_deliver_packg" type="radio" name="to_start_deliver_packg_${cugAssignCounterPackg}" id="to_start_deliver_radio_packg2" value="2" />
                                                    <label class="form-check-label" for="inlineRadio2">To Deliver The Work</label>
                                                </div>
                                            </div>
                                            <div class="text-danger" id="to_start_deliver_packg_err_${cugAssignCounterPackg}"></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_deliverables_packg" multiple data-placeholder="Select Deliverables" name="slot_deliverables_packg_${cugAssignCounterPackg}[]" id="slot_deliverables_packg_${cugAssignCounterPackg}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_deliverables_packg_err" id="slot_deliverables_packg_err_${cugAssignCounterPackg}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_notes_packg" multiple data-placeholder="Select Milestone Notes" name="slot_notes_packg_${cugAssignCounterPackg}[]" id="slot_notes_packg_${cugAssignCounterPackg}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_notes_packg_err" id="slot_notes_packg_err_${cugAssignCounterPackg}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1" placeholder="Enter Deliverables" name="slot_description_packg_${cugAssignCounterPackg}" id="slot_description_packg_${cugAssignCounterPackg}"></textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_create_del_packg" id="pymt_slot_create_del_packg_${cugAssignCounterPackg}" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
            `;
            // Append the new requirement row
            $('#repeater_req_packg').first().parent().append(newRequirementHtml);

    
            populateSlotDropdownsPckg(0, `#payment_slot_id_packg_${cugAssignCounterPackg}`);
            populateDeliverablesDropdownsPckg(0, `#slot_deliverables_packg_${cugAssignCounterPackg}`);
            populateNotesDropdownsPckg(0, `#slot_notes_packg_${cugAssignCounterPackg}`);

           $(`#payment_slot_id_packg_${cugAssignCounterPackg}`).select2({
                dropdownParent: $(`#payment_slot_id_packg_${cugAssignCounterPackg}`).closest('.col-lg-6'),
                width: '100%',
            });

            $(`#slot_deliverables_packg_${cugAssignCounterPackg}`).select2({
                dropdownParent: $(`#slot_deliverables_packg_${cugAssignCounterPackg}`).closest('.col-lg-12'),
                width: '100%',
            });

            $(`#slot_notes_packg_${cugAssignCounterPackg}`).select2({
                dropdownParent: $(`#slot_notes_packg_${cugAssignCounterPackg}`).closest('.col-lg-12'),
                width: '100%',
            });
            
             const currencySelect = document.getElementById('prposal_currency');
             const selectedOption = currencySelect.options[currencySelect.selectedIndex];
             let selectedCurrencyCode = selectedOption.getAttribute('data-code');
             
            

            
            // Show the delete button for the new row
            $('#pymt_slot_create_del_packg_' + cugAssignCounterPackg).show();
            
            var milestone_count = $('#milestone_count').val();
             if(milestone_count <= cugAssignCounterPackg){
                $('#pymt_slot_create_add_packg').prop('disabled', true);
            }else{
                 $('#pymt_slot_create_add_packg').prop('disabled', false);
            }
            
            if (milestone_count <= cugAssignCounterPackg) {
                $('#addPaymentSlotBtnPackg').prop('disabled', false);
            }else {
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            }

            // Hide delete button for the first requirement
        
        });

        // Delete a requirement row
        $(document).on('click', '.pymt_slot_create_del_packg', function(e) {
            var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
            var index = deleteId.split('_')[5];  
            // Remove the row
            $('#assign_row_packg_' + index).slideUp(400, function() {
                $(this).remove(); // Remove the row
                calculationSplit(0,index)
                cugAssignCounterPackg--; // Decrement counter
                // Hide the delete button for the first row if there is only one remaining row
                if (cugAssignCounterPackg === 1) {
                    $('#pymt_slot_create_del_packg_1').hide();
                }
                if(milestone_count <= cugAssignCounterPackg){
                    $('#pymt_slot_create_add_packg').prop('disabled', true);
                }else{
                     $('#pymt_slot_create_add_packg').prop('disabled', false);
                }
                
                if (milestone_count <= cugAssignCounterPackg) {
                    $('#addPaymentSlotBtnPackg').prop('disabled', false);
                }else {
                    $('#addPaymentSlotBtnPackg').prop('disabled', true);
                }
            });
        });

        $('#addPaymentSlotBtnPackg').on('click', function () {
            var valid = true;
            // Validate Payment Slot ID
            $('.payment_slot_id_packg').each(function () {
                let slot_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_id_packg_err');

                if (!slot_id_add) {
                    valid = false;
                    errDiv.text('Payment Milestone is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Amount
            $('.payment_slot_amount_packg:visible:enabled').each(function () {
                let slot_amount_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_amount_packg_err');

                if (!slot_amount_add || isNaN(slot_amount_add) || parseFloat(slot_amount_add) <= 0) {
                    valid = false;
                    errDiv.text('Valid Milestone Amount is required');
                } else {
                    errDiv.text('');
                }
            });
            
           
             const currencySelect = document.getElementById('prposal_currency');
             const selectedOption = currencySelect.options[currencySelect.selectedIndex];
             let selectedCurrencyCode = selectedOption.getAttribute('data-code');
            
             

            // Validate Deliverables (multi-select)
            $('.slot_deliverables_packg:visible:enabled').each(function () {
                let deliverable_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_deliverables_packg_err');

                if (!deliverable_id_add || deliverable_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Deliverable is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Notes (multi-select)
            $('.slot_notes_packg:visible:enabled').each(function () {
                let notes_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_notes_packg_err');

                if (!notes_id_add || notes_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Note is required');
                } else {
                    errDiv.text('');
                }
            });
            
            let totalAmount = parseFloat($('#payment_slot_total_amt_packg').val()) || 0;

            // Initialize sum of all entered slot amounts
            let sumOfAllSlots = 0;

            // Loop through all slot amount inputs
            $('.payment_slot_amount_packg').each(function () {
                let amount = parseFloat($(this).val()) || 0;
                sumOfAllSlots += amount;
            });
                console.log(sumOfAllSlots >= totalAmount)
                
            // Validate the current field individually
              if (sumOfAllSlots >= totalAmount) {
                 $('#payment_slot_total_amt_err_packg').text('');
              }else{
                 valid = false;
                 $('#payment_slot_total_amt_err_packg').text('Milestone Split Amount Balance Must be Zero');
                  
              }

            // Submit form if valid
            if (valid) {
                saveAccountDetailsPackg()
                $('#addPaymentSlotformPackg').submit();
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            } else {
                $('#addPaymentSlotBtnPackg').prop('disabled', false);
            }
        });


    });
</script>
<script>
    function add_paymentSlot_packg(name,count,id){
        var err=0;
         var milestone_count = $('#milestone_count').val();
         var currency_id = $('#prposal_currency').val();
         
         const currencySelect = document.getElementById('prposal_currency');
         const selectedOption = currencySelect.options[currencySelect.selectedIndex];
         let selectedCurrencyCode = selectedOption.getAttribute('data-code');
         
         
        
      
            if (currency_id === "" || currency_id < 1) {
                   Swal.fire({
                    title: "Set Currency Format",
                    text: 'Select Currency Format',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                    err++;
            }
            if (milestone_count === "" || milestone_count < 1) {
                   Swal.fire({
                    title: "Set Milestone Count",
                    text: 'Milestone Count Must Be Greater than 0',
                    icon: 'warning',
                    customClass: {
                        confirmButton: 'btn btn-primary waves-effect waves-light'
                    },
                    buttonsStyling: false
                });
                    err++;
            }
            
           
            
            if(err==0){
                $('#curency_format_package').val(currency_id);
                 $('#slot_popup_packg').click();
            }
            
            
           
            
            if(milestone_count == 1){
                $('#pymt_slot_create_add_packg').prop('disabled', true);
            }else if(milestone_count == cugAssignCounterPackg){
                 $('#pymt_slot_create_add_packg').prop('disabled', true);
            }else{
                 $('#pymt_slot_create_add_packg').prop('disabled', false);
            }
            
            if (milestone_count == 1) {
                $('#addPaymentSlotBtnPackg').prop('disabled', false);
            }else if(milestone_count == cugAssignCounterPackg){
                $('#addPaymentSlotBtnPackg').prop('disabled', false);
            } else {
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            }
            
            
        $('#pay_slot_package_name').text(name)
        $('#pay_slot_package_pro_count').text(count)
        $('#payment_slot_product_id_packg').val(id)
        //   calculateOverTotal()
            //  $('.split_balance_label_packg').text(formatCurrency(balanceAmount));
            //  $('#slot_balance_amt_packg').val(balanceAmount);
            //  $('#payment_slot_total_amt_packg').val(slot_amount);
    }
    function AdditionalChargeChange(){
         calculateOverTotal()
    }

     function calculationSplitPackg(val, indx) {
            // Sanitize current value
            let currentVal = parseFloat(val) || 0;
            

            // Get total payment amount
            let totalAmount = parseFloat($('#payment_slot_total_amt_packg').val()) || 0;

            // Initialize sum of all entered slot amounts
            let sumOfAllSlots = 0;

            // Loop through all slot amount inputs
            $('.payment_slot_amount_packg').each(function () {
                let amount = parseFloat($(this).val()) || 0;
                sumOfAllSlots += amount;
            });
            
            var milestone_count = $('#milestone_count').val();
            // Validate the current field individually
            if (sumOfAllSlots > totalAmount) {
                $(`#payment_slot_amount_packg_err_${indx}`).text('Slot Amount must be less than or equal to Total Amount.');
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            }else if(milestone_count != cugAssignCounterPackg){
                $(`#payment_slot_amount_packg_err_${indx}`).text('');
                $('#addPaymentSlotBtnPackg').prop('disabled', true);
            }else {
                $(`#payment_slot_amount_packg_err_${indx}`).text('');
                $('#addPaymentSlotBtnPackg').prop('disabled', false);
            }
            
            // if (milestone_count == 1) {
            //     $('#addPaymentSlotBtnPackg').prop('disabled', false);
            // }else if(milestone_count == cugAssignCounterPackg){
            //     $('#addPaymentSlotBtnPackg').prop('disabled', false);
            // } else {
            //     $('#addPaymentSlotBtnPackg').prop('disabled', true);
            // }

            // Calculate remaining balance
            let balanceAmount = totalAmount - sumOfAllSlots;
            balanceAmount = balanceAmount < 0 ? 0 : balanceAmount;

           
            // Update the label and hidden balance input
            $('.split_balance_label').text(formatCurrency(balanceAmount));
            $('.split_balance_label_packg').text(formatCurrency(balanceAmount));
            $('#slot_balance_amt_packg').val(balanceAmount);
            if(balanceAmount == 0){
                $('#pymt_slot_create_add_packg').prop('disabled', true);
            }else if(milestone_count <= cugAssignCounterPackg){
                 $('#pymt_slot_create_add_packg').prop('disabled', true);
            }else{
                 $('#pymt_slot_create_add_packg').prop('disabled', false);
            }
            
             
        }




function saveAccountDetailsToSession () {
    const accountData = {
        sub_total: document.getElementById("sub_total").innerText,
        product_total_amount: document.getElementById("over_all_total_amount").value,
        sub_total_amount: document.getElementById("sub_total_amount").value,
        discounted_amount_hidden: document.getElementById("discounted_amount_hidden").value,
        discount_id_hidden: document.getElementById("discount_id_hidden").value,
        proposal_total_amount: document.getElementById("proposal_total_amount").value,
        gst_amount_hidden: document.getElementById("gst_amount_hidden").value,
        gst_perc_hidden: document.getElementById("gst_perc_hidden").value,
        additional_charge_perc: document.getElementById("additional_charge_perc").value,
        additional_charge_amount: document.getElementById("additional_charge_amount").value,
        grant_total_amount: document.getElementById("grant_total_amount").value,
        new_coupon_code: document.getElementById("new_coupon_code").value,
        proposal_id: document.getElementById("proposal_hidden_id").value,
        additional_charges_ids: $('#addtional_charges_id').val(),
        slot_balance: $('#slot_balance_amt').val(),
        service_title: $('#service_title').val(),
        estimate_date: $('#estimate_date').val(),
        prposal_due_date: $('#prposal_due_date').val(),
        delivery_duration: $('#delivery_duration').val(),
        delivery_duration_end: $('#delivery_duration_end').val(),
        prposal_currency: $('#prposal_currency').val(),
        proposal_topic: $('#proposal_topic').val(),
        old_customer_check: $('#old_customer_check').val(),
        proposal_domain: $('#proposal_domain').val(),
        proposal_cre: $('#proposal_cre').val(),
        proposal_referral_staff: $('#proposal_referral_staff').val(),
        milestone_count: $('#milestone_count').val(),
         page_word_count: $('#page_word_count').val(),
        page_word: $('#page_word').val(),
        add_ons: []
    };

    $('.add_on_product:checked').each(function () {
        const addOnId = $(this).val();
        const selectedVarient = $(`input[name="addOn_varient_${addOnId}"]:checked`).val();
        const amount = $(`input[name="addon_amount_${selectedVarient}"]`).val();

        accountData.add_ons.push({
            add_on_id: addOnId,
            varient_id: selectedVarient,
            amount: amount
        });
    });

    $.ajax({
        url: '/update_preProposal',
        type: 'POST',
        data: accountData,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            console.log("Session saved successfully:", response);
        },
        error: function (xhr) {
            console.error("Error storing session data:", xhr.responseText);
            $('#addPaymentSlotBtn').prop('disabled', false); // re-enable button if error
        }
    });
}

function saveAccountDetailsPackg () {
    const accountData = {
        sub_total: document.getElementById("sub_total").innerText,
        product_total_amount: document.getElementById("over_all_total_amount").value,
        sub_total_amount: document.getElementById("sub_total_amount").value,
        discounted_amount_hidden: document.getElementById("discounted_amount_hidden").value,
        discount_id_hidden: document.getElementById("discount_id_hidden").value,
        proposal_total_amount: document.getElementById("proposal_total_amount").value,
        gst_amount_hidden: document.getElementById("gst_amount_hidden").value,
        gst_perc_hidden: document.getElementById("gst_perc_hidden").value,
        additional_charge_perc: document.getElementById("additional_charge_perc").value,
        additional_charge_amount: document.getElementById("additional_charge_amount").value,
        grant_total_amount: document.getElementById("grant_total_amount").value,
        new_coupon_code: document.getElementById("new_coupon_code").value,
        proposal_id: document.getElementById("proposal_hidden_id").value,
        additional_charges_ids: $('#addtional_charges_id').val(),
        slot_balance: $('#slot_balance_amt_packg').val(),
        service_title: $('#service_title').val(),
        estimate_date: $('#estimate_date').val(),
        prposal_due_date: $('#prposal_due_date').val(),
        delivery_duration: $('#delivery_duration').val(),
        delivery_duration_end: $('#delivery_duration_end').val(),
        prposal_currency: $('#prposal_currency').val(),
        proposal_topic: $('#proposal_topic').val(),
        old_customer_check: $('#old_customer_check').val(),
        proposal_domain: $('#proposal_domain').val(),
        proposal_cre: $('#proposal_cre').val(),
        proposal_referral_staff: $('#proposal_referral_staff').val(),
        milestone_count: $('#milestone_count').val(),
        page_word_count: $('#page_word_count').val(),
        page_word: $('#page_word').val(),
        package_id: $('#payment_slot_product_id_packg').val(),
        add_ons: []
    };

    $('.add_on_product:checked').each(function () {
        const addOnId = $(this).val();
        const selectedVarient = $(`input[name="addOn_varient_${addOnId}"]:checked`).val();
        const amount = $(`input[name="addon_amount_${selectedVarient}"]`).val();

        accountData.add_ons.push({
            add_on_id: addOnId,
            varient_id: selectedVarient,
            amount: amount
        });
    });
    
    accountData.cust_product_amounts = {};
    accountData.original_product_amounts = {};
    
    $('.cust_product_amount').each(function(){
        var productId = $(this).attr('data-product-id'); // Add data-product-id to each input
        accountData.cust_product_amounts[productId] = $(this).val();
        // original value from hidden field
        accountData.original_product_amounts[productId] = $(this).closest('.d-flex').find('.cart_product_amount').val();
    });
    accountData.package_actual_price_hidden = $('#package_actual_price_hidden').val();

    $.ajax({
        url: '/update_preProposal',
        type: 'POST',
        data: accountData,
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function (response) {
            console.log("Session saved successfully:", response);
        },
        error: function (xhr) {
            console.error("Error storing session data:", xhr.responseText);
            $('#addPaymentSlotBtn').prop('disabled', false); // re-enable button if error
        }
    });
}



</script>






<script>
     function updatePaymentSlot_packg(name,count,id){
       
        $('#pay_slot_package_name_edit').text(name)
        $('#pay_slot_package_pro_count_edit').text(count)
        $('#payment_slot_product_id_packg_edit').val(id)
       $('#package_addmore').html('');
          let editPackageCounter = 1;
          let addIndexPackageEdit = 1;

        var proposal_id =$('#proposal_hidden_id').val();

            $.ajax({
                url: "/payment_slot_by_proposal",
                type: "GET",
                data:{id:proposal_id},
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        if (response.data.length > 0) {
                                response.data.forEach(function(slot, index) {
                                    let currentIndex = index + 1;

                                
                        

                                    var editPackageSlotHtml = `
                                            <div class="row mt-2" id="assign_row_packg_edit_${editPackageCounter}">
                                                <div class="col-lg-11">
                                                    <div class="row">
                                                        <div class="col-lg-6 mb-1">
                                                             <input type="hidden" name="update_ids[]" value="${slot.sno}" />
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                                            <select class="select3 form-select payment_slot_id_packg_edit" name="payment_slot_id_packg_update_${slot.sno}" id="payment_slot_id_packg_edit_${editPackageCounter}">
                                                                <option value="">Select Payment Milestone</option>
                                                            </select>
                                                            <div class="text-danger err_mssg fs-7 payment_slot_id_packg_edit_err" id="payment_slot_id_packg_edit_err_${editPackageCounter}" ></div>
                                                        </div>
                                                        <div class="col-lg-6 mb-1">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control" placeholder="Enter Milestone Amount" value="${slot.slot_amount}" name="payment_slot_amount_packg_update_${slot.sno}" id="payment_slot_amount_packg_edit_${editPackageCounter}" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" onkeyup="calculationSplitPackg(this.value,${editPackageCounter})"/>
                                                            <div class="text-danger err_mssg fs-7 payment_slot_amount_packg_edit_err" id="payment_slot_amount_packg_edit_err_${editPackageCounter}" ></div>
                                                        </div>
                                                        
                                                        <div class="col-lg-12 mb-1">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                                            <select class="select3 form-select slot_deliverables_packg_edit" multiple data-placeholder="Select Deliverables" name="slot_deliverables_packg_update_${slot.sno}" id="slot_deliverables_packg_edit_${editPackageCounter}">
                                                                
                                                            </select>
                                                            <div class="text-danger err_mssg fs-7 slot_deliverables_packg_edit_err" id="slot_deliverables_packg_edit_err_${editPackageCounter}" ></div>
                                                        </div>
                                                        <div class="col-lg-12 mb-1">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                                            <select class="select3 form-select slot_notes_packg_edit" multiple data-placeholder="Select Milestone Notes" name="slot_notes_packg_update_${slot.sno}" id="slot_notes_packg_edit_${editPackageCounter}">
                                                                
                                                            </select>
                                                            <div class="text-danger err_mssg fs-7 slot_notes_packg_edit_err" id="slot_notes_packg_edit_err_${editPackageCounter}" ></div>
                                                        </div>
                                                        <div class="col-lg-12 mb-1">
                                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                                            <textarea class="form-control" rows="2" placeholder="Enter Deliverables" name="slot_description_packg_update_${slot.sno}" id="slot_description_packg_edit_${editPackageCounter}">${slot.slot_description || ''}</textarea>
                                                        </div>
                                                    </div>
                                                    <div class="divider divider-primary mb-2 mt-3">
                                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-1 mb-1">
                                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_pckg_update_del" id="pymt_slot_pckg_update_del_${editPackageCounter}" style="display: block !important;">
                                                        <i class="mdi mdi-delete fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>`;

                                    $('#pymt_slot_pckg_update_del_1').attr('style', 'display: none !important');

                                    if (index > 0) {
                                        $('#pymt_slot_pckg_update_del_1').attr('style', 'display: none !important');
                                    }

                                    $('#package_addmore').append(editPackageSlotHtml);
                                        populateSlotDropdownsPckgEdit(slot.slot_id, `#payment_slot_id_packg_edit_${editPackageCounter}`);
                                        populateDeliverablesDropdownsPckgEdit(slot.deliverable_ids, `#slot_deliverables_packg_edit_${editPackageCounter}`);
                                        populateNotesDropdownsPckgEdit(slot.slot_notes_ids, `#slot_notes_packg_edit_${editPackageCounter}`);

                                    $(`#payment_slot_id_packg_edit_${editPackageCounter}`).select2({
                                            dropdownParent: $(`#payment_slot_id_packg_edit_${editPackageCounter}`).closest('.col-lg-6'),
                                            width: '100%',
                                        });

                                        $(`#slot_deliverables_packg_edit_${editPackageCounter}`).select2({
                                            dropdownParent: $(`#slot_deliverables_packg_edit_${editPackageCounter}`).closest('.col-lg-12'),
                                            width: '100%',
                                        });

                                        $(`#slot_notes_packg_edit_${editPackageCounter}`).select2({
                                            dropdownParent: $(`#slot_notes_packg_edit_${editPackageCounter}`).closest('.col-lg-12'),
                                            width: '100%',
                                        });
                                    $('#pymt_slot_pckg_update_del_' + editPackageCounter).show();

                                    
                                

                                    if (editPackageCounter === 1) {
                                        $('#pymt_slot_pckg_update_del_1').attr('style', 'display: none !important');
                                    }

                                    editPackageCounter++;
                                });
                            }
                            
                    }
                },
                error: function(error) {
                    // console.error('Error fetching course categories:', error);
                }
            });
       
       $(document).on('click', '.pymt_slot_pckg_update_del', function(e) {
            var deleteId = $(this).attr('id');  // Get the id of the clicked delete button
            var index = deleteId.split('_')[5];  
            // Remove the row
            $('#assign_row_packg_edit_' + index).slideUp(400, function() {
                $(this).remove(); // Remove the row
                calculationSplit(0,index)
                editPackageCounter--; // Decrement counter
                addIndexPackageEdit--;
                // Hide the delete button for the first row if there is only one remaining row
                if (editPackageCounter === 1) {
                    $('#pymt_slot_pckg_update_del_1').hide();
                }
            });
        });

         $('.pymt_slot_pckg_update_add').on('click', function() {
           
         
            var editPackageSlotHtml = `
                            <div class="row mt-2" id="assign_row_packg_edit_${editPackageCounter}">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Milestone<span class="text-danger">*</span></label>
                                            <select class="select3 form-select payment_slot_id_packg_edit" name="payment_slot_id_packg_edit_${addIndexPackageEdit}" id="payment_slot_id_packg_edit_${editPackageCounter}">
                                                <option value="">Select Payment Milestone</option>
                                            </select>
                                            <div class="text-danger err_mssg fs-7 payment_slot_id_packg_edit_err" id="payment_slot_id_packg_edit_err_${editPackageCounter}" ></div>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control payment_slot_amount_packg" placeholder="Enter Milestone Amount " name="payment_slot_amount_packg_edit_${addIndexPackageEdit}" id="payment_slot_amount_packg_edit_${editPackageCounter}" value="0" oninput="this.value = this.value.replace(/[^0-9.]/g, '')" onkeyup="calculationSplitPackg(this.value,${editPackageCounter})" />
                                          <div class="text-danger err_mssg fs-7 payment_slot_amount_packg_edit_err" id="payment_slot_amount_packg_edit_err_${editPackageCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_deliverables_packg_edit" multiple data-placeholder="Select Deliverables" name="slot_deliverables_packg_edit_${addIndexPackageEdit}[]" id="slot_deliverables_packg_edit_${editPackageCounter}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_deliverables_packg_edit_err" id="slot_deliverables_packg_edit_err_${editPackageCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select slot_notes_packg_edit" multiple data-placeholder="Select Milestone Notes" name="slot_notes_packg_edit_${addIndexPackageEdit}[]" id="slot_notes_packg_edit_${editPackageCounter}">
                                               
                                            </select>
                                            <div class="text-danger err_mssg fs-7 slot_notes_packg_edit_err" id="slot_notes_packg_edit_err_${editPackageCounter}" ></div>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1" placeholder="Enter Deliverables" name="slot_description_packg_edit_${addIndexPackageEdit}" id="slot_description_packg_edit_${editPackageCounter}"></textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_pckg_update_del" id="pymt_slot_pckg_update_del_${editPackageCounter}" style="display: none !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                      
                   
            `;
            // Append the new requirement row
            $('#package_addmore').append(editPackageSlotHtml);

    
            populateSlotDropdownsPckgEdit(0, `#payment_slot_id_packg_edit_${editPackageCounter}`);
            populateDeliverablesDropdownsPckgEdit(0, `#slot_deliverables_packg_edit_${editPackageCounter}`);
            populateNotesDropdownsPckgEdit(0, `#slot_notes_packg_edit_${editPackageCounter}`);

           $(`#payment_slot_id_packg_edit_${editPackageCounter}`).select2({
                dropdownParent: $(`#payment_slot_id_packg_edit_${editPackageCounter}`).closest('.col-lg-6'),
                width: '100%',
            });

            $(`#slot_deliverables_packg_edit_${editPackageCounter}`).select2({
                dropdownParent: $(`#slot_deliverables_packg_edit_${editPackageCounter}`).closest('.col-lg-12'),
                width: '100%',
            });

            $(`#slot_notes_packg_edit_${editPackageCounter}`).select2({
                dropdownParent: $(`#slot_notes_packg_edit_${editPackageCounter}`).closest('.col-lg-12'),
                width: '100%',
            });
           
            // Show the delete button for the new row
            $('#pymt_slot_pckg_update_del_' + editPackageCounter).show();
             editPackageCounter++;
            addIndexPackageEdit++;
        
        });

         $('#editPackagePaymentSlotBtn').on('click', function () {
            var valid = true;
            // Validate Payment Slot ID
            $('.payment_slot_id_packg_edit').each(function () {
                let slot_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_id_packg_edit_err');

                if (!slot_id_add) {
                    valid = false;
                    errDiv.text('Payment Milestone is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Amount
            $('.payment_slot_amount_packg_edit:visible:enabled').each(function () {
                let slot_amount_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.payment_slot_amount_packg_edit_err');

                if (!slot_amount_add || isNaN(slot_amount_add) || parseFloat(slot_amount_add) <= 0) {
                    valid = false;
                    errDiv.text('Valid Milestone Amount is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Deliverables (multi-select)
            $('.slot_deliverables_packg_edit:visible:enabled').each(function () {
                let deliverable_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_deliverables_packg_edit_err');

                if (!deliverable_id_add || deliverable_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Deliverable is required');
                } else {
                    errDiv.text('');
                }
            });

            // Validate Slot Notes (multi-select)
            $('.slot_notes_packg_edit:visible:enabled').each(function () {
                let notes_id_add = $(this).val();
                let errDiv = $(this).closest('.mb-1').find('.slot_notes_packg_edit_err');

                if (!notes_id_add || notes_id_add.length === 0) {
                    valid = false;
                    errDiv.text('At least one Note is required');
                } else {
                    errDiv.text('');
                }
            });

            // Submit form if valid
            if (valid) {
                saveAccountDetailsPackg()
                $('#editPackagePaymentSlotForm').submit();
                $('#editPackagePaymentSlotBtn').prop('disabled', true);
            } else {
                $('#editPackagePaymentSlotBtn').prop('disabled', false);
            }
        });
                            
          
    }
</script>


<script>
   
    var PckgpaymentSlotListCacheEdit = [];
    var PckgdeliverablesListCacheEdit = [];
    var PckgnotesListCacheEdit = [];
    $.ajax({
        url: "/payment_slot_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgpaymentSlotListCacheEdit = response.data; 
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });
    function populateSlotDropdownsPckgEdit(val, targetDropdown) {
        var selectedValues = $('.payment_slot_id_packg_edit').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Payment Milestone</option>');

        PckgpaymentSlotListCacheEdit.forEach(function (slot) {
            if (!selectedValues.includes(slot.sno.toString()) || slot.sno.toString() === currentValue) {
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.payment_slot_name));
            }
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }

    $.ajax({
        url: "/deliverable_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgdeliverablesListCacheEdit = response.data; 
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateDeliverablesDropdownsPckgEdit(val, targetDropdown) {
        var selectedValues = $('.slot_deliverables_packg_edit').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Deliverables</option>');

        PckgdeliverablesListCacheEdit.forEach(function (slot) {
            
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.delivarable_name));
          
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }


     $.ajax({
        url: "/slot_notes_list",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                    PckgnotesListCacheEdit = response.data; 
                
            }
        },
        error: function(error) {
            // console.error('Error fetching course categories:', error);
        }
    });

    function populateNotesDropdownsPckgEdit(val, targetDropdown) {
        var selectedValues = $('.slot_notes_packg_edit').map(function () {
            return $(this).val();
        }).get();

        var $dropdown = $(targetDropdown);
        var currentValue = $dropdown.val();
        $dropdown.empty();
        $dropdown.append('<option value="">Select Milestone Notes</option>');

        PckgnotesListCacheEdit.forEach(function (slot) {
           
                $dropdown.append($('<option></option>')
                    .attr('value', slot.sno)
                    .text(slot.slot_notes_name));
        
        });

        if (val) {
            $dropdown.val(val).trigger('change');
        } else if (currentValue) {
            $dropdown.val(currentValue);
        }
    }


    
</script>


<script>
    window.onload = function () {

        const packageSelect = document.getElementById('package_id');
            if(packageSelect.value) {
                packageSelect.dispatchEvent(new Event('change'));
            }

        if (!preProposalData) return;

        // Set coupon code if available
        if (couponCode) {
            $('#new_coupon_code').val(couponCode);
        }

        // Preselect additional charges
        if (preProposalData.additional_charges_ids) {
            try {
                const charges = JSON.parse(preProposalData.additional_charges_ids);
                $('#addtional_charges_id').val(charges).trigger('change');
            } catch (e) {
                console.error("Invalid additional_charges_ids JSON:", e);
            }
        }

        if(preProposalData.slot_balance){
            $('.split_balance_label').text(formatCurrency(preProposalData.slot_balance));
            $('#slot_balance_amt').val(preProposalData.slot_balance);
            $('#payment_slot_total_amt').val(preProposalData.slot_balance);
            
        }

        if(preProposalData.package_id>0){
            $('#package_id').val(preProposalData.package_id).change();
        }


        // Handle Add-ons
        if (preProposalData.add_ons != null) {
            try {
                const addOns = JSON.parse(preProposalData.add_ons);

                if (Array.isArray(addOns) && addOns.length > 0) {
                    $('#prod_add_on').prop('checked', true);
                    $('#view_product_add_on').show();

                    addOns.forEach(function (item) {
                        $('#addOn_chk_' + item.add_on_id).prop('checked', true);
                        $('input[name="addOn_varient_' + item.add_on_id + '"][value="' + item.varient_id + '"]').prop('checked', true);
                        $('input[name="addon_amount_' + item.varient_id + '"]').val(item.amount);
                    });
                }

            } catch (e) {
                console.error("Invalid add_ons JSON:", e);
            }
        }

       
        // Wait for DOM changes then trigger calculations
        setTimeout(() => {
            calculateAddonTotal();     // Recalculate add-on total
            coupon_code_func();        // Validate and apply coupon
            calculateOverTotal();      // Final total after all adjustments
            console.log($('#new_coupon_code').val())
        }, 100); // Wait 300ms for DOM to update
    }
    
      product_list()
      
      
      
      
      
</script>
<script>
 
      old_customer_func()
    function old_customer_func(){
        const checkbox = document.getElementById("old_customer_check");
        const comunication = document.getElementById("send_proposal");
        if (checkbox.checked) {
          $('#old_customer_check').val(1);
          $('#customer_send_btn').hide();
        } else {
          $('#old_customer_check').val(0);
           $('#customer_send_btn').show();
        }
    }
</script>


@endsection