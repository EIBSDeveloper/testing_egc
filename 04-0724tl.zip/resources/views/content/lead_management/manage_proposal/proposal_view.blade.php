@extends('layouts/layoutMaster')

@section('title', 'View Proposal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
])
@endsection

@section('page-script')
@endsection
@section('content')
<!-- Users List Table -->
<style>
    .list_page thead th,
    .list_page tbody td {
        border: 1px solid black !important;
        padding: 8px !important;
    }
</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
    $user_id = auth()->user()->user_id ?? 16;
@endphp
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">View Proposal</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mb-1">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Proposal</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{ $proposal->registered_date ? date($common_date_format, strtotime($proposal->registered_date)) :'-' }}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$proposal->lead_name}}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Sale Agent</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$proposal->nick_name ?? $proposal->staff_name}}</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Mobile No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$proposal->lead_mobile ?? '-'}}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$proposal->lead_email_id ?? '-'}}</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Currency Format</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">{{$proposal->currency_code}} - {{$proposal->currency_symbol}}</label>
                </div>
            </div>
        </div>
        <div class="row">
            @if(isset($proposalList))
            @foreach($proposalList as $i=>$list)
            @php
                $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt',);
                $print_url = url('/manage_proposal/print_proposal/' . $encryptedValue,);
                $serialNo = (count($proposalList) - $i) < 10 ? '0' . (count($proposalList) - $i) : (count($proposalList) - $i);
            @endphp
            <div class="col-lg-12">
                <div class="shadow-lg border border-gray-800 rounded mb-4">
                    <div class="cursor-pointer d-flex align-items-center justify-content-between flex-wrap rounded px-4 py-2 accr-toggle" id="accr_{{$i}}" data-target="#accr_{{$i}}_tbox" style="background-color: #DFDBDB;">
                        <div class="mb-4">
                            @if($list->proposal_status !=0 && $list->proposal_status !=2)
                            <label class="bg-label-success rounded-circle fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Accepted"><i class="mdi mdi-check-decagram fs-1 fw-bold opacity-1 text-success"></i></label>
                            @endif
                            <label class="badge bg-info fw-semibold fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">{{$serialNo}}</label>
                            <label class="text-black fs-5 fw-semibold ms-2">{{$list->proposal_id}}</label>
                            <div class="d-block">
                                <label class="fs-6 text-black fw-semibold">Estimate Date &nbsp;-&nbsp;</label>
                                <label class="badge bg-success fs-6 text-white rounded fw-semibold">{{ $list->estimate_date ? date($common_date_format, strtotime($list->estimate_date)) :'-' }}</label>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-end mb-4">
                            <div class="cursor-pointer me-2">
                                <a href="{{$print_url}}" target="_blank" class="border border-dark rounded px-1 py-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Print">
                                    <span><i class="mdi mdi-printer-pos-outline fs-1 text-black"></i></span>
                                </a>
                            </div>
                            <div class="mb-0">
                                <div class="d-block">
                                    <label class="fs-4 text-black fw-semibold">Total Amount &nbsp;-&nbsp;</label>
                                    <label class="fs-4 text-black rounded fw-bold">{{$proposal->currency_symbol}} {{number_format($proposal->grant_total_amount) }}</label>
                                </div>
                                <div class="d-block">
                                    <label class="fs-6 text-black fw-semibold">Validity Date &nbsp;-&nbsp;</label>
                                    <label class="badge bg-danger fs-6 text-white rounded fw-semibold">{{ $list->due_date ? date($common_date_format, strtotime($list->due_date)) :'-' }}</label>
                                </div>
                            </div>
                            <label class="cursor-pointer op_cl ms-3"><i class="mdi mdi-menu-up text-black fs-2"></i></label>
                        </div>
                    </div>
                    <div class="px-5 pb-4 pt-2" id="accr_{{$i}}_tbox" style="display: block;">
                        <div class="fs-2 text-center text-black my-3 fw-bold">Service Details</div>
                        <div class="row">
                            <div class="col-lg-12 mb-2">
                                <table class="table align-top gy-1 gs-2 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="w-50px text-center">S.No</th>
                                            <th class="w-300px text-center">Work </th>
                                            <th class="w-50px text-center">Qty </th>
                                            <th class="w-100px text-center">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600">
                                        @if($list->product_package == 1)
                                        @foreach($list->products as $index=> $product)
                                         @php
                                            $variant_name = [];
                                             $milestoneCount = $list->slotCount;
                                            foreach ($product->cart_variants ?? [] as $variants) {
                                                foreach ($variants as $variant) {
                                                    if (!empty($variant)) {
                                                        $variant_name[] = trim($variant);
                                                    }
                                                }
                                            }
                                        
                                            $variant_view_name = implode(', ', $variant_name);
                                        @endphp
                                        <tr>
                                            <td align="center">{{$index+1}}</td>
                                            <td>
                                                <div>
                                                    @if($index == 0 )
                                                    <div class="text-black fw-bold fs-6 my-2">
                                                        <label class="text-black fw-bold fs-6 my-2" >{{$list->service_title}}</label>
                                                        <div>Total Costing &nbsp;:&nbsp; <label class=" text-black fw-bold fs-6 my-2me-2">** {{$proposal->currency_symbol}} {{number_format($list->total_amount) }} /- **</label> <label class="text-dark">(Includes {{$list->gst_perc}}% GST)</label></div>
                                                        
                                                        <div class="text-black fw-bold fs-7 my-1">
                                                            <label class="text-dark">Total Milestone &nbsp;:&nbsp;</label>
                                                            <label class="me-2 text-dark">{{$list->slotCount}}</label>
                                                            
                                                        </div>
                                                        @if($list->domain_names)
                                                         <div class="text-black fw-semibold fs-7 my-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Domain" >
                                                            <label class="text-black">{{$list->domain_names}}</label>
                                                        </div>
                                                        @endif
                                                        @if($list->topic)
                                                         <div class="text-black fw-semibold fs-7 my-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Topic" >
                                                            <label class="text-black">{{$list->topic}}</label>
                                                        </div>
                                                        @endif
                                                        @if($list->page_word_count>0)
                                                         <div class="text-black fw-semibold fs-7 my-1" >
                                                             <label class="text-black">
                                                                {{ $list->page_word_count }} 
                                                                {{ $list->page_word == 1 ? Str::plural('Page', $list->page_word_count) : Str::plural('Word', $list->page_word_count) }}
                                                            </label>
                                                        </div>
                                                        @endif
                                                       
                                                    </div>
                                                    
                                                    @endif
                                                    <!--<div class="text-black fw-semibold fs-6 mb-1">{{$product->product_name}} ( {{$proposal->currency_symbol}} {{number_format($product->total_amount_cart) }} )</div>-->
                                                    <!--<div class="text-dark fw-semibold fs-7">{{$product->product_category_name}}</div>-->
                                                    <!-- @if(!empty($variant_name))-->
                                                    <!--<div class="text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Variant Names" >({{$variant_view_name}})</div>-->
                                                    <!--@endif-->
                                                    
                                                    <div class="my-4"></div>
                                                    
                                                    @if(count($product->tools_name)>0)
                                                    <div class="text-black fw-semibold fs-6 my-2">Tools</div>
                                                     @foreach($product->tools_name as $inxTl=> $tools)
                                                    <div class="d-block ms-3"><span class="fw-bold">{{$inxTl+1}}. </span>{{$tools}}</div>
                                                    @endforeach
                                                    @endif
                                                   
                                                    @foreach($product->cart_slots as $indexslt=> $slot)
                                                    @if($indexslt !=0)
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                    @endif
                                                    @php
                                                   
                                                    $start_or_deliver=$slot['start_deliver_work'] == 1 ? 'To Start the Work':($slot['start_deliver_work'] == 2 ? 'To Deliver the Work':'');
                                                    $start_color=$slot['start_deliver_work'] == 1 ? 'bg-success':($slot['start_deliver_work'] == 2 ? 'bg-warning':'');
                                                    @endphp
                                                    <div class="text-black fw-semibold fs-6 my-2">{{$milestoneCount==1 ? 'Milestone': $slot['payment_slot_name']}} : {{$proposal->currency_symbol}} {{number_format($slot['slot_amount'] ?? 0) }} /- <span class="badge {{$start_color}} fs-7 text-black rounded fw-semibold">{{$start_or_deliver}}</span></div>
                                                         {{-- Deliverables --}}
                                                            <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                            
                                                           @foreach($slot['deliverables'] ?? [] as $variantName => $deliverList)
                                                                @php
                                                                    $DeliverablevariantNames = $helper->get_variant_and_varibale_name($variantName);
                                                                    $listId = "deliverables-list-" . $slot['sno'] . "-" . \Str::slug($variantName, '-');
                                                                @endphp
                                                            
                                                                <div class="fw-bold ms-2">{{ $DeliverablevariantNames }}</div>
                                                            
                                                                <ul id="{{ $listId }}" class="list-group ms-3 mb-3 deliverable-sortable"
                                                                    data-slot-id="{{ $slot['sno'] }}"
                                                                    data-cart-id="{{ $variantName }}">
                                                                    
                                                                    @foreach($deliverList as $deliverableId => $deliverableName)
                                                                        <li class="list-group-item border-none p-1 cursor-move" data-id="{{ $deliverableId }}">
                                                                            <strong><span class="mdi mdi-drag-variant"></span> </strong>{!! nl2br(e($deliverableName)) !!} 
                                                                            
                                                                        </li>
                                                                    @endforeach
                                                            
                                                                </ul>
                                                            @endforeach

                                                    
                                                       {{-- Notes --}}
                                                            <div class="my-4"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                            
                                                            @foreach($slot['slot_notes'] ?? [] as $variantName => $notesList)
                                                                @php
                                                                    $slotvariantNames = $helper->get_variant_and_varibale_name($variantName);
                                                                    $iNote = 1; // ✅ Reset note counter per variant
                                                                @endphp
                                                            
                                                                <div class="fw-bold ms-2">{{ $slotvariantNames }}</div>
                                                            
                                                                @foreach($notesList as $note)
                                                                    <div class="d-block ms-4  my-1 mb-2"><strong>{{ $iNote++ }}. </strong> {!! nl2br(e($note)) !!}</div>
                                                                @endforeach
                                                            @endforeach

                                                         @if($slot['slot_description'])
                                                        <div class="my-4"></div>
                                                        <div class="text-black fw-semibold fs-6 my-2">Description</div>
                                                        <div class="d-block">{{$slot['slot_description']??''}}</div>
                                                        @endif

                                                    @endforeach
                                                    
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                     @if(count($list->productAddon)>0)
                                                        <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                        @if(count($list->freeAddonProducts)>0)
                                                            <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                            @foreach($list->freeAddonProducts as $freeindex => $addon)
                                                            <div class="d-block text-black ms-5"> 
                                                                {{ $freeindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                                <span style="background-color: #994646;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                                    <del>{{$proposal->currency_symbol}} {{ number_format($addon->addon_amount) }}</del>
                                                                </span></div>
                                                            @endforeach 
                                                        @endif
                                                        @if(count($list->paidAddonProducts)>0)
                                                            <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                         @foreach($list->paidAddonProducts as $paidindex => $addon)
                                                            <div class="d-block text-black ms-5">
                                                             {{ $paidindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                            <span style="background-color: #8a2be2;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                                {{$proposal->currency_symbol}} {{ number_format($addon->addon_amount) }}
                                                            </span>
                                                        </div>
                                                         @endforeach 
                                                        @endif
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                    <div class="my-4"></div>
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                   @endif
                                                   @if($index == count($list->products)-1 )
                                                    <div class="my-4"></div>
                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                        <label>{{$list->delivery_duration}} to {{$list->delivery_duration_end}}</label>
                                                        <label>working days</label>
                                                    </div>
                                                    @endif
                                                </div>
                                            </td>
                                            <td align="center">
                                                <label class="fs-6 fw-bold">{{count($product->cart_quantities)}}</label>
                                            </td>
                                            <td align="right">
                                                <label class="fs-6 text-black fw-semibold">{{$proposal->currency_symbol}} {{number_format($product->total_amount_cart) }}</label>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @else
                                            @php
                                                $product_name = [];
                                                $product_view_name = '';
                                                foreach ($packages->product_name as $packge_prod) {
                                                    if ($packge_prod) {
                                                        $name = $packge_prod ?? '';
                                                        $product_name[] = trim($name, ',');
                                                    }
                                                }
                                                if (!empty($product_name)) {
                                                    $product_view_name = implode(', ', $product_name);
                                                }
                                                $milestoneCountPackg=count($list->package_slots);
                                            @endphp
                                        <tr>
                                            <td align="center">1</td>
                                            <td>
                                                <div>
                                                    <div class="text-black fw-bold fs-6 my-2">
                                                        <label class="text-black fw-bold fs-6 my-2" >{{$packages->package_name}} ( {{$product_view_name}} )</label>
                                                        <div>Total Costing &nbsp;:&nbsp; <label class=" text-black fw-bold fs-6 my-2me-2">** {{$proposal->currency_symbol}} {{number_format($list->total_amount) }} /- **</label><label class="text-dark">(Includes {{$list->gst_perc}}% GST)</label> </div>
                                                        
                                                        <div class="text-black fw-bold fs-7 my-1">
                                                            <label class="text-dark">Total Milestone &nbsp;:&nbsp;</label>
                                                            <label class="me-2 text-dark">{{count($list->package_slots)}}</label>
                                                            
                                                        </div>
                                                        @if($list->domain_names)
                                                         <div class="text-black fw-semibold fs-7 my-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Domain" >
                                                            <label class="text-black">{{$list->domain_names}}</label>
                                                        </div>
                                                        @endif
                                                        @if($list->topic)
                                                         <div class="text-black fw-semibold fs-7 my-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Topic" >
                                                            <label class="text-black">{{$list->topic}}</label>
                                                        </div>
                                                        @endif
                                                        @if($list->page_word_count>0)
                                                         <div class="text-black fw-semibold fs-7 my-1" >
                                                             <label class="text-black">
                                                                {{ $list->page_word_count }} 
                                                                {{ $list->page_word == 1 ? Str::plural('Page', $list->page_word_count) : Str::plural('Word', $list->page_word_count) }}
                                                            </label>
                                                        </div>
                                                        @endif
                                                       
                                                    </div>
                                                    <!--<div class="text-black fw-semibold fs-6 mb-1">{{$packages->package_name}} ( {{$product_view_name}} )</div>-->
                                                    <!--<div class="my-4"></div>-->
                                                    <!--<div class="text-dark fw-semibold fs-6 my-2">-->
                                                    <!--    <label>Total Costing &nbsp;:&nbsp;</label>-->
                                                    <!--    <label class="me-2">** {{$proposal->currency_symbol}} {{number_format($list->grant_total_amount) }} /- **</label> -->
                                                    <!--    <label>Total Milestone &nbsp;:&nbsp;</label>-->
                                                    <!--    <label class="me-2">{{count($list->package_slots)}}</label>-->
                                                    <!--    <label>(Includes {{$list->gst_perc}}% GST)</label>-->
                                                    <!--</div>-->
                                                    
                                                    @foreach($list->package_slots as  $indexslt=> $slot)
                                                    @php
                                                   
                                                    $start_or_deliver=$slot->start_deliver_work == 1 ? 'To Start the Work':($slot->start_deliver_work == 2 ? 'To Deliver the Work':'');
                                                    $start_color=$slot->start_deliver_work == 1 ? 'bg-success':($slot->start_deliver_work == 2 ? 'bg-warning':'');
                                                    @endphp
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                    <div class="text-black fw-semibold fs-6 my-2">{{$milestoneCountPackg==1 ? 'Milestone': $slot->payment_slot_name}} : {{$proposal->currency_symbol}} {{number_format($slot->slot_amount) }} /- <span class="badge {{$start_color}} fs-7 text-black rounded fw-semibold">{{$start_or_deliver}}</span></div>
                                                    <div class="text-black fw-semibold fs-6 my-2">Deliverables</div>
                                                    @foreach($slot->deliverables as $iDelv=> $deliver)
                                                    <div class="d-block ms-3"><strong>{{$iDelv+1}}. </strong>{!! nl2br(e($deliver)) !!}</div>
                                                     @endforeach
                                                    <div class="my-4"></div>
                                                    <div class="text-black fw-semibold fs-6 my-2">Note</div>
                                                    @foreach($slot->slot_notes as $isltNt=> $slotNotes)
                                                    <div class="d-block ms-3"><strong>{{$isltNt+1}}. </strong>{!! nl2br(e($slotNotes)) !!}</div>
                                                    @endforeach
                                                        @if($slot->slot_description)
                                                            <div class="my-4"></div>
                                                            <div class="text-black fw-semibold fs-6 my-2">Description</div>
                                                            <div class="d-block">{{$slot->slot_description??''}}</div>
                                                        @endif
                                                    @endforeach
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                    
                                                     @if(count($list->productAddon)>0)
                                                        <div class="text-black fw-semibold fs-6 my-2">Add On Services</div>
                                                        @if(count($list->freeAddonProducts)>0)
                                                            <div class="text-black fw-semibold fs-7 my-4 ms-3">Free Services</div>
                                                            @foreach($list->freeAddonProducts as $freeindex => $addon)
                                                            <div class="d-block text-black ms-5"> 
                                                                {{ $freeindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                                <span style="background-color: #994646;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                                    <del>{{$proposal->currency_symbol}} {{ number_format($addon->addon_amount) }}</del>
                                                                </span></div>
                                                            @endforeach 
                                                        @endif
                                                        @if(count($list->paidAddonProducts)>0)
                                                            <div class="text-black fw-semibold fs-7 my-4 ms-3">Paid Services</div>
                                                         @foreach($list->paidAddonProducts as $paidindex => $addon)
                                                            <div class="d-block text-black ms-5">
                                                             {{ $paidindex + 1 }}. {{ $addon->addon_name }} - {{ $addon->addon_variablename }}
                                                            <span style="background-color: #8a2be2;color:white;border-radius:4px;padding:0px 10px;font-weight:400;">
                                                                {{$proposal->currency_symbol}} {{ number_format($addon->addon_amount) }}
                                                            </span>
                                                        </div>
                                                         @endforeach 
                                                        @endif
                                                   
                                                    <div class="my-4"></div>
                                                    <div class="border-bottom my-4 border-gray-400 border-1 border-dashed"></div>
                                                   @endif
                                                    
                                                    <div class="my-4"></div>
                                                    <div class="text-black fw-semibold fs-6 my-2">
                                                        <label>Duration &nbsp;:&nbsp;</label>
                                                        <label>{{$list->delivery_duration}} to {{$list->delivery_duration_end}}</label>
                                                        <label>working days</label>
                                                    </div>
                                                </div>
                                            </td>
                                            <td align="center">
                                                <label class="fs-6 fw-bold">1</label>
                                            </td>
                                            <td align="right">
                                                <label class="fs-6 text-black fw-semibold">{{$proposal->currency_symbol}} {{number_format($list->packageTotalCart ?? $list->package_amount)}}</label>
                                            </td>
                                        </tr>
                                        
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                @if(count($list->additional_charge_list) > 0)
                                <div class="border border-gray-700 rounded pb-2">
                                    <div class="d-flex align-items-center justify-content-between border-bottom rounded-top bg-label-info" style="background-color: #adff2f78 !important;">
                                        <div class="mb-0 ps-3 py-2">
                                            <label class="text-black fw-semibold fs-6">Additional Charges</label>
                                        </div>
                                        <div class="me-3">
                                            <div class="badge bg-secondary rounded fs-6">{{count($list->additional_charge_list)}}</div>
                                        </div>
                                    </div>
                                    <div class="scroll-y max-h-200px px-3 py-2">
                                        <div class="row mt-2 px-3">
                                            @foreach($list->additional_charge_list as $additional_charge)
                                            <div class="d-flex align-items-start mb-2">
                                                <div class="text-black fw-semibold fs-7 me-2">1.</div>
                                                <div class="text-black fs-7 fw-semibold text-wrap">
                                                    <span>{{$additional_charge->adc_name}}</span>
                                                    <span class="ms-1 text-danger fw-semibold fs-6">({{$additional_charge->adc_percentage}}% )</span>
                                                </div>
                                            </div>
                                            @endforeach
                                            
                                        </div>
                                    </div>
                                </div>
                                @endif
                            </div>
                            @php
                            $discountLabel = '';
                            if (!empty($list->discount_type) && !empty($list->discount_value)) {
                                if ($list->discount_type == '2') {
                                    $discountLabel = $proposal->currency_symbol .' '. $list->discount_value;
                                } elseif ($list->discount_type == '1') {
                                    $discountLabel = $list->discount_value . '%';
                                }
                            }
                        @endphp
                            <div class="col-lg-6">
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-dark fs-5 me-13">Sub Total</label>
                                    <div class="fw-bold text-dark fs-2">
                                        <!--<span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>-->
                                        <span class="fs-3">{{$proposal->currency_symbol}} {{number_format($list->sub_total) }}</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2">
                                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                            <div class="me-0">
                                                <label>Discount</label>
                                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">@if($list->discount_id >0) {!! $discountLabel ? "($discountLabel)" : '' !!} @endif</label><br>
                                                @if($list->coupon_code) <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">
                                                   [ {{$list->coupon_code}} ]</label>@endif
                                            </div>
                                        </div>
                                        <div class="fw-bold fs-2">
                                            <!--<span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>-->
                                            <span class="fs-3">{{$proposal->currency_symbol}} {{number_format($list->discount_amount) }}</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-dark text-end fs-5 me-13">Additional Charges<br><span class="text-danger fw-bold">( {{$list->additional_charge_perc }}% )</span></label>
                                    <div class="fw-bold text-dark fs-2">
                                        <!--<span><i class="mdi mdi-currency-rupee fs-4 fw-bold text-dark"></i></span>-->
                                        <span class="fs-3">{{$proposal->currency_symbol}} {{number_format($list->additional_charge_amount) }}</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                                    <div class="fw-bold text-black fs-2">
                                        <!--<span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>-->
                                        <span class="fs-2">{{$proposal->currency_symbol}} {{number_format($list->grant_total_amount) }}</span>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                                    <div class="fw-bold fs-5 me-12">
                                        <div class="text-dark mb-1 fs-5 fw-semibold">
                                            <label>GST <span class="text-danger fw-bold">( {{$list->gst_perc }}% )</span></label>
                                            <!--<div class="d-block fw-bold fs-8">[{{$list->gst_inclusive ==1 ? ' Inclusive ':' Exclusive '}}]</div>-->
                                        </div>
                                    </div>
                                    <div class="fw-bold fs-2">
                                        <!--<label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>-->
                                        <label class="fs-3">{{$proposal->currency_symbol}} {{number_format($list->gst_amount) }}</label>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                            <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                            <div class="fw-bold text-black fs-2">
                                <!--<label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>-->
                                 <label class="fs-1">{{$proposal->currency_symbol}} {{number_format($list->total_amount) }}</label>
                            </div>
                        </div>
                        @if($list->proposal_status == 2 )
                        <div class="mb-2">
                            <div class="text-black fw-semibold fs-5 mb-2"><u>Reason</u></div>
                            @if($list->reject_reason == 'others')
                                <div class="text-danger fw-semibold fs-6">{{ $list->reject_reason_other ?? ''}}</div>
                            @else
                                <!--<div class="text-danger fw-semibold fs-6">{{ $list->reason_comments ?? ''}}</div>-->
                                <div class="text-danger fw-semibold fs-6">{{ $list->reason_comments ?? ''}}</div>
                            @endif
                            
                        </div>
                       @endif
                    </div>
                </div>
            </div>
            @endforeach
            @endif
           
        </div>
    </div>
</div>


<script>
   $(document).ready(function () {
        $('.accr-toggle').on('click', function () {
            const targetSelector = $(this).data('target');
            const targetBox = $(targetSelector);
        
            targetBox.slideToggle('fast');
        
            // Toggle the icon inside the clicked header
            const icon = $(this).find('.op_cl i');
            icon.toggleClass('mdi-menu-up mdi-menu-down');
        }); 
    });

   
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +

            "<'table-responsive'tr>"

        // "<'row'" +
        // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>"


    });
</script>

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.deliverable-sortable').forEach(function (list) {
            new Sortable(list, {
                animation: 150,
                onEnd: function () {
                    const slotId = list.getAttribute('data-slot-id');
                    const cartId = list.getAttribute('data-cart-id');
                    const orderedIds = Array.from(list.querySelectorAll('li')).map(li => li.getAttribute('data-id'));

                    fetch("{{ route('update.deliverable.order') }}", {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        },
                        body: JSON.stringify({
                            slot_id: slotId,
                            cart_id: cartId,
                            ordered_ids: orderedIds,
                        }),
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (!data.success) {
                            alert("Failed to update deliverable order.");
                        }
                    })
                    .catch(err => {
                        console.error("Error updating order:", err);
                    });
                }
            });
        });
    });
</script>



@endsection