@extends('layouts/blankLayout')

@section('title', 'Proposal Confirmation')
@section('content')

<style>
    /* page[size="A4"] {
        width: 210mm !important;
        height: 297mm !important;
        box-sizing: border-box;
        margin: 0 auto;
        margin-bottom: 0.5cm;
    } */

    @media print {

        /* @page {
            margin-top: 10px;
        } */

        body {
            background-color: white !important;
            margin: 0px !important;
            padding: 0px !important;
            /* padding-top: 100px !important; */
        }

        /* .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: white;
            z-index: 1000;
        } */

        .print-container::before {
            content: "";
            display: block;
            height: 150px;
        }

        .start_cont {
            background: none !important;
            /* padding-top: 180px; */
            /* counter-reset: page; */
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        tr,
        td {
            border: 1px solid #ddd;
            padding: 5px;
            break-inside: avoid !important;
        }
    }

    table th,
    tr,
    td {
        border-collapse: collapse;
        border: 1px solid #ddd;
        padding: 5px;
    }










    @media (max-width: 576px) {
        .w-xs-25 {
            width: 25% !important;
        }

        .w-xs-50 {
            width: 50% !important;
        }

        .w-xs-75 {
            width: 75% !important;
        }

        .w-xs-100 {
            width: 100% !important;
        }
    }

    /* Small devices (landscape phones, 576px and up) */
    @media (min-width: 576px) {

        .w-sm-25 {
            width: 25% !important;
        }

        .w-sm-50 {
            width: 50% !important;
        }

        .w-sm-75 {
            width: 75% !important;
        }

        .w-sm-100 {
            width: 100% !important;
        }

        .text-sm-center {
            text-align: center !important;
        }
    }

    /* Medium devices (tablets, 768px and up) */
    @media (min-width: 768px) {
        .w-md-25 {
            width: 25% !important;
        }

        .w-md-50 {
            width: 50% !important;
        }

        .w-md-75 {
            width: 75% !important;
        }

        .w-md-100 {
            width: 100% !important;
        }

        .text-md-center {
            text-align: center !important;
        }
    }

    /* Large devices (desktops, 992px and up) */
    @media (min-width: 992px) {

        .w-lg-25 {
            width: 25% !important;
        }

        .w-lg-45 {
            width: 45% !important;
        }

        .w-lg-50 {
            width: 50% !important;
        }

        .w-lg-75 {
            width: 75% !important;
        }

        .w-lg-100 {
            width: 100% !important;
        }
    }
</style>
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
  
<center>
    <div class="p-5 mt-0 w-lg-45 w-md-100 w-sm-100">
    <div class="border border-gray-500i rounded p-10" style="background: linear-gradient(#fff6aa, white);">
        <h6 class="text-center text-black fw-bold fs-1">Payment Pending</h6>
        
        <div class="mb-0 d-flex justify-content-center">
            <img src="{{ asset('assets/phdizone_images/payLater.gif') }}" alt="Pay Later Image" class="image-input-wrapper w-375px h-300px" id="showlogo">
        </div>

        <div class="text-center mt-4">
            <h6 class="text-black fs-3 fw-bold d-flex flex-wrap justify-content-center">
                <span class="me-2">Invoice ID</span> :
                <span class="fs-3">{{ $slot->invoice_id }}</span>
            </h6>
        </div>
        <div class="text-center mt-4">
            <h6 class="text-black fs-3 fw-bold d-flex flex-wrap justify-content-center">
                <span class="me-2">Amount </span> :
                <span class="fs-3">{{ $proposal->currency_symbol }} {{$converted_amount}}</span>
            </h6>
        </div>

        <div class="mt-4 text-center">
            <span class="text-black fs-5">Your payment has been deferred. Please Try to complete the payment before the due date.</span>
        </div>

        <div class="mt-3 text-center mb-2">
            <span class="text-black fs-6 fw-bold">Due Date:</span>
            <span class="text-danger fs-5">{{ $slot->due_date ? date($common_date_format, strtotime($slot->due_date)) : '-' }}</span>
        </div>

        <!-- Pay Now Button (before "If you've paid" message) -->
        <div class=" text-center">
            <button class="btn btn-primary px-5 py-2 fs-5 fw-bold" onclick="window.location.href='{{$link}}'">
                Pay Now
            </button>
        </div>

        <!-- Message after Pay Now button -->
        <div class="mt-4 text-center">
            <span class="text-black fs-6">If you’ve already paid, please share the proof with us at:</span>
        </div>

        <div class="mt-2 text-center">
            <span class="text-info fs-5">{{ $cug_mobile }}</span>
        </div>
    </div>
</div>

</center>


<script>

//   let timeLeft = 5; // seconds
//   const encrypted_lead_id = '{{$link}}'; // seconds
//   const timerElement = document.getElementById('timer');

//   const countdown = setInterval(() => {
//     timeLeft--;
//     // Display leading zero for single digit numbers
//     timerElement.textContent = timeLeft < 10 ? '0' + timeLeft : timeLeft;

//     if (timeLeft <= 0) {
//       clearInterval(countdown);
//     //   window.close();
//     //  window.location.href = 'https://www.google.com/'; 
//       window.location.href = encrypted_lead_id;
//     //  window.location.replace('https://www.google.com/');
//     }
//   }, 1000);
  
</script>

<!-- <script>
    window.onload = function() {
        setTimeout(function() {
            window.close();
        }, 5000);
    };
</script> -->
@endsection