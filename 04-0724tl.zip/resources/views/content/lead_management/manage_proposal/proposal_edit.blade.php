@extends('layouts/layoutMaster')

@section('title', 'Update Proposal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/quill/katex.scss',
'resources/assets/vendor/libs/quill/editor.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/quill/katex.js',
'resources/assets/vendor/libs/quill/quill.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite(['resources/assets/js/forms_custom_editors.js'])
@endsection
@section('content')

<style>
    .list-group-item {
        background-color: #efdaff;
        color: #333;
        border: 1px solid #5c5c5c;
        transition: background-color 0.3s, color 0.3s;
    }

    .list-group-item:hover {
        background-color: #d1b3ff;
        color: #000;
    }

    .list-group-item.active,
    .list-group-item:active {
        background-color: #099DDA !important;
        color: #fff !important;
        border-color: #099DDA !important;
    }

    .select2-selection__choice {
        text-wrap: wrap !important;
    }
</style>
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Update Proposal</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboard/crm')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Lead Management</a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:void(0);" class="d-flex align-items-center">Manage Proposal</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">07-Mar-2025</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">Priya</label>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Mobile No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">9876543210</label>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Email ID</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">priya@gmail.com</label>
                </div>
                <!-- <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Address</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-8 text-black fs-6 fw-semibold">1, Bharathiyar Street, Avaniyapuram, Madurai, Tamilnadu, India - 625012</label>
                </div> -->
            </div>
            <!-- <div class="col-lg-4 mb-3">
                <label class="text-dark mb-1 fs-6 fw-semibold">Work Name<span class="text-danger">*</span></label>
                <input type="text" class="form-control me-2" placeholder="Enter Work Name" />
            </div>
            <div class="col-lg-4">
                <label class="text-dark mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                <select id="payment_slot" class="select3 form-select" data-style="btn-default" data-live-search="true">
                    <option value="">Select Payment Slot</option>
                    <option value="1">Single Slot</option>
                    <option value="2">Dual Slot</option>
                </select>
            </div> -->
        </div>
        <div class="divider divider-primary mb-6">
            <div class="divider-text fs-3 text-black fw-semibold">Service Details</div>
        </div>
        <div class="row">
            <div class="col-lg-3 d-flex align-items-center gap-3 mb-3">
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px" type="radio" id="serv_prod_chk" name="serv_prod_pckg_chk" onclick="service_add_func('product');" checked />
                    <label class="form-check-label fs-4 fw-semibold text-black">Products</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px" type="radio" id="serv_pckg_chk" name="serv_prod_pckg_chk" onclick="service_add_func('package');" />
                    <label class="form-check-label fs-4 fw-semibold text-black">Packages</label>
                </div>
            </div>
            <div class="col-lg-3 mb-6">
                <label class="text-black mb-1 fs-6 fw-semibold">Service Title<span class="text-danger">*</span></label>
                <input type="text" class="form-control me-2" placeholder="Enter Service Title" value="Priya Work Details" />
            </div>
            <div class="col-lg-3 mb-6">
                <label class="text-black mb-1 fs-6 fw-semibold">Proposal Due Date<span class="text-danger">*</span></label>
                <div class="input-group input-group-merge">
                    <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" id="quotation_validity" placeholder="Select Date" class="form-control" value="<?php echo date(" d-M-Y"); ?>" />
                </div>
            </div>
            <div class="col-lg-3 mb-6">
                <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span class="text-danger">*</span></label>
                <select class="select3 form-select">
                    <option value="">Select Currency Format</option>
                    <option value="1">USD - $</option>
                    <option value="2">EUR - €</option>
                    <option value="3">GBP - £</option>
                    <option value="5" selected>INR - ₹</option>
                    <option value="6">KWD - د.ك</option>
                </select>
            </div>
        </div>
        <div id="serv_product_chk_tbox">
            <div class="row">
                <div class="col-lg-12 mb-3">
                    <div class="nav-align-top mb-2">
                        <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                            <div class="scroll-container-wrapper">
                                <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                                <div class="scroll-container" id="scrollContainer">
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1 active" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_1" aria-controls="tab_cate_1" aria-selected="false">
                                                <span class="ms-2">Writing Products</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">04</span>
                                            </button>
                                        </li>
                                    </div>
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_2" aria-controls="tab_cate_2" aria-selected="true">
                                                <span class="ms-2">Developement Products</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">02</span>
                                            </button>
                                        </li>
                                    </div>
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_3" aria-controls="tab_cate_3" aria-selected="true">
                                                <span class="ms-2">Reasearch Products</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">0</span>
                                            </button>
                                        </li>
                                    </div>
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_4" aria-controls="tab_cate_4" aria-selected="true">
                                                <span class="ms-2">PHD Products</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">0</span>
                                            </button>
                                        </li>
                                    </div>
                                    <div class="item">
                                        <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                            <button type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-1" role="tab" data-bs-toggle="tab" data-bs-target="#tab_cate_5" aria-controls="tab_cate_5" aria-selected="true">
                                                <span class="ms-2">Analysis Products</span>
                                                <span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">0</span>
                                            </button>
                                        </li>
                                    </div>
                                </div>
                                <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-1">
                    <div class="tab-content p-0">
                        <div class="tab-pane fade show active" id="tab_cate_1" role="tabpanel">
                            <div class="scroll-y border-gray-200i rounded max-h-250px px-3 py-3">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Thesis Writing</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">90 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">03</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">50 Pages of Grammar Check</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Reference Templates</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">LaTeX, Scrivener</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 75,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Literature Review Writing</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">14 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">02</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Structured academic writing with citations</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">References in the required citation style (e.g., APA, MLA, Chicago, etc.)</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">Google Scholar, Zotero</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 18,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Research Proposal Writing</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">10 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">04</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Well-structured and formatted proposal (including research objectives, methodology, and timeline)</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Citation and referencing in the required style</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Initial drafts for feedback and revisions</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">Roam Research, Inciteful</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 12,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Formatting and Referencing</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">7 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">04</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Ensure compliance with university guidelines for formatting (margins, page numbers, font size, etc.)</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Correct citation and referencing in the desired style (e.g., APA, MLA, Chicago, etc.)</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Table of contents, appendices, and list of figures/tables formatted properly</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">LaTeX, Scrivener</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 9,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab_cate_2" role="tabpanel">
                            <div class="scroll-y border-gray-200i rounded max-h-250px px-3 py-3">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Python Developement</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">120 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">03</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Reviewing and summarizing the existing research on a particular topic.</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Writing proposals that outline the research question, objectives, methodology, and expected outcomes.</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Writing or assisting with writing chapters for PhD theses or dissertations.</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">JupyterLab, Spyder</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 90,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <div class="card h-100 chse_me_card_btt rounded">
                                            <div class="card-body px-3 py-3">
                                                <div class="d-flex align-items-center h-35px mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Technical Research and Development Services</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center mb-2">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                            <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="d-block mb-0">
                                                        <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">60 Days</label>
                                                        <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                        <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">04</span>
                                                            <span class="fs-8 text-info"><u>View Info</u></span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-350px">
                                                            <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                            <hr class="mt-0 mb-2 border-dark">
                                                            <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Developing advanced algorithms for data analysis, machine learning models, or software solutions.</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Writing complex software programs or applications (Python, Java, R, etc.).</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Developing predictive models, training data, and analysis using machine learning techniques.</label>
                                                                </div>
                                                                <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                                    <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                                    <label class="text-black fw-semibold text-justify fs-7">Advising on the best research methodologies, techniques, and tools for your project.</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center h-35px mb-4">
                                                    <div class="me-2 cursor-pointer">
                                                        <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                            <i class="mdi mdi-tools fs-4"></i>
                                                        </div>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold facility_txt">Sphinx, MkDocs, nbconvert</div>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-center mb-2">
                                                    <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 1,30,000</div>
                                                </div>
                                                <div class="mb-1 chse_me_btt">
                                                    <a href="javascript:;" class="d-block btn btn-sm btn-primary fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_choose_me">Choose me</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab_cate_3" role="tabpanel">
                        </div>
                        <div class="tab-pane fade" id="tab_cate_4" role="tabpanel">
                        </div>
                        <div class="tab-pane fade" id="tab_cate_5" role="tabpanel">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-1">
                    <div class="card h-100 rounded">
                        <div class="scroll-y max-h-250px px-2 py-1">
                            <div class="card-body px-1 py-1">
                                <div class="row">
                                    <div class="col-lg-12 px-1">
                                        <div class="mb-1" id="cal_prod_1_az">
                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="cal_prod_1_hd">
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2 cursor-pointer">
                                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="cal_prod_1_fuc();" id="cal_prod_1_tlp">
                                                            <i class="mdi mdi-plus fs-4" id="cal_prod_1_plus_btton"></i>
                                                        </a>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Products">Writing Products</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-0">
                                                    <label class="fs-4 fw-semibold text-black">&#8377; 82,000</label>
                                                    <a href=" javascript:;" class="ms-1 fw-semibold fs-5">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Remove">
                                                            <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 22 22" width="20" height="20" id="X">
                                                                <g id="Page-1" fill="none" fill-rule="evenodd" stroke="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="1">
                                                                    <g id="Artboard" stroke="#999999" stroke-width="2" transform="translate(-1447 -2191)">
                                                                        <g id="x-circle" transform="translate(1448 2192)" fill="none" class="color000000 svgShape">
                                                                            <circle id="Oval" cx="10" cy="10" r="10" fill="none" class="color000000 svgShape"></circle>
                                                                            <path id="Shape" d="m13 7-6 6M7 7l6 6" fill="none" class="color000000 svgShape"></path>
                                                                        </g>
                                                                    </g>
                                                                </g>
                                                            </svg>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="px-3 py-1 mb-0" id="cal_prod_1_tbox" style="display: none;">
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Products</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 75,000</label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Durations</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">90 Days</label>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                                                    <a href="javascript:;" class="fw-semibold fs-5 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_update_choose_me">
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Variants">
                                                            <svg class="svg-hover" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="21" height="21" id="Edit">
                                                                <path fill="#888888" fill-rule="evenodd" d="M20.12,1 L17.309,3.86 L20.14,6.69 L22.95,3.83 L20.12,1 Z M1,2 L1,23 L21.999,23 L21.999,9.07 L19,12.07 L19,20 L3.999,20 L3.999,5 L11.93,5 L14.93,2 L1,2 Z M6,15.171 L6,17.999 L8.828,17.999 L18.728,8.1 L15.899,5.272 L6,15.171 Z"></path>
                                                            </svg>
                                                        </span>
                                                    </a>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pages">Pages</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="100 Pages">100 Pages</label>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 5,000</label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">Days</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="05 Days">05 Days</label>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 2,000</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center mt-4 mb-1">
                <div class="form-check form-check-inline">
                    <input class="form-check-input w-25px h-25px" type="checkbox" id="prod_add_on" name="prod_add_on" onclick="product_add_on_func();" checked />
                    <label class="text-black mb-1 fs-5 fw-semibold">Add-on Products</label>
                    <label class="text-black mb-1 fs-5 fw-bold me-1 ms-1">-</label>
                    <label class="badge bg-info mb-1 fw-semibold fs-5">&#8377; 20,000</label>
                </div>
            </div>
            <div class="mb-4" id="view_product_add_on" style="display:block;">
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-label-warning rounded pb-4 pt-4">
                            <div class="scroll-y max-h-275px px-3 py-0">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Plagiarism Check</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>50 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>100 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>150 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" checked />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>200 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>300 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 12,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_1" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>500 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Topic Suggestions</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_2" checked />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>03 Chapter</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_2" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>04 Chapter</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_2" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>05 Chapter</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_2" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>10 Chapter</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 3,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Thesis Writing</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>10 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>20 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" checked />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>100 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>150 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 20,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>200 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 40,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_3" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>300 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 45,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Sample Research Papers</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_4" checked />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>08 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_4" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>10 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_4" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>12 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_4" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>15 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Research Consultation (Into)</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_5" checked />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>30 Minutes</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_5" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>40 Minutes</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_5" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>50 Minutes</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_5" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>60 Minutes</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Research Proposal Writing</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_6" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>1,000 Words</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_6" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>1,500 Words</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_6" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>5,000 Words</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 20,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_6" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>7,000 Words</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 25,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Proof Reading & Editing</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_7" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>200 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 25,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_7" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>300 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 40,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_7" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>500 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 70,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Thesis Formatting</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_8" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>50 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 2,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_8" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>75 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 7,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_8" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>100 Pages</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Thesis Writing</label>
                                            </div>
                                            <div class="row mt-2">
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_9" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>100 Words Abstract</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_9" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>180 Words Abstract</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-lg-4 mb-1">
                                                    <div class="form-check">
                                                        <input class="form-check-input me-0" type="radio" name="add_on_9" />
                                                        <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                            <span>250 Words Abstract</span>
                                                            <span class="ms-1 me-1">-</span>
                                                            <span class="badge bg-danger rounded fw-semibold fs-7">Free</span>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mb-10" id="serv_package_chk_tbox" style="display: none;">
            <div class="row mb-3">
                <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Packages<span class="text-danger">*</span></label>
                    <select class="select3 form-select">
                        <option value="">Select Packages</option>
                        <option value="1">Basic Thesis Drafting</option>
                        <option value="2" selected>Complete Thesis Writing</option>
                        <option value="3">Fast Track Thesis Submission</option>
                        <option value="4">Thesis Editing & Enhancement</option>
                        <option value="5">Plagiarism Removal Product</option>
                        <option value="6">Research Proposal Writing</option>
                    </select>
                </div>
                <div class="col-lg-8 text-center">
                    <div class="d-flex align-items-start justify-content-between flex-wrap">
                        <div class="mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Duration</label>
                            <div class="d-block">
                                <label class="badge bg-warning rounded text-black fs-5 fw-semibold">104 Days</label>
                            </div>
                        </div>
                        <div class="mb-1">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Price</label>
                            <div class="d-block">
                                <label class="badge bg-success rounded fs-5 fw-semibold text-white">&#8377; 1,02,000</label>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-2 mb-1">
                            <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Products</label>
                            <div class="d-block mb-1">
                                <label class="cursor-pointer fs-5 fw-semibold text-black">02</label>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-0 mb-1">
                            <div data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Free Add-on</label>
                                <div class="d-block">
                                    <label class="cursor-pointer fs-5 fw-semibold text-black">03</label>
                                </div>
                                <div class="d-block">
                                    <a href="javascript:;" class="fs-8 fw-semibold text-info"><u>View Info</u></a>
                                </div>
                            </div>
                            <div class="dropdown-menu dropdown-menu-end w-25">
                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Free Add-on Products</div>
                                <hr class="mt-0 mb-2 border-dark">
                                <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">Topic Suggestions</div>
                                            <div class="text-info fw-semibold fs-8">03 Chapter</div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">Sample Research Papers</div>
                                            <div class="text-info fw-semibold fs-8">08 Pages</div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#127775;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">Research Consultation (Intro)</div>
                                            <div class="text-info fw-semibold fs-8">30 Minutes</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="cursor-pointer border border-secondary border-dashed rounded px-4 py-0 mb-1">
                            <div data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <label class="cursor-pointer text-dark mb-1 fs-6 fw-semibold">Paid Add-on</label>
                                <div class="d-block">
                                    <label class="cursor-pointer fs-5 fw-semibold text-black">02</label>
                                </div>
                                <div class="d-block">
                                    <a href="javascript:;" class="fs-8 fw-semibold text-info"><u>View Info</u></a>
                                </div>
                            </div>
                            <div class="dropdown-menu dropdown-menu-end w-25">
                                <div class="text-dark fs-6 text-center my-2 fw-semibold">Paid Add-on Products</div>
                                <hr class="mt-0 mb-2 border-dark">
                                <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#128261;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">Plagiarism Check</div>
                                            <div class="fw-semibold">
                                                <span class="text-danger fs-8">200 Pages</span>
                                                <span class="text-dark fs-7">( &#8377; 10,000 )</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-2 mb-2">
                                        <div class="text-black mb-1 fw-semibold fs-5 me-2">&#128261;</div>
                                        <div class="d-block">
                                            <div class="text-black fw-semibold text-justify fs-7">Thesis Writing</div>
                                            <div class="fw-semibold">
                                                <span class="text-danger fs-8">100 Pages</span>
                                                <span class="text-dark fs-7">( &#8377; 10,000 )</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="divider mb-4">
                <div class="text-black mb-0 fs-3 fw-semibold divider-text">Products Details</div>
            </div>
            <div class="row">
                <div class="col-lg-8 mb-1">
                    <div class="scroll-y border-gray-200i rounded max-h-250px px-3 py-3">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <div class="card h-100 rounded" style="background-color: rgb(240, 240, 240) !important;">
                                    <div class="card-body px-3 py-3">
                                        <div class="d-flex align-items-center h-35px mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                    <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Thesis Writing</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center h-35px mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product Category">
                                                    <i class="mdi mdi-diversify fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Writing Products</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                    <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="d-block mb-0">
                                                <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">90 Days</label>
                                                <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">03</span>
                                                    <span class="fs-8 text-info"><u>View Info</u></span>
                                                </label>
                                                <div class="dropdown-menu dropdown-menu-start w-350px">
                                                    <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                    <hr class="mt-0 mb-2 border-dark">
                                                    <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                        </div>
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">50 Pages of Grammar Check</label>
                                                        </div>
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">Reference Templates</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center h-35px mb-3">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                    <i class="mdi mdi-tools fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt">LaTeX, Scrivener</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-center mb-2">
                                            <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 75,000</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="card h-100 rounded" style="background-color: rgb(240, 240, 240) !important;">
                                    <div class="card-body px-3 py-3">
                                        <div class="d-flex align-items-center h-35px mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product">
                                                    <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Literature Review Writing</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center h-35px mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product Category">
                                                    <i class="mdi mdi-diversify fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt text-wrap">Writing Products</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center mb-1">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations & Facility">
                                                    <i class="mdi mdi-calendar-today-outline fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="d-block mb-0">
                                                <label class="cursor-pointer text-black fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Durations">14 Days</label>
                                                <label class="text-dark fs-6 fw-bold ms-1 me-1">|</label>
                                                <label class="cursor-pointer text-dark fs-6 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span class="text-black fs-7 fw-semibold me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Facility">02</span>
                                                    <span class="fs-8 text-info"><u>View Info</u></span>
                                                </label>
                                                <div class="dropdown-menu dropdown-menu-start w-350px">
                                                    <div class="text-dark fs-6 text-center my-2 fw-semibold">Facility</div>
                                                    <hr class="mt-0 mb-2 border-dark">
                                                    <div class="scroll-y max-h-150px px-4 py-1 mb-2">
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">50 Pages of Plagiarism Check</label>
                                                        </div>
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">Structured academic writing with citations</label>
                                                        </div>
                                                        <div class="d-flex align-items-start text-start border-bottom border-dark border-dashed border-top-0 border-start-0 border-end-0 pb-1 mb-1">
                                                            <label class="text-info fw-semibold fs-7 me-2">#</label>
                                                            <label class="text-black fw-semibold text-justify fs-7">References in the required citation style (e.g., APA, MLA, Chicago, etc.)</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center h-35px mb-3">
                                            <div class="me-2 cursor-pointer">
                                                <div class="bg-label-secondary rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Tools">
                                                    <i class="mdi mdi-tools fs-4"></i>
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold facility_txt">Google Scholar, Zotero, Google Scholar, Zotero, Google Scholar, Zotero</div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center justify-content-center mb-2">
                                            <div class="text-white fs-3 fw-bold rounded px-2 py-1" style="background: #833AB4; background: linear-gradient(90deg,rgba(131, 58, 180, 0.87) 40%, rgba(253, 29, 29, 0.81) 100%, rgba(252, 176, 69, 1) 100%);">&#8377; 18,000</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 mb-1">
                    <div class="card h-100 rounded">
                        <div class="scroll-y max-h-250px px-2 py-1">
                            <div class="card-body px-1 py-1">
                                <div class="row">
                                    <div class="col-lg-12 px-1">
                                        <div class="mb-1" id="pckg_cal_prod_1_az">
                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="pckg_cal_prod_1_hd">
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2 cursor-pointer">
                                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="pckg_cal_prod_1_fuc();" id="pckg_cal_prod_1_tlp">
                                                            <i class="mdi mdi-plus fs-4" id="pckg_cal_prod_1_plus_btton"></i>
                                                        </a>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Products">Writing Products</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-0">
                                                    <label class="fs-4 fw-semibold text-black">&#8377; 82,000</label>
                                                </div>
                                            </div>
                                            <div class="px-3 py-1 mb-0" id="pckg_cal_prod_1_tbox" style="display: none;">
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Products</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 75,000</label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Durations</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">90 Days</label>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pages">Pages</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="100 Pages">100 Pages</label>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 5,000</label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">Days</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="05 Days">05 Days</label>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 2,000</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-1" id="pckg_cal_prod_2_az">
                                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 cal_btt rounded px-1 py-1" id="pckg_cal_prod_2_hd">
                                                <div class="d-flex align-items-center">
                                                    <div class="me-2 cursor-pointer">
                                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Show" onclick="pckg_cal_prod_2_fuc();" id="pckg_cal_prod_2_tlp">
                                                            <i class="mdi mdi-plus fs-4" id="pckg_cal_prod_2_plus_btton"></i>
                                                        </a>
                                                    </div>
                                                    <div class="mb-0">
                                                        <div class="text-black fs-7 fw-semibold text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Literature Review Writing">Literature Review Writing</div>
                                                        <div class="d-block">
                                                            <label class="text-dark fs-8 fw-semibold text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Products">Writing Products</label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="mb-0">
                                                    <label class="fs-4 fw-semibold text-black">&#8377; 20,000</label>
                                                </div>
                                            </div>
                                            <div class="px-3 py-1 mb-0" id="pckg_cal_prod_2_tbox" style="display: none;">
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Products</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 18,000</label>
                                                    </div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap mb-1">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-7">Durations</label>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">14 Days</label>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-gray-400i border-dashed border-start-0 border-end-0 border-top-0 mb-2"></div>
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div class="text-black fw-semibold fs-7 mb-2"><u>Variants</u></div>
                                                </div>
                                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-8 text-truncate w-150px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Days">Days</label>
                                                        <div class="d-block">
                                                            <label class="text-dark fw-semibold fs-8 text-truncate w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="05 Days">05 Days</label>
                                                        </div>
                                                    </div>
                                                    <div class="mb-1">
                                                        <label class="text-black fw-semibold fs-6">&#8377; 2,000</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-5 mb-1">
                <div id="pckg_pymt_slot" style="display: none;">
                    <div class="divider divider-primary mb-4 mt-0">
                        <div class="divider-text fs-3 text-black fw-semibold">Payment Slot Details</div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="card rounded" style="background-color: #7fffd494;">
                                <div class="card-body px-3 pt-3 pb-2">
                                    <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 rounded px-1 py-1">
                                        <div class="d-flex align-items-center">
                                            <div class="me-2 cursor-pointer">
                                                <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product & Category">
                                                    <i class="mdi mdi-book-settings-outline fs-4"></i>
                                                </a>
                                            </div>
                                            <div class="mb-0">
                                                <div class="text-black fs-7 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                                <div class="d-block">
                                                    <div class="text-black fs-8 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Products">Writing Products</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <a href="javascript:;" class="btn btn-sm btn-primary rounded-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment_slot_package">Update Slot</a>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
                                        <div class="cursor-pointer border border-dashed border-gray-600i rounded px-2 py-1">
                                            <a href="javascript:;" class="mb-0">
                                                <i class="mdi mdi-cash-clock fs-3 text-dark"></i>
                                            </a>
                                            <label class="ms-1 text-black fs-6 fw-semibold">Total Slots</label>
                                            <label class="ms-2 text-black fs-6 fw-semibold">-</label>
                                            <label class="badge bg-secondary ms-2 text-white fs-7 fw-semibold">01</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-7 mb-1">
                <!--begin:: Default show without value selected -->
                <!-- <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <label class="fw-bold fs-5 me-13">Sub Total</label>
                        <div class="fw-bold fs-2">
                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                            <span class="fs-3">0</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                        <div class="d-flex align-items-center justify-content-between mb-2" id="coup_tbox">
                            <div class="me-13">
                                <label class="fw-bold fs-6">Coupon Code</label>
                                <input type="text" class="form-control w-150px px-2 py-1" placeholder="Enter Code" />
                            </div>
                            <a href="javascript:;" class="btn btn-sm btn-primary fs-8 mt-4" onclick="coupon_code_func();">Apply</a>
                        </div>
                        <div class="d-flex align-items-center justify-content-end gap-5 mb-2" id="coup_label_box" style="display: none !important;">
                            <div class="d-flex align-items-center fw-bold fs-5 me-13">
                                <div class="me-3">
                                    <label>Discount</label>
                                    <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 0% )</label><br>
                                </div>
                                <a href="javascript:;" class="btn btn-sm btn-outline-primary border-dashed fs-8 px-2 py-1" onclick="reset_coupon_func();" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset Coupon Code">
                                    <i class="mdi mdi-rotate-3d-variant text-dark fs-2"></i>
                                </a>
                            </div>
                            <div class="fw-bold fs-2">
                                <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                                <span class="fs-3">0</span>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <div class="fw-bold fs-5 me-12">
                            <div class="text-dark mb-1 fs-5 fw-semibold">
                                <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                                <div class="d-block fw-bold fs-8">[Exclusive]</div>
                            </div>
                        </div>
                        <div class="fw-bold fs-2">
                            <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                            <label class="fs-3">0</label>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                        <label class="fw-bold fs-3 me-13">Grand Total</label>
                        <div class="fw-bold fs-2">
                            <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                            <label class="fs-2">0</label>
                        </div>
                    </div> -->
                <!--end:: Default show without value selected -->

                <!--begin:: value selected after show -->
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold fs-5 me-13">Sub Total</label>
                    <div class="fw-bold fs-2">
                        <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                        <span class="fs-3">1,02,000</span>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-1 gap-5">
                    <div class="d-flex align-items-center justify-content-between mb-2" id="coup_tbox" style="display: none !important;">
                        <div class="me-13">
                            <label class="fw-bold fs-6">Coupon Code</label>
                            <input type="text" class="form-control w-150px px-2 py-1" placeholder="Enter Code" value="A7D9K2L3M0" />
                        </div>
                        <a href="javascript:;" class="btn btn-sm btn-primary fs-8 mt-4" onclick="coupon_code_func();">Apply</a>
                    </div>
                    <div class="d-flex align-items-center justify-content-end gap-5 mb-2" id="coup_label_box" style="display: inline;">
                        <div class="d-flex align-items-center fw-bold fs-5 me-13">
                            <div class="me-3">
                                <label>Discount</label>
                                <label class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Discount Percentage">( 10% )</label><br>
                                <label class="text-info fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Coupon Code">[ A7D9K2L3M0 ]</label>
                            </div>
                            <a href="javascript:;" class="btn btn-sm btn-outline-primary border-dashed fs-8 px-2 py-1" onclick="reset_coupon_func();" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset Coupon Code">
                                <i class="mdi mdi-rotate-3d-variant text-dark fs-2"></i>
                            </a>
                        </div>
                        <div class="fw-bold fs-2">
                            <span><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></span>
                            <span class="fs-3">10,200</span>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold text-black fs-4 me-9">Total Amount</label>
                    <div class="fw-bold text-black fs-2">
                        <span><i class="mdi mdi-currency-rupee fs-3 fw-bold text-black"></i></span>
                        <span class="fs-2">91,800</span>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <div class="fw-bold fs-5 me-12">
                        <div class="text-dark mb-1 fs-5 fw-semibold">
                            <label>GST <span class="text-danger fw-bold">( 18% )</span></label>
                            <div class="d-block fw-bold fs-8">[Exclusive]</div>
                        </div>
                    </div>
                    <div class="fw-bold fs-2">
                        <label><i class="mdi mdi-currency-rupee fs-4 fw-bold"></i></label>
                        <label class="fs-3">16,524</label>
                    </div>
                </div>
                <div class="row d-flex align-items-center justify-content-end mb-2 gap-5">
                    <div class="col-lg-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Additional Charges</label>
                        <input type="text" class="form-control fw-semibold py-1" placeholder="Enter Charges" value="0" />
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mb-2 gap-5">
                    <label class="fw-bold text-black fs-1 me-8">Grand Total</label>
                    <div class="fw-bold text-black fs-2">
                        <label><i class="mdi mdi-currency-rupee fs-2 fw-bold text-black"></i></label>
                        <label class="fs-1">1,08,324</label>
                    </div>
                </div>
            </div>
        </div>


        <div id="prod_pymt_slot">
            <div class="divider divider-primary mb-4 mt-0">
                <div class="divider-text fs-3 text-black fw-semibold">Payment Slot Details</div>
            </div>
            <div class="row">
                <div class="col-lg-4 mb-3">
                    <div class="card rounded" style="background-color: #7fffd494;">
                        <div class="card-body px-3 pt-3 pb-2">
                            <div class="d-flex align-items-center justify-content-between flex-wrap mb-1 rounded px-1 py-1">
                                <div class="d-flex align-items-center">
                                    <div class="me-2 cursor-pointer">
                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Product & Category">
                                            <i class="mdi mdi-book-settings-outline fs-4"></i>
                                        </a>
                                    </div>
                                    <div class="mb-0">
                                        <div class="text-black fs-7 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                        <div class="d-block">
                                            <div class="text-black fs-8 fw-semibold text-truncate w-xs-150px w-md-450px w-lg-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Products">Writing Products</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-0">
                                    <a href="javascript:;" class="btn btn-sm btn-primary rounded-3 fw-semibold" data-bs-toggle="modal" data-bs-target="#kt_modal_update_payment_slot">Update Slot</a>
                                </div>
                            </div>
                            <div class="d-flex align-items-center justify-content-center gap-2 mb-2">
                                <div class="cursor-pointer border border-dashed border-gray-600i rounded px-2 py-1">
                                    <a href="javascript:;" class="mb-0">
                                        <i class="mdi mdi-cash-clock fs-3 text-dark"></i>
                                    </a>
                                    <label class="ms-1 text-black fs-6 fw-semibold">Total Slots</label>
                                    <label class="ms-2 text-black fs-6 fw-semibold">-</label>
                                    <label class="badge bg-secondary ms-2 text-white fs-7 fw-semibold">01</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--end:: value selected after show -->
        <div class="d-flex justify-content-end align-items-center mt-13">
            <a href="/manage_proposal" class="btn btn-secondary me-2">Cancel</a>
            <a href="javascript:;" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_create_proposal">Update Proposal</a>
        </div>
    </div>
</div>




<!--begin::Modal - Update Proposal-->
<div class="modal fade" id="kt_modal_create_proposal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are You Sure Want To Update Proposal?
                <div class="d-block fw-bold text-black fs-5 py-2 mt-3">
                    <label>Priya (LD-0006/25)</label>
                    <span class="ms-2 me-2">-</span>
                    <label>[ PRO-003670/05/2025 ]</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <a href="/manage_proposal" class="btn btn-primary me-3">Yes</a>
                <a href="javascript:;" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Proposal-->

<!--begin::Modal - Add Product-->
<div class="modal fade" id="kt_modal_choose_me" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Add Product</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Writing Products</div>
                </div>
                <div class="divider mt-1 mb-1">
                    <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-gray-200i rounded">
                            <div class="scroll-y max-h-400px py-2 px-3">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_pg_chk" onclick="pckg_vart_pg_func();" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Pages</label>
                                            </div>
                                            <div id="pckg_cart_pg_chk_tbox" style="display: none;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>100 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 5,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>300 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>500 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                            </div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_dy_chk" onclick="pckg_vart_dy_func();" />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Days</label>
                                            </div>
                                            <div id="pckg_vart_dy_chk_tbox" style="display: none;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>1 Day</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>5 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 2,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk" disabled />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>10 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 3,500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Add Product</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Product-->

<!--begin::Modal - Update Product-->
<div class="modal fade" id="kt_modal_update_choose_me" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Product</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Writing Products</div>
                </div>
                <div class="divider mt-1 mb-1">
                    <div class="divider-text mb-0 text-black fw-semibold fs-3">Variants Details</div>
                </div>
                <div class="row">
                    <div class="col-lg-12 mb-1">
                        <div class="bg-gray-200i rounded">
                            <div class="scroll-y max-h-400px py-2 px-3">
                                <div class="row">
                                    <div class="col-lg-12 mb-1">
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_pg_chk_update" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Pages</label>
                                            </div>
                                            <div style="display: block;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update" checked />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>100 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 5,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>300 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 10,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_pages_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>500 Pages</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 15,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="border-bottom border-dashed border-start-0 border-end-0 border-top-0 mt-2 mb-2 border-gray-400i"></div>
                                            </div>
                                        </div>
                                        <div class="px-3 pt-1">
                                            <div class="form-check form-check-inline mb-1 mt-1">
                                                <input class="form-check-input" type="checkbox" id="pckg_vart_dy_chk_update" checked />
                                                <label class="text-black mb-1 fs-6 text-justify fw-semibold">Days</label>
                                            </div>
                                            <div style="display: block;">
                                                <div class="row mt-2">
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>1 Day</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update" checked />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>5 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 2,000</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-1">
                                                        <div class="form-check">
                                                            <input class="form-check-input me-0" type="radio" name="pckg_vart_days_chk_update" />
                                                            <label class="form-check-label text-black mb-1 fs-7 fw-semibold">
                                                                <span>10 Days</span>
                                                                <span class="ms-1 me-1">-</span>
                                                                <span class="badge bg-label-info rounded fw-semibold fs-7">&#8377; 3,500</span>
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Product</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Product-->

<!--begin::Modal - Update Payment slot-->
<div class="modal fade" id="kt_modal_update_payment_slot" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Payment Slot</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Product Category</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Writing Products</div>
                </div>
                <div class="form-repeater_pymt_slot_update mt-6">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                                            <select class="select3 form-select">
                                                <option value="">Select Payment Slot</option>
                                                <option value="1" selected>Slot 1</option>
                                                <option value="2">Slot 2</option>
                                                <option value="3">Slot 3</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Slot Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Slot Amount" value="1,08,324" />
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <select class="select3 form-select" multiple data-placeholder="Select Deliverables">
                                                <option value="1" selected>Technical Discussion</option>
                                                <option value="2" selected>Flow of the Work (Novelty and Dataset)</option>
                                                <option value="3">Chapter wise Thesis Drafting</option>
                                                <option value="4">Journal Publication Support</option>
                                                <option value="5">Appendices & References</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Slot Notes<span class="text-danger">*</span></label>
                                            <select class="select3 form-select" multiple data-placeholder="Select Slot Notes">
                                                <option value="1" selected>Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</option>
                                                <option value="2" selected>Each and every step will be acknowledged by you.</option>
                                                <option value="3">Every Section and Module of the Coding part will be clearly explained in the Google meet.</option>
                                                <option value="4">Entire Technical Knowledge will be given to you,until the client understands the concept.</option>
                                                <option value="5">As per the acknowledged description.We will be work on it.</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="2" placeholder="Enter Deliverables">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_update_del" id="pymt_slot_update_del" style="display: block !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button class="btn btn-sm btn-primary pymt_slot_update_add fs-8 px-2 py-1" data-repeater-create id="pymt_slot_update_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Balance Amount</div>
                        <div class="d-block">
                            <lable class="fs-4 fw-bold">&#8377; 0</lable>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Payment Slot</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Payment Slot-->

<!--begin::Modal - Update Package Payment slot-->
<div class="modal fade" id="kt_modal_update_payment_slot_package" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Package Payment Slot</h3>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Packages</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">Complete Thesis Writing</div>
                </div>
                <div class="row mb-4">
                    <label class="col-3 text-dark fs-6 fw-semibold">Products</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-8 text-black fs-6 fw-bold">
                        <label class="badge bg-warning text-black fw-semibold fs-7">02</label>
                    </div>
                </div>
                <div class="form-repeater_pymt_slot_pckg_update mt-6">
                    <div data-repeater-list="group-a_led_question">
                        <div data-repeater-item>
                            <div class="row mt-2">
                                <div class="col-lg-11">
                                    <div class="row">
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Payment Slot<span class="text-danger">*</span></label>
                                            <select class="select3 form-select">
                                                <option value="">Select Payment Slot</option>
                                                <option value="1" selected>Slot 1</option>
                                                <option value="2">Slot 2</option>
                                                <option value="3">Slot 3</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-6 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Slot Amount<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" placeholder="Enter Slot Amount" value="1,08,324" />
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Deliverables<span class="text-danger">*</span></label>
                                            <!-- <div class="form-floating form-floating-outline">
                                                <input id="slot_deliverables" class="form-control h-auto" placeholder="Select Deliverables">
                                            </div> -->
                                            <select class="select3 form-select" multiple data-placeholder="Select Deliverables">
                                                <option value="1" selected>Technical Discussion</option>
                                                <option value="2" selected>Flow of the Work (Novelty and Dataset)</option>
                                                <option value="3">Chapter wise Thesis Drafting</option>
                                                <option value="4">Journal Publication Support</option>
                                                <option value="5">Appendices & References</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Slot Notes<span class="text-danger">*</span></label>
                                            <!-- <div class="form-floating form-floating-outline">
                                                <input id="slot_notes" class="form-control h-auto" placeholder="Select Notes">
                                            </div> -->
                                            <select class="select3 form-select" multiple data-placeholder="Select Slot Notes">
                                                <option value="1" selected>Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.Once you acknowledge the flow only, we will move on otherwise,updated flow will be shared.</option>
                                                <option value="2" selected>Each and every step will be acknowledged by you.</option>
                                                <option value="3">Every Section and Module of the Coding part will be clearly explained in the Google meet.</option>
                                                <option value="4">Entire Technical Knowledge will be given to you,until the client understands the concept.</option>
                                                <option value="5">As per the acknowledged description.We will be work on it.</option>
                                            </select>
                                        </div>
                                        <div class="col-lg-12 mb-1">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="2" placeholder="Enter Deliverables">SUPPORT SECTION : Approval getting, Knowledge transfer, whatsapp group creation, and further doubts clearing support as well.</textarea>
                                        </div>
                                    </div>
                                    <div class="divider divider-primary mb-2 mt-3">
                                        <div class="divider-text fs-6 text-dark fw-semibold">&#9986;</div>
                                    </div>
                                </div>
                                <div class="col-lg-1 mb-1">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 px-2 py-1 pymt_slot_pckg_update_del" id="pymt_slot_pckg_update_del" style="display: block !important;">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-between mb-4 mt-4">
                    <button class="btn btn-sm btn-primary pymt_slot_pckg_update_add fs-8 px-2 py-1" data-repeater-create id="pymt_slot_pckg_update_add">
                        <i class="mdi mdi-plus me-1"></i> Add More
                    </button>
                    <div class="badge bg-danger fw-semibold fs-5 mb-2">
                        <div class="mb-1">Total Amount</div>
                        <div class="d-block">
                            <lable class="fs-4 fw-bold">&#8377; 0</lable>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Package Payment Slot</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Update Package Payment Slot-->




<script>
    $('.pymt_slot_create_add').on('click', e => {
        var bt = parseFloat($('.form-repeater_pymt_slot_create').length);
        let $clone = $('.form-repeater_pymt_slot_create').first().clone().hide();
        $clone.insertBefore('.form-repeater_pymt_slot_create:first').slideDown();
        if (bt == 1) {
            $('.pymt_slot_create_del').attr('style', 'display: block !important');
        } else {
            $('.pymt_slot_create_del').attr('style', 'display: block !important');
        }
    });

    $(document).on('click', '.form-repeater_pymt_slot_create .pymt_slot_create_del', e => {
        var bt = parseFloat($('.pymt_slot_create_del').length);
        // alert(bt);
        $(e.target).closest('.form-repeater_pymt_slot_create').slideUp(400, function() {
            $(this).remove()
        });
        if (bt == 2) {
            $('.pymt_slot_create_del').attr('style', 'display: none !important');
        } else {}
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 35;
        const elements = document.querySelectorAll('.facility_txt');

        elements.forEach(el => {
            const fullText = el.textContent.trim();

            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.setAttribute('data-bs-placement', 'bottom');
                el.textContent = fullText.slice(0, maxChars) + '...';

                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
</script>
<script>
    function cal_prod_1_fuc() {
        var cal_prod_1_tbox = document.getElementById("cal_prod_1_tbox");
        var tooltipElement = document.getElementById("cal_prod_1_tlp");

        if (cal_prod_1_tbox.style.display == "none") {
            document.getElementById("cal_prod_1_tbox").style.display = "block";
            document.getElementById("cal_prod_1_plus_btton").classList.remove("mdi-plus");
            document.getElementById("cal_prod_1_plus_btton").classList.add("mdi-minus");
            document.getElementById("cal_prod_1_hd").style.backgroundColor = "#ebebeb";
            document.getElementById("cal_prod_1_hd").classList.remove("rounded");
            document.getElementById("cal_prod_1_hd").classList.add("rounded-top");
            document.getElementById("cal_prod_1_az").classList.add("border", "border-gray-400i", "rounded");

            tooltipElement.setAttribute("title", "Hide");
            tooltipElement.setAttribute("data-bs-original-title", "Hide");

            var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
            tooltipInstance.dispose();
            new bootstrap.Tooltip(tooltipElement);
        } else {
            document.getElementById("cal_prod_1_tbox").style.display = "none";
            document.getElementById("cal_prod_1_plus_btton").classList.remove("mdi-minus");
            document.getElementById("cal_prod_1_plus_btton").classList.add("mdi-plus");
            document.getElementById("cal_prod_1_hd").style.backgroundColor = "#ffffff";
            document.getElementById("cal_prod_1_hd").classList.remove("rounded-top");
            document.getElementById("cal_prod_1_hd").classList.add("rounded");
            document.getElementById("cal_prod_1_az").classList.remove("border", "border-gray-400i", "rounded");

            tooltipElement.setAttribute("title", "Show");
            tooltipElement.setAttribute("data-bs-original-title", "Show");

            var tooltipInstance = bootstrap.Tooltip.getInstance(tooltipElement);
            tooltipInstance.dispose();
            new bootstrap.Tooltip(tooltipElement);
        }
    }
</script>
<script>
    function pckg_cal_prod_1_fuc() {
        var pckg_cal_prod_1_tbox = document.getElementById("pckg_cal_prod_1_tbox");
        var pckg_tooltipElement = document.getElementById("pckg_cal_prod_1_tlp");

        if (pckg_cal_prod_1_tbox.style.display == "none") {
            document.getElementById("pckg_cal_prod_1_tbox").style.display = "block";
            document.getElementById("pckg_cal_prod_1_plus_btton").classList.remove("mdi-plus");
            document.getElementById("pckg_cal_prod_1_plus_btton").classList.add("mdi-minus");
            document.getElementById("pckg_cal_prod_1_hd").style.backgroundColor = "#ebebeb";
            document.getElementById("pckg_cal_prod_1_hd").classList.remove("rounded");
            document.getElementById("pckg_cal_prod_1_hd").classList.add("rounded-top");
            document.getElementById("pckg_cal_prod_1_az").classList.add("border", "border-gray-400i", "rounded");

            pckg_tooltipElement.setAttribute("title", "Hide");
            pckg_tooltipElement.setAttribute("data-bs-original-title", "Hide");

            var pckg_tooltipInstance = bootstrap.Tooltip.getInstance(pckg_tooltipElement);
            pckg_tooltipInstance.dispose();
            new bootstrap.Tooltip(pckg_tooltipElement);
        } else {
            document.getElementById("pckg_cal_prod_1_tbox").style.display = "none";
            document.getElementById("pckg_cal_prod_1_plus_btton").classList.remove("mdi-minus");
            document.getElementById("pckg_cal_prod_1_plus_btton").classList.add("mdi-plus");
            document.getElementById("pckg_cal_prod_1_hd").style.backgroundColor = "#ffffff";
            document.getElementById("pckg_cal_prod_1_hd").classList.remove("rounded-top");
            document.getElementById("pckg_cal_prod_1_hd").classList.add("rounded");
            document.getElementById("pckg_cal_prod_1_az").classList.remove("border", "border-gray-400i", "rounded");

            pckg_tooltipElement.setAttribute("title", "Show");
            pckg_tooltipElement.setAttribute("data-bs-original-title", "Show");

            var pckg_tooltipInstance = bootstrap.Tooltip.getInstance(pckg_tooltipElement);
            pckg_tooltipInstance.dispose();
            new bootstrap.Tooltip(pckg_tooltipElement);
        }
    }

    function pckg_cal_prod_2_fuc() {
        var pckg_cal_prod_2_tbox = document.getElementById("pckg_cal_prod_2_tbox");
        var pckg_tooltipElement_2 = document.getElementById("pckg_cal_prod_2_tlp");

        if (pckg_cal_prod_2_tbox.style.display == "none") {
            document.getElementById("pckg_cal_prod_2_tbox").style.display = "block";
            document.getElementById("pckg_cal_prod_2_plus_btton").classList.remove("mdi-plus");
            document.getElementById("pckg_cal_prod_2_plus_btton").classList.add("mdi-minus");
            document.getElementById("pckg_cal_prod_2_hd").style.backgroundColor = "#ebebeb";
            document.getElementById("pckg_cal_prod_2_hd").classList.remove("rounded");
            document.getElementById("pckg_cal_prod_2_hd").classList.add("rounded-top");
            document.getElementById("pckg_cal_prod_2_az").classList.add("border", "border-gray-400i", "rounded");

            pckg_tooltipElement_2.setAttribute("title", "Hide");
            pckg_tooltipElement_2.setAttribute("data-bs-original-title", "Hide");

            var pckg_tooltipInstance_2 = bootstrap.Tooltip.getInstance(pckg_tooltipElement_2);
            pckg_tooltipInstance_2.dispose();
            new bootstrap.Tooltip(pckg_tooltipElement_2);
        } else {
            document.getElementById("pckg_cal_prod_2_tbox").style.display = "none";
            document.getElementById("pckg_cal_prod_2_plus_btton").classList.remove("mdi-minus");
            document.getElementById("pckg_cal_prod_2_plus_btton").classList.add("mdi-plus");
            document.getElementById("pckg_cal_prod_2_hd").style.backgroundColor = "#ffffff";
            document.getElementById("pckg_cal_prod_2_hd").classList.remove("rounded-top");
            document.getElementById("pckg_cal_prod_2_hd").classList.add("rounded");
            document.getElementById("pckg_cal_prod_2_az").classList.remove("border", "border-gray-400i", "rounded");

            pckg_tooltipElement_2.setAttribute("title", "Show");
            pckg_tooltipElement_2.setAttribute("data-bs-original-title", "Show");

            var pckg_tooltipInstance_2 = bootstrap.Tooltip.getInstance(pckg_tooltipElement_2);
            pckg_tooltipInstance_2.dispose();
            new bootstrap.Tooltip(pckg_tooltipElement_2);
        }
    }
</script>

<script>
    function pckg_vart_pg_func() {
        var pckg_vart_pg_chk = document.getElementById("pckg_vart_pg_chk");
        var pckg_cart_pg_chk_tbox = document.getElementById("pckg_cart_pg_chk_tbox");
        const pckg_vart_pages_chk = document.getElementsByName("pckg_vart_pages_chk");
        if (pckg_vart_pg_chk.checked) {
            pckg_cart_pg_chk_tbox.style.display = "block";
            for (let i = 0; i < pckg_vart_pages_chk.length; i++) {
                pckg_vart_pages_chk[i].disabled = false;
            }
        } else {
            pckg_cart_pg_chk_tbox.style.display = "none";
            for (let i = 0; i < pckg_vart_pages_chk.length; i++) {
                pckg_vart_pages_chk[i].disabled = true;
                pckg_vart_pages_chk[i].checked = false;
            }
        }
    }

    function pckg_vart_dy_func() {
        var pckg_vart_dy_chk = document.getElementById("pckg_vart_dy_chk");
        var pckg_vart_dy_chk_tbox = document.getElementById("pckg_vart_dy_chk_tbox");
        const pckg_vart_days_chk = document.getElementsByName("pckg_vart_days_chk");
        if (pckg_vart_dy_chk.checked) {
            pckg_vart_dy_chk_tbox.style.display = "block";
            for (let i = 0; i < pckg_vart_days_chk.length; i++) {
                pckg_vart_days_chk[i].disabled = false;
            }
        } else {
            pckg_vart_dy_chk_tbox.style.display = "none";
            for (let i = 0; i < pckg_vart_days_chk.length; i++) {
                pckg_vart_days_chk[i].disabled = true;
                pckg_vart_days_chk[i].checked = false;
            }
        }
    }
</script>
<script>
    function service_add_func(val) {
        var serv_product_chk_tbox = document.getElementById("serv_product_chk_tbox");
        var serv_package_chk_tbox = document.getElementById("serv_package_chk_tbox");
        var prod_pymt_slot = document.getElementById("prod_pymt_slot");
        var pckg_pymt_slot = document.getElementById("pckg_pymt_slot");

        if (val == 'package') {
            serv_product_chk_tbox.style.display = "none";
            serv_package_chk_tbox.style.display = "block";
            prod_pymt_slot.style.display = "none";
            pckg_pymt_slot.style.display = "block";
        } else {
            serv_product_chk_tbox.style.display = "block";
            serv_package_chk_tbox.style.display = "none";
            prod_pymt_slot.style.display = "block";
            pckg_pymt_slot.style.display = "none";
        }
    }

    function product_add_on_func() {
        var prod_add_on = document.getElementById("prod_add_on");
        var view_product_add_on = document.getElementById("view_product_add_on");

        if (prod_add_on.checked) {
            view_product_add_on.style.display = "block";
        } else {
            view_product_add_on.style.display = "none";
        }
    }


    function coupon_code_func() {
        document.getElementById("coup_tbox").style.setProperty("display", "none", "important");
        document.getElementById("coup_label_box").style.setProperty("display", "flex", "important");
    }

    function reset_coupon_func() {
        document.getElementById("coup_label_box").style.setProperty("display", "none", "important");
        document.getElementById("coup_tbox").style.setProperty("display", "flex", "important");
    }
</script>
@endsection