@extends('layouts/layoutMaster')

@section('title', 'Manage Proposal')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js'
])
@endsection

@section('page-script')
@endsection
@section('content')
<style>
    .proposal_table thead th,
    .proposal_table tbody td {
        padding: 8px !important;
    }

    .indv_proposal thead th,
    .indv_proposal tbody td {
        padding: 8px !important;
        border: 1px solid rgb(180, 180, 180) !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
     .blink-icon {
        animation: blinkScale 1.5s infinite; /* Apply both blink and scale animations */
    }
    
    @keyframes blinkScale {
        0% {
            opacity: 1;  /* Fully visible */
            transform: scale(1); /* Original size */
        }
        50% {
            opacity: 0;  /* Invisible */
            transform: scale(1.2); /* Slightly larger */
        }
        100% {
            opacity: 1;  /* Fully visible */
            transform: scale(1); /* Back to original size */
        }
    }
</style>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id ?? 16;
        $user_data=$helper->get_staff_data($user_id);
        $hot_lead_days = $helper->general_setting_data()->hot_lead_days ?? 7;
    @endphp
    @php
        $module_name = 'Lead Management';
        $menu_name = 'Manage Proposal';
    @endphp
    
<!-- Proposal List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Proposal</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 pt-0">
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <!-- <div class="d-flex justify-content-end align-items-center flex-wrap">
                        <a href="{{url('/manage_proposal/proposal_add')}}" class="btn btn-sm fw-bold btn-primary me-2 mb-2">
                            <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Proposal
                        </a>
                    </div> -->
                    <div class="row">
                        <div class="d-flex justify-content-between align-items-center">
                                <div class="mb-4">
                                    @php $perpage_count = $perpage ? $perpage : 25; @endphp
                                    <div>
                                        <span>Show</span>
                                        <br>
                                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                            @php
                                            $options = [10, 25, 100, 500]; // Define available options
                                            @endphp
                                            @php foreach ($options as $option): @endphp
                                            <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                                @php echo $option; @endphp
                                            </option>
                                            @php endforeach; @endphp
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="mb-2">
                                    <form id="filter_form" method="POST" action="/manage_proposal">
                                        @csrf
                                        <div class="d-flex align-items-center gap-2">
                                            <div class="mb-1">
                                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                                <input type="hidden" name="filter_on" value="0">
                                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />      
                                                <input
                                                type="text"
                                                class="form-control"
                                                id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                                placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                                                />
                                            </div>
                                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1 " onclick="search_filter_func()">Search</button>
                                            <a href="{{ url('/manage_proposal') }}" type="button"
                                                class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span class="mdi mdi-refresh fs-6"></span>
                                            </a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        <div class="col-lg-12">
                            <div class="table-responsive">
                                <table class="table align-middle table-row-dashed gy-1 gs-2 proposal_table">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-100px">Proposal No</th>
                                            <th class="min-w-80px">Proposal Date</th>
                                            <th class="min-w-100px">Lead</th>
                                            <th class="min-w-50px">Payment</th>
                                            <th class="min-w-80px">Amount</th>
                                            <th class="min-w-50px text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @if(isset($proposal_list))
                                        @foreach($proposal_list as $i => $list)
                                        @php
                                            $paidProgress = $list->total_amount > 0 ? ($list->total_paidAmount / $list->total_amount)*100 : 0 ;
                                            $paidProgress = $paidProgress >100 ?  '100' :$paidProgress;
                                             $paidProgress = round($paidProgress, 1);
                                        @endphp
                                        <tr id="rev_prop_hd_{{$i}}">
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    @if(count($list->proposal_data) >0)
                                                    <div class="me-2 cursor-pointer">
                                                        <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-1 py-1" onclick="rev_prop_fuc({{$i}});">
                                                            <i class="mdi mdi-plus fs-4" id="rev_prop_{{$i}}_plus_btton"></i>
                                                        </a>
                                                    </div>
                                                    @endif
                                                    <div class="mb-0" >
                                                        <span class=" d-flex gap-1 align-items-center">
                                                        <label class="fs-7">{{$list->proposal_id}}
                                                            
                                                        </label> 
                                                        @if($list->old_customer_check !=1)
                                                           @if($list->send_status == 1)
                                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Send">
                                                                    <img src="{{asset('assets/phdizone_images/proposal/successfully_send.gif')}}" class="image-input-wrapper w-35px"  />
                                                                    </span>
                                                            @elseif($list->send_status == 2 )
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Read">
                                                                    <img src="{{asset('assets/phdizone_images/proposal/email_read.gif')}}" class="image-input-wrapper w-30px ms-1" />
                                                               </span>
                                                            @elseif($list->send_status == 0)
                                                                <!-- <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Send">-->
                                                                <!--    <img src="{{asset('assets/phdizone_images/proposal/email_not_send.gif')}}" class="w-45px " />-->
                                                                <!--</span>-->
                                                            @endif
                                                        @endif
                                                        
                                                         @if($list->old_customer_check ==1)
                                                             @if($list->temp_send_link)
                                                                <span>
                                                                <a href="{{$list->temp_send_link}}" target="_blank" class="dropdown-item">
                                                                            <span><i class="mdi mdi-link fs-5 text-primary fw-bold "></i></span>
                                                                        </a></span>
                                                                   
                                                             @endif
                                                         @endif
                                                        </span>
                                                        
                                                        <div class="d-block">
                                                            @if($list->proposal_status == 1)
                                                                <span class="badge bg-success text-white fw-semibold fs-8">Proposal Accepted</span>
                                                            @elseif($list->proposal_status == 2)
                                                              @if($list->rejected_by == 0)
                                                                    <span class="badge bg-danger text-white fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Rejected By Customer">Proposal Rejected <span class="mdi mdi-account-tie fs-8" ></span> </span>
                                                                @else
                                                                    <span class="badge bg-danger text-white fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Rejected By Company">Proposal Rejected <span class="mdi mdi-office-building fs-8" ></span> </span>
                                                                @endif
                                                            @elseif($list->proposal_status == 3)
                                                                <span class="badge bg-warning text-black fw-semibold fs-8">Invoice Created</span>
                                                            @endif
                                                            
                                                            @if($list->verify_status == 0)
                                                        <span data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom"
                                                            title="Proposal Not Verified">
                                                            <svg class="w-20px h-20px"
                                                                enable-background="new 0 0 500 500"
                                                                viewBox="0 0 500 500"
                                                                id="hand-draw-white-cross-mark-on-red-circle">
                                                                <rect id="Layer_1" fill="#fff0f0"
                                                                    display="none"></rect>
                                                                <g id="Layer_2">
                                                                    <circle cx="250" cy="250"
                                                                        r="200" fill="#f32f45"></circle>
                                                                    <path fill="#f32f45" d="M345.6,381.2c-15,0-30.5-5.8-46-17.1c-2-1.5-24.9-18.1-54.5-45.7c-18.2,21.3-28.6,35.5-28.8,35.7l-0.3,0.3
                                                                    l-0.3,0.3c-4.8,6-21.9,25.5-42.8,25.5c-8,0-15.5-2.8-21.5-8.2c-26.9-23.6-4.6-68.6,0.1-77.4l0.2-0.3c8.3-14.9,17.9-30,28.6-45.1
                                                                    c-16.4-20.4-30.5-40.9-42-61.1c-4.4-8-25-48.1,0.4-69.6c6.9-5.9,15.2-9,24-9c21.5,0,37.4,18.5,40.4,22.3
                                                                    c0.2,0.3,14.6,18.2,38.6,43.2c51.1-54,97.3-87.9,99.4-89.4c16.9-12.5,33.9-18.8,50.3-18.8c25.1,0,39.2,15,40.7,16.7l0.4,0.4
                                                                    c8.9,10.6,12.6,23.1,10.6,36.3c-4.5,30.1-37.4,52.9-44.5,57.5c-27.1,18.4-54.6,40.6-82,66c13.8,11,27.6,21.2,41.1,30.3
                                                                    c5.9,3.4,32.9,20.3,38.9,46.9c3.2,14,0.1,28.1-8.9,40.7l-0.3,0.5l-0.4,0.4C385.4,364.5,371.3,381.2,345.6,381.2
                                                                    C345.6,381.2,345.6,381.2,345.6,381.2z"></path>
                                                                    <path fill="#fff"
                                                                        d="M417.1,96.9c0,0-22.8-25.6-64.3,5c0,0-55,40-110.7,102.2c-34-33.7-54.7-59.7-54.7-59.7s-19.5-24.3-35.8-10.5
                                                                    c-14.1,11.9,4.1,44.5,4.1,44.5c14.4,25.4,31.9,49.1,49.9,70.2c-13.1,17.5-25.5,36.2-36.5,55.6c0,0-20.8,38.6-4.6,52.9
                                                                    c14,12.3,35.5-14.7,35.5-14.7s16-21.9,43.6-52.8c36.9,36.3,67.6,58.4,67.6,58.4c38.8,28.6,59.9,2.2,59.9,2.2
                                                                    c23.2-32.7-24.2-59-24.2-59c-21.8-14.6-42.2-30.5-60.6-46.2c28.6-28,62.9-57.9,101-83.8C387.4,161.1,441.7,126.1,417.1,96.9z">
                                                                    </path>
                                                                </g>
                                                            </svg>
                                                        </span>
                                                        @else
                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                                            title="Proposal Verified"><i
                                                                                                class="mdi mdi-check-decagram fs-4 text-success"></i></span>
                                                        
                                                        @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Estimate Date">{{ $list->estimate_date ? date($common_date_format, strtotime($list->estimate_date)) :'-' }}</label>
                                                <div class="d-block">
                                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Validity Date">{{ $list->due_date ? date($common_date_format, strtotime($list->due_date)) :'-' }}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7">{{$list->lead_name}}</label>
                                                <div class="d-block">
                                                    <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">{{$list->lead_email_id}}</label>
                                                </div>
                                            </td>
                                            <td class="">
                                               <div class="cursor-pointer progress border border-gray-400i rounded bg-label-primary w-145px h-15px mt-1" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Payment Progress : {{$paidProgress}}%">
                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8" role="progressbar" style="width: {{$paidProgress}}%" aria-valuenow="{{$paidProgress}}" aria-valuemin="0" aria-valuemax="100">{{$paidProgress}}%</div>
                                                </div>
                                                <div class="d-flex justify-content-end">
                                                <label class="badge bg-success text-black text-right fw-semibold fs-8 my-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Paid Amount">{{$list->currency_symbol}} {{ number_format($list->total_paidAmount)  }}</label>
                                                </div>
                                            </td>
                                            <td align="right">
                                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">{{$list->currency_symbol}} {{number_format($list->grant_total_amount,2)}}</label>
                                            </td>
                                             @php
                                                $encryptedValue = $helper->encrypt_decrypt($list->sno,'encrypt',);
                                                $print_url = url('/manage_proposal/print_proposal/' . $encryptedValue,);
                                                $edit_url = url('/manage_proposal/proposal_edit/' . $encryptedValue,);
                                                $revised_url = url('/manage_proposal/proposal_revise/' . $encryptedValue,);
                                                $view_url = url('/manage_proposal/proposal_view/' . $encryptedValue,);
                                                $create_invoice_url = url('/manage_proposal/create_invoice/' . $encryptedValue,);
                                                 $verify_url = url('/manage_proposal/reject_proposal/' . $encryptedValue,);
                                                 $isPageUpdated = $helper->isProposalPageUpdated($list->sno);
                                            @endphp
                                            <td class="text-center">
                                                <span class="text-end">
                                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                    </a>
                                                    <!--@if($user_id == 0)-->
                                                    <!--    @if($isPageUpdated == 1)-->
                                                    <!--    <a href="javascript:;" class="btn btn-icon " data-bs-toggle="modal" data-bs-target="#kt_modal_update_pagecount" onclick="update_page_func('{{$list->sno}}','{{$list->lead_email_id}}','{{$list->lead_mobile}}','{{$list->registered_date}}','{{$list->lead_name}}','{{$list->grant_total_amount}}','{{$list->estimate_date}}','{{$list->due_date}}','{{$list->proposal_id}}','{{$list->currency_symbol}}','{{$list->service_title}}')">-->
                                                    <!--        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Page Count"><i class="mdi mdi-file-alert fs-3 text-danger blink-icon"></i></span>-->
                                                    <!--    </a>-->
                                                    <!--    @endif-->
                                                    <!--@endif-->
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                          @if($list->proposal_status == 0 || $list->proposal_status == 2)
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_proposal" onclick="send_proposal_func('{{$list->sno}}','{{$list->lead_email_id}}','{{$list->lead_mobile}}','{{$list->registered_date}}','{{$list->lead_name}}','{{$list->grant_total_amount}}','{{$list->estimate_date}}','{{$list->due_date}}','{{$list->proposal_id}}','{{$list->currency_symbol}}')">
                                                                <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Proposal</span>
                                                            </a>
                                                             @endif
                                                        @if($list->proposal_status != 0 && $list->proposal_status != 2 )
                                                            @if(auth()->user()->hasPermission($module_name, 'Create Invoice', $menu_name))
                                                             <a href="{{$create_invoice_url}}" target="_blank" class="dropdown-item">
                                                                <span><i class="mdi mdi-invoice-list-outline fs-4 text-black me-1"></i>Create Invoice</span>
                                                            </a>
                                                            @endif
                                                        @endif
                                                         <a href="{{$print_url}}" target="_blank" class="dropdown-item">
                                                            <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                        </a>
                                                        <a href="{{$view_url}}" target="_blank" class="dropdown-item">
                                                            <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span>
                                                        </a>
                                                        @if($list->verify_status == 0)
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_verify_proposal" onclick="verify_proposal_func('{{$list->sno}}','{{$list->lead_email_id}}','{{$list->lead_mobile}}','{{$list->registered_date}}','{{$list->lead_name}}','{{$list->grant_total_amount}}','{{$list->estimate_date}}','{{$list->due_date}}','{{$list->proposal_id}}','{{$list->currency_symbol}}')">
                                                                <span><i class="mdi mdi-check-decagram fs-4 text-black me-1"></i> Verify Proposal</span>
                                                            </a>
                                                        @endif
                                                         <!--<a href="{{$edit_url}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Edit</a>-->
                                                          @if($list->proposal_status == 0 || $list->proposal_status == 2 )
                                                            <a href="{{$revised_url}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Revised</a>
                                                          @endif
                                                           @if($list->proposal_status == 0 || $list->proposal_status == 1  )
                                                            <a href="{{$verify_url}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-close-circle fs-4 text-black me-1"></i> Reject Proposal</span></a>
                                                          @endif
                                                    </div>
                                                </span>
                                            </td>
                                        </tr>
                                         <tr id="rev_prop_{{$i}}_tbox" style="display:none;background-color: #efffdd52;">
                                            <td colspan="6">
                                                <div class="table-responsive">
                                                    <table class="table align-top gy-1 gs-2 indv_proposal">
                                                        <thead>
                                                            <tr class="text-start align-top fw-bold fs-6 gs-0">
                                                                <th class="min-w-100px fw-semibold text-black">Proposal No</th>
                                                                <th class="min-w-100px fw-semibold text-black">Proposal Date</th>
                                                                <th class="min-w-100px fw-semibold text-black text-center">Sub Total</th>
                                                                <th class="min-w-100px fw-semibold text-black text-center">Discount</th>
                                                                <th class="min-w-100px fw-semibold text-black text-center">Total Amount</th>
                                                                <th class="min-w-100px fw-semibold text-black text-center">GST</th>
                                                                <th class="min-w-100px fw-semibold text-black text-center">Grand Total</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                                            @if(isset($list->proposal_data))
                                                            @foreach($list->proposal_data as $inx => $list_propos)
                                                            <tr style="background-color:{{$list_propos->proposal_status==1 ?' #50cd897a;' : '' }}">
                                                                <td>
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->proposal_id}}</label>
                                                                    @if($list_propos->proposal_status==1)
                                                                    <div class="d-block">
                                                                        <span class="badge bg-success text-white fw-semibold fs-8">Proposal Accepted</span>
                                                                    </div>
                                                                    @elseif($list_propos->proposal_status==2)
                                                                        <div class="d-block">
                                                                            <span class="badge bg-danger text-white fw-semibold fs-8">Proposal Rejected</span>
                                                                        </div>
                                                                    @else
                                                                    @endif
                                                                </td>
                                                                <td>
                                                                    <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">{{ $list_propos->estimate_date ? date($common_date_format, strtotime($list_propos->estimate_date)) :'-' }}</label>
                                                                    <div class="d-block">
                                                                        <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Validity Date">{{ $list_propos->due_date ? date($common_date_format, strtotime($list_propos->due_date)) :'-' }}</label>
                                                                    </div>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->currency_symbol}} {{$list_propos->sub_total}}</label>
                                                                </td>
                                                                <td align="center">
                                                                    @if($list_propos->discount_id > 0)
                                                                    @if($list_propos->discount_type == 1)
                                                                    <label class="badge bg-danger text-white rounded fw-semibold fs-8">{{$list_propos->discount_value}}%</label>
                                                                     @else
                                                                     <label class="badge bg-danger text-white rounded fw-semibold fs-8">{{$list_propos->currency_symbol}} {{$list_propos->discount_value}}</label>
                                                                    @endif
                                                                    <label class="text-black fw-semibold fs-7 ms-1 me-1">-</label>
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->currency_symbol}} {{number_format($list_propos->discount_amount)}}</label>
                                                                    <div class="d-block">
                                                                        @if($list_propos->coupon_code)
                                                                        <label class="text-info fw-semibold fs-8">[ {{$list_propos->coupon_code }} ]</label>
                                                                        @else
                                                                        -
                                                                        @endif
                                                                    </div>
                                                                    @else
                                                                    -
                                                                    @endif
                                                                </td>
                                                                <td align="right">
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->currency_symbol}} {{number_format($list_propos->total_amount)}}</label>
                                                                </td>
                                                                <td align="center">
                                                                    <label class="badge bg-success text-black rounded fw-semibold fs-8">{{$list_propos->gst_perc}}%</label>
                                                                    <label class="text-black fw-semibold fs-7 ms-1 me-1">-</label>
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->currency_symbol}} {{number_format($list_propos->gst_amount,2)}}</label>
                                                                </td>
                                                                <td align="right">
                                                                    <label class="text-black fw-semibold fs-7">{{$list_propos->currency_symbol}} {{number_format($list_propos->grant_total_amount,2)}}</label>
                                                                </td>
                                                            </tr>
                                                            @endforeach
                                                           @endif
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                         
                                        <!--<tr>
                                            <td>
                                                <label class="fs-7">PRO-003669/03/2025</label>
                                                <div class="d-block">
                                                    <span class="badge bg-danger text-white fw-semibold">Proposal Rejected</span>
                                                    <a href="javascript:;" data-bs-toggle="tooltip" data-bs-placement="right" title="The cost is too high for my budget">
                                                        <i class="mdi mdi-information text-dark"></i>
                                                    </a>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">27-Mar-2025</label>
                                                <div class="d-block">
                                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">31-Mar-2025</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7">Dharshini</label>
                                                <div class="d-block">
                                                    <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">dharshini@gmail.com</label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <label class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">01</label>
                                            </td>
                                            <td align="right">
                                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 69,000</label>
                                            </td>
                                            <td class="text-center">
                                                <span class="text-end">
                                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_send_proposal">
                                                            <span><i class="mdi mdi-invoice-text-send-outline fs-4 text-black me-1"></i>Send Proposal</span>
                                                        </a>
                                                        <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="dropdown-item">
                                                            <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                        </a>
                                                        <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="dropdown-item">
                                                            <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span></a>
                                                        <a href="{{url('/manage_proposal/proposal_edit')}}" target="_blank" class="dropdown-item"> <span><i class="mdi mdi-square-edit-outline fs-4 text-black me-1"></i></span>Edit</a>
                                                    </div>
                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div>
                                                    <label class="fs-7">PRO-003668/02/2025</label>
                                                    <div class="d-block">
                                                        <span class="badge bg-warning text-black fw-bold">Invoice Generated</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal  Date">22-Feb-2024</label>
                                                <div class="d-block">
                                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Validity Date">30-Feb-2024</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="fs-7">Praveen</label>
                                                <div class="d-block">
                                                    <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Email ID">praveen@gmail.com</label>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <label class="badge bg-info text-white fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Count">01</label>
                                            </td>
                                            <td align="right">
                                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Proposal Amount">&#8377; 80,254</label>
                                            </td>
                                            <td class="text-center">
                                                <span class="text-end">
                                                    <a class="btn btn-icon btn-sm" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a href="{{url('/manage_proposal/proposal_print')}}" target="_blank" class="dropdown-item">
                                                            <span><i class="mdi mdi-printer-pos-outline fs-4 text-black me-1"></i>Print</span>
                                                        </a>
                                                        <a href="{{url('/manage_proposal/proposal_view')}}" target="_blank" class="dropdown-item">
                                                            <span> <i class="mdi mdi-eye-outline fs-4 text-black me-1"></i>View</span>
                                                        </a>
                                                    </div>
                                                </span>
                                            </td>
                                        </tr> -->
                                    </tbody>
                                </table>
                            </div>
                             <div class="mt-4">
                                {{ $proposal_list->appends(request()->except(['page', '_token']))->links() }}
    
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <!--begin::Modal - update Page-->
    <div class="modal fade" id="kt_modal_update_pagecount" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Page Count</h3>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold" id="page_lead_register_date">07-Mar-2025</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold" id="page_lead_name">Priya</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Proposal No</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold" id="page_proposal_no">PRO-003669/03/2025</label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Start / End Date</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <div class="col-7 text-black fs-6 fw-bold">
                            <label class="text-black fs-6 fw-bold" id="page_proposal_start"><?php echo date("d-M-Y"); ?></label>
                            <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                            <label class="badge bg-danger text-white fs-7 fw-semibold" id="page_proposal_end"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold"><span class="currency_symbol"></span> <span id="page_proposal_total">0</span></label>
                    </div>
                    <div class="row mb-3">
                        <label class="col-4 text-dark fs-6 fw-semibold">Service Title</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold"><span id="page_service_title">0</span></label>
                    </div>
                    <input type="hidden" name="page_proposal_id" id="page_proposal_id">
                    <div class="mb-3" id="fetchProposalPageData"></div>
                    <div class="d-flex justify-content-center align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="updatePageBtn" class="btn btn-primary">Update</button>
                        <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - update Page-->

<!--begin::Modal - Verify Proposal-->
<div class="modal fade" id="kt_modal_verify_proposal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Verify Proposal</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="verify_lead_register_date">07-Mar-2025</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="verify_lead_name">Priya</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Proposal No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="verify_proposal_no">PRO-003669/03/2025</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Start / End Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-7 text-black fs-6 fw-bold">
                        <label class="text-black fs-6 fw-bold" id="verify_proposal_start"><?php echo date("d-M-Y"); ?></label>
                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                        <label class="badge bg-danger text-white fs-7 fw-semibold" id="verify_proposal_end"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold"><span class="currency_symbol"></span> <span id="verify_proposal_total">0</span></label>
                </div>
                <input type="hidden" name="verify_proposal_id" id="verify_proposal_id">

                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="VerifyProposalBtn" class="btn btn-primary">Verify Proposal</button>
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Verify Proposal-->
<!--begin::Modal - Send Proposal-->
<div class="modal fade" id="kt_modal_send_proposal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Send Proposal</h3>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Registered Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_lead_register_date">07-Mar-2025</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_lead_name">Priya</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Proposal No</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold" id="send_proposal_no">PRO-003669/03/2025</label>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Start / End Date</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <div class="col-7 text-black fs-6 fw-bold">
                        <label class="text-black fs-6 fw-bold" id="send_proposal_start"><?php echo date("d-M-Y"); ?></label>
                        <label class="text-black fs-6 fw-bold ms-1 me-1">/</label>
                        <label class="badge bg-danger text-white fs-7 fw-semibold" id="send_proposal_end"><?php echo date("d-M-Y", strtotime("+7 days")); ?></label>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-4 text-dark fs-6 fw-semibold">Total Amount</label>
                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                    <label class="col-7 text-black fs-6 fw-bold"><span class="currency_symbol"></span> <span id="send_proposal_total">0</span></label>
                </div>
                <input type="hidden" name="send_proposal_id" id="send_proposal_id">
                <input type="hidden" name="send_proposal_whatsapp" id="send_proposal_whatsapp" value="0">
                <input type="hidden" name="send_proposal_email" id="send_proposal_email" value="0">
                <input type="hidden" name="send_proposal_sms" id="send_proposal_sms" value="0">
                <!-- <div class="row mb-3">
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Additional Charges</label>
                        <input type="text" class="form-control" placeholder="Enter Additional Charges" value="0" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="badge bg-label-secondary text-center d-block py-1">
                            <label class="text-black mb-3 fs-4 fw-semibold">Grand Total</label>
                            <div class="d-block">
                                <div class="text-black fs-3 fw-bold">&#8377; 1,08,324</div>
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="d-flex  gap-2 mt-4 mb-1">
                     <label class="text-black mb-1 fs-6 fw-semibold" id="old_cus_check_text">Skip Communication</label>
                    <input class="form-check-input" type="checkbox" id="old_cus_check" name="old_cus_check" value="1" checked onclick="old_cus_check_func();">
                </div>
                <div class="communication_check">
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-1">
                        <div class="text-black fs-6 fw-semibold mb-1">Choose Communication</div>
                        <div class="badge bg-label-primary rounded-pill mb-1">
                            <i class="mdi mdi-link-variant mdi-14px me-1"></i>
                            <span class="align-middle fw-semibold">Proposal Attached</span>
                        </div>
                    </div>
                </div>
                <div class="row communication_check">
                    <div class="col-lg-12 mb-3">
                        <div class="d-flex align-items-center flex-wrap gap-2">
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_whats_app" onclick="send_proposal_whatsapp_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/whatsapp.png')}}" alt="whatsapp" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Whats App</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_email" onclick="send_proposal_email_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/email.png')}}" alt="email" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Email</div>
                                    </div>
                                </div>
                            </a>
                            <a href="#" class="btn px-0 py-0 mb-1 act_bx" id="sd_prpl_message" onclick="send_proposal_message_func();" style="display:none;">
                                <div class="d-flex align-items-center flex-column rounded border border-gray-600 border-solid w-100px h-95px px-2 pt-3 pb-0">
                                    <img src="{{asset('assets/phdizone_images/social_media/message.png')}}" alt="message" class="w-45px h-45px" />
                                    <div class="d-block">
                                        <div class="text-dark fw-semibold fs-8 social_md_txt">Message</div>
                                    </div>
                                </div>
                            </a>
                        </div>
                         <div class="text-danger" id="communication_err"></div>
                    </div>
                    <!--<div class="col-lg-12 mb-3">-->
                    <!--    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>-->
                    <!--    <textarea class="form-control" rows="3" placeholder="Enter Description" id="description" name="description">Thank you for your Service Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of </textarea>-->
                    <!--</div>-->
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="sendMessageBtn" class="btn btn-primary">Send Proposal</button>
                    <span class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Send Proposal-->

<!--begin::Modal - Delete Proposal-->
<div class="modal fade" id="kt_modal_delete_quotation" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                delete Proposal ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label>Priya Dharshini</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes, delete!</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Proposal-->


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.9.3/min/dropzone.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
     
        .tags-inline.tagify__dropdown {
            z-index: 9999 !important; /* Ensure it is higher than the modal's z-index */
        }
    </style>
    
     <script>
      function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#filter_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#filter_form').submit();
        }
      }
    </script>

    <script>
        // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
    </script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        const maxChars = 13;
        const elements = document.querySelectorAll('.social_md_txt');

        elements.forEach(el => {
            const fullText = el.textContent.trim();

            if (fullText.length > maxChars) {
                el.setAttribute('title', fullText);
                el.setAttribute('data-bs-placement', 'bottom');
                el.textContent = fullText.slice(0, maxChars) + '...';

                bootstrap.Tooltip.getOrCreateInstance(el);
            }
        });
    });
</script>
<script>
    function rev_prop_fuc(val) {
        var rev_prop_tbox = document.getElementById(`rev_prop_${val}_tbox`);
        var plus_button = document.getElementById(`rev_prop_${val}_plus_btton`);
        var header = document.getElementById(`rev_prop_hd_${val}`);

        if (rev_prop_tbox.style.display === "none" || rev_prop_tbox.style.display === "") {
            rev_prop_tbox.style.display = "table-row";
            plus_button.classList.remove("mdi-plus");
            plus_button.classList.add("mdi-minus");
            header.style.backgroundColor = "#f9f3c5db";
        } else {
            rev_prop_tbox.style.display = "none";
            plus_button.classList.remove("mdi-minus");
            plus_button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    }

</script>
<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>
<script>
    function send_proposal_whatsapp_func() {
       const box = document.getElementById("sd_prpl_whats_app");
        const input = document.getElementById("send_proposal_whatsapp");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_email_func() {
        const box = document.getElementById("sd_prpl_email");
        const input = document.getElementById("send_proposal_email");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

    function send_proposal_message_func() {
        const box = document.getElementById("sd_prpl_message");
        const input = document.getElementById("send_proposal_sms");

        box.classList.toggle("act_bx_selected");

        if (box.classList.contains("act_bx_selected")) {
            input.value = 1;
        } else {
            input.value = 0;
        }
    }

</script>

<script>
    function whatsapp_func1() {
        var whatsapp = document.getElementById("whatsapp");
        var whatsapp_on = document.getElementById("whatsapp_on");

        if (whatsapp_on.click) {
            whatsapp.style.display = "block";
            whatsapp_on.style.display = "none";

        } else {
            whatsapp.style.display = "none";
            whatsapp_on.style.display = "block";
        }
    }
</script>

<script>
    function facebook_func() {
        var facebook = document.getElementById("facebook");
        var facebook_on = document.getElementById("facebook_on");

        if (facebook.click) {
            facebook_on.style.display = "block";
            facebook.style.display = "none";

        } else {
            facebook_on.style.display = "none";
            facebook.style.display = "block";
        }
    }
</script>

<script>
    function facebook_func1() {
        var facebook = document.getElementById("facebook");
        var facebook_on = document.getElementById("facebook_on");

        if (facebook_on.click) {
            facebook.style.display = "block";
            facebook_on.style.display = "none";

        } else {
            facebook.style.display = "none";
            facebook_on.style.display = "block";
        }
    }
</script>

<script>
    function email_func() {
        var email = document.getElementById("email");
        var email_on = document.getElementById("email_on");

        if (email.click) {
            email_on.style.display = "block";
            email.style.display = "none";

        } else {
            email_on.style.display = "none";
            email.style.display = "block";
        }
    }
</script>

<script>
    function email_func1() {
        var email = document.getElementById("email");
        var email_on = document.getElementById("email_on");

        if (email_on.click) {
            email.style.display = "block";
            email_on.style.display = "none";

        } else {
            email.style.display = "none";
            email_on.style.display = "block";
        }
    }
</script>

<script>
    function insta_func() {
        var insta = document.getElementById("insta");
        var insta_on = document.getElementById("insta_on");

        if (insta.click) {
            insta_on.style.display = "block";
            insta.style.display = "none";

        } else {
            insta_on.style.display = "none";
            insta.style.display = "block";
        }
    }
</script>

<script>
    function insta_func1() {
        var insta = document.getElementById("insta");
        var insta_on = document.getElementById("insta_on");

        if (insta_on.click) {
            insta.style.display = "block";
            insta_on.style.display = "none";

        } else {
            insta.style.display = "none";
            insta_on.style.display = "block";
        }
    }
</script>
<script>
    function pinin_func() {
        var pinin = document.getElementById("pinin");
        var pinin_on = document.getElementById("pinin_on");

        if (pinin.click) {
            pinin_on.style.display = "block";
            pinin.style.display = "none";

        } else {
            pinin_on.style.display = "none";
            pinin.style.display = "block";
        }
    }
</script>

<script>
    function pinin_func1() {
        var pinin = document.getElementById("pinin");
        var pinin_on = document.getElementById("pinin_on");

        if (pinin_on.click) {
            pinin.style.display = "block";
            pinin_on.style.display = "none";

        } else {
            pinin.style.display = "none";
            pinin_on.style.display = "block";
        }
    }
</script>
<script>
    function linked_func() {
        var linked = document.getElementById("linked");
        var linked_on = document.getElementById("linked_on");

        if (linked.click) {
            linked_on.style.display = "block";
            linked.style.display = "none";

        } else {
            linked_on.style.display = "none";
            linked.style.display = "block";
        }
    }
</script>

<script>
    function linked_func1() {
        var linked = document.getElementById("linked");
        var linked_on = document.getElementById("linked_on");

        if (linked_on.click) {
            linked.style.display = "block";
            linked_on.style.display = "none";

        } else {
            linked.style.display = "none";
            linked_on.style.display = "block";
        }
    }
</script>
<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    $(".list_page_1").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    function send_proposal_func(id,email,mobile,register_date,name,total,start_date,end_date,proposal_id,currency_symbol){
        $('#send_lead_name').text(name);
        $('#send_lead_register_date').text(register_date ? formatDate(register_date) :'-');
        $('#send_proposal_start').text(formatDate(start_date));
        $('#send_proposal_end').text(formatDate(end_date));
        $('#send_proposal_no').text(proposal_id);
          $('.currency_symbol').text(currency_symbol);
        $('#send_proposal_total').text(formatCurrency(total));
        $('#send_proposal_id').val(id);
        var message = "Thank you for your Service Assign, always a pleasure to work with you! We have generated a new Proposal in the amount of ₹" + formatCurrency(total);
            $('#description').val(message);
        if (mobile && mobile.trim() !== "") {
            $('#sd_prpl_message').removeClass('d-none');
            $('#sd_prpl_whats_app').removeClass('d-none');
        } else {
            $('#sd_prpl_message').addClass('d-none');
            $('#sd_prpl_whats_app').addClass('d-none');
        }
    
        // Email check (show/hide Email button)
        if (email && email.trim() !== "") {
            $('#sd_prpl_email').removeClass('d-none');
        } else {
            $('#sd_prpl_email').addClass('d-none');
        }
    }
    
    function verify_proposal_func(id,email,mobile,register_date,name,total,start_date,end_date,proposal_id,currency_symbol){
        $('#verify_lead_name').text(name);
        $('#verify_lead_register_date').text(register_date ? formatDate(register_date) :'-');
        $('#verify_proposal_start').text(formatDate(start_date));
        $('#verify_proposal_end').text(formatDate(end_date));
        $('#verify_proposal_no').text(proposal_id);
        $('.currency_symbol').text(currency_symbol);
        $('#verify_proposal_total').text(formatCurrency(total));
        $('#verify_proposal_id').val(id);
    }
</script>

<script>
     $('#sendMessageBtn').on('click', function(e) {
        var err =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const proposal_id = $('#send_proposal_id').val();
        let sms = $('#send_proposal_sms').val();
        let email = $('#send_proposal_email').val();
        let whatsapp = $('#send_proposal_whatsapp').val();
        // const description = $('#description').val();

        var old_cus_check = document.getElementById("old_cus_check");
        var old_customer_check =  0;
        if (old_cus_check.checked) {
            sms =0;
            email =0;
            whatsapp = 0;
            old_customer_check=1;
        }else{
             if(sms ==1 || email ==1 || whatsapp == 1){
                $('#communication_err').text('');
            }else{
                $('#communication_err').text('Please Select Any One Communication.!');
                err++;
            }
        }
   

        if(err == 0){
              $('#sendMessageBtn').prop('disabled', true);
               $('#sendMessageBtn').text('Sending...');
            $.ajax({
                url: '/proposal_message',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    proposal_id: proposal_id,
                    sms: sms,
                    email: email,
                    whatsapp: whatsapp,
                    old_customer_check: old_customer_check,
                    // description: description,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); // Reload the page to update the UI
                        console.log(response)
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#sendMessageBtn').prop('disabled', true);
                          resetButton();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#sendMessageBtn').prop('disabled', true);
                      resetButton();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send Proposal');
                $('#sendMessageBtn .spinner-border').addClass('d-none');
            }
    });
    
       $('#VerifyProposalBtn').on('click', function(e) {
        var err1 =0;
        e.preventDefault();
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        const proposal_id = $('#verify_proposal_id').val();
      
   

        if(err1 == 0){
              $('#VerifyProposalBtn').prop('disabled', true);
               $('#VerifyProposalBtn').text('Verifying...');
            $.ajax({
                url: '/proposal_verify',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }, // Replace with your backend URL
                method: 'POST',
                data: JSON.stringify({
                    proposal_id: proposal_id,
                }),
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload(); 
                    } else {
                        toastr.error(response.message || 'Failed to send the message.');
                         $('#VerifyProposalBtn').prop('disabled', true);
                          resetButtonVerify();
                    }
                },
                error: function(xhr, status, error) {
                    const errorMsg = xhr.responseJSON?.message || 'Failed to send the message.';
                    toastr.error(errorMsg);
                     $('#VerifyProposalBtn').prop('disabled', true);
                      resetButtonVerify();
                }
            });
        }

         function resetButton() {
                $('#sendMessageBtn').prop('disabled', false);
                $('#sendMessageBtn').text('Send Proposal');
                $('#sendMessageBtn .spinner-border').addClass('d-none');
            }
             function resetButtonVerify() {
                $('#VerifyProposalBtn').prop('disabled', false);
                $('#VerifyProposalBtn').text('Verify Proposal');
                $('#VerifyProposalBtn .spinner-border').addClass('d-none');
            }
    });

    function formatCurrency(amt) {
        var roundedAmt = parseFloat(amt);
        var isWhole = Number.isInteger(roundedAmt);
    
        return roundedAmt.toLocaleString('en-IN', {
            minimumFractionDigits: isWhole ? 0 : 2,
            maximumFractionDigits: isWhole ? 0 : 2
        });
    }
      function formatDate(dateString) {
            let date = new Date(dateString); 
            let day = String(date.getDate()).padStart(2, '0'); 
            let monthIndex = date.getMonth();
            let year = date.getFullYear(); 

            const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            let month = months[monthIndex]; 

            return `${day}-${month}-${year}`;
        }
</script>
<script>
old_cus_check_func()
   function old_cus_check_func(){
        var old_cus_check = document.getElementById("old_cus_check");
     
        if (old_cus_check.checked) {
           $('.communication_check').hide();
            
        } else{
            $('.communication_check').show();
        }
    }
</script>
 <script>
   function update_page_func(id, email, mobile, register_date, name, total, start_date, end_date, proposal_id, currency_symbol,service){
    // Set modal data
    $('#page_lead_name').text(name);
    $('#page_lead_register_date').text(register_date ? formatDate(register_date) : '-');
    $('#page_proposal_start').text(formatDate(start_date));
    $('#page_proposal_end').text(formatDate(end_date));
    $('#page_proposal_no').text(proposal_id);
    $('#page_service_title').text(service);
    $('.currency_symbol').text(currency_symbol);
    $('#page_proposal_total').text(formatCurrency(total));
    $('#page_proposal_id').val(id);
    $('#fetchProposalPageData').empty();
    // Fetch proposal details via AJAX
    $.ajax({
        url: '/fetch-proposal-details',
        method: 'GET',
        data: { proposal_id: id },
        success: function(response) {
            $('#fetchProposalPageData').empty();
            var products = response.products;
            if (products && products.length > 0) {
                let tableHtml = `${response.package_name ? `<div class="mb-2"><span class="text-dark fs-6 fw-semibold">Package Name:</span> <span class="text-black fs-6 fw-bold">${response.package_name}</span></div>` : '' }<table class="table align-center table-row-dashed table-striped table-hover gy-0 gs-1">`;
                tableHtml += '<thead><tr class="text-start align-center fw-bold fs-6 gs-0 bg-primary"><th>Product Name</th><th>Variant Names</th><th>Total Pages</th></tr></thead><tbody>';
                
                products.forEach(product => {
                    tableHtml += `<tr data-sno="${product.sno}" data-category-id="${product.product_category_id}">`;
                    tableHtml += `<td>${product.product_name}</td>`;
                    tableHtml += `<td>${product.variant_names.join(', ')}</td>`;
                    tableHtml += `<td>
                                    ${product.product_category_id == 2 
                                        ? `<input type="number" value="0" class="form-control total_pages_input border-none bg-transparent" data-sno="${product.sno}" readonly> ` 
                                        : `<input type="number" value="${product.total_pages}" class="form-control total_pages_input" data-sno="${product.sno}" oninput="validatePageCount(this)" >`}
                                    <span class="error-message text-danger d-none">Page count must be greater than 0.</span>
                                  </td>`;
                    tableHtml += '</tr>';
                });
                
                tableHtml += '</tbody></table>';
                $('#fetchProposalPageData').html(tableHtml);
            }
        },
        error: function() {
            console.error("Error fetching proposal details.");
        }
    });
}

function validatePageCount(input) {
    var categoryId = $(input).closest('tr').data('category-id'); // Get the correct category_id from the row data
    var value = $(input).val();

    if (categoryId != 2 && value <= 0) {
        $(input).next('.error-message').removeClass('d-none');
    } else {
        $(input).next('.error-message').addClass('d-none');
    }
}

$('#updatePageBtn').on('click', function() {
    var updatedPages = [];
    var hasError = false;

    // Remove any previous error messages
    $('.error-message').remove();

    // Loop through each total_pages input
    $('.total_pages_input').each(function() {
        var sno = $(this).data('sno');
        var totalPages = $(this).val();
        var productCategoryId = $(this).closest('tr').data('category-id'); // Get the product category ID from the row

        // If product_category_id is not 2 and total_pages is 0, show an error
        if (productCategoryId != 2 && totalPages == 0) {
            hasError = true;
            // Show error message below the input
            $(this).after('<span class="text-danger error-message">Total pages must be greater than 0 for this product.</span>');
        } else {
            // Add valid input data to the updatedPages array
            updatedPages.push({ sno: sno, total_pages: totalPages });
        }
    });

    // If there's an error, stop the process
    if (hasError) {
        return false;  // Prevent form submission
    }
    var proposal_id= $('#page_proposal_id').val();
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    
    // Proceed with AJAX request to update the pages
    $.ajax({
        url: '/update-proposal-pages',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': csrfToken
        },
        method: 'POST',
        data: JSON.stringify({ updatedPages: updatedPages ,proposal_id:proposal_id}),
        success: function(response) {
            $('#kt_modal_update_pagecount').modal('hide');
            location.reload();
        },
        error: function(response) {
            console.error('Error updating pages: ' + response.responseJSON.error);
        }
    });
});

</script>
@endsection