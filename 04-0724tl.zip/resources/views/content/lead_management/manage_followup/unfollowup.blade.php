@extends('layouts/layoutMaster')

@section('title', 'Manage FollowUp')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite(['resources/assets/js/forms-file-upload.js'])
@endsection
@section('content')

    <!-- Lead List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Manage Followup</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Sales</a>
                    </li>
                </ol>
            </nav>
        </div>
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            $user_id = auth()->user()->user_id;
            $user_data = $helper->get_staff_data($user_id);
        @endphp
        <div class="card-body px-4 py-0">
            <div class="row mt-2">
                <div class="col-xl-12">
                    <!--<div class="nav-align-top mb-2">-->
                    <!--    <ul class="nav nav-pills" role="tablist">-->
                    <!--        <li class="nav-item me-2">-->
                    <!--            <a href="{{ url('/sales/manage_lead_follow_up') }}" type="button"-->
                    <!--                class="nav-link text-capitalize " style="background: #fcff66;">Today Followup-->
                    <!--                @if (isset($todayFollowupCount))-->
                    <!--                    <span-->
                    <!--                        class="badge bg-success ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d', $todayFollowupCount) }}</span>-->
                    <!--                @endif-->
                    <!--            </a>-->
                    <!--        </li>-->
                    <!--        <li class="nav-item me-2">-->
                    <!--            <a href="{{ url('/sales/manage_lead_follow_up/closed_follow') }}" type="button"-->
                    <!--                class="nav-link text-capitalize bg-success ">-->
                    <!--                Closed Followup @if (isset($closedFollowupCount))-->
                    <!--                    <span-->
                    <!--                        class="badge bg-info ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d', $closedFollowupCount) }}</span>-->
                    <!--                @endif-->
                    <!--            </a>-->
                    <!--        </li>-->
                    <!--        <li class="nav-item me-2">-->
                    <!--            <a href="{{ url('/sales/manage_lead_follow_up/reschedule_follow') }}" type="button"-->
                    <!--                class="nav-link text-capitalize " style="background: lightpink;">-->
                    <!--                Reschedule Followup @if (isset($rescheduleFollowupCount))-->
                    <!--                    <span-->
                    <!--                        class="badge bg-secondary ms-2 badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d', $rescheduleFollowupCount) }}</span>-->
                    <!--                @endif-->
                    <!--            </a>-->
                    <!--        </li>-->
                    <!--        <li class="nav-item me-2">-->
                    <!--            <a href="{{ url('/sales/manage_lead_follow_up/un_follow') }}" type="button"-->
                    <!--                class="nav-link text-capitalize " style="background: #f46666;">-->
                    <!--                UnFollowup @if (isset($unFollowupCount))-->
                    <!--                    <span-->
                    <!--                        class="badge bg-warning ms-2 text-black badge-pill animate__animated animate__pulse animate__infinite">{{ sprintf('%02d', $unFollowupCount) }}</span>-->
                    <!--                @endif-->
                    <!--            </a>-->
                    <!--        </li>-->
                    <!--    </ul>-->
                    <!--</div>-->
                    
                    <div class="nav-align-top mb-2">
            <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                    <div class="scroll-container" id="scrollContainer">
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2 "  aria-selected="false" style="background-color: #FCFF66 !important;" id="tdy_flwup">
                                    <span id="tdy_flwup_txt">Today Followup</span>
                                    @if(isset($todayFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$todayFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/closed_follow')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2" style="background-color: #d0dfd7 !important;"   aria-selected="true" id="cld_flwup">
                                    <span class="ms-2" id="cld_flwup_txt">Closed Followup</span>
                                    @if(isset($closedFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$closedFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/reschedule_follow')}}"  type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2" style="background-color: #FFB6C1 !important;" aria-selected="true" id="rescd_flwup">
                                    <span class="ms-2" id="rescd_flwup_txt">Reschedule Followup</span>
                                     @if(isset($rescheduleFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$rescheduleFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/un_follow')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2 active" style="background-color: #ff7a7a !important;"  aria-selected="true" id="un_flwup">
                                    <span class="ms-2" id="un_flwup_txt">Un Followup</span>
                                    @if(isset($unFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$unFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        
                </div>
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="d-flex justify-content-end align-items-center flex-wrap">

                            {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2"
                            id="lead_filter" title="Filter">
                            <i class="mdi mdi-filter-outline text-center"></i>
                        </a> --}}
                        </div>

                        
                        
                 <div class="d-flex justify-content-between align-items-center">
                      <div class="mb-4">
                          @php $perpage_count = $perpage ? $perpage : 10; @endphp
                          <div>
                              <span>Show</span>
                              <br>
                              <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                  <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                  </option>
                                @php endforeach; @endphp
                              </select>
                          </div>
                      </div>
                      <div class="mb-4">
                        <form id="search_form" method="POST" action="/manage_followup/un_follow">
                          @csrf
                          <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                              <input type="hidden" name="page" value="{{ request('page', 1) }}">
                              <input type="hidden" name="filter_on" value="1">
                              <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                              <input
                                type="text"
                                class="form-control"
                                id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                              />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                          </div>
                        </form>
                      </div>
                    </div>
                    
                        <div class="row">
                            <div class="col-lg-12">
                                <table
                                    class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-100px">Lead</th>
                                            <th class="min-w-100px">Date</th>
                                            <th class="min-w-100px">Time</th>
                                            <th class="min-w-100px">Followed By</th>
                                            <th class="min-w-100px">Followup Status</th>
                                            <th class="min-w-100px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @if (count($lead_flw_list) > 0)
                                            @foreach ($lead_flw_list as $list)
                                                <tr>
                                                    <td>
                                                        <div class="mb-0 align-items-center">
                                                            <label>
                                                                <span class="fs-7 me-2">{{ $list->lead_name }}</span>
                                                                <span>
                                                                    @if ($list->lead_gender == 1)
                                                                        <i class="mdi mdi-face-man text-info"></i>
                                                                    @elseif($list->lead_gender == 2)
                                                                        <i class="mdi mdi-face-woman text-danger"></i>
                                                                    @else
                                                                        {{-- <i class="mdi mdi-face-woman text-danger"></i> --}}
                                                                    @endif

                                                                </span>
                                                            </label>
                                                            <div class="d-block text-primary fs-8" title="Email ID">
                                                                {{ $list->lead_email_id }}</div>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="d-block badge rounded bg-success text-black fs-7 ">
                                                            {{ date('d-M-Y', strtotime($list->appointment_date)) }}</div>

                                                    </td>
                                                    <td>
                                                        <div class="d-block badge rounded bg-danger text-white fs-7">
                                                            {{ date('h:i A', strtotime($list->appointment_time)) }}</div>

                                                    </td>
                                                    <td>{{ $list->staff_name }}</td>
                                                    <td>
                                                        <a href="javascript:;"
                                                            class="badge bg-secondary text-white fw-bold fs-8"
                                                            id="" data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">Not Followed yet</a>
                                                    </td>
                                                   <td>
                                              <button type="button"
                                                  class="btn btn-danger btn-sm fw-semibold rounded-pill px-3 blink-btn"
                                                  data-bs-toggle="modal"
                                                  data-bs-target="#kt_modal_follow_up_lead_schedule"
                                                  onclick="openResheduleModal('{{ $list->ld_name_id }}','{{ $list->lead_name }}','{{ $list->lead_mobile }}')">
 
                                                  <i class="bx bx-calendar me-1"></i> Closed Follow-up
                                              </button>
                                          </td>
 

                                                </tr>
                                            @endforeach
                                        @endif

                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                {{ $lead_flw_list->appends(request()->except(['page', '_token']))->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

 
<style>
  .blink-btn {
    animation: pulseRed 1.5s infinite;
}
 
@keyframes pulseRed {
    0% { box-shadow: 0 0 0 0 rgba(220,53,69, 0.7); }
    70% { box-shadow: 0 0 0 8px rgba(220,53,69, 0); }
    100% { box-shadow: 0 0 0 0 rgba(220,53,69, 0); }
}
</style>

        <!--begin::Modal - Followup Lead Schedule-->
        <!--<div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"-->
        <!--    data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">-->
            <!--begin::Modal dialog-->
        <!--    <div class="modal-dialog modal-lg">-->
                <!--begin::Modal content-->
        <!--        <div class="modal-content rounded">-->
                    <!--begin::Modal header-->
        <!--            <div class="modal-header justify-content-end border-0 pb-0">-->
                        <!--begin::Close-->
        <!--                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">-->
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
        <!--                    <span class="svg-icon svg-icon-1">-->
        <!--                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"-->
        <!--                            xmlns="http://www.w3.org/2000/svg">-->
        <!--                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"-->
        <!--                                transform="rotate(-45 6 17.3137)" fill="currentColor" />-->
        <!--                            <rect x="7.41422" y="6" width="16" height="2" rx="1"-->
        <!--                                transform="rotate(45 7.41422 6)" fill="currentColor" />-->
        <!--                        </svg>-->
        <!--                    </span>-->
                            <!--end::Svg Icon-->
        <!--                </div>-->
                        <!--end::Close-->
        <!--            </div>-->
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
        <!--            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">-->
                        <!--begin::Heading-->
        <!--                <div class="mb-4 text-center">-->
        <!--                    <h3 class="text-center mb-4 text-black">Followup Report</h3>-->
        <!--                </div>-->
        <!--                <form id="updateResheduleForm" autocomplete="off">-->
        <!--                    <div class="row mt-4">-->
        <!--                        <div class="col-lg-6 mb-3">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Name</label>-->
        <!--                            <div>-->
        <!--                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_name_reop">-</label>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-6 mb-3">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold">Lead Mobile</label>-->
        <!--                            <div>-->
        <!--                                <label class="text-dark mb-1 fs-5 fw-semibold" id="lead_phone_reop">-</label>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-6 mb-3">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold">Followup Date</label>-->
        <!--                            <div class="input-group input-group-merge">-->
        <!--                                <span class="input-group-text bg-gray-200"><i-->
        <!--                                        class="mdi mdi-calendar-month-outline fs-4"></i></span>-->
        <!--                                <input type="text" id="app_date" placeholder="Select Date"-->
        <!--                                    class="form-control" disabled />-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-6 mb-3">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold">Followup Time</label>-->
        <!--                            <input type="text" class="form-control " placeholder="HH:MM" id="app_time"-->
        <!--                                disabled />-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-12 mb-3 d-flex justify-content-end">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold">Reshcedule Count</label> <span-->
        <!--                                class="badge bg-danger" id="followup_reschedule_rep_count"></span>-->
        <!--                        </div>-->

        <!--                        <div class="col-lg-12 mb-3">-->
        <!--                            <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span-->
        <!--                                    class="text-danger">*</span></label>-->
        <!--                            <div class="form-check form-check-inline" id="prog_yes" name="prog_yes"-->
        <!--                                onclick="yes_func();">-->
        <!--                                <input class="form-check-input" type="radio" name="progressed" id="progressed"-->
        <!--                                    value="1" />-->
        <!--                                <label class="form-check-label" for="inlineRadio1">Yes</label>-->
        <!--                            </div>-->
        <!--                            <div class="form-check form-check-inline" id="prog_no" name="prog_no"-->
        <!--                                onclick="no_func();">-->
        <!--                                <input class="form-check-input" type="radio" name="progressed" id="progressed"-->
        <!--                                    value="2" />-->
        <!--                                <label class="form-check-label" for="inlineRadio2">No</label>-->
        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-12 mb-3" id="message" name="message"-->
        <!--                            style="display: none !important;">-->
        <!--                            <div class="row">-->
        <!--                                <div class="col-lg-6 mb-3">-->
        <!--                                    <label class="text-dark mb-1 fs-6 fw-semibold d-block">Conversation-->
        <!--                                        Message<span class="text-danger">*</span></label>-->
        <!--                                    <div class="form-check form-check-inline">-->
        <!--                                        <input class="form-check-input" type="checkbox" name="app_score"-->
        <!--                                            onclick="onlyOne(this)" value="1" />-->
        <!--                                        <label class="text-dark mb-1 fs-6 fw-semibold">Positive</label>-->
        <!--                                    </div>-->
        <!--                                    <div class="form-check form-check-inline">-->
        <!--                                        <input class="form-check-input" type="checkbox" name="app_score"-->
        <!--                                            onclick="onlyOne(this)" value="-1" />-->
        <!--                                        <label class="text-dark mb-1 fs-6 fw-semibold">Negative</label>-->
        <!--                                    </div>-->
        <!--                                    <div class="form-check form-check-inline">-->
        <!--                                        <input class="form-check-input" type="checkbox" name="app_score"-->
        <!--                                            onclick="onlyOne(this)" value="0" />-->
        <!--                                        <label class="text-dark mb-1 fs-6 fw-semibold">Neutral</label>-->
        <!--                                    </div>-->
        <!--                                </div>-->
                                        <!--<div class="col-lg-6 mb-3">-->
                                        <!--    <label class="text-danger mb-1 fs-6 fw-semibold d-block">Highly Interested Lead</label>-->
                                        <!--    <div class="form-check form-check-inline">-->
                                        <!--        <input class="form-check-input" type="checkbox" name="hot_lead" id="hot_lead" />-->
                                        <!--        <label class="text-dark mb-1 fs-6 fw-semibold">Hot Lead</label>-->
                                        <!--    </div>-->

                                        <!--</div>-->
        <!--                                <div class="col-lg-12 mb-3">-->
        <!--                                    <textarea class="form-control" rows="3" id="convo_message" placeholder="Enter Conversation Message"-->
        <!--                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"></textarea>-->
        <!--                                </div>-->
        <!--                            </div>-->
        <!--                        </div>-->
                                <!--<div class="mb-3" id="reason" name="reason" style="display: none !important;">-->
                                <!--    <div class="col-lg-12 mb-3">-->
                                <!--        <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>-->
                                <!--        <textarea class="form-control" rows="3" id="app_reason" placeholder="Enter Reason"></textarea>-->
                                <!--    </div>-->
                                <!--    <div class="row mb-3">-->
                                <!--        <div class="col-lg-6 mb-3">-->
                                <!--            <label class="text-dark mb-1 fs-6 fw-semibold">Re-Followup Date</label>-->
                                <!--            <div class="input-group input-group-merge">-->
                                <!--                <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>-->
                                <!--                <input type="text" id="re_app_date" placeholder="Select Date" class="form-control" name="appointment_date" />-->
                                <!--            </div>-->
                                <!--        </div>-->
                                <!--        <div class="col-lg-6 mb-3">-->
                                <!--            <label class="text-dark mb-1 fs-6 fw-semibold">Re-Followup Time</label>-->
                                <!--            <input type="text" class="form-control common_time_class " placeholder="HH:MM" id="re_app_time" name="appointment_time" />-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
        <!--                        <div class="mb-3" id="reason" name="reason" style="display: none !important;">-->
        <!--                            <div class="col-lg-12 mb-3">-->
        <!--                                <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span-->
        <!--                                        class="text-danger">*</span></label>-->
        <!--                                {{-- <select id="app_reason" name="app_reason" class="select3 form-select">-->

        <!--                            </select> --}}-->
        <!--                                <select id="app_reason" name="app_reason" class="select3 form-select"-->
        <!--                                    onchange="toggleInputField_followup(this.value)">-->
        <!--                                    <option value="">Select Reason</option>-->
        <!--                                    @if (isset($followupReasonList))-->
        <!--                                        @foreach ($followupReasonList as $s_reason)-->
        <!--                                            <option value="{{ $s_reason->reason_name }}"-->
        <!--                                                data-comments-check-followup="{{ $s_reason->comments_check }}">-->
        <!--                                                {{ $s_reason->reason_name }}-->
        <!--                                            </option>-->
        <!--                                        @endforeach-->
        <!--                                    @endif-->
        <!--                                    <option value="1">Others</option>-->
        <!--                                </select>-->
        <!--                                <div class="text-danger" id="app_reason_select_err"></div>-->
        <!--                                <div class="mt-4" id="followup_reason_div" style="display: none;">-->
        <!--                                    <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span-->
        <!--                                            class="text-danger">*</span></label>-->
        <!--                                    <input type="text" class="form-control" name="followup_reason_text"-->
        <!--                                        id="followup_reason_text" value="" placeholder="Enter Reason">-->
        <!--                                </div>-->
        <!--                                {{-- <div class="mt-4" id="followup_comments_div" style="display: none;">-->
        <!--                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span-->
        <!--                                    class="text-danger">*</span></label>-->
        <!--                            <input type="text" class="form-control" name="followup_comments_text"-->
        <!--                                id="followup_comments_text" value="" placeholder="Enter Comments">-->
        <!--                        </div> --}}-->
        <!--                                <div class="text-danger" id="followup_reason_text_err"></div>-->
        <!--                                {{-- <div class="text-danger" id="followup_comments_text_err"></div> --}}-->

        <!--                            </div>-->
        <!--                            <div class="row mb-3">-->
        <!--                                <div class="col-lg-6 mb-3">-->
        <!--                                    <label class="text-dark mb-1 fs-6 fw-semibold">Re-Appointment Date</label>-->
        <!--                                    <div class="input-group input-group-merge">-->
        <!--                                        <span class="input-group-text"><i-->
        <!--                                                class="mdi mdi-calendar-month-outline fs-4"></i></span>-->
        <!--                                        <input type="text" id="re_app_date" placeholder="Select Date"-->
        <!--                                            class="form-control" name="appointment_date" />-->
        <!--                                    </div>-->
        <!--                                </div>-->
        <!--                                <div class="col-lg-6 mb-3">-->
        <!--                                    <label class="text-dark mb-1 fs-6 fw-semibold">Re-Appointment Time</label>-->
        <!--                                    <input type="text" class="form-control common_time_class_new "-->
        <!--                                        placeholder="HH:MM" id="re_app_time" name="appointment_time" />-->
        <!--                                </div>-->
        <!--                                <div class="col-lg-12 mb-3 d-flex justify-content-end">-->
        <!--                                    <label class="text-dark mb-1 fs-6 fw-semibold">Reshcedule Count</label> <span-->
        <!--                                        class="badge bg-danger" id="followup_reschedule_count"></span>-->
        <!--                                </div>-->

        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="col-lg-12 mb-3">-->
        <!--                            <div class="accordion mb-2" id="accordionExample">-->
        <!--                                <div class="accordion-item active">-->
        <!--                                    <h2 class="accordion-header" id="headingOne">-->
        <!--                                        <button type="button" class="accordion-button fw-bold"-->
        <!--                                            data-bs-toggle="collapse" data-bs-target="#accordionOne"-->
        <!--                                            aria-expanded="false" aria-controls="accordionOne" role="tabpanel">-->
        <!--                                            Follow Up History<span-->
        <!--                                                class="ms-2 badge bg-info text-white rounded fw-bold fs- "-->
        <!--                                                id="app_count">-->
        <!--                                            </span>-->
        <!--                                        </button>-->
        <!--                                    </h2>-->
        <!--                                    <div id="accordionOne" class="accordion-collapse collapse"-->
        <!--                                        data-bs-parent="#accordionExample">-->
        <!--                                        <div class="accordion-body">-->
        <!--                                            <div class="row">-->
        <!--                                                <div class="col-lg-12">-->
        <!--                                                    <table-->
        <!--                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1">-->
        <!--                                                        <thead>-->
        <!--                                                            <tr-->
        <!--                                                                class="text-start align-top fw-bold fs-6 gs-0 bg-primary">-->
        <!--                                                                <th class="min-w-50px">S.No</th>-->
        <!--                                                                <th class="min-w-80px">Date</th>-->
        <!--                                                                <th class="min-w-50px">Time</th>-->
        <!--                                                                <th class="min-w-80px">Followed BY</th>-->
        <!--                                                                <th class="min-w-80px">Reason</th>-->
                                                                        <!-- <th class="min-w-80px">ReSchedule</th> -->
        <!--                                                                <th class="min-w-50px">Score</th>-->
        <!--                                                                <th class="min-w-80px">Conversation</th>-->
        <!--                                                            </tr>-->
        <!--                                                        </thead>-->
        <!--                                                        <tbody id="historicalLeadIdsTableBody"-->
        <!--                                                            class="text-black fw-semibold fs-7">-->

        <!--                                                        </tbody>-->
        <!--                                                    </table>-->
        <!--                                                </div>-->
        <!--                                            </div>-->
        <!--                                        </div>-->
        <!--                                    </div>-->
        <!--                                </div>-->

        <!--                            </div>-->
        <!--                            <div class="accordion" id="accordionExample2">-->
        <!--                                <div class="accordion-item active">-->
        <!--                                    <h2 class="accordion-header" id="headingTwo">-->
        <!--                                        <button type="button" class="accordion-button fw-bold"-->
        <!--                                            data-bs-toggle="collapse" data-bs-target="#accordionTwo"-->
        <!--                                            aria-expanded="false" aria-controls="accordionTwo" role="tabpanel">-->
        <!--                                            Appointment History<span-->
        <!--                                                class="ms-2 badge bg-info text-white rounded fw-bold fs- "-->
        <!--                                                id="apptmnt_count">-->
        <!--                                            </span>-->
        <!--                                        </button>-->
        <!--                                    </h2>-->
        <!--                                    <div id="accordionTwo" class="accordion-collapse collapse"-->
        <!--                                        data-bs-parent="#accordionExample2">-->
        <!--                                        <div class="accordion-body">-->
        <!--                                            <div class="row">-->
        <!--                                                <div class="col-lg-12">-->
        <!--                                                    <table-->
        <!--                                                        class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1  list_page_1">-->
        <!--                                                        <thead>-->
        <!--                                                            <tr-->
        <!--                                                                class="text-start align-top fw-bold fs-6 gs-0 bg-primary">-->
        <!--                                                                <th class="min-w-50px">S.No</th>-->
        <!--                                                                <th class="min-w-100px">Date / Time</th>-->
        <!--                                                                <th class="min-w-50px">Category</th>-->
        <!--                                                                <th class="min-w-80px">Status</th>-->
        <!--                                                                <th class="min-w-80px">Conversation</th>-->
        <!--                                                                <th class="min-w-80px">Reason</th>-->
        <!--                                                            </tr>-->
        <!--                                                        </thead>-->
        <!--                                                        <tbody id="appointmentLeadIdsTableBody"-->
        <!--                                                            class="text-black fw-semibold fs-7">-->

        <!--                                                        </tbody>-->
        <!--                                                    </table>-->
        <!--                                                </div>-->
        <!--                                            </div>-->
        <!--                                        </div>-->
        <!--                                    </div>-->
        <!--                                </div>-->

        <!--                            </div>-->
        <!--                        </div>-->
        <!--                        <div class="d-flex justify-content-end align-items-center mt-4">-->
        <!--                            <button type="reset" class="btn btn-secondary me-3"-->
        <!--                                data-bs-dismiss="modal">Cancel</button>-->
        <!--                            <button type="submit" class="btn btn-primary" id="rescheduleBtn">Submit-->
        <!--                                Report</button>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                </form>-->

        <!--            </div>-->
                    <!--end::Modal body-->
        <!--        </div>-->
                <!--end::Modal content-->
        <!--    </div>-->
            <!--end::Modal dialog-->
        <!--</div>-->
        <!--end::Modal - Followup Lead Schedule-->
        
          <!--begin::Modal - Pending Followup Lead Schedule-->
    <div class="modal fade" id="kt_modal_follow_up_lead_schedule" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Followup Report</h3>
                    </div>
                    <form id="updateResheduleForm" autocomplete="off">
                        <div class="row mt-4">
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_name_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Lead Mobile</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="lead_phone_reop">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Date</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_date">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Followup Time</label>
                                <div class="bg-label-info border border-gray-400 fs-6 fw-semibold rounded px-4 py-2"
                                    id="app_time">
                                </div>
                            </div>
                            <div class="col-lg-12 mb-1 d-flex align-items-center justify-content-end">
                                <div class="text-black fs-5 fw-semibold">
                                    <span>Reschedule Count</span>
                                    <span class="badge bg-danger fs-6 text-white rounded"
                                        id="followup_reschedule_rep_count">00</span>
                                </div>
                            </div>
                            <div class="col-lg-12 mb-4">
                                <label class="text-black mb-1 fs-6 fw-semibold mt-4 me-2  d-block">Progressed<span
                                        class="text-danger">*</span></label>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="1" name="progressed" onclick="progress_func('yes');" checked />
                                    <label class="form-check-label">Yes</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="progressed" id="progressed"
                                        value="2" name="progressed" onclick="progress_func('no');" />
                                    <label class="form-check-label">No</label>
                                </div>
                            </div>
                        </div>
                        <div id="message" name="message">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">
                                        Follow Through <span class="text-danger">*</span>
                                    </label>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through" id="direct_call" value="1" checked />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold" for="direct_call">Direct Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through" id="whatsapp_chat" value="2" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold" for="whatsapp_chat">Whatsapp Chat</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through" id="whatsapp_call" value="3" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold" for="whatsapp_call">Whatsapp Call</label>
                                    </div>

                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="follow_through" id="email" value="4" />
                                        <label class="form-check-label text-black mb-1 fs-6 fw-semibold" for="email">E-Mail</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold d-block">Conversation Message<span
                                            class="text-danger">*</span></label>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="1" checked />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Positive</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="-1" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Negative</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="app_score"
                                            onclick="onlyOne(this)" value="0" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">Neutral</label>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="convo_message"
                                        oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                                        placeholder="Enter Conversation Message"></textarea>
                                    <div class="text-danger" id="convo_message_err"></div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div id="reason" name="reason" style="display: none !important;">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select" id="app_reason" name="app_reason"
                                        onchange="toggleInputField_followup(this.value)">
                                        <option value="">Select Reason</option>
                                        @if (isset($followupReasonList))
                                            @foreach ($followupReasonList as $s_reason)
                                                <option value="{{ $s_reason->reason_name }}"
                                                    data-comments-check-followup="{{ $s_reason->comments_check }}">
                                                    {{ $s_reason->reason_name }}
                                                </option>
                                            @endforeach
                                        @endif
                                        <option value="1">Others</option>
                                    </select>
                                    <div class="text-danger" id="app_reason_select_err"></div>
                                    <div class="mt-4" id="followup_reason_div" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="followup_reason_text"
                                            id="followup_reason_text" value="" placeholder="Enter Reason">
                                        <div class="text-danger" id="followup_comments_text_err"></div>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                                class="text-danger">*</span></label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="re_app_date" placeholder="Select Date"
                                                class="form-control" value="" name="appointment_date" />

                                        </div>
                                        <div class="text-danger" id="re_app_date_err"></div>
                                    </div>
                                    <div class="col-lg-6 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Re-Appointment Time<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control common_time_class_new"
                                            placeholder="HH:MM" id="re_app_time" name="appointment_time"
                                            value="" />
                                        <div class="text-danger" id="re_app_time_err"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="border-bottom mb-3 mt-2"></div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 mb-3">
                                <div class="accordion">
                                    <div class="accordion-item mb-2 active">
                                        <h2 class="accordion-header" id="headingPopoutOne">
                                            <button type="button" class="accordion-button" data-bs-toggle="collapse"
                                                data-bs-target="#accordionPopoutOne" aria-expanded="true"
                                                aria-controls="accordionPopoutOne">
                                                <span class="text-black fw-semibold fs-6">Followup History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="app_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutOne" class="accordion-collapse collapse show"
                                            aria-labelledby="headingPopoutOne" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-125px">Last Followup<br>Date / Time
                                                                    </th>
                                                                    <th class="min-w-125px">Followed By</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="historicalLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item mb-2">
                                        <h2 class="accordion-header" id="headingPopoutTwo">
                                            <button type="button" class="accordion-button collapsed"
                                                data-bs-toggle="collapse" data-bs-target="#accordionPopoutTwo"
                                                aria-expanded="false" aria-controls="accordionPopoutTwo">
                                                <span class="text-black fw-semibold fs-6">Appointment History</span>
                                                <span class="text-black fw-semibold fs-6 ms-1 me-1">-</span>
                                                <span class="badge bg-info rounded text-white fw-semibold fs-6"
                                                    id="apptmnt_count">00</span>
                                            </button>
                                        </h2>
                                        <div id="accordionPopoutTwo" class="accordion-collapse collapse"
                                            aria-labelledby="headingPopoutTwo" data-bs-parent="#accordionPopout">
                                            <div class="accordion-body">
                                                <div class="row">
                                                    <div class="col-lg-12 mb-0">
                                                        <table
                                                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1">
                                                            <thead>
                                                                <tr
                                                                    class="text-start align-top fw-bold fs-7 gs-0 bg-primary">
                                                                    <th class="min-w-50px">S.No</th>
                                                                    <th class="min-w-100px">Date / Time</th>
                                                                    <th class="min-w-100px">Category</th>
                                                                    <th class="min-w-100px">Conversation</th>
                                                                    <th class="min-w-100px">Reason</th>
                                                                    <th class="min-w-100px">Status</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody class="text-black fw-semibold fs-8"
                                                                id="appointmentLeadIdsTableBody">

                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id='rescheduleBtn' class="btn btn-primary"
                                    onclick="updateReshedule()">Submit
                                    Report</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Pending Followup Lead Schedule-->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        <style>
            /* Customize Toastr notification */
            .toast-success {
                background-color: green;
            }

            /* Customize Toastr notification */
            .toast-error {
                background-color: red;
            }

            .error_msg {
                border: solid 2px red !important;
                border-color: red !important;
            }
        </style>
        <script>
            // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
        </script>

        <script>
            $(".list_page").DataTable({
                "ordering": false,
                "paging": false,
                // "aaSorting":[],
                "language": {
                    "lengthMenu": "Show _MENU_",
                },
                "dom": "<'row mb-3'" +
                    // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                    // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                    ">" +

                    "<'table-responsive'tr>" +

                    "<'row'" +
                    // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                    ">"
            });
        </script>



        <script>
            document.getElementById('updateResheduleForm').addEventListener('submit', function(event) {
                event.preventDefault();
                // if (FollvalidateForm()) {
                updateReshedule();
                // }
            });
        </script>
        <script>
              let reshedule_id;

        function openResheduleModal(categoryId, name, mobile) {
            $('#lead_name_reop').html(name);
            $('#lead_phone_reop').html(mobile);
            reshedule_id = categoryId;
            // Function to format date to '10-Jun-2024'
            function formatDate(dateString) {
                const date = new Date(dateString);
                const day = date.getDate().toString().padStart(2, '0');
                const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                const month = monthNames[date.getMonth()];
                const year = date.getFullYear();
                return `${day}-${month}-${year}`;
            }

            function formatTime(timeString) {
                const date = new Date(`1970-01-01T${timeString}Z`);
                let hours = date.getUTCHours();
                const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                return `${hours}:${minutes} ${ampm}`;
            }
            fetch(`/edit_appointment/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;



                        document.getElementById('app_date').innerText = formatDate(lead.appointment_date);
                        document.getElementById('app_time').innerText = lead.appointment_time;
                        $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                        $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                        // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                        //   console.log('Appointment Count:', data.data.appointmentCount);
                        $('#app_count').html(data.data.appointmentCount);
                        const historicalTableBody = document.getElementById('historicalLeadIdsTableBody');
                        historicalTableBody.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];
                                const FollowThough = [
                                    'Unknown',        // 0
                                    'Direct Call',    // 1
                                    'Whatsapp Chat',  // 2
                                    'Whatsapp Call',  // 3
                                    'E-Mail',         // 4
                                ];
                                const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                <td>
                                    <div class="mb-0 align-items-center">
                                        <label>
                                            <span class="fs-7 me-2">${index + 1}</span>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label
                                        class="fs-8 text-black fw-semibold">${formatDate(category.appointment_date)}</label>
                                    <div class="d-block">
                                        <label class="text-dark fs-8"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="Followup Date">${formatTime(category.appointment_time)}</label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <div class="text-black fw-semibold fs-7 mb-1">${category.staff_name}</div>
                                        <div> <span class="bg-info text-white text-center p-1 rounded" title="Follow though">${FollowThough[category.follow_through ?? 0]}</span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="text-black fw-bold fs-8 text-truncate max-w-100px" data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                        title="${category.convo_message ?? '-'}">
                                        ${category.convo_message ?? '-'}
                                    </div>
                                </td>
                                <td>
                                    <div class="text-truncate max-w-150px"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="bottom"
                                        title="${category.reason ?? '-'}"> ${category.reason ?? '-'}</div>
                                </td>
                            </tr>`;

                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                       
                                    </tr>`;
                            historicalTableBody.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }


                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });

            fetch(`/appointment_history/${categoryId}`)
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        //   console.log(data)
                        const lead = data.data.latestAppointment;
                        const historicalLeadIds = data.data.historicalLeadIds;

                        $('#apptmnt_count').html(data.data.appointmentCount);
                        const historicalTableBodyAppt = document.getElementById('appointmentLeadIdsTableBody');
                        historicalTableBodyAppt.innerHTML = '';

                        if (historicalLeadIds.length > 0) {
                            for (let index = 0; index < historicalLeadIds.length; index++) {
                                const category = historicalLeadIds[index];

                                const row = `<tr>
                                    <td>
                                        <div class="mb-0 align-items-center">
                                            <label>
                                                <span class="fs-7 me-2">${index + 1}</span>
                                            </label>
                                        </div>
                                    </td>
                                     <td>
                                        <label
                                            class="fs-8 text-black fw-semibold">${category.previous_appointment_date ? formatDate(category.previous_appointment_date) :'-'}</label>
                                        <div class="d-block">
                                            <label class="text-dark fs-8"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Appointment Time">${category.previous_appointment_time ? formatTime(category.previous_appointment_time) :''} </label>
                                        </div>
                                    </td>
                                    <td>
                                        <label
                                            class="text-black fw-semibold fs-7">${category.appointment_category}</label>
                                    </td>
                                    <td>
                                    
                                        <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_reason || '-'}">
                                             ${category.appointment_reason || '-'}</div>
                                    </td>
                                    <td>
                                      <div class="text-truncate max-w-150px"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title=" ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}">
                                             ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):(category.convo_message ? category.convo_message :'-') )}</div>
                                    </td>
                                    <td>
                                      ${category.appointment_status == 2 ? `<div class="badge bg-success fw-semibold fs-7">Completed</div>` :
                                            category.appointment_status == 3 ? `<div class="badge bg-danger fw-semibold fs-7">Cancelled</div>` :
                                            category.appointment_status == 1 ? `<div class="badge bg-warning text-black fw-semibold fs-7">Scheduled</div>` :
                                            '<span>-</span>'}
                                    </td>
                                    
                                </tr>`;

                                historicalTableBodyAppt.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }
                        } else {
                            const row = `<tr>
                                        
                                    </tr>`;
                            historicalTableBodyAppt.innerHTML += row;
                            $('[data-bs-toggle="tooltip"]').tooltip();
                        }

                    } else {
                        console.error('Error fetching category:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Error fetching category:', error);
                });


        }

        function updateReshedule() {
            const resheduleid = reshedule_id;
            const progressed = document.querySelector('input[name="progressed"]:checked').value;

            // Initialize variables
            let app_score = null;
            let follow_through = null;
            let convo_message = null;
            let hot_lead = null;
            let reason = null;
            let appointment_date = null;
            let appointment_time = null;
            var err = 0;
            if (progressed == 1) {
                app_score = document.querySelector('input[name="app_score"]:checked').value;
                follow_through = document.querySelector('input[name="follow_through"]:checked').value;
                convo_message = document.getElementById('convo_message').value;
                if (convo_message == '') {
                    $('#convo_message_err').text('Conversation Message is Required')
                    err++
                } else {
                    $('#convo_message_err').text('');
                }
                // hot_lead = document.getElementById('hot_lead').value;
            } else {
                reason = document.getElementById('app_reason').value;
                var other_reason = document.getElementById('followup_reason_text').value;
                appointment_date = document.getElementById('re_app_date').value;
                appointment_time = document.getElementById('re_app_time').value;
                if (reason == '') {
                    $('#app_reason_select_err').text('Reason is Required');
                    err++;
                } else {
                    $('#app_reason_select_err').text('');
                }
                if (reason == 1) {
                    if (other_reason == "") {
                        $('#followup_comments_text_err').text('Other Reason is Required');
                        err++;
                    } else {
                        reason = other_reason;
                    }
                }
                if (appointment_date == '') {
                    $('#re_app_date_err').text('Followup Date is Required');
                    err++;
                } else {
                    $('#re_app_date_err').text('');
                }

                if (appointment_time == '') {
                    $('#re_app_time_err').text('Followup Time is Required');
                    err++;
                } else {
                    $('#re_app_time_err').text('');
                }

                // appointment_date = document.querySelector('input[name="appointment_date"]').value;
                // appointment_time = document.querySelector('input[name="appointment_time"]').value;
            }


            const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
            // if(document.getElementById('hot_lead').checked){
            //   hot_lead=1;
            // }else{
            //   hot_lead=0;
            // }

            if (err == 0) {
                $('#rescheduleBtn').prop('disabled', true);
                fetch(`/appointment_update/${resheduleid}`, {
                        method: 'post',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': csrfToken
                        },
                        body: JSON.stringify({
                            progressed: progressed,
                            app_score: app_score,
                            follow_through: follow_through,
                            convo_message: convo_message,
                            // hot_lead: hot_lead,
                            reason: reason,
                            appointment_date: appointment_date,
                            appointment_time: appointment_time,
                        }),
                    })

                    .then(data => {
                        if (data.status === 200) {
                            toastr.success('Appointment Updated successfully!');
                            $('#rescheduleBtn').prop('disabled', true);
                            location.reload();
                        } else {
                            toastr.error('Appointment Failed to update!');
                            $('#rescheduleBtn').prop('disabled', false);
                        }
                    })
                    .catch(error => {
                        console.error('Error updating category:', error);
                        $('#rescheduleBtn').prop('disabled', false);

                    });
            } else {
                $('#rescheduleBtn').prop('disabled', false);
            }

        }

            // new appointment
            let resheduleagain_id;

            function openResheduleModalAgain(categoryId, name, mobile) {
                $('#lead_name_app_again').html(name);
                $('#lead_phone_app_again').html(mobile);
                resheduleagain_id = categoryId;
                // Function to format date to '10-Jun-2024'
                function formatDate(dateString) {
                    const date = new Date(dateString);
                    const day = date.getDate().toString().padStart(2, '0');
                    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                    const month = monthNames[date.getMonth()];
                    const year = date.getFullYear();
                    return `${day}-${month}-${year}`;
                }

                function formatTime(timeString) {
                    const date = new Date(`1970-01-01T${timeString}Z`);
                    let hours = date.getUTCHours();
                    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
                    const ampm = hours >= 12 ? 'PM' : 'AM';
                    hours = hours % 12;
                    hours = hours ? hours : 12; // the hour '0' should be '12'
                    return `${hours}:${minutes} ${ampm}`;
                }
                fetch(`/edit_appointment/${categoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            const lead = data.data.latestAppointment;
                            const historicalLeadIds = data.data.historicalLeadIds;
                            document.getElementById('lead_id_again').value = lead.lead_id;
                            $('#followup_reschedule_count_again').text(data.data.lead_reschedule_count);
                            $('#followup_reschedule_count').text(data.data.lead_reschedule_count);
                            $('#followup_reschedule_rep_count').text(data.data.lead_reschedule_count);


                            // document.getElementById('lead_id_again').value = formatDate(lead.lead_id);
                            // document.getElementById('app_time_again').value = lead.appointment_time;
                            // document.getElementById('app_count').innerHTML  = lead.appointmentCount;
                            console.log('Appointment Count:', data.data.appointmentCount);
                            $('#app_count_again').html(data.data.appointmentCount);
                            const historicalTableBody = document.getElementById('historicalLeadIdsTableBodyAgain');
                            historicalTableBody.innerHTML = '';

                            if (historicalLeadIds.length > 0) {
                                for (let index = 0; index < historicalLeadIds.length; index++) {
                                    const category = historicalLeadIds[index];
                                    if (category.app_score === 1) {
                                        var score =
                                            `<span class="text-success fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                    } else if (category.app_score === -1) {
                                        var score =
                                            `<span class="text-danger fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                    } else if (category.app_score === 0) {
                                        var score =
                                            `<span class="text-info fw-bold fs-5 text-center">${category.app_score ?? '-'}</span>`;
                                    } else {
                                        var score = `<span class="text-info fw-bold fs-5 text-center">-</span>`;
                                    }
                                    const FollowThough = [
                                        'Unknown',        // 0
                                        'Direct Call',    // 1
                                        'Whatsapp Chat',  // 2
                                        'Whatsapp Call',  // 3
                                        'E-Mail',         // 4
                                    ];
                                    const row = `<tr class="${category.status == 5 ? 'bg-danger' : ''}">
                                    <td>
                                        <div class="mb-0 align-items-center">
                                            <label>
                                                <span class="fs-7 me-2">${index + 1}</span>
                                            </label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-block badge rounded bg-success text-black fs-7">${formatDate(category.appointment_date)}</div>
                                    </td>
                                    <td>
                                        <div class="d-block badge rounded bg-danger text-white fs-7">${formatTime(category.appointment_time)}</div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <div class="text-black fw-semibold fs-7 mb-1">${category.staff_name}</div>
                                            <div> <span class="bg-info text-white text-center p-1 rounded" title="Follow though">${FollowThough[category.follow_through ?? 0]}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="text-black fw-bold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${category.reason ?? '-'}">${category.reason ?? '-'}</div>
                                    </td>
                                    <td>
                                        <label title="Score">
                                            ${score}
                                        </label>
                                    </td>
                                    <td>
                                        <div class=" text-black fw-bold fs-8 text-truncate max-w-100px" id="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${category.convo_message ? category.convo_message : '-'}">${category.convo_message ? category.convo_message : '-'}</div>
                                    </td>
                                </tr>`;
                                    historicalTableBody.innerHTML += row;
                                    $('[data-bs-toggle="tooltip"]').tooltip();
                                }
                            } else {
                                const row = `<tr>
                                            <td colspan="6" class="text-center">No data available</td>
                                        </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }

                            $('[data-bs-toggle="tooltip"]').tooltip();


                        } else {
                            console.error('Error fetching category:', data.message);
                        }
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    })
                    .catch(error => {
                        console.error('Error fetching category:', error);
                    });

                fetch(`/appointment_history/${categoryId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 200) {
                            console.log(data)
                            const lead = data.data.latestAppointment;
                            const historicalLeadIds = data.data.historicalLeadIds;

                            $('#apptmnt_count_again').html(data.data.appointmentCount);
                            const historicalTableBody = document.getElementById('appointmentLeadIdsTableBodyAgain');
                            historicalTableBody.innerHTML = '';

                            if (historicalLeadIds.length > 0) {
                                for (let index = 0; index < historicalLeadIds.length; index++) {
                                    const category = historicalLeadIds[index];
                                    const row = `<tr>
                                    <td>${index + 1}</td>
                                    <td>
                                        <label>${formatDate(category.previous_appointment_date == null? category.appointment_date : category.previous_appointment_date)}</label>
                                        <div class="d-block text-primary fs-8" title="Last Follow Up Date">${formatTime((category.previous_appointment_time == null? category.appointment_time : category.previous_appointment_time))}</div>
                                    </td>
                                    <td>
                                        <label class="text-truncate max-w-100px" title="${category.appointment_category}">${category.appointment_category !== null ? category.appointment_category : '-'}</label>
                                    </td>
                                    <td>
                                        <label title="Score">
                                            ${category.appointment_status == 2 ? `<span class="text-success fw-bold fs-6 text-center">Completed</span>` :
                                            category.appointment_status == 3 ? `<span class="text-danger fw-bold fs-6 text-center">Cancelled</span>` :
                                            category.appointment_status == 1 ? `<span class="text-info fw-bold fs-6 text-center">Not Yet Started</span>` :
                                            '<span>-</span>'}
                                        </label>
                                    </td>
                                      <td>
                                        ${category.appointment_status == 2 ? (category.convo_message ?category.convo_message :'-'):(category.appointment_status == 3 ?(category.status_reason_message ?category.status_reason_message :'-'):'-' )}
                                    </td>
                                    <td>
                                        <label class="text-truncate max-w-100px" title="${category.appointment_reason}">
                                        ${category.appointment_reason !== null ? category.appointment_reason : '-'}</label>
                                        </td>
                                </tr>`;
                                    historicalTableBody.innerHTML += row;
                                    $('[data-bs-toggle="tooltip"]').tooltip();
                                }
                            } else {
                                const row = `<tr>
                                            <td colspan="6" class="text-center">No data available</td>
                                        </tr>`;
                                historicalTableBody.innerHTML += row;
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            }

                        } else {
                            console.error('Error fetching category:', data.message);
                        }
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    })
                    .catch(error => {
                        console.error('Error fetching category:', error);
                    });
            }
            let status_id;
        </script>



        <script>
            function yes_func() {
                var prog_yes = document.getElementById("prog_yes");
                var message = document.getElementById("message");
                var reason = document.getElementById("reason");

                if (prog_yes.click) {
                    message.style.display = "block";
                    reason.style.display = "none";

                } else {
                    message.style.display = "none";
                    // linked_on.style.display = "block";
                }
            }
        </script>
        <script>
            function no_func() {
                var prog_no = document.getElementById("prog_no");
                var reason = document.getElementById("reason");

                if (prog_no.click) {
                    reason.style.display = "block";
                    message.style.display = "none";

                } else {
                    reason.style.display = "none";
                    // linked_on.style.display = "block";
                }
            }
        </script>



        <script>
            $(document).ready(function() {
                //lead name auto complete for add
                $('#search').on('keyup', function() {
                    var query = $(this).val();
                    // alert(query);
                    if (query.length > 2) {
                        $.ajax({
                            url: "{{ route('autocomplete_lead_name') }}",
                            type: "GET",
                            data: {
                                'term': query
                            },
                            success: function(data) {
                                //   console.log(data)
                                $('#result-list').empty().show();
                                if (data.length > 0) {
                                    $.each(data, function(index, value) {
                                        $('#result-list').append(
                                            '<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' +
                                            value.lead_name + ' - ' + value
                                            .lead_mobile +
                                            '<input type="hidden" value="' + value.sno +
                                            '" ></p>');

                                    });
                                } else {
                                    $('#search_err').html('No Record Found or Leads');
                                }
                            }
                        });
                    } else {
                        $('#result-list').hide();
                    }
                });
                // console.log('before select name',$('#lead_id_add').val())
                // Handle selection from the list
                $(document).on('click', '#result-list p', function() {
                    var selectedText = $(this).text();
                    var leadSno = $(this).find('input[type="hidden"]').val();
                    $('#search').val(selectedText);
                    $('#result-list').hide(); // Hide the list after selection
                    $('#lead_id_add').val(leadSno);
                    // console.log('after select name',$('#lead_id_add').val())

                });

                //lead name auto complete for Edit
                $('#search_edit').on('keyup', function() {
                    var query = $(this).val();
                    // alert(query);
                    if (query.length > 2) {
                        $.ajax({
                            url: "{{ route('autocomplete_lead_name') }}",
                            type: "GET",
                            data: {
                                'term': query
                            },
                            success: function(data) {
                                //   console.log(data)
                                $('#result-list_edit').empty().show();
                                if (data.length > 0) {
                                    $.each(data, function(index, value) {
                                        $('#result-list_edit').append(
                                            '<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' +
                                            value.lead_name + ' - ' + value
                                            .lead_mobile +
                                            '<input type="hidden" value="' + value.sno +
                                            '" ></p>');

                                    });
                                } else {
                                    $('#search_edit_err').html('No Record Found or Leads');
                                }
                            }
                        });
                    } else {
                        $('#result-list_edit').hide();
                    }
                });

                // Handle selection from the list
                $(document).on('click', '#result-list_edit p', function() {
                    var selectedText = $(this).text();
                    var leadSno = $(this).find('input[type="hidden"]').val();
                    $('#search_edit').val(selectedText);
                    $('#result-list_edit').hide(); // Hide the list after selection
                    $('#lead_id_edit').val(leadSno);
                    // console.log('after select name edit',$('#lead_id_edit').val())

                });


            });
        </script>
        <script>
            $('#lead_filter').click(function() {
                $('.lead_filter').slideToggle('slow');
            });

            document.getElementById('filter_form').onsubmit = function() {
                this.querySelector('button[type="submit"]').disabled = true;
            };
        </script>
        <script>
            function date_fill_issue_rpt() {
                var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
                var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
                var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
                var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
                var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
                var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
                var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
                var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
                var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

                if (dt_fill_issue_rpt == "today") {
                    today_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "week") {
                    today_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "block";
                    week_to_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";

                    var curr = new Date; // get current date
                    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                    var last = first + 6; // last day is the first day + 6

                    var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                    firstday = firstday.split("-").reverse().join("-");
                    var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                    lastday = lastday.split("-").reverse().join("-");
                    $('#lead_week_st_dt_fill').val(firstday);
                    $('#lead_week_ed_dt_fill').val(lastday);

                } else if (dt_fill_issue_rpt == "monthly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "block";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "custom_date") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "block";
                    to_dt_iss_rpt.style.display = "block";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }
            }
        </script>

        <script>
            function sort_filter(val) {
                if (val != "") {
                    $('.sorting_filter_class').val(val);
                    $('#search_form').submit();
                } else {
                    $('.sorting_filter_class').val(10);
                    $('#search_form').submit();
                }
            }
        </script>
    
        <script>
        function progress_func(prog_val) {

            if (prog_val == 'no') {
                document.getElementById("message").style.display = "none";
                document.getElementById("reason").style.display = "block";

            } else {
                document.getElementById("message").style.display = "block";
                document.getElementById("reason").style.display = "none";
            }
        }
    </script>
    
    <script>
        function onlyOne(checkbox) {
            var checkboxes = document.getElementsByName('app_score')
            checkboxes.forEach((item) => {
                if (item !== checkbox) item.checked = false
            })
        }
    </script>
    
     <script>
        $(".list_page_1").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    
      <script>
        $(document).ready(function() {
            $(".common_time_class_new").flatpickr({
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                defaultHour: new Date().getHours(),
                defaultMinute: new Date().getMinutes()
            });
        });
        function toggleInputField_followup(value) {
            var followupReasonDiv = document.getElementById('followup_reason_div');
            var followupReasonText = document.getElementById('followup_reason_text');
            // var followupCommentsDiv = document.getElementById('followup_comments_div');
            var selectedOption = document.querySelector('#app_reason option:nth-child(' + (document.getElementById(
                'app_reason').selectedIndex + 1) + ')');
            // var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check-followup') : null;

            if (value == '1') {
                followupReasonDiv.style.display = 'block';
                followupReasonText.setAttribute('required', 'required');
            } else {
                followupReasonDiv.style.display = 'none';
                followupReasonText.removeAttribute('required');
            }

            // if (commentsCheck == '1') {
            //     followupCommentsDiv.style.display = 'block';
            // } else {
            //     followupCommentsDiv.style.display = 'none';
            // }
        }
    </script>
    
    @endsection
