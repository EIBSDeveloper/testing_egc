@extends('layouts/layoutMaster')

@section('title', 'Manage Followup')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@endsection
@section('content')

<!-- Lead List Table -->
<div class="card">
   <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Followup</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                </li>
            </ol>
        </nav>
    </div>
    @php
        $helper = new \App\Helpers\Helpers();
        $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
        $user_id = auth()->user()->user_id;
        $user_data=$helper->get_staff_data($user_id);
    @endphp
    <div class="card-body px-4 py-0">
        <div class="nav-align-top mb-2">
            <ul class="nav nav-pills flex-nowrap border-bottom" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><i class="mdi mdi-chevron-left fs-2 text-white"></i></button>
                    <div class="scroll-container" id="scrollContainer">
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2 "  aria-selected="false" style="background-color: #FCFF66 !important;" id="tdy_flwup">
                                    <span id="tdy_flwup_txt">Today Followup</span>
                                    @if(isset($todayFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$todayFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/closed_follow')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2" style="background-color: #d0dfd7 !important;"   aria-selected="true" id="cld_flwup">
                                    <span class="ms-2" id="cld_flwup_txt">Closed Followup</span>
                                    @if(isset($closedFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$closedFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/reschedule_follow')}}"  type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2 active" style="background-color: #FFB6C1 !important;" aria-selected="true" id="rescd_flwup">
                                    <span class="ms-2" id="rescd_flwup_txt">Reschedule Followup</span>
                                     @if(isset($rescheduleFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$rescheduleFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                        <div class="item">
                            <li class="nav-item rounded me-2 mb-2" style="border: 1px solid #099dda;">
                                <a href="{{url('/manage_followup/un_follow')}}" type="button" class="nav-link text-capitalize border border-gray-500 rounded px-3 py-2" style="background-color: #ff7a7a !important;"  aria-selected="true" id="un_flwup">
                                    <span class="ms-2" id="un_flwup_txt">Un Followup</span>
                                    @if(isset($unFollowupCount))<span class="badge bg-label-info rounded fw-semibold border-gray-400 fs-8 ms-2">{{ sprintf("%02d",$unFollowupCount) }}</span>@endif
                                </a>
                            </li>
                        </div>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="row mt-2">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="d-flex justify-content-end align-items-center flex-wrap">

                        {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2"
                            id="lead_filter" title="Filter">
                            <i class="mdi mdi-filter-outline text-center"></i>
                        </a> --}}
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                      <div class="mb-4">
                          @php $perpage_count = $perpage ? $perpage : 10; @endphp
                          <div>
                              <span>Show</span>
                              <br>
                              <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                  <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                  </option>
                                @php endforeach; @endphp
                              </select>
                          </div>
                      </div>
                      <div class="mb-4">
                        <form id="search_form" method="POST" action="/manage_followup/reschedule_follow">
                          @csrf
                          <div class="d-flex align-items-center gap-2">
                            <div class="mb-1">
                              <input type="hidden" name="page" value="{{ request('page', 1) }}">
                              <input type="hidden" name="filter_on" value="1">
                              <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Search</label>
                              <input
                                type="text"
                                class="form-control"
                                id="lead_fill" name="lead_fill" value="{{ $lead_fill ?? "" }}"
                                placeholder="Enter Lead - Name/ Mob. No/ Email Id"
                              />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mt-4" onclick="search_filter_func()">Search</button>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-100px">Lead</th>
                                        <th class="min-w-100px">Date</th>
                                        <th class="min-w-100px">Time</th>
                                        <th class="min-w-100px">Followed By</th>
                                        <th class="min-w-100px">Reason</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                  @if (count($lead_flw_list) > 0)
                                    @foreach ($lead_flw_list as $list)
                                      <tr>
                                          <td>
                                              <div class="mb-0 align-items-center">
                                                  <label>
                                                      <span class="fs-7 me-2">{{$list->lead_name }}</span>
                                                      <span>
                                                        @if($list->lead_gender==1)
                                                        <i class="mdi mdi-face-man text-info"></i>
                                                        @elseif($list->lead_gender==2)
                                                        <i class="mdi mdi-face-woman text-danger"></i>
                                                        @else
                                                        {{-- <i class="mdi mdi-face-woman text-danger"></i> --}}
                                                        @endif

                                                      </span>
                                                  </label>
                                                  <div class="d-block text-primary fs-8" title="Email ID">{{ $list->lead_email_id }}</div>
                                              </div>
                                          </td>
                                          <td>
                                              <div class="d-block badge rounded bg-success text-black fs-7 ">{{date('d-M-Y', strtotime($list->appointment_date))}}</div>
                                          </td>
                                          <td>
                                              <div class="d-block badge rounded bg-danger text-white fs-7">{{date('h:i A', strtotime($list->appointment_time))}}</div>

                                          </td>
                                          <td>{{ $list->staff_name }}</td>
                                          <td>
                                            <div class=" text-black fw-bold fs-8" id="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->reason ?? "-" }}">{{$list->reason ?? "-"}}</div>
                                          </td>


                                      </tr>
                                    @endforeach
                                  @endif

                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4">
                          {{ $lead_flw_list->appends(request()->except(['page', '_token']))->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>






    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if(Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
        @endif

    </script>

         <script>
          $(".list_page").DataTable({
              "ordering": false,
              "paging": false,
              // "aaSorting":[],
              "language": {
                  "lengthMenu": "Show _MENU_"
              , }
              ,"dom": "<'row mb-3'" +
                  // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                  // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                  ">" +

                  "<'table-responsive'tr>" +

                  "<'row'" +
                  // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                  // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                  ">"
          });
        </script>


{{-- date and time format script --}}
    <script>
      function formatAppointmentDate(dateString) {
          // Parse the date string
          const date = new Date(dateString);

          // Get the day, month, year, hour, and minute
          const day = String(date.getDate()).padStart(2, '0');
          const month = date.toLocaleString('default', { month: 'short' });
          const year = date.getFullYear();
          let hour = date.getHours();
          const minute = String(date.getMinutes()).padStart(2, '0');

          // Determine AM or PM suffix
          const ampm = hour >= 12 ? 'PM' : 'AM';

          // Convert to 12-hour format and ensure two digits
          hour = String(hour % 12 || 12).padStart(2, '0'); // Convert hour 0 to 12 and ensure two digits

          // Format the final string
          return `${day}-${month}-${year} ${hour}.${minute} ${ampm}`;
      }
    </script>

    {{-- view script --}}
    <script>
      function openViewModal(val){
        var appointment_status = val.appointment_status;
        if(appointment_status == 1){
          appointment_status ='New Appointment Scheduled';
          document.getElementById('appt_status_view').classList.add('bg-warning', 'text-black');
          document.getElementById('appt_status_view').textContent = appointment_status;

        }
        else if(appointment_status == 2){
          appointment_status ='Appointment Completed';
          document.getElementById('appt_status_view').classList.add('bg-success', 'text-black');
          document.getElementById('appt_status_view').textContent = appointment_status;
        }
        else if(appointment_status == 3){
          appointment_status ='	Appointment Cancelled';
          document.getElementById('appt_status_view').classList.add('bg-danger', 'text-white');
          document.getElementById('appt_status_view').textContent = appointment_status;
        }
        else{
          appointment_status ='Re-Appointment Scheduled';
          document.getElementById('appt_status_view').classList.add('bg-info', 'text-white');
          document.getElementById('appt_status_view').textContent = appointment_status;
        }

        // document.getElementById('appt_status_view').textContent = appointment_status;
        document.getElementById('lead_name_view').textContent = val.lead_name;
        document.getElementById('appt_category_view').textContent = val.appointment_category;
        if(val.re_appointment_date){
          document.getElementById('appt_date_view').textContent = formatAppointmentDate(val.re_appointment_date);
        }else{
          document.getElementById('appt_date_view').textContent = formatAppointmentDate(val.appointment_date);
        }

        document.getElementById('ass_staff_view').textContent = val.staff_name;
        document.getElementById('reason_msg_view').textContent = val.appointment_reason;
      }
    </script>
 {{-- complete Appointment script --}}
    <script>
      function completeAppointment(val){
        document.getElementById('lead_id_complete').value = val.sno;
        document.getElementById('lead_name_complete').textContent = val.lead_name;
        document.getElementById('appt_category_complete').textContent = val.appointment_category;
        document.getElementById('appt_date_complete').textContent = formatAppointmentDate(val.appointment_date);
        document.getElementById('assg_staff_complete').textContent = val.staff_name;
        document.getElementById('reason_msg_complete').textContent = val.appointment_reason;
      }

      function completeValidateForm(){
        var err = 0;

        var pst=document.getElementById("conv_msg_positive")
        var negt=document.getElementById("conv_msg_negative")
        var neut=document.getElementById("conv_msg_neutral")

        // var hl=document.getElementById("conv_sht_msg_hl")
        // var dl=document.getElementById("conv_sht_msg_dl")
        // var ft=document.getElementById("conv_sht_msg_ft")
        // var fu=document.getElementById("conv_sht_msg_fu")
        // var fb=document.getElementById("conv_sht_msg_fp")
        // var ftl=document.getElementById("conv_sht_msg_ftl")

        if(!pst.checked && !negt.checked && !neut.checked){
          document.getElementById('covo_scr_err').innerHTML = ' Conversation Score(eg.postive..) is required...!';
          err++;
        }
        else{
          document.getElementById('covo_scr_err').innerHTML = '';
        }

        // if(!hl.checked && !dl.checked && !ft.checked && !fu.checked && !fb.checked && !ftl.checked){
        //   document.getElementById('lead_type_complt_err').innerHTML = 'Lead Type(eg.HL..) is required...!';
        //   err++;
        // }
        // else{
        //   document.getElementById('lead_type_complt_err').innerHTML = '';
        // }


        // return err == 0;
        return  err == 0;
      }
    </script>
 {{-- cancel Appointment script --}}
    <script>
       function cancelAppointment(val){
        document.getElementById('lead_id_cancel').value = val.sno;
        document.getElementById('lead_name_cancel').textContent = val.lead_name;
        document.getElementById('appt_category_cancel').textContent = val.appointment_category;
        document.getElementById('appt_date_cancel').textContent = formatAppointmentDate(val.appointment_date);
        document.getElementById('assg_staff_cancel').textContent = val.staff_name;
        document.getElementById('reason_msg_cancel').textContent = val.appointment_reason;
      }

      function cancelValidateForm(){

        var err = 0;

         // Validate cancel_reason
         var cancel_reason = document.getElementById("cancel_reason").value.trim();
        if (cancel_reason === "") {
            document.getElementById('cancel_reason_err').innerHTML = 'Cancel Reason is required...!';
            document.getElementById('cancel_reason').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('cancel_reason').classList.remove('error_msg');
            document.getElementById('cancel_reason_err').innerHTML = '';
        }
        return err == 0;
      }

    </script>
 {{-- Re-appointment script --}}
<script>
  function reAppointment(val){
   document.getElementById('lead_id_re_appt').value = val.sno;
   document.getElementById('lead_name_re_appt').textContent = val.lead_name;
   document.getElementById('appt_category_re_appt').textContent = val.appointment_category;
   document.getElementById('appt_date_re_appt').textContent = formatAppointmentDate(val.appointment_date);
   document.getElementById('assg_staff_re_appt').textContent = val.staff_name;
   document.getElementById('reason_msg_re_appt').textContent = val.appointment_reason;
 }

 function reAppointmentValidateForm(){
    var err = 0;

      // Validate ReAppointment Date
      var ld_appt_reappt_date = document.getElementById("ld_appt_reappt_date").value.trim();
      if (ld_appt_reappt_date === "") {
        document.getElementById('ld_appt_reappt_date_err').innerHTML = 'Re_Appointment Date is required...!';
        document.getElementById('ld_appt_reappt_date').classList.add('error_msg');
        err++;
      } else {
        document.getElementById('ld_appt_reappt_date').classList.remove('error_msg');
        document.getElementById('ld_appt_reappt_date_err').innerHTML = '';
      }

    // Validate ReAppointment Reason
      var re_appt_reason = document.getElementById("re_appt_reason").value.trim();
      if (re_appt_reason === "") {
        document.getElementById('re_appt_reason_err').innerHTML = 'Re Appointment Reason is required...!';
        document.getElementById('re_appt_reason').classList.add('error_msg');
        err++;
      } else {
        document.getElementById('re_appt_reason').classList.remove('error_msg');
        document.getElementById('re_appt_reason_err').innerHTML = '';
      }
      return err == 0;
}
</script>
 {{-- Edit Modal script --}}
<script>
    function openEditModal(val){
            $.ajax({
                url: "{{ route('department') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('select[name="assg_dept_edit"]');
                        selectDropdown.empty();
                        selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                        response.data.forEach(function(dept) {
                            selectDropdown.append($('<option></option>').attr('value', dept
                                    .sno)
                                .text(dept.department_name));
                            if(val.department_id==dept.sno){
                            $('#assg_dept_edit').val(dept.sno).change();
                            }
                        });
                    }
                },
                error: function(error) {
                  selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                    // console.error('Error fetching course Brand:', error);
                }
            });
            $('#assg_dept_edit').on('change', function() {
              var depart_id=this.value;

              $.ajax({
                url: "{{ route('sales_staff') }}",
                type: "GET",
                data: { dept_id: depart_id },
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var selectDropdown = $('#assgn_staff_edit');
                        selectDropdown.empty();
                        selectDropdown.append('<option value="">Select Staff</option>');

                        response.data.forEach(function(staff) {
                            var option = $('<option></option>')
                                .attr('value', staff.sno)
                                .text(staff.staff_name);

                            if (val.staff_id === staff.sno) {
                                option.attr('selected', 'selected');
                            }

                            selectDropdown.append(option);
                        });
                    }
                },
                error: function(error) {
                    var selectDropdown = $('#assgn_staff_edit');
                    selectDropdown.empty();
                    selectDropdown.append('<option value="">Select Staff</option>');
                    console.error('Error fetching staff:', error);
                }
            });

            })


            document.getElementById('ld_appt_id_edit').value = val.sno;
            document.getElementById('lead_id_edit').value = val.ld_name_id;
            document.getElementById('search_edit').value = val.lead_name + ' - '+val.lead_id ;
            document.getElementById('appt_category_edit').value = val.appointment_category;
            document.getElementById('ld_appt_dt_edit').value = val.appointment_date;
            // document.getElementById('ass_staff_view').textContent = val.staff_name;
            document.getElementById('reason_msg_edit').value = val.appointment_reason;
            var event = new Event('change', {
                bubbles: true,
                cancelable: true
            });
            document.getElementById('appt_category_edit').dispatchEvent(event);
          //   console.log('before select name edit',$('#lead_id_edit').val())

    }




</script>

{{-- add validate --}}
<script>
function addvalidateForm() {
        var err = 0;

        $('#addSubmit').prop('disabled', true);
        // Validate Lead Name
        var ld_name_add = document.getElementById("lead_id_add").value.trim();
        if (ld_name_add === "") {
            document.getElementById('search_err').innerHTML = 'Lead Name is required...!';
            document.getElementById('lead_id_add').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('lead_id_add').classList.remove('error_msg');
            document.getElementById('search_err').innerHTML = '';
        }
      // Validate appointment category
        var appt_catg_add = document.getElementById("appt_catg_add").value.trim();
        if (appt_catg_add === "") {
            document.getElementById('appt_catg_add_err').innerHTML = 'Appointment Category is required...!';
            document.getElementById('appt_catg_add').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('appt_catg_add').classList.remove('error_msg');
            document.getElementById('appt_catg_add_err').innerHTML = '';
        }

        // Validate Appointment date
        var ld_appt_dt_add = document.getElementById("ld_appt_dt_add").value.trim();
        if (ld_appt_dt_add === "") {
            document.getElementById('ld_appt_dt_add_err').innerHTML = 'Appointment Date is required...!';
            document.getElementById('ld_appt_dt_add').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('ld_appt_dt_add').classList.remove('error_msg');
            document.getElementById('ld_appt_dt_add_err').innerHTML = '';
        }

        // Validate Reason message
        var appt_reason_add = document.getElementById("appt_reason_add").value.trim();
        if (appt_reason_add === "") {
            document.getElementById('appt_reason_add_err').innerHTML = 'Reason is required...!';
            document.getElementById('appt_reason_add').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('appt_reason_add').classList.remove('error_msg');
            document.getElementById('appt_reason_add_err').innerHTML = '';
        }

        // Validate Staff
        var assg_staff_add = document.getElementById("assg_staff_add").value.trim();
        if (assg_staff_add === "") {
            document.getElementById('assg_staff_add_err').innerHTML = 'Staff is required...!';
            document.getElementById('assg_staff_add').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('assg_staff_add').classList.remove('error_msg');
            document.getElementById('assg_staff_add_err').innerHTML = '';
        }

        if(err==0){
            $('#addLeadAppointmentForm').submit();
        }else{
            $('#addSubmit').prop('disabled', false);
        }

    }
</script>
<script>
    function editvalidateForm() {
        var err = 0;
        $('#editSubmit').prop('disabled', true);
        // Validate Lead Name
        var ld_id_edit = document.getElementById("lead_id_edit").value.trim();
        var ld_name_edit = document.getElementById("search_edit").value.trim();
        if (ld_name_edit === "" || ld_id_edit ==="") {
            document.getElementById('ld_name_edit_err').innerHTML = 'Lead Name is required...!';
            document.getElementById('search_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('search_edit').classList.remove('error_msg');
            document.getElementById('ld_name_edit_err').innerHTML = '';
        }
      // Validate appointment category
        var appt_category_edit = document.getElementById("appt_category_edit").value.trim();
        if (appt_category_edit === "") {
            document.getElementById('appt_category_edit_err').innerHTML = 'Appointment Category is required...!';
            document.getElementById('appt_category_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('appt_category_edit').classList.remove('error_msg');
            document.getElementById('appt_category_edit_err').innerHTML = '';
        }

        // Validate Appointment date
        var ld_appt_dt_edit = document.getElementById("ld_appt_dt_edit").value.trim();
        if (ld_appt_dt_edit === "") {
            document.getElementById('ld_appt_dt_edit_err').innerHTML = 'Appointment Date is required...!';
            document.getElementById('ld_appt_dt_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('ld_appt_dt_edit').classList.remove('error_msg');
            document.getElementById('ld_appt_dt_edit_err').innerHTML = '';
        }

        // Validate Reason message
        var reason_msg_edit = document.getElementById("reason_msg_edit").value.trim();
        if (reason_msg_edit === "") {
            document.getElementById('reason_msg_edit_err').innerHTML = 'Reason is required...!';
            document.getElementById('reason_msg_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('reason_msg_edit').classList.remove('error_msg');
            document.getElementById('reason_msg_edit_err').innerHTML = '';
        }

        // Validate Staff

        var assg_dept_edit = document.getElementById("assg_dept_edit").value.trim();
        if (assg_dept_edit === "") {
            document.getElementById('assg_dept_edit_err').innerHTML = 'Department is required...!';
            document.getElementById('assg_dept_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('assg_dept_edit').classList.remove('error_msg');
            document.getElementById('assg_dept_edit_err').innerHTML = '';
        }

        var assgn_staff_edit = document.getElementById("assgn_staff_edit").value.trim();
        if (assgn_staff_edit === "") {
            document.getElementById('assgn_staff_edit_err').innerHTML = 'Staff is required...!';
            document.getElementById('assgn_staff_edit').classList.add('error_msg');
            err++;
        } else {
            document.getElementById('assgn_staff_edit').classList.remove('error_msg');
            document.getElementById('assgn_staff_edit_err').innerHTML = '';
        }

        if(err==0){
            $('#editLeadAppointmentForm').submit();
        }else{
            $('#editSubmit').prop('disabled', false);
        }


    }
</script>
<script>
  $(document).ready(function() {
        //lead name auto complete for add
            $('#search').on('keyup', function() {
                var query = $(this).val();
                // alert(query);
                if (query.length > 2) {
                    $.ajax({
                        url: "{{ route('autocomplete_lead_name') }}",
                        type: "GET",
                        data: {'term': query},
                        success: function(data) {
                        //   console.log(data)
                            $('#result-list').empty().show();
                            if (data.length > 0) {
                                $.each(data, function(index, value) {
                                    $('#result-list').append('<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' + value.lead_name + ' - ' +value.lead_mobile +'<input type="hidden" value="'+value.sno+'" ></p>');

                                });
                            } else {
                                $('#search_err').html('No Record Found or Leads');
                            }
                        }
                    });
                } else {
                    $('#result-list').hide();
                }
            });
            // console.log('before select name',$('#lead_id_add').val())
            // Handle selection from the list
            $(document).on('click', '#result-list p', function() {
                var selectedText = $(this).text();
                var leadSno = $(this).find('input[type="hidden"]').val();
                $('#search').val(selectedText);
                $('#result-list').hide(); // Hide the list after selection
                $('#lead_id_add').val(leadSno);
                // console.log('after select name',$('#lead_id_add').val())

            });

          //lead name auto complete for Edit
          $('#search_edit').on('keyup', function() {
                var query = $(this).val();
                // alert(query);
                if (query.length > 2) {
                    $.ajax({
                        url: "{{ route('autocomplete_lead_name') }}",
                        type: "GET",
                        data: {'term': query},
                        success: function(data) {
                        //   console.log(data)
                            $('#result-list_edit').empty().show();
                            if (data.length > 0) {
                                $.each(data, function(index, value) {
                                    $('#result-list_edit').append('<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' + value.lead_name + ' - ' + value.lead_mobile +'<input type="hidden" value="'+value.sno+'" ></p>');

                                });
                            } else {
                                $('#search_edit_err').html('No Record Found or Leads');
                            }
                        }
                    });
                } else {
                    $('#result-list_edit').hide();
                }
            });

            // Handle selection from the list
            $(document).on('click', '#result-list_edit p', function() {
                var selectedText = $(this).text();
                var leadSno = $(this).find('input[type="hidden"]').val();
                $('#search_edit').val(selectedText);
                $('#result-list_edit').hide(); // Hide the list after selection
                $('#lead_id_edit').val(leadSno);
                // console.log('after select name edit',$('#lead_id_edit').val())

            });


        });
</script>
<script>
   $('#lead_filter').click(function() {
            $('.lead_filter').slideToggle('slow');
        });

        document.getElementById('filter_form').onsubmit = function() {
            this.querySelector('button[type="submit"]').disabled = true;
        };
</script>
<script>
  function date_fill_issue_rpt() {
      var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
      var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
      var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
      var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
      var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
      var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
      var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
      var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
      var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

      if (dt_fill_issue_rpt == "today") {
          today_dt_iss_rpt.style.display = "block";
          monthly_dt_iss_rpt.style.display = "none";
          from_dt_iss_rpt.style.display = "none";
          to_dt_iss_rpt.style.display = "none";
          week_from_dt_iss_rpt.style.display = "none";
          week_to_dt_iss_rpt.style.display = "none";
      } else if (dt_fill_issue_rpt == "week") {
          today_dt_iss_rpt.style.display = "none";
          week_from_dt_iss_rpt.style.display = "block";
          week_to_dt_iss_rpt.style.display = "block";
          monthly_dt_iss_rpt.style.display = "none";
          from_dt_iss_rpt.style.display = "none";
          to_dt_iss_rpt.style.display = "none";

          var curr = new Date; // get current date
          var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
          var last = first + 6; // last day is the first day + 6

          var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
          firstday = firstday.split("-").reverse().join("-");
          var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
          lastday = lastday.split("-").reverse().join("-");
          $('#lead_week_st_dt_fill').val(firstday);
          $('#lead_week_ed_dt_fill').val(lastday);

      } else if (dt_fill_issue_rpt == "monthly") {
          today_dt_iss_rpt.style.display = "none";
          monthly_dt_iss_rpt.style.display = "block";
          from_dt_iss_rpt.style.display = "none";
          to_dt_iss_rpt.style.display = "none";
          week_from_dt_iss_rpt.style.display = "none";
          week_to_dt_iss_rpt.style.display = "none";
      } else if (dt_fill_issue_rpt == "custom_date") {
          today_dt_iss_rpt.style.display = "none";
          monthly_dt_iss_rpt.style.display = "none";
          from_dt_iss_rpt.style.display = "block";
          to_dt_iss_rpt.style.display = "block";
          week_from_dt_iss_rpt.style.display = "none";
          week_to_dt_iss_rpt.style.display = "none";
      } else {
          today_dt_iss_rpt.style.display = "none";
          monthly_dt_iss_rpt.style.display = "none";
          from_dt_iss_rpt.style.display = "none";
          to_dt_iss_rpt.style.display = "none";
          week_from_dt_iss_rpt.style.display = "none";
          week_to_dt_iss_rpt.style.display = "none";
      }
  }
</script>

<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#search_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#search_form').submit();
    }
  }
</script>
<script>
    function today_followup() {
        const tdy_flwup = document.getElementById("tdy_flwup");

        if (tdy_flwup && tdy_flwup.classList.contains('active')) {

            document.getElementById("tdy_flwup_txt").setAttribute("style", "color:rgb(0, 0, 0) !important;");
            tdy_flwup.setAttribute("style", "background-color: #faff00 !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;");

        } else {
            document.getElementById("tdy_flwup_txt").setAttribute("style", "color:#4b4b4b !important;");
            tdy_flwup.setAttribute("style", "background-color: #FCFF66 !important;box-shadow: 0px 0rem 0rem 0px rgba(0, 0, 0, 0.22) !important;");
        }
    }

    function closed_followup() {
        const cld_flwup = document.getElementById("cld_flwup");

        if (cld_flwup && cld_flwup.classList.contains('active')) {

            document.getElementById("cld_flwup_txt").setAttribute("style", "color:rgb(0, 0, 0) !important;");
            cld_flwup.setAttribute("style", "background-color: #50CD89 !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;");

        } else {
            document.getElementById("cld_flwup_txt").setAttribute("style", "color:#4b4b4b !important;");
            cld_flwup.setAttribute("style", "background-color: #d0dfd7 !important;box-shadow: 0px 0rem 0rem 0px rgba(0, 0, 0, 0.22) !important;");
        }
    }

    function reschedule_followup() {
        const rescd_flwup = document.getElementById("rescd_flwup");

        if (rescd_flwup && rescd_flwup.classList.contains('active')) {

            document.getElementById("rescd_flwup_txt").setAttribute("style", "color:rgb(0, 0, 0) !important;");
            rescd_flwup.setAttribute("style", "background-color: #FFB6C1 !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;");

        } else {
            document.getElementById("rescd_flwup_txt").setAttribute("style", "color:#4b4b4b !important;");
            rescd_flwup.setAttribute("style", "background-color: #82ffbb !important;box-shadow: 0px 0rem 0rem 0px rgba(0, 0, 0, 0.22) !important;");
        }
    }

    function un_followup() {
        const un_flwup = document.getElementById("un_flwup");

        if (un_flwup && un_flwup.classList.contains('active')) {

            document.getElementById("un_flwup_txt").setAttribute("style", "color:rgb(0, 0, 0) !important;");
            un_flwup.setAttribute("style", "background-color: #F46666 !important; box-shadow: 0px 0rem 1rem 6px rgba(0, 0, 0, 0.22) !important;");

        } else {
            document.getElementById("un_flwup_txt").setAttribute("style", "color:#4b4b4b !important;");
            un_flwup.setAttribute("style", "background-color: #ff7a7a !important;box-shadow: 0px 0rem 0rem 0px rgba(0, 0, 0, 0.22) !important;");
        }
    }

    document.addEventListener("DOMContentLoaded", function() {
        // On page load
        today_followup();
        closed_followup();
        reschedule_followup();
        un_followup();

        // On tab change
        document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', function(event) {
                today_followup();
                closed_followup();
                reschedule_followup();
                un_followup();
            });
        });
    });
</script>

    @endsection
