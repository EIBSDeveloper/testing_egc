@extends('layouts/layoutMaster')

@section('title', 'Manage Calls')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
@php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
@endphp
@php
    $dayCounter = 1;
    $currentMonth = request()->get('month', date('m')); // Default to current month if not provided
    $currentYear = request()->get('year', date('Y')); // Default to current year if not provided

    // Calculate the first day of the month
    $firstDayOfMonth = Carbon\Carbon::createFromDate($currentYear, $currentMonth, 1);
    // Get the number of days in the current month
    $daysInMonth = $firstDayOfMonth->daysInMonth;

    // Calculate previous month and year
    $previousMonth = $currentMonth > 1 ? $currentMonth - 1 : 12; // Handle wrapping back to December
    $previousYear = $currentMonth == 1 ? $currentYear - 1 : $currentYear; // Adjust year for previous month if in January

    // Calculate next month and year
    $nextMonth = $currentMonth < 12 ? $currentMonth + 1 : 1; // Handle wrapping to January
    $nextYear = $currentMonth == 12 ? $currentYear + 1 : $currentYear; // Adjust year for next month if in December
    $currentDate = '2025-' . str_pad($currentMonth, 2, '0', STR_PAD_LEFT) . '-' . str_pad($dayCounter, 2, '0', STR_PAD_LEFT);
    
     $module_name = 'Lead Management';
     $menu_name = 'Manage Calls';
@endphp

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }
</style>
    
    
<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-0 flex-wrap">
        <div class="card-action-title text-black fs-5 fw-bold mb-1">
        <h5 class="card-title mb-1">Manage Calls</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Lead Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="mb-0 d-flex align-items-center">
            {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-2 mb-2" data-bs-toggle="modal" data-bs-target="#">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Export"><i class="mdi mdi-calendar-export-outline"></i></span>
            </a> --}}

            <div class="me-2 mb-2 w-60">
                  @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                <div class="cursor-pointer input-group input-group-merge">
                    <span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                    <input type="text" class="cursor-pointer form-control bg-label-warning text-black month_filter_common_class" value="<?php echo $month_filter ?? date("M-Y"); ?>" readonly onchange="month_filter(this.value)">
                    <!--<span class="input-group-text bg-label-warning text-black"><i class="mdi mdi-menu-down fs-4"></i></span>-->
                </div>
                @endif
            </div>
            
            <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white me-2 mb-2" id="filter">
                <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Filter"><i class="mdi mdi-filter-outline text-center"></i></span>
            </a>
            
            

        </div>
    </div>
    
   
   
    <div class="card-body px-4 py-0 pt-2">
        
        <div class="d-flex flex-wrap align-items-center mb-2">
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Incoming Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('F');}}</span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/phdizone_images/calls/incoming_call.ico')}}" alt="Incoming Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-black fs-6" style="background-color: #50CD89 !important;">{{  sprintf("%02d",$incoming_call_count)  }}</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Outgoing Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('F');}}</span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/phdizone_images/calls/outgoing_call.ico')}}" alt="Outgoing Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <label class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Outgoing Calls" style="background-color: #FFA500 !important;">{{ sprintf("%02d",$outgoingcall_count) }}</label>
                    <label class="fw-bold text-black fs-5 ms-1 me-1">/</label>
                    <label class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Outgoing Call Ratio" style="background-color: #FFA500 !important;">{{ number_format($outgoing_call_ratio,2) }} %</label>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2">
                <div class="text-dark fw-semibold fs-6 mb-1">Missed Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('F');}}</span> )</div>
                <div class="mb-3">
                    <img src="{{asset('assets/phdizone_images/calls/missed_call.ico')}}" alt="Missed Call Icon" class="text-black fw-bold" style="height: 35px !important;Width: 35px !important;">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Missed Calls" style="background-color: #4CD2FC !important;">{{ sprintf("%02d",$missedcall_count) }}</div>
                    <label class="fw-bold text-black fs-5 ms-1 me-1">/</label>
                    <div class="badge rounded fw-bold text-black fs-6" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Average Missed Call Ratio" style="background-color: #4CD2FC !important;">{{ number_format($missed_call_ratio,2) }} %</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                <div class="text-dark fw-semibold fs-6 mb-1">Rejected Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('F');}}</span> )</div>
                <div class="mb-3">
                    <img src="{{asset('assets/phdizone_images/calls/reject_call.ico')}}" alt="Rejected Call Icon" class="text-black fw-bold" style="height: 35px !important;Width: 35px !important;">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #9F0A22 !important;">{{  sprintf("%02d",$rejected_call_count)  }}</div>
                </div>
            </a>
            <a href="javascript:;" class="text-center border border-2 p-2 me-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Number of Leads">
                <div class="text-dark fw-semibold fs-6 mb-1">Dialed Calls</div>
                <div class="text-black fw-semibold fs-7 mb-4">( <span class="text-info">{{\Carbon\Carbon::createFromFormat('m', $month)->format('F');}}</span> )</div>
                <div class="mb-4">
                    <img src="{{asset('assets/phdizone_images/calls/dialed_call.ico')}}" alt="Dialed Call Icon" class="w-40px h-40px text-black fw-bold">
                </div>
                <div class="d-block">
                    <div class="badge rounded fw-bold text-white fs-6" style="background-color: #1855FD !important;">{{  sprintf("%02d",$dialedcall_count)  }}</div>
                </div>
            </a>
        </div>
        
        <div class="filter_tbox" style="display: none;">
          <form id="filter_form" method="POST" action="{{ route('lead-management-manage-calls') }}" autocomplete="off">
            @csrf
            <div class="row py-1">
                <input type="hidden" name="year" value="{{$year}}">
                <input type="hidden" name="month" value="{{$month}}">
                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                <input type="hidden" name="filter_on" value="1">
                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                    <select id="status_fill" name="status_fill" class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="0" {{$status_fill == "0" ? "selected" :""}}>Outgoing Call</option>
                        <option value="4" {{$status_fill == "4" ? "selected" :""}}>Dialed Call</option>
                        <option value="1" {{$status_fill == "1" ? "selected" :""}}>Incoming Call</option>
                        <option value="2" {{$status_fill == "2" ? "selected" :""}}>Missed Call</option>
                        <option value="3" {{$status_fill == "3" ? "selected" :""}}>Rejected Call</option>
                    </select>
                </div>

                <div class="col-lg-3 mb-2">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Callers</label>
                    <select id="staff_fill" name="staff_fill" class="select3 form-select">
                        <option value="" selected>All</option>
                        @foreach ($staff_list as $stf_list)
                            <option value="{{ $stf_list->staff_id }}" @if($stf_list->staff_id==
                              $staff_fill)
                              selected @endif>{{ $stf_list->staff_name }}</option>
                            @endforeach
                    </select>
                </div>
            </div>
            <div class="d-flex justify-content-end mb-2">
              <a href="{{ url('/manage_calls') }}" type="button"
                  class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
              </a>
              <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
            </div>
          </form>
        </div>
        
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center ">
                    <div class="">
                        @php $perpage_count = $perpage ? $perpage : 10; @endphp
                        <div>
                            <span>Show</span>
                            <br>
                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                @php
                                $options = [10, 25, 100, 500]; // Define available options
                                @endphp
                                @php foreach ($options as $option): @endphp
                                <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                                    @php echo $option; @endphp
                                </option>
                                @php endforeach; @endphp
                            </select>
                        </div>
                    </div>
                    <div class="">
                        <form id="search_form" method="POST" action="/manage_calls">
                            @csrf
                            <div class="d-flex align-items-center gap-2">
                                <div class="">
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="1">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input
                                    type="text"
                                    class="form-control"
                                    id="lead_fill" name="call_fill" value="{{ $call_fill ?? "" }}"
                                    placeholder="Enter sales - Name/ Mob. No"
                                />
                                </div>
                                <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1" onclick="search_filter_func()">Search</button>
                                <a href="{{ url('/manage_calls') }}" type="button"
                                    class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 " data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reset"><span class="mdi mdi-refresh fs-6"></span>
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
                <table class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-100px px-2">Staff</th>
                            <th class="min-w-100px px-2">Communicator</th>
                            <th class="text-start" style="width: 10%;">Lead status</th>
                            <th class="min-w-100px px-1">Call Date</th>
                            <th class="min-w-100px px-1">Start Time</th>
                            <th class="min-w-100px px-1">End Time</th>
                            <th class="min-w-100px px-1">Duration</th>
                            <th class="min-w-100px px-1">Status</th>
                            @if(auth()->user()->hasPermission($module_name, 'Location', $menu_name))
                            <th class="min-w-50px px-1">Location</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @php
                            $startTime = microtime(true);
                        @endphp
                        @if (isset($calls))
                        @foreach ($calls as $call)
                          @php
                            if($call->call_status==0){
                              $bgColor="";
                              $img="outgoing_call.ico";
                            }elseif($call->call_status==1){
                              $bgColor="";
                              $img="incoming_call.ico";
                            }elseif($call->call_status==2){
                              $bgColor="#ffcf9f !important;";
                              $img="missed_call.ico";
                            }elseif($call->call_status==3){
                              $bgColor="#FF7979 !important;";
                              $img="rejected_call.ico";
                            }elseif($call->call_status==4){
                              $bgColor="";
                              $img="dialed_call.ico";
                            }
                      
                                $last_login_data = $lastLoginDataMap[$call->staff_phone_no] ?? null;
                              
                                 $last_login_date = $last_login_data ? $last_login_data->last_sync_date :'';
                                 $last_login_time = $last_login_data? $last_login_data->last_sync_time :'';
                               if ($last_login_date && $last_login_time) {
                                    // Combine the date and time to form a DateTime object
                                    $last_login_datetime = new DateTime($last_login_date . ' ' . $last_login_time);
                                    
                                    // Get the current date and time
                                    $current_datetime = new DateTime();
                                    
                                    // Calculate the difference between current time and last login time
                                    $interval = $current_datetime->diff($last_login_datetime);
                            
                                    // Initialize an array to hold the duration breakdown
                                    $duration = [];
                            
                                    // Check for years
                                    if ($interval->y > 0) {
                                        $duration[] = $interval->y . ' year' . ($interval->y > 1 ? 's' : '');
                                    }
                            
                                    // Check for months
                                    if ($interval->m > 0) {
                                        $duration[] = $interval->m . ' month' . ($interval->m > 1 ? 's' : '');
                                    }
                            
                                    // Check for days
                                    if ($interval->d > 0) {
                                        $duration[] = $interval->d . ' day' . ($interval->d > 1 ? 's' : '');
                                    }
                            
                                    // Check for hours
                                    if ($interval->h > 0) {
                                        $duration[] = $interval->h . ' hour' . ($interval->h > 1 ? 's' : '');
                                    }
                            
                                    // Check for minutes
                                    if ($interval->i > 0) {
                                        $duration[] = $interval->i . ' minute' . ($interval->i > 1 ? 's' : '');
                                    }
                            
                                    // If no significant time difference (seconds)
                                    if ($interval->s > 0 && empty($duration)) {
                                        $duration[] = $interval->s . ' second' . ($interval->s > 1 ? 's' : '');
                                    }
                            
                                    // If no significant time difference at all
                                    if (empty($duration)) {
                                        $duration[] = 'Just now';
                                    }
                            
                                    // Combine all the parts with spaces
                                    $duration = implode(' ', $duration);
                            
                                } else {
                                    $duration = '-';
                                }
                          @endphp
                          <tr style="background: {{ $bgColor }}">
                          <td class="px-1">
                                  <div class="d-flex align-items-center px-1">
                                      <div class="symbol symbol-35px border border-gray-400 bg-primary rounded px-1 py-1 me-2">
                                          <div class="image-input image-input-circle" data-kt-image-input="true">
                                              <img src="{{asset('assets/phdizone_images/calls/'.($img))}}" alt="Communicator" class="image-input-wrapper w-20px h-20px" />
                                          </div>
                                      </div>
                                      <div class="mb-0 align-items-center">
                                          <label class="fs-7 me-1">{{ $call->staff_name}}</label>
                                          <div class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">{{ $call->staff_phone_no }}</div>
                                      </div>
                                  </div>
                                @if(isset($last_login_date))
                                <div class="ms-4">
                                    <span data-bs-toggle="tooltip" data-bs-placement="right" title="Last Login Date & Time">
                                        <span class=" text-info fs-8 fw-bold">{{ $last_login_date? date($common_date_format, strtotime($last_login_date)) : ''; }}</span>
                                        <span class="text-info fs-8 fw-bold">{{ $last_login_time ? date('h:i A', strtotime($last_login_time)) : ''; }}</span>
                                    </span>
                                    <div class="text-danger fs-8 fw-bold">{{$duration}} ago</div>
                                </div>
                                @endif
                              </td>
                              
                              
                              <td class="px-1">
                                   @if($call->lead_name)
                                  <div class="d-flex align-items-center px-1">
                                      <div class="mb-0 align-items-center">
                                          <label class="fs-7 me-1">{{ $call->lead_name ? $call->lead_name :($call->customer_name ? $call->customer_name :"Unknown")}}</label>
                                          <div class="d-block text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">{{ $call->customer_phone_no }}</div>
                                          <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-info rounded fw-bold fs-8 mb-2 mt-1 px-1 ">{{ $call->lead_staff ?? 'Old Staff'}}</span></div>
                                      </div>
                                  </div>
                                   @elseif($call->internal_user_name)
                                  <div class="d-flex align-items-center px-1">
                                      <div class="mb-0 align-items-center">
                                          <label class="fs-7 me-1">{{ $call->internal_user_name ? $call->internal_user_name :($call->customer_name ? $call->customer_name :"Unknown")}}</label>
                                          <div class="d-block text-primary fs-8 mb-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">{{ $call->customer_phone_no }}</div>
                                          <div class="d-block text-primary fs-8"  title="Created By"><span class="bg-label-warning rounded fw-bold fs-8 mb-2 mt-1 px-1 ">Internal</span></div>
                                      </div>
                                  </div>
                                  @else
                                  <div class="d-flex align-items-center px-1">
                                      <div class="mb-0 align-items-center">
                                          <label class="fs-7 me-1">{{ $call->lead_name ? $call->lead_name :($call->customer_name ? $call->customer_name :"Unknown")}}</label>
                                          <label class="d-block text-primary fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile No">
                                            <div class="d-flex align-items-center justify-content-center gap-2">
                                                {{ $call->customer_phone_no }}
                                                 @if(\Carbon\Carbon::parse($call->call_start_date)->lt(\Carbon\Carbon::now()->subHours(24)))
                                                <a href="javascript:;" class="fw-bold me-2 mb-2 btn btn-icon btn-sm"
                                                    data-bs-toggle="modal" data-bs-target="#kt_modal_lead_convert"
                                                    onclick="convertLeadOrSpam('{{ $call->sno }}','{{ $call->customer_phone_no }}','{{ $call->lead_name ? $call->lead_name :($call->customer_name ? $call->customer_name :"Unknown")}}')">
                                                    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>
                                                </a>
                                                @endif
                                            </div>
                                          </label>
                                      </div>
                                  </div>
                                  @endif
                              </td>
                              <td>
                                @if($call->lead_name)
                                    @if( $call->lead_status == 0)
                                    <label class="badge bg-info text-white rounded fw-bold fs-8 mb-2" >Active</label>
                                    @elseif( $call->lead_status == 1)
                                    <label class="badge bg-warning text-white rounded fw-bold fs-8 mb-2 " >In Active</label>
                                    @elseif( $call->lead_status == 4)
                                    <label class="badge bg-success text-white rounded fw-bold fs-8 mb-2" >Customer</label>
                                    @elseif( $call->lead_status == 10)
                                    <label class="badge bg-success text-white rounded fw-bold fs-8 mb-2" >Old Customer</label>
                                    @elseif($call->lead_status == 5 && ($call->drop_verified == 0 || $call->drop_tl_verified == 0) ) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead Awaiting </label>
                                    @elseif($call->lead_status == 5 && $call->drop_verified == 1 && in_array(auth()->user()->role_id ?? 12, [12,18,20,21])) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead </label> 
                                    @elseif($call->lead_status == 5 && $call->drop_verified == 1 && !in_array(auth()->user()->role_id ?? 12, [12,18,20,21])) 
                                    <label class="badge bg-danger text-white rounded fw-bold fs-8 mb-2" > Dead Lead Awaiting </label> 
                                    @elseif( $call->lead_status == 7 && ($call->spam_verified == 0 || $call->spam_tl_verified == 0) ) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam Awaiting </label> 
                                    @elseif($call->lead_status == 7 && $call->spam_verified == 1 && in_array(auth()->user()->role_id ?? 12, [12,18,20,21])) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam </label> 
                                    @elseif($call->lead_status == 7 && $call->spam_verified == 1 && !in_array(auth()->user()->role_id ?? 12, [12,18,20,21])) 
                                    <label class="badge bg-primary text-white rounded fw-bold fs-8 mb-2" > Spam Awaiting </label>
                                    @elseif( $call->lead_status == 8)
                                    <label class="badge bg-warning text-primary rounded fw-bold fs-8 mb-2" >OLD Lead</label>
                                @endif
                                @else
                                -
                                @endif
                            </td>
                              <td class="px-1">
                                  <label class="text-black fs-7 fw-semibold">{{ date($common_date_format, strtotime($call->call_start_date)) }}</label>
                            </td>
                              <td class="px-1">
                                  <label class="text-info fs-7 fw-semibold">{{ date('h:i A', strtotime($call->call_start_time)) }}</label>
                              </td>
                              <td class="px-1">
                                  <label class="text-danger fs-7 fw-semibold">{{ $call->call_end_time ? date('h:i A', strtotime($call->call_end_time)) : '-'; }}</label>
                              </td>
                              <td class="px-1">
                                  <label class="badge bg-warning text-black fs-7 fw-bold">{{ $call->call_duration ? $call->call_duration :"-" }}</label>
                              </td>
                              <td class="px-1">
                                @if($call->call_status==0)
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold" style="background-color: #FFA500 !important;">Outgoing Call</label>
                                @elseif ($call->call_status==1)
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold" style="background-color: #50CD89 !important;">Incoming Call</label>
                                @elseif ($call->call_status==2)
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold" style="background-color: #4CD2FC !important;">Missed Call</label>
                                @elseif ($call->call_status==3)
                                <label class="badge bg-danger rounded text-white fs-7 fw-semibold" style="background-color: #9F0A22 !important;">Rejected Call</label>
                                @elseif($call->call_status==4)
                                <label class="badge bg-warning rounded text-white fs-7 fw-semibold" style="background-color: #1855FD !important;">Dialed Call</label>
                                @endif
                              </td>
                               @if(auth()->user()->hasPermission($module_name, 'Location', $menu_name))
                              <td>
                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_call_location" class="border border-gray-400 rounded px-1 py-2"   onclick="call_location_func({{$call->latitude ? $call->latitude : '0'}},{{$call->longitude ? $call->longitude : '0'}})">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Location"> <i class="mdi mdi-map-marker-radius text-gray fs-4"></i></span>
                                </a>
                              </td>
                              @endif
                          </tr>
                        @endforeach
                        @endif
                    
                    </tbody>
                </table>
            </div>
            @php
                $endTime = microtime(true);
                $executionTime = $endTime - $startTime;
                // Convert to milliseconds (optional)
                $executionTimeMs = number_format($executionTime * 1000, 2);
            @endphp
            
            <!--<p class="text-danger fw-bold">Render Time: {{ $executionTimeMs }} ms</p>-->
            <div class="mt-4">
              {{ $calls->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>

<!--begin::Modal - Convert to Lead Or Spam-->
<div class="modal fade" id="kt_modal_lead_convert" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md" id="leadConvertModal">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Lead Convert</h3>
                </div>
                <form id="leadSpamForm" action="{{ route('spam_lead_convert_calls') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="container" id="swal2-html-container" style="display: block;">
                    <div class="mb-4 fw-bold fs-6 text-center">
                        <span>Are you sure you want to Convert <b class='text-danger' id="lead_convert_no"></b> Lead?</span>
                    </div>
                    <div class="row mb-4">
                        <input type="hidden" id="cloud_call_id" name="cloud_call_id" value=""/>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold d-block">Convert To<span class="text-danger">*</span></label>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="lead_convert_to" id="inlineRadio1" value="1"  checked/>
                                <label class="form-check-label" for="inlineRadio1">Lead</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="lead_convert_to" id="inlineRadio2" value="2" />
                                <label class="form-check-label" for="inlineRadio2">Spam</label>
                            </div>
                            <div class="text-danger" id="lead_convert_to_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold" id="lead_name_label">Lead Name</label><span class="text-danger">*</span>
                            <input type="text" class="form-control" id="lead_name_create" name="lead_name" placeholder="Enter Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                            <div class="text-danger" id="lead_name_create_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            {{-- {{ $reasonList }} --}}
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Sales Person <span class="text-danger">*</span></label>
                            <select id="sales_staff_add" name="sales_staff_add" class="select3 form-select" data-parent-dropDown="#kt_modal_lead_convert">
                            </select>
                            <div class="text-danger" id="sales_staff_add_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="spam_reason_select_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Reason <span class="text-danger">*</span></label>
                            <select id="spam_reason" name="spam_reason" class="select3 form-select" onchange="toggleReason(this.value)" data-parent-dropDown="#kt_modal_lead_convert">
                                <option value="">Select Reason</option>
                                @if (isset($reasonList) && count($reasonList) > 0)
                                @foreach ($reasonList as $reason_spam)
                                <option value="{{ $reason_spam->reason_name }}" data-comments-check="{{ $reason_spam->comments_check }}">
                                    {{ $reason_spam->reason_name }}
                                </option>
                                @endforeach
                                @endif
                                <option value="1">Others</option>
                            </select>
                            <div class="text-danger" id="reason_select_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="reason_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Other Reason <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="reason_text" id="reason_text" value="" placeholder="Enter Reason" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                            <div class="text-danger" id="reason_text_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3" id="comments_div" style="display: none;">
                            <label class="text-dark mb-1 fs-6 fw-semibold required">Comments <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="spam_comments" id="spam_comments" value="" placeholder="Enter Comments" oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                            <div class="text-danger" id="spam_comments_err"></div>
                        </div>
                        <div class="text-center mt-2">
                            <button type="submit" class="btn btn-danger me-3" id="submitConvert" onclick="convertValidation(event)">Yes, Convert!</button>
                            <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                        </div>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
    </div>
<!--end::Modal - Convert to Lead Or Spam-->
</div>

  <!--begin::Modal - Staff Call Location-->
  <div class="modal fade" id="kt_modal_call_location" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-4 text-center">
                        <h3 class="text-center mb-4 text-black" id="call_location_name">Call Location</h3>
                    </div>
                    <div class="row mb-4">
                        <div id="call-location-data"></div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Staff Call Location-->

<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
  function sort_filter(val) {
    if (val != "") {
      $('.sorting_filter_class').val(val);
      $('#filter_form').submit();
    } else {
      $('.sorting_filter_class').val(10);
      $('#filter_form').submit();
    }
  }
</script>
 <script>
      function month_filter(val) {
        var url = "{{ url('') }}";
        window.location = '/manage_calls/?month_filter=' + val;
        
    }

    </script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#lead_week_st_dt_fill').val(firstday);
            $('#lead_week_ed_dt_fill').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
  </script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_"
        , }
        , "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
    function call_location_func(latitude, longitude){
        console.log(longitude)
        var location =`<iframe width="100%" height="500" src="https://maps.google.com/maps?q=${latitude},${longitude}&hl=es;z=14&output=embed"></iframe>`
            $('#call-location-data').html(location);
    }

</script>

<script>
    $.ajax({
        url: "{{ route('sales_staff') }}",
        type: "GET",
        success: function(response) {
            if (response.status === 200 && response.data) {
                let select = document.getElementById('sales_staff_add');
                select.innerHTML = ''; // Clear existing options
                // Add the empty option
                let defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = 'Select Sales Person';
                select.appendChild(defaultOption);
                
                response.data.forEach(staff => {
                    if(staff.department_id === 1){
                        let option = document.createElement('option');
                        option.value = staff.sno;
                        option.textContent = staff.staff_name + " - "+staff.position_name;
                        select.appendChild(option);
                    }
                });
            } else {
                let select = document.getElementById('sales_staff_add');
                select.innerHTML = ''; // Clear existing options
                // Add the empty option
                let defaultOption = document.createElement('option');
                defaultOption.value = '';
                defaultOption.textContent = 'Select Sales Person';
                select.appendChild(defaultOption);

            }
        },
        error: function(error) {

            }
    });

    function convertLeadOrSpam(id, mobile,name) { 
        // alert(mobile);
        $('#cloud_call_id').val(id);
        $('#lead_name_create').val(name);
        $('#lead_convert_no').html(mobile);
    }
  
    function convertValidation(event) {
        var err = 0;
        
        var lead_name_create = document.getElementById("lead_name_create");

        if (lead_name_create.value === "") {
            document.getElementById('lead_name_create_err').innerHTML = 'Name is required...!';
            err++;
        } else {
            document.getElementById('lead_name_create_err').innerHTML = '';
        }


        var sales_staff_add = document.getElementById("sales_staff_add");

        if (sales_staff_add.value === "") {
            document.getElementById('sales_staff_add_err').innerHTML = 'Sales Person is required...!';
            err++;
        } else {
            document.getElementById('sales_staff_add_err').innerHTML = '';
        }
        
        var lead_convert_to = document.querySelector('input[name="lead_convert_to"]:checked').value;
        if(lead_convert_to==2){
        // Get other fields and validate
        var spam_reason = document.getElementById("spam_reason");
        var reason_text = document.getElementById("reason_text");
        var spam_comments = document.getElementById("spam_comments");

        // Clear error messages for reason and comments
        document.getElementById('reason_text_err').innerHTML = '';
        document.getElementById('spam_comments_err').innerHTML = '';

        // Check if spam reason is provided
        if (!spam_reason || spam_reason.value === "") {
            // alert('reason valid');
            document.getElementById('reason_select_err').innerHTML = 'Reason is required...!';
            err++;
        } else if (spam_reason.value === "1") {
            // alert('other reason valid');
            if (!reason_text || reason_text.value.trim() === "") {
                document.getElementById('reason_text_err').innerHTML = 'Other reason is required...!';
                err++;
            }
        }
        
        // Check if the selected reason's comments_check is 1 before validating comments
        var selectedReasonOption = spam_reason.options[spam_reason.selectedIndex];
        var commentsCheck = selectedReasonOption ? selectedReasonOption.getAttribute('data-comments-check') : null;
        
        }else{
            document.getElementById('reason_text_err').innerHTML = '';
            document.getElementById('spam_comments_err').innerHTML = '';
        }

        if (commentsCheck == "1" && (!spam_comments || spam_comments.value.trim() === "")) {
            // alert('comments valid');
            document.getElementById('spam_comments_err').innerHTML = 'Comments are required...!';
            err++;
        }

        if (err === 0) {
            $('#leadSpamForm').submit();
            $('#submitConvert').prop('disabled', true);
        } else {
            $('#submitConvert').prop('disabled', false);
            
            event.preventDefault();
        }
    }
</script>

<script>
    function toggleReason(value) {
      
      document.getElementById('reason_text_err').innerHTML = '';
      document.getElementById('spam_comments_err').innerHTML = '';
      document.getElementById('sales_staff_add_err').innerHTML = '';
      document.getElementById('lead_name_create_err').innerHTML = '';
       
        var convertValue = document.querySelector('input[name="lead_convert_to"]:checked').value;
        var spamReasonSelect = document.getElementById('spam_reason_select_div');
        var spamReasonDiv = document.getElementById('reason_div');
        var spamReasonText = document.getElementById('reason_text');
        var spamCommentsDiv = document.getElementById('comments_div');
        var selectedOption = document.querySelector('#spam_reason option:nth-child(' + (document.getElementById('spam_reason').selectedIndex + 1) + ')');
        var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

        if (convertValue == '2') {
        spamReasonSelect.style.display = 'block';
        $('#lead_name_label').html('Spam Name');
        
        } else {
        spamReasonSelect.style.display = 'none';
        $('#lead_name_label').html('Lead Name');
        }

        // Show or hide reason div and set required attribute
        if (value == '1') {
            spamReasonDiv.style.display = 'block';
            spamReasonText.setAttribute('required', 'required');
        } else {
            spamReasonDiv.style.display = 'none';
            spamReasonText.removeAttribute('required');
        }

        // Show or hide comments div based on selected reason
        if (commentsCheck == '1') {
            spamCommentsDiv.style.display = 'block';
        } else {
            spamCommentsDiv.style.display = 'none';
        }
    }

    // Add event listeners to the radio buttons to trigger toggleReason when changed
    document.querySelectorAll('input[name="lead_convert_to"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
        toggleReason(document.getElementById('spam_reason').value);
    });
    });

    // Initialize display based on the default selected radio button value
    window.addEventListener('DOMContentLoaded', function() {
    toggleReason(document.getElementById('spam_reason').value);
    });
  </script>

@endsection