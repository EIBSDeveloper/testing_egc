@extends('layouts/layoutMaster')

@section('title', 'Daiy Task')

@section('vendor-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
@vite(['resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/sortablejs/sortable.js',])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

<style>
    .skeleton-loader-container {
    padding: 1rem;
    }
    
    .skeleton-service-card {
    background: #fff;
    border-radius: 8px;
    padding: 1rem;
    margin-bottom: 1rem;
    border: 1px solid #e9ecef;
    animation: skeleton-pulse 1.5s ease-in-out infinite;
    }
    
    .skeleton-header {
    margin-bottom: 1rem;
    }
    
    .skeleton-line {
    height: 12px;
    background: #e9ecef;
    border-radius: 4px;
    margin-bottom: 0.5rem;
    }
    
    .skeleton-title {
    width: 70%;
    height: 16px;
    }
    
    .skeleton-subtitle {
    width: 50%;
    }
    
    .skeleton-badges {
    display: flex;
    gap: 0.5rem;
    }
    
    .skeleton-badge {
    width: 80px;
    height: 24px;
    background: #e9ecef;
    border-radius: 12px;
    }
    
    @keyframes skeleton-pulse {
    0% { opacity: 1; }
    50% { opacity: 0.7; }
    100% { opacity: 1; }
    }

    /* Date Picker Styles */
    .date-picker-container .card {
        border: none;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-radius: 12px;
        border-left: 4px solid #4361ee;
    }
    
    .date-picker-container .input-group-text {
        background-color: #4361ee;
        color: white;
        border: none;
        border-radius: 8px 0 0 8px;
    }

    .date-picker-container .form-control {
        border: 1px solid #e0e0e0;
        border-radius: 0 8px 8px 0;
        padding: 10px 15px;
        font-size: 1rem;
    }

    .date-picker-container .form-control:focus {
        border-color: #4361ee;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }

    .date-picker-container .progress-container {
        height: 8px;
        background-color: rgba(0, 0, 0, 0.08);
        border-radius: 10px;
        overflow: hidden;
        position: relative;
    }

    .date-picker-container .progress-bar {
        height: 100%;
        width: 0;
        background: linear-gradient(90deg, #4361ee 0%, #4cc9f0 100%);
        border-radius: 10px;
        transition: width 0.8s cubic-bezier(0.22, 0.61, 0.36, 1);
        position: relative;
    }

    .date-picker-container .progress-bar::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        animation: shimmer 2s infinite;
    }

    @keyframes shimmer {
        0% {
            transform: translateX(-100%);
        }
        100% {
            transform: translateX(100%);
        }
    }

    /* Date Display Styles */
    .date-display-container .card {
        border: none;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-radius: 12px;
        border-left: 4px solid #4361ee;
        background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
    }

    .date-display-container .date-badge {
        width: 60px;
        height: 60px;
        border-radius: 12px;
        background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        box-shadow: 0 4px 8px rgba(67, 97, 238, 0.3);
    }

    .date-display-container .progress-container {
        height: 12px;
        background-color: rgba(0, 0, 0, 0.08);
        border-radius: 10px;
        overflow: hidden;
        position: relative;
    }

    .date-display-container .progress-bar {
        height: 100%;
        width: 0;
        background: linear-gradient(90deg, #4361ee 0%, #4cc9f0 100%);
        border-radius: 10px;
        transition: width 0.8s cubic-bezier(0.22, 0.61, 0.36, 1);
        position: relative;
    }

    .date-display-container .progress-bar::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        animation: shimmer 2s infinite;
    }
</style>

<div class="card card-action mb-2 rounded">
    @php
    $helper = new \App\Helpers\Helpers();
    @endphp
     <div class="card-header border-bottom px-4 pb-1 ">
        <div class="card-action-title">
            <h5 class="card-title my-1">Weekly Task</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex align-items-center justify-content-end gap-5 ">
                 <div class="input-group">
                    <span class="input-group-text">
                        <i class="mdi mdi-calendar"></i>
                    </span>
                    <input type="text" class="form-control datepicker" id="task_date_picker" readonly placeholder="Select date">
                </div>
            </div>
        </div>
    </div>
</div>
    <div class="px-2 py-2" style="background:#f7f7f9;">
        <input type="hidden" name="task_date" id="task_date">
        <div class="date-display-container mb-4">
            <div class="card">
                <div class="card-body py-3">
                    <div class="row align-items-center">
                        <div class="col-lg-8">
                            <div class="d-flex align-items-center gap-3">
                                <div class="date-badge">
                                    <i class="mdi mdi-calendar-check fs-1 text-white"></i>
                                </div>
                                <div>
                                    <h5 class="mb-1 text-black">Selected Date</h5>
                                    <div class="d-flex align-items-center gap-2">
                                        <span class="fs-4 fw-bold text-primary" id="selected_date_display">-</span>
                                        <span class="badge bg-light text-dark fs-6" id="selected_day_display">-</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="d-flex align-items-center gap-3">
                                <div class="progress-container" style="width: 100%;">
                                    <div class="progress-bar" id="date_progress_bar" style="width: 0%;"></div>
                                </div>
                                <span class="fs-6 fw-semibold" id="date_hours_display">0hrs / 7hrs</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-4">
            {{-- ! STAFFS ! --}}
            <div class="col-lg-3">
                <div class="card dashboard-card rounded staff-card">
                <div class="card-header pb-4">
                    <h2 class="fw-semibold fs-6 d-flex justify-content-start text-black align-items-center gap-2">
                        <i class="mdi mdi-account-group fs-3"></i> Production Staff
                    </h2>
                    <input type="text" class="form-control"  placeholder="Search Staff" id="staff-search" />
                </div>
                <div class="card-body-mini">
                    <input type="hidden" name="pro_staff_id" id="pro_staff_id">
                    <div class="content-container">
                        <div style="max-height: 445px;overflow-x:hidden;overflow-y:auto;min-height: 445px;" id="production-staff-container">
                            <!-- PRODUCTION STAFF CONTAINER -->
                        </div>
                    </div>
                </div>
            </div>
            </div>
            {{-- ! SERVICES ! --}}
            <div class="col-lg-3">
                <div class="card dashboard-card rounded service-card">
                <div class="card-header">
                    <h2 class="fw-semibold fs-6 d-flex justify-content-start text-black align-items-center gap-2">
                        <i class="mdi mdi-package-variant fs-3"></i> Services
                    </h2>
                </div>
                <div class="card-body-mini">
                    <input type="hidden" name="service_id" id="service_id">
                    <div class="content-container">
                        <div style="max-height:490px; overflow-x:hidden; overflow-y:auto; min-height:490px;" id="service-container">
                            <!-- SERVICE CONTAINER -->
                        </div>
                    </div>
                </div>
            </div>
            </div>
            {{-- ! TASKS ! --}}
            <div class="col-lg-3">
                <div class="card dashboard-card rounded task-card">
                <div class="card-header">
                    <h2 class="fw-semibold fs-6 d-flex justify-content-start text-black align-items-center gap-2">
                        <i class="mdi mdi-clipboard-alert fs-3"></i> Tasks
                    </h2>
                </div>
                <div class="card-body-mini">
                    <input type="hidden" id="selected_task_id" name="selected_task_id" >
                    <div class="content-container">
                        <div style="max-height:490px; overflow-x:hidden; overflow-y:auto; min-height:490px;" id="task-container" >
                            <div class="empty-state" id="drag-empty-state">
                                <i class="fas fa-list-alt"></i>
                                <label>Select a Service</label>
                                <p class="mt-2">Choose a service to view available tasks</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            {{-- ! SELECTED TASKS ! --}}
            <div class="col-lg-3">
                <div class="card dashboard-card rounded selected-card">
                <div class="card-header">
                    <h2 class="fw-semibold fs-6 d-flex justify-content-start text-black align-items-center gap-2">
                        <i class="mdi mdi-clipboard-check fs-3"></i> Selected Tasks
                    </h2>
                </div>
                <div class="card-body-mini">
                    <div class="content-container">
                        <div style="max-height:490px; overflow-x:hidden; overflow-y:auto; min-height:490px;" id="drop-container">
                            <div class="empty-state" id="drop-empty-state">
                                <i class="fas fa-hand-point-left"></i>
                                <label>Drag & Drop Tasks</label>
                                <p class="mt-2">Drag tasks here to assign them</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>


<!--begin::Modal - Task Split Modal-->
<div class="modal fade" id="kt_modal_task_split" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Distribute Workload</h3>
                </div>
                <div class="row">
                    <div class="info-card col-lg-6">
                        <h5 class="d-flex gap-2 text-danger">
                            <i class="fas fa-info-circle"></i>Task Details
                        </h5>
                        <div class="row mb-2">
                            <div class="col-lg-12 mb-2">
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Staff</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_staff">-</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold"><span class="text-truncate" id="split_customer">-</span> <br> ( <span class="text-primary" id="split_customer_id">-</span> )</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Service</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_product_name">-</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Variant</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_variant">-</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Variable</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_variable">-</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Task</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold"><span class="text-truncate mb-1" id="split_task_name">-</span> <br> ( <span class="text-info" id="split_task_id">-</span> )</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Total <span id="split_page_label">Pages</span></label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_total_pages">-</label>
                                </div>
                                <div class="row mb-3">
                                    <label class="col-4 text-dark fs-6 fw-semibold">Total Hours</label>
                                    <label class="col-1 text-black fs-6 fw-bold">:</label>
                                    <label class="col-6 text-black fs-6 fw-bold" id="split_total_hours">-</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-card col-lg-6">
                        <h5 class="d-flex gap-2 text-danger">
                            <i class="fas fa-code-branch"></i>Task Allocation
                        </h5>
                    
                        <form id="taskSplitForm">
                            <div class="row">
                                <div class="col-lg-6 mb-3">
                                    <input type="hidden" name="total_page_or_per" id="total_page_or_per">
                                    <input type="hidden" name="total_hours" id="total_hours">
                                    <label class="text-black mb-1 fs-6 fw-semibold"><span id="create_task_page_or_per">Pages</span> Allocation<span class="text-danger">*</span></label>
                                    <input type="hidden" name="page_or_per_value" id="page_or_per_value">
                                    <input type="text" class="form-control" id="page_allocate" oninput="this.value = this.value.replace(/[^0-9]/g, '');" maxlength="3" placeholder="Enter Page Allocation" disabled />
                                    <div id="page_allocate_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Time Allocation<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="time_allocate"  maxlength="5" placeholder="Enter Time Allocation" />
                                    <div id="time_allocate_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Additional Instructions</label>
                                    <textarea class="form-control" rows="3" name="description" id="description"
                                        placeholder="Enter Your Additional Instructions"></textarea>
                                </div>
                            </div>
                    
                            <!-- Allocation Visualization -->
                            <div class="allocation-visual">                
                                <div class="allocation-summary">
                                    <div class="summary-card">
                                        <div class="summary-value" id="total_page_or_per_all">-</div>
                                        <div class="summary-label">Total <span class="allocation_page_or_per">Pages</span></div>
                                    </div>
                                    <div class="summary-card allocated">
                                        <div class="summary-value" id="allocated_page_or_per_all">-</div>
                                        <div class="summary-label">Allocated <span class="allocation_page_or_per">Pages</span></div>
                                    </div>
                                    <div class="summary-card remaining">
                                        <div class="summary-value" id="remaining_page_or_per_all">-</div>
                                        <div class="summary-label">Remaining <span class="allocation_page_or_per">Pages</span></div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="split_modal_create_btn" class="btn btn-primary d-none" onclick="splitModalValidation()">Create Task</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Task Split Modal -->

<!--begin::Modal - Edit Task Modal-->
<div class="modal fade" id="kt_modal_edit_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Staff Tasks</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="bg-white border border-muted px-4 py-4 rounded">
                            <h5 class="fw-bold fs-4 pb-2 d-flex align-items-center gap-2 mb-4" style="border-bottom: 2px solid #f1f5f9;">
                                <i class="fas fa-user-circle text-primary"></i>Staff Details
                            </h5>
                    
                            <div class="text-center mb-4">
                                <div class="d-flex justify-content-center">
                                    <div class="staff-avatar" id="staff-avatar-modal">-</div>
                                </div>
                                <h4 class="fw-bold fs-4 mb-2 text-black mb-2" id="edit_staff_name">-</h4>
                                <div class="d-flex justify-content-center align-items-center gap-2 mb-3">
                                    <span class="fs-6 fw-semibold d-flex align-items-center gap-2" id="edit_emp_skill">
                                        <i class="fas fa-chart-line"></i>
                                    </span>
                                </div>
                            </div>
                    
                            <div class="d-flex gap-2 mb-4">
                                <div class="hours-card">
                                    <i class="fas fa-clock text-primary fs-4"></i>
                                    <div class="fs-1 fw-bold text-black mt-2" id="edit_total_hrs">5h</div>
                                    <div class="fs-6 fw-semibold text-dark">Allocated Hours</div>
                                </div>
                                <div class="hours-card balance">
                                    <i class="fas fa-hourglass-half text-warning fs-4"></i>
                                    <div class="fs-1 fw-bold text-black mt-2" id="edit_balance_hrs">2h</div>
                                    <div class="fs-6 fw-semibold text-dark">Balance Hours</div>
                                </div>
                            </div>
                    
                            <div class="details-container">
                                <div class="detail-row">
                                    <span class="detail-label">
                                        <i class="fas fa-briefcase"></i> Position
                                    </span>
                                    <span class="detail-value" id="edit_job_position_name">-</span>
                                </div>
                                <div class="detail-row">
                                    <span class="detail-label">
                                        <i class="fas fa-tasks"></i> Assigned Tasks
                                    </span>
                                    <span class="detail-value" id="edit_task_Count">-</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <h5 class="d-flex gap-2 fs-5 fw-bold text-black">
                            <i class="fas fa-code-branch text-primary"></i>Allocated Tasks
                        </h5>
                        <div style="max-height:480px; overflow-x:hidden; overflow-y:auto; min-height:480px;" id="edit_task_container">
                            
                        </div>
                    </div>
                </div>
                <div class="d-flex mt-4 justify-content-center align-items-center mt-4">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary d-none" onclick="closeEditModal()" id="edit_add_new_task">Add New Task</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Task Modal -->

<!-- Toastr Starts -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #313f46;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
<!-- Toastr Ends -->

<!-- EDIT TASK MODAL CSS -->
<style>
    .staff-avatar-modal {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 700;
        font-size: 1.75rem;
        margin: 0 auto 1.5rem;
        box-shadow: 0 10px 15px -3px rgba(102, 126, 234, 0.4);
    }
    
    .form-card {
        background: white;
        border-radius: 12px
        padding: 1.75rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        height: 100%;
        transition: all 0.3s ease;
        border: 1px solid #f1f5f9;
    }
    
    .form-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    }
    
    .detail-row {
        display: flex;
        justify-content: space-between;
        padding: 1rem 0;
        border-bottom: 1px solid #f1f5f9;
    }
    
    .detail-row:last-child {
        border-bottom: none;
    }
    
    .detail-label {
        color: #6c757d;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    
    .detail-value {
        color: #1e293b;
        font-weight: 600;
    }
    
    .hours-card {
        flex: 1;
        background: white;
        border-radius: 10px;
        padding: 1.25rem;
        text-align: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        border-top: 4px solid #4361ee;
    }
    
    .hours-card.balance {
        border-top-color: #f59e0b;
    }
    
    .task-card-modal {
        background: white;
        border-radius: 12px;
        padding: 1.75rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        border-left: 5px solid #f59e0b;
        position: relative;
        margin-bottom: 1.5rem;
    }
    
    .priority-indicator {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.875rem;
        font-weight: 500;
    }
    
    .priority-medium {
        background-color: #fffbeb;
        color: #d97706;
        border: 1px solid #fed7aa;
    }
    
    .metric-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.75rem 1rem;
        border-radius: 10px;
        font-size: 0.875rem;
        font-weight: 500;
        flex: 1;
        justify-content: center;
    }
    
    .progress-metric {
        background-color: #e7f3ff;
        color: #0d6efd;
    }
    
    .hours-metric {
        background-color: #f0f9ff;
        color: #0ea5e9;
    }
</style>

<!-- SPLIT MODAL CSS -->
<style>
    .info-card {
        background: #f8f9fa;
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 1.5rem;
        border-left: 4px solid #4361ee;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
    }
    
    .badge-staff {
        background: linear-gradient(135deg, #ff9a00 0%, #ff6a00 100%);
        color: white;
        font-weight: 600;
        padding: 0.4rem 0.8rem;
        border-radius: 20px;
        font-size: 0.85rem;
    }

    .form-card {
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }
    
    .allocation-visual {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1.5rem 0;
    }
    
    .allocation-summary {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1rem;
        margin-top: 1.5rem;
    }
    
    .summary-card {
        background: white;
        border-radius: 10px;
        padding: 1rem;
        text-align: center;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
        border-top: 4px solid #4361ee;
    }
    
    .summary-card.allocated {
        border-top-color: #4cc9f0;
    }
    
    .summary-card.remaining {
        border-top-color: #f72585;
    }
    
    .summary-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #212529;
        margin: 0.5rem 0;
    }
    
    .summary-label {
        font-size: 0.85rem;
        color: #6c757d;
        font-weight: 500;
    }
</style>

<!-- SORTABLE STYLE -->
<style>
    .dragging {
        background: #e0f7fa !important;
        border: 2px dashed #00acc1 !important;
    }

    .task-item {
        cursor: grab;
        transition: transform 0.2s ease;
    }

    .task-item:active {
        transform: scale(1.02);
    }
</style>

<!-- SORTABLE SCRIPT -->
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const taskContainer = document.getElementById('task-container');
        const dropContainer = document.getElementById('drop-container');
        const emptyState = document.getElementById('drop-empty-state');

        $('#kt_modal_task_split').on('hidden.bs.modal', function () {
            // When modal is closed (Cancel or backdrop)
            dropBackToOriginal();
        });

        function updateTaskBgClass(evt) {
            const item = evt.item; // The dragged DOM element
            const toContainer = evt.to; // container where item is dropped
            const taskSno = item.dataset.sno;
            
            if (toContainer.id === 'drop-container') {
                // Dropped in dropContainer → success
                item.classList.remove('bg-label-danger');
                item.classList.add('bg-label-success');
                $('#selected_task_id').val(taskSno);
            } else if (toContainer.id === 'task-container') {
                // Dropped back in original taskContainer → danger
                item.classList.remove('bg-label-success');
                item.classList.add('bg-label-danger');
                $('#selected_task_id').val('');
            }

            toggleEmptyState();
        }

        function toggleEmptyState() {
            const tasks = Array.from(dropContainer.children).filter(
                el => el !== emptyState
            );
            emptyState.style.display = tasks.length > 0 ? 'none' : 'flex';
        }

        function dropBackToOriginal() {
            const selectedTaskId = $('#selected_task_id').val();

            if (selectedTaskId) {
                const dropContainer = document.getElementById('drop-container');
                const taskContainer = document.getElementById('task-container');
                const item = dropContainer.querySelector(`[data-sno="${selectedTaskId}"]`);

                if (item) {
                    taskContainer.appendChild(item);

                    // Update background class
                    item.classList.remove('bg-label-success');
                    item.classList.add('bg-label-danger');

                    // Clear selected task id
                    $('#selected_task_id').val('');
                }

                // Update empty state visibility
                const emptyState = document.getElementById('drop-empty-state');
                const tasks = Array.from(dropContainer.children).filter(el => el !== emptyState);
                emptyState.style.display = tasks.length > 0 ? 'none' : 'flex';
            }
        }

        function openSplitModal() {
            const selectedTaskID = $('#selected_task_id').val();

            $.ajax({
                url: `/split_task_data_fetch/${selectedTaskID}`,
                method: 'GET',
                success: function (response) {
                    if(response.status === 200) {
                        const data = response.data;

                        $('#split_modal_create_btn').removeClass('d-none');

                        $('#split_staff').html(data.staff_name);
                        $('#split_product_name').html(data.product_name);
                        $('#split_customer').html(data.cus_name);
                        $('#split_customer_id').html(data.customer_id);
                        $('#split_task_name').html(data.task_name);
                        $('#split_task_id').html(data.task_id);
                        $('#split_variant').html(data.variant_name);
                        $('#split_variable').html(data.variable_name);

                        let cat = '';

                        if(data.task_category == 0) {
                            cat = ' Pages';
                            $('#split_page_label').html('Pages');
                            $('#create_task_page_or_per').html('Pages');
                            $('#page_or_per_value').val(0);
                            $('#page_allocate').removeAttr('placeholder').attr('placeholder', 'Enter Page Allocation');
                            $('.allocation_page_or_per').html('Pages');
                        } else if(data.task_category == 1) {
                            cat = '%';
                            $('#split_page_label').html('Percentage');
                            $('#page_or_per_value').val(1);
                            $('#create_task_page_or_per').html('Percentage');
                            $('#page_allocate').removeAttr('placeholder').attr('placeholder', 'Enter Percentage Allocation');
                            $('.allocation_page_or_per').html('Percentage');
                        }

                        $('#split_total_pages').html(data.pages_percentage + cat);
                        $('#total_page_or_per_all').html(data.pages_percentage);
                        $('#total_page_or_per').val(data.pages_percentage);
                        $('#total_hours').val(data.working_hours);
                        $('#allocated_page_or_per_all').html(0);
                        $('#remaining_page_or_per_all').html(0);
                        $('#split_total_hours').html(data.working_hours + ' hrs');
                        $('#time_allocate_err, #page_allocate_err').text('');
                        $('#kt_modal_task_split').modal('show');
                    } else {
                        console.error('Error Fetching Data !');
                    }
                },
                error: function (err) {
                    console.error('Error Fetching Data Due To : ' + err);
                }
            })
        }

        // Enable sorting and dragging between containers
        Sortable.create(taskContainer, {
            group: 'shared', // same group => drag between them
            animation: 150,
            ghostClass: 'dragging',
            filter: '#drag-empty-state',
            preventOnFilter: false,
            onEnd: updateTaskBgClass
        });

        Sortable.create(dropContainer, {
            group: 'shared',
            animation: 150,
            ghostClass: 'dragging',
            filter: '#drop-empty-state',
            preventOnFilter: false,
            onAdd: function (evt) {
                updateTaskBgClass(evt);
                openSplitModal();
            }
        });

        toggleEmptyState();
    });
</script>

<!-- WEEKLY FILTER STYLES -->
<style>
    .progress-container {
        margin-top: 12px;
        height: 8px;
        background-color: rgba(0, 0, 0, 0.08);
        border-radius: 10px;
        overflow: hidden;
        position: relative;
    }
    .progress-bar {
        height: 100%;
        width: 0;
        background: #f0913d;
        border-radius: 10px;
        transition: width 0.8s cubic-bezier(0.22, 0.61, 0.36, 1);
        position: relative;
    }

    .progress-bar::after {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        animation: shimmer 2s infinite;
    }

    .day-card.active .progress-percentage {
        color: rgba(255, 255, 255, 0.95);
    }

    .dashboard-container {
        display: flex;
        gap: 25px;
        overflow-x: auto;
        padding: 10px 5px 25px;
        scrollbar-width: thin;
    }
    
    .dashboard-card {
        border-radius: 20px;
        min-width: 200px;
        min-height: 600px;
        flex: 0 0 auto;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
        border: none;
        overflow: hidden;
        transition: all 0.3s ease;
        position: relative;
        padding: 0 5px;
    }

    .card-header {
        border-bottom: none;
        padding: 20px 5px 0px;
        background: transparent;
    }

    .card-body-mini {
        padding: 0 2px 25px;
        height: 100%;
        display: flex;
        flex-direction: column;
    }

    .content-container {
        /* background: #EFEFEF; */
        /* border-radius: 16px; */
        padding: 5px;
        flex-grow: 1;
        /* box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); */
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }

    /* Card specific gradients */
    .staff-card {
        background: #FFF;
    }

    .service-card {
        background: #FFF;
    }

    .task-card {
        background: #FFF;
    }

    .selected-card {
        background: #FFF;
    }

    /* Service item styles */
    .service-item {
        padding: 15px;
        /* margin-bottom: 12px; */
        background: white;
        border-radius: 12px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.04);
        transition: all 0.2s ease;
        border-left: 4px solid #8a4fff;
        cursor: pointer;
    }

    .service-item:hover {
        transform: translateX(5px);
        /* box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08); */
    }

    .service-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        /* margin-bottom: 8px; */
    }

    .service-name {
        font-weight: 600;
        font-size: 1.1rem;
        margin: 0;
    }

    .service-price {
        font-weight: 700;
        color: #8a4fff;
        font-size: 1.1rem;
    }

    .service-desc {
        color: #6c757d;
        font-size: 0.9rem;
        margin: 0;
    }

    /* Task item styles */
    .task-item {
        padding: 15px;
        margin-bottom: 12px;
        background: white;
        border-radius: 12px;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.04);
        transition: all 0.2s ease;
        border-left: 4px solid #f72585;
        cursor: grab;
    }

    .task-item:active {
        cursor: grabbing;
    }

    .task-item:hover {
        transform: translateX(5px);
        /* box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08); */
    }

    .task-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        /* margin-bottom: 8px; */
    }

    .task-name {
        font-weight: 600;
        font-size: 1.1rem;
        margin: 0;
    }

    .task-duration {
        background: #f72585;
        color: white;
        padding: 3px 10px;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
    }

    .task-desc {
        color: #6c757d;
        font-size: 0.9rem;
        margin: 0 0 10px;
    }

    .task-footer {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 0.85rem;
        color: #6c757d;
    }

    .staff-avatar {
        width: 80px;
        height: 80px;
        border-radius: 50%;
        background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 1.8rem;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        border: 3px solid white;
    }

    .staff-avatar-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
    }

    .staff-avatar-initial {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
        font-weight: bold;
    }

    /* Container style */
    #production-staff-container a {
        overflow: hidden;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    #production-staff-container a:hover {
        background-color: #f8f9fa;
        transform: scale(1.01);
    }

    /* Tooltip fix (Bootstrap) */
    [data-bs-toggle="tooltip"] {
        cursor: pointer;
    }
</style>

<!-- WEEKLY FILTER SCRIPT -->
<script>
    // Get current week's dates
    // function getWeekDates(offset = 0) {
    //     const now = new Date();
    //     const dayOfWeek = now.getDay();
    //     const startDate = new Date(now);
        
    //     // Adjust to start from Monday (if today is Sunday, start from previous Monday)
    //     const diff = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
    //     startDate.setDate(now.getDate() - diff + (offset * 7));
        
    //     const weekDates = [];
    //     const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        
    //     for (let i = 0; i < 6; i++) {
    //         const currentDate = new Date(startDate);
    //         currentDate.setDate(startDate.getDate() + i);

    //         const formattedDate = currentDate.toISOString().split('T')[0];
            
    //         // Generate random progress between 20-95%
    //         const progress = 0;
            
    //         weekDates.push({
    //             name: dayNames[i],
    //             date: currentDate,
    //             formattedDate: formattedDate,
    //             progress: progress
    //         });
    //     }
        
    //     return weekDates;
    // }
    
    // Format date as "MMM DD"
    function formatDate(date) {
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
    
    // Create day elements
    // function createDayElements(weekData) {
    //     const container = document.querySelector('.weekly-filter');
    //     container.innerHTML = '';

    //     weekData.forEach((day, index) => {
    //         const dayElement = document.createElement('div');
    //         dayElement.className = 'day col-lg-2';
    //         dayElement.setAttribute('data-progress', day.progress);
    //         dayElement.setAttribute('data-day', day.name);
    //         dayElement.setAttribute('data-date', day.formattedDate);

    //         dayElement.innerHTML = `
    //             <div class="day-card ${index === 0 ? 'active' : ''}">
    //                 <div class="fw-semibold fs-6 mb-2">${day.name}</div>
    //                 <div class="fs-7 mb-3">${formatDate(day.date)}</div>
    //                 <div class="task-day-container" style="display:none;">
    //                     <div class="progress-container">
    //                         <div class="progress-bar"></div>
    //                     </div>
    //                     <div class="fs-7 mt-2 task_date_hrs_show fw-semibold d-flex justify-content-center align-items-center gap-1">
    //                         <i class="mdi mdi-clock-time-five-outline"></i> 0hrs
    //                     </div>
    //                 </div>
    //             </div>
    //         `;

    //         container.appendChild(dayElement);

    //         // Click listener for this day
    //         dayElement.addEventListener('click', () => {
    //             document.querySelectorAll('.day-card').forEach(card => card.classList.remove('active'));
    //             dayElement.querySelector('.day-card').classList.add('active');

    //             resetModal();


    //             // Set hidden input
    //             document.getElementById('task_date').value = day.formattedDate;
    //         });
    //     });

    //     // Set initial task_date
    //     document.getElementById('task_date').value = weekData[0].formattedDate;
    // }

    function updateWeekProgress(progressData) {
        const days = document.querySelectorAll('.day');

        days.forEach(day => {
            const dayCard = day.querySelector('.day-card');
            const daycontainer = day.querySelector('.task-day-container');
            const bar = daycontainer.querySelector('.progress-bar');
            const text = daycontainer.querySelector('.task_date_hrs_show');

            const date = day.getAttribute('data-date');
            const hoursWorked = parseInt(progressData[date]) || 0;

            // Calculate percentage relative to 7 hours
            const progressPercent = Math.min((hoursWorked / 7) * 100, 100);

            if(dayCard.classList.contains('active')) {
                daycontainer.style.display = 'block';
                bar.style.width = '0%';
                setTimeout(() => bar.style.width = progressPercent + '%', 150);
                text.innerHTML = `<i class="mdi mdi-clock-time-five-outline"></i> ${hoursWorked}hrs`;
            } else {
                daycontainer.style.display = 'none';
            }
        });
    }

    // Date Picker Initialization
    document.addEventListener("DOMContentLoaded", function () {
        function normalize(date) {
            return new Date(date.getFullYear(), date.getMonth(), date.getDate());
        }
 
        const today = normalize(new Date());
 
        // Get next Monday
        const day = today.getDay(); // 0 = Sun, 1 = Mon
        const daysToNextMonday = day === 0 ? 1 : 8 - day;
 
        const nextMonday = normalize(new Date(
            today.getFullYear(),
            today.getMonth(),
            today.getDate() + daysToNextMonday
        ));
 
        const nextSaturday = normalize(new Date(
            nextMonday.getFullYear(),
            nextMonday.getMonth(),
            nextMonday.getDate() + 5
        ));
 
        const $picker = $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            autoclose: true,
            todayHighlight: false,
            daysOfWeekDisabled: [0], // Sunday disabled
 
            defaultViewDate: {
                year: nextMonday.getFullYear(),
                month: nextMonday.getMonth(),
                day: nextMonday.getDate()
            },
 
            beforeShowDay: function (date) {
                const d = normalize(date);
 
                if (d >= nextMonday && d <= nextSaturday) {
                    return {
                        enabled: true,
                        classes: 'allowed-date'
                    };
                }
                return { enabled: false };
            }
        });
 
        // ✅ Set next Monday as default selected date
        $picker.datepicker('setDate', nextMonday);

        // Set today's date as default
        // const today = new Date();
        const formattedToday = today.toISOString().split('T')[0];
        $('#task_date_picker').val(formattedToday);
        $('#task_date').val(formattedToday);

        updateDateDisplay(formattedToday);

        // Date picker change event
        $('#task_date_picker').on('change', function() {
            const selectedDate = $(this).val();
            $('#task_date').val(selectedDate);
            
            updateDateDisplay(selectedDate);

            // Reset selections when date changes
            resetSelections();
            
            // Fetch progress for selected date if staff is selected
            const staffId = $('#pro_staff_id').val();
            if (staffId) {
                fetchDateProgress(staffId, selectedDate);
            }
        });

        function updateDateDisplay(dateStr) {
            const date = new Date(dateStr);
            
            // Format date as "DD MMMM YYYY"
            const formattedDate = date.toLocaleDateString('en-US', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            });
            
            // Get day name
            const dayName = date.toLocaleDateString('en-US', { weekday: 'long' });
            
            // Update display elements
            $('#selected_date_display').text(formattedDate);
            $('#selected_day_display').text(dayName);
        }

        // Function to reset selections when date changes
        function resetSelections() {
            // Reset staff selection
            $('.staff_card_color_').removeClass('bg-label-success').addClass('bg-label-danger');
            $('#pro_staff_id').val('');
            
            // Reset service selection
            $('.service_color_change_').removeClass('bg-label-success').addClass('bg-label-danger');
            $('#service_id').val('');
            
            // Reset service container
            $('#service-container').html(`
                <div class="empty-state">
                    <i class="fa-solid fa-box-open"></i>
                    <label>No Services Available</label>
                    <p>There are currently no services assigned to this staff member.</p>
                </div>
            `);
            
            // Reset task container
            $('#task-container').html(`
                <div class="empty-state">
                    <i class="fas fa-list-alt"></i>
                    <label>Select a Service</label>
                    <p class="mt-2">Choose a service to view available tasks</p>
                </div>
            `);
            
            // Reset selected task
            $('#selected_task_id').val('');
            
            // Reset drop container
            const dropContainer = document.getElementById('drop-container');
            const emptyState = document.getElementById('drop-empty-state');
            dropContainer.innerHTML = '';
            dropContainer.appendChild(emptyState);
            emptyState.style.display = 'flex';
            
            // Reset progress display
            updateDateProgress(0);
        }

        // Function to fetch progress for selected date
        function fetchDateProgress(staffId, date) {
            $.ajax({
                url: `/get_task_date_progress/${staffId}/${date}`,
                method: 'GET',
                success: function (response) {
                    if(response.status === 200) {
                        const hoursWorked = parseFloat(response.data) || 0;
                        updateDateProgress(hoursWorked);  // ← Use this instead
                        editTask();
                        $('#kt_modal_edit_task').modal('show');
                    } else {
                        console.error('Error Fetching Data.');
                        updateDateProgress(0);
                    }
                },
                error: function (err) {
                    console.error('Error fetching date progress:', err);
                    updateDateProgress(0);
                }
            });
        }

        // Function to update progress display
        function updateDateProgress(hoursWorked) {
            const maxHours = 7;
            const progressPercent = Math.min((hoursWorked / maxHours) * 100, 100);
            
            $('#date_progress_bar').css('width', progressPercent + '%');
            $('#date_hours_display').text(hoursWorked + 'hrs / ' + maxHours + 'hrs');
        }
    });

    // Update the selectStaff function to use date picker
    function selectStaff (index, sno) {
        $('.staff_card_color_').removeClass('bg-label-success').addClass('bg-label-danger');
        $(`#staff_card_color_${index}`).removeClass('bg-label-danger').addClass('bg-label-success');
        $('#pro_staff_id').val(sno);
        serviceDataFetch(sno);

        $('#task-container').html(`
        <div class="empty-state">
            <i class="fas fa-list-alt"></i>
            <label>Select a Service</label>
            <p class="mt-2">Choose a service to view available tasks</p>
        </div>
        `);

        const taskDate = $('#task_date').val();

        $.ajax({
            url: `/get_task_date_progress/${sno}/${taskDate}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    const hoursWorked = parseFloat(response.data) || 0;
                    
                    // Update progress display
                    updateDateProgress(hoursWorked);  // ← THIS IS CORRECT
                    editTask();
                    $('#kt_modal_edit_task').modal('show');
                } else {
                    console.error('Error Fetching Data.');
                    updateDateProgress(0);
                }
            },
            error: function (err) {
                console.error('Error Fetching Data Due To : ' + err);
                updateDateProgress(0);
            }
        });
    }

    // Add this helper function if not already present
    function updateDateProgress(hoursWorked) {
        const maxHours = 7;
        const progressPercent = Math.min((hoursWorked / maxHours) * 100, 100);
        
        $('#date_progress_bar').css('width', progressPercent + '%');
        $('#date_hours_display').text(hoursWorked + 'hrs / ' + maxHours + 'hrs');
    }
    
    // Initialize the component
    // document.addEventListener('DOMContentLoaded', () => {
    //     const weekData = getWeekDates(1);
    //     createDayElements(weekData);
    // });
</script>

<!-- DOCUMENT LOADS -->
<script>
    $(document).ready(function () {
        productionStaffDataFetch();

        $('#service-container').html(`
        <div class="empty-state">
            <i class="fa-solid fa-box-open"></i>
            <label>No Services Available</label>
            <p>There are currently no services assigned to this staff member.</p>
        </div>
        `);
    });
</script>

<!-- PRODUCTION STAFF STYLES -->
<style>
    .staff-card-mini {
        background: white;
        border-radius: 18px;
        padding: 0;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        /* border-left: 5px solid #2FB5B0; */
        
        box-shadow: inset 0px 0px 4px -1px rgba(34, 6, 48, 0.54)
    }

    .staff-card-mini:hover {
        transform: translateY(-8px);
    }

    .staff-card-mini.active {
        background: linear-gradient(135deg, #f8f9ff 0%, #eef2ff 100%);
        box-shadow: 0 15px 35px rgba(67, 97, 238, 0.2), 0 0 20px rgba(67, 97, 238, 0.3);
    }

    .staff-card-mini-content {
        padding: 15px;
    }

    .staff-avatar-container {
        position: relative;
    }

    .staff-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 1.8rem;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        position: relative;
        overflow: hidden;
        border: 3px solid white;
    }

    .staff-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 50%;
    }

    .initials {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
    }

    .staff-level-badge {
        position: absolute;
        bottom: -6px;
        right: 0px;
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: bold;
        font-size: 0.8rem;
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.2);
        border: 2px solid white;
    }

    .level-junior {
        background: linear-gradient(135deg, #48bb78, #38a169);
    }

    .level-mid {
        background: linear-gradient(135deg, #ed8936, #dd6b20);
    }

    .level-senior {
        background: linear-gradient(135deg, #e53e3e, #c53030);
    }

    .staff-name {
        font-weight: 700;
        font-size: 1.4rem;
        margin: 0 0 5px;
        color: #2d3748;
        line-height: 1.3;
    }

    .staff-nickname {
        font-size: 1.1rem;
        color: #4361ee;
        font-weight: 600;
        margin: 0 0 8px;
        display: flex;
        align-items: center;
        gap: 5px;
    }

    .staff-position {
        font-size: 1rem;
        color: #718096;
        margin: 0;
        font-weight: 500;
        line-height: 1.4;
    }

    

    .empty-state {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 100%;
        text-align: center;
        color: #718096;
        padding: 20px;
        margin-top: 140px;
        grid-column: 1 / -1;
    }

    .empty-state i {
        font-size: 2rem;
        margin-bottom: 20px;
        opacity: 0.7;
        color: #4361ee;
    }

    .empty-state label {
        font-size: 1.05rem;
        font-weight: 600;
        margin-bottom: 10px;
    }

    /* Animation for new elements */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .fade-in-up {
        animation: fadeInUp 0.5s ease forwards;
    }

    /* Selection animation */
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(67, 97, 238, 0.4);
        }

        70% {
            box-shadow: 0 0 0 10px rgba(67, 97, 238, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(67, 97, 238, 0);
        }
    }

    .staff-card-mini.active {
        animation: pulse 2s infinite;
    }
</style>

<!-- PRODUCTION STAFF DATA FETCH -->
<script>
    function productionStaffDataFetch(search = '') {
        $.ajax({
            url: `/production_staff_data_fetch`,
            method: 'GET',
            data: { search: search },
            success: function (response) {
                if(response.status === 200) {
                    const productionStaffs = response.data;

                    if(productionStaffs.length > 0) {
                        const staffFetchContainer = $('#production-staff-container');
                        staffFetchContainer.empty();
                        let html = '';
                        
                        productionStaffs.forEach((staff, index) => {
                            // Get skill level info
                            const skillInfo = getSkillInfo(staff.employee_skill_id);
                            
                            // Get initials for avatar
                            const initials = getInitials(staff.staff_name);
                            
                            html += `
                                <div class="staff-card-mini bg-label-danger fade-in-up mb-4 staff_card_color_" style="animation-delay: ${index * 0.1}s" id="staff_card_color_${index}" onclick="selectStaff(${index}, ${staff.sno})">
                                    <div class="staff-card-mini-content">
                                        <div class="row">
                                            <div class="staff-avatar-container col-lg-4">
                                                <div class="staff-avatar">`;
                            
                            if(staff.staff_image !== null) {
                                html += `
                                    <img src="/staff_images/${staff.staff_image}" alt="${staff.staff_name}" onerror="this.style.display='none'">
                                   
                                `;
                            } else {
                                html += `<div class="initials">${initials}</div>`;
                            }
                            
                            html += `
                                                </div>
                                                <div class="staff-level-badge ${skillInfo.class}" data-bs-toggle="tooltip" title="${skillInfo.skill}">
                                                    ${skillInfo.badge}
                                                </div>
                                            </div>
                                            <div class="staff-info col-lg-8">
                                                <h3 class="fs-6 fw-bold my-2 text-truncate" data-bs-toggle="tooltip" title="${staff.staff_name}">${staff.staff_name}</h3>
                                                <div class="fs-7 fw-semibold my-2 d-flex align-items-center gap-1" style="color: #4361ee;">
                                                    <i class="fas fa-user-circle"></i> ${staff.nick_name}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fs-8 text-white fw-semibold mt-3 text-center bg-info py-1 px-1">${staff.job_position_name}</div>
                                    </div>
                                </div>
                            `;
                        });
                        
                        staffFetchContainer.html(html);
                        
                        // Initialize tooltips
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // Show empty state if no staff
                        $('#production-staff-container').html(`
                            <div class="empty-state">
                                <i class="fas fa-user-slash"></i>
                                <label>No Staff Available</label>
                                <p>There are currently no production staff members to display.</p>
                            </div>
                        `);
                    }
                } else {
                    console.error('Data Fetching Failed!');
                    // Show error state
                    $('#production-staff-container').html(`
                        <div class="empty-state">
                            <i class="fas fa-exclamation-triangle"></i>
                            <label>Error Loading Data</label>
                            <p>Failed to fetch staff data. Please try again later.</p>
                        </div>
                    `);
                }
            },
            error: function (err) {
                console.error('Data Fetching Failed Due To :' + err);
                // Show error state
                $('#production-staff-container').html(`
                    <div class="empty-state">
                        <i class="fas fa-exclamation-triangle"></i>
                        <label>Error Loading Data</label>
                        <p>Failed to fetch staff data. Please try again later.</p>
                    </div>
                `);
            }
        });
    }
</script>

<!-- SEARCH STAFF SCRIPT -->
<script>
    $('#staff-search').on('input', function() {
        const searchValue = $(this).val().trim();
        productionStaffDataFetch(searchValue);

        // Reset Staff Value
        $('#pro_staff_id').val('');

        // Reset Service Id
        $('#service_id').val('');

        // Reset Service Container
        $('#service-container').html(`
            <div class="empty-state">
                <i class="fa-solid fa-box-open"></i>
                <label>No Services Available</label>
                <p>There are currently no services assigned to this staff member.</p>
            </div>
        `);

        // Reset Task Container
        $('#task-container').html(`
            <div class="empty-state">
                <i class="fas fa-clipboard-list"></i>
                <label>No Tasks Available</label>
                <p>There are currently no tasks for this service.</p>
            </div>
        `);
    });
</script>

<!-- GET EMPLOYEE SKILL INFO -->
<script>
     function getSkillInfo(employeeSkill) {
        if(employeeSkill == 2) {
            return { skill: 'Mid Level', badge: 'ML', class: 'level-mid' };
        } else if(employeeSkill == 3) {
            return { skill: 'Senior', badge: 'S', class: 'level-senior' };
        } else {
            return { skill: 'Junior', badge: 'J', class: 'level-junior' };
        }
    }
</script>

<!-- GET STAFF INITIAL -->
<script>
    function getInitials(name) {
        return name
            .split(' ')
            .map(part => part.charAt(0))
            .join('')
            .toUpperCase();
    }
</script>

<!-- STAFF SELECT & COLOR CHANGE -->
<script>
    function selectStaff (index, sno) {
        $('.staff_card_color_').removeClass('bg-label-success').addClass('bg-label-danger');
        $(`#staff_card_color_${index}`).removeClass('bg-label-danger').addClass('bg-label-success');
        $('#pro_staff_id').val(sno);
        serviceDataFetch(sno);

        $('#task-container').html(`
        <div class="empty-state">
            <i class="fas fa-list-alt"></i>
            <label>Select a Service</label>
            <p class="mt-2">Choose a service to view available tasks</p>
        </div>
        `);

        const taskDate = $('#task_date').val();

        $.ajax({
            url: `/get_task_date_progress/${sno}/${taskDate}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    // Extract hours worked from response
                    const hoursWorked = parseFloat(response.data) || 0;
                    
                    // Update progress display
                    updateDateProgress(hoursWorked);
                    editTask();
                    $('#kt_modal_edit_task').modal('show');
                } else {
                    console.error('Error Fetching Data.');
                    updateDateProgress(0);
                }
            },
            error: function (err) {
                console.error('Error Fetching Data Due To : ' + err);
                updateDateProgress(0);
            }
        });
    }

    let shouldResetModal = true; // default: reset modal on close

    // document.addEventListener('DOMContentLoaded', function() {
    //     const editModalEl = document.getElementById('kt_modal_edit_task');
    //     if (editModalEl) {
    //         editModalEl.addEventListener('hidden.bs.modal', function () {
    //             if (shouldResetModal) {
    //                 resetModal();
    //             }
    //             shouldResetModal = true; // reset flag for next time
    //         });
    //     }
    // });

    // // Cancel button should reset modal (default behavior)
    // $('.btn-secondary[data-bs-dismiss="modal"]').click(function() {
    //     shouldResetModal = true;
    // });

    function closeEditModal() {
        shouldResetModal = false; // don't reset modal on close
        $('#kt_modal_edit_task').modal('hide');
    }
</script>

<!-- SERVICE STYLE -->
<style>
    .service-card-mini {
        background: white;
        border-radius: 16px;
        padding: 0;
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        cursor: pointer;
        position: relative;
        overflow: hidden;
        /* border-left: 5px solid #00BAB1; */
        box-shadow: inset 0px 0px 4px -1px rgba(34, 6, 48, 0.54)
    }

    .service-card-mini:hover {
        transform: translateY(-8px);
    }

    .service-card-mini.active {
        background: linear-gradient(135deg, #f8f9ff 0%, #eef2ff 100%);
        box-shadow: 0 15px 35px rgba(67, 97, 238, 0.15);
    }

    .service-card-mini-content {
        padding: 10px;
    }

    /* .service-header {
        display: flex;
        align-items: flex-start;
    } */

    .service-info {
        flex: 1;
        min-width: 0;
        /* Important for text truncation */
    }

    .customer-name {
        font-weight: 700;
        font-size: 1.3rem;
        margin: 0 0 6px;
        color: #2d3748;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        line-height: 1.3;
    }

    .customer-id {
        font-size: 0.95rem;
        color: #4361ee;
        font-weight: 600;
        margin: 0 0 12px;
        display: flex;
        align-items: center;
        gap: 6px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .customer-id i {
        font-size: 0.9rem;
    }

    .product-badge {
        --badge-bg: linear-gradient(135deg, #ffd166 0%, #f9a826 100%);
        --badge-color: #2d3748;
        --badge-shadow: rgba(0, 0, 0, 0.1);

        background: var(--badge-bg);
        color: var(--badge-color);
        border-radius: 10px;
        box-shadow: 0 3px 8px var(--badge-shadow);
        transition: all 0.3s ease;
        cursor: default;
    }

    /* Hover animation for better feel */
    .product-badge:hover {
        transform: translateY(-2px);
        /* box-shadow: 0 5px 12px var(--badge-shadow); */
    }

    /* 🟡 Default (golden) */
    .product-badge--yellow {
        --badge-bg: linear-gradient(135deg, #ffd166 0%, #f9a826 100%);
        --badge-color: #2d3748;
    }
    
    /* 🔵 Blue */
    .product-badge--blue {
        --badge-bg: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
        --badge-color: #fff;
    }
    
    /* 🟢 Green */
    .product-badge--green {
        --badge-bg: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        --badge-color: #fff;
    }

    /* Selection animation */
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(67, 97, 238, 0.4);
        }

        70% {
            box-shadow: 0 0 0 10px rgba(67, 97, 238, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(67, 97, 238, 0);
        }
    }

    .service-card-mini.active {
        animation: pulse 2s infinite;
    }
</style>

<!-- SERVICE DATA FETCH -->
<script>
     function serviceDataFetch(id) {
        const serviceContainer = $('#service-container');
        let skeletonHtml = '';
        
        // Create 3 skeleton cards
        for (let i = 0; i < 3; i++) { skeletonHtml +=` <div class="skeleton-service-card">
            <div class="skeleton-header">
                <div class="skeleton-line skeleton-title"></div>
                <div class="skeleton-line skeleton-subtitle"></div>
            </div>
            <div class="skeleton-badges">
                <div class="skeleton-badge"></div>
                <div class="skeleton-badge"></div>
                <div class="skeleton-badge"></div>
            </div>
            </div>
            `;
            }
        
            serviceContainer.html(`
            <div class="skeleton-loader-container">
                ${skeletonHtml}
            </div>
            `);

        $.ajax({
            url: `/get_customer_services/${id}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    const serviceData = response.data;
                    serviceContainer.empty();
                    let html = '';
                    
                    if(serviceData.length > 0) {
                        serviceData.forEach((service, index) => {
                            
                            html += `
                                <div class="service-card-mini fade-in-up bg-label-danger mb-4 service_color_change_" style="animation-delay: ${index * 0.1}s" id="service_color_change_${index}" onclick="selectService(${index}, ${service.sno})">
                                    <div class="service-card-mini-content">
                                        <div class="service-header">
                                            <div class="service-info">
                                                <h3 class="fw-semibold text-black mb-2 text-truncate fs-6">${service.cus_name}</h3>
                                                <div class="fw-semibold d-flex align-items-center mb-2  gap-2 fs-7" style="color: #4361ee;">
                                                    <i class="mdi mdi-card-account-details"></i> ${service.customer_id}
                                                </div>
                                                <div class="d-flex flex-column gap-2">
                                                    <div class="product-badge fw-semibold fs-7 d-inline-flex align-items-center gap-1 px-2 py-1 product-badge--yellow" data-bs-toggle="tooltip" title="Service" >
                                                        <i class="mdi mdi-cog-outline"></i>
                                                        ${service.product_name}
                                                    </div>
                                                    
                                                    <div class="product-badge fw-semibold fs-7 d-inline-flex align-items-center gap-1 px-2 py-1 product-badge--blue" data-bs-toggle="tooltip" title="Variant" >
                                                        <i class="mdi mdi-package-variant"></i>
                                                        ${service.variant_name}
                                                    </div>
                                                    
                                                    <div class="product-badge fw-semibold fs-7 d-inline-flex align-items-center gap-1 px-2 py-1 product-badge--green" data-bs-toggle="tooltip" title="Variable">
                                                        <i class="mdi mdi-tune-vertical"></i>
                                                        ${service.variable_name}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        
                        serviceContainer.html(html);
                        // Initialize tooltips
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // Show empty state if no services
                        serviceContainer.html(`
                            <div class="empty-state">
                                <i class="fa-solid fa-box-open"></i>
                                <label>No Services Available</label>
                                <p>There are currently no services assigned to this staff member.</p>
                            </div>
                        `);
                    }
                } else {
                    console.error('Error Fetching Service!');
                    // Show error state
                    $('#service-container').html(`
                        <div class="empty-state">
                            <i class="fas fa-exclamation-triangle"></i>
                            <label>Error Loading Services</label>
                            <p>Failed to fetch service data. Please try again later.</p>
                        </div>
                    `);
                }
            },
            error: function (err) {
                console.error('Error Fetching Service Due To : ' + err);
                // Show error state
                $('#service-container').html(`
                    <div class="empty-state">
                        <i class="fas fa-exclamation-triangle"></i>
                        <label>Error Loading Services</label>
                        <p>Failed to fetch service data. Please try again later.</p>
                    </div>
                `);
            }
        });
    }
</script>

<!-- SERVICE SELECT & COLOR CHANGE -->
<script>
    function selectService(index, sno) {
        $('.service_color_change_').removeClass('bg-label-success').addClass('bg-label-danger');
        $(`#service_color_change_${index}`).removeClass('bg-label-danger').addClass('bg-label-success');
        $('#service_id').val(sno);
        taskDataFetch(sno);
    }
</script>

<!-- TASK STYLE -->
<style>
    .task-card-mini {
        background: white;
        border-radius: 16px;
        padding: 0;
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        cursor: grab;
        position: relative;
        overflow: hidden;
        /* border-left: 5px solid #00BAB1; */
        box-shadow: inset 0px 0px 4px -1px rgba(34, 6, 48, 0.54)
    }

    .task-card-mini:active {
        cursor: grabbing;
    }

    .task-card-mini:hover {
        transform: translateY(-8px);
        /* box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15); */
    }

    .task-card-mini-content {
        padding: 10px;
    }

    .task-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        background: linear-gradient(135deg, #4361ee 0%, #4cc9f0 100%);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 1.4rem;
        margin-right: 16px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        flex-shrink: 0;
    }

    .task-info {
        flex: 1;
        min-width: 0;
    }

    .task-id {
        font-size: 0.9rem;
        color: #4361ee;
        font-weight: 600;
        margin: 0 0 5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }

    .task-id i {
        font-size: 0.85rem;
    }

    .metric-badge {
        padding: 8px 14px;
        border-radius: 10px;
        font-weight: 600;
        font-size: 0.9rem;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        color: white;
    }

    .progress-metric {
        background: linear-gradient(135deg, #28a745, #20c997);
    }

    .hours-metric {
        background: linear-gradient(135deg, #dc3545, #e83e8c);
    }

    /* Priority indicators */
    .priority-indicator {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.8rem;
        padding: 4px 10px;
        border-radius: 20px;
        font-weight: 600;
    }

    .priority-high {
        background: rgba(239, 71, 111, 0.15);
        color: #ef476f;
    }

    .priority-medium {
        background: rgba(255, 193, 7, 0.15);
        color: #ffc107;
    }

    .priority-low {
        background: rgba(25, 135, 84, 0.15);
        color: #00BAB1;
    }

    .bg-label-danger {
        background: #f4f4f4 !important;
    }
</style>

<!-- TASK DATA FETCH -->
<script>
    function taskDataFetch(id) {
        const staffId = $('#pro_staff_id').val();
        const taskDataContainer = $('#task-container');
        let skeletonHtml = '';
        
        // Create 3 skeleton cards
        for (let i = 0; i < 3; i++) { skeletonHtml +=` <div class="skeleton-service-card">
            <div class="skeleton-header">
                <div class="skeleton-line skeleton-title"></div>
                <div class="skeleton-line skeleton-subtitle"></div>
            </div>
            <div class="skeleton-badges">
                <div class="skeleton-badge"></div>
                <div class="skeleton-badge"></div>
                <div class="skeleton-badge"></div>
            </div>
            </div>
            `;
            }
        
            taskDataContainer.html(`
            <div class="skeleton-loader-container">
                ${skeletonHtml}
            </div>
            `);
        $.ajax({
            url: `/task_data_fetch/${id}/${staffId}`,
            method: 'GET',
            success: function(response) {
                if(response.status === 200) {
                    const taskData = response.data;
                    taskDataContainer.empty();
                    let html = '';

                    if(taskData.length > 0) {
                        let completedCount = 0;
                        let inProgressCount = 0;
                        let pendingCount = 0;
                        
                        taskData.forEach((task, index) => {
                            // Get priority info (you might need to add priority to your data)
                            const priorityInfo = getPriorityInfo(task.priority || 'medium');
                            
                            const taskCategory = task.task_category;
                            let Category = '';

                            if(taskCategory == 0) {
                                Category = 'Pages';
                            } else if(taskCategory == 1) {
                                Category = '%';
                            }
                            
                            html += `
                                <div class="task-card-mini fade-in-up bg-label-danger mb-3" data-sno="${task.sno}" style="animation-delay: ${index * 0.1}s" id="task-${task.sno}">
                                    <div class="task-card-mini-content">
                                        <div class="task-header">
                                            <div class="task-info">
                                                <h3 class="fs-6 fw-semibold text-black text-truncate" data-bs-toggle="tooltip" title="${task.task_name}" >${task.task_name}</h3>
                                                <div class="task-id">
                                                    <i class="fas fa-hashtag"></i> ${task.task_id}
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex gap-2">
                                            <div class="metric-badge progress-metric">
                                                <i class="fas fa-chart-line"></i>
                                                ${task.pages_percentage} ${Category}
                                            </div>
                                            <div class="metric-badge hours-metric">
                                                <i class="fas fa-clock"></i>
                                                ${task.working_hours}hrs
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        
                        taskDataContainer.html(html);

                        // Initialize tooltips
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        // Show empty state if no tasks
                        taskDataContainer.html(`
                            <div class="empty-state">
                                <i class="fas fa-clipboard-list"></i>
                                <label>No Tasks Available</label>
                                <p>There are currently no tasks for this service.</p>
                            </div>
                        `);
                    }
                } else {
                    console.error('Error Fetching Tasks!');
                    // Show error state
                    $('#task-container').html(`
                        <div class="empty-state">
                            <i class="fas fa-exclamation-triangle"></i>
                            <label>Error Loading Tasks</label>
                            <p>Failed to fetch task data. Please try again later.</p>
                        </div>
                    `);
                }
            },
            error: function (err) {
                console.error('Error Fetching Tasks Due To : ' + err);
                // Show error state
                $('#task-container').html(`
                    <div class="empty-state">
                        <i class="fas fa-exclamation-triangle"></i>
                        <label>Error Loading Tasks</label>
                        <p>Failed to fetch task data. Please try again later.</p>
                    </div>
                `);
            }
        })
    }

    function getPriorityInfo(priority) {
        switch(priority) {
            case 'high':
                return { text: 'High Priority', class: 'priority-high', icon: 'fas fa-exclamation-circle' };
            case 'medium':
                return { text: 'Medium Priority', class: 'priority-medium', icon: 'fas fa-info-circle' };
            case 'low':
                return { text: 'Low Priority', class: 'priority-low', icon: 'fas fa-flag' };
            default:
                return { text: 'Medium Priority', class: 'priority-medium', icon: 'fas fa-info-circle' };
        }
    }
</script>

<!-- TIME ALLOCATION SCRIPT -->
<script>
    $('#time_allocate').on('input', function () {
        const staffId = $('#pro_staff_id').val();
        const taskDate = $('#task_date').val();
        const maxHours = 7;
        
        let alreadyAllocatedHours = 0;
        
        // Fetch already allocated hours for this date if staff and date are selected
        if (staffId && taskDate) {
            $.ajax({
                url: `/get_task_date_progress/${staffId}/${taskDate}`,
                method: 'GET',
                async: false,
                success: function (response) {
                    if(response.status === 200) {
                        alreadyAllocatedHours = parseInt(response.data) || 0;
                    }
                }
            });
        }
        
        const availableHours = maxHours - alreadyAllocatedHours;
        const totalHours = parseFloat($('#total_hours').val()) || 0;
        const totalPages = parseFloat($('#total_page_or_per').val()) || 0;
        let val = $(this).val();

        // ✅ Allow only numbers and one decimal point
        val = val.replace(/[^0-9.]/g, ''); // remove anything not 0–9 or .
        const parts = val.split('.');
        if (parts.length > 2) {
            val = parts[0] + '.' + parts[1]; // keep only one dot
        }
        $(this).val(val);

        let hoursInput = parseFloat(val) || 0;
        let defaultPages = 0;

        // ✅ Restrict user to available hours
        if (hoursInput > availableHours) {
            hoursInput = availableHours;
            $(this).val(availableHours);
            toastr.warning(`Maximum available hours for this date: ${availableHours}hrs`);
        }

        // ✅ Also ensure not greater than total hours (if provided)
        if (hoursInput > totalHours && totalHours > 0) {
            hoursInput = totalHours;
            $(this).val(totalHours);
        }

        // ✅ Calculate proportional pages/percentage
        if (hoursInput > 0 && totalHours > 0) {
            defaultPages = ((totalPages / totalHours) * hoursInput).toFixed(0);
        }

        const remainingPages = totalPages - defaultPages;

        // ✅ Update UI elements
        $('#page_allocate').val(defaultPages);
        $('#allocated_page_or_per_all').html(defaultPages);
        $('#remaining_page_or_per_all').html(remainingPages);
    });
</script>

<!-- SPLIT MODAL VALIDATION -->
<script>
    function splitModalValidation() {
        const timeAllocation = $('#time_allocate').val();
        const pageAllocation = $('#page_allocate').val();
        const pageOrPerCat = $('#page_or_per_value').val();
        const timeVal = parseInt(timeAllocation, 10);
        const totalPagesAllocated = $('#total_page_or_per').val();
        let isValid = true;

        $('#time_allocate_err, #page_allocate_err').text('');

        if(timeAllocation === '') {
            $('#time_allocate_err').text('Enter Time Allocation.');
            isValid = false;
        }

        if(!isValid) {
            return false;
        } else {
            $('#split_modal_create_btn').addClass('d-none');

            const createStaffId = $('#pro_staff_id').val();
            const createServiceId = $('#service_id').val();
            const createTaskId = $('#selected_task_id').val();
            const createTaskDate = $('#task_date').val();
            const description = $('#description').val();

            $.ajax({
                url: `/create_daily_task`,
                method: 'POST',
                data: {
                    staff_id: createStaffId,
                    service_id: createServiceId,
                    task_id: createTaskId,
                    task_date: createTaskDate,
                    allocated_pages: pageAllocation,
                    allocated_time: timeAllocation,
                    description: description,
                },
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    if (response.status === 200) {
                        toastr.success(response.message);
                        location.reload();
                    } else if (response.status === 302) {
                        toastr.error(response.message);
                        location.reload();
                    } else {
                        toastr.error(response.message || 'Something went wrong!');
                    }
                },
                error: function (xhr, status, error) {
                    let message = 'Error while creating task. Please try again.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        location.reload();
                        message = xhr.responseJSON.message;
                    } else if (xhr.status === 302 && xhr.responseJSON) {
                        message = xhr.responseJSON.message;
                        location.reload();
                    }
                    toastr.error(message);
                }
            });
        }

        return true;
    }
</script>

<!-- RESET MODAL -->
<script>
    function resetModal() {
        // Reset staff cards
        $('.staff_card_color_').removeClass('bg-label-success').addClass('bg-label-danger');
        
        // Clear hidden inputs
        $('#pro_staff_id').val('');
        $('#service_id').val('');
        
        // Reset task container
        $('#task-container').html(`
        <div class="empty-state">
            <i class="fas fa-list-alt"></i>
            <label>Select a Service</label>
            <p class="mt-2">Choose a service to view available tasks</p>
        </div>
        `);
        
        // Reset service container
        $('#service-container').html(`
        <div class="empty-state">
            <i class="fa-solid fa-box-open"></i>
            <label>No Services Available</label>
            <p>There are currently no services assigned to this staff member.</p>
        </div>
        `);
        
        $('.task-day-container').hide();
    }
</script>

<!-- EDIT TASK DATA FETCH -->
<script>
    function editTask() {
        const editTaskDate = $('#task_date').val();
        const editStaffId = $('#pro_staff_id').val();

        $.ajax({
            url: `/edit_daily_task/${editStaffId}/${editTaskDate}`,
            method: 'GET',
            success: function(response) {
                if(response.status === 200) {
                    const edit = response.data;

                    $('#edit_staff_name').html(response.staff.staff_name);
                    $('#edit_job_position_name').html(response.staff.job_position_name);

                    const staffImage = response.staff.staff_image;
                    const staffName = response.staff.staff_name;
                    let avatarHtml = '';
                    
                    if (staffImage) {
                        var imgUrl = "{{ asset('staff_images/') }}/" + staffImage;
                        avatarHtml = `<img src="${imgUrl}" class="staff-avatar-img">`;
                    } else {
                        const firstLetter = staffName.charAt(0).toUpperCase();
                        avatarHtml = `<div class="staff-avatar-initial">${firstLetter}</div>`;
                    }
                    
                    $('#staff-avatar-modal').html(avatarHtml);
                    
                    if(response.staff.employee_skill_id == 0) {
                        $('#edit_emp_skill').html(`<i class="fas fa-chart-line"></i> Junior`);
                    } else if(response.staff.employee_skill_id == 1) {
                        $('#edit_emp_skill').html(`<i class="fas fa-chart-line"></i> Mid Level`);
                    } else if(response.staff.employee_skill_id == 2) {
                        $('#edit_emp_skill').html(`<i class="fas fa-chart-line"></i> Senior`);
                    }

                    $('#edit_total_hrs').html(response.staff.total_hours + ' hrs');
                    $('#edit_balance_hrs').html(response.staff.balance_hours + ' hrs');
                    $('#edit_task_Count').html(response.staff.task_count);

                    if (response.staff.total_hours < 7) {
                        $('#edit_add_new_task').removeClass('d-none'); // show
                    } else {
                        $('#edit_add_new_task').addClass('d-none'); // hide
                    }
                    

                    const editTaskContainer = $('#edit_task_container');
                    editTaskContainer.empty();
                    let html = '';
                     let taskCategory = 'na';
                    // Check if tasks array is empty
                    if (edit.length === 0) {
                        html = `
                            <div class="text-center py-5">
                                <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                                <h5 class="text-muted">No Allocated Tasks</h5>
                                <p class="text-muted">Please add tasks to view.</p>
                            </div>
                        `;
                    } else {
                        
                        // Loop through tasks if they exist
                        edit.forEach(task => {
                            // alert(task.task_category)
                           
                             if(task.task_category == 0){
                            taskCategory = ' pages';
                            } else if(task.task_category == 1) {
                            taskCategory = '%';
                            }


                            html += `
                                <div class="task-card-modal">
                                    <div class="d-flex justify-content-between align-items-start mb-4">
                                        <div>
                                            <h4 class="fw-bold text-black mb-1 fs-4">${task.task_name}</h4>
                                            <div class="text-info fs-6 fw-semibold">
                                                #${task.task_id}
                                            </div>
                                        </div>
                                        <span class="priority-indicator priority-medium">
                                            <i class="fas fa-exclamation-circle"></i> Medium Priority
                                        </span>
                                    </div>
                                
                                    <p class="text-muted mb-3">${task.description ? task.description : '-'}</p>
                                
                                    <div class="d-flex gap-4">
                                        <span class="metric-badge progress-metric">
                                            <i class="fas fa-chart-line"></i> ${task.max_page_or_per} ${taskCategory}
                                        </span>
                                        <span class="metric-badge hours-metric">
                                            <i class="fas fa-clock"></i> ${task.task_hours} hours
                                        </span>
                                        <button type="button" class="btn btn-danger d-flex gap-2" onclick="deleteTask(${task.sno})">
                                            <i class="mdi mdi-delete"></i> Delete
                                        </button>
                                    </div>
                                </div>
                            `;
                        });
                    }

                    editTaskContainer.html(html);
                }
            },
            error: function (Err) {
                console.error('Error Fetching Data Due To : ' + Err);
            }
        });
    }
</script>

<!-- DELETE TASK -->
<script>
    function deleteTask(id) {
        $.ajax({
            url: `/delete_daily_task/${id}`,
            method: 'DELETE',
            headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                if(response.status === 200) {
                    location.reload();
                    toastr.success('Task Deleted Successfully!');
                } else {
                    toastr.error('Task Deleting Failed!');
                }
            },
            error: function (Err) {
                console.error('Error Deleting Task Due To : ' + Err);
            }
        });
    }
</script>

@endsection