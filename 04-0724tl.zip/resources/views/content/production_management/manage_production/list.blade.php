@extends('layouts/layoutMaster')

@section('title', 'Manage Production')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
@php
use Carbon\Carbon;
$loginStaff = auth()->user()->user_id;
@endphp
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }

    .bg-hov:hover {
        background-color: #eae1fc !important;
    }

    .task_perct_dbox .select2-selection--single {
        height: 2rem !important;
    }

    .task_perct_dbox .select2-selection__rendered {
        line-height: 1.8rem !important;
    }

    .task_perct_dbox .select2-selection__arrow {
        line-height: 1.8rem !important;
        height: 2rem !important;
    }
</style>
<style>
    .task-view-container {
        font-family: 'Inter', sans-serif;
    }

    .task-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .staff-avatar {
        width: 80px;
        height: 80px;
        border: 3px solid #fff;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .staff-avatar-placeholder {
        width: 80px;
        height: 80px;
        margin: 0 auto;
        font-size: 1.5rem;
    }

    .checklist-item {
        transition: all 0.3s ease;
        border-radius: 8px;
    }

    .checklist-item:hover {
        background-color: #f8f9fa;
        transform: translateX(5px);
    }

    .form-check-input:checked {
        background-color: #198754;
        border-color: #198754;
    }

    .detail-item {
        padding: 8px 0;
    }

    .task-description {
        border-left: 4px solid #667eea;
    }

    .log-item {
        transition: all 0.2s ease;
    }

    .log-item:hover {
        background-color: #f8f9fa;
        border-radius: 6px;
        padding-left: 8px;
        padding-right: 8px;
    }

    .stat-item {
        padding: 10px;
    }

    .progress {
        border-radius: 10px;
    }

    .progress-bar {
        border-radius: 10px;
    }

    .card {
        border-radius: 12px;
    }

    .time-details {
        border: 1px solid #e9ecef;
    }
</style>
<!-- Task List Table -->
@php
$helper = new \App\Helpers\Helpers();
$module_name = 'Production Management';
$menu_name = 'Manage Production';
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Production</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                <!--<a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter"-->
                <!--    title="Filter">-->
                <!--    <i class="mdi mdi-filter-outline text-center"></i>-->
                <!--</a>-->
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                    <input type="text" class="form-control" placeholder="Enter Customer Name" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Writing Products</option>
                        <option value="2">Developement Products</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Thesis Writing</option>
                        <option value="2">Technical Research and Development Services</option>
                        <option value="3">Formatting and Referencing</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Task</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Thesis Writing Support</option>
                        <option value="2">Client Onboarding & Requirement Gathering</option>
                        <option value="3">Literature Review</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Staff</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Naveen R</option>
                        <option value="2">Iswarya D</option>
                        <option value="3">Guberan J</option>
                        <option value="4">Indhumathi K</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Task Not Yet Started</option>
                        <option value="2">Task In Progress</option>
                        <option value="3">Task Completed</option>
                        <option value="4">Task Delayed</option>
                        <option value="5">Task Hold</option>
                        <option value="6">Task Not Completed</option>
                        <option value="7">Task Verified</option>
                        <option value="8">Task QC Verified</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                        onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date"
                            class="form-control this_month_dt_fill" value="<?php echo date(" M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="row">
            {{-- <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_production">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div> --}}
            <div class="col-lg-12">
                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-50px">Staff</th>
                            <th class="min-w-125px">Customer</th>
                            <th class="min-w-125px">Task</th>
                            <th class="min-w-125px">Assigned Date</th>
                            <th class="min-w-80px">No.of.Pages/<br>Percentage
                            </th>
                            <th class="min-w-100px text-center">Timer</th>
                            <th class="min-w-80px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7" id="task_table_tbody">
                        @if (isset($lists))
                            @foreach ($lists as $i=> $list)
                                @php
                                    $rework_color = $list->rework_check > 0 ? 'bg-label-danger' : '';
                                @endphp
                                <tr class="{{ $rework_color }}">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="symbol symbol-35px me-2">
                                                <div class="image-input image-input-circle" data-kt-image-input="true">
                                                    @if ($list->staff_image && file_exists(public_path('staff_images/' .
                                                    $list->staff_image)))
                                                    <img src="{{ asset('staff_images/' . $list->staff_image) }}" alt="Staff"
                                                        class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                                    @else
                                                    {!! $helper->name_image(strtoupper(substr($list->staff_name, 0, 1)),
                                                    $list->gender) !!}
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="mb-0">
                                                <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff">{{
                                                    $list->staff_name }}</label>
                                                <div class="d-block">
                                                    <div class="text-dark fs-8" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Staff Nick Name">{{ $list->nick_name
                                                        }}</div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <label class="text-black d-block fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Customer">{{ $list->cus_name }}</label>
                                        <label class="text-info fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Customer ID">{{ $list->customer_id }}</label>
                                        <label class="text-danger d-block fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Last Date">{{ $list->development_date ?
                                            Carbon::parse($list->development_date)->format('d-M-Y') : '-' }}</label>
                                    </td>
                                    <td>
                                        <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Task">{{
                                            $list->task_name }}</label>
                                        <div class="d-block">
                                            <label
                                                class="bg-warning text-black rounded px-2 mb-1 py-0 fw-semibold fs-8 text-wrap"
                                                data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service">{{
                                                $list->product_name }}</label>
                                        </div>
                                        @php
                                        $percentage = $helper->completed_task_percentage($list->sno);
                                        @endphp
                                        <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Task Progress : {{ $percentage }}%">
                                            <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                                                role="progressbar" style="width: {{ $percentage }}%"
                                                aria-valuenow="{{ $percentage }}" aria-valuemin="{{ $percentage }}"
                                                aria-valuemax="{{ $percentage }}">{{ $percentage }}%</div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-column align-items-center gap-2">
                                            <label class="fs-7 bg-danger text-white px-2 py-1" data-bs-toggle="tooltip"
                                                data-bs-placement="top" title="Assigned Date">
                                                <?php echo $list->task_date ? date("d-M-Y", strtotime($list->task_date)) : '-'; ?>
                                            </label>
                                            @if ($list->rework_check > 0)
                                            <a href="javascript:;" class="badge rework-badge high text-white fs-6 ms-2" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_rework_details" onclick="reworkDetails('{{ $list->sno }}', '{{ $list->staff_id }}')">
                                                    Rework {{ $list->rework_check < 10 ? str_pad($list->rework_check, 2, '0', STR_PAD_LEFT) : $list->rework_check }}
                                                </a>
                                            @endif
                                        </div>
                                    </td>
                                    <td>
                                        @php
                                            $page_or_per = $list->task_category == 1 ? 'Percentages' : 'Pages';
                                        @endphp
                                        <label class="bg-danger rounded-2 px-2 py-1 fw-semibold text-white fs-5 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Total {{ $page_or_per }}">{{ $list->max_page_or_per }}</label>
                                        /
                                        <label class="bg-success rounded-2 ms-1 px-2 py-1 fw-semibold text-white fs-5 me-1"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Completed {{ $page_or_per }}">{{ $list->min_page_or_per }}</label>
                                    </td>
                                    <td>
                                        @php
                                            $task_pending_or_not = $helper->task_pending_or_not($list->staff_id, $list->sno);
                                            $get_task_status = $helper->get_task_status($list->staff_id, $list->sno);
                                        @endphp
                                        @if ($list->status == 0 || $list->status == 2)
                                            @if($get_task_status)
                                                <a href="javascript:;" class="badge bg-info text-black mb-1 fs-7 fw-semibold"
                                                    style="background-color: #fade10 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <span>Task In Progress</span>
                                                </a>
                                            @else
                                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                    style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    <span>Task Not Yet Started</span>
                                                </a>
                                            @endif
                                        @elseif ($list->status == 3)
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                style="background-color: #008000 !important;">
                                                <span>Completed</span>
                                            </a>
                                        @elseif ($list->status > 3)
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                style="background-color: #000080 !important;">
                                                <span>QC Verified</span>
                                            </a>
                                        @elseif ($list->status == 5)
                                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                style="background-color: #008080 !important;">
                                                <span>Delivery Verified</span>
                                            </a>
                                        @endif
                                    </td>
                            <td>

                                <div class="mb-1 text-center">
                                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_task" onclick="view_task({{$list->sno}})">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                class="mdi mdi-eye-outline fs-3"></i></span>
                                    </a>
                                    @endif
                                </div>
                                </div>
                                </td>
                                </tr>
                            @endforeach
                        @endif
        </tbody>
        </table>
        <!-- </div> -->
    </div>
</div>
</div>
</div>

<!--begin::Modal - View Rework-->
<div class="modal fade" id="kt_modal_rework_details" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black fw-bold">
                        <label>
                            <span class="mb-2 fs-2 fw-semibold ">Rework Details</span>
                            <span class="text-danger fw-bold fs-2 px-2 py-1 mt-4" id="task_log_tsk_name">-</span>
                        </label>
                    </h3>
                </div>

                <div class="row mx-3">
                    <div class="col-lg-12" id="rework_details_container">

                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Rework-->

<!--begin::Modal - Complete Task -->
<div class="modal fade" id="kt_modal_complete_task" tabindex="-1" aria-hidden="true" 
     data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded-4">
            <!--begin::Modal header-->
            <div class="modal-header border-0 pb-0 align-items-center">
                <!--begin::Close-->
                <button type="button" class="btn btn-sm btn-icon btn-active-color-primary ms-auto" data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-2">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                </button>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            
            <!--begin::Modal body-->
            <div class="modal-body pt-6 pb-8 px-8 px-xl-12">
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Task Complete</h3>
                </div>
                <div class="task-view-container">
                    <!-- Header Section -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="task-header bg-gradient-primary text-white rounded-3 p-4 shadow-sm">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <h2 class="mb-1 fw-bold fs-2" style="color: #ffeca9 " id="comp_tsk_tsk_name">
                                            Task Name Here
                                        </h2>
                                        <p class="mb-0 opacity-75">
                                            <i class="mdi mdi-account-outline me-1"></i>
                                            Created by <span id="com_tsk_created_staff">Staff Name</span>
                                        </p>
                                    </div>
                                    <div class="task-badge">
                                        <span class="badge bg-white text-primary fs-6 px-3 py-2" id="com_tsk_tsk_id">
                                            -
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                    <!-- Main Content Grid -->
                    <div class="row">
                        <input type="hidden" name="task_status_id" id="task_status_id">
                        <!-- Left Column - Task Details -->
                        <div class="col-lg-8">
                            <!-- Customer & Service Info Card -->
                            <div class="card border-0 shadow-sm mb-4">
                                <div class="card-header bg-transparent border-0 py-3">
                                    <h5 class="card-title mb-0 text-dark">
                                        <i class="mdi mdi-information-outline text-primary me-2"></i>
                                        Task Details
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-account-circle-outline me-1"></i>
                                                    Customer
                                                </label>
                                                <div class="fw-bold text-dark fs-6">
                                                    <span id="com_tsk_cus_name">-</span>
                                                    <small class="text-primary ms-1" id="com_tsk_cus_id"></small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-phone-outline me-1"></i>
                                                    Contact
                                                </label>
                                                <div class="fw-bold text-dark fs-6" id="com_tsk_cus_mobile">
                                                    -
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-cog-outline me-1"></i>
                                                    Service
                                                </label>
                                                <div class="fw-bold text-dark fs-6" id="com_task_pro_name">
                                                    -
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-dropbox me-1"></i>
                                                    Product Category
                                                </label>
                                                <div class="fw-bold text-dark fs-6" id="com_task_cat_name">
                                                    -
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-package-variant me-1"></i>
                                                    Variant
                                                </label>
                                                <div class="fw-bold text-dark fs-6" id="com_tsk_variant_name">
                                                    -
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-1">
                                                    <i class="mdi mdi-tune-vertical me-1"></i>
                                                    Variable
                                                </label>
                                                <div class="fw-bold text-dark fs-6" id="com_tsk_variable_name">
                                                    -
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="detail-item">
                                                <label class="text-muted small fw-semibold mb-2">
                                                    <i class="mdi mdi-text-long me-1"></i>
                                                    Description
                                                </label>
                                                <div class="task-description bg-light rounded-2 p-3">
                                                    <p class="mb-0 text-dark fs-6" id="com_tsk_tsk_desc">
                                                        -
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                
                            <!-- Checklist & Progress in Same Row -->
                            <div class="row">
                                <!-- Progress Summary -->
                                <div class="col-lg-12">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-header bg-transparent border-0 py-3">
                                            <h5 class="card-title mb-0 text-dark">
                                                <i class="mdi mdi-chart-pie text-warning me-2"></i>
                                                Progress Summary
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="progress-summary text-center">
                                                <div class="row mb-3 range-container">
                                                    <label for="formRangeMax" class="form-label text-info fs-5 mb-4 fw-bold">
                                                        Number Of <span id="com_task_page_or_per">Pages</span> Completed:
                                                        <span id="currentValue" class="current-value bg-success fs-4 px-2 py-1 text-white"></span><span id="com_task_page_or_per2"></span>
                                                    </label>
                                                    <input type="hidden" name="checklist_task_id" id="checklist_task_id">
                                                    <input type="range" class="form-range mt-4" id="formRangeMax" name="num_pages" min="1" max="10" step="1" value="1"
                                                        onchange="checklistShow()" />
                                                
                                                    <div class="d-flex justify-content-between mt-2 fs-6 text-muted">
                                                        <span class="text-success fs-4 fw-semibold">Page 1</span>
                                                        <span class="text-success fs-4 fw-semibold">Page 10</span>
                                                    </div>
                                                    <div id="range_move_err" class="text-danger fs-7 fw-semibold mt-2"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Task Checklist -->
                                <div class="col-lg-12" id="checklist_container">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-header bg-transparent border-0 py-3">
                                            <h5 class="card-title mb-0 text-dark">
                                                <i class="mdi mdi-format-list-checks text-success me-2"></i>
                                                Task Checklist
                                            </h5>
                                        </div>
                                        <div class="card-body">
                                            <div id="task_check_fetch_container" style="max-height: 400px; overflow-y: auto;">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                
                        <!-- Right Column - Staff & Time Spent -->
                        <div class="col-lg-4">
                            <!-- Combined Staff Assignment & Time Spent Card -->
                            <div class="card border-0 shadow-sm">
                                <div class="card-header bg-transparent border-0 py-3">
                                    <h5 class="card-title mb-0 text-dark">
                                        <i class="mdi mdi-account-clock text-info me-2"></i>
                                        Staff & Time Tracking
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <!-- Staff Profile Section -->
                                    <div class="staff-section text-center mb-4 pb-3 border-bottom">
                                        <div class="staff-profile">
                                            <div id="com_tsk_staff_img">
                                            </div>
                                            <h6 class="mt-3 mb-1 fw-bold text-dark" id="com_tsk_pro_staff_name">-</h6>
                                            <p class="text-muted small mb-2" id="com_tsk_pro_nick_name">-</p>
                                            <span class="badge bg-info bg-opacity-10 text-info" id="com_tsk_job_pos">-</span>
                                        </div>
                                    </div>
                
                                    <!-- Total Time Spent Section -->
                                    <div class="time-spent-section text-center mb-4">
                                        <div class="total-hours">
                                            <div class="text-muted small mb-2">Allocated Hours</div>
                                            <div class="display-5 text-primary fw-bold mb-3" id="total_time">-</div>
                                        </div>
                                    </div>
                
                                    <!-- Time Logs Section -->
                                    <div class="time-logs-section">
                                        <button class="btn btn-outline-primary btn-sm w-100 mb-3" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#timeLogs">
                                            <i class="mdi mdi-clock-outline me-1"></i>
                                            View Detailed Time Logs
                                        </button>
                
                                        <div class="collapse show" id="timeLogs">
                                            <div class="time-logs-container" id="time-logs-container" style="max-height: 200px; overflow-y: auto;">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-end align-items-center mb-2">
                    <a href="{{ url('/manage_production') }}" class="btn fw-bold btn-secondary me-3 waves-effect waves-light">Cancel</a>
                    <button type="button" class="btn fw-bold btn-primary waves-effect waves-light" onclick="updateTaskValidation()" >Update Task</button>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Complete Task -->

<!--begin::Modal - Task Completed-->
<div class="modal fade" id="kt_modal_task_completed" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Task Complete</h3>
                </div>
                <form method="POST" action="{{ route('manage_production/update_task') }}" id="update_form">
                    @csrf
                    <div id="task_complete_data_div"></div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Attach Files</label>
                        <div id="dropArea" class="border p-4 text-center" style="cursor: pointer;">
                            <p id="dropMessage">Click or drag & drop files here to upload</p>
                            <input type="file" id="fileInput" multiple hidden>
                            <input type="hidden" name="uploaded_files" id="uploaded_files">
                            <div id="previewList" class="d-flex flex-wrap gap-2 mt-3"></div>
                        </div>
                    </div>
                    <input type="hidden" name="task_completedhidden" id="task_completedhidden" value="0">
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="task_completedbtn">Update Task</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Task Complete-->


<!--begin::Modal - View Task-->
<div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <label>View Task Details</label>
                        {{-- <label class="ms-1 me-1">-</label> --}}
                        {{-- <label id="view_badge"></label> --}}
                    </h3>
                </div>
                <div id="view_data_div"></div>
                <div id="submitted_document_container" class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Task-->

<!--begin::Modal - View History-->
<div class="modal fade" id="kt_modal_view_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black fw-bold">
                        <label>
                            <span class="mb-2 fs-2 fw-semibold d-block">Task Log</span>
                            <span class="bg-danger text-white fw-bold fs-5 px-2 py-1 mt-4"
                                id="task_log_tsk_name">-</span>
                        </label>
                    </h3>
                </div>

                <div class="row mx-3">
                    <div class="col-lg-12">
                        <div class="table-responsive shadow-sm">
                            <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
                                <thead>
                                    <tr class="text-start align-middle fw-bold fs-6 bg-primary text-white">
                                        <th class="min-w-50px px-3 py-2">Sno</th>
                                        <th class="min-w-125px px-3 py-2">Start Time</th>
                                        <th class="min-w-125px px-3 py-2">End Time</th>
                                        <th class="min-w-80px px-3 py-2">Duration</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-700 fw-semibold fs-7" id="task_log_tr_data">
                                    <!-- AJAX WILL POPULATE HERE -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View History-->


{{-- Dropzone.js CSS For Reviewed Form --}}
<style>
    /* Rework badge styling */
    .rework-badge {
        position: relative;
        background: linear-gradient(90deg, #f44336, #e53935);
        color: #fff;
        border-radius: 14px;
        padding: 6px 14px;
        font-weight: 600;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        letter-spacing: 0.3px;
        box-shadow: 0 0 10px rgba(244, 67, 54, 0.5);
        animation: reworkPulse 2s ease-in-out infinite;
        overflow: hidden;
    }

    /* Subtle pulse animation */
    @keyframes reworkPulse {
        0%, 100% {
            transform: scale(1);
            box-shadow: 0 0 8px rgba(244, 67, 54, 0.5);
            filter: brightness(1);
        }
        50% {
            transform: scale(1.05);
            box-shadow: 0 0 14px rgba(244, 67, 54, 0.8);
            filter: brightness(1.1);
        }
    }

    /* Glossy light sweep animation */
    .rework-badge::before {
        content: '';
        position: absolute;
        top: 0;
        left: -75%;
        width: 50%;
        height: 100%;
        background: linear-gradient(120deg, rgba(255,255,255,0.3), transparent);
        transform: skewX(-25deg);
        animation: lightSweep 3s infinite;
    }

    @keyframes lightSweep {
        0% {
            left: -75%;
        }
        50% {
            left: 125%;
        }
        100% {
            left: 125%;
        }
    }

    .rework-badge.low { background: linear-gradient(90deg, #ff9800, #f57c00); }
    .rework-badge.high { background: linear-gradient(90deg, #d32f2f, #b71c1c); }
    
    .btn-start-timer {
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        border: none !important;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .btn-start-timer:hover {
        background: linear-gradient(135deg, #218838 0%, #1e9e8a 100%);
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3) !important;
    }

    .btn-start-timer:active {
        transform: translateY(0);
        box-shadow: 0 2px 4px rgba(40, 167, 69, 0.3) !important;
    }

    .btn-end-timer {
        background: linear-gradient(135deg, #dc3545 0%, #e35d6a 100%);
        border: none !important;
        transition: all 0.3s ease;
        text-decoration: none;
    }

    .btn-end-timer:hover {
        background: linear-gradient(135deg, #c82333 0%, #d9534f 100%);
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3) !important;
    }

    .btn-end-timer:active {
        transform: translateY(0);
        box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3) !important;
    }

    /* Optional: Add pulse animation for active timer */
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(40, 167, 69, 0.7);
        }

        70% {
            box-shadow: 0 0 0 10px rgba(40, 167, 69, 0);
        }

        100% {
            box-shadow: 0 0 0 0 rgba(40, 167, 69, 0);
        }
    }

    .timer-active {
        animation: pulse 2s infinite;
    }

    .range-container {
        padding: 1.2rem 1rem;
    }
</style>
<script>
        const dropArea = document.getElementById("dropArea");
    const fileInput = document.getElementById("fileInput");
    const folderInput = document.getElementById("task_sno_complete"); // This is your folder name input (int)
    const previewList = document.getElementById("previewList");
    const dropMessage = document.getElementById("dropMessage");
    const csrfToken = document.querySelector('input[name="_token"]').value;
    let uploadedFiles = [];

    // Clicking on drop area opens file selector
    dropArea.addEventListener("click", () => fileInput.click());

    // Handle drag over
    dropArea.addEventListener("dragover", e => {
        e.preventDefault();
        dropArea.classList.add("bg-light");
    });

    // Handle drag leave
    dropArea.addEventListener("dragleave", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
    });

    // Handle drop
    dropArea.addEventListener("drop", e => {
        e.preventDefault();
        dropArea.classList.remove("bg-light");
        if (e.dataTransfer.files.length) {
            handleFiles(e.dataTransfer.files);
        }
    });

    // Handle file input change
    fileInput.addEventListener("change", e => {
        if (e.target.files.length) {
            handleFiles(e.target.files);
        }
    });

    // Convert bytes to human readable size
    function humanFileSize(size) {
        const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
        return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
    }

    // Handle preview and upload
    function handleFiles(files) {
        dropMessage.style.display = "none";

        [...files].forEach(file => {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";

            const progressBar = document.createElement("div");
            progressBar.className = "progress-bar_attach";
            const progressBarInner = document.createElement("div");
            progressBarInner.className = "progress-bar-inner";
            progressBar.appendChild(progressBarInner);

            // Show image thumbnail or icon
            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.className = "preview-thumb";
                const reader = new FileReader();
                reader.onload = e => (img.src = e.target.result);
                reader.readAsDataURL(file);
                previewItem.appendChild(img);
            } else {
                const noPreview = document.createElement("div");
                noPreview.className = "preview-thumb";
                noPreview.textContent = "📄";
                previewItem.appendChild(noPreview);
            }

            // Filename and size
            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.textContent = file.name;

            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = humanFileSize(file.size);

            previewItem.appendChild(nameDiv);
            previewItem.appendChild(sizeDiv);
            previewItem.appendChild(progressBar);
            previewList.appendChild(previewItem);

            // Upload file
            uploadFile(file, progressBarInner, function (serverFileName) {
                const removeBtn = document.createElement("button");
                removeBtn.className = "remove-btn";
                removeBtn.innerHTML = "&times;";
                removeBtn.onclick = () => {
                    previewList.removeChild(previewItem);
                    uploadedFiles = uploadedFiles.filter(f => f !== serverFileName);
                    document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);

                    if (!previewList.hasChildNodes()) {
                        dropMessage.style.display = "block";
                    }

                    // Send delete request
                    fetch("{{ route('delete_uploaded_file') }}", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json",
                            "X-CSRF-TOKEN": csrfToken
                        },
                        body: JSON.stringify({
                            file_name: serverFileName,
                            folder_name: folderInput.value  // folder name as int (stringified)
                        })
                    })
                        .then(res => res.json())
                        .then(data => {
                            if (!data.success) alert("File delete failed: " + data.message);
                        })
                        .catch(() => alert("Delete error"));
                };

                previewItem.appendChild(removeBtn);
            });
        });
    }

    // Upload via XHR
    function uploadFile(file, progressElement, callback) {
        const url = "{{ route('files_upload_production') }}";
        const formData = new FormData();
        formData.append("file_upload[]", file);
        formData.append("folder_name", $("#task_sno_complete").val()); // int folder name (e.g., "1")

        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.setRequestHeader("X-CSRF-TOKEN", csrfToken);

        xhr.upload.onprogress = function (e) {
            if (e.lengthComputable) {
                const percent = (e.loaded / e.total) * 100;
                progressElement.style.width = percent + "%";
            }
        };

        xhr.onload = function () {
            if (xhr.status === 200) {
                const res = JSON.parse(xhr.responseText);
                if (res.success && res.files.length > 0) {
                    const serverFile = res.files[0];
                    uploadedFiles.push(serverFile);
                    document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                    progressElement.style.backgroundColor = "#28a745"; // green
                    callback(serverFile);
                } else {
                    progressElement.style.backgroundColor = "#dc3545"; // red
                    alert("Upload failed: " + (res.message || "Unknown error"));
                }
            } else {
                progressElement.style.backgroundColor = "#dc3545";
                alert("Upload failed with status " + xhr.status);
            }
        };

        xhr.onerror = function () {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload error.");
        };

        xhr.send(formData);
    }


</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
</style>
<script>
    // Display Toastr messages
    @if (Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
    @endif
</script>
<script>
    function sort_filter(val) {
        if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
        } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
        }
    }
</script>
<script>
    $(document).ready(function() {
        @if ($filter_on ?? '')
            $('.filter_tbox').slideToggle('fast');
        @endif
    });
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function view_task(id) {



        fetch('/manage_production/task_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    $('#view_data_div').empty().append(data.data.html);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                    
                     const containers = document.getElementById('product_variant_container');
                    containers.innerHTML = '';
                    
                    var monitor = data.responseData;

                    const submittedContainer = document.getElementById('submitted_document_container');
                    if (!submittedContainer) {
                        console.error('Missing container');
                        return;
                    }
                    submittedContainer.innerHTML = ''; // Clear first

                    if (monitor.attachments) {
                        let attachments = [];
                        try {
                            attachments = JSON.parse(monitor.attachments);
                            console.log("Parsed attachments:", attachments);
                        } catch (e) {
                            console.error('Invalid attachments format', monitor.attachments);
                        }

                        const folder = monitor.sno;

                        if (attachments.length > 0) {
                            attachments.forEach(file => {
                                const extension = file.split('.').pop().toLowerCase();
                                const fileUrl = `/task_files/${folder}/${file}`;

                                let iconSrc = '/assets/phdizone_images/def_file.png';
                                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) {
                                    iconSrc = fileUrl;
                                } else {
                                    iconSrc = '/assets/phdizone_images/Document.jpg';
                                }

                                const html = `
                                    <div class="d-block overlay text-center me-1 px-2 py-2">
                                        <a href="${fileUrl}" target="_blank" download
                                            class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                            <img src="${iconSrc}" alt="Attachment" class="h-75px w-75px" />
                                        </a>
                                    </div>`;
                                submittedContainer.insertAdjacentHTML('beforeend', html);
                            });
                        } else {
                            submittedContainer.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
                        }
                    }

                   
                } else {
                    console.log(data.error_msg);
                }
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }
</script>
<script>
    const display = document.querySelector('#tsk_timer_button');
    const taskcsrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    let elapsedSeconds = 0;
    let timerIntervalId = null;
    let syncIntervalId = null;

    function updateDisplay(seconds) {
        let hours = Math.floor(seconds / 3600);
        let minutes = Math.floor((seconds % 3600) / 60);
        let secondsR = seconds % 60;
        let hh = hours < 10 ? "0" + hours : hours;
        let mm = minutes < 10 ? "0" + minutes : minutes;
        let ss = secondsR < 10 ? "0" + secondsR : secondsR;

        if (display) {
            if (seconds < 60) {
                display.textContent = ss + ' sec';
            } else if (seconds < 3600) {
                display.textContent = mm + ":" + ss;
            } else {
                display.textContent = hh + ":" + mm + ":" + ss;
            }
        }
    }

    function startTimer2() {
        // Clear existing interval if any
        if (timerIntervalId) clearInterval(timerIntervalId);
        if (syncIntervalId) clearInterval(syncIntervalId);

        // Start local UI timer
        timerIntervalId = setInterval(function () {
            elapsedSeconds++;
            updateDisplay(elapsedSeconds);
        }, 1000);

        // Periodically sync with server (every 6 seconds)
        syncIntervalId = setInterval(fetchElapsedTimeFromServer2, 6000);
    }

    function stopTimer2() {
        clearInterval(timerIntervalId);
        clearInterval(syncIntervalId);
        timerIntervalId = null;
        syncIntervalId = null;
    }

    function fetchElapsedTimeFromServer2() {
        fetch('/task-log/running', {
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': taskcsrfToken,
                'Accept': 'application/json'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.running && data.elapsed_seconds >= 0) {
                elapsedSeconds = data.elapsed_seconds;

                // UI updates
                $('#task_timer_hd_nav').show();
                document.getElementById("task_st_timer_icn_nav").style.display = "none";
                document.getElementById("task_ed_timer_icn_nav").style.display = "block";

                // if (!timerIntervalId) {
                    startTimer2(); // Only start if not already started
                // }

            } else {
                stopTimer2();
                display.textContent = '';
                $('#task_timer_hd_nav').hide();
                document.getElementById("task_st_timer_icn_nav").style.display = "block";
                document.getElementById("task_ed_timer_icn_nav").style.display = "none";
            }
        })
        .catch(error => {
            console.error('Timer sync failed:', error);
        });
    }

</script>
<script>
    function checkAllTaskChkBox() {
        // Check if all task checkboxes are checked
        var allChecked = $('.task_chk_box').length > 0 && $('.task_chk_box:not(:checked)').length === 0;
        // Check if all .task_perct_dbox values are 100
        var all100 = true; // assume true
        $('.task_perct_dbox').each(function() {
            if ($(this).val() !== "100") {
                all100 = false;
                return false; // break loop early
            }
        });

        // Update button based on both conditions
        if (allChecked && all100) {
            $('#task_completedbtn').html('Task Completed');
            $('#task_completedhidden').val(1);
        } else {
            $('#task_completedbtn').html('Update Task');
            $('#task_completedhidden').val(0);
        }
    }


    function task_complete(id) {
        fetch('/manage_production/task_complete/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    $('#task_complete_data_div').empty().append(data.data.html);
                    $('[data-bs-toggle="tooltip"]').tooltip();

                    const containers = document.getElementById('product_variant_container_complete');
                    containers.innerHTML = '';                

                    checkAllTaskChkBox()
                    const select2 = $('.select3');
                    if (select2.length) {
                        select2.each(function() {
                            var $this = $(this);
                            select2Focus($this);
                            $this.wrap('<div class="position-relative"></div>').select2({
                                dropdownParent: $this.parent()
                            });
                        });
                    }
                } else {
                    console.log(data.error_msg);
                }
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }
</script>
<script>
    // var refreshIntervalId;
    // var elapsedSeconds = 0;

    function endTaskModal(staff_id, task_id) {
        $('.timer_list_div').show();
        completeTaskDataFetch(task_id);
        $('#kt_modal_complete_task').modal('show');

        $('#kt_modal_complete_task').data('staff_id', staff_id);
        $('#kt_modal_complete_task').data('task_id', task_id);
    }

    function stoptaskTimer() {
        var staff_id = $('#kt_modal_complete_task').data('staff_id');
        var task_id = $('#kt_modal_complete_task').data('task_id');

        $.ajax({
            url: '/task-log/stop',
            method: 'POST',
            data: {
                task_id: task_id,
                staff_id: staff_id,
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                console.log('Timer stopped:', response);
                toastr.success('Timer stopped successfully!');
                fetchElapsedTimeFromServer2()
                fetch('/manage_production/task_table/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();  // we expect JSON now
                })
                .then(data => {
                    if (data && data.data) {
                        $('#task_table_tbody').empty().append(data.data);
                        $('[data-bs-toggle="tooltip"]').tooltip();  // re-initialize tooltips after HTML is added
                    } else {
                        console.log('No data received');
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
                // Update UI or stop frontend timer here
            },
            error: function(xhr) {
                console.error('Stop timer error:', xhr.responseText);
            }
        });
    }

    function starttaskTimer(staff_id, task_id) {
        // var display = document.querySelector('#tsk_timer');
        var whom = staff_id;

        $.ajax({
            url: '/task-log/start',
            method: 'POST',
            data: {
                task_id: task_id,
                staff_id: staff_id,
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                // console.log('Timer started:', response);
                // Start frontend timer or update UI
                toastr.success('Timer started successfully!');
                // location.reload();
                fetchElapsedTimeFromServer2()
                fetch('/manage_production/task_table/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();  // we expect JSON now
                })
                .then(data => {
                    if (data && data.data) {
                        $('#task_table_tbody').empty().append(data.data);
                        $('[data-bs-toggle="tooltip"]').tooltip();  // re-initialize tooltips after HTML is added
                    } else {
                        console.log('No data received');
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
                // $('.timer_list_div').hide();
                // $('#timer_list_div_id'+staff_id+'_'+task_id).show();
                // document.getElementById("task_st_timer_list" + whom + '_' + task_id).style.display = "none";
                // document.getElementById("task_timer_hd_nav").style.display = "inline";
                // document.getElementById("task_st_timer_icn_nav").style.display = "none";
                // document.getElementById("task_ed_timer_icn_nav").style.display = "block";
            },
            error: function(xhr) {
                if (xhr.status === 409) {
                    const res = xhr.responseJSON;
                    toastr.error(res.message || 'A timer is already running for another task.');
                    
                } else {
                    toastr.error('An error occurred while starting the timer.');
                    console.error('Start timer error:', xhr.responseText);
                }
            }
        });
    }

    function task_timer_func(val, whom, task_id) {
        if (val == 'start_timer') {
            starttaskTimer(whom, task_id);
        } else {
            endTaskModal(whom, task_id);
        }
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    const slider = document.getElementById('formRangeMax');
    const currentValue = document.getElementById('currentValue');

  slider.addEventListener('input', () => {
    let val = slider.value;
    currentValue.textContent = val;
  });
</script>

{{-- ! Complete Task Data Fetch --}}
<script>
    function completeTaskDataFetch(id) {
        $.ajax({
            url: `/complete_task_data_fetch/${id}`,
            method: 'GET',
            success: function(response) {
                if(response.status === 200) {
                    $('#range_move_err').text('');
                    var data = response.data;

                    $('#checklist_container').hide();

                    $('#comp_tsk_tsk_name').html(data.task_name);
                    $('#com_tsk_created_staff').html(data.pc_name);
                    $('#com_tsk_tsk_id').html(`# ${data.tsk_id}`);
                    $('#com_tsk_cus_name').html(data.cus_name);
                    $('#com_tsk_cus_id').html(`(${data.cus_id})`);
                    $('#com_tsk_cus_mobile').html(data.cus_mobile);
                    $('#com_task_pro_name').html(data.product_name);
                    $('#com_task_cat_name').html(data.product_category_name);
                    $('#com_tsk_variant_name').html(data.variant_name);
                    $('#com_tsk_variable_name').html(data.variable_name);
                    $('#com_tsk_tsk_desc').html(data.task_desc ? data.task_desc : 'No Description is given.');
                    $('#com_tsk_pro_staff_name').html(data.pro_staff_name);
                    $('#com_tsk_pro_nick_name').html(data.pro_nick_name);
                    $('#com_tsk_job_pos').html(data.job_position_name);
                    $('#com_tsk_staff_img').html(response.image);
                    $('#time-logs-container').html(response.html);
                    $('#total_time').html(response.total_time);

                    $('#task_status_id').val(data.sno);
                    $('#checklist_task_id').val(data.task_id);

                    // Get range input and update attributes
                    const rangeInput = document.getElementById('formRangeMax');
                    const currentValueDisplay = document.getElementById('currentValue');
                    const rangeMin = parseInt(data.min_page_or_per) || 1;
                    if(data.rework_check > 0) {
                        var rangeMax = parseInt(data.max_page_or_per);
                    } else {
                        var rangeMax = parseInt(data.pages_percentage) || 10;
                    }

                    rangeInput.min = rangeMin;
                    rangeInput.max = rangeMax;

                    // Reset value if current is outside new bounds
                    if (parseInt(rangeInput.value) < rangeMin || parseInt(rangeInput.value) > rangeMax) {
                        rangeInput.value = rangeMin;
                    }

                    // Update value display
                    currentValueDisplay.textContent = `${rangeInput.value}`;

                    // Update page labels
                    const rangeLabels = rangeInput.nextElementSibling; // .d-flex container
                    if (rangeLabels) {
                        const spans = rangeLabels.querySelectorAll('span');
                        if (spans.length === 2) {
                            spans[0].textContent = `${rangeMin}${data.task_category == 1 ? ' %' : ' Pages'}`;
                            spans[1].textContent = `${rangeMax}${data.task_category == 1 ? ' %' : ' Pages'}`;
                        }
                    }

                    // Update display on input change
                    rangeInput.addEventListener('input', function () {
                        currentValueDisplay.textContent = `${this.value}`;
                    });
                }
            },
            error: function(xhr) {
                console.error(`Error Fetching Data : ${xhr}`);
            }
        });
    }
</script>

{{-- ! Update Task Validation --}}
<script>
    function updateTaskValidation() {
        var rangeInput = document.getElementById('formRangeMax');
        var minValue = parseInt(rangeInput.min);
        var currentValue = parseInt(rangeInput.value);
        var maxValue = parseInt(rangeInput.max);
        $('#range_move_err').text('');

        if(currentValue === minValue) {
            $('#range_move_err').text('Complete at least one full page before providing an update on the task.');
            return false;
        } else {
            var sno = $('#task_status_id').val();
            
            const formData = {
                num_pages: currentValue,
                max_pages: maxValue,
                status: currentValue === maxValue ? 3 : null
            };

            if (currentValue === maxValue) {
                var checklistIds = [];
                $('.task_chk_box:checked').each(function () {
                    checklistIds.push($(this).val());
                });

                var taskId = $('#checklist_task_id').val();

                formData.task_id = taskId;
                formData.checklist_ids = checklistIds;
            }

            $.ajax({
                url: `/update_task_status/${sno}`,
                method: 'POST',
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                success: function (response) {
                    if(response.status === 200) {
                        stoptaskTimer()
                        if(currentValue === maxValue) {
                            toastr.success('Task Marked As Complete!');
                            location.reload();
                        } else {
                            toastr.success('Task Updated Successfully!');
                            location.reload();
                        }
                    } else {
                        toastr.error('Task Updation Failed!');
                    }
                },
                error: function(err) {
                    console.error('Task Creation Failed');
                }
            });
        }

        return true;
    }
</script>

{{-- ! Task Completed Checklist Data Fetch --}}
<script>
    function fetchTaskCompletedChecklist() {
        var taskId = $('#checklist_task_id').val();
        $.ajax({
            url: `/fetch_production_checklist/${taskId}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    var checklists = response.data;
                    var checklistContainer = $('#task_check_fetch_container');
                    checklistContainer.empty();

                    checklists.forEach(check => {
                        checklistContainer.append(
                            `<div class="checklist-item d-flex align-items-center p-3 border-bottom">
                                <div class="form-check mb-0 flex-grow-1">
                                    <input class="form-check-input task_chk_box" type="checkbox" name="task_check_list[]" value="${check.sno}">
                                    <label class="form-check-label text-dark fw-semibold fs-6 ms-2" for="check_1">
                                        ${check.task_checklist}
                                    </label>
                                </div>
                            </div>`
                        );
                    });
                    console.log(checklists);
                } else {
                    console.error('Task Fetching Failed');
                }
            },
            error: function(err) {
                console.error('Task Fetching Failed');
            }
        });
    }
</script>

{{-- ! Checklist Hide & Show --}}
<script>
    function checklistShow() {
        $('#checklist_container').hide();
        var rangeInput = document.getElementById('formRangeMax');
        var currentValue = parseInt(rangeInput.value);
        var maxValue = parseInt(rangeInput.max);

        if(currentValue === maxValue) {
            fetchTaskCompletedChecklist()
            $('#checklist_container').show();
        }
    }
</script>

{{-- ! Task Log Data Fetch --}}
<script>
    function fetchTaskLog(id, staffId) {
        $.ajax({
            url: `/fetch_task_log/${id}/${staffId}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    var tbody = '';

                    $.each(response.data, function(index, logs) {

                        var start = formatDateTime(logs.start_time);
                        var end = formatDateTime(logs.end_time);

                        tbody += '<tr>';
                        tbody += `<td class="px-3 py-2">${index + 1}</td>`;
                        tbody += `<td class="px-3 py-2">
                            <span class="badge text-white fs-6 fw-semibold mb-2" style="background:rgb(149 0 24) !important">${start.date} ${start.time}</span><br>
                        </td>`;
                        tbody += `<td class="px-3 py-2">
                            <span class="badge text-black fs-6 fw-semibold mb-2" style="background:#EEEE82 !important">${end.date} ${end.time}</span><br>
                        </td>`;
                        tbody += `<td class="px-3 py-2 fs-5 fw-bold" style="color: #4361ee !important;">${formatTime(logs.duration)}</td>`;
                        tbody += '</tr>';
                    });
                    $('#task_log_tr_data').html(tbody);
                    $('#task_log_tsk_name').html(response.task_name);
                } else {
                    console.error('Task Log Fetched Failed');
                }
            },
            error: function(err) {
                console.error('Task Log Fetched Failed');
            }
        });
    }

    function formatDateTime(dateTimeStr) {
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var dateObj = new Date(dateTimeStr.replace(' ', 'T')); // convert to ISO format

        var day = String(dateObj.getDate()).padStart(2, '0');
        var month = months[dateObj.getMonth()];
        var year = dateObj.getFullYear();

        var hours = dateObj.getHours();
        var minutes = String(dateObj.getMinutes()).padStart(2, '0');

        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // hour '0' should be '12'
        var hoursStr = String(hours).padStart(2, '0');

        return {
        date: `${day}-${month}-${year}`,
        time: `${hoursStr}:${minutes} ${ampm}`
        };
    }

    function formatTime(timeStr) {
        const [hours, minutes, seconds] = timeStr.split(':').map(Number);

        let result = [];

        if (hours > 0) {
            result.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
        }
        if (minutes > 0) {
            result.push(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
        }
        if (seconds > 0) {
            result.push(`${seconds} second${seconds !== 1 ? 's' : ''}`);
        }

        // If all are zero, return '0 seconds' or whatever you prefer
        if (result.length === 0) {
            return '0 seconds';
        }

        return result.join(' ');
    }
    function reworkDetails(id, staffId) {
        $.ajax({
            url: `/rework_details/${id}/${staffId}`,
            method: 'GET',
            success: function (response) {
                if(response.status === 200) {
                    $('#rework_details_container').html(response.data);
                    $('#task_log_tsk_name').html(response.task_name);
                } else {
                    console.error('Rework History Fetched Failed');
                }
            },
            error: function(err) {
                console.error('Rework History Fetched Failed');
            }
        });
    }
</script>
@endsection