@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Production Management';
    $menu_name = 'Manage Production';
@endphp
@if (auth()->user()->hasPermission($module_name, 'List', $menu_name))
    @if (isset($ListTable))
        @foreach ($ListTable as $i => $list)
            @php
                $staff_image = $list['staff_image'] ?? '';
                $staff_name = $list['staff_name'] ?? 'A';
                $gender = $list['gender'] ?? 0;
            @endphp
            <tr>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle" data-kt-image-input="true">
                                @if ($staff_image && file_exists(public_path('staff_images/' . $staff_image)))
                                    <img src="{{ asset('staff_images/' . $staff_image) }}" alt="Staff"
                                        class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                @else
                                    {!! $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender) !!}
                                @endif
                            </div>
                        </div>
                        <div class="mb-0">
                            <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip"
                                data-bs-placement="bottom" title="Staff">{{ $list['staff_name'] }}</label>
                            <div class="d-block">
                                <div class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Staff Nick Name">{{ $list['nick_name'] }}</div>
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    @php
                        $percentage = $helper->completed_task_percentage($list['sno']);
                    @endphp
                    <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Task">{{ $list['product_task_name'] }}</label>
                    <div class="d-block">
                        <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Customer">{{ $list['cus_name'] }}</label>
                        <label class="text-dark"><i class="mdi mdi-chevron-double-right fs-4"></i></label>
                        <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Services">{{ $list['product_name'] }}</label>
                    </div>
                    <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Task Progress : {{ $percentage }}%">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                            role="progressbar" style="width: {{ $percentage }}%" aria-valuenow="{{ $percentage }}"
                            aria-valuemin="{{ $percentage }}" aria-valuemax="{{ $percentage }}">
                            {{ $percentage }}%</div>
                    </div>
                </td>
                <td>
                    <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Start Date">
                        <?php echo $list['start_date_time'] ? date('d-M-Y h:i A', strtotime($list['start_date_time'])) : '-'; ?>
                    </label>
                    <div class="d-block">
                        <label class="badge bg-danger fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="End Date">
                            <?php echo $list['end_date_time'] ? date('d-M-Y h:i A', strtotime($list['end_date_time'])) : '-'; ?>
                        </label>
                    </div>
                </td>
                <td>
                    @php
                        $check_list = json_decode($list['task_check_list_ids'], true);
                        $check_list_count = is_array($check_list) ? count($check_list) : 0;
                        $completed_count = $helper->completed_task_details($list['sno']) ?? 0;
                        $balance_count = $check_list_count - $completed_count;
                    @endphp
                    <label class="badge bg-secondary rounded-pill fw-semibold text-white fs-7 me-1"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Total Checklist">{{ str_pad($check_list_count ?? 0, 2, '0', STR_PAD_LEFT) ?? '0' }}</label>
                    <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7 me-2"
                        data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Checklist"
                        style="border:1px solid #08a34f;">{{ str_pad($completed_count ?? 0, 2, '0', STR_PAD_LEFT) ?? '0' }}</label>
                    <label class="badge bg-danger rounded-pill fw-semibold text-white fs-7" data-bs-toggle="tooltip"
                        data-bs-placement="bottom"
                        title="Pending Checklist">{{ str_pad($balance_count ?? 0, 2, '0', STR_PAD_LEFT) ?? '0' }}</label>
                </td>
                <td>
                    @if ($list['status'] == 0)
                        <a class="cursor-pointer badge fs-7 fw-semibold text-white"
                            style="background-color: #008080 !important;">
                            <span>Task Assigned</span>
                        </a>
                    @elseif ($list['status'] == 5)
                        <a class="cursor-pointer badge fs-7 fw-semibold text-black"
                            style="background-color: #FFDF20 !important;">
                            <span>Task On Hold</span>
                        </a>
                    @elseif($list['status'] == 1)
                        <a class="cursor-pointer badge bg-info text-black fs-7 fw-semibold" data-bs-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false" style="background-color: #FFA500 !important;">
                            <span>Task In Progress</span>
                            <span class="ms-2"><i class="mdi mdi-menu-down text-black"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-start">
                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_task_completed"
                                onclick="task_complete({{ $list['sno'] }})">Task
                                Completed</span></a>
                        </div>
                    @else
                        <a class="cursor-pointer badge fs-7 fw-semibold text-white"
                            style="background-color: #218838 !important;">
                            <span>Task Completed</span>
                        </a>
                    @endif
                </td>
                <td>
                    @php
                        if ($list['status'] == 3) {
                            $product_task_name = 'Completed';
                            $task_color = '#218838';
                            $task_text_color = 'text-white';
                        } elseif ($list['status'] == 0) {
                            $product_task_name = 'Assigned';
                            $task_color = '#008080';
                            $task_text_color = 'text-white';
                        } else {
                            $product_task_name = 'In Progress';
                            $task_color = '#FFA500';
                            $task_text_color = 'text-black';
                        }
                    @endphp
                    <div class="d-flex align-items-center justify-content-between flex-wrap">
                        @php
                            $task_pending_or_not = $helper->task_pending_or_not($list['assign_staff_id'], $list['sno']);
                        @endphp

                        @if (auth()->user()->user_id == $list['assign_staff_id'])
                            @if ($list['status'] < 3)
                                <div class="mb-1 text-center timer_list_div"
                                    id="timer_list_div_id{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}">
                                    @if ($task_pending_or_not)
                                        {{-- Timer is running: show End Timer --}}
                                        <img src="{{ asset('assets/phdizone_images/header/timer_g1.gif') }}"
                                            alt="Task Running" class="image-input-wrapper w-45px h-45px"
                                            id="task_timer_icon_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}" />
                                        <div class="d-block mt-1">
                                            <a href="javascript:;"
                                                class="border border-danger rounded text-danger fw-semibold fs-7 px-2 py-0"
                                                id="task_end_timer_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}"
                                                onclick="task_timer_func('end_timer','{{ $list['assign_staff_id'] }}','{{ $list['sno'] }}');">
                                                End Timer
                                            </a>
                                        </div>
                                    @else
                                        {{-- Timer not running: show Start Timer --}}
                                        <div class="d-block mt-1">
                                            <a href="javascript:;"
                                                class="border border-success rounded text-dark fw-semibold fs-7 px-2 py-0"
                                                id="task_st_timer_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}"
                                                onclick="task_timer_func('start_timer','{{ $list['assign_staff_id'] }}','{{ $list['sno'] }}');">
                                                Start Timer
                                            </a>
                                        </div>
                                    @endif
                                </div>
                            @endif
                        @endif

                        <div class="mb-1 text-end">
                            @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal"
                                    data-bs-target="#kt_modal_view_task"
                                    onclick="view_task({{ $list['sno'] }},'{{ $product_task_name }}','{{ $task_color }}','{{ $task_text_color }}')">
                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                            class="mdi mdi-eye-outline fs-3"></i></span>
                                </a>
                            @endif
                        </div>
                    </div>
                </td>
            </tr>
        @endforeach
    @endif
@endif
