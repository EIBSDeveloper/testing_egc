@extends('layouts/layoutMaster')

@section('title', 'Manage Production')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }

    .bg-hov:hover {
        background-color: #eae1fc !important;
    }

    .task_perct_dbox .select2-selection--single {
        height: 2rem !important;
    }

    .task_perct_dbox .select2-selection__rendered {
        line-height: 1.8rem !important;
    }

    .task_perct_dbox .select2-selection__arrow {
        line-height: 1.8rem !important;
        height: 2rem !important;
    }
</style>
<!-- Task List Table -->
@php
$helper = new \App\Helpers\Helpers();
$module_name = 'Production Management';
$menu_name = 'Manage Production';
@endphp
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Production</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                @if(auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter"
                    title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                </a>
                @endif
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                    <input type="text" class="form-control" placeholder="Enter Customer ID" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                    <input type="text" class="form-control" placeholder="Enter Customer Name" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Writing Products</option>
                        <option value="2">Developement Products</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Thesis Writing</option>
                        <option value="2">Technical Research and Development Services</option>
                        <option value="3">Formatting and Referencing</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Task</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Thesis Writing Support</option>
                        <option value="2">Client Onboarding & Requirement Gathering</option>
                        <option value="3">Literature Review</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Staff</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Naveen R</option>
                        <option value="2">Iswarya D</option>
                        <option value="3">Guberan J</option>
                        <option value="4">Indhumathi K</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Task Not Yet Started</option>
                        <option value="2">Task In Progress</option>
                        <option value="3">Task Completed</option>
                        <option value="4">Task Delayed</option>
                        <option value="5">Task Hold</option>
                        <option value="6">Task Not Completed</option>
                        <option value="7">Task Verified</option>
                        <option value="8">Task QC Verified</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                        onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i
                                class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date"
                            class="form-control this_month_dt_fill" value="<?php echo date(" M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control"
                            value="<?php echo date(" d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_production">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-50px">Staff</th>
                            <th class="min-w-125px">Task</th>
                            <th class="min-w-125px">Assigned Date</th>
                            <th class="min-w-80px">Checklist<br><span data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Total / Complete / Pending">(T / C / P)</span>
                            </th>
                            <th class="min-w-100px">Status</th>
                            <th class="min-w-80px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7" id="task_table_tbody">
                        @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                        @if (isset($ListTable))
                        @foreach ($ListTable as $i=> $list)
                        @php
                        $staff_image = $list['staff_image'] ?? "";
                        $staff_name = $list['staff_name'] ?? "A";
                        $gender = $list['gender'] ?? 0;
                        @endphp
                        <tr>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-35px me-2">
                                        <div class="image-input image-input-circle" data-kt-image-input="true">
                                            @if ($staff_image && file_exists(public_path('staff_images/' .
                                            $staff_image)))
                                            <img src="{{ asset('staff_images/' . $staff_image) }}" alt="Staff"
                                                class="image-input-wrapper w-45px h-45px" id="uploadedlogo" />
                                            @else
                                            {!! $helper->name_image(strtoupper(substr($staff_name, 0, 1)), $gender) !!}
                                            @endif
                                        </div>
                                    </div>
                                    <div class="mb-0">
                                        <label class="fs-7 text-black fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Staff">{{ $list['staff_name'] }}</label>
                                        <div class="d-block">
                                            <div class="text-dark fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Staff Nick Name">{{ $list['nick_name']
                                                }}</div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                @php
                                $percentage = $helper->completed_task_percentage($list['sno']);
                                @endphp
                                <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Task">{{ $list['product_task_name'] }}</label>
                                <div class="d-block">
                                    <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Customer">{{ $list['cus_name'] }}</label>
                                    <label class="text-dark"><i class="mdi mdi-chevron-double-right fs-4"></i></label>
                                    <label class="text-dark fw-semibold fs-8 text-wrap" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="Services">{{ $list['product_name'] }}</label>
                                </div>
                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Task Progress : {{$percentage}}%">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                                        role="progressbar" style="width: {{$percentage}}%"
                                        aria-valuenow="{{$percentage}}" aria-valuemin="{{$percentage}}"
                                        aria-valuemax="{{$percentage}}">{{$percentage}}%</div>
                                </div>
                            </td>
                            <td>
                                <label class="fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                    title="Start Date">
                                    <?php echo $list['start_date_time'] ? date("d-M-Y h:i A", strtotime($list['start_date_time'])) : '-'; ?>
                                </label>
                                <div class="d-block">
                                    <label class="badge bg-danger fs-8" data-bs-toggle="tooltip"
                                        data-bs-placement="bottom" title="End Date">
                                        <?php echo $list['end_date_time'] ? date("d-M-Y h:i A", strtotime($list['end_date_time'])) : '-'; ?>
                                    </label>
                                </div>
                            </td>
                            <td>
                                @php
                                $check_list = json_decode($list['task_check_list_ids'], true);
                                $check_list_count = is_array($check_list) ? count($check_list) : 0;
                                $completed_count = $helper->completed_task_details($list['sno'])??0;
                                $balance_count = $check_list_count - $completed_count;
                                @endphp
                                <label class="badge bg-secondary rounded-pill fw-semibold text-white fs-7 me-1"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Total Checklist">{{
                                    str_pad($check_list_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>
                                <label class="badge bg-transparent rounded-pill fw-semibold text-black fs-7 me-2"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed Checklist"
                                    style="border:1px solid #08a34f;">{{ str_pad($completed_count??0, 2, '0',
                                    STR_PAD_LEFT)??'0' }}</label>
                                <label class="badge bg-danger rounded-pill fw-semibold text-white fs-7"
                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Pending Checklist">{{
                                    str_pad($balance_count??0, 2, '0', STR_PAD_LEFT)??'0' }}</label>
                            </td>
                            <td>
                                @if ($list['status'] == 0)
                                <a class="cursor-pointer badge fs-7 fw-semibold text-white"
                                    style="background-color: #008080 !important;">
                                    <span>Task Assigned</span>
                                </a>
                                @elseif ($list['status'] == 5)
                                <a class="cursor-pointer badge fs-7 fw-semibold text-black" style="background-color: #FFDF20 !important;">
                                    <span>Task On Hold</span>
                                </a>
                                @elseif( $list['status'] == 1)
                                <a class="cursor-pointer badge bg-info text-black fs-7 fw-semibold"
                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                    style="background-color: #FFA500 !important;">
                                    <span>Task In Progress</span>
                                    <span class="ms-2"><i class="mdi mdi-menu-down text-black"></i></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-start">
                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_task_completed"
                                        onclick="task_complete({{$list['sno']}})">Task Completed</span></a>
                                </div>
                                @else
                                    <a class="cursor-pointer badge fs-7 fw-semibold text-white" style="background-color: #218838 !important;">
                                        <span>Task Completed</span>
                                    </a>
                                @endif
                            </td>
                            <td>
                                @php
                                if ($list['status'] == 3){
                                $product_task_name = 'Completed';
                                $task_color = '#218838';
                                $task_text_color = 'text-white';
                                } elseif ($list['status'] == 0) {
                                $product_task_name = 'Assigned';
                                $task_color = '#008080';
                                $task_text_color = 'text-white';
                                }
                                else{
                                $product_task_name = 'In Progress';
                                $task_color = '#FFA500';
                                $task_text_color = 'text-black';
                                }
                                @endphp
                                <div class="d-flex align-items-center justify-content-between flex-wrap">
                                    @php
                                    $task_pending_or_not = $helper->task_pending_or_not($list['assign_staff_id'],
                                    $list['sno']);
                                    @endphp

                                    @if(auth()->user()->user_id == $list['assign_staff_id'])
                                    @if ($list['status'] < 3) <div class="mb-1 text-center timer_list_div"
                                        id="timer_list_div_id{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}">
                                        @if($task_pending_or_not)
                                        {{-- Timer is running: show End Timer --}}
                                        <img src="{{ asset('assets/phdizone_images/header/timer_g1.gif') }}"
                                            alt="Task Running" class="image-input-wrapper w-45px h-45px"
                                            id="task_timer_icon_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}" />
                                        <div class="d-block mt-1">
                                            <a href="javascript:;"
                                                class="border border-danger rounded text-danger fw-semibold fs-7 px-2 py-0"
                                                id="task_end_timer_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}"
                                                onclick="task_timer_func('end_timer','{{ $list['assign_staff_id'] }}','{{ $list['sno'] }}');">
                                                End Timer
                                            </a>
                                        </div>
                                        @else
                                        {{-- Timer not running: show Start Timer --}}
                                        <div class="d-block mt-1">
                                            <a href="javascript:;"
                                                class="border border-success rounded text-dark fw-semibold fs-7 px-2 py-0"
                                                id="task_st_timer_list{{ $list['assign_staff_id'] }}_{{ $list['sno'] }}"
                                                onclick="task_timer_func('start_timer','{{ $list['assign_staff_id'] }}','{{ $list['sno'] }}');">
                                                Start Timer
                                            </a>
                                        </div>
                                        @endif
                                </div>
                                @endif
                                @endif

                                <div class="mb-1 text-end">
                                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                    <a href="javascript:;" class="text-black fw-bold" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_view_task"
                                        onclick="view_task({{$list['sno']}},'{{$product_task_name}}','{{$task_color}}','{{$task_text_color}}')">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i
                                                class="mdi mdi-eye-outline fs-3"></i></span>
                                    </a>
                                    @endif
                                </div>
            </div>
            </td>
            </tr>
            @endforeach
            @endif
            @endif
            </tbody>
            </table>
            <!-- </div> -->
        </div>
        <div class="mt-4">
            {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
        </div>
    </div>
</div>
</div>


<!--begin::Modal - Task Completed-->
<div class="modal fade" id="kt_modal_task_completed" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Task Complete</h3>
                </div>
                <form method="POST" action="{{ route('manage_production/update_task') }}" id="update_form">
                    @csrf
                    <div id="task_complete_data_div"></div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Attach Files</label>
                        <div id="dropArea" class="border p-4 text-center" style="cursor: pointer;">
                            <p id="dropMessage">Click or drag & drop files here to upload</p>
                            <input type="file" id="fileInput" multiple hidden>
                            <input type="hidden" name="uploaded_files" id="uploaded_files">
                            <div id="previewList" class="d-flex flex-wrap gap-2 mt-3"></div>
                        </div>
                    </div>
                    <input type="hidden" name="task_completedhidden" id="task_completedhidden" value="0">
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="task_completedbtn">Update Task</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Task Complete-->


<!--begin::Modal - View Task-->
<div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-6">
                    <h3 class="text-center text-black">
                        <label>View Task Details</label>
                        <label class="ms-1 me-1">-</label>
                        <label id="view_badge"></label>
                    </h3>
                </div>
                <div id="view_data_div"></div>
                <div id="submitted_document_container" class="d-flex mb-1 align-items-center flex-wrap gap-2 px-2 py-1">
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Task-->


{{-- Dropzone.js CSS For Reviewed Form --}}
<style>
    .preview-item {
        position: relative;
        width: 150px;
        border: 1px solid #ccc;
        padding: 5px;
        border-radius: 5px;
        text-align: center;
    }

    .preview-thumb {
        width: 100%;
        height: 100px;
        object-fit: contain;
    }

    .remove-btn {
        position: absolute;
        top: -8px;
        right: -8px;
        background: red;
        color: white;
        border: none;
        border-radius: 50%;
        width: 22px;
        height: 22px;
        font-size: 14px;
        cursor: pointer;
    }

    .progress-bar_attach {
        width: 100%;
        background: #eee;
        height: 5px;
        margin-top: 5px;
    }

    .progress-bar-inner {
        height: 5px;
        width: 0%;
        background-color: blue;
        transition: width 0.3s;
    }
</style>
<script>
    const dropArea = document.getElementById("dropArea");
const fileInput = document.getElementById("fileInput");
const folderInput = document.getElementById("task_sno_complete"); // This is your folder name input (int)
const previewList = document.getElementById("previewList");
const dropMessage = document.getElementById("dropMessage");
const csrfToken = document.querySelector('input[name="_token"]').value;
let uploadedFiles = [];

// Clicking on drop area opens file selector
dropArea.addEventListener("click", () => fileInput.click());

// Handle drag over
dropArea.addEventListener("dragover", e => {
    e.preventDefault();
    dropArea.classList.add("bg-light");
});

// Handle drag leave
dropArea.addEventListener("dragleave", e => {
    e.preventDefault();
    dropArea.classList.remove("bg-light");
});

// Handle drop
dropArea.addEventListener("drop", e => {
    e.preventDefault();
    dropArea.classList.remove("bg-light");
    if (e.dataTransfer.files.length) {
        handleFiles(e.dataTransfer.files);
    }
});

// Handle file input change
fileInput.addEventListener("change", e => {
    if (e.target.files.length) {
        handleFiles(e.target.files);
    }
});

// Convert bytes to human readable size
function humanFileSize(size) {
    const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
    return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
}

// Handle preview and upload
function handleFiles(files) {
    dropMessage.style.display = "none";

    [...files].forEach(file => {
        const previewItem = document.createElement("div");
        previewItem.className = "preview-item";

        const progressBar = document.createElement("div");
        progressBar.className = "progress-bar_attach";
        const progressBarInner = document.createElement("div");
        progressBarInner.className = "progress-bar-inner";
        progressBar.appendChild(progressBarInner);

        // Show image thumbnail or icon
        if (file.type.startsWith("image/")) {
            const img = document.createElement("img");
            img.className = "preview-thumb";
            const reader = new FileReader();
            reader.onload = e => (img.src = e.target.result);
            reader.readAsDataURL(file);
            previewItem.appendChild(img);
        } else {
            const noPreview = document.createElement("div");
            noPreview.className = "preview-thumb";
            noPreview.textContent = "📄";
            previewItem.appendChild(noPreview);
        }

        // Filename and size
        const nameDiv = document.createElement("div");
        nameDiv.className = "preview-filename";
        nameDiv.textContent = file.name;

        const sizeDiv = document.createElement("div");
        sizeDiv.className = "preview-size";
        sizeDiv.textContent = humanFileSize(file.size);

        previewItem.appendChild(nameDiv);
        previewItem.appendChild(sizeDiv);
        previewItem.appendChild(progressBar);
        previewList.appendChild(previewItem);

        // Upload file
        uploadFile(file, progressBarInner, function (serverFileName) {
            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "&times;";
            removeBtn.onclick = () => {
                previewList.removeChild(previewItem);
                uploadedFiles = uploadedFiles.filter(f => f !== serverFileName);
                document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);

                if (!previewList.hasChildNodes()) {
                    dropMessage.style.display = "block";
                }

                // Send delete request
                fetch("{{ route('delete_uploaded_file') }}", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": csrfToken
                    },
                    body: JSON.stringify({
                        file_name: serverFileName,
                        folder_name: folderInput.value  // folder name as int (stringified)
                    })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (!data.success) alert("File delete failed: " + data.message);
                    })
                    .catch(() => alert("Delete error"));
            };

            previewItem.appendChild(removeBtn);
        });
    });
}

// Upload via XHR
function uploadFile(file, progressElement, callback) {
    const url = "{{ route('files_upload_production') }}";
    const formData = new FormData();
    formData.append("file_upload[]", file);
    formData.append("folder_name", $("#task_sno_complete").val()); // int folder name (e.g., "1")

    const xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("X-CSRF-TOKEN", csrfToken);

    xhr.upload.onprogress = function (e) {
        if (e.lengthComputable) {
            const percent = (e.loaded / e.total) * 100;
            progressElement.style.width = percent + "%";
        }
    };

    xhr.onload = function () {
        if (xhr.status === 200) {
            const res = JSON.parse(xhr.responseText);
            if (res.success && res.files.length > 0) {
                const serverFile = res.files[0];
                uploadedFiles.push(serverFile);
                document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                progressElement.style.backgroundColor = "#28a745"; // green
                callback(serverFile);
            } else {
                progressElement.style.backgroundColor = "#dc3545"; // red
                alert("Upload failed: " + (res.message || "Unknown error"));
            }
        } else {
            progressElement.style.backgroundColor = "#dc3545";
            alert("Upload failed with status " + xhr.status);
        }
    };

    xhr.onerror = function () {
        progressElement.style.backgroundColor = "#dc3545";
        alert("Upload error.");
    };

    xhr.send(formData);
}


</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
    /* Customize Toastr container */
    .toast {
        background-color: #39484f;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .err_msg {
        /* background-color: red; */
        border-color: red;
    }
</style>
<script>
    // Display Toastr messages
    @if (Session::has('toastr'))
        var type = "{{ Session::get('toastr')['type'] }}";
        var message = "{{ Session::get('toastr')['message'] }}";
        toastr[type](message);
    @endif
</script>
<script>
    function sort_filter(val) {
        if (val != "") {
        $('.sorting_filter_class').val(val);
        $('#search_form').submit();
        } else {
        $('.sorting_filter_class').val(10);
        $('#search_form').submit();
        }
    }
</script>
<script>
    $(document).ready(function() {
        @if ($filter_on ?? '')
            $('.filter_tbox').slideToggle('fast');
        @endif
    });
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function view_task(id,task_name,color,text_color) {

        $('#view_badge').html(`
                            <span class="badge bg-info ${text_color || ''} rounded fw-semibold fs-5" 
                                    style="background-color: ${color || ''} !important;">
                                ${task_name || ''}
                            </span>
                            `);


        fetch('/manage_production/task_view/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    $('#view_data_div').empty().append(data.data.html);
                    $('[data-bs-toggle="tooltip"]').tooltip();
                    
                     const containers = document.getElementById('product_variant_container');
                    containers.innerHTML = '';
                    
                    var monitor = data.responseData;

                    const submittedContainer = document.getElementById('submitted_document_container');
                    if (!submittedContainer) {
                        console.error('Missing container');
                        return;
                    }
                    submittedContainer.innerHTML = ''; // Clear first

                    if (monitor.attachments) {
                        let attachments = [];
                        try {
                            attachments = JSON.parse(monitor.attachments);
                            console.log("Parsed attachments:", attachments);
                        } catch (e) {
                            console.error('Invalid attachments format', monitor.attachments);
                        }

                        const folder = monitor.sno;

                        if (attachments.length > 0) {
                            attachments.forEach(file => {
                                const extension = file.split('.').pop().toLowerCase();
                                const fileUrl = `/task_files/${folder}/${file}`;

                                let iconSrc = '/assets/phdizone_images/def_file.png';
                                if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(extension)) {
                                    iconSrc = fileUrl;
                                } else {
                                    iconSrc = '/assets/phdizone_images/Document.jpg';
                                }

                                const html = `
                                    <div class="d-block overlay text-center me-1 px-2 py-2">
                                        <a href="${fileUrl}" target="_blank" download
                                            class="overlay-wrapper card-rounded w-75px h-75px border border-gray-600i rounded">
                                            <img src="${iconSrc}" alt="Attachment" class="h-75px w-75px" />
                                        </a>
                                    </div>`;
                                submittedContainer.insertAdjacentHTML('beforeend', html);
                            });
                        } else {
                            submittedContainer.innerHTML = '<span class="text-muted">No submitted documents found.</span>';
                        }
                    }

                   
                } else {
                    console.log(data.error_msg);
                }
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }
</script>
<script>
    const display = document.querySelector('#tsk_timer_button');
    const taskcsrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    let elapsedSeconds = 0;
    let timerIntervalId = null;
    let syncIntervalId = null;

    function updateDisplay(seconds) {
        let hours = Math.floor(seconds / 3600);
        let minutes = Math.floor((seconds % 3600) / 60);
        let secondsR = seconds % 60;
        let hh = hours < 10 ? "0" + hours : hours;
        let mm = minutes < 10 ? "0" + minutes : minutes;
        let ss = secondsR < 10 ? "0" + secondsR : secondsR;

        if (display) {
            if (seconds < 60) {
                display.textContent = ss + ' sec';
            } else if (seconds < 3600) {
                display.textContent = mm + ":" + ss;
            } else {
                display.textContent = hh + ":" + mm + ":" + ss;
            }
        }
    }

    function startTimer2() {
        // Clear existing interval if any
        if (timerIntervalId) clearInterval(timerIntervalId);
        if (syncIntervalId) clearInterval(syncIntervalId);

        // Start local UI timer
        timerIntervalId = setInterval(function () {
            elapsedSeconds++;
            updateDisplay(elapsedSeconds);
        }, 1000);

        // Periodically sync with server (every 6 seconds)
        syncIntervalId = setInterval(fetchElapsedTimeFromServer2, 6000);
    }

    function stopTimer2() {
        clearInterval(timerIntervalId);
        clearInterval(syncIntervalId);
        timerIntervalId = null;
        syncIntervalId = null;
    }

    function fetchElapsedTimeFromServer2() {
        fetch('/task-log/running', {
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': taskcsrfToken,
                'Accept': 'application/json'
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.running && data.elapsed_seconds >= 0) {
                elapsedSeconds = data.elapsed_seconds;

                // UI updates
                $('#task_timer_hd_nav').show();
                document.getElementById("task_st_timer_icn_nav").style.display = "none";
                document.getElementById("task_ed_timer_icn_nav").style.display = "block";

                // if (!timerIntervalId) {
                    startTimer2(); // Only start if not already started
                // }

            } else {
                stopTimer2();
                display.textContent = '';
                $('#task_timer_hd_nav').hide();
                document.getElementById("task_st_timer_icn_nav").style.display = "block";
                document.getElementById("task_ed_timer_icn_nav").style.display = "none";
            }
        })
        .catch(error => {
            console.error('Timer sync failed:', error);
        });
    }

</script>
<script>
    function checkAllTaskChkBox() {
        // Check if all task checkboxes are checked
        var allChecked = $('.task_chk_box').length > 0 && $('.task_chk_box:not(:checked)').length === 0;
        // Check if all .task_perct_dbox values are 100
        var all100 = true; // assume true
        $('.task_perct_dbox').each(function() {
            if ($(this).val() !== "100") {
                all100 = false;
                return false; // break loop early
            }
        });

        // Update button based on both conditions
        if (allChecked && all100) {
            $('#task_completedbtn').html('Task Completed');
            $('#task_completedhidden').val(1);
        } else {
            $('#task_completedbtn').html('Update Task');
            $('#task_completedhidden').val(0);
        }
    }


    function task_complete(id) {
        fetch('/manage_production/task_complete/' + id, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 200) {
                    var com = data.data;
                    $('#task_complete_data_div').empty().append(data.data.html);
                    $('[data-bs-toggle="tooltip"]').tooltip();

                    const containers = document.getElementById('product_variant_container_complete');
                    containers.innerHTML = '';                

                    checkAllTaskChkBox()
                    const select2 = $('.select3');
                    if (select2.length) {
                        select2.each(function() {
                            var $this = $(this);
                            select2Focus($this);
                            $this.wrap('<div class="position-relative"></div>').select2({
                                dropdownParent: $this.parent()
                            });
                        });
                    }
                } else {
                    console.log(data.error_msg);
                }
            })
            .catch(error => {
                console.log('Error:', error);
            });
    }
</script>
<script>
    // var refreshIntervalId;
    // var elapsedSeconds = 0;

    function stoptaskTimer(staff_id, task_id) {
        // var display = document.querySelector('#tsk_timer');
        var whom = staff_id;
         $('.timer_list_div').show();
        // clearInterval(refreshIntervalId);
        // elapsedSeconds = 0;
        // if (display) display.textContent = "";

        $.ajax({
            url: '/task-log/stop',
            method: 'POST',
            data: {
                task_id: task_id,
                staff_id: staff_id,
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                console.log('Timer stopped:', response);
                toastr.success('Timer stopped successfully!');
                fetchElapsedTimeFromServer2()
                // document.getElementById("task_end_timer_list" + whom + '_' + task_id).style.display = "none";
                // document.getElementById("task_timer_icon_list" + whom + '_' + task_id).style.display = "none";
                // document.getElementById("task_timer_hd_nav").style.display = "none";
                // document.getElementById("task_st_timer_icn_nav").style.display = "block";
                // document.getElementById("task_ed_timer_icn_nav").style.display = "none";
                fetch('/manage_production/task_table/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();  // we expect JSON now
                })
                .then(data => {
                    if (data && data.data) {
                        $('#task_table_tbody').empty().append(data.data);
                        $('[data-bs-toggle="tooltip"]').tooltip();  // re-initialize tooltips after HTML is added
                    } else {
                        console.log('No data received');
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
                // Update UI or stop frontend timer here
            },
            error: function(xhr) {
                console.error('Stop timer error:', xhr.responseText);
            }
        });
    }

    function starttaskTimer(staff_id, task_id) {
        // var display = document.querySelector('#tsk_timer');
        var whom = staff_id;

        $.ajax({
            url: '/task-log/start',
            method: 'POST',
            data: {
                task_id: task_id,
                staff_id: staff_id,
                _token: $('meta[name="csrf-token"]').attr('content')
            },
            success: function(response) {
                // console.log('Timer started:', response);
                // Start frontend timer or update UI
                toastr.success('Timer started successfully!');
                // location.reload();
                fetchElapsedTimeFromServer2()
                fetch('/manage_production/task_table/', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();  // we expect JSON now
                })
                .then(data => {
                    if (data && data.data) {
                        $('#task_table_tbody').empty().append(data.data);
                        $('[data-bs-toggle="tooltip"]').tooltip();  // re-initialize tooltips after HTML is added
                    } else {
                        console.log('No data received');
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
                // $('.timer_list_div').hide();
                // $('#timer_list_div_id'+staff_id+'_'+task_id).show();
                // document.getElementById("task_st_timer_list" + whom + '_' + task_id).style.display = "none";
                // document.getElementById("task_timer_hd_nav").style.display = "inline";
                // document.getElementById("task_st_timer_icn_nav").style.display = "none";
                // document.getElementById("task_ed_timer_icn_nav").style.display = "block";
            },
            error: function(xhr) {
                if (xhr.status === 409) {
                    const res = xhr.responseJSON;
                    toastr.error(res.message || 'A timer is already running for another task.');
                    
                } else {
                    toastr.error('An error occurred while starting the timer.');
                    console.error('Start timer error:', xhr.responseText);
                }
            }
        });
    }

    function task_timer_func(val, whom, task_id) {

        if (val == 'start_timer') {
            starttaskTimer(whom, task_id);
        } else {
            stoptaskTimer(whom, task_id);
        }
    }
</script>


<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection