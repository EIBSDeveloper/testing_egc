@extends('layouts/layoutMaster')

@section('title', 'Manage Deliverables ')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .customer_table thead th,
    .customer_table tbody td {
        padding: 8px !important;
    }

    .indv_cust_serv thead th,
    .indv_cust_serv tbody td {
        padding: 8px !important;
        /* border: 1px solid rgb(180, 180, 180) !important; */
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>


<style>
.circular-progress {
  --size: 60px;
  --progress: 0;
  --track-color: #d2e1f0;
  --fill-color: #EB5B65;

  width: var(--size);
  height: var(--size);
  border-radius: 50%;
  background: conic-gradient(
    var(--fill-color) calc(var(--progress) * 1%),
    var(--track-color) 0
  );
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  font-family: Arial, sans-serif;
  font-weight: bold;
  color: #000;
  transition: transform 0.8s ease-in-out;
  transform-style: preserve-3d;
  perspective: 800px;
}

.circular-progress::before {
  content: '';
  position: absolute;
  width: calc(var(--size) - 15px);
  height: calc(var(--size) - 15px);
  background-color: #ffffff;
  border-radius: 50%;
  z-index: 0;
}

/* Front (progress side) */
.progress-front {
  position: absolute;
  backface-visibility: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  inset: 0;
}

/* Back (success GIF side) */
.progress-back {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: rotateY(180deg);
  backface-visibility: hidden;
}

/* Flipped state */
.flip {
  transform: rotateY(180deg);
}

/* Grid layout */
.progress-grid {
  display: grid;
  grid-template-columns: repeat(3, auto);
  gap: 20px;
  justify-content: center;
  align-items: center;
  padding: 20px;
}
</style>

<style>
  .progress {
  position: relative;
  overflow: hidden;
}

.progress-bar {
  position: relative;
  animation: none !important;
}

/* Highlight animation overlay */
.progress-bar::after {
  content: "";
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    120deg,
    transparent 0%,
    rgba(255,255,255,0.6) 50%,
    transparent 100%
  );
  animation: progress-shine 2.2s infinite linear;
  border-radius: inherit;
}

@keyframes progress-shine {
  0% { left: -100%; }
  100% { left: 100%; }
}

</style>

@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Service Management';
    $menu_name   = 'Manage Deliverables';
@endphp

<!-- Customer List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Deliverables</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <form class="search_form" method="POST" action="/manage_work_order">
                <div class="row py-1">                 
                    @csrf
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"  value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                        <select class="select3 form-select" name="cat_fill">
                            <option value="" selected>All</option>
                            @if (isset($Product_cat_list))
                                @foreach ($Product_cat_list as $pc_list)
                                    <option value="{{ $pc_list->sno }}" @if($pc_list->sno == $cat_fill) selected @endif>{{ $pc_list->product_category_name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                        <select class="select3 form-select" name="product_fill">
                            <option value="" selected>All</option>
                            @if (isset($Product_list))
                                @foreach ($Product_list as $prd_list)
                                    <option value="{{ $prd_list->sno }}" @if($prd_list->sno == $product_fill) selected @endif>{{ $prd_list->product_name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                       <select class="select3 form-select" name="status_fill">
                            <option value="" @if($status_fill === null || $status_fill === '') selected @endif>All</option>
                            <option value="0" @if($status_fill == 0) selected @endif>Service Not Yet Started</option>
                            <option value="1" @if($status_fill == 1) selected @endif>Service In Progress</option>
                            <option value="2" @if($status_fill == 2) selected @endif>Service Completed</option>
                            <option value="3" @if($status_fill == 3) selected @endif>Service Delayed</option>
                            <option value="4" @if($status_fill == 4) selected @endif>Service Hold</option>
                            <option value="5" @if($status_fill == 5) selected @endif>Service Not Completed</option>
                            <option value="6" @if($status_fill == 6) selected @endif>Service Verified</option>
                            <option value="7" @if($status_fill == 7) selected @endif>Service QC Verified</option>
                            <option value="8" @if($status_fill == 8) selected @endif>Service Delivered</option>
                        </select>

                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                     <a href="{{ url('/manage_service') }}" type="button" class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Go</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="select3 form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form class="search_form" method="POST" action="/manage_work_order">
                        @csrf
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div>
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="0">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"  value="@php echo $perpage ? $perpage : 10; @endphp" />
                        <input
                            type="text"
                            class="form-control"
                            id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                            placeholder="Enter Search"
                        />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="table-responsive">
                <div class="row">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 ">
                        {{--  --}}
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Services</th>
                                <th class="min-w-150px">Customers</th>
                                <th style="min-w-100px ">CRE</th>
                                <th style="min-w-100px ">PC</th>
                                <th style="min-w-100px text-center">MileStone</th>
                                <th style="min-w-100px text-center">Delivered</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                @if (isset($ListTable))
                                @foreach ($ListTable as $i=> $list)
                                    <tr id="indv_cust_hd_{{$i}}">
                                      <td>
                                          @php
                                              $countryCode = $list->country_code ?? 91;
                                              $mobile = $list->cus_mobile ?? '';
                                              $phone_no = $mobile ? '( +'.$countryCode.' ) '. $mobile : '';
                                              $percentage = $helper->completed_service_percentage($list->sno);
                                              $year = date('Y', strtotime($list->created_at));
                                              $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
                                              $service_id = "SR-{$id}/{$year}";
                                              $milestone_data = $list->milestone_data ? $list->milestone_data : [];
                                          @endphp
                                          <div class="d-flex align-items-center gap-2">
                                              <div class="me-2 cursor-pointer">
                                                  <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-2 py-2" onclick="indv_cust_func('{{$i}}');">
                                                      <i class="mdi mdi-plus fs-4" id="indv_cust_{{$i}}_plus_btton"></i>
                                                  </a>
                                              </div>
                                              <div class="d-flex flex-column">
                                                  <div class="d-flex align-items-center">
                                                      <label class="fs-7 text-black fw-semibold text-truncate cursor-pointer"  style="max-width: 300px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_name }}">{{ $list->product_name }}</label>
                                                      <label data-bs-toggle="dropdown">
                                                              <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 cursor-pointer"
                                                                  title="Product Variant">
                                                              </span>
                                                          </label>
                                                      <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                                          <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                                              <u>Product Variant Info</u>
                                                          </div>

                                                              @php
                                                                  $variant_variable = json_decode($list->variant_variable_ids ?? '[]', true);
                                                              @endphp
                                                              
                                                              @if (!empty($variant_variable))
                                                                  @foreach ($variant_variable as $cart_item)
                                                                      @php 
                                                                          $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
                                                                          $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
                                                                      @endphp
                                                                      <div class="mb-2">
                                                                          <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                                                          <div class="text-black">{{ $variant_name ?? '-' }}</div>
                                                                          <div class="text-dark fw-semibold fs-8 mt-1">Details Variable:</div>
                                                                          <div class="text-black">{{ $variable_name ?? '-' }}</div>
                                                                      </div>
                                                                      @if (!$loop->last)
                                                                          <hr class="my-2">
                                                                      @endif
                                                                  @endforeach
                                                              @else
                                                                  <div class="text-muted fs-8 text-center">No variant data found.</div>
                                                              @endif
                                                      </div>
                                                  </div>
                                                  <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service ID">{{ $service_id }}</label>
                                              </div>
                                          </div>
                                      </td>
                                      <td>
                                        <div class="d-flex flex-column ">
                                            <div class=" text-wrap" style="width: 200px">
                                                <div class="text-black fw-semibold fs-7">
                                                    <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                    <label class="mt-1" data-bs-toggle="dropdown">
                                                    <span class="cursor-pointer p-1" style=" border-radius: 6px;
                                                    background:#e3f2fd; color:#0d47a1; font-weight:600;"><span class="mdi mdi-email"></span>
                                                </label>


                                                <div class="dropdown-menu dropdown-menu-start">
                                                    <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="d-flex px-3 flex-column align-items-start justify-content-start mb-2">
                                                            <label class="fs-8 text-black text-wrap fw-semibold" style="width: 150px;">{{ $list->cus_email_id??'-' }}</label>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>




                                                </div>
                                            </div>
                                            <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{ $list->cus_id }}</div>
                                            <label class="text-dakr fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile NO">{{$phone_no}}</label>
                                        </div>
                                      </td>
                                      <td>
                                          <div class="d-flex align-items-center">
                                          <div class="d-flex gap-2 align-items-center">
                                              @if ($list->cre_image)
                                                  <div class="w-50px h-50px">
                                                  <img
                                                  src="{{ asset('/staff_images/' . $list->cre_image) }}"
                                                  alt="avatar"
                                                  class="rounded-circle w-100 h-100"
                                                  >
                                                  </div>
                                                  <div class="d-flex flex-column justify-content-center">
                                                      <label class="badge bg-danger  px-3 py-2 fw-semibold fs-7 text-white">{{$list->cre_name}}</label>
                                                  </div>
                                              @else
                                                  <div class="d-flex flex-column gap-1">
                                                      <div class="d-flex gap-2 align-items-center">
                                                          <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                              <i class="mdi mdi-account-off fs-5"></i>
                                                          </div>
                                                          <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                      </div>
                                                  </div>
                                              @endif
                                          </div>
                                      </td>
                                      <td>
                                          <div class="d-flex align-items-center">
                                          <div class="d-flex gap-2 align-items-center">
                                              @if ($list->pc_image)
                                                  <div class="w-50px h-50px">
                                                  <img
                                                  src="{{ asset('/staff_images/' . $list->pc_image) }}"
                                                  alt="avatar"
                                                  class="rounded-circle w-100 h-100"
                                                  >
                                                  </div>
                                                  <div class="d-flex flex-column justify-content-center">
                                                      <label class="badge bg-danger  px-3 py-2 fw-semibold fs-7 text-white">{{$list->pc_name}}</label>
                                                  </div>
                                              @else
                                                  <div class="d-flex flex-column gap-1">
                                                      <div class="d-flex gap-2 align-items-center">
                                                          <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                              <i class="mdi mdi-account-off fs-5"></i>
                                                          </div>
                                                          <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                      </div>
                                                  </div>    
                                              @endif
                                          </div>
                                      </td>
                                      <td align="center">
                                        <span class="cursor-pointer px-2 py-1 fs-3"data-bs-toggle="tooltip" data-bs-placement="bottom" title="MileStone Count" style="border-radius:6px; background:#e0f7fa; color:#006064; font-weight:1000; border:1px solid #006064;"> @if (is_array($milestone_data) && count($milestone_data) > 0) {{ str_pad(count($milestone_data), 2, '0', STR_PAD_LEFT) }} @else 0 @endif</span>
                                      </td>
                                      <td align="center">
                                        <span class="cursor-pointer px-2 py-1 fs-3"data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered Count" style="border-radius:6px; background:#f3e5f5; color:#4a148c; font-weight:1000; border:1px solid #4a148c;">0</span>
                                      </td>
                                    </tr>
                                    <tr id="indv_cust_{{$i}}_tbox" style="display:none;">
                                    <td colspan="6">
                                        <table class="table align-top gy-1 gs-2 indv_cust_serv">
                                        <thead style="background:#BDE3F0;">
                                            <tr class="text-start align-top fs-6 gs-0">
                                              <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                              <th class="min-w-100px text-black fw-semibold">MileStone</th>
                                              <th class="min-w-100px text-black fw-semibold text-center">Tasks</th>
                                              <th class="min-w-100px text-black fw-semibold text-center">Tasks Status</th>
                                              <th class="min-w-50px text-black fw-semibold text-center">Staffs</th>
                                              <th class="min-w-50px text-black fw-semibold text-center">Status</th>
                                            </tr>
                                        </thead>

                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @if (is_array($milestone_data) && count($milestone_data) > 0)
                                                @foreach ($milestone_data as $mi => $mile)
                                                    <tr>
                                                        <td align="center">
                                                            <label class="mt-4">{{$mi+1}}</label>
                                                        </td>
                                                        <td>
                                                            <div class="mt-3 d-flex flex-column">
                                                                <div class="d-flex justify-content-between align-items-center mb-1">
                                                                    <span class="cursor-pointer px-2 py-1" style="border-radius:6px; background:#fff3e0; color:#e65100; font-weight:600;">{{ $mile->mile_stone_name }}</span>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="d-flex justify-content-center align-items-end">
                                                            <label class="fs-7 text-black fw-semibold text-truncate cursor-pointer" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ reset($mile->task_names) }}">{{ reset($mile->task_names) }} </label>
                                                            <label class="mt-1" data-bs-toggle="dropdown">
                                                                <span class="cursor-pointer p-1 ms-1 w-150px" style=" border-radius: 6px;
                                                                background:#e3f2fd; color:#0d47a1; font-weight:600;">More</span>
                                                            </label>
                                                            <div class="dropdown-menu dropdown-menu-start p-2">
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <div class="d-flex px-3 flex-column align-items-start justify-content-start mb-2">
                                                                            <div class="scroll-y" style="max-height: 150px;width:100%;">
                                                                                @foreach($mile->task_names as $i => $task)
                                                                                    <div class="mb-2">
                                                                                        <div class="text-dark fw-semibold fs-8">Task {{ $i + 1 }}:</div>
                                                                                        <div class="text-black fw-semibold fs-8">{{ $task }}</div>
                                                                                    </div>
                                                                                    <hr class="my-1">
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                        </td>
                                                        
                                                        <td align="center">
                                                            <div class="d-flex gap-2 align-items-center  justify-content-center">
                                                            <div class="circular-progress" data-progress="{{ $mile->milestone_percentage }}">
                                                                <div class="progress-front">
                                                                <span class="progress-value">{{ $mile->milestone_percentage }}%</span>
                                                                </div>
                                                                <div class="progress-back">
                                                                <div class="w-50px h-50px">
                                                                    <img src="{{ asset('assets/phdizone_images/Correct.gif') }}" alt="Success" class="w-100 h-100" />
                                                                </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="d-flex align-items-center justify-content-center avatar-group mt-2">
                                                                @php
                                                                    $staffToShow = array_slice($mile->assigned_staff, 0, 3); // show only first 3
                                                                    $extraCount = $mile->staff_count - count($staffToShow);
                                                                @endphp
                                                                @if (!empty($mile->assigned_staff) && count($mile->assigned_staff) > 0)

                                                            
                                                                    @foreach ($staffToShow as $st)
                                                                        <div class="avatar pull-up rounded-circle"
                                                                            data-bs-toggle="tooltip"
                                                                            title="{{ $st->staff_name }}">
                                                                            <img src="{{ asset('staff_images/' . $st->staff_image) }}"
                                                                                class="rounded-circle"
                                                                                alt="{{ $st->staff_name }}">
                                                                        </div>
                                                                    @endforeach

                                                                    {{-- IF MORE STAFF — SHOW +X --}}
                                                                    @if ($extraCount > 0)
                                                                        <div class="avatar pull-up rounded-circle" data-bs-toggle="dropdown">
                                                                            <span class="avatar-initial rounded-circle">+{{ $extraCount }}</span>
                                                                        </div>

                                                                        {{-- DROPDOWN LIST --}}
                                                                        <div class="dropdown-menu dropdown-menu-start w-250px">
                                                                            <div class="scroll-y max-h-200px px-3 py-1">

                                                                                @foreach ($mile->assigned_staff as $st)
                                                                                    <div class="d-flex align-items-center mb-2">
                                                                                        <div class="symbol me-2">
                                                                                            <img src="{{ asset('staff_images/' . $st->staff_image) }}"
                                                                                                class="w-px-40 h-px-40 rounded-circle border"
                                                                                                alt="">
                                                                                        </div>
                                                                                        <div>
                                                                                            <label class="fs-7 text-black fw-semibold">{{ $st->staff_name }}</label>
                                                                                            <div class="text-dark fs-8 mt-n1">Staff</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <hr class="my-1">
                                                                                @endforeach

                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                @else
                                                                    <div class="d-flex flex-column gap-1">
                                                                        <div class="d-flex gap-2 align-items-center">
                                                                            <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                                                <i class="mdi mdi-account-off fs-5"></i>
                                                                            </div>
                                                                            <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                                        </div>
                                                                    </div>  
                                                                @endif

                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #2193b0, #6dd5ed); border-radius:9px;">
                                                                    Delivery Documentation
                                                                </span>
                                                            </div>


                                                            {{-- <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #f7971e, #ffd200); border-radius:9px;">
                                                                    Send Document
                                                                </span>
                                                            </div>
                                                            <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #11998e, #38ef7d); border-radius:9px;">
                                                                    Document Sended
                                                                </span>
                                                            </div> --}}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                @else
                                                <tr>
                                                    <td colspan="6" class="text-center text-danger fw-bold fs-7">Milestone Not Unlocked</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                        </table>
                                    </td>
                                    </tr>
                                @endforeach
                                @endif
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


  <style>
    .upload-box { background: #fafafa; }
    .dz-preview .dz-image img { width: 70px; height: 70px; object-fit: cover; }
  </style>

<!--begin::Modal - Project View -->
<div class="modal fade" id="kt_modal_move_to_delivery" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <div class="modal-dialog modal-lg">
    <div class="modal-content rounded">
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>

      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6 text-center">
          <h4 class="text-black">
            <label class="text-black">Delivery Documentation <span id="del_mile" class="text-success fs-4 fw-bold"></span> </label>
          </h4>
        </div>

        <!-- Hidden inputs for mile/customer -->
        <input type="hidden" name="mile_sno" value="">
        <input type="hidden" name="customer_id" value="">

        <div class="row mb-3">
          <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Customer</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="customer_name">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Customer ID</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-info fs-6 fw-semibold" id="customer_id">
                    --
                </div>
                </div>
            </div>
          <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Service</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                    <div class="col-8 text-black fs-6 fw-semibold" id="service_name">
                        --
                    </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Service ID</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="service_id">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Variant</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="variant_name">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Variable</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="variable_name">
                    --
                </div>
                </div>
            </div>
        </div>

        <input type="hidden" name="submit_delivery_service" id="submit_delivery_service" />
        <input type="hidden" name="submit_delivery_mile" id="submit_delivery_mile" />
        <div id="delivery_attachment_checklist"></div>
        {{-- <div class="col-lg-12 my-3">
          <div class="d-flex justify-content-between align-items-center my-3">
            <label class="fs-4 text-black fw-semibold mb-0">Delivery Attachment</label>
          </div>

          <div class="col-lg-12 scroll-y mt-3" style="max-height: 400px; overflow-y: auto;">
            <div class="row" id="checklist_container">
            </div>
          </div> --}}
        </div>

        {{-- <div class="modal-footer border-0 pt-5">
          <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="finalSubmitBtn">Submit Delivery Documents</button>
        </div> --}}
      </div>
    </div>
  </div>
</div>
<!--end modal -->

<meta name="csrf-token" content="{{ csrf_token() }}">


{{-- Init scripts --}}
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // const dropzones = new Map();
        // const uploadedFiles = new Map();

        // if (typeof Dropzone !== 'undefined') Dropzone.autoDiscover = false;

        // // Checklist toggle show/hide
        // document.querySelectorAll('.checklist-toggle').forEach(cb => {
        //     cb.addEventListener('change', function() {
        //     const targetId = this.dataset.target;
        //     const box = document.getElementById(targetId);
        //     if (!box) return;

        //     if (this.checked) {
        //         box.classList.remove('d-none');

        //         const mile_sno = document.querySelector('input[name="mile_sno"]').value || '';
        //         const customer_id = document.querySelector('input[name="customer_id"]').value || '';
        //         box.querySelectorAll('input[name="mile_sno"]').forEach(i => i.value = mile_sno);
        //         box.querySelectorAll('input[name="customer_id"]').forEach(i => i.value = customer_id);

        //         loadExistingFiles(this.value);
        //     } else {
        //         box.classList.add('d-none');
        //         uploadedFiles.delete(this.value);
        //         const dz = dropzones.get(this.value);
        //         if (dz) dz.removeAllFiles(true);
        //     }
        //     });
        // });

        // // Initialize Dropzones
        // document.querySelectorAll('.dynamic-dropzone').forEach(formEl => {
        //     const deliId = formEl.dataset.deliId;

        //     if (formEl.dropzone) try { formEl.dropzone.destroy(); } catch(e){}

        //     const dz = new Dropzone(formEl, {
        //     url: formEl.getAttribute('action'),
        //     paramName: 'file',
        //     uploadMultiple: false,
        //     maxFiles: 20,
        //     maxFilesize: 5,
        //     acceptedFiles: ".xls,.xlsx,.pdf,.doc,.docx,.png,.jpg,.jpeg",
        //     addRemoveLinks: true,
        //     autoProcessQueue: true,
        //     headers: {
        //         'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        //         'Accept': 'application/json'
        //     },
        //     init: function() {
        //         const myDz = this;
        //         dropzones.set(deliId, myDz);

        //         myDz.on('sending', function(file, xhr, formData){
        //         const mileInput = formEl.querySelector('input[name="mile_sno"]');
        //         const deliInput = formEl.querySelector('input[name="deli_id"]');
        //         const custInput = formEl.querySelector('input[name="customer_id"]');

        //         if (mileInput) formData.append('mile_sno', mileInput.value);
        //         if (deliInput) formData.append('deli_id', deliInput.value);
        //         if (custInput) formData.append('customer_id', custInput.value);
        //         });

        //         myDz.on('success', function(file, response) {
        //         // if (typeof response === 'string') {
        //         //     try { response = JSON.parse(response); } catch(e){
        //         //     Swal.fire({ icon:'error', title:'Upload error', text:'Invalid server response' }); return;
        //         //     }
        //         // }
        //         // if (!response.success) {
        //         //     Swal.fire({ icon:'error', title:'Upload failed', text: response.message || 'Server error' });
        //         //     myDz.removeFile(file);
        //         //     return;
        //         // }

        //         const deli = formEl.querySelector('input[name="deli_id"]').value;
        //         if (!uploadedFiles.has(deli)) uploadedFiles.set(deli, []);

        //         const arr = uploadedFiles.get(deli);
        //         (response.files || []).forEach(f => {
        //             if (!arr.some(x => x.unique_name === f.unique_name)) {
        //             arr.push(f);
        //             }
        //             file._unique_name = f.unique_name;
        //             file._path = f.path;
        //         });

        //         updateFileList(deli);
        //         });

        //         myDz.on('removedfile', function(file) {
        //         const deli = formEl.querySelector('input[name="deli_id"]').value;
        //         const unique = file._unique_name || file.name;

        //         if (unique && uploadedFiles.has(deli)) {
        //             const arr = uploadedFiles.get(deli);
        //             const idx = arr.findIndex(x => x.unique_name === unique);
        //             if (idx !== -1) {
        //             const removed = arr.splice(idx,1)[0];
        //             updateFileList(deli);

        //             fetch("{{ route('delivery.remove') }}", {
        //                 method: 'POST',
        //                 headers: {
        //                 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        //                 'Accept': 'application/json'
        //                 },
        //                 body: JSON.stringify({ file_path: removed.path, mile_sno: document.querySelector('input[name="mile_sno"]').value, deli_id: deli })
        //             }).then(r => r.json()).then(j => console.log('remove resp',j)).catch(e=>console.error(e));
        //             }
        //         }
        //         });

        //         myDz.on('error', function(file, err){
        //         Swal.fire({ icon:'error', title:'Upload error', text: (err.message || err) });
        //         });

        //     } // init
        //     });

        //     formEl.dropzone = dz;
        // });

        // // Load existing files
        // function loadExistingFiles(deliId) {
        //     const mileSno = document.querySelector('input[name="mile_sno"]').value;
        //     if (!mileSno || !deliId) return;

        //     fetch("{{ route('delivery.existing.files') }}", {
        //     method: 'POST',
        //     headers: {
        //         'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        //         'Accept': 'application/json'
        //     },
        //     body: JSON.stringify({ mile_sno: mileSno, deli_id: deliId })
        //     }).then(r => r.json()).then(data => {
        //     const dz = dropzones.get(String(deliId));
        //     if (!dz) return;

        //     dz.removeAllFiles(true);
        //     uploadedFiles.set(deliId, data.files || []);
        //     updateFileList(deliId);

        //     // Add mock files for existing
        //     (data.files || []).forEach(f => {
        //         const mock = { name: f.name, size: f.size, accepted: true, status: Dropzone.ADDED, _unique_name: f.unique_name, _path: f.path };
        //         dz.emit("addedfile", mock);
        //         if (f.type && f.type.startsWith('image')) dz.emit("thumbnail", mock, f.url);
        //         dz.emit("complete", mock);
        //     });
        //     });
        // }

        // function updateFileList(deliId) {
        //     const fileListDiv = document.getElementById(`file-list-${deliId}`);
        //     const arr = uploadedFiles.get(String(deliId)) || [];
        //     if (!fileListDiv) return;

        //     if (arr.length === 0) {
        //     fileListDiv.innerHTML = '<div class="text-muted small">No files uploaded yet</div>';
        //     return;
        //     }

        //     fileListDiv.innerHTML = `
        //     <div class="text-success small mb-1"><i class="fas fa-check-circle me-1"></i>${arr.length} file(s) uploaded</div>
        //     <div class="file-list-details small text-muted" style="max-height: 100px; overflow-y:auto;">
        //         ${arr.map(f => `<div class="mb-1"><i class="fas fa-paperclip me-1"></i> ${f.original_name}</div>`).join('')}
        //     </div>
        //     `;
        // }

        // Final submit
        // document.getElementById('finalSubmitBtn').addEventListener('click', function(){
        //     const mileSno = document.querySelector('input[name="mile_sno"]').value;
        //     const customerId = document.querySelector('input[name="customer_id"]').value;
        //     const checked = Array.from(document.querySelectorAll('.checklist-toggle:checked'));
        //     if (checked.length === 0) {
        //     Swal.fire({ icon:'warning', title:'No Checklist Selected', text:'Please select at least one checklist' });
        //     return;
        //     }

        //     const checklistItems = checked.map(cb => {
        //     const id = cb.value;
        //     const name = cb.dataset.name;
        //     const files = uploadedFiles.get(String(id)) || [];
        //     return { id, name, files };
        //     });

        //     const missing = checklistItems.filter(i => i.files.length === 0);
        //     if (missing.length > 0) {
        //     const listHtml = missing.map(m => `<div>${m.name}</div>`).join('');
        //     Swal.fire({ icon:'error', title:'Missing files', html:`Please upload files for: <br/>${listHtml}` });
        //     return;
        //     }

        //     const checklistIds = checklistItems.map(i => i.id);

        //     Swal.fire({
        //     title: 'Confirm Submission',
        //     html: `<p>You're about to submit ${checklistItems.reduce((s,i)=>s+i.files.length,0)} file(s) for ${checklistItems.length} checklist item(s).</p>`,
        //     icon: 'question',
        //     showCancelButton: true
        //     }).then(res => {
        //     if (!res.isConfirmed) return;
        //     Swal.fire({ title:'Submitting...', allowOutsideClick:false, didOpen: ()=>Swal.showLoading() });

        //     fetch("{{ route('delivery.final.submit') }}", {
        //         method: 'POST',
        //         headers: {
        //         'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
        //         'Accept': 'application/json'
        //         },
        //         body: JSON.stringify({
        //         mile_sno: mileSno,
        //         customer_id: customerId,
        //         checklist_items: checklistIds
        //         })
        //     }).then(r => r.json()).then(json => {
        //         Swal.close();
        //         if (json.success) {
        //         Swal.fire({ icon:'success', title:'Saved', html:`${json.message || 'Files moved to live folder'}` }).then(() => {
        //             document.querySelectorAll('.checklist-toggle:checked').forEach(cb => {
        //             cb.checked = false;
        //             const target = document.getElementById(cb.dataset.target);
        //             if (target) target.classList.add('d-none');
        //             });
        //             dropzones.forEach(dz => dz.removeAllFiles(true));
        //             uploadedFiles.clear();
        //             const modalEl = document.getElementById('kt_modal_move_to_delivery');
        //             const modalObj = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
        //             modalObj.hide();
        //             setTimeout(()=>location.reload(), 800);
        //         });
        //         } else {
        //         Swal.fire({ icon:'error', title:'Error', text: json.message || 'Something failed' });
        //         }
        //     }).catch(err=>{
        //         Swal.fire({ icon:'error', title:'Error', text:'Network error' });
        //     });
        //     });
        // });

        // Open modal with AJAX data
        window.readyToDeliver = function(sno, mile_sno) {
            document.querySelector('input[name="mile_sno"]').value = mile_sno;

            fetch(`/delivery_documentation_data_fetch/${sno}/${mile_sno}`)
            .then(r => r.json())
            .then(resp => {
                if (!resp || resp.status !== 200) {
                Swal.fire({ icon:'error', title:'Fetch failed', text: resp?.message || 'Server error' });
                return;
                }
                const d = resp.data;
                const m = resp.milestone_data;



                // Fill HTML Fields
                $('#customer_name').text(d.cus_name);
                $('#customer_id').text(d.customer_id);
                $('#service_name').text(d.product_name);
                $('#service_id').text(d.formatted_service_id);
                $('#variant_name').text(d.variant_name);
                $('#variable_name').text(d.variable_name);                           
                document.getElementById('del_mile').textContent = m ? (' - ' + (m.payment_slot_name || '')) : '';

                document.querySelector('input[name="customer_id"]').value = d.customer_id || '';

                document.querySelectorAll('.dynamic-dropzone input[name="mile_sno"]').forEach(i=>i.value = mile_sno);
                document.querySelectorAll('.dynamic-dropzone input[name="customer_id"]').forEach(i=>i.value = d.customer_id || '');

                // document.querySelectorAll('.checklist-toggle').forEach(cb=>{
                // cb.checked = false;
                // const target = document.getElementById(cb.dataset.target);
                // if (target) target.classList.add('d-none');
                // uploadedFiles.delete(cb.value);
                // const dz = dropzones.get(cb.value);
                // if (dz) dz.removeAllFiles(true);
                // const listDiv = document.getElementById('file-list-'+cb.value);
                // if (listDiv) listDiv.innerHTML = '<div class="text-muted small">No files uploaded yet</div>';
                // });

                const modalEl = document.getElementById('kt_modal_move_to_delivery');
                const modalObj = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modalObj.show();

                fetchDeliveryAttachmentChecklist();

                
                $('#submit_delivery_mile').val(mile_sno);                
                $('#submit_delivery_service').val(sno);     
            });
        };
        });

</script>



<!-- DROPZONE ADD CSS -->
<style>
    .drop-area {
        border: 2px dashed #d1d9e8;
        border-radius: 16px;
        padding: 40px 30px;
        text-align: center;
        position: relative;
        background: linear-gradient(135deg, #f8faff 0%, #f0f4ff 100%);
        cursor: pointer;
        font-family: 'Inter', 'Segoe UI', sans-serif;
        color: #2d3748;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        overflow: hidden;
    }

    .drop-area::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(74, 144, 226, 0.1), transparent);
        transition: left 0.6s ease;
    }

    .drop-area:hover::before {
        left: 100%;
    }

    .drop-area:hover,
    .drop-area.dragover {
        border-color: #4a90e2;
        background: linear-gradient(135deg, #f0f7ff 0%, #e8f2ff 100%);
        box-shadow: 0 8px 32px rgba(74, 144, 226, 0.15);
        transform: translateY(-2px);
    }

    .drop-area.dragover {
        border-color: #357abd;
        background: linear-gradient(135deg, #e8f2ff 0%, #dbeafe 100%);
        box-shadow: 0 12px 40px rgba(74, 144, 226, 0.25);
    }

    /* Drop Area Content */
    .drop-area-content {
        pointer-events: none;
        user-select: none;
    }

    .drop-message h5 {
        font-weight: 600;
        color: #2d3748;
        margin-bottom: 8px;
    }

    .drop-message p {
        font-size: 14px;
        color: #718096;
    }

    /* Browse Button */
    .drop-area .btn {
        pointer-events: all;
        background: linear-gradient(135deg, #4a90e2, #357abd);
        border: none;
        border-radius: 8px;
        padding: 10px 24px;
        font-weight: 600;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(74, 144, 226, 0.3);
        transition: all 0.3s ease;
    }

    .drop-area .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(74, 144, 226, 0.4);
        background: linear-gradient(135deg, #357abd, #2563eb);
    }

    /* Preview List */
    .preview-list {
        margin-top: 30px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 16px;
        justify-content: start;
    }

    .preview-item {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 16px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.3s ease;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        position: relative;
        overflow: hidden;
    }

    .preview-item:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        border-color: #4a90e2;
    }

    .preview-item::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
        background: linear-gradient(135deg, #4a90e2, #357abd);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .preview-item:hover::before {
        opacity: 1;
    }

    /* File Thumbnail */
    .preview-thumb {
        width: 60px;
        height: 60px;
        border-radius: 8px;
        object-fit: cover;
        background: linear-gradient(135deg, #f8fafc, #e2e8f0);
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-size: 24px;
        color: #64748b;
    }

    .preview-thumb img {
        width: 100%;
        height: 100%;
        border-radius: 8px;
        object-fit: cover;
    }

    /* File Info */
    .preview-info {
        flex: 1;
        min-width: 0;
    }

    .preview-filename {
        font-weight: 600;
        font-size: 14px;
        color: #2d3748;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-bottom: 4px;
    }

    .preview-size {
        font-size: 12px;
        color: #718096;
        font-weight: 500;
    }

    /* Remove Button */
    .remove-btn {
        background: #ef4444;
        border: none;
        border-radius: 6px;
        color: white;
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        flex-shrink: 0;
        font-size: 16px;
        box-shadow: 0 2px 6px rgba(239, 68, 68, 0.3);
    }

    .remove-btn:hover {
        background: #dc2626;
        transform: scale(1.1);
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);
    }

    /* Progress Bar */
    .progress-container {
        width: 100%;
        margin-top: 8px;
    }

    .progress-bar {
        width: 100%;
        height: 100%;
        background: #e2e8f0;
        border-radius: 3px;
        overflow: hidden;
    }

    .progress-bar-inner {
        height: 100%;
        background: linear-gradient(90deg, #10b981, #059669);
        border-radius: 3px;
        transition: width 0.4s ease;
        position: relative;
    }

    .progress-bar-inner::after {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.6), transparent);
        animation: shimmer 1.5s infinite;
    }

    @keyframes shimmer {
        0% { left: -100%; }
        100% { left: 100%; }
    }

    /* File Type Icons */
    .file-type-icon {
        font-size: 24px;
        text-align: center;
    }

    .file-pdf { color: #ef4444; }
    .file-doc { color: #2563eb; }
    .file-xls { color: #059669; }
    .file-zip { color: #f59e0b; }
    .file-img { color: #8b5cf6; }
    .file-default { color: #64748b; }

    /* Empty State */
    .preview-list:empty {
        display: none;
    }
    
    .upload-section input[type="radio"] {
    display: inline-block;
    position: absolute;
    overflow: hidden;
    clip: rect(0 0 0 0);
    height: 1;
    width: 1;
    margin: -1;
    padding: 0;
    border: 0;
    }

    :root {
    --primary-color: 76, 78, 81;
    --icon-size: 2rem;
    }

    .upload-section .icon {
    display: flex;
    justify-content: center;
    align-items: center;
    width: var(--icon-size);
    height: var(--icon-size);
    color: rgb(var(--primary-color));
    border-radius: 0.5rem;
    padding: 0.5rem;
    overflow: hidden;
    }

    .upload-section .icon:hover {
    cursor: pointer;
    background-color: rgba(var(--primary-color), 0.1);
    }

    .upload-section .peer:checked ~ .icon {
    background-color: rgba(var(--primary-color), 0.2);
    }

    .upload-section .wrapper {
    display: flex;
    flex-shrink: 0;
    gap: 0.5rem;
    }

    .upload-section .page {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    /* min-height: 100px; */
    }

    .bg-label-blue {
        background-color: #d4eefe !important;
        color: #cbe9fc !important;
    }

    .bg-blue {
        --bs-bg-opacity: 1;
        background-color: #4ba7df !important;
    }

    button.accordion-button.disabled_btn:after {
        background: none;
    }

    .upload-loader {
        position: absolute;
        inset: 0;
        background: rgba(255,255,255,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 50;
        pointer-events: all;
    }
</style>

<!-- FETCH DELIVERY ATTACHMENT CHECKLIST -->
<script>
    function fetchDeliveryAttachmentChecklist() {
        $.ajax({
            url: `/delivery_attachment_list`,
            type: 'GET',
            success: function (response) {
                if (response.status === 200) {

                    let append_html = '';
                    append_html += `<div class="row my-3">
                                                <div>
                                                    <div class="divider text-start">
                                                        <div class="divider-text rounded px-2 pe-2 bg-primary"><span  class="text-start fw-semibold text-white fs-4">Upload Document</span></div>
                                                    </div>
                                                </div>
                                            <div id="form_div">
                                                <form id="add_pro_verify_form" method="POST" enctype="multipart/form-data">`;
        
                                                    // let checklist_no = 1;
                                                    response.data.forEach((check_list) => {
        
                                                        var checklist_sno = check_list.sno ?? 0;
                                                        var checklist_name = check_list.delivery_attachment_checklist ?? '-';
        
                                                        append_html += `<div class="col-lg-12 mb-3 checklist-item">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input checklist-toggle w-20px h-20px is_valid_enable" 
                                                                    type="checkbox" id="check${checklist_sno}" value="${checklist_sno}"
                                                                    onchange="append_attach_details('form_div','${checklist_sno}')"/>
        
                                                                <label for="check${checklist_sno}" 
                                                                    class="text-black mb-1 fs-6 fw-semibold">
                                                                    ${checklist_name} <span id="checklist_error_${checklist_sno}" class="text-danger mt-2 fs-7 fw-semibold"></span>
                                                                </label>
                                                            </div>
        
                                                            <div id="pro_ver_project_checklist_section_${checklist_sno}"></div>
                                                        </div>`;
                                                    });
        
                                                append_html += `<div class="d-flex justify-content-end align-items-end mt-4">
                                                        <button type="button" onclick="submit_func('form_div')"  id="updateSubmitBtn" class="btn btn-primary">Upload Delivery Checklist</a>
                                                    </div>`;
                                append_html += `</form>
                            </div>`;
                        append_html += `</div>`;

                    $('#delivery_attachment_checklist').html(append_html);
                }
            }
        })
    }

    function append_attach_details(div_id, checklist_sno) {
        const section = $(`#${div_id} #pro_ver_project_checklist_section_${checklist_sno}`);
        let checkbox = $(`#${div_id} input.checklist-toggle[onchange="append_attach_details('${div_id}','${checklist_sno}')"]`);

        // Checkbox unchecked → hide everything
        if (!checkbox.is(":checked")) {
            section.empty();
            return;
        }

        // Inject UI
        section.html(`
            <div class="upload-section p-2 rounded mt-2 border border-1 border-secondary-subtle">
                <!-- DROPZONE UPLOAD -->
                <div id="upload_dropzone_${checklist_sno}" class="upload-box">

                    <div id="upload_loader_${checklist_sno}" 
                        class="upload-loader d-none">
                        <div class="spinner-border text-primary" role="status"></div>
                        <span class="ms-2 fw-semibold">Uploading...</span>
                    </div>
                    
                    <input type="hidden" name="project_files[${checklist_sno}]" 
                        id="project_files_${checklist_sno}" />

                    <label class="text-black mb-3 fs-6 fw-semibold d-block">
                        Attachment <span class="text-danger">*</span>
                    </label>

                    <div id="dropArea_${checklist_sno}" class="drop-area">

                        <div class="drop-area-content">
                            <div id="dropMessage_${checklist_sno}" class="drop-message">
                                <h5 class="mb-2">Drop files here or click to upload</h5>
                                <p class="text-muted mb-0">Supports images, documents, and other files</p>
                            </div>

                            <button type="button" class="btn btn-primary btn-browse btn-sm mt-3">
                                <i class="mdi mdi-folder-open-outline me-2"></i>Browse Files
                            </button>
                        </div>

                        <div class="preview-list" id="previewList_${checklist_sno}"></div>
                        <input type="file" id="fileInput_${checklist_sno}" multiple style="display:none;" />

                    </div>

                    <div id="dropzone_error_${checklist_sno}" class="text-danger mt-2 fs-7 fw-semibold"></div>

                </div>
            </div>
        `);

        // Initialize Dropzone with div_id
        get_drop_zone_func(div_id, checklist_sno);

        // Radio Toggle Logic (Pure JS)
        // document.querySelectorAll(`#${div_id} input[name="attach_type[${checklist_sno}]"]`).forEach(radio => {
        //     radio.addEventListener("change", function () {

        //         const val = this.value;   // "dropzone" or "drive"

        //         const dropzoneBox = document.querySelector(`#${div_id} #upload_dropzone_${checklist_sno}`);
        //         const driveBox    = document.querySelector(`#${div_id} #upload_drive_${checklist_sno}`);
        //         const selectedBox = document.querySelector(`#${div_id} #upload_${val}_${checklist_sno}`);

        //         // Hide all
        //         dropzoneBox.classList.add("d-none");
        //         driveBox.classList.add("d-none");

        //         // Show selected
        //         selectedBox.classList.remove("d-none");

        //         // Re-initialize dropzone only once
        //         if (val === "dropzone") {

        //             const dzElement = document.querySelector(`#dropzone_${checklist_sno}`);

        //             if (!dzElement.dataset.dzInit) {
        //                 get_drop_zone_func(div_id, checklist_sno);
        //                 dzElement.dataset.dzInit = "true"; // mark initialized
        //             }
        //         }
        //     });
        // });
    }

    function get_drop_zone_func(div_id, sno) {

        var container = $(`#${div_id}`);

        var dropArea            = container.find(`#dropArea_${sno}`)[0];
        var fileInput           = container.find(`#fileInput_${sno}`)[0];
        var previewList         = container.find(`#previewList_${sno}`)[0];
        var dropMessage         = container.find(`#dropMessage_${sno}`)[0];
        var uploadedFilesInput  = container.find(`#project_files_${sno}`)[0];
        var browseBtn           = container.find(`#upload_dropzone_${sno} .btn-browse`)[0];
        const loader = container.find(`#upload_loader_${sno}`);

        let uploadedFiles = [];
        let activeUploads = 0;

        function showLoader() {
            loader.removeClass('d-none');
        }

        function hideLoader() {
            loader.addClass('d-none');
        }

        dropArea.addEventListener('click', (e) => {
            if (e.target.closest('.btn') || !e.target.closest('.preview-item')) {
                fileInput.click();
            }
        });

        browseBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            fileInput.click();
        });

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, e => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => dropArea.classList.add('dragover'));
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, () => dropArea.classList.remove('dragover'));
        });

        dropArea.addEventListener('drop', e => handleFiles(e.dataTransfer.files));
        fileInput.addEventListener('change', e => {
            handleFiles(e.target.files);
            fileInput.value = "";
        });

        function handleFiles(files) {
            Array.from(files).forEach(file => {
                if (!uploadedFiles.includes(file.name)) {
                    uploadFile(file, sno);
                } else {
                    showToast(`File "${file.name}" already added.`, 'warning');
                }
            });
        }

        function uploadFile(file, check_id) {

            activeUploads++;
            showLoader();

            const formData = new FormData();
            formData.append('file', file);
            formData.append('check_id', check_id);
            formData.append('_token', '{{ csrf_token() }}');

            const previewItem = createPreviewItem(file, check_id);
            previewList.appendChild(previewItem);
            dropMessage.style.display = "none";

            fetch('/manage_production/fetch_drop_zone', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {

                if (data.status === 'success') {

                    uploadedFiles.push(data.filename);
                    updateUploadedFilesInput();

                    previewItem.dataset.serverFilename = data.filename;
                    previewItem.classList.add('upload-success');

                    const progressBar = previewItem.querySelector('.progress-bar-inner');
                    progressBar.style.width = '100%';
                    progressBar.style.background = 'linear-gradient(90deg, #10b981, #059669)';

                } else {
                    throw new Error(data.message || 'Upload failed');
                }
            })
            .catch(err => {
                previewItem.classList.add('upload-error');
                previewItem.querySelector('.progress-bar-inner').style.background =
                    'linear-gradient(90deg, #ef4444, #dc2626)';
                showToast('Error uploading file', 'error');
            }).finally(() => {
                activeUploads--;
                if(activeUploads === 0) {
                    hideLoader();
                }
            });
        }

        function createPreviewItem(file, check_id) {

            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";
            previewItem.innerHTML = `
                <div class="preview-thumb">${getFileThumbnail(file)}</div>
                <div class="preview-info">
                    <div class="preview-filename">${file.name}</div>
                    <div class="preview-size">${formatFileSize(file.size)}</div>
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div class="progress-bar-inner" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
                <button type="button" class="remove-btn" title="Remove file">
                    <i class="mdi mdi-close"></i>
                </button>
            `;

            simulateUploadProgress(previewItem);

            previewItem.querySelector('.remove-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                removeFile(previewItem, file.name, check_id);
            });
            
            $(document).on("click", `#pro_ver_project_checklist_section_${check_id} #drive_${check_id}`, function (e) {
                e.stopPropagation();

                let fileVal = $(`#pro_ver_project_checklist_section_${check_id} #project_files_${check_id}`)
                    .val()
                    ?.trim() || "";

                if (fileVal !== '' && fileVal !== '[]') {
                    removeFile(previewItem, file.name, check_id);
                }
            });

            return previewItem;
        }

        function removeFile(previewItem, fileName, check_id) {
            const serverFileName = previewItem.dataset.serverFilename || fileName;

            previewItem.remove();
            uploadedFiles = uploadedFiles.filter(f => f !== serverFileName);
            updateUploadedFilesInput();

            if (uploadedFiles.length === 0) {
                dropMessage.style.display = "block";
            }

            fetch('/manage_production/remove-temp-file', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                body: JSON.stringify({
                    filename: serverFileName,
                    check_id: check_id,
                    file_path: '{{ auth()->id() }}/temp_project/' + check_id + '/' + serverFileName
                })
            });
        }

        function getFileThumbnail(file) {
            if (file.type.startsWith('image/')) {
                return `<img src="${URL.createObjectURL(file)}" alt="${file.name}" />`;
            }
            const extension = file.name.split('.').pop().toLowerCase();
            const iconMap = {
                pdf: 'mdi-file-pdf-box file-pdf',
                doc: 'mdi-file-word-box file-doc',
                docx: 'mdi-file-word-box file-doc',
                xls: 'mdi-file-excel-box file-xls',
                xlsx: 'mdi-file-excel-box file-xls',
                zip: 'mdi-folder-zip file-zip',
                rar: 'mdi-folder-zip file-zip',
                jpg: 'mdi-file-image file-img',
                jpeg: 'mdi-file-image file-img',
                png: 'mdi-file-image file-img',
                gif: 'mdi-file-image file-img'
            };
            return `<i class="mdi ${iconMap[extension] || 'mdi-file-document file-default'}"></i>`;
        }

        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024, sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }

        function simulateUploadProgress(previewItem) {
            const progressBar = previewItem.querySelector('.progress-bar-inner');
            let progress = 0;
            const interval = setInterval(() => {
                progress += Math.random() * 15;
                if (progress >= 100) {
                    progress = 100;
                    clearInterval(interval);
                }
                progressBar.style.width = progress + '%';
            }, 200);
        }

        function updateUploadedFilesInput() {
            uploadedFilesInput.value = JSON.stringify(uploadedFiles);
        }
    }

    function submit_func(div_id) {

        let container = $("#" + div_id);
        let error = 0;

        // Clear previous errors
        $('[id^="dropzone_error_"], [id^="checklist_error_"]').text("");

        // -------------------------------------------------------------
        // 🔥 SEQUENTIAL VALIDATION (one-by-one) USING error++
        // -------------------------------------------------------------
        let checklistItems = container.find('.is_valid_enable');

        for (let i = 0; i < checklistItems.length; i++) {

            let checkbox = $(checklistItems[i]);
            let check_id = checkbox.val();
            let checked = checkbox.is(':checked');

            // ---------- STEP 1: Checkbox must be checked ----------
            if (!checked) {
                container.find(`#checklist_error_${check_id}`).text(' *Checklist must be verified!');
                error++;
                break; // 🔥 Stop further validation
            }

            // var attach_type_check = $(`#${div_id} input[name='attach_type[${check_id}]']:checked`).val().trim();
        
            // if(attach_type_check == 'drive'){
            //     var fileVal = container.find(`#drive_url_${check_id}`).val()?.trim() || "";
        
            //     if (fileVal === '' || fileVal === null || fileVal === undefined) {
            //         container.find(`#drive_url_error_${check_id}`).text('URL is required!');
            //         error++;
            //         break; // 🔥 Stop further validation
            //     }
            // }else if(attach_type_check == 'dropzone'){
                // ---------- STEP 2: File must be uploaded ----------
                var fileVal = container.find(`#project_files_${check_id}`).val()?.trim() || "";
        
                if (fileVal === '' || fileVal === '[]' || fileVal === null || fileVal === undefined) {
                    container.find(`#dropzone_error_${check_id}`).text('Attachment is required!');
                    error++;
                    break; // 🔥 Stop further validation
                }
            // }

            // If both pass → continue to next checkbox
        }

        // -------------------------------------------------------------
        // FINALLY CHECK ERROR COUNT
        // -------------------------------------------------------------
        if (error > 0) {
            return false; // ❌ stop submit
        }

        let form = container.find('form')[0]; 
        let formData = new FormData(form);
        formData.append('_token', '{{ csrf_token() }}');
        formData.append('milestone_id', $('#submit_delivery_mile').val());
        formData.append('service_id', $('#submit_delivery_service').val());

        // -------------------------------
        // 3️⃣ AJAX submit (optional)
        // -------------------------------

        $.ajax({
            url: '/delivery/final/submit',
            method: 'POST',
            data: formData,
            processData: false,
            contentType: false,

            beforeSend: function () {
                container.find('#updateSubmitBtn').prop('disabled', true);
            },

            success: function (res) {
                if (res.status === 200) {
                    // $('#kt_modal_producation_verification_panel').modal('hide');
                    toastr.success('Delivery Attachments submitted Successfully!');
                    location.reload();
                } else {
                    toastr.error('Submission failed!');
                }
            },

            error: function (xhr) {
                console.error('Form submit error:', xhr.responseText);
                toastr.error('Failed to submit form.');
            },

            complete: function () {
                container.find('#updateSubmitBtn').prop('disabled', false);
            }
        });
    }
</script>


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .err_msg{
        /* background-color: red; */
        border-color: red;
        }

    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

{{-- * TOASTR ENDS --}}




<script>
function indv_cust_func(rowIndex) {

    // Loop through all rows
    document.querySelectorAll("[id^='indv_cust_'][id$='_tbox']").forEach(function(tbox) {
        const index = tbox.id.split("_")[2];  // get number
        const button = document.getElementById(`indv_cust_${index}_plus_btton`);
        const header = document.getElementById(`indv_cust_hd_${index}`);

        if (index == rowIndex) {
            // Toggle open/close
            const isVisible = tbox.style.display === "table-row";

            tbox.style.display = isVisible ? "none" : "table-row";
            button.classList.toggle("mdi-minus", !isVisible);
            button.classList.toggle("mdi-plus", isVisible);

            // Optional highlight
            // header.style.backgroundColor = isVisible ? "" : "#f9f3c5db";
        }
        else {
            // Hide all other rows
            tbox.style.display = "none";
            button.classList.remove("mdi-minus");
            button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    });
}
</script>


<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
document.querySelectorAll('.circular-progress').forEach(el => {
  const progress = parseInt(el.getAttribute('data-progress')) || 0;
  const color = progress === 100 ? '#75D195' : '#EB5B65';
  el.style.setProperty('--progress', progress);
  el.style.setProperty('--fill-color', color);

  if (progress === 100) {
    el.style.setProperty('--fill-color', '#75D195');

    const front = el.querySelector('.progress-front');
    const back = el.querySelector('.progress-back');

    let showProgress = true;

    setInterval(() => {
      el.classList.toggle('flip');
      showProgress = !showProgress;

      if (showProgress) {
        // Show progress circle side
        el.style.background = `conic-gradient(${color} calc(var(--progress) * 1%), var(--track-color) 0)`;
        el.querySelector('.circular-progress::before');
      } else {
        // Hide progress circle when tick.gif is visible
        el.style.background = 'transparent';
      }
    }, 2000);
  }
});
</script>

@endsection
