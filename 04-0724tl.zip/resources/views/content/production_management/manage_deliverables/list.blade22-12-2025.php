@extends('layouts/layoutMaster')

@section('title', 'Manage Deliverables ')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .customer_table thead th,
    .customer_table tbody td {
        padding: 8px !important;
    }

    .indv_cust_serv thead th,
    .indv_cust_serv tbody td {
        padding: 8px !important;
        /* border: 1px solid rgb(180, 180, 180) !important; */
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>


<style>
.circular-progress {
  --size: 60px;
  --progress: 0;
  --track-color: #d2e1f0;
  --fill-color: #EB5B65;

  width: var(--size);
  height: var(--size);
  border-radius: 50%;
  background: conic-gradient(
    var(--fill-color) calc(var(--progress) * 1%),
    var(--track-color) 0
  );
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  font-family: Arial, sans-serif;
  font-weight: bold;
  color: #000;
  transition: transform 0.8s ease-in-out;
  transform-style: preserve-3d;
  perspective: 800px;
}

.circular-progress::before {
  content: '';
  position: absolute;
  width: calc(var(--size) - 15px);
  height: calc(var(--size) - 15px);
  background-color: #ffffff;
  border-radius: 50%;
  z-index: 0;
}

/* Front (progress side) */
.progress-front {
  position: absolute;
  backface-visibility: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  inset: 0;
}

/* Back (success GIF side) */
.progress-back {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: rotateY(180deg);
  backface-visibility: hidden;
}

/* Flipped state */
.flip {
  transform: rotateY(180deg);
}

/* Grid layout */
.progress-grid {
  display: grid;
  grid-template-columns: repeat(3, auto);
  gap: 20px;
  justify-content: center;
  align-items: center;
  padding: 20px;
}
</style>

<style>
  .progress {
  position: relative;
  overflow: hidden;
}

.progress-bar {
  position: relative;
  animation: none !important;
}

/* Highlight animation overlay */
.progress-bar::after {
  content: "";
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    120deg,
    transparent 0%,
    rgba(255,255,255,0.6) 50%,
    transparent 100%
  );
  animation: progress-shine 2.2s infinite linear;
  border-radius: inherit;
}

@keyframes progress-shine {
  0% { left: -100%; }
  100% { left: 100%; }
}

</style>

@php
    $helper = new \App\Helpers\Helpers();
    $module_name = 'Service Management';
    $menu_name   = 'Manage Deliverables';
@endphp

<!-- Customer List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Manage Deliverables</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <form class="search_form" method="POST" action="/manage_work_order">
                <div class="row py-1">                 
                    @csrf
                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                    <input type="hidden" name="filter_on" value="1">
                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"  value="@php echo $perpage ? $perpage : 10; @endphp" />
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                        <select class="select3 form-select" name="cat_fill">
                            <option value="" selected>All</option>
                            @if (isset($Product_cat_list))
                                @foreach ($Product_cat_list as $pc_list)
                                    <option value="{{ $pc_list->sno }}" @if($pc_list->sno == $cat_fill) selected @endif>{{ $pc_list->product_category_name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                        <select class="select3 form-select" name="product_fill">
                            <option value="" selected>All</option>
                            @if (isset($Product_list))
                                @foreach ($Product_list as $prd_list)
                                    <option value="{{ $prd_list->sno }}" @if($prd_list->sno == $product_fill) selected @endif>{{ $prd_list->product_name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                       <select class="select3 form-select" name="status_fill">
                            <option value="" @if($status_fill === null || $status_fill === '') selected @endif>All</option>
                            <option value="0" @if($status_fill == 0) selected @endif>Service Not Yet Started</option>
                            <option value="1" @if($status_fill == 1) selected @endif>Service In Progress</option>
                            <option value="2" @if($status_fill == 2) selected @endif>Service Completed</option>
                            <option value="3" @if($status_fill == 3) selected @endif>Service Delayed</option>
                            <option value="4" @if($status_fill == 4) selected @endif>Service Hold</option>
                            <option value="5" @if($status_fill == 5) selected @endif>Service Not Completed</option>
                            <option value="6" @if($status_fill == 6) selected @endif>Service Verified</option>
                            <option value="7" @if($status_fill == 7) selected @endif>Service QC Verified</option>
                            <option value="8" @if($status_fill == 8) selected @endif>Service Delivered</option>
                        </select>

                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                     <a href="{{ url('/manage_service') }}" type="button" class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset</a>
                    <button type="submit" class="btn btn-primary btn-sm waves-effect waves-light">Go</button>
                </div>
            </form>
        </div>
        <div class="row">
            <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="select3 form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count == $option) ? 'selected' : ''; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form class="search_form" method="POST" action="/manage_work_order">
                        @csrf
                    <div class="d-flex align-items-center gap-2 mt-2">
                        <div>
                        <input type="hidden" name="page" value="{{ request('page', 1) }}">
                        <input type="hidden" name="filter_on" value="0">
                        <input type="hidden" class="sorting_filter_class" name="sorting_filter"  value="@php echo $perpage ? $perpage : 10; @endphp" />
                        <input
                            type="text"
                            class="form-control"
                            id="search_fill" name="search_fill" value="{{ $search_fill ?? "" }}"
                            placeholder="Enter Search"
                        />
                        </div>
                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6" onclick="search_filter_func()">Search</button>
                    </div>
                    </form>
                </div>
            </div>
            <div class="table-responsive">
                <div class="row">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 ">
                        {{--  --}}
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">Services</th>
                                <th class="min-w-150px">Customers</th>
                                <th style="min-w-100px ">CRE</th>
                                <th style="min-w-100px ">PC</th>
                                <th style="min-w-100px text-center">MileStone</th>
                                <th style="min-w-100px text-center">Delivered</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7">
                            @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                @if (isset($ListTable))
                                @foreach ($ListTable as $i=> $list)
                                    <tr id="indv_cust_hd_{{$i}}">
                                      <td>
                                          @php
                                              $countryCode = $list->country_code ?? 91;
                                              $mobile = $list->cus_mobile ?? '';
                                              $phone_no = $mobile ? '( +'.$countryCode.' ) '. $mobile : '';
                                              $percentage = $helper->completed_service_percentage($list->sno);
                                              $year = date('Y', strtotime($list->created_at));
                                              $id = str_pad($list->sno, 5, '0', STR_PAD_LEFT);
                                              $service_id = "SR-{$id}/{$year}";
                                              $milestone_data = $list->milestone_data ? $list->milestone_data : [];
                                          @endphp
                                          <div class="d-flex align-items-center gap-2">
                                              <div class="me-2 cursor-pointer">
                                                  <a href="javascript:;" class="bg-label-secondary border border-gray-400i rounded px-2 py-2" onclick="indv_cust_func('{{$i}}');">
                                                      <i class="mdi mdi-plus fs-4" id="indv_cust_{{$i}}_plus_btton"></i>
                                                  </a>
                                              </div>
                                              <div class="d-flex flex-column">
                                                  <div class="d-flex align-items-center">
                                                      <label class="fs-7 text-black fw-semibold text-truncate cursor-pointer"  style="max-width: 300px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_name }}">{{ $list->product_name }}</label>
                                                      <label data-bs-toggle="dropdown">
                                                              <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 cursor-pointer"
                                                                  title="Product Variant">
                                                              </span>
                                                          </label>
                                                      <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                                          <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                                              <u>Product Variant Info</u>
                                                          </div>

                                                              @php
                                                                  $variant_variable = json_decode($list->variant_variable_ids ?? '[]', true);
                                                              @endphp
                                                              
                                                              @if (!empty($variant_variable))
                                                                  @foreach ($variant_variable as $cart_item)
                                                                      @php 
                                                                          $variant_name = $helper->get_variant_data_by_id($cart_item['variant_id'])->product_variant_name ?? 'N/A';
                                                                          $variable_name = $helper->get_variable_data_by_id($cart_item['variable_id'])->variable_name ?? 'N/A';
                                                                      @endphp
                                                                      <div class="mb-2">
                                                                          <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                                                          <div class="text-black">{{ $variant_name ?? '-' }}</div>
                                                                          <div class="text-dark fw-semibold fs-8 mt-1">Details Variable:</div>
                                                                          <div class="text-black">{{ $variable_name ?? '-' }}</div>
                                                                      </div>
                                                                      @if (!$loop->last)
                                                                          <hr class="my-2">
                                                                      @endif
                                                                  @endforeach
                                                              @else
                                                                  <div class="text-muted fs-8 text-center">No variant data found.</div>
                                                              @endif
                                                      </div>
                                                  </div>
                                                  <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service ID">{{ $service_id }}</label>
                                              </div>
                                          </div>
                                      </td>
                                      <td>
                                        <div class="d-flex flex-column ">
                                            <div class=" text-wrap" style="width: 200px">
                                                <div class="text-black fw-semibold fs-7">
                                                    <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                    <label class="mt-1" data-bs-toggle="dropdown">
                                                    <span class="cursor-pointer p-1" style=" border-radius: 6px;
                                                    background:#e3f2fd; color:#0d47a1; font-weight:600;"><span class="mdi mdi-email"></span>
                                                </label>


                                                <div class="dropdown-menu dropdown-menu-start">
                                                    <div class="row">
                                                    <div class="col-lg-12">
                                                        <div class="d-flex px-3 flex-column align-items-start justify-content-start mb-2">
                                                            <label class="fs-8 text-black text-wrap fw-semibold" style="width: 150px;">{{ $list->cus_email_id??'-' }}</label>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>




                                                </div>
                                            </div>
                                            <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">{{ $list->cus_id }}</div>
                                            <label class="text-dakr fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Mobile NO">{{$phone_no}}</label>
                                        </div>
                                      </td>
                                      <td>
                                          <div class="d-flex align-items-center">
                                          <div class="d-flex gap-2 align-items-center">
                                              @if ($list->cre_image)
                                                  <div class="w-50px h-50px">
                                                  <img
                                                  src="{{ asset('/staff_images/' . $list->cre_image) }}"
                                                  alt="avatar"
                                                  class="rounded-circle w-100 h-100"
                                                  >
                                                  </div>
                                                  <div class="d-flex flex-column justify-content-center">
                                                      <label class="badge bg-danger  px-3 py-2 fw-semibold fs-7 text-white">{{$list->cre_name}}</label>
                                                  </div>
                                              @else
                                                  <div class="d-flex flex-column gap-1">
                                                      <div class="d-flex gap-2 align-items-center">
                                                          <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                              <i class="mdi mdi-account-off fs-5"></i>
                                                          </div>
                                                          <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                      </div>
                                                  </div>
                                              @endif
                                          </div>
                                      </td>
                                      <td>
                                          <div class="d-flex align-items-center">
                                          <div class="d-flex gap-2 align-items-center">
                                              @if ($list->pc_image)
                                                  <div class="w-50px h-50px">
                                                  <img
                                                  src="{{ asset('/staff_images/' . $list->pc_image) }}"
                                                  alt="avatar"
                                                  class="rounded-circle w-100 h-100"
                                                  >
                                                  </div>
                                                  <div class="d-flex flex-column justify-content-center">
                                                      <label class="badge bg-danger  px-3 py-2 fw-semibold fs-7 text-white">{{$list->pc_name}}</label>
                                                  </div>
                                              @else
                                                  <div class="d-flex flex-column gap-1">
                                                      <div class="d-flex gap-2 align-items-center">
                                                          <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                              <i class="mdi mdi-account-off fs-5"></i>
                                                          </div>
                                                          <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                      </div>
                                                  </div>    
                                              @endif
                                          </div>
                                      </td>
                                      <td align="center">
                                        <span class="cursor-pointer px-2 py-1 fs-3"data-bs-toggle="tooltip" data-bs-placement="bottom" title="MileStone Count" style="border-radius:6px; background:#e0f7fa; color:#006064; font-weight:1000; border:1px solid #006064;"> @if (is_array($milestone_data) && count($milestone_data) > 0) {{ str_pad(count($milestone_data), 2, '0', STR_PAD_LEFT) }} @else 0 @endif</span>
                                      </td>
                                      <td align="center">
                                        <span class="cursor-pointer px-2 py-1 fs-3"data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delivered Count" style="border-radius:6px; background:#f3e5f5; color:#4a148c; font-weight:1000; border:1px solid #4a148c;">0</span>
                                      </td>
                                    </tr>
                                    <tr id="indv_cust_{{$i}}_tbox" style="display:none;">
                                    <td colspan="6">
                                        <table class="table align-top gy-1 gs-2 indv_cust_serv">
                                        <thead style="background:#BDE3F0;">
                                            <tr class="text-start align-top fs-6 gs-0">
                                              <th class="min-w-50px text-black fw-semibold text-center">S.No</th>
                                              <th class="min-w-100px text-black fw-semibold">MileStone</th>
                                              <th class="min-w-100px text-black fw-semibold text-center">Tasks</th>
                                              <th class="min-w-100px text-black fw-semibold text-center">Tasks Status</th>
                                              <th class="min-w-50px text-black fw-semibold text-center">Staffs</th>
                                              <th class="min-w-50px text-black fw-semibold text-center">Status</th>
                                            </tr>
                                        </thead>

                                        <tbody class="text-gray-600 fw-semibold fs-7">
                                            @if (is_array($milestone_data) && count($milestone_data) > 0)
                                                @foreach ($milestone_data as $mi => $mile)
                                                    <tr>
                                                        <td align="center">
                                                            <label class="mt-4">{{$mi+1}}</label>
                                                        </td>
                                                        <td>
                                                            <div class="mt-3 d-flex flex-column">
                                                                <div class="d-flex justify-content-between align-items-center mb-1">
                                                                    <span class="cursor-pointer px-2 py-1" style="border-radius:6px; background:#fff3e0; color:#e65100; font-weight:600;">{{ $mile->mile_stone_name }}</span>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="d-flex justify-content-center align-items-end">
                                                            <label class="fs-7 text-black fw-semibold text-truncate cursor-pointer" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ reset($mile->task_names) }}">{{ reset($mile->task_names) }} </label>
                                                            <label class="mt-1" data-bs-toggle="dropdown">
                                                                <span class="cursor-pointer p-1 ms-1 w-150px" style=" border-radius: 6px;
                                                                background:#e3f2fd; color:#0d47a1; font-weight:600;">More</span>
                                                            </label>
                                                            <div class="dropdown-menu dropdown-menu-start p-2">
                                                                <div class="row">
                                                                    <div class="col-lg-12">
                                                                        <div class="d-flex px-3 flex-column align-items-start justify-content-start mb-2">
                                                                            <div class="scroll-y" style="max-height: 150px;width:100%;">
                                                                                @foreach($mile->task_names as $i => $task)
                                                                                    <div class="mb-2">
                                                                                        <div class="text-dark fw-semibold fs-8">Task {{ $i + 1 }}:</div>
                                                                                        <div class="text-black fw-semibold fs-8">{{ $task }}</div>
                                                                                    </div>
                                                                                    <hr class="my-1">
                                                                                @endforeach
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                        </td>
                                                        
                                                        <td align="center">
                                                            <div class="d-flex gap-2 align-items-center  justify-content-center">
                                                            <div class="circular-progress" data-progress="{{ $mile->milestone_percentage }}">
                                                                <div class="progress-front">
                                                                <span class="progress-value">{{ $mile->milestone_percentage }}%</span>
                                                                </div>
                                                                <div class="progress-back">
                                                                <div class="w-50px h-50px">
                                                                    <img src="{{ asset('assets/phdizone_images/Correct.gif') }}" alt="Success" class="w-100 h-100" />
                                                                </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="d-flex align-items-center justify-content-center avatar-group mt-2">
                                                                @php
                                                                    $staffToShow = array_slice($mile->assigned_staff, 0, 3); // show only first 3
                                                                    $extraCount = $mile->staff_count - count($staffToShow);
                                                                @endphp
                                                                @if (!empty($mile->assigned_staff) && count($mile->assigned_staff) > 0)

                                                            
                                                                    @foreach ($staffToShow as $st)
                                                                        <div class="avatar pull-up rounded-circle"
                                                                            data-bs-toggle="tooltip"
                                                                            title="{{ $st->staff_name }}">
                                                                            <img src="{{ asset('staff_images/' . $st->staff_image) }}"
                                                                                class="rounded-circle"
                                                                                alt="{{ $st->staff_name }}">
                                                                        </div>
                                                                    @endforeach

                                                                    {{-- IF MORE STAFF — SHOW +X --}}
                                                                    @if ($extraCount > 0)
                                                                        <div class="avatar pull-up rounded-circle" data-bs-toggle="dropdown">
                                                                            <span class="avatar-initial rounded-circle">+{{ $extraCount }}</span>
                                                                        </div>

                                                                        {{-- DROPDOWN LIST --}}
                                                                        <div class="dropdown-menu dropdown-menu-start w-250px">
                                                                            <div class="scroll-y max-h-200px px-3 py-1">

                                                                                @foreach ($mile->assigned_staff as $st)
                                                                                    <div class="d-flex align-items-center mb-2">
                                                                                        <div class="symbol me-2">
                                                                                            <img src="{{ asset('staff_images/' . $st->staff_image) }}"
                                                                                                class="w-px-40 h-px-40 rounded-circle border"
                                                                                                alt="">
                                                                                        </div>
                                                                                        <div>
                                                                                            <label class="fs-7 text-black fw-semibold">{{ $st->staff_name }}</label>
                                                                                            <div class="text-dark fs-8 mt-n1">Staff</div>
                                                                                        </div>
                                                                                    </div>
                                                                                    <hr class="my-1">
                                                                                @endforeach

                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                @else
                                                                    <div class="d-flex flex-column gap-1">
                                                                        <div class="d-flex gap-2 align-items-center">
                                                                            <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                                                <i class="mdi mdi-account-off fs-5"></i>
                                                                            </div>
                                                                            <label class="fw-semibold fs-8 text-dark mb-0">Staff Not Assigned</label>
                                                                        </div>
                                                                    </div>  
                                                                @endif

                                                            </div>
                                                        </td>
                                                        <td align="center">
                                                            <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #2193b0, #6dd5ed); border-radius:9px;">
                                                                    Delivery Documentation
                                                                </span>
                                                            </div>


                                                            {{-- <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #f7971e, #ffd200); border-radius:9px;">
                                                                    Send Document
                                                                </span>
                                                            </div>
                                                            <div class="mt-4">
                                                                <span class="text-white fw-semibold fs-7 px-3 py-2 cursor-pointer"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#kt_modal_move_to_delivery"
                                                                    onclick="readyToDeliver('{{ $list->sno }}', '{{ $mile->mile_sno }}')"
                                                                    style="background: linear-gradient(to right, #11998e, #38ef7d); border-radius:9px;">
                                                                    Document Sended
                                                                </span>
                                                            </div> --}}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                @else
                                                <tr>
                                                    <td colspan="6" class="text-center text-danger fw-bold fs-7">Milestone Not Unlocked</td>
                                                </tr>
                                            @endif
                                        </tbody>
                                        </table>
                                    </td>
                                    </tr>
                                @endforeach
                                @endif
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="mt-4">
                {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


  <style>
    .upload-box { background: #fafafa; }
    .dz-preview .dz-image img { width: 70px; height: 70px; object-fit: cover; }
  </style>

<!--begin::Modal - Project View -->
<div class="modal fade" id="kt_modal_move_to_delivery" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <div class="modal-dialog modal-lg">
    <div class="modal-content rounded">
      <div class="modal-header justify-content-end border-0 pb-0">
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
        </div>
      </div>

      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <div class="mb-6 text-center">
          <h4 class="text-black">
            <label class="text-black">Delivery Documentation <span id="del_mile" class="text-success fs-4 fw-bold"></span> </label>
          </h4>
        </div>

        <!-- Hidden inputs for mile/customer -->
        <input type="hidden" name="mile_sno" value="">
        <input type="hidden" name="customer_id" value="">

        <div class="row mb-3">
          <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Customer</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="customer_name">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Customer ID</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-info fs-6 fw-semibold" id="customer_id">
                    --
                </div>
                </div>
            </div>
          <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Service</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                    <div class="col-8 text-black fs-6 fw-semibold" id="service_name">
                        --
                    </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Service ID</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="service_id">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Variant</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="variant_name">
                    --
                </div>
                </div>
            </div>

            <div class="col-lg-12 mb-4">
                <div class="row">
                <div class="col-3 text-dark fs-6 fw-semibold">Variable</div>
                <div class="col-1 text-black fs-6 fw-bold">:</div>
                <div class="col-8 text-black fs-6 fw-semibold" id="variable_name">
                    --
                </div>
                </div>
            </div>
        </div>

        <div class="col-lg-12 my-3">
          <div class="d-flex justify-content-between align-items-center my-3">
            <label class="fs-4 text-black fw-semibold mb-0">Delivery Attachment</label>
          </div>

          <div class="col-lg-12 scroll-y mt-3" style="max-height: 400px; overflow-y: auto;">
            <div class="row" id="checklist_container">
              @if(isset($DeliCheck_list))
                @foreach($DeliCheck_list as $dc_list)
                  @php
                    $checkId = "check_" . $dc_list->sno;
                    $hiddenId = "CheckHidden_" . $dc_list->sno;
                    $dropzoneId = "dropzone_" . $dc_list->sno;
                  @endphp

                  <div class="col-lg-12 mb-3 checklist-item">
                    <div class="form-check form-check-inline">
                      <input 
                        class="form-check-input checklist-toggle w-20px h-20px" 
                        type="checkbox" 
                        id="{{ $checkId }}" 
                        value="{{ $dc_list->sno }}"
                        data-target="{{ $hiddenId }}"
                        data-name="{{ $dc_list->delivery_attachment_checklist }}"
                      >
                      <label for="{{ $checkId }}" class="text-black mb-1 fs-6 fw-semibold">
                        {{ $dc_list->delivery_attachment_checklist }}
                      </label>
                    </div>

                    <div class="d-none p-2 rounded mt-2 border border-1 border-secondary-subtle upload-box" id="{{ $hiddenId }}">
                      <form action="{{ route('delivery.upload') }}" 
                            class="dropzone needsclick dynamic-dropzone" 
                            id="{{ $dropzoneId }}"
                            data-deli-id="{{ $dc_list->sno }}">
                        @csrf
                        <input type="hidden" name="mile_sno" value="7">
                        <input type="hidden" name="deli_id" value="{{ $dc_list->sno }}">
                        <input type="hidden" name="customer_id" value="423">
                        <div class="dz-message needsclick justify-content-center align-items-center">
                          <span class="note needsclick">
                            <h4>Click Here To Upload Files</h4>
                            <p class="text-muted mb-0">Upload files for: {{ $dc_list->delivery_attachment_checklist }}</p>
                          </span>
                        </div>
                        <div class="d-block text-muted fs-6">Max File Size (5 MB) | Multiple files allowed</div>
                        <div class="fallback">
                          <input name="file[]" type="file" multiple />
                        </div>
                      </form>
                      <div class="mt-2">
                        <div class="file-list" id="file-list-{{ $dc_list->sno }}"></div>
                      </div>
                    </div>
                  </div>

                @endforeach
              @endif
            </div>
          </div>
        </div>

        <div class="modal-footer border-0 pt-5">
          <button type="button" class="btn btn-light me-3" data-bs-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-primary" id="finalSubmitBtn">Submit Delivery Documents</button>
        </div>
      </div>
    </div>
  </div>
</div>
<!--end modal -->

<meta name="csrf-token" content="{{ csrf_token() }}">


{{-- Init scripts --}}
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const dropzones = new Map();
        const uploadedFiles = new Map();

        if (typeof Dropzone !== 'undefined') Dropzone.autoDiscover = false;

        // Checklist toggle show/hide
        document.querySelectorAll('.checklist-toggle').forEach(cb => {
            cb.addEventListener('change', function() {
            const targetId = this.dataset.target;
            const box = document.getElementById(targetId);
            if (!box) return;

            if (this.checked) {
                box.classList.remove('d-none');

                const mile_sno = document.querySelector('input[name="mile_sno"]').value || '';
                const customer_id = document.querySelector('input[name="customer_id"]').value || '';
                box.querySelectorAll('input[name="mile_sno"]').forEach(i => i.value = mile_sno);
                box.querySelectorAll('input[name="customer_id"]').forEach(i => i.value = customer_id);

                loadExistingFiles(this.value);
            } else {
                box.classList.add('d-none');
                uploadedFiles.delete(this.value);
                const dz = dropzones.get(this.value);
                if (dz) dz.removeAllFiles(true);
            }
            });
        });

        // Initialize Dropzones
        document.querySelectorAll('.dynamic-dropzone').forEach(formEl => {
            const deliId = formEl.dataset.deliId;

            if (formEl.dropzone) try { formEl.dropzone.destroy(); } catch(e){}

            const dz = new Dropzone(formEl, {
            url: formEl.getAttribute('action'),
            paramName: 'file',
            uploadMultiple: false,
            maxFiles: 20,
            maxFilesize: 5,
            acceptedFiles: ".xls,.xlsx,.pdf,.doc,.docx,.png,.jpg,.jpeg",
            addRemoveLinks: true,
            autoProcessQueue: true,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
            },
            init: function() {
                const myDz = this;
                dropzones.set(deliId, myDz);

                myDz.on('sending', function(file, xhr, formData){
                const mileInput = formEl.querySelector('input[name="mile_sno"]');
                const deliInput = formEl.querySelector('input[name="deli_id"]');
                const custInput = formEl.querySelector('input[name="customer_id"]');

                if (mileInput) formData.append('mile_sno', mileInput.value);
                if (deliInput) formData.append('deli_id', deliInput.value);
                if (custInput) formData.append('customer_id', custInput.value);
                });

                myDz.on('success', function(file, response) {
                // if (typeof response === 'string') {
                //     try { response = JSON.parse(response); } catch(e){
                //     Swal.fire({ icon:'error', title:'Upload error', text:'Invalid server response' }); return;
                //     }
                // }
                // if (!response.success) {
                //     Swal.fire({ icon:'error', title:'Upload failed', text: response.message || 'Server error' });
                //     myDz.removeFile(file);
                //     return;
                // }

                const deli = formEl.querySelector('input[name="deli_id"]').value;
                if (!uploadedFiles.has(deli)) uploadedFiles.set(deli, []);

                const arr = uploadedFiles.get(deli);
                (response.files || []).forEach(f => {
                    if (!arr.some(x => x.unique_name === f.unique_name)) {
                    arr.push(f);
                    }
                    file._unique_name = f.unique_name;
                    file._path = f.path;
                });

                updateFileList(deli);
                });

                myDz.on('removedfile', function(file) {
                const deli = formEl.querySelector('input[name="deli_id"]').value;
                const unique = file._unique_name || file.name;

                if (unique && uploadedFiles.has(deli)) {
                    const arr = uploadedFiles.get(deli);
                    const idx = arr.findIndex(x => x.unique_name === unique);
                    if (idx !== -1) {
                    const removed = arr.splice(idx,1)[0];
                    updateFileList(deli);

                    fetch("{{ route('delivery.remove') }}", {
                        method: 'POST',
                        headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'Accept': 'application/json'
                        },
                        body: JSON.stringify({ file_path: removed.path, mile_sno: document.querySelector('input[name="mile_sno"]').value, deli_id: deli })
                    }).then(r => r.json()).then(j => console.log('remove resp',j)).catch(e=>console.error(e));
                    }
                }
                });

                myDz.on('error', function(file, err){
                Swal.fire({ icon:'error', title:'Upload error', text: (err.message || err) });
                });

            } // init
            });

            formEl.dropzone = dz;
        });

        // Load existing files
        function loadExistingFiles(deliId) {
            const mileSno = document.querySelector('input[name="mile_sno"]').value;
            if (!mileSno || !deliId) return;

            fetch("{{ route('delivery.existing.files') }}", {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
            },
            body: JSON.stringify({ mile_sno: mileSno, deli_id: deliId })
            }).then(r => r.json()).then(data => {
            const dz = dropzones.get(String(deliId));
            if (!dz) return;

            dz.removeAllFiles(true);
            uploadedFiles.set(deliId, data.files || []);
            updateFileList(deliId);

            // Add mock files for existing
            (data.files || []).forEach(f => {
                const mock = { name: f.name, size: f.size, accepted: true, status: Dropzone.ADDED, _unique_name: f.unique_name, _path: f.path };
                dz.emit("addedfile", mock);
                if (f.type && f.type.startsWith('image')) dz.emit("thumbnail", mock, f.url);
                dz.emit("complete", mock);
            });
            });
        }

        function updateFileList(deliId) {
            const fileListDiv = document.getElementById(`file-list-${deliId}`);
            const arr = uploadedFiles.get(String(deliId)) || [];
            if (!fileListDiv) return;

            if (arr.length === 0) {
            fileListDiv.innerHTML = '<div class="text-muted small">No files uploaded yet</div>';
            return;
            }

            fileListDiv.innerHTML = `
            <div class="text-success small mb-1"><i class="fas fa-check-circle me-1"></i>${arr.length} file(s) uploaded</div>
            <div class="file-list-details small text-muted" style="max-height: 100px; overflow-y:auto;">
                ${arr.map(f => `<div class="mb-1"><i class="fas fa-paperclip me-1"></i> ${f.original_name}</div>`).join('')}
            </div>
            `;
        }

        // Final submit
        document.getElementById('finalSubmitBtn').addEventListener('click', function(){
            const mileSno = document.querySelector('input[name="mile_sno"]').value;
            const customerId = document.querySelector('input[name="customer_id"]').value;
            const checked = Array.from(document.querySelectorAll('.checklist-toggle:checked'));
            if (checked.length === 0) {
            Swal.fire({ icon:'warning', title:'No Checklist Selected', text:'Please select at least one checklist' });
            return;
            }

            const checklistItems = checked.map(cb => {
            const id = cb.value;
            const name = cb.dataset.name;
            const files = uploadedFiles.get(String(id)) || [];
            return { id, name, files };
            });

            const missing = checklistItems.filter(i => i.files.length === 0);
            if (missing.length > 0) {
            const listHtml = missing.map(m => `<div>${m.name}</div>`).join('');
            Swal.fire({ icon:'error', title:'Missing files', html:`Please upload files for: <br/>${listHtml}` });
            return;
            }

            const checklistIds = checklistItems.map(i => i.id);

            Swal.fire({
            title: 'Confirm Submission',
            html: `<p>You're about to submit ${checklistItems.reduce((s,i)=>s+i.files.length,0)} file(s) for ${checklistItems.length} checklist item(s).</p>`,
            icon: 'question',
            showCancelButton: true
            }).then(res => {
            if (!res.isConfirmed) return;
            Swal.fire({ title:'Submitting...', allowOutsideClick:false, didOpen: ()=>Swal.showLoading() });

            fetch("{{ route('delivery.final.submit') }}", {
                method: 'POST',
                headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                'Accept': 'application/json'
                },
                body: JSON.stringify({
                mile_sno: mileSno,
                customer_id: customerId,
                checklist_items: checklistIds
                })
            }).then(r => r.json()).then(json => {
                Swal.close();
                if (json.success) {
                Swal.fire({ icon:'success', title:'Saved', html:`${json.message || 'Files moved to live folder'}` }).then(() => {
                    document.querySelectorAll('.checklist-toggle:checked').forEach(cb => {
                    cb.checked = false;
                    const target = document.getElementById(cb.dataset.target);
                    if (target) target.classList.add('d-none');
                    });
                    dropzones.forEach(dz => dz.removeAllFiles(true));
                    uploadedFiles.clear();
                    const modalEl = document.getElementById('kt_modal_move_to_delivery');
                    const modalObj = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                    modalObj.hide();
                    setTimeout(()=>location.reload(), 800);
                });
                } else {
                Swal.fire({ icon:'error', title:'Error', text: json.message || 'Something failed' });
                }
            }).catch(err=>{
                Swal.fire({ icon:'error', title:'Error', text:'Network error' });
            });
            });
        });

        // Open modal with AJAX data
        window.readyToDeliver = function(sno, mile_sno) {
            document.querySelector('input[name="mile_sno"]').value = mile_sno;

            fetch(`/delivery_documentation_data_fetch/${sno}/${mile_sno}`)
            .then(r => r.json())
            .then(resp => {
                if (!resp || resp.status !== 200) {
                Swal.fire({ icon:'error', title:'Fetch failed', text: resp?.message || 'Server error' });
                return;
                }
                const d = resp.data;
                const m = resp.milestone_data;



                // Fill HTML Fields
                $('#customer_name').text(d.cus_name);
                $('#customer_id').text(d.customer_id);
                $('#service_name').text(d.product_name);
                $('#service_id').text(d.formatted_service_id);
                $('#variant_name').text(d.variant_name);
                $('#variable_name').text(d.variable_name);                
                document.getElementById('del_mile').textContent = m ? (' - ' + (m.payment_slot_name || '')) : '';

                document.querySelector('input[name="customer_id"]').value = d.customer_id || '';

                document.querySelectorAll('.dynamic-dropzone input[name="mile_sno"]').forEach(i=>i.value = mile_sno);
                document.querySelectorAll('.dynamic-dropzone input[name="customer_id"]').forEach(i=>i.value = d.customer_id || '');

                document.querySelectorAll('.checklist-toggle').forEach(cb=>{
                cb.checked = false;
                const target = document.getElementById(cb.dataset.target);
                if (target) target.classList.add('d-none');
                uploadedFiles.delete(cb.value);
                const dz = dropzones.get(cb.value);
                if (dz) dz.removeAllFiles(true);
                const listDiv = document.getElementById('file-list-'+cb.value);
                if (listDiv) listDiv.innerHTML = '<div class="text-muted small">No files uploaded yet</div>';
                });

                const modalEl = document.getElementById('kt_modal_move_to_delivery');
                const modalObj = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                modalObj.show();
            });
        };
        });

</script>




<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
        .err_msg{
        /* background-color: red; */
        border-color: red;
        }

    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

{{-- * TOASTR ENDS --}}




<script>
function indv_cust_func(rowIndex) {

    // Loop through all rows
    document.querySelectorAll("[id^='indv_cust_'][id$='_tbox']").forEach(function(tbox) {
        const index = tbox.id.split("_")[2];  // get number
        const button = document.getElementById(`indv_cust_${index}_plus_btton`);
        const header = document.getElementById(`indv_cust_hd_${index}`);

        if (index == rowIndex) {
            // Toggle open/close
            const isVisible = tbox.style.display === "table-row";

            tbox.style.display = isVisible ? "none" : "table-row";
            button.classList.toggle("mdi-minus", !isVisible);
            button.classList.toggle("mdi-plus", isVisible);

            // Optional highlight
            // header.style.backgroundColor = isVisible ? "" : "#f9f3c5db";
        }
        else {
            // Hide all other rows
            tbox.style.display = "none";
            button.classList.remove("mdi-minus");
            button.classList.add("mdi-plus");
            header.removeAttribute("style");
        }
    });
}
</script>


<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
<script>
document.querySelectorAll('.circular-progress').forEach(el => {
  const progress = parseInt(el.getAttribute('data-progress')) || 0;
  const color = progress === 100 ? '#75D195' : '#EB5B65';
  el.style.setProperty('--progress', progress);
  el.style.setProperty('--fill-color', color);

  if (progress === 100) {
    el.style.setProperty('--fill-color', '#75D195');

    const front = el.querySelector('.progress-front');
    const back = el.querySelector('.progress-back');

    let showProgress = true;

    setInterval(() => {
      el.classList.toggle('flip');
      showProgress = !showProgress;

      if (showProgress) {
        // Show progress circle side
        el.style.background = `conic-gradient(${color} calc(var(--progress) * 1%), var(--track-color) 0)`;
        el.querySelector('.circular-progress::before');
      } else {
        // Hide progress circle when tick.gif is visible
        el.style.background = 'transparent';
      }
    }, 2000);
  }
});
</script>

@endsection
