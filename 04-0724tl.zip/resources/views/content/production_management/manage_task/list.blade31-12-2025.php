@extends('layouts/layoutMaster')

@section('title', 'Manage Task')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }

        @keyframes softPulse {

            0%,
            100% {
                background-color: #f44336;
                box-shadow: 0 0 6px rgba(244, 67, 54, 0.6);
                transform: scale(1);
            }

            50% {
                background-color: #e53935;
                box-shadow: 0 0 12px rgba(244, 67, 54, 0.8);
                transform: scale(1.03);
            }
        }

        .rework-badge {
            background-color: #f44336;
            /* material red */
            color: #fff;
            border-radius: 12px;
            padding: 4px 12px;
            animation: softPulse 1.5s ease-in-out infinite;
            font-weight: 600;
            text-shadow: 0 0 1px rgba(0, 0, 0, 0.2);
        }

        /* Rework badge styling */
        .rework-badge {
            position: relative;
            background: linear-gradient(90deg, #f44336, #e53935);
            color: #fff;
            border-radius: 14px;
            padding: 6px 14px;
            font-weight: 600;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
            letter-spacing: 0.3px;
            box-shadow: 0 0 10px rgba(244, 67, 54, 0.5);
            animation: reworkPulse 2s ease-in-out infinite;
            overflow: hidden;
        }

        /* Subtle pulse animation */
        @keyframes reworkPulse {

            0%,
            100% {
                transform: scale(1);
                box-shadow: 0 0 8px rgba(244, 67, 54, 0.5);
                filter: brightness(1);
            }

            50% {
                transform: scale(1.05);
                box-shadow: 0 0 14px rgba(244, 67, 54, 0.8);
                filter: brightness(1.1);
            }
        }

        /* Glossy light sweep animation */
        .rework-badge::before {
            content: '';
            position: absolute;
            top: 0;
            left: -75%;
            width: 50%;
            height: 100%;
            background: linear-gradient(120deg, rgba(255, 255, 255, 0.3), transparent);
            transform: skewX(-25deg);
            animation: lightSweep 3s infinite;
        }

        @keyframes lightSweep {
            0% {
                left: -75%;
            }

            50% {
                left: 125%;
            }

            100% {
                left: 125%;
            }
        }

        .rework-badge.low {
            background: linear-gradient(90deg, #ff9800, #f57c00);
        }

        .rework-badge.high {
            background: linear-gradient(90deg, #d32f2f, #b71c1c);
        }

        .btn-start-timer {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none !important;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-start-timer:hover {
            background: linear-gradient(135deg, #218838 0%, #1e9e8a 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(40, 167, 69, 0.3) !important;
        }

        .btn-start-timer:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(40, 167, 69, 0.3) !important;
        }

        .btn-end-timer {
            background: linear-gradient(135deg, #dc3545 0%, #e35d6a 100%);
            border: none !important;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-end-timer:hover {
            background: linear-gradient(135deg, #c82333 0%, #d9534f 100%);
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3) !important;
        }

        .btn-end-timer:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(220, 53, 69, 0.3) !important;
        }

        .range-container {
            padding: 1.2rem 1rem;
        }
    </style>
    <style>
        .task-view-container {
            font-family: 'Inter', sans-serif;
        }

        .task-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .staff-avatar {
            width: 80px;
            height: 80px;
            border: 3px solid #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .staff-avatar-placeholder {
            width: 80px;
            height: 80px;
            margin: 0 auto;
            font-size: 1.5rem;
        }

        .checklist-item {
            transition: all 0.3s ease;
            border-radius: 8px;
        }

        .checklist-item:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }

        .form-check-input:checked {
            background-color: #198754;
            border-color: #198754;
        }

        .detail-item {
            padding: 8px 0;
        }

        .task-description {
            border-left: 4px solid #667eea;
        }

        .log-item {
            transition: all 0.2s ease;
        }

        .log-item:hover {
            background-color: #f8f9fa;
            border-radius: 6px;
            padding-left: 8px;
            padding-right: 8px;
        }

        .stat-item {
            padding: 10px;
        }

        .progress {
            border-radius: 10px;
        }

        .progress-bar {
            border-radius: 10px;
        }

        .card {
            border-radius: 12px;
        }

        .time-details {
            border: 1px solid #e9ecef;
        }
    </style>
    <!-- Task List Table -->
    @php
        $helper = new \App\Helpers\Helpers();
        $loginStaff = auth()->user()->user_id;
        $module_name = 'Production Management';
        $menu_name = 'Manage Task';
    @endphp
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Task</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                    <!--<a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter"-->
                    <!--    title="Filter">-->
                    <!--    <i class="mdi mdi-filter-outline text-center"></i>-->
                    <!--</a>-->
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="filter_tbox" style="display: none;">
                <div class="row py-1">
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer ID</label>
                        <input type="text" class="form-control" placeholder="Enter Customer ID" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer</label>
                        <input type="text" class="form-control" placeholder="Enter Customer Name" />
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Writing Products</option>
                            <option value="2">Developement Products</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Thesis Writing</option>
                            <option value="2">Technical Research and Development Services</option>
                            <option value="3">Formatting and Referencing</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Task</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Thesis Writing Support</option>
                            <option value="2">Client Onboarding & Requirement Gathering</option>
                            <option value="3">Literature Review</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Assigned To</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Naveen R</option>
                            <option value="2">Iswarya D</option>
                            <option value="3">Guberan J</option>
                            <option value="4">Indhumathi K</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Task Not Yet Started</option>
                            <option value="2">Task In Progress</option>
                            <option value="3">Task Completed</option>
                            <option value="4">Task Delayed</option>
                            <option value="5">Task Hold</option>
                            <option value="6">Task Not Completed</option>
                            <option value="7">Task Verified</option>
                            <option value="8">Task QC Verified</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                        <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt"
                            onchange="date_fill_issue_rpt();">
                            <option value="all">All</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="monthly">This Month</option>
                            <option value="custom_date">Custom Date</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control"
                                value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text bg-gray-200"><i
                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date"
                                class="form-control this_month_dt_fill" value="<?php echo date(' M-Y'); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" />
                        </div>
                    </div>
                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date"
                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" />
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                    <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                    <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
                </div>
            </div>
            <div class="row">
                {{-- <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @php foreach ($options as $option): @endphp
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @php endforeach; @endphp
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/manage_task">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                    id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div> --}}
                <div class="col-lg-12">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-125px">Customer</th>
                                <th class="min-w-125px">Services</th>
                                <th class="min-w-80px">Tasks</th>
                                <th class="min-w-50px">Assigned To</th>
                                <th class="min-w-80px">No.of.Pages/<br>Percentage
                                </th>
                                <th class="min-w-100px">Status</th>
                                <th class="min-w-50px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7" id="task_table_tbody">
                            @if (auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                @if (isset($lists))
                                    @foreach ($lists as $i => $list)
                                        @php
                                            $rework_color = $list->rework_check > 0 ? 'bg-label-danger' : '';
                                        @endphp
                                        <tr class="{{ $rework_color }}">
                                            <td>
                                                @php
                                                    $percentage = $helper->completed_task_percentage($list->sno);
                                                @endphp
                                                <label class="text-black fw-semibold fs-7 text-wrap"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Customer Name">{{ $list->cus_name }}</label>
                                                <label class="text-light fw-semibold fs-8 text-wrap d-block"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Customer Id">{{ $list->customer_id }}</label>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column">
                                                    <div class="d-flex align-items-center">
                                                        <label
                                                            class="fs-7 text-black fw-semibold text-truncate cursor-pointer"
                                                            style="max-width: 300px;" data-bs-toggle="tooltip"
                                                            data-bs-placement="bottom"
                                                            title="{{ $list->product_name }}">{{ $list->product_name }}</label>
                                                        <label data-bs-toggle="dropdown">
                                                            <span
                                                                class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 cursor-pointer"
                                                                title="Product Variant">
                                                            </span>
                                                        </label>
                                                        <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                                            <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                                                <u>Product Variant Info</u>
                                                            </div>

                                                            <div class="mb-2">
                                                                <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                                                <div class="text-black">{{ $list->variant_name }}</div>

                                                                <div class="text-dark fw-semibold fs-8 mt-1">Details
                                                                    Variable:</div>
                                                                <div class="text-black">{{ $list->variable_name }}</div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="Service ID">{{ $list->formatted_service_id }}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <label class="text-black fw-semibold fs-7 text-wrap"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Task Name">{{ $list->task_name }}</label>
                                                <label class="text-info fw-semibold fs-8 text-wrap d-block"><span
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="Task Id">{{ $list->task_id }}</span></label>
                                                <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Task Progress : {{ $percentage }}%">
                                                    <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                                                        role="progressbar" style="width: {{ $percentage }}%"
                                                        aria-valuenow="{{ $percentage }}"
                                                        aria-valuemin="{{ $percentage }}"
                                                        aria-valuemax="{{ $percentage }}">{{ $percentage }}%</div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-column gap-2 align-items-center avatar-group mb-4">
                                                    <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle"
                                                        data-bs-toggle="tooltip" data-bs-placement="top"
                                                        title="{{ $list->staff_name }}">
                                                        <img src="{{ asset('staff_images/' . $list->staff_image) }}"
                                                            alt="Staff" class="rounded-circle">
                                                    </div>
                                                    @if ($list->rework_check > 0)
                                                        <a href="javascript:;"
                                                            class="badge rework-badge high text-white fs-6 ms-2"
                                                            data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_rework_details"
                                                            onclick="reworkDetails('{{ $list->sno }}', '{{ $list->staff_id }}')">
                                                            Rework
                                                            {{ $list->rework_check < 10 ? str_pad($list->rework_check, 2, '0', STR_PAD_LEFT) : $list->rework_check }}
                                                        </a>
                                                    @endif
                                                </div>
                                            </td>
                                            <td>
                                                @php
                                                    $page_or_per = $list->task_category == 1 ? 'Percentages' : 'Pages';
                                                @endphp
                                                <label
                                                    class="bg-danger rounded-2 px-2 py-1 fw-semibold text-white fs-5 me-1"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Total {{ $page_or_per }}">{{ $list->max_page_or_per }}</label>
                                                /
                                                <label
                                                    class="bg-success rounded-2 ms-1 px-2 py-1 fw-semibold text-white fs-5 me-1"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Completed {{ $page_or_per }}">{{ $list->min_page_or_per }}</label>
                                            </td>
                                            <td>
                                                @php
                                                    $task_pending_or_not = $helper->task_pending_or_not(
                                                        $list->staff_id,
                                                        $list->sno,
                                                    );
                                                @endphp

                                                <!-- STATUS CHANGE -->
                                                @if (auth()->user()->user_id == $list->staff_id)
                                                    @if ($list->status < 3)
                                                        <div class="mb-1 timer_list_div d-flex flex-column align-items-center"
                                                            id="timer_list_div_id{{ $list->staff_id }}_{{ $list->sno }}">
                                                            @if ($task_pending_or_not)
                                                                {{-- Timer is running: show End Timer --}}
                                                                <img src="{{ asset('assets/phdizone_images/header/timer_g1.gif') }}"
                                                                    alt="Task Running"
                                                                    class="image-input-wrapper w-45px h-45px"
                                                                    id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}" />
                                                                <div class="d-block mt-1">
                                                                    <a href="javascript:;"
                                                                        class="btn-end-timer d-inline-flex align-items-center border border-danger rounded-pill text-white fw-semibold fs-7 px-3 py-2 shadow-sm"
                                                                        id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                        onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}');">
                                                                        <i class="fas fa-stop-circle me-2 fs-6"></i>
                                                                        End Timer
                                                                    </a>
                                                                </div>
                                                            @else
                                                                {{-- Timer not running: show Start Timer --}}
                                                                <div class="d-block mt-1">
                                                                    <a href="javascript:;"
                                                                        class="btn-start-timer d-inline-flex align-items-center border border-success rounded-pill text-white fw-semibold fs-7 px-3 py-2 me-2 shadow-sm"
                                                                        id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                        onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}');">
                                                                        <i class="fas fa-play-circle me-2 fs-6"></i>
                                                                        Start Timer
                                                                    </a>
                                                                </div>
                                                            @endif
                                                        </div>
                                                    @elseif ($list->status <= 3)
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #008000 !important;">
                                                            <span>Completed</span>
                                                        </a>
                                                    @endif
                                                @elseif($list->pc_id == $loginStaff)
                                                    @if($list->status < 3)
                                                        @if ($task_pending_or_not)
                                                            <a href="javascript:;"
                                                                class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                                style="background-color: #FF00FF !important;">
                                                                <span>Not Yet Started</span>
                                                            </a>
                                                        @else
                                                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                                <span>In Progress</span>
                                                            </a>
                                                        @endif
                                                    @elseif ($list->status == 3)
                                                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #000080 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            <span>Waiting For QC Verify</span>
                                                            <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item open-action-modal" data-bs-toggle="modal" onclick="status_change('{{ $list->sno }}')" 
                                                                data-bs-target="#kt_modal_Task_status_change">
                                                                QC Verification
                                                            </a>
                                                        </div>
                                                    @elseif ($list->status == 4)
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #000080 !important;">
                                                            <span>QC Verified</span>
                                                        </a>
                                                    @endif
                                                @else
                                                    @if ($list->status < 3)
                                                        @if ($task_pending_or_not)
                                                            <a href="javascript:;"
                                                                class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                                style="background-color: #FF00FF !important;">
                                                                <span>Not Yet Started</span>
                                                            </a>
                                                        @else
                                                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                                <span>In Progress</span>
                                                            </a>
                                                        @endif
                                                    @elseif ($list->status == 3)
                                                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                                                            <span>Completed</span>
                                                        </a>
                                                    @elseif ($list->status == 4)
                                                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #000080 !important;">
                                                            <span>QC Verified</span>
                                                        </a>
                                                    @endif
                                                @endif
                                            </td>
                                            <td>
                                                <span class="text-center">
                                                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        {{-- <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_history"
                                                            onclick="fetchTaskLog('{{ $list->sno }}', '{{ $list->staff_id }}')">
                                                            <span><i class="mdi mdi-history ms-2 fs-3 fw-bold"></i>Task Log</span>
                                                        </a> --}}
                                                        @php
                                                            $currentStatus = '';
                                                            $currentBg = '';
                                                            $currenttxcr = '';
                                                            if ($list->status == 0 || $list->status == 1) {
                                                                $currentStatus = 'In Progress';
                                                                $currentBg = '#eea810';
                                                                $currenttxcr = 'text-white';
                                                            } elseif ($list->status == 3) {
                                                                if ($list->pc_id == $loginStaff) {
                                                                    $currentStatus = 'Waiting For QC Verify';
                                                                    $currentBg = '#000080';
                                                                    $currenttxcr = 'text-white';
                                                                } else {
                                                                    $currentStatus = 'Completed';
                                                                    $currentBg = '#008000';
                                                                    $currenttxcr = 'text-white';
                                                                }
                                                            } elseif ($list->status == 4) {
                                                                if ($list->cre_id == $loginStaff) {
                                                                    $currentStatus = 'Waiting For Delivery';
                                                                    $currentBg = '#008080';
                                                                    $currenttxcr = 'text-white';
                                                                } else {
                                                                    $currentStatus = 'QC Verified';
                                                                    $currentBg = '#000080';
                                                                    $currenttxcr = 'text-white';
                                                                }
                                                            } elseif ($list->status == 5) {
                                                                if ($list->cre_id == $loginStaff) {
                                                                    $currentStatus = 'Delivery Confirmation';
                                                                    $currentBg = '#800000';
                                                                    $currenttxcr = 'text-white';
                                                                } else {
                                                                    $currentStatus = 'Delivery Verified';
                                                                    $currentBg = '#008080';
                                                                    $currenttxcr = 'text-white';
                                                                }
                                                            } elseif ($list->status == 6) {
                                                                $currentStatus = 'Delivered';
                                                                $currentBg = '#0000FF';
                                                                $currenttxcr = 'text-white';
                                                            } elseif ($list->status == 7) {
                                                                if ($list->cre_id == $loginStaff) {
                                                                    $currentStatus = 'Rejected';
                                                                    $currentBg = '#FF00FF';
                                                                    $currenttxcr = 'text-white';
                                                                } else {
                                                                    $currentStatus = 'Rejected';
                                                                    $currentBg = '#FF00FF';
                                                                    $currenttxcr = 'text-white';
                                                                }
                                                            }

                                                        @endphp
                                                        @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_view_task"
                                                                onclick="view_task({{ $list->sno }},'{{ $currentStatus }}','{{ $currentBg }}','{{ $currenttxcr }}')">
                                                                <span> <i
                                                                        class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                            </a>
                                                        @endif
                                                    </div>
                                                </span>
                                            </td>
                                         </tr>
                                    @endforeach
                                @endif
                            @endif
                        </tbody>
                    </table>
                    <!-- </div> -->
                </div>
                {{-- <div class="mt-4">
            {{ $ListTable->appends(request()->except(['page', '_token']))->links() }}
        </div> --}}
            </div>
        </div>
    </div>


    <!--begin::Modal - View Rework-->
    <div class="modal fade" id="kt_modal_rework_details" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black fw-bold">
                            <label>
                                <span class="mb-2 fs-2 fw-semibold ">Rework Details</span>
                                <span class="text-danger fw-bold fs-2 px-2 py-1 mt-4" id="task_log_tsk_name">-</span>
                            </label>
                        </h3>
                    </div>

                    <div class="row mx-3">
                        <div class="col-lg-12" id="rework_details_container">

                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Rework-->

    <!--begin::Modal - Complete Task -->
    <div class="modal fade" id="kt_modal_complete_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded-4">
                <!--begin::Modal header-->
                <div class="modal-header border-0 pb-0 align-items-center">
                    <!--begin::Close-->
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary ms-auto"
                        data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->

                <!--begin::Modal body-->
                <div class="modal-body pt-6 pb-8 px-8 px-xl-12">
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Task Complete</h3>
                    </div>
                    <div class="task-view-container">
                        <!-- Header Section -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <div class="task-header bg-gradient-primary text-white rounded-3 p-4 shadow-sm">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h2 class="mb-1 fw-bold fs-2" style="color: #ffeca9 " id="comp_tsk_tsk_name">
                                                Task Name Here
                                            </h2>
                                            <p class="mb-0 opacity-75">
                                                <i class="mdi mdi-account-outline me-1"></i>
                                                Created by <span id="com_tsk_created_staff">Staff Name</span>
                                            </p>
                                        </div>
                                        <div class="task-badge">
                                            <span class="badge bg-white text-primary fs-6 px-3 py-2" id="com_tsk_tsk_id">
                                                -
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Main Content Grid -->
                        <div class="row">
                            <input type="hidden" name="task_status_id" id="task_status_id">
                            <!-- Left Column - Task Details -->
                            <div class="col-lg-8">
                                <!-- Customer & Service Info Card -->
                                <div class="card border-0 shadow-sm mb-4">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h5 class="card-title mb-0 text-dark">
                                            <i class="mdi mdi-information-outline text-primary me-2"></i>
                                            Task Details
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-account-circle-outline me-1"></i>
                                                        Customer
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6">
                                                        <span id="com_tsk_cus_name">-</span>
                                                        <small class="text-primary ms-1" id="com_tsk_cus_id"></small>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-phone-outline me-1"></i>
                                                        Contact
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_cus_mobile">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-cog-outline me-1"></i>
                                                        Service
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_task_pro_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-dropbox me-1"></i>
                                                        Product Category
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_task_cat_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-package-variant me-1"></i>
                                                        Variant
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_variant_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-tune-vertical me-1"></i>
                                                        Variable
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_variable_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-2">
                                                        <i class="mdi mdi-text-long me-1"></i>
                                                        Description
                                                    </label>
                                                    <div class="task-description bg-light rounded-2 p-3">
                                                        <p class="mb-0 text-dark fs-6" id="com_tsk_tsk_desc">
                                                            -
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Checklist & Progress in Same Row -->
                                <div class="row">
                                    <!-- Progress Summary -->
                                    <div class="col-lg-12">
                                        <div class="card border-0 shadow-sm h-100">
                                            <div class="card-header bg-transparent border-0 py-3">
                                                <h5 class="card-title mb-0 text-dark">
                                                    <i class="mdi mdi-chart-pie text-warning me-2"></i>
                                                    Progress Summary
                                                </h5>
                                            </div>
                                            <div class="card-body">
                                                <div class="progress-summary text-center">
                                                    <div class="row mb-3 range-container">
                                                        <label for="formRangeMax"
                                                            class="form-label text-info fs-5 mb-4 fw-bold">
                                                            Number Of <span id="com_task_page_or_per">Pages</span>
                                                            Completed:
                                                            <span id="currentValue"
                                                                class="current-value bg-success fs-4 px-2 py-1 text-white"></span><span
                                                                id="com_task_page_or_per2"></span>
                                                        </label>
                                                        <input type="hidden" name="checklist_task_id"
                                                            id="checklist_task_id">
                                                        <input type="range" class="form-range mt-4" id="formRangeMax"
                                                            name="num_pages" min="0" max="10"
                                                            step="1" value="1" onchange="checklistShow()" />

                                                        <div class="d-flex justify-content-between mt-2 fs-6 text-muted">
                                                            <span class="text-success fs-4 fw-semibold">Page 1</span>
                                                            <span class="text-success fs-4 fw-semibold">Page 10</span>
                                                        </div>
                                                        <div id="range_move_err"
                                                            class="text-danger fs-7 fw-semibold mt-2">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Task Checklist -->
                                    <div class="col-lg-12" id="checklist_container">
                                        <div class="card border-0 shadow-sm h-100">
                                            <div class="card-header bg-transparent border-0 py-3">
                                                <h5 class="card-title mb-0 text-dark">
                                                    <i class="mdi mdi-format-list-checks text-success me-2"></i>
                                                    Task Checklist
                                                </h5>
                                            </div>
                                            <div class="card-body">
                                                <div id="task_check_fetch_container"
                                                    style="max-height: 400px; overflow-y: auto;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Column - Staff & Time Spent -->
                            <div class="col-lg-4">
                                <!-- Combined Staff Assignment & Time Spent Card -->
                                <div class="card border-0 shadow-sm">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h5 class="card-title mb-0 text-dark">
                                            <i class="mdi mdi-account-clock text-info me-2"></i>
                                            Staff & Time Tracking
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <!-- Staff Profile Section -->
                                        <div class="staff-section text-center mb-4 pb-3 border-bottom">
                                            <div class="staff-profile">
                                                <div id="com_tsk_staff_img">
                                                </div>
                                                <h6 class="mt-3 mb-1 fw-bold text-dark" id="com_tsk_pro_staff_name">-</h6>
                                                <p class="text-muted small mb-2" id="com_tsk_pro_nick_name">-</p>
                                                <span class="badge bg-info bg-opacity-10 text-info"
                                                    id="com_tsk_job_pos">-</span>
                                            </div>
                                        </div>

                                        <!-- Total Time Spent Section -->
                                        <div class="time-spent-section text-center mb-4">
                                            <div class="total-hours">
                                                <div class="text-muted small mb-2">Allocated Hours</div>
                                                <div class="display-5 text-primary fw-bold mb-3" id="total_time">-</div>
                                            </div>
                                        </div>

                                        <!-- Time Logs Section -->
                                        <div class="time-logs-section">
                                            <button class="btn btn-outline-primary btn-sm w-100 mb-3" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#timeLogs">
                                                <i class="mdi mdi-clock-outline me-1"></i>
                                                View Detailed Time Logs
                                            </button>

                                            <div class="collapse show" id="timeLogs">
                                                <div class="time-logs-container" id="time-logs-container"
                                                    style="max-height: 200px; overflow-y: auto;">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2">
                        <a href="{{ url('/manage_production') }}"
                            class="btn fw-bold btn-secondary me-3 waves-effect waves-light">Cancel</a>
                        <button type="button" class="btn fw-bold btn-primary waves-effect waves-light"
                            onclick="updateTaskValidation()">Update Task</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Complete Task -->

    <!--begin::Modal - Update Task-->
    <div class="modal fade" id="kt_modal_edit_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Task</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" name="edit_daily_task_sno" id="edit_daily_task_sno">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_staff" id="edit_task_staff"
                                onchange="fetchEditTaskService()">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_staff_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_service" id="edit_task_service"
                                onchange="fetchEditTask()">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_service_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Task<span class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_id" id="edit_task_id">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="edit_task_btn"
                            onclick="editValidation()">Update Task</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Task-->

    <!--begin::Modal - View Task-->
    <div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">
                            <label>View Task Details</label>
                            <label class="ms-1 me-1">-</label>
                            <label id="view_badge"></label>
                        </h3>
                    </div>
                    <div id="view_data_div"></div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Task-->

    <!--begin::Modal - Delete Task-->
    <div class="modal fade" id="kt_modal_delete_task" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to
                    delete Task ?
                    <div class="d-block fw-bold fs-5 mt-3 py-2">
                        <label class="mb-1" id="del_task_name">-</label>
                        <label class="ms-1 me-1 mb-1">-</label>
                        <label class="mb-1" id="del_customer">-</label>
                        <label class="ms-1 me-1 mb-1">-</label>
                        <label class="mb-1" id="del_prd">-</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_confirm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Task-->

    <!--begin::Modal - View History-->
    <div class="modal fade" id="kt_modal_view_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black fw-bold">
                            <label>
                                <span class="mb-2 fs-2 fw-semibold d-block">Task Log</span>
                                <span class="bg-danger text-white fw-bold fs-5 px-2 py-1 mt-4"
                                    id="task_log_tsk_name">-</span>
                            </label>
                        </h3>
                    </div>

                    <div class="row mx-3">
                        <div class="col-lg-12">
                            <div class="table-responsive shadow-sm">
                                <table
                                    class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
                                    <thead>
                                        <tr class="text-start align-middle fw-bold fs-6 bg-primary text-white">
                                            <th class="min-w-50px px-3 py-2">Sno</th>
                                            <th class="min-w-125px px-3 py-2">Start Time</th>
                                            <th class="min-w-125px px-3 py-2">End Time</th>
                                            <th class="min-w-80px px-3 py-2">Duration</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-700 fw-semibold fs-7" id="task_log_tr_data">
                                        <!-- AJAX WILL POPULATE HERE -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View History-->

    <!--begin::Modal - Status Change-->
    <div class="modal fade" id="kt_modal_Task_status_change" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content rounded">
                <!-- Modal Header -->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>

                <!-- Modal Body -->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!-- Confirmation Icon -->
                    <div class="bg-label-danger rounded-circle d-flex justify-content-center align-items-center w-80px h-80px"
                        style="margin: 0 auto 1.5rem;">
                        <i class="mdi mdi-help fs-2"></i>
                    </div>

                    <!-- Confirmation Text -->
                    <div class="text-center mb-4">
                        <h4 class="mb-2">Are you sure you want to <span id="status_change_status_name"
                                class="badge"></span> this task?</h4>
                        <p class="text-muted">Please review the task details before confirming</p>
                    </div>

                    <!-- Task Details -->
                    <div class="task-details-card">
                        <input type="hidden" name="sts_chng_tsk_id" id="sts_chng_tsk_id">
                        <input type="hidden" name="sts_chng_sts_id" id="sts_chng_sts_id">

                        <div class="detail-row">
                            <div class="detail-label fs-5 fw-bold">Task</div>
                            <div class="detail-value fs-6 fw-semibold">
                                <span id="sts_change_tsk_name"></span>
                                (<span id="sts_change_tsk_id" class="text-danger fw-bold"></span>)
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-label fs-5 fw-bold">Customer</div>
                            <div class="detail-value fs-6 fw-semibold">
                                <span id="sts_change_cus_name"></span>
                                (<span id="sts_change_cus_id" class="text-info fw-bold"></span>)
                            </div>
                        </div>

                        <div class="detail-row">
                            <div class="detail-label fs-5 fw-bold">Service</div>
                            <div class="detail-value fs-6 fw-semibold">
                                <span id="sts_change_product_name"></span>
                                (<span id="sts_change_product_cat" class="text-success fw-bold"></span>)
                            </div>
                        </div>
                    </div>

                    <!-- Page Stats -->
                    <div class="page-stats">
                        <div class="stat-card total">
                            <div class="stat-label fs-6 text-dark" style="text-transform: uppercase;letter-spacing: 1px;">
                                Total Allocated <span class="status_change_per_or_page">Pages</span>
                            </div>
                            <div class="stat-number" id="sts_chnge_max_page">0</div>
                        </div>
                        <div class="stat-card completed">
                            <div class="stat-label fs-6 text-dark" style="text-transform: uppercase;letter-spacing: 1px;">
                                Completed <span class="status_change_per_or_page">Pages</span></div>
                            <div class="stat-number" id="sts_chnge_min_page">0</div>
                        </div>
                    </div>

                    <!-- Checklist Section -->
                    <div id="sts_chnge_hide_show" style="display: none;">
                        <div class="section-title">
                            <i class="mdi mdi-list-box-outline fs-3"></i>
                            Checklist
                        </div>
                        <div class="checklist-container" id="sts_chnge_check_container">
                            <!-- Checklist items will be dynamically added here -->
                        </div>
                    </div>

                    <!-- Delivery Confirmation -->
                    <div id="cre_confirmation_container" style="display: none;">
                        <div class="section-title">
                            <i class="mdi mdi-clipboard-check-outline fs-3"></i>
                            Delivery Confirmation
                        </div>
                        <div class="confirmation-container">
                            <div class="confirmation-check">
                                <input class="form-check-input mt-1" type="checkbox" id="cre_confrm_check"
                                    value="1">
                                <div class="confirmation-text">
                                    <strong>Important:</strong> Please verify whether the customer has paid the milestone
                                    amount. If payment has not been made, kindly collect it before confirming the delivery.
                                    You are fully responsible for handling this, as it occurred in your presence. I approve
                                    this approach.
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reject Status -->
                    <div id="reject-status-container" style="display: none;">
                        <div class="section-title">
                            <i class="mdi mdi-cancel fs-3"></i>
                            Reject Reason
                        </div>
                        <div class="status-container">
                            <label class="form-label fs-6 text-black">Reject Reason <span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control" rows="3"
                                placeholder="Please provide a detailed reason for rejecting this task..." name="reject_reason"
                                id="reject_reason"></textarea>
                            <div id="reject_status_err" class="text-danger mt-1 fs-7 fw-semibold"></div>
                        </div>
                    </div>

                    <!-- Rework Status -->
                    <div id="rework-status-container" style="display: none;">
                        <div class="section-title">
                            <i class="mdi mdi-rotate-left fs-3"></i>
                            Rework Details
                        </div>
                        <div class="status-container">
                            <div class="row">
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fs-6 text-black">Rework <span
                                            class="status_change_per_or_page">Pages</span>
                                        <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Enter number of pages"
                                        id="rework_pages" name="rework_pages"
                                        oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/^(\d{10})\\d*/, '$1');">
                                    <div id="rework_pages_err" class="text-danger mt-1 fs-7 fw-semibold"></div>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label fs-6 text-black">Rework Reason <span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" placeholder="Please provide a detailed reason for requesting rework..."
                                        name="rework_reason" id="rework_reason"></textarea>
                                    <div id="rework_status_err" class="text-danger mt-1 fs-7 fw-semibold"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal Footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Cancel
                    </button>
                    <button type="button" class="btn btn-primary" id="status_change_btn" onclick="sts_submit()">Confirm
                        Change
                    </button>
                </div>
            </div>
        </div>
    </div>
    <!--end::Modal - Status Change-->


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <style>
        :root {
            --primary-color: #3a7bd5;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --success-color: #2ecc71;
            --info-color: #3498db;
            --secondary-color: #95a5a6;
            --dark-color: #343a40;
            --border-radius: 12px;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .task-details-card {
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--primary-color);
        }

        .detail-row {
            display: flex;
            margin-bottom: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .detail-label {
            flex: 0 0 30%;
            font-weight: 600;
            color: var(--dark-color);
        }

        .detail-value {
            flex: 1;
            color: #555;
        }

        .page-stats {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            flex: 1;
            text-align: center;
            padding: 1.25rem;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.total {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            border-left: 4px solid var(--secondary-color);
        }

        .stat-card.completed {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-left: 4px solid var(--info-color);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0.5rem 0;
        }

        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .section-title i {
            color: var(--primary-color);
        }

        .checklist-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px dashed #dee2e6;
        }

        .checkbox-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 0.75rem;
            padding: 0.75rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .checkbox-item input {
            margin-top: 0.25rem;
            margin-right: 0.75rem;
        }

        .confirmation-container {
            background-color: #fff9e6;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--warning-color);
        }

        .confirmation-check {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
        }

        .confirmation-text {
            color: #856404;
            line-height: 1.5;
        }

        .status-container {
            background-color: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #e9ecef;
        }
    </style>

    <script>
        function view_task(id, task_name, color, text_color) {

            $('#view_badge').html(`
                            <span class="badge bg-info ${text_color || ''} rounded fw-semibold fs-5" 
                                    style="background-color: ${color || ''} !important;">
                                ${task_name || ''}
                            </span>
                            `);
            fetch('/manage_production/task_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        $('#view_data_div').empty().append(data.data.html);
                        $('[data-bs-toggle="tooltip"]').tooltip();

                        const containers = document.getElementById('product_variant_container');
                        containers.innerHTML = '';

                    } else {
                        console.log(data.error_msg);
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>

    <script>
        $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.filter_tbox').slideToggle('fast');
            @endif
        });
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>

    <script>
        function status_change(id, yesOrNo = '') {

            $.ajax({
                url: `/status_change_data_fetch/${id}`,
                method: "GET",
                success: function(response) {
                    if (response.status === 200) {
                        var status = response.data;
                        var html = '';

                        $('#sts_chng_tsk_id').val(id);
                        $('#sts_chnge_hide_show').show();
                        $('#cre_confirmation_container').hide();
                        $('#reject-status-container').hide();
                        $('#rework-status-container').hide();
                        $('#status_change_btn').prop('disabled', false);
                        $('#reject_status_err').text('');

                        if (yesOrNo == 'reject') {
                            $('#sts_chng_sts_id').val(6);
                        } else {
                            $('#sts_chng_sts_id').val(status.status);
                        }

                        $('#sts_change_tsk_name').html(status.task_name);
                        $('#sts_change_tsk_id').html(status.tasks_id);
                        $('#sts_change_cus_name').html(status.cus_name);
                        $('#sts_change_cus_id').html(status.customer_id);
                        $('#sts_change_product_name').html(status.product_name);
                        $('#sts_change_product_cat').html(status.product_category_name);
                        $('#sts_chnge_min_page').html(status.min_page_or_per);
                        $('#sts_chnge_max_page').html(status.max_page_or_per);
                        $("#status_change_status_name").removeClass(`text-white`);
                        $("#status_change_status_name").removeClass(`text-black`);

                        var maxPages = status.max_page_or_per;

                        if (status.task_category == 1) {
                            $('.status_change_per_or_page').html('Percentage');
                        } else {
                            $('.status_change_per_or_page').html('Pages');
                        }

                        if (status.status == 3) {
                            $('#status_change_status_name').html('QC Verification');
                            $('#status_change_btn').html('QC Verification');
                            $("#status_change_status_name").attr('style', `background-color:#000080`);
                            $("#status_change_status_name").addClass('text-white');

                            // QC Checklist
                            $.ajax({
                                url: `/list_qc_checklist`,
                                method: 'GET',
                                success: function(response) {
                                    if (response.status === 200) {
                                        if (response.data.length > 0) {
                                            response.data.forEach((check, index) => {
                                                html += `
                                            <div class="d-flex align-items-center mb-2">
                                                <input class="form-check-input task_chk_box" type="checkbox" name="task_check_list[]" value="${check.sno}">
                                                <label class="form-check-label ms-2">${check.qc_checklist}</label>
                                            </div>
                                            `;
                                            });

                                            $('#sts_chnge_check_container').html(html);
                                        } else {
                                            html +=
                                                `<label class="mb-0 text-dark fs-6 fw-bold">No QC Check to Verify</label>`;
                                            $('#sts_chnge_check_container').html(html);
                                        }

                                        const totalQC = $('.task_chk_box').length;
                                        const checkedQC = $('.task_chk_box:checked').length;

                                        $('#status_change_btn').prop('disabled', totalQC === 0 ||
                                            totalQC !== checkedQC);

                                        $(document).on('change', '.task_chk_box', function() {
                                            const total = $('.task_chk_box').length;
                                            const checked = $('.task_chk_box:checked')
                                                .length;
                                            $('#status_change_btn').prop('disabled',
                                                total === 0 || total !== checked);
                                        });
                                    }
                                }
                            });
                        } else if (status.status == 4) {
                            $('#status_change_status_name').html('Delivery Verification');
                            $('#status_change_btn').html('Delivery Verification');
                            $("#status_change_status_name").attr('style', `background-color:#008080`);
                            $("#status_change_status_name").addClass('text-white');

                            // Delivery Checklist
                            $.ajax({
                                url: `/list_delivery_checklist`,
                                method: 'GET',
                                success: function(response) {
                                    if (response.status === 200) {
                                        if (response.data.length > 0) {
                                            response.data.forEach((check, index) => {
                                                html += `
                                            <div class="d-flex align-items-center mb-2">
                                                <input class="form-check-input delivery_chck_bx" type="checkbox" name="delivery_checklist[]" value="${check.sno}">
                                                <label class="form-check-label ms-2">${check.delivery_checklist}</label>
                                            </div>`;
                                            });

                                            $('#sts_chnge_check_container').html(html);
                                        } else {
                                            html +=
                                                `<label class="mb-0 text-dark fs-6 fw-bold">No Delivery Check to Verify</label>`;
                                            $('#sts_chnge_check_container').html(html);
                                        }

                                        const totalDC = $('.delivery_chck_bx').length;
                                        const checkedDC = $('.delivery_chck_bx:checked').length;

                                        $('#status_change_btn').prop('disabled', totalDC === 0 ||
                                            totalDC !== checkedDC);

                                        $(document).on('change', '.delivery_chck_bx', function() {
                                            const totalDelivery = $('.delivery_chck_bx')
                                                .length;
                                            const checkedDelivery = $(
                                                '.delivery_chck_bx:checked').length;
                                            $('#status_change_btn').prop('disabled',
                                                totalDelivery === 0 || totalDelivery !==
                                                checkedDelivery);
                                        });
                                    }
                                }
                            });
                        } else if (status.status == 5 && yesOrNo == 'confirm') {
                            $('#sts_chnge_hide_show').hide();
                            $('#cre_confirmation_container').show();

                            $('#status_change_btn').prop('disabled', true);

                            $('#cre_confrm_check').on('change', function() {
                                if ($(this).is(':checked')) {
                                    $('#status_change_btn').prop('disabled', false);
                                } else {
                                    $('#status_change_btn').prop('disabled', true);
                                }
                            });

                        } else if (status.status == 5 && yesOrNo == 'reject') {
                            $('#sts_chnge_hide_show').hide();
                            $('#reject-status-container').show();
                            $('#status_change_btn').prop('disabled', true);

                            $('#reject_reason').on('input', function() {
                                if ($(this).val().trim() !== '') {
                                    $('#status_change_btn').prop('disabled', false);
                                    $('#reject_status_err').text('');
                                } else {
                                    $('#status_change_btn').prop('disabled', true);
                                    $('#reject_status_err').text('Enter Reject Reason.');
                                }
                            });
                        } else if (status.status == 7) {
                            $('#sts_chnge_hide_show').hide();
                            $('#rework-status-container').show();
                            $('#status_change_btn').prop('disabled', true);

                            function checkReworkInputs() {
                                var reworkValid = true;
                                const reason = $('#rework_reason').val().trim();
                                const pages = $('#rework_pages').val().trim();

                                // Reset errors
                                $('#rework_status_err').html('');
                                $('#rework_pages_err').html('');

                                if (reason === '') {
                                    reworkValid = false;
                                    $('#rework_status_err').html('Enter Rework Reason.');
                                }

                                if (pages === '') {
                                    reworkValid = false;
                                    $('#rework_pages_err').html('Enter Rework Pages.');
                                } else if (parseInt(pages) > maxPages) {
                                    reworkValid = false;
                                    $('#rework_pages_err').html('Rework Pages exceed Allocated Pages.');
                                } else if (parseInt(pages) <= 0) {
                                    reworkValid = false;
                                    $('#rework_pages_err').html('Enter Atleast One Pages.');
                                }

                                $('#status_change_btn').prop('disabled', !reworkValid);
                            }

                            $('#rework_reason, #rework_pages').on('input', checkReworkInputs);
                        }
                    }
                },
                error: function() {
                    console.error('Data Fetching Failed!');
                }
            });

        }


        function sts_submit() {
            var sno = $("#sts_chng_tsk_id").val();
            var status = $("#sts_chng_sts_id").val();

            if (sno) {

                let payload = {
                    sno: sno,
                    status: status
                };

                var qcCheckId = [];
                if (status == 3) {
                    $('.task_chk_box:checked').each(function() {
                        qcCheckId.push($(this).val());
                    });
                }

                var deliveryCheckId = [];
                if (status == 4) {
                    $('.delivery_chck_bx:checked').each(function() {
                        deliveryCheckId.push($(this).val());
                    });
                }

                var rejectReason = '';
                if (status == 6) {
                    rejectReason = $('#reject_reason').val();
                }

                var reworkReason = '';
                var reworkPages = '';
                if (status == 7) {
                    reworkReason = $('#rework_reason').val();
                    reworkPages = $('#rework_pages').val();
                }


                payload.qc_checked_ids = qcCheckId;
                payload.delivery_checked_ids = deliveryCheckId;
                payload.reject_reason = rejectReason;
                payload.rework_reason = reworkReason;
                payload.rework_pages = reworkPages;

                $.ajax({
                    url: "{{ route('task/status_change') }}",
                    method: "POST",
                    data: JSON.stringify(payload),
                    contentType: "application/json",
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    beforeSend: function() {
                        $('#status_change_btn').prop('disabled', true);
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Task status has been successfully updated!');
                            location.reload();
                        }
                    },
                    error: function() {

                    }
                });
            }
        }
    </script>

    <script>
        function Delete_task(sno, task, cus_name, cus_id, prd) {
            document.querySelector('#kt_modal_delete_task .btn-danger').setAttribute('data-id', sno);
            $('#del_task_name').html(task);
            $('#del_customer').html(cus_name + ' ( ' + cus_id + ' )');
            $('#del_prd').html(prd);
        }
    </script>
    <script>
        function get_task_working_hours(id) {

            if (id == '') {
                const Hour = 0;
                // Assign value to input field
                $('#workingHours').val(Hour);
                const hourLabel = Hour === 1 ? 'Hr' : 'Hrs';
                $('#workingHours_label').html(`${Hour} ${hourLabel}`);
                updateEndDate();
                return false;
            }

            fetch(`/fetch_task_check_list/${id}`, {
                    method: 'GET',
                    headers: {
                        'CONTENT-TYPE': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        var cus = data.data;

                        const Hour = parseFloat(cus.hours_id) || 0;
                        // Assign value to input field
                        $('#workingHours').val(Hour);
                        const hourLabel = Hour === 1 ? 'Hr' : 'Hrs';
                        $('#workingHours_label').html(`${Hour} ${hourLabel}`);
                        $('#empl_skill').html(cus.employee_skill);
                        updateEndDate();

                        const select_task_ch = $('#task_check_list');
                        select_task_ch.empty(); // Clear previous options
                        if (cus.task_check_list && cus.task_check_list.length > 0) {
                            cus.task_check_list.forEach(task_ch => {
                                select_task_ch.append(
                                    `<option value="${task_ch.sno}">${task_ch.task_checklist}</option>`);
                            });
                        }

                        // select.trigger('change'); // If using Select2 or similar
                    } else {
                        console.log('Error Fetching Data!');
                    }
                })
                .catch(err => {
                    console.log(`Error Fetching Data : ${err}`);
                });
        }

        function Edit_task(id) {
            fetch('/task_edit/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.log(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#task_customer').html(com.cus_name + ' ( ' + com.cus_id + ' )');
                        $('#task_service').html(com.product_name);
                        $('#task_service_cat').html(com.product_category_name);
                        $('#workingHours').val(com.working_hours).change();
                        $('#task_per_hr_task').val(com.per_hour_cost);
                        // Your original datetime string
                        const datetimeStr = com.start_date_time;

                        // Parse into a Date object (assumes local time)
                        const dateObj = new Date(datetimeStr.replace(' ', 'T')); // "2025-06-11T14:53:00"

                        // Define month names for formatting
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                            "Dec"
                        ];

                        // Format function
                        function formatDate(d) {
                            let day = d.getDate();
                            let month = monthNames[d.getMonth()];
                            let year = d.getFullYear();

                            // Hours 12-hour format
                            let hours = d.getHours();
                            let ampm = hours >= 12 ? 'PM' : 'AM';
                            hours = hours % 12;
                            hours = hours ? hours : 12; // hour '0' should be '12'

                            // Minutes with leading zero
                            let minutes = d.getMinutes();
                            minutes = minutes < 10 ? '0' + minutes : minutes;

                            return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                        }

                        const task_st_dt_tm = document.getElementById('task_st_dt_tm');
                        if (task_st_dt_tm) {
                            task_st_dt_tm.flatpickr({
                                enableTime: true,
                                dateFormat: "d-M-Y h:i K",
                                minDate: formatDate(
                                    dateObj) // disables past dates and times before current moment
                            });
                        }

                        // Set formatted value to your input
                        $('#task_st_dt_tm').val(formatDate(dateObj));
                        updateEndDate()

                        $('#max_amount_edit').val(com.max_amount);
                        $('#desc_edit').val(com.product_desc);
                        var cus = data.data;
                        $('#tsk_variant').html(cus.variant_name);
                        $('#tsk_variable').html(cus.variable_name);
                        const select = $('#task_staffs');
                        select.empty(); // Clear previous options
                        if (cus.production_staffs && cus.production_staffs.length > 0) {
                            cus.production_staffs.forEach(staff => {
                                select.append(
                                    `<option value="${staff.sno}" data-perhour="${staff.per_hour_cost}">${staff.staff_name}</option>`
                                    );
                            });
                        }
                        const select_task = $('#task_name');
                        select_task.empty(); // Clear previous options
                        select_task.append(`<option value="">Select Task</option>`);

                        if (cus && Array.isArray(cus.task_list) && cus.task_list.length > 0) {
                            cus.task_list.forEach(task => {
                                // Check task object properties before appending
                                if (task && task.sno !== undefined && task.task_name) {
                                    select_task.append(
                                        `<option value="${task.sno}" data-workinghour="${task.hours_id}">${task.task_name}</option>`
                                        );
                                    select_task.val(cus.task_name).change();
                                }
                            });
                            let task_check_list = [];

                            try {
                                task_check_list = JSON.parse(com.task_check_list_ids).map(id => id.toString().trim());
                            } catch (e) {}
                            setTimeout(() => $('#task_check_list').val(task_check_list || '').trigger('change'), 2000);
                        }

                        let task_staffs = [];

                        try {
                            task_staffs = JSON.parse(com.assign_staffs).map(id => id.toString().trim());
                        } catch (e) {}
                        $('#task_staffs').val(task_staffs || '').change();

                        $('#task_desc').val(com.task_desc);
                        // if(com.billable==1){
                        //     $('#billablle_task').prop('checked', true);
                        // }else{
                        //     $('#billablle_task').prop('checked', false);
                        // }

                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
                });
        }


        function updateEndDate() {
            const workingHoursSelect = document.getElementById('workingHours');
            const startDateInput = document.getElementById('task_st_dt_tm');
            const endDateInput = document.getElementById('assigned_end_date');
            const workingHours = parseFloat(workingHoursSelect.value);
            const startDateStr = startDateInput.value;

            if (!workingHours || !startDateStr) {
                endDateInput.value = '';
                return;
            }

            // Parse the start date from input (should be ISO format or flatpickr format)
            const startDate = new Date(startDateStr);

            if (isNaN(startDate)) {
                endDateInput.value = 'Invalid Start Date';
                return;
            }

            // Calculate end date by adding working hours (in milliseconds)
            const endDate = new Date(startDate.getTime() + workingHours * 60 * 60 * 1000);

            // Format endDate as "d-M-Y h:i A"
            const day = String(endDate.getDate()).padStart(2, '0');
            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const month = monthNames[endDate.getMonth()];
            const year = endDate.getFullYear();

            let hours = endDate.getHours();
            const minutes = String(endDate.getMinutes()).padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // convert 0 to 12
            const formattedHours = String(hours).padStart(2, '0');

            const formattedEndDate = `${day}-${month}-${year} ${formattedHours}:${minutes} ${ampm}`;

            $('#assigned_end_date').val(formattedEndDate);
            $('#assigned_end_date_hidden').val(formattedEndDate);
        }
    </script>
    <script>
        function AddvalidateForm() {
            let isValid = 0;
            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'task_name',
                    name: 'Task Name'
                },
                {
                    id: 'workingHours',
                    name: 'Working Hours'
                },
                {
                    id: 'task_st_dt_tm',
                    name: 'Assigned Start Date'
                },
                {
                    id: 'task_per_hr_task',
                    name: 'Per Hour Cost'
                },
                {
                    id: 'task_staffs',
                    name: 'Staff'
                },
                {
                    id: 'task_check_list',
                    name: 'Checklist'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            if (isValid == 0) {
                $('#add_form').submit();
            }
        }
    </script>
    <script>
        function delete_confirm() {

            var delete_id = document.querySelector('#kt_modal_delete_task .btn-danger').getAttribute('data-id');

            fetch('/task_delete/' + delete_id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Task Deleted successfully!');
                        location.reload();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    {{-- ! Date Picker Script --}}
    <script>
        $(document).ready(function() {
            var isRtl = false; // Define this as needed
            if ($('.area_andarkottaram').length) {
                $('.area_andarkottaram').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'd-M-yyyy',
                    orientation: isRtl ? 'auto right' : 'auto left'
                });
            }
        });
    </script>


    {{-- ! Update Edit Task --}}
    <script>
        let isProgrammaticChange = false;
        let isTaskChange = false;

        function fetchEditTaskService(preselectServiceId = '', callback = null) {
            if (isProgrammaticChange) return;
            $('#edit_task_id').empty();
            $.ajax({
                url: `/get_customer_services`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var services = response.data;
                        const serviceContainer = $('#edit_task_service');
                        $('#edit_task_id').val('');
                        serviceContainer.empty();

                        serviceContainer.append(`<option value="">Select Service</option>`);
                        services.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.cus_name} - ${service.customer_id} - ${service.product_name}</option>`
                                );
                        });

                        // Set preselected value if provided
                        isTaskChange = true;
                        if (preselectServiceId) {
                            serviceContainer.val(preselectServiceId).trigger('change');
                        }
                        isTaskChange = false;

                        // Use the correct callback variable name
                        if (callback && typeof callback === 'function') {
                            callback();
                        }

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }

        function fetchEditTask(taskId = '') {
            if (isTaskChange) return;
            var serviceId = $('#edit_task_service').val();
            var staffId = $('#edit_task_staff').val();
            $.ajax({
                url: `/task_data_fetch/${serviceId}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var tasks = response.data;
                        const taskContainer = $('#edit_task_id');
                        taskContainer.empty();

                        taskContainer.append(`<option value="">Select Task</option>`)
                        tasks.forEach(task => {
                            taskContainer.append(
                                `<option value="${task.sno}">${task.task_name} - ${task.task_id}</option>`
                                );
                        });
                        taskContainer.val(taskId).trigger('change');

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }

        function updateEditTask(sno) {
            $.ajax({
                url: `/edit_daily_task/${sno}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var edit = response.data;

                        // Staff Data Fetch
                        $.ajax({
                            url: `/production_staff_data_fetch`,
                            method: 'GET',
                            success: function(response) {
                                if (response.status === 200) {

                                    $('#edit_daily_task_sno').val(edit.sno);

                                    var staffs = response.data;
                                    const staffContainer = $('#edit_task_staff');
                                    staffContainer.empty();

                                    staffContainer.append(`<option value="">Select Staff</option>`)
                                    staffs.forEach(staff => {
                                        staffContainer.append(
                                            `<option value="${staff.sno}">${staff.staff_name} - ${staff.department_name}</option>`
                                            );
                                    });

                                    isProgrammaticChange = true;
                                    staffContainer.val(edit.staff_id).trigger('change');
                                    isProgrammaticChange = false;

                                } else {
                                    console.error(`Error Fetching Data : ${response.error_msg}`);
                                }
                            },
                            error: function(Err) {
                                console.error(`Error Fetching Data : ${Err}`);
                            }
                        });

                        fetchEditTaskService(edit.service_id, function() {
                            fetchEditTask(edit.task_id);
                        });

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }
    </script>

    {{-- ! Edit Task Validation --}}
    <script>
        function editValidation() {
            var staffId = $('#edit_task_staff').val();
            var serviceId = $('#edit_task_service').val();
            var taskId = $('#edit_task_id').val();
            var dailyId = $('#edit_daily_task_sno').val();
            let isValid = true;

            $('#edit_task_err', '#edit_task_service_err', '#edit_task_staff_err').text('');

            if (!staffId) {
                isValid = false;
                $('#edit_task_staff_err').text('Staff is required.');
            }

            if (!serviceId) {
                isValid = false;
                $('#edit_task_service_err').text('Service is required.');
            }

            if (!taskId) {
                isValid = false;
                $('#edit_task_err').text('Task is required.');
            }

            if (!isValid) {
                return false;
            } else {

                var postData = {
                    staff_id: staffId,
                    service_id: serviceId,
                    task_id: taskId,
                    sno: dailyId,
                };

                $.ajax({
                    url: `/update_daily_tasks`,
                    method: 'POST',
                    data: postData,
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Daily Task Updated Successfully!');
                            location.reload();
                        } else {
                            toastr.error('Daily Task Updation Failed!');
                        }
                    },
                    error: function(Err) {
                        console.error(`Error Updating Data : ${Err}`);
                    }
                });
            }

            return true;
        }
    </script>

    {{-- ! Task Log Data Fetch --}}
    <script>
        function fetchTaskLog(id, staffId) {
            $.ajax({
                url: `/fetch_task_log/${id}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var tbody = '';

                        $.each(response.data, function(index, logs) {

                            var start = formatDateTime(logs.start_time);
                            var end = formatDateTime(logs.end_time);

                            tbody += '<tr>';
                            tbody += `<td class="px-3 py-2">${index + 1}</td>`;
                            tbody += `<td class="px-3 py-2">
                            <span class="badge text-white fs-6 fw-semibold mb-2" style="background:rgb(149 0 24) !important">${start.date} ${start.time}</span><br>
                        </td>`;
                            tbody += `<td class="px-3 py-2">
                            <span class="badge text-black fs-6 fw-semibold mb-2" style="background:#EEEE82 !important">${end.date} ${end.time}</span><br>
                        </td>`;
                            tbody +=
                                `<td class="px-3 py-2 fs-5 fw-bold" style="color: #4361ee !important;">${formatTime(logs.duration)}</td>`;
                            tbody += '</tr>';
                        });
                        $('#task_log_tr_data').html(tbody);
                        $('#task_log_tsk_name').html(response.task_name.task_name);
                    } else {
                        console.error('Task Log Fetched Failed');
                    }
                },
                error: function(err) {
                    console.error('Task Log Fetched Failed');
                }
            });
        }

        function formatDateTime(dateTimeStr) {
            var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            ];
            var dateObj = new Date(dateTimeStr.replace(' ', 'T')); // convert to ISO format

            var day = String(dateObj.getDate()).padStart(2, '0');
            var month = months[dateObj.getMonth()];
            var year = dateObj.getFullYear();

            var hours = dateObj.getHours();
            var minutes = String(dateObj.getMinutes()).padStart(2, '0');

            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // hour '0' should be '12'
            var hoursStr = String(hours).padStart(2, '0');

            return {
                date: `${day}-${month}-${year}`,
                time: `${hoursStr}:${minutes} ${ampm}`
            };
        }

        function formatTime(timeStr) {
            const [hours, minutes, seconds] = timeStr.split(':').map(Number);

            let result = [];

            if (hours > 0) {
                result.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
            }
            if (minutes > 0) {
                result.push(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
            }
            if (seconds > 0) {
                result.push(`${seconds} second${seconds !== 1 ? 's' : ''}`);
            }

            // If all are zero, return '0 seconds' or whatever you prefer
            if (result.length === 0) {
                return '0 seconds';
            }

            return result.join(' ');
        }

        function reworkDetails(id, staffId) {
            $.ajax({
                url: `/rework_details/${id}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        $('#rework_details_container').html(response.data);
                        $('#task_log_tsk_name').html(response.task_name);
                    } else {
                        console.error('Rework History Fetched Failed');
                    }
                },
                error: function(err) {
                    console.error('Rework History Fetched Failed');
                }
            });
        }
    </script>

    <!-- TIMER SCRIPT -->
    <script>
        // var refreshIntervalId;
        // var elapsedSeconds = 0;

        function endTaskModal(staff_id, task_id) {
            $('.timer_list_div').show();
            completeTaskDataFetch(task_id);
            $('#kt_modal_complete_task').modal('show');

            $('#kt_modal_complete_task').data('staff_id', staff_id);
            $('#kt_modal_complete_task').data('task_id', task_id);
        }

        function stoptaskTimer() {
            var staff_id = $('#kt_modal_complete_task').data('staff_id');
            var task_id = $('#kt_modal_complete_task').data('task_id');

            $.ajax({
                url: '/task-log/stop',
                method: 'POST',
                data: {
                    task_id: task_id,
                    staff_id: staff_id,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    console.log('Timer stopped:', response);
                    toastr.success('Timer stopped successfully!');
                    fetchElapsedTimeFromServer2()
                    fetch('/manage_task/task_table/', {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json(); // we expect JSON now
                        })
                        .then(data => {
                            if (data && data.data) {
                                $('#task_table_tbody').empty().append(data.data);
                                $('[data-bs-toggle="tooltip"]')
                            .tooltip(); // re-initialize tooltips after HTML is added
                            } else {
                                console.log('No data received');
                            }
                        })
                        .catch(error => {
                            console.log('Error:', error);
                        });
                    // Update UI or stop frontend timer here
                },
                error: function(xhr) {
                    console.error('Stop timer error:', xhr.responseText);
                }
            });
        }

        function starttaskTimer(staff_id, task_id) {
            // var display = document.querySelector('#tsk_timer');
            var whom = staff_id;

            $.ajax({
                url: '/task-log/start',
                method: 'POST',
                data: {
                    task_id: task_id,
                    staff_id: staff_id,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    // console.log('Timer started:', response);
                    // Start frontend timer or update UI
                    toastr.success('Timer started successfully!');
                    // location.reload();
                    fetchElapsedTimeFromServer2()
                    fetch('/manage_task/task_table/', {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json(); // we expect JSON now
                        })
                        .then(data => {
                            if (data && data.data) {
                                $('#task_table_tbody').empty().append(data.data);
                                $('[data-bs-toggle="tooltip"]')
                            .tooltip(); // re-initialize tooltips after HTML is added
                            } else {
                                console.log('No data received');
                            }
                        })
                        .catch(error => {
                            console.log('Error:', error);
                        });
                    // $('.timer_list_div').hide();
                    // $('#timer_list_div_id'+staff_id+'_'+task_id).show();
                    // document.getElementById("task_st_timer_list" + whom + '_' + task_id).style.display = "none";
                    // document.getElementById("task_timer_hd_nav").style.display = "inline";
                    // document.getElementById("task_st_timer_icn_nav").style.display = "none";
                    // document.getElementById("task_ed_timer_icn_nav").style.display = "block";
                },
                error: function(xhr) {
                    if (xhr.status === 409) {
                        const res = xhr.responseJSON;
                        toastr.error(res.message || 'A timer is already running for another task.');

                    } else {
                        toastr.error('An error occurred while starting the timer.');
                        console.error('Start timer error:', xhr.responseText);
                    }
                }
            });
        }

        function task_timer_func(val, whom, task_id) {
            if (val == 'start_timer') {
                starttaskTimer(whom, task_id);
            } else {
                endTaskModal(whom, task_id);
            }
        }
    </script>

    <script>
        const display = document.querySelector('#tsk_timer_button');
        const taskcsrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        let elapsedSeconds = 0;
        let timerIntervalId = null;
        let syncIntervalId = null;

        function updateDisplay(seconds) {
            let hours = Math.floor(seconds / 3600);
            let minutes = Math.floor((seconds % 3600) / 60);
            let secondsR = seconds % 60;
            let hh = hours < 10 ? "0" + hours : hours;
            let mm = minutes < 10 ? "0" + minutes : minutes;
            let ss = secondsR < 10 ? "0" + secondsR : secondsR;

            if (display) {
                if (seconds < 60) {
                    display.textContent = ss + ' sec';
                } else if (seconds < 3600) {
                    display.textContent = mm + ":" + ss;
                } else {
                    display.textContent = hh + ":" + mm + ":" + ss;
                }
            }
        }

        function startTimer2() {
            // Clear existing interval if any
            if (timerIntervalId) clearInterval(timerIntervalId);
            if (syncIntervalId) clearInterval(syncIntervalId);

            // Start local UI timer
            timerIntervalId = setInterval(function() {
                elapsedSeconds++;
                updateDisplay(elapsedSeconds);
            }, 1000);

            // Periodically sync with server (every 6 seconds)
            syncIntervalId = setInterval(fetchElapsedTimeFromServer2, 6000);
        }

        function stopTimer2() {
            clearInterval(timerIntervalId);
            clearInterval(syncIntervalId);
            timerIntervalId = null;
            syncIntervalId = null;
        }

        function fetchElapsedTimeFromServer2() {
            fetch('/task-log/running', {
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': taskcsrfToken,
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.running && data.elapsed_seconds >= 0) {
                        elapsedSeconds = data.elapsed_seconds;

                        // UI updates
                        $('#task_timer_hd_nav').show();
                        document.getElementById("task_st_timer_icn_nav").style.display = "none";
                        document.getElementById("task_ed_timer_icn_nav").style.display = "block";

                        // if (!timerIntervalId) {
                        startTimer2(); // Only start if not already started
                        // }

                    } else {
                        stopTimer2();
                        display.textContent = '';
                        $('#task_timer_hd_nav').hide();
                        document.getElementById("task_st_timer_icn_nav").style.display = "block";
                        document.getElementById("task_ed_timer_icn_nav").style.display = "none";
                    }
                })
                .catch(error => {
                    console.error('Timer sync failed:', error);
                });
        }
    </script>

    {{-- ! Complete Task Data Fetch --}}
    <script>
        function completeTaskDataFetch(id) {
            $.ajax({
                url: `/complete_task_data_fetch/${id}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        $('#range_move_err').text('');
                        var data = response.data;

                        $('#checklist_container').hide();

                        $('#comp_tsk_tsk_name').html(data.task_name);
                        $('#com_tsk_created_staff').html(data.pc_name);
                        $('#com_tsk_tsk_id').html(`# ${data.tsk_id}`);
                        $('#com_tsk_cus_name').html(data.cus_name);
                        $('#com_tsk_cus_id').html(`(${data.cus_id})`);
                        $('#com_tsk_cus_mobile').html(data.cus_mobile);
                        $('#com_task_pro_name').html(data.product_name);
                        $('#com_task_cat_name').html(data.product_category_name);
                        $('#com_tsk_variant_name').html(data.variant_name);
                        $('#com_tsk_variable_name').html(data.variable_name);
                        $('#com_tsk_tsk_desc').html(data.task_desc ? data.task_desc :
                            'No Description is given.');
                        $('#com_tsk_pro_staff_name').html(data.pro_staff_name);
                        $('#com_tsk_pro_nick_name').html(data.pro_nick_name);
                        $('#com_tsk_job_pos').html(data.job_position_name);
                        $('#com_tsk_staff_img').html(response.image);
                        $('#time-logs-container').html(response.html);
                        $('#total_time').html(response.total_time);

                        $('#task_status_id').val(data.sno);
                        $('#checklist_task_id').val(data.task_id);

                        // Get range input and update attributes
                        const rangeInput = document.getElementById('formRangeMax');
                        const currentValueDisplay = document.getElementById('currentValue');
                        const rangeMin = parseInt(data.min_page_or_per) || 0;
                        const rangeMax = parseInt(data.max_page_or_per) || 10;

                        rangeInput.min = rangeMin;
                        rangeInput.max = rangeMax;

                        // Reset value if current is outside new bounds
                        if (parseInt(rangeInput.value) < rangeMin || parseInt(rangeInput.value) > rangeMax) {
                            rangeInput.value = rangeMin;
                        }

                        // Update value display
                        currentValueDisplay.textContent = `${rangeInput.value}`;

                        // Update page labels
                        const rangeLabels = rangeInput.nextElementSibling; // .d-flex container
                        if (rangeLabels) {
                            const spans = rangeLabels.querySelectorAll('span');
                            if (spans.length === 2) {
                                spans[0].textContent =
                                `${rangeMin}${data.task_category == 1 ? ' %' : ' Pages'}`;
                                spans[1].textContent =
                                `${rangeMax}${data.task_category == 1 ? ' %' : ' Pages'}`;
                            }
                        }

                        // Update display on input change
                        rangeInput.addEventListener('input', function() {
                            currentValueDisplay.textContent = `${this.value}`;
                        });
                    }
                },
                error: function(xhr) {
                    console.error(`Error Fetching Data : ${xhr}`);
                }
            });
        }
    </script>

    {{-- ! Checklist Hide & Show --}}
    <script>
        function checklistShow() {
            $('#checklist_container').hide();
            var rangeInput = document.getElementById('formRangeMax');
            var currentValue = parseInt(rangeInput.value);
            var maxValue = parseInt(rangeInput.max);

            if (currentValue === maxValue) {
                fetchTaskCompletedChecklist()
                $('#checklist_container').show();
            }
        }
    </script>

    {{-- ! Update Task Validation --}}
    <script>
        function updateTaskValidation() {
            var rangeInput = document.getElementById('formRangeMax');
            var minValue = parseInt(rangeInput.min);
            var currentValue = parseInt(rangeInput.value);
            var maxValue = parseInt(rangeInput.max);
            $('#range_move_err').text('');

            if (currentValue === minValue) {
                $('#range_move_err').text('Complete at least one full page before providing an update on the task.');
                return false;
            } else {
                var sno = $('#task_status_id').val();

                const formData = {
                    num_pages: currentValue,
                    max_pages: maxValue,
                    status: currentValue === maxValue ? 3 : null
                };

                if (currentValue === maxValue) {
                    var checklistIds = [];
                    $('.task_chk_box:checked').each(function() {
                        checklistIds.push($(this).val());
                    });

                    var taskId = $('#checklist_task_id').val();

                    formData.task_id = taskId;
                    formData.checklist_ids = checklistIds;
                }

                $.ajax({
                    url: `/update_task_status/${sno}`,
                    method: 'POST',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            stoptaskTimer()
                            if (currentValue === maxValue) {
                                toastr.success('Task marked as complete!');
                                location.reload();
                            } else {
                                toastr.success('Task updated successfully!');
                                location.reload();
                            }
                        } else {
                            toastr.error('Task Updation Failed!');
                        }
                    },
                    error: function(err) {
                        console.error('Task Creation Failed');
                    }
                });
            }

            return true;
        }
    </script>

    {{-- ! Task Completed Checklist Data Fetch --}}
    <script>
        function fetchTaskCompletedChecklist() {
            var taskId = $('#checklist_task_id').val();
            $.ajax({
                url: `/fetch_production_checklist/${taskId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var checklists = response.data;
                        var checklistContainer = $('#task_check_fetch_container');
                        checklistContainer.empty();

                        checklists.forEach(check => {
                            checklistContainer.append(
                                `<div class="checklist-item d-flex align-items-center p-3 border-bottom">
                                <div class="form-check mb-0 flex-grow-1">
                                    <input class="form-check-input task_chk_box" type="checkbox" name="task_check_list[]" value="${check.sno}">
                                    <label class="form-check-label text-dark fw-semibold fs-6 ms-2" for="check_1">
                                        ${check.task_checklist}
                                    </label>
                                </div>
                            </div>`
                            );
                        });
                        console.log(checklists);
                    } else {
                        console.error('Task Fetching Failed');
                    }
                },
                error: function(err) {
                    console.error('Task Fetching Failed');
                }
            });
        }
    </script>

@endsection
