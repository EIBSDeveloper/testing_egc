@php
    $helper = new \App\Helpers\Helpers();
    $loginStaff = auth()->user()->user_id;
    $module_name = 'Production Management';
    $menu_name = 'Manage Task';
@endphp
@if (auth()->user()->hasPermission($module_name, 'List', $menu_name))
    @if (isset($lists))
        @foreach ($lists as $i => $list)
            @php
                $rework_color = $list->rework_check > 0 ? 'bg-label-danger' : '';
            @endphp
            <tr class="{{ $rework_color }}">
                <td>
                    @php
                        $percentage = $helper->completed_task_percentage($list->sno);
                    @endphp
                    <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Customer Name">{{ $list->cus_name }}</label>
                    <label class="text-light fw-semibold fs-8 text-wrap d-block" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Customer Id">{{ $list->customer_id }}</label>
                </td>
                <td>
                    <div class="d-flex flex-column">
                        <div class="d-flex align-items-center">
                            <label class="fs-7 text-black fw-semibold text-truncate cursor-pointer"
                                style="max-width: 300px;" data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="{{ $list->product_name }}">{{ $list->product_name }}</label>
                            <label data-bs-toggle="dropdown">
                                <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 cursor-pointer"
                                    title="Product Variant">
                                </span>
                            </label>
                            <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                    <u>Product Variant Info</u>
                                </div>

                                <div class="mb-2">
                                    <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                    <div class="text-black">{{ $list->variant_name }}</div>

                                    <div class="text-dark fw-semibold fs-8 mt-1">Details
                                        Variable:</div>
                                    <div class="text-black">{{ $list->variable_name }}</div>
                                </div>
                            </div>
                        </div>
                        <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="Service ID">{{ $list->formatted_service_id }}</label>
                    </div>
                </td>
                <td>
                    <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip"
                        data-bs-placement="bottom" title="Task Name">{{ $list->task_name }}</label>
                    <label class="text-info fw-semibold fs-8 text-wrap d-block"><span data-bs-toggle="tooltip"
                            data-bs-placement="bottom" title="Task Id">{{ $list->task_id }}</span></label>
                    <div class="progress border border-gray-400i rounded bg-label-primary w-175px h-15px"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Task Progress : {{ $percentage }}%">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-primary fs-8"
                            role="progressbar" style="width: {{ $percentage }}%" aria-valuenow="{{ $percentage }}"
                            aria-valuemin="{{ $percentage }}" aria-valuemax="{{ $percentage }}">
                            {{ $percentage }}%</div>
                    </div>
                </td>
                <td>
                    <div class="d-flex flex-column gap-2 align-items-center avatar-group mb-4">
                        <div class="avatar pull-up border border-gray-700i border-dashed rounded-circle"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="{{ $list->staff_name }}">
                            <img src="{{ asset('staff_images/' . $list->staff_image) }}" alt="Staff"
                                class="rounded-circle">
                        </div>
                        @if ($list->rework_check > 0)
                            <a href="javascript:;" class="badge rework-badge high text-white fs-6 ms-2"
                                data-bs-toggle="modal" data-bs-target="#kt_modal_rework_details"
                                onclick="reworkDetails('{{ $list->sno }}', '{{ $list->staff_id }}')">
                                Rework
                                {{ $list->rework_check < 10 ? str_pad($list->rework_check, 2, '0', STR_PAD_LEFT) : $list->rework_check }}
                            </a>
                        @endif
                    </div>
                </td>
                <td>
                    @php
                        $page_or_per = $list->task_category == 1 ? 'Percentages' : 'Pages';
                    @endphp
                    <label class="bg-danger rounded-2 px-2 py-1 fw-semibold text-white fs-5 me-1"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Total {{ $page_or_per }}">{{ $list->max_page_or_per }}</label>
                    /
                    <label class="bg-success rounded-2 ms-1 px-2 py-1 fw-semibold text-white fs-5 me-1"
                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                        title="Completed {{ $page_or_per }}">{{ $list->min_page_or_per }}</label>
                </td>
                <td>
                    @php
                        $task_pending_or_not = $helper->task_pending_or_not($list->staff_id, $list->sno);
                    @endphp

                    <!-- STATUS CHANGE -->
                    @if (auth()->user()->user_id == $list->staff_id)
                        @if ($list->status < 3)
                            <div class="mb-1 timer_list_div d-flex flex-column align-items-center"
                                id="timer_list_div_id{{ $list->staff_id }}_{{ $list->sno }}">
                                @if ($task_pending_or_not)
                                    {{-- Timer is running: show End Timer --}}
                                    <img src="{{ asset('assets/phdizone_images/header/timer_g1.gif') }}"
                                        alt="Task Running" class="image-input-wrapper w-45px h-45px"
                                        id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}" />
                                    <div class="d-block mt-1">
                                        <a href="javascript:;"
                                            class="btn-end-timer d-inline-flex align-items-center border border-danger rounded-pill text-white fw-semibold fs-7 px-3 py-2 shadow-sm"
                                            id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                            onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}');">
                                            <i class="fas fa-stop-circle me-2 fs-6"></i>
                                            End Timer
                                        </a>
                                    </div>
                                @else
                                    {{-- Timer not running: show Start Timer --}}
                                    <div class="d-block mt-1">
                                        <a href="javascript:;"
                                            class="btn-start-timer d-inline-flex align-items-center border border-success rounded-pill text-white fw-semibold fs-7 px-3 py-2 me-2 shadow-sm"
                                            id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                            onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}');">
                                            <i class="fas fa-play-circle me-2 fs-6"></i>
                                            Start Timer
                                        </a>
                                    </div>
                                @endif
                            </div>
                        @elseif ($list->status <= 3)
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                style="background-color: #008000 !important;">
                                <span>Completed</span>
                            </a>
                        @endif
                    @elseif($list->pc_id == $loginStaff)
                        @if ($list->status < 3)
                            @if ($task_pending_or_not)
                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                    style="background-color: #FF00FF !important;">
                                    <span>Not Yet Started</span>
                                </a>
                            @else
                                <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                    <span>In Progress</span>
                                </a>
                            @endif
                        @elseif ($list->status == 3)
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                style="background-color: #000080 !important;" data-bs-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <span>Waiting For QC Verify</span>
                                <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a href="javascript:;" class="dropdown-item open-action-modal" data-bs-toggle="modal"
                                    onclick="status_change('{{ $list->sno }}')"
                                    data-bs-target="#kt_modal_Task_status_change">
                                    QC Verification
                                </a>
                            </div>
                        @elseif ($list->status == 4)
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                style="background-color: #000080 !important;">
                                <span>QC Verified</span>
                            </a>
                        @endif
                    @else
                        @if ($list->status < 3)
                            @if ($task_pending_or_not)
                                <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                    style="background-color: #FF00FF !important;">
                                    <span>Not Yet Started</span>
                                </a>
                            @else
                                <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                    <span>In Progress</span>
                                </a>
                            @endif
                        @elseif ($list->status == 3)
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                style="background-color: #008000 !important;">
                                <span>Completed</span>
                            </a>
                        @elseif ($list->status == 4)
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                style="background-color: #000080 !important;">
                                <span>QC Verified</span>
                            </a>
                        @endif
                    @endif
                </td>
                <td>
                    <span class="text-center">
                        <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            {{-- <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_history"
                                                            onclick="fetchTaskLog('{{ $list->sno }}', '{{ $list->staff_id }}')">
                                                            <span><i class="mdi mdi-history ms-2 fs-3 fw-bold"></i>Task Log</span>
                                                        </a> --}}
                            @php
                                $currentStatus = '';
                                $currentBg = '';
                                $currenttxcr = '';
                                if ($list->status == 0 || $list->status == 1) {
                                    $currentStatus = 'In Progress';
                                    $currentBg = '#eea810';
                                    $currenttxcr = 'text-white';
                                } elseif ($list->status == 3) {
                                    if ($list->pc_id == $loginStaff) {
                                        $currentStatus = 'Waiting For QC Verify';
                                        $currentBg = '#000080';
                                        $currenttxcr = 'text-white';
                                    } else {
                                        $currentStatus = 'Completed';
                                        $currentBg = '#008000';
                                        $currenttxcr = 'text-white';
                                    }
                                } elseif ($list->status == 4) {
                                    if ($list->cre_id == $loginStaff) {
                                        $currentStatus = 'Waiting For Delivery';
                                        $currentBg = '#008080';
                                        $currenttxcr = 'text-white';
                                    } else {
                                        $currentStatus = 'QC Verified';
                                        $currentBg = '#000080';
                                        $currenttxcr = 'text-white';
                                    }
                                } elseif ($list->status == 5) {
                                    if ($list->cre_id == $loginStaff) {
                                        $currentStatus = 'Delivery Confirmation';
                                        $currentBg = '#800000';
                                        $currenttxcr = 'text-white';
                                    } else {
                                        $currentStatus = 'Delivery Verified';
                                        $currentBg = '#008080';
                                        $currenttxcr = 'text-white';
                                    }
                                } elseif ($list->status == 6) {
                                    $currentStatus = 'Delivered';
                                    $currentBg = '#0000FF';
                                    $currenttxcr = 'text-white';
                                } elseif ($list->status == 7) {
                                    if ($list->cre_id == $loginStaff) {
                                        $currentStatus = 'Rejected';
                                        $currentBg = '#FF00FF';
                                        $currenttxcr = 'text-white';
                                    } else {
                                        $currentStatus = 'Rejected';
                                        $currentBg = '#FF00FF';
                                        $currenttxcr = 'text-white';
                                    }
                                }

                            @endphp
                            @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                    data-bs-target="#kt_modal_view_task"
                                    onclick="view_task({{ $list->sno }},'{{ $currentStatus }}','{{ $currentBg }}','{{ $currenttxcr }}')">
                                    <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                </a>
                            @endif
                        </div>
                    </span>
                </td>
            </tr>
        @endforeach
    @endif
@endif
