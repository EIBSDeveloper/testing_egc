@php
    $helper = new \App\Helpers\Helpers();
    $loginStaff = auth()->user()->user_id;
    $module_name = 'Production Management';
    $menu_name = 'Manage Task';
@endphp
@foreach ($lists as $list)
    @php
    $percentage = $helper->completed_task_percentage($list->sno);
    $page_or_per = $list->task_category == 1 ? 'Percentage' : 'Pages';

    if($list->is_journal == 1) {
        $bg = 'e3f2fd';
    } elseif ($list->is_correction == 1) {
        $bg = 'fff8e1';
    } elseif ($list->rework_check == 1) {
        $bg = 'fbe9e7';
    } else {
        $bg = '';
    }

    @endphp
    <tr style="background: #{{ $bg }};">
        <td>
            <div class="d-flex flex-column">
                @if ($list->is_journal == 1)
                    <?php $taskName = $helper->getJournalTaskName($list->sno); ?>
                    <label class="text-black fs-7 fw-semibold text-truncate" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $taskName->paper_name }}">{{ $taskName->paper_name }} </label>
                    <div class="d-flex gap-1 align-items-center">
                        <label class="text-info fs-8 fw-semibold text-truncate mt-2" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $taskName->journal_id }}">{{ $taskName->journal_id }} </label>
                        @php
                            $rawHours = $list->task_hours;
                            $formattedHours = '0h';

                            if (is_numeric($rawHours)) {
                                $hours = floatval($rawHours);
                                $wholeHours = floor($hours);
                                $minutes = round(($hours - $wholeHours) * 60);

                                if ($wholeHours > 0 && $minutes > 0) {
                                    $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                } elseif ($wholeHours > 0) {
                                    $formattedHours = $wholeHours . 'h';
                                } elseif ($minutes > 0) {
                                    $formattedHours = $minutes . 'm';
                                }
                            }
                        @endphp

                        <label class="text-secondary fs-8 fw-semibold">|</label>
                        <label class="text-danger fs-8 fw-semibold"
                            data-bs-toggle="tooltip"
                            data-bs-placement="bottom"
                            title="Task Hours">
                            <span class="mdi mdi-alarm me-1 fs-6"></span>
                            {{ $formattedHours }}
                        </label>
                    </div>
                @elseif ($list->is_request == 1)
                    <?php $taskName = $helper->getRequestTaskNames($list->sno); ?>
                    <label class="text-black fs-7 fw-semibold text-truncate" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $taskName->request_name }}">{{ $taskName->request_name }} </label>
                    {{-- <div class="d-flex gap-1 align-items-center">
                        <label class="text-info fs-8 fw-semibold text-truncate mt-2" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $taskName->journal_id }}">{{ $taskName->journal_id }} </label>
                        @php
                            $rawHours = $list->task_hours;
                            $formattedHours = '0h';

                            if (is_numeric($rawHours)) {
                                $hours = floatval($rawHours);
                                $wholeHours = floor($hours);
                                $minutes = round(($hours - $wholeHours) * 60);

                                if ($wholeHours > 0 && $minutes > 0) {
                                    $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                } elseif ($wholeHours > 0) {
                                    $formattedHours = $wholeHours . 'h';
                                } elseif ($minutes > 0) {
                                    $formattedHours = $minutes . 'm';
                                }
                            }
                        @endphp

                        <label class="text-secondary fs-8 fw-semibold">|</label>
                        <label class="text-danger fs-8 fw-semibold"
                            data-bs-toggle="tooltip"
                            data-bs-placement="bottom"
                            title="Task Hours">
                            <span class="mdi mdi-alarm me-1 fs-6"></span>
                            {{ $formattedHours }}
                        </label>
                    </div> --}}
                @else
                    <label class="text-black fs-7 fw-semibold text-truncate" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->task_name }}">{{ $list->task_name }} </label>
                    <div class="d-flex gap-1 align-items-center">
                        <label class="text-info fs-8 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task ID">{{ $list->task_id }}</label>
                        @php
                            $rawHours = $list->task_hours;
                            $formattedHours = '0h';

                            if (is_numeric($rawHours)) {
                                $hours = floatval($rawHours);
                                $wholeHours = floor($hours);
                                $minutes = round(($hours - $wholeHours) * 60);

                                if ($wholeHours > 0 && $minutes > 0) {
                                    $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                } elseif ($wholeHours > 0) {
                                    $formattedHours = $wholeHours . 'h';
                                } elseif ($minutes > 0) {
                                    $formattedHours = $minutes . 'm';
                                }
                            }
                        @endphp

                        <label class="text-secondary fs-8 fw-semibold">|</label>
                        <label class="text-danger fs-8 fw-semibold"
                            data-bs-toggle="tooltip"
                            data-bs-placement="bottom"
                            title="Task Hours">
                            <span class="mdi mdi-alarm me-1 fs-6"></span>
                            {{ $formattedHours }}
                        </label>
                    </div>
                @endif
            <hr class="my-1">
            <div class="d-flex flex-column">
                <div class="d-flex gap-1 align-items-center">
                <label class="text-black fw-semibold fs-7">{{ $percentage }}%</label>
                <label class="text-secondary fw-semibold fs-8">Of Task Completed</label>
                </div>
                <div class="progress bg-label-primary rounded" style="width: 100%;">
                <div class="progress-bar-inline" role="progressbar" style="width: {{ $percentage }}%;" aria-valuenow="{{ $percentage }}" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>

            </div>
        </td>
        <td>
            @if($list->is_journal == 1)
            <span class="px-2 py-1" style="border-radius:6px; background:#0d47a1; color:white; font-weight:600; border:1px solid #0d47a1;">Journal</span>
            @elseif ($list->is_correction == 1)
            <span class="px-2 py-1" style="border-radius:6px; background:#ff6f00; color:white; font-weight:600; border:1px solid #ff6f00;">Correction</span>
            @elseif ($list->rework_check == 1)
            <span class="px-2 py-1" style="border-radius:6px; background:#d84315; color:white; font-weight:600; border:1px solid #d84315;">Rework</span>
            @elseif ($list->is_request == 1)
            <span class="px-2 py-1" style="border-radius:6px; background:#6f09f3; color:white; font-weight:600; border:1px solid #6f09f3;">Request</span>
            @else
            <span class="px-2 py-1" style="border-radius:6px; background:#333; color:white; font-weight:600; border:1px solid #333;">Task</span>
            @endif
        </td>
        <td>
            <div class="d-flex flex-column">
            <label class="fs-7 text-black fw-semibold text-truncate "  style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_name }}">{{ $list->product_name }} </label>
            <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service ID">{{ $list->formatted_service_id }}</label>
            <div class="d-flex align-items-center gap-1">
                <label class="text-secondary  fw-semibold fs-8 text-truncate" style="max-width:150px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->product_category_name }}">{{ $list->product_category_name }}</label>
                <label data-bs-toggle="dropdown">
                <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 "
                    title="Product Variant">
                </span>
            </label>
            <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                    <u>Product Variant Info</u>
                </div>

                <div class="mb-2">
                    <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                    <div class="text-black">{{ $list->variant_name }}</div>

                    <div class="text-dark fw-semibold fs-8 mt-1">Variable Name:</div>
                    <div class="text-black">{{ $list->variable_name }}</div>
                </div>

            </div>
            </div>

            </div>
        </td>
        <td>
            @if ($isStaffs == 1 || $isStaffs == 2)
            <div class="d-flex flex-column">
                <label class="fw-bold fs-7 text-info">{{ $list->customer_id }}</label>
            </div>
            @else
            <div class="d-flex flex-column">
                <label class="fw-semibold fs-7 text-black text-truncate "  style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                <label class="fw-semibold fs-8 text-info">{{ $list->customer_id }}</label>
                <label class="fw-semibold fs-8 text-secondary">{{ $list->cus_mobile ?? $list->cus_email_id }}</label>
            </div>
            @endif
        </td>
        @if($isStaffs != 2)
            <td>
                @if ($list->staff_image !== null)
                <div class="d-flex flex-column gap-1">
                    <div class="d-flex gap-2 align-items-center">
                        @if ($list->staff_image != '' && file_exists(public_path('staff_images/' . $list->staff_image)))
                            <div class="symbol symbol-35px me-2">
                                <div class="image-input image-input-circle"
                                    data-kt-image-input="true">
                                    <img src="{{ asset('staff_images/' . $list->staff_image) }}"
                                        alt="user-avatar"
                                        class="rounded-circle image-input-wrapper w-45px h-45px"
                                        id="uploadedlogo" />
                                </div>
                            </div>
                        @else
                            <div class="symbol symbol-35px me-2">
                                @php
                                    $initial = strtoupper(substr($list->staff_name, 0, 1));
                                    echo $helper->name_image(
                                        $initial,
                                        $list->gender ?? 'Male',
                                    );
                                @endphp
                            </div>
                        @endif
                        <div class="d-flex flex-column justify-content-center">
                            <label
                                class="fw-semibold fs-7 text-black mb-0">{{ $list->staff_name }}</label>
                            <label
                                class="fw-semibold fs-7 text-secondary mb-0">{{ $list->job_position_name }}</label>
                        </div>
                    </div>
                </div>
                @else
                    <div class="d-flex flex-column gap-1">
                        <div class="d-flex gap-2 align-items-center">
                            <div class="profile-avatar bg-light text-muted border"
                                data-bs-toggle="tooltip" title="No Staff">
                                <i class="mdi mdi-account-off fs-5"></i>
                            </div>
                            <label class="fw-semibold fs-8 text-dark mb-0">Staff Not
                                Assigned</label>
                        </div>
                    </div>
                @endif
            </td>
        @endif
        <td align="center">
            @if($list->is_journal != 1 && $list->is_request != 1)
                <div class="d-flex gap-1 align-items-center">
                    <span class="badge p-2 fw-semibold fs-4 pull-up d-flex align-items-center justify-content-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Allocated {{ $page_or_per }}"
                    style="background:#2196f3; color:#fff; border-radius:50px; width:40px; height:40px;">{{ str_pad($list->max_page_or_per, 2, '0', STR_PAD_LEFT) }}
                    </span>
                    <label>|</label>
                    <span class="badge p-2 fw-semibold fs-4 pull-up d-flex align-items-center justify-content-center" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Completed {{ $page_or_per }}"
                        style="background:#4b6d41; color:#fff; border-radius:50px; width:40px; height:40px;">{{ str_pad($list->min_page_or_per, 2, '0', STR_PAD_LEFT) }}
                    </span>
                </div>
            @else
                <div class="text-center">-</div>
            @endif
        </td>
        <td>
            @php
                $task_pending_or_not = $helper->task_pending_or_not(
                    $list->staff_id,
                    $list->sno,
                );
            @endphp

            <!-- Journal Task -->
            @if($list->is_journal == 1)

                <!-- Production Staff -->
                @if($isStaffs == 2)

                    @if($list->status < 3)
                        <div class="d-flex flex-column gap-1 align-items-start justify-content-start">

                        @if ($task_pending_or_not)
                            <img
                                id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}', true);"
                                src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                class="rounded-circle img-fluid"
                                style="width:60px;height:60px;object-fit:cover;" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Click To End Timer"
                            >

                        @else
                            <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}" class="clock-icon cursor-pointer">
                                <span class="mdi mdi-alarm fs-2"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                    onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}', true);"
                                    title="Click To Start Timer"></span>
                            </i>
                        @endif

                        </div>

                    @elseif($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_file_upload" onclick="journalUploadDataFetch('{{ $list->sno }}')">
                            <span>Attach Documents</span>
                            <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>
                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif

                <!-- PC -->
                @elseif($isStaffs == 1)

                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Waiting For Documents</span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif

                <!-- Other Staffs -->
                @else

                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                            <span>Waiting For Documents</span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif
                @endif

            <!-- Request Task -->
            @elseif($list->is_request == 1)

                <!-- Production Staff -->
                @if($isStaffs == 2)

                    @if($list->status < 3)
                        <div class="d-flex flex-column gap-1 align-items-start justify-content-start">

                        @if ($task_pending_or_not)
                            <img
                                id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}', false, true);"
                                src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                class="rounded-circle img-fluid"
                                style="width:60px;height:60px;object-fit:cover;" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Click To End Timer"
                            >

                        @else
                            <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}" class="clock-icon cursor-pointer">
                                <span class="mdi mdi-alarm fs-2"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                    onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}', false, true);"
                                    title="Click To Start Timer"></span>
                            </i>
                        @endif

                        </div>

                    @elseif($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_file_upload" onclick="journalUploadDataFetch('{{ $list->sno }}', 1)">
                            <span>Attach Documents</span>
                            <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>
                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif

                <!-- PC -->
                @elseif($isStaffs == 1)

                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Waiting For Documents</span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif

                <!-- Other Staffs -->
                @else

                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                            <span>Waiting For Documents</span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #104b01 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #db1515 !important;">
                            <span>Rework</span>
                        </a>
                    @endif
                @endif

            <!-- Normal Task -->
            @else

                <!-- Production Staffs -->
                @if($isStaffs == 2)

                    @if($list->status < 3)
                        <div class="d-flex flex-column gap-1 align-items-start justify-content-start">

                        @if ($task_pending_or_not)
                            <img
                                id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}');"
                                src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                class="rounded-circle img-fluid"
                                style="width:60px;height:60px;object-fit:cover;" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Click To End Timer"
                            >
                        @else
                            <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}" class="clock-icon cursor-pointer">
                                <span class="mdi mdi-alarm fs-2"
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                    onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}');"
                                    title="Click To Start Timer"></span>
                            </i>
                        @endif

                        </div>

                    @elseif($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #d84315 !important;">
                            <span>Rework</span>
                        </a>

                    @elseif ($list->status == 6)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #ff6f00 !important;">
                            <span>Correction</span>
                        </a>

                    @else
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                            <span>Completed</span>
                        </a>
                    @endif

                <!-- PC -->
                @elseif($isStaffs == 1)

                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Completed</span>
                            <span class="ms-2"><i class="mdi mdi-menu-down text-white"></i></span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <a href="javascript:;" class="dropdown-item open-action-modal" data-bs-toggle="modal" onclick="status_change('{{ $list->sno }}')"
                                data-bs-target="#kt_modal_qc_status_change">
                                QC Verification
                            </a>
                        </div>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #d84315 !important;">
                            <span>Rework</span>
                        </a>

                    @elseif ($list->status == 6)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #ff6f00 !important;">
                            <span>Correction</span>
                        </a>
                    @else
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #000080 !important;">
                            <span>QC Verified</span>
                        </a>
                    @endif

                <!-- Other Staffs -->
                @else
                    @if($list->status < 3)

                        @if ($task_pending_or_not)
                            <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                <span>In Progress</span>
                            </a>
                        @else
                            <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #cf3c3cf5 !important;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span>Not Yet Started</span>
                            </a>
                        @endif

                    @elseif ($list->status == 3)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #008000 !important;">
                            <span>Completed</span>
                        </a>

                    @elseif ($list->status == 4)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #000080 !important;">
                            <span>QC Verified</span>
                        </a>

                    @elseif ($list->status == 5)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #d84315 !important;">
                            <span>Rework</span>
                        </a>

                    @elseif ($list->status == 6)
                        <a href="javascript:;" class="badge bg-info text-white mb-1 fs-7 fw-semibold" style="background-color: #ff6f00 !important;">
                            <span>Correction</span>
                        </a>
                    @endif
                @endif
            @endif
        </td>
        @if (auth()->user()->user_id < 2)
            <td>
                @if ($task_pending_or_not)
                    <img
                        src="{{ asset('assets/phdizone_images/CEOTimer.gif') }}"
                        class="rounded-circle img-fluid"
                        style="width:60px;height:60px;object-fit:cover;" data-bs-toggle="tooltip"
                            data-bs-placement="bottom"
                    >
                @endif
            </td>
        @endif
        <td>
            <span class="text-center">
                <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <i class="mdi mdi-dots-vertical fs-3 text-black mb-2"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    @php
                        $currentStatus = '';
                        $currentBg = '';
                        $currenttxcr = '';

                        if ($list->is_journal == 1) {

                            if($list->status < 3) {

                                if($task_pending_or_not) {
                                    $currentStatus = 'In Progress';
                                    $currentBg = '#ffc700';
                                    $currenttxcr = 'text-black';
                                } else {
                                    $currentStatus = 'Not Yet Started';
                                    $currentBg = '#d04343';
                                    $currenttxcr = 'text-white';
                                }
                            } else if ($list->status == 3) {
                                $currentStatus = 'Waiting For Documents';
                                $currentBg = '#50cd89';
                                $currenttxcr = 'text-white';
                            } else if ($list->status == 4) {
                                $currentStatus = 'Completed';
                                $currentBg = '#104b01';
                                $currenttxcr = 'text-white';
                            } else if ($list->status == 5) {
                                $currentStatus = 'Rework';
                                $currentBg = '#d84315';
                                $currenttxcr = 'text-white';
                            }
                        } else {
                            if($list->status < 3) {

                                if($task_pending_or_not) {
                                    $currentStatus = 'In Progress';
                                    $currentBg = '#ffc700';
                                    $currenttxcr = 'text-black';
                                } else {
                                    $currentStatus = 'Not Yet Started';
                                    $currentBg = '#d04343';
                                    $currenttxcr = 'text-white';
                                }
                            } else if ($list->status == 3) {
                                $currentStatus = 'Completed';
                                $currentBg = '#50cd89';
                                $currenttxcr = 'text-white';
                            } else if ($list->status == 4) {
                                $currentStatus = 'QC Verified';
                                $currentBg = '#000080';
                                $currenttxcr = 'text-white';
                            } else if ($list->status == 5) {
                                $currentStatus = 'Rework';
                                $currentBg = '#d84315';
                                $currenttxcr = 'text-white';
                            } else if ($list->status == 6) {
                                $currentStatus = 'Correction';
                                $currentBg = '#ff6f00';
                                $currenttxcr = 'text-white';
                            }
                        }
                    @endphp
                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                            data-bs-target="#kt_modal_view_task"
                            onclick="view_task({{ $list->sno }},'{{ $currentStatus }}','{{ $currentBg }}','{{ $currenttxcr }}')">
                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                        </a>
                    @endif
                </div>
            </span>
        </td>
    </tr>
@endforeach
