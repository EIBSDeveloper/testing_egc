@extends('layouts/layoutMaster')

@section('title', 'Manage Task')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/nouislider/nouislider.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/nouislider/nouislider.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/sliders.js')
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .list_page thead th,
        .list_page tbody td {
            padding: 10px !important;
        }

        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }
    </style>

    <style>
        .task-view-container {
            font-family: 'Inter', sans-serif;
        }

        .task-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        .staff-avatar {
            width: 80px;
            height: 80px;
            border: 3px solid #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .staff-avatar-placeholder {
            width: 80px;
            height: 80px;
            margin: 0 auto;
            font-size: 1.5rem;
        }

        .checklist-item {
            transition: all 0.3s ease;
            border-radius: 8px;
        }

        .checklist-item:hover {
            background-color: #f8f9fa;
            transform: translateX(5px);
        }

        .form-check-input:checked {
            background-color: #198754;
            border-color: #198754;
        }

        .detail-item {
            padding: 8px 0;
        }

        .task-description {
            border-left: 4px solid #667eea;
        }

        .log-item {
            transition: all 0.2s ease;
        }

        .log-item:hover {
            background-color: #f8f9fa;
            border-radius: 6px;
            padding-left: 8px;
            padding-right: 8px;
        }

        .stat-item {
            padding: 10px;
        }

        .progress {
            border-radius: 10px;
        }

        .progress-bar-inline {
            border-radius: 10px;
            background: #099dda;
        }

        .card {
            border-radius: 12px;
        }

        .time-details {
            border: 1px solid #e9ecef;
        }
    </style>
    <style>
        .dropdown:hover>.dropdown-menu {
            display: block;
            margin-top: 0;
        }
    </style>

    @php
        $helper = new \App\Helpers\Helpers();
        $module_name = 'Production Management';
        $menu_name = 'Manage Task';
    @endphp

    <!-- Task List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Task</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap gap-2">
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #fff8e1 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Correction</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #fbe9e7 !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Rework</label>
                    </div>
                    <div class="d-flex align-items-center px-1 py-1">
                        <label class="bg-danger rounded border border-dark w-25px h-25px me-1"
                            style="background-color: #e3f2fd !important;"> </label>
                        <label class="fs-7 fw-semibold text-black">Journal</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12 d-flex gap-2  align-items-center mb-3 justify-content-between">
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #c41b1b;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#fdd2d2;">
                            <i class="mdi mdi-alpha-x-circle" style="color:#c41b1b; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#c41b1b; font-size:13px;">Not Yet Started</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $notYetStartedCount == 0 ? 0 : str_pad($notYetStartedCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #C47A1B;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#FDEBD2;">
                            <i class="mdi mdi-clock-time-five" style="color:#C47A1B; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#C47A1B; font-size:13px;">In Progress</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $inProgressCount == 0 ? 0 : str_pad($inProgressCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #496628;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#deeedb;">
                            <i class="mdi mdi-check-circle" style="color:#496628; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#496628; font-size:13px;">Completed</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $completedCount == 0 ? 0 : str_pad($completedCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    @if ($isStaffs != 2)
                        <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #1b26c4;">
                            <div class="d-flex align-items-center justify-content-center rounded-circle"
                                style="width:42px; height:42px; background:#d3d2fd;">
                                <i class="mdi mdi-check-decagram" style="color:#1b26c4; font-size:20px;"></i>
                            </div>
                            <div class="d-flex flex-column ms-3">
                                <span class="fw-semibold" style="color:#1b26c4; font-size:13px;">QC Verified</span>
                                <span
                                    class="fw-bold text-dark fs-5">{{ $qcVerifiedCount == 0 ? 0 : str_pad($qcVerifiedCount, 2, '0', STR_PAD_LEFT) }}</span>
                            </div>
                        </div>
                    @endif
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #424242;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#f5f5f5;">
                            <i class="mdi mdi-book-clock" style="color:#424242; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#424242; font-size:13px;">Tasks</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $total_tasks == 0 ? 0 : str_pad($total_tasks, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #ff6f00;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#fff8e1;">
                            <i class="mdi mdi-pencil-circle" style="color:#ff6f00; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#ff6f00; font-size:13px;">Correction</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $correctionCount == 0 ? 0 : str_pad($correctionCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #d84315;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#fbe9e7;">
                            <i class="mdi mdi-clock-edit" style="color:#d84315; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#d84315; font-size:13px;">Rework</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $reworkCount == 0 ? 0 : str_pad($reworkCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center p-3 rounded flex-shrink-0" style="border:1px solid #0d47a1;">
                        <div class="d-flex align-items-center justify-content-center rounded-circle"
                            style="width:42px; height:42px; background:#e3f2fd;">
                            <i class="mdi mdi-book-edit" style="color:#0d47a1; font-size:20px;"></i>
                        </div>
                        <div class="d-flex flex-column ms-3">
                            <span class="fw-semibold" style="color:#0d47a1; font-size:13px;">Journal</span>
                            <span
                                class="fw-bold text-dark fs-5">{{ $journalCount == 0 ? 0 : str_pad($journalCount, 2, '0', STR_PAD_LEFT) }}</span>
                        </div>
                    </div>

                </div>
                <div class="col-lg-12">
                    <table class="table align-middel table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-125px">Task</th>
                                <th class="min-w-100px">From</th>
                                <th class="min-w-125px">Service / Category</th>
                                <th class="min-w-80px">Customer</th>
                                @if ($isStaffs != 2)
                                    <th class="min-w-150px">Assigned To</th>
                                @endif
                                <th class="min-w-80px">Pages / Percentage</th>
                                <th class="min-w-100px">Status</th>
                                @if (auth()->user()->user_id < 2)
                                    <th class="min-w-50px">Timer</th>
                                @endif
                                <th class="min-w-50px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7" id="task_table_body">
                            @foreach ($lists as $list)
                                @php
                                    $percentage = $helper->completed_task_percentage($list->sno);
                                    $page_or_per = $list->task_category == 1 ? 'Percentage' : 'Pages';

                                    if ($list->is_journal == 1) {
                                        $bg = 'e3f2fd';
                                    } elseif ($list->is_correction == 1) {
                                        $bg = 'fff8e1';
                                    } elseif ($list->rework_check == 1) {
                                        $bg = 'fbe9e7';
                                    } else {
                                        $bg = '';
                                    }

                                    $current_date = date('Y-m-d');
                                    $task_date = $list->task_date;
                                @endphp
                                <tr style="background: #{{ $bg }};">
                                    <td>
                                        <div class="d-flex flex-column">
                                            @if ($list->is_journal == 1)
                                                <?php $taskName = $helper->getJournalTaskName($list->sno); ?>
                                                <label class="text-black fs-7 fw-semibold text-truncate"
                                                    style="max-width: 200px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $taskName->paper_name }}">{{ $taskName->paper_name }}
                                                </label>
                                                <div class="d-flex gap-1 align-items-center">
                                                    <label class="text-info fs-8 fw-semibold text-truncate mt-2"
                                                        style="max-width: 200px;" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="{{ $taskName->journal_id }}">{{ $taskName->journal_id }}
                                                    </label>
                                                    @php
                                                        $rawHours = $list->task_hours;
                                                        $formattedHours = '0h';

                                                        if (is_numeric($rawHours)) {
                                                            $hours = floatval($rawHours);
                                                            $wholeHours = floor($hours);
                                                            $minutes = round(($hours - $wholeHours) * 60);

                                                            if ($wholeHours > 0 && $minutes > 0) {
                                                                $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                                            } elseif ($wholeHours > 0) {
                                                                $formattedHours = $wholeHours . 'h';
                                                            } elseif ($minutes > 0) {
                                                                $formattedHours = $minutes . 'm';
                                                            }
                                                        }
                                                    @endphp

                                                    <label class="text-secondary fs-8 fw-semibold">|</label>
                                                    <label class="text-danger fs-8 fw-semibold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Task Hours">
                                                        <span class="mdi mdi-alarm me-1 fs-6"></span>
                                                        {{ $formattedHours }}
                                                    </label>
                                                </div>
                                            @elseif ($list->is_request == 1)
                                                <?php $taskName = $helper->getRequestTaskNames($list->sno); ?>
                                                <label class="text-black fs-7 fw-semibold text-truncate"
                                                    style="max-width: 200px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $taskName->request_name }}">{{ $taskName->request_name }}
                                                </label>
                                                {{-- <div class="d-flex gap-1 align-items-center">
                                                <label class="text-info fs-8 fw-semibold text-truncate mt-2" style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $taskName->journal_id }}">{{ $taskName->journal_id }} </label>
                                                @php
                                                    $rawHours = $list->task_hours;
                                                    $formattedHours = '0h';

                                                    if (is_numeric($rawHours)) {
                                                        $hours = floatval($rawHours);
                                                        $wholeHours = floor($hours);
                                                        $minutes = round(($hours - $wholeHours) * 60);

                                                        if ($wholeHours > 0 && $minutes > 0) {
                                                            $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                                        } elseif ($wholeHours > 0) {
                                                            $formattedHours = $wholeHours . 'h';
                                                        } elseif ($minutes > 0) {
                                                            $formattedHours = $minutes . 'm';
                                                        }
                                                    }
                                                @endphp

                                                <label class="text-secondary fs-8 fw-semibold">|</label>
                                                <label class="text-danger fs-8 fw-semibold"
                                                    data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="Task Hours">
                                                    <span class="mdi mdi-alarm me-1 fs-6"></span>
                                                    {{ $formattedHours }}
                                                </label>
                                            </div> --}}
                                            @else
                                                <label class="text-black fs-7 fw-semibold text-truncate"
                                                    style="max-width: 200px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $list->task_name }}">{{ $list->task_name }} </label>
                                                <div class="d-flex gap-1 align-items-center">
                                                    <label class="text-info fs-8 fw-semibold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom"
                                                        title="Task ID">{{ $list->task_id }}</label>
                                                    @php
                                                        $rawHours = $list->task_hours;
                                                        $formattedHours = '0h';

                                                        if (is_numeric($rawHours)) {
                                                            $hours = floatval($rawHours);
                                                            $wholeHours = floor($hours);
                                                            $minutes = round(($hours - $wholeHours) * 60);

                                                            if ($wholeHours > 0 && $minutes > 0) {
                                                                $formattedHours = $wholeHours . 'h ' . $minutes . 'm';
                                                            } elseif ($wholeHours > 0) {
                                                                $formattedHours = $wholeHours . 'h';
                                                            } elseif ($minutes > 0) {
                                                                $formattedHours = $minutes . 'm';
                                                            }
                                                        }
                                                    @endphp

                                                    <label class="text-secondary fs-8 fw-semibold">|</label>
                                                    <label class="text-danger fs-8 fw-semibold" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Task Hours">
                                                        <span class="mdi mdi-alarm me-1 fs-6"></span>
                                                        {{ $formattedHours }}
                                                    </label>
                                                </div>
                                            @endif
                                            <hr class="my-1">
                                            <div class="d-flex flex-column">
                                                <div class="d-flex gap-1 align-items-center">
                                                    <label
                                                        class="text-black fw-semibold fs-7">{{ $percentage }}%</label>
                                                    <label class="text-secondary fw-semibold fs-8">Of Task
                                                        Completed</label>
                                                </div>
                                                <div class="progress bg-label-primary rounded" style="width: 100%;">
                                                    <div class="progress-bar-inline" role="progressbar"
                                                        style="width: {{ $percentage }}%;"
                                                        aria-valuenow="{{ $percentage }}" aria-valuemin="0"
                                                        aria-valuemax="100"></div>
                                                </div>
                                            </div>

                                        </div>
                                    </td>
                                    <td>
                                       
                                        @php
                                            $hidetimer = 0;
                                        @endphp
                                        @if ($list->is_journal == 1)
                                            <span class="px-2 py-1"
                                                style="border-radius:6px; background:#0d47a1; color:white; font-weight:600; border:1px solid #0d47a1;">Journal</span>
                                                @php
                                                    $hidetimer = 1;
                                                @endphp

                                        @elseif ($list->is_correction == 1)
                                            <span class="px-2 py-1"
                                                style="border-radius:6px; background:#ff6f00; color:white; font-weight:600; border:1px solid #ff6f00;">Correction</span>
                                                @php
                                                    $hidetimer = 1;
                                                @endphp

                                        @elseif ($list->rework_check == 1)
                                            <span class="px-2 py-1"
                                                style="border-radius:6px; background:#d84315; color:white; font-weight:600; border:1px solid #d84315;">Rework</span>
                                                @php
                                                    $hidetimer = 1;
                                                @endphp

                                        @elseif ($list->is_request == 1)
                                            <span class="px-2 py-1"
                                                style="border-radius:6px; background:#6f09f3; color:white; font-weight:600; border:1px solid #6f09f3;">Request</span>
                                                @php
                                                    $hidetimer = 1;
                                                @endphp

                                        @else
                                            <span class="px-2 py-1"
                                                style="border-radius:6px; background:#333; color:white; font-weight:600; border:1px solid #333;">Task</span>
                                                @php
                                                if ($task_date <= $current_date){
                                                    $hidetimer = 1;
                                                }
                                                @endphp
                                        @endif
                                        <div class="d-block">
                                            <label
                                                class="text-info fw-bold mt-2">{{ $list->task_date ? date('d-M-Y', strtotime($list->task_date)) : '' }}</label>
                                        </div>

                                    </td>
                                    <td>
                                        <div class="d-flex flex-column">
                                            <label class="fs-7 text-black fw-semibold text-truncate "
                                                style="max-width: 200px;" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="{{ $list->product_name }}">{{ $list->product_name }} </label>
                                            <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Service ID">{{ $list->formatted_service_id }}</label>
                                            <div class="d-flex align-items-center gap-1">
                                                <label class="text-secondary  fw-semibold fs-8 text-truncate"
                                                    style="max-width:150px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $list->product_category_name }}">{{ $list->product_category_name }}</label>
                                                <label data-bs-toggle="dropdown">
                                                    <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-1 "
                                                        title="Product Variant">
                                                    </span>
                                                </label>
                                                <div class="dropdown-menu dropdown-menu-start w-250px p-2">
                                                    <div class="text-black text-center fw-semibold fs-7 mb-2 ps-4">
                                                        <u>Product Variant Info</u>
                                                    </div>

                                                    <div class="mb-2">
                                                        <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                                        <div class="text-black">{{ $list->variant_name }}</div>

                                                        <div class="text-dark fw-semibold fs-8 mt-1">Variable Name:</div>
                                                        <div class="text-black">{{ $list->variable_name }}</div>
                                                    </div>

                                                </div>
                                            </div>

                                        </div>
                                    </td>
                                    <td>
                                        @if ($isStaffs == 1 || $isStaffs == 2)
                                            <div class="d-flex flex-column">
                                                <label class="fw-bold fs-7 text-info">{{ $list->customer_id }}</label>
                                            </div>
                                        @else
                                            <div class="d-flex flex-column">
                                                <label class="fw-semibold fs-7 text-black text-truncate "
                                                    style="max-width: 200px;" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{ $list->cus_name }}">{{ $list->cus_name }}</label>
                                                <label class="fw-semibold fs-8 text-info">{{ $list->customer_id }}</label>
                                                <label
                                                    class="fw-semibold fs-8 text-secondary">{{ $list->cus_mobile ?? $list->cus_email_id }}</label>
                                            </div>
                                        @endif
                                    </td>
                                    @if ($isStaffs != 2)
                                        <td>
                                            @if ($list->staff_image !== null)
                                                <div class="d-flex flex-column gap-1">
                                                    <div class="d-flex gap-2 align-items-center">
                                                        @if ($list->staff_image != '' && file_exists(public_path('staff_images/' . $list->staff_image)))
                                                            <div class="symbol symbol-35px me-2">
                                                                <div class="image-input image-input-circle"
                                                                    data-kt-image-input="true">
                                                                    <img src="{{ asset('staff_images/' . $list->staff_image) }}"
                                                                        alt="user-avatar"
                                                                        class="rounded-circle image-input-wrapper w-45px h-45px"
                                                                        id="uploadedlogo" />
                                                                </div>
                                                            </div>
                                                        @else
                                                            <div class="symbol symbol-35px me-2">
                                                                @php
                                                                    $initial = strtoupper(
                                                                        substr($list->staff_name, 0, 1),
                                                                    );
                                                                    echo $helper->name_image(
                                                                        $initial,
                                                                        $list->gender ?? 'Male',
                                                                    );
                                                                @endphp
                                                            </div>
                                                        @endif
                                                        <div class="d-flex flex-column justify-content-center">
                                                            <label
                                                                class="fw-semibold fs-7 text-black mb-0">{{ $list->staff_name }}</label>
                                                            <label
                                                                class="fw-semibold fs-7 text-secondary mb-0">{{ $list->job_position_name }}</label>
                                                        </div>
                                                    </div>
                                                </div>
                                            @else
                                                <div class="d-flex flex-column gap-1">
                                                    <div class="d-flex gap-2 align-items-center">
                                                        <div class="profile-avatar bg-light text-muted border"
                                                            data-bs-toggle="tooltip" title="No Staff">
                                                            <i class="mdi mdi-account-off fs-5"></i>
                                                        </div>
                                                        <label class="fw-semibold fs-8 text-dark mb-0">Staff Not
                                                            Assigned</label>
                                                    </div>
                                                </div>
                                            @endif
                                        </td>
                                    @endif
                                    <td align="center">
                                        @if ($list->is_journal != 1 && $list->is_request != 1)
                                            <div class="d-flex gap-1 align-items-center">
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 pull-up d-flex align-items-center justify-content-center"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Allocated {{ $page_or_per }}"
                                                    style="background:#2196f3; color:#fff; border-radius:50px; width:40px; height:40px;">{{ str_pad($list->max_page_or_per, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                                <label>|</label>
                                                <span
                                                    class="badge p-2 fw-semibold fs-4 pull-up d-flex align-items-center justify-content-center"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Completed {{ $page_or_per }}"
                                                    style="background:#4b6d41; color:#fff; border-radius:50px; width:40px; height:40px;">{{ str_pad($list->min_page_or_per, 2, '0', STR_PAD_LEFT) }}
                                                </span>
                                            </div>
                                        @else
                                            <div class="text-center">-</div>
                                        @endif
                                    </td>
                                    <td>
                                        @php
                                            $task_pending_or_not = $helper->task_pending_or_not(
                                                $list->staff_id,
                                                $list->sno,
                                            );
                                        @endphp

                                        <!-- Journal Task -->
                                        @if ($list->is_journal == 1)

                                            <!-- Production Staff -->
                                            @if ($isStaffs == 2)
                                                @if ($list->status < 3)
                                                    @if ($hidetimer)
                                                        <div
                                                            class="d-flex flex-column gap-1 align-items-start justify-content-start">

                                                            @if ($task_pending_or_not)
                                                                <img id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}', true);"
                                                                    src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                                                    class="rounded-circle img-fluid"
                                                                    style="width:60px;height:60px;object-fit:cover;"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Click To End Timer">
                                                            @else
                                                                <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    class="clock-icon cursor-pointer">
                                                                    <span class="mdi mdi-alarm fs-2"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                        onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}', true);"
                                                                        title="Click To Start Timer"></span>
                                                                </i>
                                                            @endif

                                                        </div>
                                                    @else
                                                        -
                                                    @endif
                                                @elseif($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;"
                                                        data-bs-toggle="modal" data-bs-target="#kt_modal_file_upload"
                                                        onclick="journalUploadDataFetch('{{ $list->sno }}')">
                                                        <span>Attach Documents</span>
                                                        <span class="ms-2"><i
                                                                class="mdi mdi-menu-down text-white"></i></span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif

                                                <!-- PC -->
                                            @elseif($isStaffs == 1)
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;"
                                                        data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <span>Waiting For Documents</span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif

                                                <!-- Other Staffs -->
                                            @else
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;">
                                                        <span>Waiting For Documents</span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif
                                            @endif

                                            <!-- Request Task -->
                                        @elseif($list->is_request == 1)
                                            <!-- Production Staff -->
                                            @if ($isStaffs == 2)
                                                @if ($list->status < 3)
                                                    @if ($hidetimer)
                                                        <div
                                                            class="d-flex flex-column gap-1 align-items-start justify-content-start">

                                                            @if ($task_pending_or_not)
                                                                <img id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}', false, true);"
                                                                    src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                                                    class="rounded-circle img-fluid"
                                                                    style="width:60px;height:60px;object-fit:cover;"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Click To End Timer">
                                                            @else
                                                                <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    class="clock-icon cursor-pointer">
                                                                    <span class="mdi mdi-alarm fs-2"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                        onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}', false, true);"
                                                                        title="Click To Start Timer"></span>
                                                                </i>
                                                            @endif

                                                        </div>
                                                    @else
                                                        -
                                                    @endif
                                                @elseif($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;"
                                                        data-bs-toggle="modal" data-bs-target="#kt_modal_file_upload"
                                                        onclick="journalUploadDataFetch('{{ $list->sno }}', 1)">
                                                        <span>Attach Documents</span>
                                                        <span class="ms-2"><i
                                                                class="mdi mdi-menu-down text-white"></i></span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif

                                                <!-- PC -->
                                            @elseif($isStaffs == 1)
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;"
                                                        data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <span>Waiting For Documents</span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif

                                                <!-- Other Staffs -->
                                            @else
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;">
                                                        <span>Waiting For Documents</span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #104b01 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #db1515 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @endif
                                            @endif

                                            <!-- Normal Task -->
                                        @else
                                            <!-- Production Staffs -->
                                            @if ($isStaffs == 2)
                                                @if ($list->status < 3) 
                                                    @if ($hidetimer)
                                                        <div
                                                            class="d-flex flex-column gap-1 align-items-start justify-content-start">

                                                            @if ($task_pending_or_not)
                                                                <img id="task_end_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    onclick="task_timer_func('end_timer','{{ $list->staff_id }}','{{ $list->sno }}');"
                                                                    src="{{ asset('assets/phdizone_images/Countdown.gif') }}"
                                                                    class="rounded-circle img-fluid"
                                                                    style="width:60px;height:60px;object-fit:cover;"
                                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                    title="Click To End Timer">
                                                            @else
                                                                <i id="task_timer_icon_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                    class="clock-icon cursor-pointer">
                                                                    <span class="mdi mdi-alarm fs-2"
                                                                        data-bs-toggle="tooltip"
                                                                        data-bs-placement="bottom"
                                                                        id="task_st_timer_list{{ $list->staff_id }}_{{ $list->sno }}"
                                                                        onclick="task_timer_func('start_timer','{{ $list->staff_id }}','{{ $list->sno }}');"
                                                                        title="Click To Start Timer"></span>
                                                                </i>
                                                            @endif

                                                        </div>
                                                    @else
                                                        -
                                                    @endif
                                                @elseif($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #d84315 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @elseif ($list->status == 6)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #ff6f00 !important;">
                                                        <span>Correction</span>
                                                    </a>
                                                @else
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @endif

                                                <!-- PC -->
                                            @elseif($isStaffs == 1)
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;"
                                                        data-bs-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        <span>Completed</span>
                                                        <span class="ms-2"><i
                                                                class="mdi mdi-menu-down text-white"></i></span>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-end">
                                                        <a href="javascript:;" class="dropdown-item open-action-modal"
                                                            data-bs-toggle="modal"
                                                            onclick="status_change('{{ $list->sno }}')"
                                                            data-bs-target="#kt_modal_qc_status_change">
                                                            QC Verification
                                                        </a>
                                                    </div>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #d84315 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @elseif ($list->status == 6)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #ff6f00 !important;">
                                                        <span>Correction</span>
                                                    </a>
                                                @else
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #000080 !important;">
                                                        <span>QC Verified</span>
                                                    </a>
                                                @endif

                                                <!-- Other Staffs -->
                                            @else
                                                @if ($list->status < 3)
                                                    @if ($task_pending_or_not)
                                                        <a href="javascript:;"
                                                            class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                                            <span>In Progress</span>
                                                        </a>
                                                    @else
                                                        <a href="javascript:;"
                                                            class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                            style="background-color: #cf3c3cf5 !important;"
                                                            data-bs-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false">
                                                            <span>Not Yet Started</span>
                                                        </a>
                                                    @endif
                                                @elseif ($list->status == 3)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #008000 !important;">
                                                        <span>Completed</span>
                                                    </a>
                                                @elseif ($list->status == 4)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #000080 !important;">
                                                        <span>QC Verified</span>
                                                    </a>
                                                @elseif ($list->status == 5)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #d84315 !important;">
                                                        <span>Rework</span>
                                                    </a>
                                                @elseif ($list->status == 6)
                                                    <a href="javascript:;"
                                                        class="badge bg-info text-white mb-1 fs-7 fw-semibold"
                                                        style="background-color: #ff6f00 !important;">
                                                        <span>Correction</span>
                                                    </a>
                                                @endif
                                            @endif
                                        @endif
                                    </td>
                                    @if (auth()->user()->user_id < 2)
                                        <td>
                                            @if ($task_pending_or_not)
                                                <img src="{{ asset('assets/phdizone_images/CEOTimer.gif') }}"
                                                    class="rounded-circle img-fluid"
                                                    style="width:60px;height:60px;object-fit:cover;"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom">
                                            @endif
                                        </td>
                                    @endif
                                    <td>
                                        <span class="text-center">
                                            <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false">
                                                <i class="mdi mdi-dots-vertical fs-3 text-black mb-2"></i>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                @php
                                                    $currentStatus = '';
                                                    $currentBg = '';
                                                    $currenttxcr = '';

                                                    if ($list->is_journal == 1) {
                                                        if ($list->status < 3) {
                                                            if ($task_pending_or_not) {
                                                                $currentStatus = 'In Progress';
                                                                $currentBg = '#ffc700';
                                                                $currenttxcr = 'text-black';
                                                            } else {
                                                                $currentStatus = 'Not Yet Started';
                                                                $currentBg = '#d04343';
                                                                $currenttxcr = 'text-white';
                                                            }
                                                        } elseif ($list->status == 3) {
                                                            $currentStatus = 'Waiting For Documents';
                                                            $currentBg = '#50cd89';
                                                            $currenttxcr = 'text-white';
                                                        } elseif ($list->status == 4) {
                                                            $currentStatus = 'Completed';
                                                            $currentBg = '#104b01';
                                                            $currenttxcr = 'text-white';
                                                        } elseif ($list->status == 5) {
                                                            $currentStatus = 'Rework';
                                                            $currentBg = '#d84315';
                                                            $currenttxcr = 'text-white';
                                                        }
                                                    } else {
                                                        if ($list->status < 3) {
                                                            if ($task_pending_or_not) {
                                                                $currentStatus = 'In Progress';
                                                                $currentBg = '#ffc700';
                                                                $currenttxcr = 'text-black';
                                                            } else {
                                                                $currentStatus = 'Not Yet Started';
                                                                $currentBg = '#d04343';
                                                                $currenttxcr = 'text-white';
                                                            }
                                                        } elseif ($list->status == 3) {
                                                            $currentStatus = 'Completed';
                                                            $currentBg = '#50cd89';
                                                            $currenttxcr = 'text-white';
                                                        } elseif ($list->status == 4) {
                                                            $currentStatus = 'QC Verified';
                                                            $currentBg = '#000080';
                                                            $currenttxcr = 'text-white';
                                                        } elseif ($list->status == 5) {
                                                            $currentStatus = 'Rework';
                                                            $currentBg = '#d84315';
                                                            $currenttxcr = 'text-white';
                                                        } elseif ($list->status == 6) {
                                                            $currentStatus = 'Correction';
                                                            $currentBg = '#ff6f00';
                                                            $currenttxcr = 'text-white';
                                                        }
                                                    }
                                                @endphp
                                                @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_view_task"
                                                        onclick="view_task({{ $list->sno }},'{{ $currentStatus }}','{{ $currentBg }}','{{ $currenttxcr }}')">
                                                        <span> <i
                                                                class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                                                    </a>
                                                @endif
                                            </div>
                                        </span>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                {{-- <div id="task_table_body2"></div> --}}
            </div>
        </div>
    </div>


    <!--begin::Modal - Journal File Upload-->
    <div class="modal fade" id="kt_modal_file_upload" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="text-center text-black">Attach Documents</h3>
                    </div>
                    <input type="hidden" name="fileUploadTaskID" id="fileUploadTaskID">
                    <input type="hidden" name="fileUploadHidStatus" id="fileUploadHidStatus">
                    <input type="hidden" id="uploaded_files" name="uploaded_files">
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="fileUploadPaperName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-info fs-6 fw-semibold" id="fileUploadJournalId">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="fileUploadServiceName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-info fs-6 fw-semibold" id="fileUploadServiceId">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal TL</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="fileUploadJTLName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal Executive</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="fileUploadJCName">
                            -
                        </label>
                    </div>

                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Reviewer Comments</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="fileUploadComments">-</label>
                    </div>
                    <hr>
                    <div class="row mb-4">
                        <div class="upload-container">
                            <label class="upload-label">Documents</label>
                            <div id="dropArea" class="drop-area">
                                <div id="dropMessage" class="drop-message">
                                    <div class="upload-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                                        </svg>
                                    </div>
                                    <div class="upload-text">Drag & drop files here or <span
                                            class="clickable">browse</span></div>
                                    <p class="upload-subtext">Supports PDF, DOC, DOCX, JPG, PNG • Max 10MB per file</p>
                                </div>
                                <input type="file" id="fileInput" class="file-input d-none" />
                            </div>

                            <div class="preview-container" id="previewContainer" style="display: none;">
                                <div class="preview-header">
                                    <div class="preview-title">
                                        <span>Uploaded Files</span>
                                        <span class="badge" id="fileCount">0</span>
                                    </div>
                                    <button type="button" class="clear-all-btn" id="clearAllBtn">Clear All</button>
                                </div>
                                <div class="preview-list" id="previewList"></div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-end mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" id="uploadJournalFilesBtn">Submit</a>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Journal File Upload-->

    <!--begin::Modal - Verification-->
    <div class="modal fade" id="kt_modal_journal_verification" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="text-center text-black">Task Completion</h3>
                    </div>
                    <input type="hidden" name="" id="journalTaskID">
                    <input type="hidden" name="" id="journalHiddenStatus">
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="journalPaperName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-info fs-6 fw-semibold" id="journalJournalId">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="journalServiceName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Service ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-info fs-6 fw-semibold" id="journalServiceId">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal TL</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="journalTLName">-</label>
                    </div>
                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Journal Executive</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="journalStaffName">
                            -
                        </label>
                    </div>

                    <div class="row mb-4">
                        <label class="col-3 text-dark fs-6 fw-semibold">Reviewer Comments</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-8 text-black fs-6 fw-semibold" id="journalRevisionComments">-</label>
                    </div>
                    <hr>
                    <div class="row mb-4">
                        <input type="hidden" name="" id="journalHiddenMinValue">
                        <div class="col-lg-12">
                            <label class="text-start fw-semibold ">Progress Summary<span id="workMonitorValue"
                                    class="ms-2 text-white bg-dark px-2 fw-semibold fs-6"
                                    style="border-radius:3px;">0%</span></label>
                            <div id="workMonitorSlider" class="my-4"></div>
                            <div class="d-flex align-items-center justify-content-between">
                                <label class="text-danger fs-6 fw-semibold" id="journalMinValueHTML">0%</label>
                                <label class="text-danger fs-6 fw-semibold">100%</label>
                            </div>
                            <div id="journalTaskProgressErr" class="text-danger fs-7 fw-semibold mt-2"></div>
                        </div>

                    </div>
                    <div class="d-flex justify-content-end align-items-end mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <a href="javascript:;" class="btn btn-primary" onclick="journalTaskValidation()">Submit</a>
                    </div>

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Verification-->

    <!--begin::Modal - View Rework-->
    <div class="modal fade" id="kt_modal_rework_details" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black fw-bold">
                            <label>
                                <span class="mb-2 fs-2 fw-semibold ">Rework Details</span>
                                <span class="text-danger fw-bold fs-2 px-2 py-1 mt-4" id="task_log_tsk_name">-</span>
                            </label>
                        </h3>
                    </div>

                    <div class="row mx-3">
                        <div class="col-lg-12" id="rework_details_container">

                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Rework-->

    <!--begin::Modal - Complete Task -->
    <div class="modal fade" id="kt_modal_complete_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded-4">
                <!--begin::Modal header-->
                <div class="modal-header border-0 pb-0 align-items-center">
                    <!--begin::Close-->
                    <button type="button" class="btn btn-sm btn-icon btn-active-color-primary ms-auto"
                        data-bs-dismiss="modal" aria-label="Close">
                        <span class="svg-icon svg-icon-2">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                    </button>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->

                <!--begin::Modal body-->
                <div class="modal-body pt-6 pb-8 px-8 px-xl-12">
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Task Complete</h3>
                    </div>
                    <div class="task-view-container">
                        <!-- Header Section -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <div class="task-header bg-gradient-primary text-white rounded-3 p-4 shadow-sm">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h2 class="mb-1 fw-bold fs-2" style="color: #ffeca9 " id="comp_tsk_tsk_name">
                                                Task Name Here
                                            </h2>
                                            <p class="mb-0 opacity-75">
                                                <i class="mdi mdi-account-outline me-1"></i>
                                                Created by <span id="com_tsk_created_staff">Staff Name</span>
                                            </p>
                                        </div>
                                        <div class="task-badge">
                                            <span class="badge bg-white text-primary fs-6 px-3 py-2" id="com_tsk_tsk_id">
                                                -
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Main Content Grid -->
                        <div class="row">
                            <input type="hidden" name="task_status_id" id="task_status_id">
                            <!-- Left Column - Task Details -->
                            <div class="col-lg-8">
                                <!-- Customer & Service Info Card -->
                                <div class="card border-0 shadow-sm mb-4">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h5 class="card-title mb-0 text-dark">
                                            <i class="mdi mdi-information-outline text-primary me-2"></i>
                                            Task Details
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-account-circle-outline me-1"></i>
                                                        Customer
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6">
                                                        <span id="com_tsk_cus_name">-</span>
                                                        <small class="text-primary ms-1" id="com_tsk_cus_id"></small>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-phone-outline me-1"></i>
                                                        Contact
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_cus_mobile">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-cog-outline me-1"></i>
                                                        Service
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_task_pro_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-dropbox me-1"></i>
                                                        Product Category
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_task_cat_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-package-variant me-1"></i>
                                                        Variant
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_variant_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-1">
                                                        <i class="mdi mdi-tune-vertical me-1"></i>
                                                        Variable
                                                    </label>
                                                    <div class="fw-bold text-dark fs-6" id="com_tsk_variable_name">
                                                        -
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="detail-item">
                                                    <label class="text-muted small fw-semibold mb-2">
                                                        <i class="mdi mdi-text-long me-1"></i>
                                                        Description
                                                    </label>
                                                    <div class="task-description bg-light rounded-2 p-3">
                                                        <p class="mb-0 text-dark fs-6" id="com_tsk_tsk_desc">
                                                            -
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Checklist & Progress in Same Row -->
                                <div class="row">
                                    <!-- Progress Summary -->
                                    <div class="col-lg-12">
                                        <div class="card border-0 shadow-sm h-100">
                                            <div class="card-header bg-transparent border-0 py-3">
                                                <h5 class="card-title mb-0 text-dark">
                                                    <i class="mdi mdi-chart-pie text-warning me-2"></i>
                                                    Progress Summary
                                                </h5>
                                            </div>
                                            <div class="card-body">
                                                <div class="progress-summary text-center">
                                                    <div class="row mb-3 range-container">
                                                        <label for="formRangeMax"
                                                            class="form-label text-info fs-5 mb-4 fw-bold">
                                                            Number Of <span id="com_task_page_or_per">Pages</span>
                                                            Completed:
                                                            <span id="currentValue"
                                                                class="current-value bg-success fs-4 px-2 py-1 text-white"></span><span
                                                                id="com_task_page_or_per2"></span>
                                                        </label>
                                                        <input type="hidden" name="checklist_task_id"
                                                            id="checklist_task_id">
                                                        <input type="range" class="form-range mt-4" id="formRangeMax"
                                                            name="num_pages" min="0" max="10"
                                                            step="1" value="1" onchange="checklistShow()" />

                                                        <div class="d-flex justify-content-between mt-2 fs-6 text-muted">
                                                            <span class="text-success fs-4 fw-semibold">Page 1</span>
                                                            <span class="text-success fs-4 fw-semibold">Page 10</span>
                                                        </div>
                                                        <div id="range_move_err"
                                                            class="text-danger fs-7 fw-semibold mt-2">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Task Description -->
                                    <div class="col-lg-12 my-4">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Comments</label>
                                        <textarea class="form-control" rows="3" placeholder="Enter Comments" id="taskDesc"></textarea>
                                    </div>
                                    <!-- Task Checklist -->
                                    <div class="col-lg-12" id="checklist_container">
                                        <div class="card border-0 shadow-sm h-100">
                                            <div class="card-header bg-transparent border-0 py-3">
                                                <h5 class="card-title mb-0 text-dark">
                                                    <i class="mdi mdi-format-list-checks text-success me-2"></i>
                                                    Task Checklist
                                                </h5>
                                            </div>
                                            <div class="card-body">
                                                <div id="task_check_fetch_container"
                                                    style="max-height: 400px; overflow-y: auto;">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Right Column - Staff & Time Spent -->
                            <div class="col-lg-4">
                                <!-- Combined Staff Assignment & Time Spent Card -->
                                <div class="card border-0 shadow-sm">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h5 class="card-title mb-0 text-dark">
                                            <i class="mdi mdi-account-clock text-info me-2"></i>
                                            Staff & Time Tracking
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <!-- Staff Profile Section -->
                                        <div class="staff-section text-center mb-4 pb-3 border-bottom">
                                            <div class="staff-profile">
                                                <div id="com_tsk_staff_img">
                                                </div>
                                                <h6 class="mt-3 mb-1 fw-bold text-dark" id="com_tsk_pro_staff_name">-</h6>
                                                <p class="text-muted small mb-2" id="com_tsk_pro_nick_name">-</p>
                                                <span class="badge bg-info bg-opacity-10 text-info"
                                                    id="com_tsk_job_pos">-</span>
                                            </div>
                                        </div>

                                        <!-- Total Time Spent Section -->
                                        <div class="time-spent-section text-center mb-4">
                                            <div class="total-hours">
                                                <div class="text-muted small mb-2">Allocated Hours</div>
                                                <div class="display-5 text-primary fw-bold mb-3" id="total_time">-</div>
                                            </div>
                                        </div>

                                        <!-- Time Logs Section -->
                                        <div class="time-logs-section">
                                            <button class="btn btn-outline-primary btn-sm w-100 mb-3" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#timeLogs">
                                                <i class="mdi mdi-clock-outline me-1"></i>
                                                View Detailed Time Logs
                                            </button>

                                            <div class="collapse show" id="timeLogs">
                                                <div class="time-logs-container" id="time-logs-container"
                                                    style="max-height: 200px; overflow-y: auto;">

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mb-2">
                        <a href="{{ url('/manage_production') }}"
                            class="btn fw-bold btn-secondary me-3 waves-effect waves-light">Cancel</a>
                        <button type="button" class="btn fw-bold btn-primary waves-effect waves-light"
                            onclick="updateTaskValidation()">Update Task</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Complete Task -->

    <!--begin::Modal - Update Task-->
    <div class="modal fade" id="kt_modal_edit_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Task</h3>
                    </div>
                    <div class="row">
                        <input type="hidden" name="edit_daily_task_sno" id="edit_daily_task_sno">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_staff" id="edit_task_staff"
                                onchange="fetchEditTaskService()">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_staff_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_service" id="edit_task_service"
                                onchange="fetchEditTask()">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_service_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Task<span class="text-danger">*</span></label>
                            <select class="select3 form-select" name="edit_task_id" id="edit_task_id">
                            </select>
                            <div class="fs-7 fw-semibold mt-1 text-danger" id="edit_task_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="edit_task_btn"
                            onclick="editValidation()">Update Task</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Task-->

    <!--begin::Modal - View Task-->
    <div class="modal fade" id="kt_modal_view_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-6">
                        <h3 class="text-center text-black">
                            <label>View Task Details</label>
                            <label class="ms-1 me-1">-</label>
                            <label id="view_badge"></label>
                        </h3>
                    </div>
                    <div id="view_data_div"></div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View Task-->

    <!--begin::Modal - Delete Task-->
    <div class="modal fade" id="kt_modal_delete_task" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you
                    want
                    to
                    delete Task ?
                    <div class="d-block fw-bold fs-5 mt-3 py-2">
                        <label class="mb-1" id="del_task_name">-</label>
                        <label class="ms-1 me-1 mb-1">-</label>
                        <label class="mb-1" id="del_customer">-</label>
                        <label class="ms-1 me-1 mb-1">-</label>
                        <label class="mb-1" id="del_prd">-</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" class="btn btn-danger me-3" onclick="delete_confirm()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Task-->

    <!--begin::Modal - View History-->
    <div class="modal fade" id="kt_modal_view_history" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black fw-bold">
                            <label>
                                <span class="mb-2 fs-2 fw-semibold d-block">Task Log</span>
                                <span class="bg-danger text-white fw-bold fs-5 px-2 py-1 mt-4"
                                    id="task_log_tsk_name">-</span>
                            </label>
                        </h3>
                    </div>

                    <div class="row mx-3">
                        <div class="col-lg-12">
                            <div class="table-responsive shadow-sm">
                                <table
                                    class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 mb-0">
                                    <thead>
                                        <tr class="text-start align-middle fw-bold fs-6 bg-primary text-white">
                                            <th class="min-w-50px px-3 py-2">Sno</th>
                                            <th class="min-w-125px px-3 py-2">Start Time</th>
                                            <th class="min-w-125px px-3 py-2">End Time</th>
                                            <th class="min-w-80px px-3 py-2">Duration</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-700 fw-semibold fs-7" id="task_log_tr_data">
                                        <!-- AJAX WILL POPULATE HERE -->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - View History-->

    <!--begin::Modal - Status Change-->
    <div class="modal fade" id="kt_modal_qc_status_change" tabindex="-1" aria-hidden="true"
        data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 shadow-lg rounded-5 bg-white">

                <!-- Header -->
                <div
                    class="modal-header border-0 pt-5 pb-3 px-6 px-md-8 d-flex align-items-center justify-content-between">
                    <h3 class="modal-title fw-bolder fs-3 text-gray-900 mb-0">Update QC Status</h3>
                    <button type="button" class="btn btn-icon btn-active-light-primary" data-bs-dismiss="modal">
                        <i class="mdi mdi-close fs-2"></i>
                    </button>
                </div>

                <!-- Body -->
                <div class="modal-body px-6 px-md-8 pb-6 pt-0">

                    <!-- Confirmation text -->
                    <input type="text" name="" id="qcCheckTaskId">
                    <div class="mb-6">
                        <p class="text-dark fs-5 p-6">
                            Confirm the quality check results for
                            <strong class="text-black" id="qcCheckTaskName">-</strong>.
                            Changing the status to
                            <span class="fw-semibold text-danger">Accepted</span>
                            will automatically notify the assigned agent.
                        </p>
                    </div>

                    <!-- Info chips -->
                    <div class="row g-4 mb-7">
                        <div class="col-md-4">
                            <div class="bg-white border border-1 border-dark rounded p-4 h-100">
                                <div class="text-muted fs-7 fw-semibold mb-1">SERVICE</div>
                                <div class="fw-bold fs-6 text-black" id="qcServiceName">-</div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="bg-white border border-1 border-dark rounded p-4 h-100">
                                <div class="text-muted fs-7 fw-semibold mb-1">CUSTOMER</div>
                                <div class="fw-bold fs-6 text-black" id="qcCustomerId">-</div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="bg-white border border-1 border-dark rounded p-4 h-100">
                                <div class="text-muted fs-7 fw-semibold mb-1">Allocated / Completed</div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="fw-bold fs-6" id="qcWork">-</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Status selector (pill / segmented style) -->
                    <div class="mb-6">
                        <label class="form-label fw-bold fs-5 text-gray-900 py-3 mb-3">New Status</label>
                        <div class="bg-light rounded-4 p-2 d-flex gap-2" id="statusTabs">
                            <button class="btn btn-dark flex-fill fw-semibold active" data-status="approved">
                                <i class="mdi mdi-check-circle text-success me-2"></i> Approved
                            </button>

                            <button class="btn btn-dark flex-fill fw-semibold" data-status="rework">
                                <i class="mdi mdi-repeat-variant text-warning me-2"></i> Rework
                            </button>

                            <button class="btn btn-dark flex-fill fw-bold" data-status="rejected">
                                <i class="mdi mdi-close-thick me-2 text-danger"></i> Rejected
                            </button>
                        </div>
                    </div>

                    <div id="dynamicContentContainer"></div>
                    <div id="validationMessages" class="mt-3 text-danger fs-7 fw-semibold"></div>

                </div>

                <!-- Footer -->
                <div class="modal-footer border-0 pt-0 px-8 pb-6">
                    <button class="btn btn-lg btn-light fw-semibold px-8">
                        Cancel
                    </button>

                    <button type="button" onclick="statusValidation()" class="btn btn-lg btn-primary fw-bold px-10">
                        Confirm Change
                    </button>
                </div>


            </div>
        </div>
    </div>
    <!--end::Modal - Status Change-->


    <style>
        .btn-dark.active {
            background-color: #099dda !important;
            position: relative;
        }

        .btn-dark.active::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 10%;
            width: 80%;
            height: 3px;
            background-color: #6f757c;
            border-radius: 3px;
        }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
    <style>
        :root {
            --primary-color: #3a7bd5;
            --danger-color: #e74c3c;
            --warning-color: #f39c12;
            --success-color: #2ecc71;
            --info-color: #3498db;
            --secondary-color: #95a5a6;
            --dark-color: #343a40;
            --border-radius: 12px;
            --box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .task-details-card {
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--primary-color);
        }

        .detail-row {
            display: flex;
            margin-bottom: 0.75rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .detail-label {
            flex: 0 0 30%;
            font-weight: 600;
            color: var(--dark-color);
        }

        .detail-value {
            flex: 1;
            color: #555;
        }

        .page-stats {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .stat-card {
            flex: 1;
            text-align: center;
            padding: 1.25rem;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card.total {
            background: linear-gradient(135deg, #f5f7fa, #c3cfe2);
            border-left: 4px solid var(--secondary-color);
        }

        .stat-card.completed {
            background: linear-gradient(135deg, #e3f2fd, #bbdefb);
            border-left: 4px solid var(--info-color);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            margin: 0.5rem 0;
        }

        .section-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 1rem;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .section-title i {
            color: var(--primary-color);
        }

        .checklist-container {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px dashed #dee2e6;
        }

        .checkbox-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 0.75rem;
            padding: 0.75rem;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }

        .checkbox-item input {
            margin-top: 0.25rem;
            margin-right: 0.75rem;
        }

        .confirmation-container {
            background-color: #fff9e6;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-left: 4px solid var(--warning-color);
        }

        .confirmation-check {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
        }

        .confirmation-text {
            color: #856404;
            line-height: 1.5;
        }

        .status-container {
            background-color: white;
            border-radius: 10px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border: 1px solid #e9ecef;
        }
    </style>

    <script>
        function view_task(id, task_name, color, text_color) {

            $('#view_badge').html(`
                            <span class="badge bg-info ${text_color || ''} rounded fw-semibold fs-5"
                                    style="background-color: ${color || ''} !important;">
                                ${task_name || ''}
                            </span>
                            `);
            fetch('/manage_production/task_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        $('#view_data_div').empty().append(data.data.html);
                        $('[data-bs-toggle="tooltip"]').tooltip();

                        const containers = document.getElementById('product_variant_container');
                        containers.innerHTML = '';

                    } else {
                        console.log(data.error_msg);
                    }
                })
                .catch(error => {
                    console.log('Error:', error);
                });
        }
    </script>

    <script>
        function sort_filter(val) {
            if (val != "") {
                $('.sorting_filter_class').val(val);
                $('#search_form').submit();
            } else {
                $('.sorting_filter_class').val(10);
                $('#search_form').submit();
            }
        }
    </script>

    <script>
        $(document).ready(function() {
            @if ($filter_on ?? '')
                $('.filter_tbox').slideToggle('fast');
            @endif
        });
        $('#filter').click(function() {
            $('.filter_tbox').slideToggle('slow');
        });
    </script>


    <script>
        // $(document).ready(function() {
        //     let currentTaskData = {};
        //     let currentStatus = 'approved';
        //     let currentTaskId = null;
        //     let modalMode = 'qc';



        //     // Tab switching logic
        //     $('#statusTabs button').on('click', function() {
        //         const status = $(this).data('status');

        //         // Update tabs
        //         $('#statusTabs button').removeClass('active');
        //         $(this).addClass('active');

        //         // Update content visibility
        //         $('.status-content').removeClass('active').addClass('d-none');
        //         $(`#${status}Section`).removeClass('d-none').addClass('active');

        //         currentStatus = status;

        //         loadChecklist(status);
        //     });

        //     function loadChecklist(status) {
        //         $.ajax({
        //             url: `/list_qc_checklist`,
        //             method: 'GET',
        //             success: function(response) {
        //                 if (response.status === 200) {
        //                     let html = '';
        //                     const containerId = status === 'rework' ? 'rework_check_container' :
        //                                     status === 'rejected' ? 'reject_check_container' :
        //                                     'sts_chnge_check_container';

        //                     if (response.data.length > 0) {
        //                         response.data.forEach((check, index) => {
        //                             html += `
    //                                 <div class="d-flex align-items-center mb-2">
    //                                     <input class="form-check-input task_chk_box_${status}"
    //                                         type="checkbox"
    //                                         id="qcChecklist${check.sno}"
    //                                         name="task_check_list[]"
    //                                         value="${check.sno}"
    //                                         data-status="${status}">
    //                                     <label class="form-check-label ms-2" for="qcChecklist${check.sno}">${check.qc_checklist}</label>
    //                                 </div>
    //                             `;
        //                         });
        //                     } else {
        //                         html = `<div class="alert alert-info">No QC Check to Verify</div>`;
        //                     }

        //                     $(`#${containerId}`).html(html);

        //                     // Initialize button state
        //                     updateButtonState(status);

        //                     // Setup checkbox change listeners
        //                     $(`.task_chk_box_${status}`).on('change', function() {
        //                         updateButtonState(status);
        //                     });
        //                 }
        //             }
        //         });
        //     }

        //     // Update button state based on checkboxes
        //     function updateButtonState(status) {
        //         const checkboxes = $(`.task_chk_box_${status}`);
        //         const total = checkboxes.length;
        //         const checked = checkboxes.filter(':checked').length;

        //         if (status === 'approved') {
        //             $('#approveBtn').prop('disabled', total === 0 || total !== checked);
        //         } else if (status === 'rework') {
        //             const reason = $('#reworkReason').val().trim();
        //             $('#submitReworkBtn').prop('disabled',
        //                 total === 0 || total !== checked || reason === '');
        //         } else if (status === 'rejected') {
        //             const reason = $('#rejectReason').val().trim();
        //             $('#submitRejectBtn').prop('disabled',
        //                 total === 0 || total !== checked || reason === '');
        //         }
        //     }

        //     // Listen for reason text changes
        //     $('#reworkReason, #rejectReason').on('input', function() {
        //         const status = $(this).attr('id') === 'reworkReason' ? 'rework' : 'rejected';
        //         updateButtonState(status);
        //     });

        //     // Submit handlers
        //     $('#approveBtn').on('click', function() {
        //         if (!$(this).prop('disabled')) {
        //             submitStatus('approved');
        //         }
        //     });

        //     $('#submitReworkBtn').on('click', function() {
        //         if (!$(this).prop('disabled')) {
        //             submitStatus('rework', $('#reworkReason').val());
        //         }
        //     });

        //     $('#submitRejectBtn').on('click', function() {
        //         if (!$(this).prop('disabled')) {
        //             submitStatus('rejected', $('#rejectReason').val());
        //         }
        //     });

        //     // Submit status to server
        //     function submitStatus(status, reason = '') {
        //         const checkboxes = $(`.task_chk_box_${status}:checked`);
        //         const checklistItems = checkboxes.map(function() {
        //             return $(this).val();
        //         }).get();

        //         const data = {
        //             status: status,
        //             checklist: checklistItems,
        //             reason: reason,
        //             // Add other necessary data
        //             task_id: response.task_id, // from your response variable
        //             task_name: response.task_name
        //         };

        //         $.ajax({
        //             url: '/update_task_status',
        //             method: 'POST',
        //             data: data,
        //             success: function(response) {
        //                 if (response.success) {
        //                     showSuccessMessage(`Task marked as ${status}`);
        //                     // Reset form or redirect
        //                     resetForm();
        //                 } else {
        //                     showErrorMessage(response.message || 'Error updating status');
        //                 }
        //             },
        //             error: function() {
        //                 showErrorMessage('Server error occurred');
        //             }
        //         });
        //     }

        //     // Utility functions
        //     function showSuccessMessage(message) {
        //         // Use toast or alert
        //         alert('Success: ' + message);
        //     }

        //     function showErrorMessage(message) {
        //         alert('Error: ' + message);
        //     }

        //     function resetForm() {
        //         $('.task_chk_box').prop('checked', false);
        //         $('#reworkReason, #rejectReason').val('');
        //         updateButtonState(currentStatus);
        //     }

        //     // Load initial checklist
        //     loadChecklist('approved');
        // });
    </script>

    <script>
        function status_change(id, yesOrNo = '') {

            $.ajax({
                url: `/status_change_data_fetch/${id}`,
                method: "GET",
                success: function(response) {
                    if (response.status === 200) {
                        var status = response.data;

                        // QC Checklist
                        $('#qcCheckTaskName').html(status.task_name);
                        $('#qcServiceName').html(status.product_name);
                        $('#qcCustomerId').html(status.customer_id);
                        $('#qcCheckTaskId').val(id);

                        let workCategory = 'Pages';
                        if (status.task_category == 1) workCategory = 'Percentage';

                        $('#qcWork').html(
                            `${status.max_page_or_per} ${workCategory} /<br> ${status.min_page_or_per} ${workCategory}`
                        );

                        let changeStatus = "approved";
                        loadChecklist(changeStatus);

                        // var html = '';

                        // $('#sts_chng_tsk_id').val(id);
                        // $('#sts_chnge_hide_show').show();
                        // $('#cre_confirmation_container').hide();
                        // $('#reject-status-container').hide();
                        // $('#rework-status-container').hide();
                        // $('#status_change_btn').prop('disabled', false);
                        // $('#reject_status_err').text('');

                        // if (yesOrNo == 'reject') {
                        //     $('#sts_chng_sts_id').val(6);
                        // } else {
                        //     $('#sts_chng_sts_id').val(status.status);
                        // }

                        // $('#sts_change_tsk_name').html(status.task_name);
                        // $('#sts_change_tsk_id').html(status.tasks_id);
                        // $('#sts_change_cus_name').html(status.cus_name);
                        // $('#sts_change_cus_id').html(status.customer_id);
                        // $('#sts_change_product_name').html(status.product_name);
                        // $('#sts_change_product_cat').html(status.product_category_name);
                        // $('#sts_chnge_min_page').html(status.min_page_or_per);
                        // $('#sts_chnge_max_page').html(status.max_page_or_per);
                        // $("#status_change_status_name").removeClass(`text-white`);
                        // $("#status_change_status_name").removeClass(`text-black`);

                        // var maxPages = status.max_page_or_per;

                        // if (status.task_category == 1) {
                        //     $('.status_change_per_or_page').html('Percentage');
                        // } else {
                        //     $('.status_change_per_or_page').html('Pages');
                        // }

                        // if (status.status == 3) {
                        //     $('#status_change_status_name').html('QC Verification');
                        //     $('#status_change_btn').html('QC Verification');
                        //     $("#status_change_status_name").attr('style', `background-color:#000080`);
                        //     $("#status_change_status_name").addClass('text-white');

                        //     // QC Checklist
                        //     $.ajax({
                        //         url: `/list_qc_checklist`,
                        //         method: 'GET',
                        //         success: function(response) {
                        //             if (response.status === 200) {
                        //                 if (response.data.length > 0) {
                        //                     response.data.forEach((check, index) => {
                        //                         html += `
                    //                     <div class="d-flex align-items-center mb-2">
                    //                         <input class="form-check-input task_chk_box" type="checkbox" name="task_check_list[]" value="${check.sno}">
                    //                         <label class="form-check-label ms-2">${check.qc_checklist}</label>
                    //                     </div>
                    //                     `;
                        //                     });

                        //                     $('#sts_chnge_check_container').html(html);
                        //                 } else {
                        //                     html +=
                        //                         `<label class="mb-0 text-dark fs-6 fw-bold">No QC Check to Verify</label>`;
                        //                     $('#sts_chnge_check_container').html(html);
                        //                 }

                        //                 const totalQC = $('.task_chk_box').length;
                        //                 const checkedQC = $('.task_chk_box:checked').length;

                        //                 $('#status_change_btn').prop('disabled', totalQC === 0 ||
                        //                     totalQC !== checkedQC);

                        //                 $(document).on('change', '.task_chk_box', function() {
                        //                     const total = $('.task_chk_box').length;
                        //                     const checked = $('.task_chk_box:checked')
                        //                         .length;
                        //                     $('#status_change_btn').prop('disabled',
                        //                         total === 0 || total !== checked);
                        //                 });
                        //             }
                        //         }
                        //     });
                        // } else if (status.status == 4) {
                        //     $('#status_change_status_name').html('Delivery Verification');
                        //     $('#status_change_btn').html('Delivery Verification');
                        //     $("#status_change_status_name").attr('style', `background-color:#008080`);
                        //     $("#status_change_status_name").addClass('text-white');

                        //     // Delivery Checklist
                        //     $.ajax({
                        //         url: `/list_delivery_checklist`,
                        //         method: 'GET',
                        //         success: function(response) {
                        //             if (response.status === 200) {
                        //                 if (response.data.length > 0) {
                        //                     response.data.forEach((check, index) => {
                        //                         html += `
                    //                     <div class="d-flex align-items-center mb-2">
                    //                         <input class="form-check-input delivery_chck_bx" type="checkbox" name="delivery_checklist[]" value="${check.sno}">
                    //                         <label class="form-check-label ms-2">${check.delivery_checklist}</label>
                    //                     </div>`;
                        //                     });

                        //                     $('#sts_chnge_check_container').html(html);
                        //                 } else {
                        //                     html +=
                        //                         `<label class="mb-0 text-dark fs-6 fw-bold">No Delivery Check to Verify</label>`;
                        //                     $('#sts_chnge_check_container').html(html);
                        //                 }

                        //                 const totalDC = $('.delivery_chck_bx').length;
                        //                 const checkedDC = $('.delivery_chck_bx:checked').length;

                        //                 $('#status_change_btn').prop('disabled', totalDC === 0 ||
                        //                     totalDC !== checkedDC);

                        //                 $(document).on('change', '.delivery_chck_bx', function() {
                        //                     const totalDelivery = $('.delivery_chck_bx')
                        //                         .length;
                        //                     const checkedDelivery = $(
                        //                         '.delivery_chck_bx:checked').length;
                        //                     $('#status_change_btn').prop('disabled',
                        //                         totalDelivery === 0 || totalDelivery !==
                        //                         checkedDelivery);
                        //                 });
                        //             }
                        //         }
                        //     });
                        // } else if (status.status == 5 && yesOrNo == 'confirm') {
                        //     $('#sts_chnge_hide_show').hide();
                        //     $('#cre_confirmation_container').show();

                        //     $('#status_change_btn').prop('disabled', true);

                        //     $('#cre_confrm_check').on('change', function() {
                        //         if ($(this).is(':checked')) {
                        //             $('#status_change_btn').prop('disabled', false);
                        //         } else {
                        //             $('#status_change_btn').prop('disabled', true);
                        //         }
                        //     });

                        // } else if (status.status == 5 && yesOrNo == 'reject') {
                        //     $('#sts_chnge_hide_show').hide();
                        //     $('#reject-status-container').show();
                        //     $('#status_change_btn').prop('disabled', true);

                        //     $('#reject_reason').on('input', function() {
                        //         if ($(this).val().trim() !== '') {
                        //             $('#status_change_btn').prop('disabled', false);
                        //             $('#reject_status_err').text('');
                        //         } else {
                        //             $('#status_change_btn').prop('disabled', true);
                        //             $('#reject_status_err').text('Enter Reject Reason.');
                        //         }
                        //     });
                        // } else if (status.status == 7) {
                        //     $('#sts_chnge_hide_show').hide();
                        //     $('#rework-status-container').show();
                        //     $('#status_change_btn').prop('disabled', true);

                        //     function checkReworkInputs() {
                        //         var reworkValid = true;
                        //         const reason = $('#rework_reason').val().trim();
                        //         const pages = $('#rework_pages').val().trim();

                        //         // Reset errors
                        //         $('#rework_status_err').html('');
                        //         $('#rework_pages_err').html('');

                        //         if (reason === '') {
                        //             reworkValid = false;
                        //             $('#rework_status_err').html('Enter Rework Reason.');
                        //         }

                        //         if (pages === '') {
                        //             reworkValid = false;
                        //             $('#rework_pages_err').html('Enter Rework Pages.');
                        //         } else if (parseInt(pages) > maxPages) {
                        //             reworkValid = false;
                        //             $('#rework_pages_err').html('Rework Pages exceed Allocated Pages.');
                        //         } else if (parseInt(pages) <= 0) {
                        //             reworkValid = false;
                        //             $('#rework_pages_err').html('Enter Atleast One Pages.');
                        //         }

                        //         $('#status_change_btn').prop('disabled', !reworkValid);
                        //     }

                        //     $('#rework_reason, #rework_pages').on('input', checkReworkInputs);
                        // }
                    }
                },
                error: function() {
                    console.error('Data Fetching Failed!');
                }
            });

        }

        $(document).ready(function() {
            let currentStatus = 'approved';

            $('#statusTabs button').on('click', function() {
                const status = $(this).data('status');

                // Update tabs
                $('#statusTabs button').removeClass('active');
                $(this).addClass('active');

                // Update content visibility
                $('.status-content').removeClass('active').addClass('d-none');
                $(`#${status}Section`).removeClass('d-none').addClass('active');

                currentStatus = status;

                loadChecklist(status);
            });
        });

        function loadChecklist(status) {

            const container = $('#dynamicContentContainer');
            let html = '';
            $('#validationMessages').text('');

            if (status == 'approved') {
                container.empty();
                $.ajax({
                    url: `/list_qc_checklist`,
                    type: 'GET',
                    success: function(response) {
                        if (response.status === 200) {
                            if (response.data.length > 0) {
                                response.data.forEach((check, index) => {
                                    html += `
                                        <div class="d-flex align-items-center mb-2">
                                            <input class="form-check-input qc-checklist task_chk_box_${status}"
                                                type="checkbox"
                                                id="qcChecklist${check.sno}"
                                                name="task_check_list[]"
                                                value="${check.sno}"
                                                data-status="${status}">
                                            <label class="form-check-label ms-2" for="qcChecklist${check.sno}">${check.qc_checklist}</label>
                                        </div>
                                    `;
                                });
                            } else {
                                html = `<div class="alert alert-info">No QC Check to Verify</div>`;
                            }

                            container.html(html);
                        }
                    },
                    error: function(err) {
                        console.error(`AJAX Error Due To : ${err}`);
                    }
                });
            } else if (status == 'rework') {

                container.empty();

                html += `
                    <div class="form-floating form-floating-outline mb-6">
                        <textarea class="form-control h-px-100" id="reworkReason" placeholder="Enter Rework Reason"></textarea>
                        <label for="reworkReason">Rework Reason</label>
                    </div>
                `;

                container.html(html);
            } else if (status = "rejected") {
                container.empty();

                html += `
                    <div class="form-floating form-floating-outline mb-6">
                        <textarea class="form-control h-px-100" id="rejectReason" placeholder="Enter Reject Reason"></textarea>
                        <label for="rejectReason">Reject Reason</label>
                    </div>
                `;

                container.html(html);
            }
        }

        function validateApprovedStatus() {
            const qcCheckboxes = $('.qc-checklist');
            const checkedCount = $('.qc-checklist:checked').length;
            const totalCount = qcCheckboxes.length;

            if (totalCount > 0 && checkedCount !== totalCount) {
                $('#validationMessages').text("Check all the checklist.");
                return false;
            }

            return true;
        }

        function validateReworkStatus() {
            const reason = $('#reworkReason').val().trim();

            if (!reason) {
                $('#validationMessages').text("Rework Reason is required.");
                return false;
            }

            return true;
        }

        function validateRejectReason() {
            const rejectReason = $('#rejectReason').val().trim();

            if (!rejectReason) {
                $('#validationMessages').text("Reject reason is required.");
                return false;
            }

            return true;
        }

        function validateCurrentStatus() {
            const currentStatus = $('#statusTabs .active').data('status');

            switch (currentStatus) {
                case 'approved':
                    return validateApprovedStatus();
                case 'rework':
                    return validateReworkStatus();
                case 'rejected':
                    return validateRejectReason();
                default:
                    return false;
            }
        }

        function statusValidation() {
            if (!validateCurrentStatus()) {
                toastr.error("Please fix the validation errors.");
                return false;
            }

            const currentStatus = $('#statusTabs .active').data('status');
            let formData = {
                task_id: $('#qcCheckTaskId').val(),
                status: currentStatus
            };

            switch (currentStatus) {
                case 'approved':
                    const qcItems = [];
                    $('.qc-checklist:checked').each(function() {
                        qcItems.push($(this).val());
                    });

                    formData.qc_checklist = qcItems;
                    break;
                case 'rework':
                    formData.rework_reason = $('#reworkReason').val();
                    break;
                case 'rejected':
                    formData.reject_reason = $('#rejectReason').val();
                    break;
            }

            console.log(formData);
            sts_submit(formData);
            return false;
        }


        function sts_submit(data) {
            $.ajax({
                url: "/task/status_change",
                method: "POST",
                data: JSON.stringify(data),
                contentType: "application/json",
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success('Task status has been successfully updated!');
                        location.reload();
                    }
                },
                error: function() {
                    toastr.error("Something Went Wrong");
                }
            });
        }
    </script>

    <script>
        function Delete_task(sno, task, cus_name, cus_id, prd) {
            document.querySelector('#kt_modal_delete_task .btn-danger').setAttribute('data-id', sno);
            $('#del_task_name').html(task);
            $('#del_customer').html(cus_name + ' ( ' + cus_id + ' )');
            $('#del_prd').html(prd);
        }
    </script>
    <script>
        function get_task_working_hours(id) {

            if (id == '') {
                const Hour = 0;
                // Assign value to input field
                $('#workingHours').val(Hour);
                const hourLabel = Hour === 1 ? 'Hr' : 'Hrs';
                $('#workingHours_label').html(`${Hour} ${hourLabel}`);
                updateEndDate();
                return false;
            }

            fetch(`/fetch_task_check_list/${id}`, {
                    method: 'GET',
                    headers: {
                        'CONTENT-TYPE': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 200) {
                        var cus = data.data;

                        const Hour = parseFloat(cus.hours_id) || 0;
                        // Assign value to input field
                        $('#workingHours').val(Hour);
                        const hourLabel = Hour === 1 ? 'Hr' : 'Hrs';
                        $('#workingHours_label').html(`${Hour} ${hourLabel}`);
                        $('#empl_skill').html(cus.employee_skill);
                        updateEndDate();

                        const select_task_ch = $('#task_check_list');
                        select_task_ch.empty(); // Clear previous options
                        if (cus.task_check_list && cus.task_check_list.length > 0) {
                            cus.task_check_list.forEach(task_ch => {
                                select_task_ch.append(
                                    `<option value="${task_ch.sno}">${task_ch.task_checklist}</option>`);
                            });
                        }

                        // select.trigger('change'); // If using Select2 or similar
                    } else {
                        console.log('Error Fetching Data!');
                    }
                })
                .catch(err => {
                    console.log(`Error Fetching Data : ${err}`);
                });
        }

        function Edit_task(id) {
            fetch('/task_edit/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        console.log(data.data);
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#task_customer').html(com.cus_name + ' ( ' + com.cus_id + ' )');
                        $('#task_service').html(com.product_name);
                        $('#task_service_cat').html(com.product_category_name);
                        $('#workingHours').val(com.working_hours).change();
                        $('#task_per_hr_task').val(com.per_hour_cost);
                        // Your original datetime string
                        const datetimeStr = com.start_date_time;

                        // Parse into a Date object (assumes local time)
                        const dateObj = new Date(datetimeStr.replace(' ', 'T')); // "2025-06-11T14:53:00"

                        // Define month names for formatting
                        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov",
                            "Dec"
                        ];

                        // Format function
                        function formatDate(d) {
                            let day = d.getDate();
                            let month = monthNames[d.getMonth()];
                            let year = d.getFullYear();

                            // Hours 12-hour format
                            let hours = d.getHours();
                            let ampm = hours >= 12 ? 'PM' : 'AM';
                            hours = hours % 12;
                            hours = hours ? hours : 12; // hour '0' should be '12'

                            // Minutes with leading zero
                            let minutes = d.getMinutes();
                            minutes = minutes < 10 ? '0' + minutes : minutes;

                            return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
                        }

                        const task_st_dt_tm = document.getElementById('task_st_dt_tm');
                        if (task_st_dt_tm) {
                            task_st_dt_tm.flatpickr({
                                enableTime: true,
                                dateFormat: "d-M-Y h:i K",
                                minDate: formatDate(
                                    dateObj) // disables past dates and times before current moment
                            });
                        }

                        // Set formatted value to your input
                        $('#task_st_dt_tm').val(formatDate(dateObj));
                        updateEndDate()

                        $('#max_amount_edit').val(com.max_amount);
                        $('#desc_edit').val(com.product_desc);
                        var cus = data.data;
                        $('#tsk_variant').html(cus.variant_name);
                        $('#tsk_variable').html(cus.variable_name);
                        const select = $('#task_staffs');
                        select.empty(); // Clear previous options
                        if (cus.production_staffs && cus.production_staffs.length > 0) {
                            cus.production_staffs.forEach(staff => {
                                select.append(
                                    `<option value="${staff.sno}" data-perhour="${staff.per_hour_cost}">${staff.staff_name}</option>`
                                );
                            });
                        }
                        const select_task = $('#task_name');
                        select_task.empty(); // Clear previous options
                        select_task.append(`<option value="">Select Task</option>`);

                        if (cus && Array.isArray(cus.task_list) && cus.task_list.length > 0) {
                            cus.task_list.forEach(task => {
                                // Check task object properties before appending
                                if (task && task.sno !== undefined && task.task_name) {
                                    select_task.append(
                                        `<option value="${task.sno}" data-workinghour="${task.hours_id}">${task.task_name}</option>`
                                    );
                                    select_task.val(cus.task_name).change();
                                }
                            });
                            let task_check_list = [];

                            try {
                                task_check_list = JSON.parse(com.task_check_list_ids).map(id => id.toString().trim());
                            } catch (e) {}
                            setTimeout(() => $('#task_check_list').val(task_check_list || '').trigger('change'), 2000);
                        }

                        let task_staffs = [];

                        try {
                            task_staffs = JSON.parse(com.assign_staffs).map(id => id.toString().trim());
                        } catch (e) {}
                        $('#task_staffs').val(task_staffs || '').change();

                        $('#task_desc').val(com.task_desc);
                        // if(com.billable==1){
                        //     $('#billablle_task').prop('checked', true);
                        // }else{
                        //     $('#billablle_task').prop('checked', false);
                        // }

                    } else {
                        // console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    // console.error('Error:', error);
                });
        }


        function updateEndDate() {
            const workingHoursSelect = document.getElementById('workingHours');
            const startDateInput = document.getElementById('task_st_dt_tm');
            const endDateInput = document.getElementById('assigned_end_date');
            const workingHours = parseFloat(workingHoursSelect.value);
            const startDateStr = startDateInput.value;

            if (!workingHours || !startDateStr) {
                endDateInput.value = '';
                return;
            }

            // Parse the start date from input (should be ISO format or flatpickr format)
            const startDate = new Date(startDateStr);

            if (isNaN(startDate)) {
                endDateInput.value = 'Invalid Start Date';
                return;
            }

            // Calculate end date by adding working hours (in milliseconds)
            const endDate = new Date(startDate.getTime() + workingHours * 60 * 60 * 1000);

            // Format endDate as "d-M-Y h:i A"
            const day = String(endDate.getDate()).padStart(2, '0');
            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            const month = monthNames[endDate.getMonth()];
            const year = endDate.getFullYear();

            let hours = endDate.getHours();
            const minutes = String(endDate.getMinutes()).padStart(2, '0');
            const ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // convert 0 to 12
            const formattedHours = String(hours).padStart(2, '0');

            const formattedEndDate = `${day}-${month}-${year} ${formattedHours}:${minutes} ${ampm}`;

            $('#assigned_end_date').val(formattedEndDate);
            $('#assigned_end_date_hidden').val(formattedEndDate);
        }
    </script>
    <script>
        function AddvalidateForm() {
            let isValid = 0;
            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'task_name',
                    name: 'Task Name'
                },
                {
                    id: 'workingHours',
                    name: 'Working Hours'
                },
                {
                    id: 'task_st_dt_tm',
                    name: 'Assigned Start Date'
                },
                {
                    id: 'task_per_hr_task',
                    name: 'Per Hour Cost'
                },
                {
                    id: 'task_staffs',
                    name: 'Staff'
                },
                {
                    id: 'task_check_list',
                    name: 'Checklist'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            if (isValid == 0) {
                $('#add_form').submit();
            }
        }
    </script>
    <script>
        function delete_confirm() {

            var delete_id = document.querySelector('#kt_modal_delete_task .btn-danger').getAttribute('data-id');

            fetch('/task_delete/' + delete_id, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Task Deleted successfully!');
                        location.reload();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function date_fill_issue_rpt() {
            var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
            var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
            var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
            var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
            var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
            var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
            var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
            var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
            var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

            if (dt_fill_issue_rpt == "today") {
                today_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "week") {
                today_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "block";
                week_to_dt_iss_rpt.style.display = "block";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";

                var curr = new Date; // get current date
                var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                var last = first + 6; // last day is the first day + 6

                var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                firstday = firstday.split("-").reverse().join("-");
                var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                lastday = lastday.split("-").reverse().join("-");
                $('#week_from_date_fil').val(firstday);
                $('#week_to_date_fil').val(lastday);

            } else if (dt_fill_issue_rpt == "monthly") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "block";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else if (dt_fill_issue_rpt == "custom_date") {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "block";
                to_dt_iss_rpt.style.display = "block";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            } else {
                today_dt_iss_rpt.style.display = "none";
                monthly_dt_iss_rpt.style.display = "none";
                from_dt_iss_rpt.style.display = "none";
                to_dt_iss_rpt.style.display = "none";
                week_from_dt_iss_rpt.style.display = "none";
                week_to_dt_iss_rpt.style.display = "none";
            }
        }
    </script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "paging": false,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>

    {{-- ! Date Picker Script --}}
    <script>
        $(document).ready(function() {
            var isRtl = false; // Define this as needed
            if ($('.area_andarkottaram').length) {
                $('.area_andarkottaram').datepicker({
                    todayHighlight: true,
                    autoclose: true,
                    format: 'd-M-yyyy',
                    orientation: isRtl ? 'auto right' : 'auto left'
                });
            }
        });
    </script>


    {{-- ! Update Edit Task --}}
    <script>
        let isProgrammaticChange = false;
        let isTaskChange = false;

        function fetchEditTaskService(preselectServiceId = '', callback = null) {
            if (isProgrammaticChange) return;
            $('#edit_task_id').empty();
            $.ajax({
                url: `/get_customer_services`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var services = response.data;
                        const serviceContainer = $('#edit_task_service');
                        $('#edit_task_id').val('');
                        serviceContainer.empty();

                        serviceContainer.append(`<option value="">Select Service</option>`);
                        services.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.cus_name} - ${service.customer_id} - ${service.product_name}</option>`
                            );
                        });

                        // Set preselected value if provided
                        isTaskChange = true;
                        if (preselectServiceId) {
                            serviceContainer.val(preselectServiceId).trigger('change');
                        }
                        isTaskChange = false;

                        // Use the correct callback variable name
                        if (callback && typeof callback === 'function') {
                            callback();
                        }

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }

        function fetchEditTask(taskId = '') {
            if (isTaskChange) return;
            var serviceId = $('#edit_task_service').val();
            var staffId = $('#edit_task_staff').val();
            $.ajax({
                url: `/task_data_fetch/${serviceId}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var tasks = response.data;
                        const taskContainer = $('#edit_task_id');
                        taskContainer.empty();

                        taskContainer.append(`<option value="">Select Task</option>`)
                        tasks.forEach(task => {
                            taskContainer.append(
                                `<option value="${task.sno}">${task.task_name} - ${task.task_id}</option>`
                            );
                        });
                        taskContainer.val(taskId).trigger('change');

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }

        function updateEditTask(sno) {
            $.ajax({
                url: `/edit_daily_task/${sno}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var edit = response.data;

                        // Staff Data Fetch
                        $.ajax({
                            url: `/production_staff_data_fetch`,
                            method: 'GET',
                            success: function(response) {
                                if (response.status === 200) {

                                    $('#edit_daily_task_sno').val(edit.sno);

                                    var staffs = response.data;
                                    const staffContainer = $('#edit_task_staff');
                                    staffContainer.empty();

                                    staffContainer.append(`<option value="">Select Staff</option>`)
                                    staffs.forEach(staff => {
                                        staffContainer.append(
                                            `<option value="${staff.sno}">${staff.staff_name} - ${staff.department_name}</option>`
                                        );
                                    });

                                    isProgrammaticChange = true;
                                    staffContainer.val(edit.staff_id).trigger('change');
                                    isProgrammaticChange = false;

                                } else {
                                    console.error(`Error Fetching Data : ${response.error_msg}`);
                                }
                            },
                            error: function(Err) {
                                console.error(`Error Fetching Data : ${Err}`);
                            }
                        });

                        fetchEditTaskService(edit.service_id, function() {
                            fetchEditTask(edit.task_id);
                        });

                    } else {
                        console.error(`Error Fetching Data : ${response.error_msg}`);
                    }
                },
                error: function(Err) {
                    console.error(`Error Fetching Data : ${Err}`);
                }
            });
        }
    </script>

    {{-- ! Edit Task Validation --}}
    <script>
        function editValidation() {
            var staffId = $('#edit_task_staff').val();
            var serviceId = $('#edit_task_service').val();
            var taskId = $('#edit_task_id').val();
            var dailyId = $('#edit_daily_task_sno').val();
            let isValid = true;

            $('#edit_task_err', '#edit_task_service_err', '#edit_task_staff_err').text('');

            if (!staffId) {
                isValid = false;
                $('#edit_task_staff_err').text('Staff is required.');
            }

            if (!serviceId) {
                isValid = false;
                $('#edit_task_service_err').text('Service is required.');
            }

            if (!taskId) {
                isValid = false;
                $('#edit_task_err').text('Task is required.');
            }

            if (!isValid) {
                return false;
            } else {

                var postData = {
                    staff_id: staffId,
                    service_id: serviceId,
                    task_id: taskId,
                    sno: dailyId,
                };

                $.ajax({
                    url: `/update_daily_tasks`,
                    method: 'POST',
                    data: postData,
                    headers: {
                        'X-CSRF-Token': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Daily Task Updated Successfully!');
                            location.reload();
                        } else {
                            toastr.error('Daily Task Updation Failed!');
                        }
                    },
                    error: function(Err) {
                        console.error(`Error Updating Data : ${Err}`);
                    }
                });
            }

            return true;
        }
    </script>

    {{-- ! Task Log Data Fetch --}}
    <script>
        function fetchTaskLog(id, staffId) {
            $.ajax({
                url: `/fetch_task_log/${id}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var tbody = '';

                        $.each(response.data, function(index, logs) {

                            var start = formatDateTime(logs.start_time);
                            var end = formatDateTime(logs.end_time);

                            tbody += '<tr>';
                            tbody += `<td class="px-3 py-2">${index + 1}</td>`;
                            tbody += `<td class="px-3 py-2">
                            <span class="badge text-white fs-6 fw-semibold mb-2" style="background:rgb(149 0 24) !important">${start.date} ${start.time}</span><br>
                        </td>`;
                            tbody += `<td class="px-3 py-2">
                            <span class="badge text-black fs-6 fw-semibold mb-2" style="background:#EEEE82 !important">${end.date} ${end.time}</span><br>
                        </td>`;
                            tbody +=
                                `<td class="px-3 py-2 fs-5 fw-bold" style="color: #4361ee !important;">${formatTime(logs.duration)}</td>`;
                            tbody += '</tr>';
                        });
                        $('#task_log_tr_data').html(tbody);
                        $('#task_log_tsk_name').html(response.task_name.task_name);
                    } else {
                        console.error('Task Log Fetched Failed');
                    }
                },
                error: function(err) {
                    console.error('Task Log Fetched Failed');
                }
            });
        }

        function formatDateTime(dateTimeStr) {
            var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            ];
            var dateObj = new Date(dateTimeStr.replace(' ', 'T')); // convert to ISO format

            var day = String(dateObj.getDate()).padStart(2, '0');
            var month = months[dateObj.getMonth()];
            var year = dateObj.getFullYear();

            var hours = dateObj.getHours();
            var minutes = String(dateObj.getMinutes()).padStart(2, '0');

            var ampm = hours >= 12 ? 'PM' : 'AM';
            hours = hours % 12;
            hours = hours ? hours : 12; // hour '0' should be '12'
            var hoursStr = String(hours).padStart(2, '0');

            return {
                date: `${day}-${month}-${year}`,
                time: `${hoursStr}:${minutes} ${ampm}`
            };
        }

        function formatTime(timeStr) {
            const [hours, minutes, seconds] = timeStr.split(':').map(Number);

            let result = [];

            if (hours > 0) {
                result.push(`${hours} hour${hours !== 1 ? 's' : ''}`);
            }
            if (minutes > 0) {
                result.push(`${minutes} minute${minutes !== 1 ? 's' : ''}`);
            }
            if (seconds > 0) {
                result.push(`${seconds} second${seconds !== 1 ? 's' : ''}`);
            }

            // If all are zero, return '0 seconds' or whatever you prefer
            if (result.length === 0) {
                return '0 seconds';
            }

            return result.join(' ');
        }

        function reworkDetails(id, staffId) {
            $.ajax({
                url: `/rework_details/${id}/${staffId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        $('#rework_details_container').html(response.data);
                        $('#task_log_tsk_name').html(response.task_name);
                    } else {
                        console.error('Rework History Fetched Failed');
                    }
                },
                error: function(err) {
                    console.error('Rework History Fetched Failed');
                }
            });
        }
    </script>

    <!-- TIMER SCRIPT -->
    <script>
        // var refreshIntervalId;
        // var elapsedSeconds = 0;

        function endTaskModal(staff_id, task_id, isJournal, isRequest) {
            $('.timer_list_div').show();

            if (isJournal) {
                journalTaskDataFetch(task_id);
                $('#kt_modal_journal_verification').modal('show');
                $('#kt_modal_journal_verification').data('staff_id', staff_id);
                $('#kt_modal_journal_verification').data('task_id', task_id);
            } else if (isRequest) {
                journalTaskDataFetch(task_id, 1);
                $('#kt_modal_journal_verification').modal('show');
                $('#kt_modal_journal_verification').data('staff_id', staff_id);
                $('#kt_modal_journal_verification').data('task_id', task_id);
            } else {
                completeTaskDataFetch(task_id);
                $('#kt_modal_complete_task').modal('show');
                $('#kt_modal_complete_task').data('staff_id', staff_id);
                $('#kt_modal_complete_task').data('task_id', task_id);
            }
        }

        function stoptaskTimer(isJournal = false) {
            if (isJournal) {
                var staff_id = $('#kt_modal_journal_verification').data('staff_id');
                var task_id = $('#kt_modal_journal_verification').data('task_id');
            } else {
                var staff_id = $('#kt_modal_complete_task').data('staff_id');
                var task_id = $('#kt_modal_complete_task').data('task_id');
            }

            $.ajax({
                url: '/task-log/stop',
                method: 'POST',
                data: {
                    task_id: task_id,
                    staff_id: staff_id,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    console.log('Timer stopped:', response);
                    toastr.success('Timer stopped successfully!');
                    fetchElapsedTimeFromServer2()
                    fetch('/manage_task/task_table/', {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json(); // we expect JSON now
                        })
                        .then(data => {
                            if (data && data.data) {
                                $('#task_table_body').empty().append(data.data);
                                $('[data-bs-toggle="tooltip"]')
                                    .tooltip(); // re-initialize tooltips after HTML is added
                            } else {
                                console.log('No data received');
                            }
                        })
                        .catch(error => {
                            console.log('Error:', error);
                        });
                    // Update UI or stop frontend timer here
                },
                error: function(xhr) {
                    console.error('Stop timer error:', xhr.responseText);
                }
            });
        }

        function starttaskTimer(staff_id, task_id, isJournal, isrequest) {
            // var display = document.querySelector('#tsk_timer');
            var whom = staff_id;

            $.ajax({
                url: '/task-log/start',
                method: 'POST',
                data: {
                    task_id: task_id,
                    staff_id: staff_id,
                    is_journal: isJournal ? 1 : 0,
                    is_request: isrequest ? 1 : 0,
                    _token: $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    // console.log('Timer started:', response);
                    // Start frontend timer or update UI
                    toastr.success('Timer started successfully!');
                    // location.reload();
                    fetchElapsedTimeFromServer2()
                    fetch('/manage_task/task_table/', {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            }
                        })
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('Network response was not ok');
                            }
                            return response.json(); // we expect JSON now
                        })
                        .then(data => {
                            if (data && data.data) {
                                $('[data-bs-toggle="tooltip"]').tooltip('dispose');
                                $('#task_table_body').empty().append(data.data);
                                $('[data-bs-toggle="tooltip"]').tooltip();
                            } else {
                                console.log('No data received');
                            }
                        })
                        .catch(error => {
                            console.log('Error:', error);
                        });
                    // $('.timer_list_div').hide();
                    // $('#timer_list_div_id'+staff_id+'_'+task_id).show();
                    // document.getElementById("task_st_timer_list" + whom + '_' + task_id).style.display = "none";
                    // document.getElementById("task_timer_hd_nav").style.display = "inline";
                    // document.getElementById("task_st_timer_icn_nav").style.display = "none";
                    // document.getElementById("task_ed_timer_icn_nav").style.display = "block";
                },
                error: function(xhr) {
                    if (xhr.status === 409) {
                        const res = xhr.responseJSON;
                        toastr.error(res.message || 'A timer is already running for another task.');

                    } else {
                        toastr.error('An error occurred while starting the timer.');
                        console.error('Start timer error:', xhr.responseText);
                    }
                }
            });
        }

        function task_timer_func(val, whom, task_id, isJournal = false, isrequest = false) {
            if (val == 'start_timer') {
                starttaskTimer(whom, task_id, isJournal, isrequest);
            } else {
                endTaskModal(whom, task_id, isJournal, isrequest);
            }
        }
    </script>

    <script>
        const display = document.querySelector('#tsk_timer_button');
        const taskcsrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        let elapsedSeconds = 0;
        let timerIntervalId = null;
        let syncIntervalId = null;

        function updateDisplay(seconds) {
            let hours = Math.floor(seconds / 3600);
            let minutes = Math.floor((seconds % 3600) / 60);
            let secondsR = seconds % 60;
            let hh = hours < 10 ? "0" + hours : hours;
            let mm = minutes < 10 ? "0" + minutes : minutes;
            let ss = secondsR < 10 ? "0" + secondsR : secondsR;

            if (display) {
                if (seconds < 60) {
                    display.textContent = ss + ' sec';
                } else if (seconds < 3600) {
                    display.textContent = mm + ":" + ss;
                } else {
                    display.textContent = hh + ":" + mm + ":" + ss;
                }
            }
        }

        function startTimer2() {
            // Clear existing interval if any
            if (timerIntervalId) clearInterval(timerIntervalId);
            if (syncIntervalId) clearInterval(syncIntervalId);

            // Start local UI timer
            timerIntervalId = setInterval(function() {
                elapsedSeconds++;
                updateDisplay(elapsedSeconds);
            }, 1000);

            // Periodically sync with server (every 6 seconds)
            syncIntervalId = setInterval(fetchElapsedTimeFromServer2, 6000);
        }

        function stopTimer2() {
            clearInterval(timerIntervalId);
            clearInterval(syncIntervalId);
            timerIntervalId = null;
            syncIntervalId = null;
        }

        function fetchElapsedTimeFromServer2() {
            fetch('/task-log/running', {
                    method: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': taskcsrfToken,
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {
                    if (data.running && data.elapsed_seconds >= 0) {
                        elapsedSeconds = data.elapsed_seconds;

                        // UI updates
                        $('#task_timer_hd_nav').show();
                        document.getElementById("task_st_timer_icn_nav").style.display = "none";
                        document.getElementById("task_ed_timer_icn_nav").style.display = "block";

                        // if (!timerIntervalId) {
                        startTimer2(); // Only start if not already started
                        // }

                    } else {
                        stopTimer2();
                        display.textContent = '';
                        $('#task_timer_hd_nav').hide();
                        document.getElementById("task_st_timer_icn_nav").style.display = "block";
                        document.getElementById("task_ed_timer_icn_nav").style.display = "none";
                    }
                })
                .catch(error => {
                    console.error('Timer sync failed:', error);
                });
        }
    </script>

    {{-- ! Complete Task Data Fetch --}}
    <script>
        function completeTaskDataFetch(id) {
            $.ajax({
                url: `/complete_task_data_fetch/${id}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        $('#range_move_err').text('');
                        var data = response.data;
                        $('#checklist_container').hide();

                        $('#comp_tsk_tsk_name').html(data.task_name);
                        $('#com_tsk_created_staff').html(data.pc_name);
                        $('#com_tsk_tsk_id').html(`# ${data.tsk_id}`);
                        $('#com_tsk_cus_name').html(data.cus_name);
                        $('#com_tsk_cus_id').html(`(${data.cus_id})`);
                        $('#com_tsk_cus_mobile').html(data.cus_mobile);
                        $('#com_task_pro_name').html(data.product_name);
                        $('#com_task_cat_name').html(data.product_category_name);
                        $('#com_tsk_variant_name').html(data.variant_name);
                        $('#com_tsk_variable_name').html(data.variable_name);
                        $('#com_tsk_tsk_desc').html(data.task_desc ? data.task_desc :
                            'No Description is given.');
                        $('#com_tsk_pro_staff_name').html(data.pro_staff_name);
                        $('#com_tsk_pro_nick_name').html(data.pro_nick_name);
                        $('#com_tsk_job_pos').html(data.job_position_name);
                        $('#com_tsk_staff_img').html(response.image);
                        $('#time-logs-container').html(response.html);
                        $('#total_time').html(response.total_time);

                        $('#task_status_id').val(data.sno);
                        $('#checklist_task_id').val(data.task_id);

                        // Get range input and update attributes
                        const rangeInput = document.getElementById('formRangeMax');
                        const currentValueDisplay = document.getElementById('currentValue');
                        const rangeMin = parseInt(data.min_page_or_per) || 0;
                        const rangeMax = parseInt(data.max_page_or_per) || 10;

                        rangeInput.min = rangeMin;
                        rangeInput.max = rangeMax;

                        // Reset value if current is outside new bounds
                        if (parseInt(rangeInput.value) < rangeMin || parseInt(rangeInput.value) > rangeMax) {
                            rangeInput.value = rangeMin;
                        }

                        // Update value display
                        currentValueDisplay.textContent = `${rangeInput.value}`;

                        // Update page labels
                        const rangeLabels = rangeInput.nextElementSibling; // .d-flex container
                        if (rangeLabels) {
                            const spans = rangeLabels.querySelectorAll('span');
                            if (spans.length === 2) {
                                spans[0].textContent =
                                    `${rangeMin}${data.task_category == 1 ? ' %' : ' Pages'}`;
                                spans[1].textContent =
                                    `${rangeMax}${data.task_category == 1 ? ' %' : ' Pages'}`;
                            }
                        }

                        // Update display on input change
                        rangeInput.addEventListener('input', function() {
                            currentValueDisplay.textContent = `${this.value}`;
                        });
                    }
                },
                error: function(xhr) {
                    console.error(`Error Fetching Data : ${xhr}`);
                }
            });
        }
    </script>

    <!-- Journal Task Data Fetch -->
    <script>
        let workMonitorSlider;
        let workMonitorCurrentValue = 0;
        let maxJournalTaskValue = 100;

        function journalTaskDataFetch(id, status = 0) {

            if (!id) return;

            $.ajax({
                url: `/journal_task_data_fetch/${id}/${status}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;

                        $('#journalTaskID').val(id);
                        $('#journalHiddenStatus').val(status);
                        $('#journalPaperName').html(data.paper_name);
                        $('#journalJournalId').html(data.journal_id);
                        $('#journalServiceName').html(data.product_name);
                        $('#journalServiceId').html(data.formatted_service_id);
                        $('#journalTLName').html(data.jtl_name);
                        $('#journalStaffName').html(data.jc_name);
                        $('#journalRevisionComments').html(data.comments);

                        const minValue = data.min_page_or_per || 0;
                        $('#journalMinValueHTML').html(`${minValue}%`);
                        $('#journalHiddenMinValue').val(minValue);

                        workMonitorSlider = document.getElementById('workMonitorSlider');

                        if (workMonitorSlider) {
                            noUiSlider.create(workMonitorSlider, {
                                start: [minValue], // start at 0%
                                connect: [true, false],
                                direction: isRtl ? 'rtl' : 'ltr',
                                range: {
                                    min: minValue,
                                    max: maxJournalTaskValue
                                }
                            });

                            // Update percentage when sliding
                            workMonitorSlider.noUiSlider.on('update', function(values) {
                                workMonitorCurrentValue = Math.round(values[0]);
                                $('#workMonitorValue').html(workMonitorCurrentValue + '%');
                            });
                        }
                    } else {
                        console.error('Something Went Wrong.');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching Due To :' + err);
                }
            })
        }
    </script>

    <!-- Journal Task Validation -->
    <script>
        function journalTaskValidation() {
            const minValue = $('#journalHiddenMinValue').val();
            const journalStatus = $('#journalHiddenStatus').val();

            if (!workMonitorSlider || workMonitorCurrentValue === null) {
                $('#journalTaskProgressErr').html('Progress Slider Not Initialized.');
                return false;
            }

            // Validate value
            if (workMonitorCurrentValue <= minValue) {
                $('#journalTaskProgressErr').html(`Update Progress Summary above ${minValue}%.`);
                return false;
            }

            if (workMonitorCurrentValue > maxJournalTaskValue) {
                $('#journalTaskProgressErr').html('Invalid progress value');
                return false;
            }

            const formData = {
                num_pages: workMonitorCurrentValue,
                max_pages: maxJournalTaskValue,
                status: workMonitorCurrentValue === maxJournalTaskValue ? 3 : null,
                is_journal: journalStatus,
            };

            const sno = $('#journalTaskID').val();

            $.ajax({
                url: `/update_task_status/${sno}`,
                method: 'POST',
                data: formData,
                headers: {
                    'X-CSRF-TOKEN': '{{ csrf_token() }}'
                },
                success: function(response) {
                    if (response.status === 200) {
                        stoptaskTimer(true)
                        if (workMonitorCurrentValue === maxJournalTaskValue) {
                            toastr.success('Task marked as complete!');
                            location.reload();
                        } else {
                            toastr.success('Task updated successfully!');
                            location.reload();
                        }
                    } else {
                        toastr.error('Task Updation Failed!');
                    }
                },
                error: function(err) {
                    console.error('Task Creation Failed');
                }
            });

            return true;
        }
    </script>

    {{-- ! Checklist Hide & Show --}}
    <script>
        function checklistShow() {
            $('#checklist_container').hide();
            var rangeInput = document.getElementById('formRangeMax');
            var currentValue = parseInt(rangeInput.value);
            var maxValue = parseInt(rangeInput.max);

            if (currentValue === maxValue) {
                fetchTaskCompletedChecklist()
                $('#checklist_container').show();
            }
        }
    </script>

    {{-- ! Update Task Validation --}}
    <script>
        function updateTaskValidation() {
            var rangeInput = document.getElementById('formRangeMax');
            var minValue = parseInt(rangeInput.min);
            var currentValue = parseInt(rangeInput.value);
            var maxValue = parseInt(rangeInput.max);
            $('#range_move_err').text('');

            if (currentValue === minValue) {
                $('#range_move_err').text('Complete at least one full page before providing an update on the task.');
                return false;
            } else {
                var sno = $('#task_status_id').val();

                const formData = {
                    num_pages: currentValue,
                    max_pages: maxValue,
                    status: currentValue === maxValue ? 3 : null,
                    task_desc: $('#taskDesc').val()
                };

                if (currentValue === maxValue) {
                    var checklistIds = [];
                    $('.task_chk_box:checked').each(function() {
                        checklistIds.push($(this).val());
                    });

                    var taskId = $('#checklist_task_id').val();

                    formData.task_id = taskId;
                    formData.checklist_ids = checklistIds;
                }

                $.ajax({
                    url: `/update_task_status/${sno}`,
                    method: 'POST',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            stoptaskTimer()
                            if (currentValue === maxValue) {
                                toastr.success('Task marked as complete!');
                                location.reload();
                            } else {
                                toastr.success('Task updated successfully!');
                                location.reload();
                            }
                        } else {
                            toastr.error('Task Updation Failed!');
                        }
                    },
                    error: function(err) {
                        console.error('Task Creation Failed');
                    }
                });
            }

            return true;
        }
    </script>

    {{-- ! Task Completed Checklist Data Fetch --}}
    <script>
        function fetchTaskCompletedChecklist() {
            var taskId = $('#checklist_task_id').val();
            $.ajax({
                url: `/fetch_production_checklist/${taskId}`,
                method: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        var checklists = response.data;
                        var checklistContainer = $('#task_check_fetch_container');
                        checklistContainer.empty();

                        checklists.forEach(check => {
                            checklistContainer.append(
                                `<div class="checklist-item d-flex align-items-center p-3 border-bottom">
                                <div class="form-check mb-0 flex-grow-1">
                                    <input class="form-check-input task_chk_box" type="checkbox" name="task_check_list[]" value="${check.sno}">
                                    <label class="form-check-label text-dark fw-semibold fs-6 ms-2" for="check_1">
                                        ${check.task_checklist}
                                    </label>
                                </div>
                            </div>`
                            );
                        });
                        console.log(checklists);
                    } else {
                        console.error('Task Fetching Failed');
                    }
                },
                error: function(err) {
                    console.error('Task Fetching Failed');
                }
            });
        }
    </script>

    <!-- Journal Upload Data Fetch -->
    <script>
        function journalUploadDataFetch(sno, status = 0) {
            if (!sno) return;

            $.ajax({
                url: `/journal_task_data_fetch/${sno}/${status}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;

                        $('#fileUploadTaskID').val(sno);
                        $('#fileUploadHidStatus').val(status);
                        $('#fileUploadPaperName').html(data.paper_name);
                        $('#fileUploadJournalId').html(data.journal_id);
                        $('#fileUploadServiceName').html(data.product_name);
                        $('#fileUploadServiceId').html(data.formatted_service_id);
                        $('#fileUploadJTLName').html(data.jtl_name);
                        $('#fileUploadJCName').html(data.jc_name);
                        $('#fileUploadComments').html(data.comments);
                    } else {
                        console.error('Something Went Wrong.');
                    }
                },
                error: function() {
                    console.error('Servor Error.');
                }
            })
        }
    </script>

    <!-- File Upload Dropzone CSS -->
    <style>
        :root {
            --primary-blue: #3b82f6;
            --primary-blue-hover: #2563eb;
            --success-green: #10b981;
            --danger-red: #ef4444;
            --light-gray: #f8fafc;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-dark: #1e293b;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --radius-lg: 12px;
            --radius-md: 8px;
            --radius-sm: 6px;
            --transition: all 0.2s ease;
        }

        .upload-container {
            margin-top: 8px;
        }

        .upload-label {
            display: block;
            color: var(--text-dark);
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .upload-label .optional {
            color: var(--dark-gray);
            font-weight: 400;
            font-size: 13px;
            margin-left: 4px;
        }

        .drop-area {
            border: 2px dashed var(--medium-gray);
            border-radius: var(--radius-lg);
            padding: 48px 32px;
            text-align: center;
            position: relative;
            background-color: var(--light-gray);
            transition: var(--transition);
            cursor: pointer;
            overflow: hidden;
        }

        .drop-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: inherit;
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(59, 130, 246, 0) 100%);
            opacity: 0;
            transition: var(--transition);
        }

        .drop-area:hover {
            border-color: var(--primary-blue);
            background-color: #f0f9ff;
            transform: translateY(-1px);
            box-shadow: var(--shadow-md);
        }

        .drop-area:hover::before {
            opacity: 1;
        }

        .drop-area.drag-over {
            border-color: var(--primary-blue);
            background-color: #e0f2fe;
            transform: translateY(-1px);
            box-shadow: var(--shadow-lg);
        }

        .drop-area.drag-over::before {
            opacity: 1;
        }

        .drop-message {
            color: var(--dark-gray);
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            pointer-events: none;
        }

        .upload-icon {
            margin-bottom: 16px;
            color: var(--dark-gray);
            transition: var(--transition);
        }

        .drop-area:hover .upload-icon {
            color: var(--primary-blue);
            transform: scale(1.05);
        }

        .upload-icon svg {
            width: 48px;
            height: 48px;
            stroke-width: 1.5;
        }

        .upload-text {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
            color: var(--text-dark);
        }

        .upload-subtext {
            font-size: 14px;
            color: var(--dark-gray);
            margin-bottom: 0;
        }

        .clickable {
            color: var(--primary-blue);
            font-weight: 600;
            text-decoration: none;
            transition: var(--transition);
        }

        .clickable:hover {
            color: var(--primary-blue-hover);
            text-decoration: underline;
        }

        .file-input {
            display: none;
        }

        .preview-container {
            margin-top: 24px;
        }

        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
            padding-bottom: 12px;
            border-bottom: 1px solid var(--medium-gray);
        }

        .preview-title {
            font-size: 15px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .preview-title .badge {
            background-color: var(--primary-blue);
            color: white;
            font-size: 12px;
            padding: 2px 8px;
            border-radius: 12px;
            font-weight: 500;
        }

        .clear-all-btn {
            background: none;
            border: none;
            color: var(--danger-red);
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .clear-all-btn:hover {
            background-color: #fee2e2;
        }

        .preview-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 16px;
            margin-top: 0;
            overflow-y: scroll;
            max-height: 231px;
        }

        .preview-item {
            border: 1px solid var(--medium-gray);
            border-radius: var(--radius-md);
            background: white;
            box-shadow: var(--shadow-sm);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 16px;
            position: relative;
            transition: var(--transition);
            overflow: hidden;
        }

        .preview-item:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
            border-color: var(--primary-blue);
        }

        .preview-thumb-container {
            width: 100%;
            height: 100px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            background-color: #f8fafc;
        }

        .preview-thumb {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .file-icon {
            width: 48px;
            height: 48px;
            color: var(--dark-gray);
        }

        .file-icon svg {
            width: 100%;
            height: 100%;
        }

        .preview-filename {
            font-weight: 500;
            text-align: center;
            margin-bottom: 6px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            width: 100%;
            font-size: 14px;
            color: var(--text-dark);
        }

        .preview-size {
            color: var(--dark-gray);
            font-size: 12px;
            margin-bottom: 12px;
        }

        .progress-container {
            width: 100%;
        }

        .progress-bar {
            width: 100%;
            height: 4px;
            background-color: var(--medium-gray);
            border-radius: 2px;
            overflow: hidden;
            margin-bottom: 8px;
        }

        .progress-bar-inner {
            height: 100%;
            width: 0;
            background: linear-gradient(90deg, var(--primary-blue), #60a5fa);
            transition: width 0.3s ease;
            border-radius: 2px;
        }

        .progress-text {
            font-size: 11px;
            color: var(--dark-gray);
            text-align: center;
            font-weight: 500;
        }

        .remove-btn {
            position: absolute;
            top: 8px;
            right: 8px;
            background: white;
            border: 1px solid var(--medium-gray);
            border-radius: 50%;
            color: var(--dark-gray);
            font-weight: bold;
            width: 28px;
            height: 28px;
            cursor: pointer;
            line-height: 26px;
            text-align: center;
            padding: 0;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.8;
        }

        .remove-btn:hover {
            background-color: var(--danger-red);
            color: white;
            border-color: var(--danger-red);
            opacity: 1;
            transform: scale(1.1);
        }

        .file-status {
            position: absolute;
            top: 8px;
            left: 8px;
            font-size: 10px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-uploading {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-success {
            background-color: #d1fae5;
            color: #065f46;
        }

        .status-error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .file-type-badge {
            position: absolute;
            bottom: 8px;
            right: 8px;
            background-color: rgba(0, 0, 0, 0.7);
            color: white;
            font-size: 10px;
            padding: 2px 6px;
            border-radius: 4px;
            text-transform: uppercase;
            font-weight: 500;
        }

        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 48px 32px;
            color: var(--dark-gray);
            background-color: var(--light-gray);
            border-radius: var(--radius-md);
            border: 1px dashed var(--medium-gray);
        }

        .empty-icon {
            font-size: 32px;
            margin-bottom: 16px;
            opacity: 0.5;
        }

        .empty-text {
            font-size: 14px;
            color: var(--dark-gray);
        }

        @media (max-width: 640px) {
            .drop-area {
                padding: 32px 16px;
            }

            .preview-list {
                grid-template-columns: 1fr;
            }

            .upload-text {
                font-size: 15px;
            }

            .upload-subtext {
                font-size: 13px;
            }
        }

        /* Add to your existing CSS */
        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes pulse {
            0% {
                opacity: 0.6;
            }

            50% {
                opacity: 1;
            }

            100% {
                opacity: 0.6;
            }
        }

        .drive-step.active {
            background: #e8f0fe !important;
            border-left-color: #1a73e8 !important;
        }

        .drive-step.active .step-icon {
            background: #1a73e8 !important;
            color: white !important;
        }

        .drive-step.completed {
            background: #e6f4ea !important;
            border-left-color: #34a853 !important;
        }

        .drive-step.completed .step-icon {
            background: #34a853 !important;
            color: white !important;
        }

        #uploadJournalFilesBtn.loading {
            position: relative;
            color: transparent !important;
            pointer-events: none;
        }

        #uploadJournalFilesBtn.loading::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 20px;
            height: 20px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: button-spin 0.8s linear infinite;
        }

        @keyframes button-spin {
            to {
                transform: translate(-50%, -50%) rotate(360deg);
            }
        }
    </style>

    <!-- File Upload Dropzone JS -->
    <script>
        const dropArea = document.getElementById("dropArea");
        const fileInput = document.getElementById("fileInput");
        const previewList = document.getElementById("previewList");
        const previewContainer = document.getElementById("previewContainer");
        const dropMessage = document.getElementById("dropMessage");
        const fileCount = document.getElementById("fileCount");
        const clearAllBtn = document.getElementById("clearAllBtn");
        let uploadedFiles = [];

        // File type icons mapping
        const fileIcons = {
            pdf: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15 13.5H9m6 3H9m3-6h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>`,
            doc: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" />
                </svg>`,
            image: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                </svg>`,
            default: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" />
                    </svg>`
        };

        // Get file icon based on type
        function getFileIcon(file) {
            if (file.type.startsWith('image/')) return fileIcons.image;
            if (file.type === 'application/pdf') return fileIcons.pdf;
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return fileIcons.doc;
            return fileIcons.default;
        }

        // Get file type for badge
        function getFileType(file) {
            if (file.type.startsWith('image/')) return 'IMG';
            if (file.type === 'application/pdf') return 'PDF';
            if (file.type.includes('document') || file.name.match(/\.(doc|docx)$/i)) return 'DOC';
            return file.name.split('.').pop().toUpperCase();
        }

        // Make whole drop area clickable
        dropArea.addEventListener("click", () => fileInput.click());

        dropArea.addEventListener("dragover", e => {
            e.preventDefault();
            dropArea.classList.add("drag-over");
        });

        dropArea.addEventListener("dragleave", e => {
            e.preventDefault();
            dropArea.classList.remove("drag-over");
        });

        dropArea.addEventListener("drop", e => {
            e.preventDefault();
            dropArea.classList.remove("drag-over");
            if (e.dataTransfer.files.length) {
                handleFiles(e.dataTransfer.files);
            }
        });

        fileInput.addEventListener("change", e => {
            if (e.target.files.length) {
                handleFiles(e.target.files);
            }
        });

        // Clear all files
        clearAllBtn.addEventListener("click", async (e) => {
            e.preventDefault();
            e.stopPropagation();

            // Disable button to prevent double clicks
            clearAllBtn.disabled = true;

            for (const file of uploadedFiles) {
                if (file.stored_name) {
                    await removeFileFromServer(file.stored_name);
                }
            }

            // Clear UI
            previewList.innerHTML = '';
            uploadedFiles = [];
            updateFileCount();
            previewContainer.style.display = 'none';
            dropMessage.style.display = 'block';
            document.getElementById("uploaded_files").value = JSON.stringify([]);

            clearAllBtn.disabled = false;
        });

        function humanFileSize(size) {
            const i = size === 0 ? 0 : Math.floor(Math.log(size) / Math.log(1024));
            return (size / Math.pow(1024, i)).toFixed(2) + " " + ["B", "KB", "MB", "GB", "TB"][i];
        }

        function updateFileCount() {
            fileCount.textContent = uploadedFiles.length;
        }

        function handleFiles(files) {
            dropMessage.style.display = "none";
            previewContainer.style.display = "block";

            if (uploadedFiles.length >= 1) {
                toastr.warning('Only one file is allowed.');
                return;
            }

            // 🚫 If user drags multiple files at once
            if (files.length > 1) {
                toastr.warning('Please upload only one file.');
                return;
            }

            [...files].forEach(file => {
                if (file.size > 10 * 1024 * 1024) {
                    toastr.warning(`File "${file.name}" exceeds 10MB limit`);
                    return;
                }

                if (uploadedFiles.length >= 1) {
                    return; // hard stop
                }

                const previewItem = document.createElement("div");
                previewItem.className = "preview-item";

                // File status badge
                const statusBadge = document.createElement("div");
                statusBadge.className = "file-status status-uploading";
                statusBadge.textContent = "Uploading";
                previewItem.appendChild(statusBadge);

                // File type badge
                const typeBadge = document.createElement("div");
                typeBadge.className = "file-type-badge";
                typeBadge.textContent = getFileType(file);
                previewItem.appendChild(typeBadge);

                // Remove button
                const removeBtn = document.createElement("button");
                removeBtn.type = "button";
                removeBtn.className = "remove-btn";
                removeBtn.innerHTML = "×";
                removeBtn.onclick = async (e) => {

                    e.preventDefault(); // extra protection
                    e.stopPropagation();

                    if (confirm('Remove this file?')) {
                        const storedName = previewItem.dataset.storedName;
                        if (storedName) {
                            const success = await removeFileFromServer(storedName);
                            if (success) {
                                previewList.removeChild(previewItem);
                                uploadedFiles = uploadedFiles.filter(f => f.stored_name !== storedName);
                                updateFileCount();
                                if (uploadedFiles.length === 0) {
                                    previewContainer.style.display = "none";
                                    dropMessage.style.display = "block";
                                }
                                document.getElementById("uploaded_files").value = JSON.stringify(
                                    uploadedFiles);
                            }
                        } else {
                            // If upload was in progress, just remove from UI
                            previewList.removeChild(previewItem);
                            uploadedFiles = uploadedFiles.filter(f => f.original_name !== file.name);
                            updateFileCount();
                            if (uploadedFiles.length === 0) {
                                previewContainer.style.display = "none";
                                dropMessage.style.display = "block";
                            }
                            document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                        }
                    }
                };
                previewItem.appendChild(removeBtn);

                // Thumbnail container
                const thumbContainer = document.createElement("div");
                thumbContainer.className = "preview-thumb-container";

                if (file.type.startsWith("image/")) {
                    const img = document.createElement("img");
                    img.className = "preview-thumb";
                    const reader = new FileReader();
                    reader.onload = e => img.src = e.target.result;
                    reader.readAsDataURL(file);
                    thumbContainer.appendChild(img);
                } else {
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "file-icon";
                    fileIcon.innerHTML = getFileIcon(file);
                    thumbContainer.appendChild(fileIcon);
                }
                previewItem.appendChild(thumbContainer);

                // File name
                const nameDiv = document.createElement("div");
                nameDiv.className = "preview-filename";
                nameDiv.title = file.name;
                nameDiv.textContent = file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name;
                previewItem.appendChild(nameDiv);

                // File size
                const sizeDiv = document.createElement("div");
                sizeDiv.className = "preview-size";
                sizeDiv.textContent = humanFileSize(file.size);
                previewItem.appendChild(sizeDiv);

                // Progress container
                const progressContainer = document.createElement("div");
                progressContainer.className = "progress-container";

                const progressBar = document.createElement("div");
                progressBar.className = "progress-bar";
                const progressBarInner = document.createElement("div");
                progressBarInner.className = "progress-bar-inner";
                progressBar.appendChild(progressBarInner);
                progressContainer.appendChild(progressBar);

                const progressText = document.createElement("div");
                progressText.className = "progress-text";
                progressText.textContent = "0%";
                progressContainer.appendChild(progressText);

                previewItem.appendChild(progressContainer);

                // Add temporary file to array (will be updated after upload)
                uploadedFiles.push({
                    original_name: file.name,
                    stored_name: null, // Will be set after upload
                    path: null
                });

                // Add to preview list
                previewList.appendChild(previewItem);

                // Upload file
                uploadFile(file, progressBarInner, progressText, statusBadge, previewItem);
            });

            updateFileCount();
        }

        function uploadFile(file, progressElement, progressText, statusBadge, previewItem) {
            const url = "{{ route('upload_journal') }}";
            const formData = new FormData();
            formData.append("file_upload[]", file);

            const xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("X-CSRF-TOKEN", document.querySelector('input[name="_token"]').value);

            xhr.upload.onprogress = function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressElement.style.width = percent + "%";
                    progressText.textContent = percent + "%";
                }
            };

            xhr.onload = function() {
                if (xhr.status === 200) {
                    const res = JSON.parse(xhr.responseText);
                    if (res.success && res.files.length > 0) {
                        const uploadedFile = res.files[0];

                        // Store file info on the preview item
                        previewItem.dataset.storedName = uploadedFile.stored_name;

                        // Update the file in uploadedFiles array
                        const fileIndex = uploadedFiles.findIndex(f => f.original_name === uploadedFile.original_name);
                        if (fileIndex !== -1) {
                            uploadedFiles[fileIndex] = uploadedFile;
                        }

                        document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                        progressElement.style.background = "var(--success-green)";
                        statusBadge.className = "file-status status-success";
                        statusBadge.textContent = "Uploaded";
                        progressText.textContent = "Complete";

                        // Update the filename display to show original name
                        const nameDiv = previewItem.querySelector('.preview-filename');
                        nameDiv.textContent = uploadedFile.original_name.length > 20 ?
                            uploadedFile.original_name.substring(0, 20) + '...' : uploadedFile.original_name;
                        nameDiv.title = uploadedFile.original_name;

                        previewItem.style.borderColor = "var(--success-green)";
                        previewItem.style.boxShadow = "0 0 0 1px var(--success-green)";
                    } else {
                        handleUploadError(progressElement, statusBadge, progressText, res.message || 'Upload failed');
                    }
                } else {
                    handleUploadError(progressElement, statusBadge, progressText, 'Upload failed with status ' + xhr
                        .status);
                }
            };

            xhr.onerror = function() {
                handleUploadError(progressElement, statusBadge, progressText, 'Network error');
            };

            xhr.send(formData);
        }

        async function removeFileFromServer(fileName) {
            try {
                const response = await fetch("{{ url('/upload/temp/remove') }}", {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                    },
                    body: JSON.stringify({
                        file_name: fileName
                    }) // Note: matches your backend parameter name
                });

                const result = await response.json();

                if (result.success) {
                    return true;
                } else {
                    toastr.error(result.message || 'Failed to remove file');
                    return false;
                }
            } catch (error) {
                toastr.error(error.message || 'Error removing file');
                return false;
            }
        }

        function handleUploadError(progressElement, statusBadge, progressText, message) {
            progressElement.style.background = "var(--danger-red)";
            statusBadge.className = "file-status status-error";
            statusBadge.textContent = "Error";
            progressText.textContent = "Failed";
            toastr.error(message || 'Upload failed');
        }

        // Initialize with any existing files from hidden input
        document.addEventListener('DOMContentLoaded', () => {
            const existingFiles = JSON.parse(document.getElementById("uploaded_files").value || '[]');
            if (existingFiles.length > 0) {
                // Display already uploaded files
                previewContainer.style.display = "block";
                dropMessage.style.display = "none";

                existingFiles.forEach(file => {
                    createPreviewForExistingFile(file);
                });

                uploadedFiles = existingFiles;
                updateFileCount();
            }
        });

        function createPreviewForExistingFile(fileData) {
            const previewItem = document.createElement("div");
            previewItem.className = "preview-item";
            previewItem.dataset.storedName = fileData.stored_name;

            // File status badge
            const statusBadge = document.createElement("div");
            statusBadge.className = "file-status status-success";
            statusBadge.textContent = "Uploaded";
            previewItem.appendChild(statusBadge);

            // File type badge
            const typeBadge = document.createElement("div");
            typeBadge.className = "file-type-badge";
            const fileExt = fileData.original_name.split('.').pop().toUpperCase();
            typeBadge.textContent = ['PDF', 'DOC', 'DOCX', 'JPG', 'JPEG', 'PNG', 'GIF'].includes(fileExt) ?
                fileExt : fileExt;
            previewItem.appendChild(typeBadge);

            // Remove button
            const removeBtn = document.createElement("button");
            removeBtn.className = "remove-btn";
            removeBtn.innerHTML = "×";
            removeBtn.onclick = async () => {
                if (confirm('Remove this file?')) {
                    const storedName = fileData.stored_name;
                    const success = await removeFileFromServer(storedName);
                    if (success) {
                        previewList.removeChild(previewItem);
                        uploadedFiles = uploadedFiles.filter(f => f.stored_name !== storedName);
                        updateFileCount();
                        if (uploadedFiles.length === 0) {
                            previewContainer.style.display = "none";
                            dropMessage.style.display = "block";
                        }
                        document.getElementById("uploaded_files").value = JSON.stringify(uploadedFiles);
                    }
                }
            };
            previewItem.appendChild(removeBtn);

            // Thumbnail container
            const thumbContainer = document.createElement("div");
            thumbContainer.className = "preview-thumb-container";

            // Check if it's an image
            const isImage = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileData.original_name.split('.').pop()
                .toLowerCase());

            if (isImage && fileData.path) {
                // Try to load image from path
                const img = document.createElement("img");
                img.className = "preview-thumb";
                img.src = "{{ asset('') }}" + fileData.path;
                img.onerror = function() {
                    // If image fails to load, show file icon
                    thumbContainer.innerHTML = '';
                    const fileIcon = document.createElement("div");
                    fileIcon.className = "file-icon";
                    fileIcon.innerHTML = fileIcons.image;
                    thumbContainer.appendChild(fileIcon);
                };
                thumbContainer.appendChild(img);
            } else {
                const fileIcon = document.createElement("div");
                fileIcon.className = "file-icon";
                const fileExt = fileData.original_name.split('.').pop().toLowerCase();
                if (fileExt === 'pdf') {
                    fileIcon.innerHTML = fileIcons.pdf;
                } else if (['doc', 'docx'].includes(fileExt)) {
                    fileIcon.innerHTML = fileIcons.doc;
                } else if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'].includes(fileExt)) {
                    fileIcon.innerHTML = fileIcons.image;
                } else {
                    fileIcon.innerHTML = fileIcons.default;
                }
                thumbContainer.appendChild(fileIcon);
            }
            previewItem.appendChild(thumbContainer);

            // File name
            const nameDiv = document.createElement("div");
            nameDiv.className = "preview-filename";
            nameDiv.title = fileData.original_name;
            nameDiv.textContent = fileData.original_name.length > 20 ?
                fileData.original_name.substring(0, 20) + '...' : fileData.original_name;
            previewItem.appendChild(nameDiv);

            // File size (if available)
            const sizeDiv = document.createElement("div");
            sizeDiv.className = "preview-size";
            sizeDiv.textContent = fileData.size ? humanFileSize(fileData.size) : 'Size unknown';
            previewItem.appendChild(sizeDiv);

            previewList.appendChild(previewItem);
        }
    </script>

    <!-- Upload Files Journal -->
    <script>
        function uploadFilesJournal() {
            showGoogleDriveLoader();
            const taskId = $('#fileUploadTaskID').val();
            const journalSts = $('#fileUploadHidStatus').val();

            const formData = new FormData();
            formData.append('uploaded_files', $('#uploaded_files').val());
            formData.append('task_id', taskId);
            formData.append('journal_status', journalSts);

            $.ajax({
                url: `/upload_production_journals`,
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                },
                data: formData,
                processData: false,
                contentType: false,
                beforeSend: function() {
                    $('#uploadJournalFilesBtn').addClass('loading').prop('disabled', true);
                },
                success: function(response) {
                    hideGoogleDriveLoader();
                    if (response.status === 200) {
                        showSuccessMessage(response.message);
                        location.reload();
                    } else {
                        hideGoogleDriveLoader();
                        toastr.error(response.message || 'An Error Occured');
                        $('#uploadJournalFilesBtn').prop('disabled', false).removeClass('loading');
                    }
                },
                error: function(xhr, status, error) {
                    hideGoogleDriveLoader();
                    $('#uploadJournalFilesBtn').prop('disabled', false).removeClass('loading');

                    if (xhr.status === 409) {
                        // Journal name already exists
                        toastr.error(xhr.responseJSON?.message || 'Journal name already exists!');
                    } else if (xhr.status === 422) {
                        // Validation errors
                        const errors = xhr.responseJSON?.errors;
                        if (errors) {
                            // Display validation errors for each field
                            Object.keys(errors).forEach(field => {
                                toastr.error(errors[field][0]);
                            });
                        } else {
                            toastr.error(xhr.responseJSON?.message || 'Validation failed!');
                        }
                    } else if (xhr.status === 500) {
                        // Server error
                        toastr.error(xhr.responseJSON?.message || 'Server error occurred!');
                    } else {
                        // Other errors
                        toastr.error('An unexpected error occurred: ' + error);
                    }
                }
            })
        }

        function showGoogleDriveLoader() {
            // Create overlay if it doesn't exist
            if (!$('#drive-loader-overlay').length) {
                $('body').append(`
                    <div id="drive-loader-overlay" style="
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(255, 255, 255, 0.9);
                        z-index: 9999;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        backdrop-filter: blur(2px);
                        transition: opacity 0.3s ease;
                    ">
                        <div class="drive-loader" style="
                            width: 80px;
                            height: 80px;
                            position: relative;
                            margin-bottom: 20px;
                        ">
                            <div class="drive-logo" style="
                                width: 40px;
                                height: 40px;
                                position: absolute;
                                top: 50%;
                                left: 50%;
                                transform: translate(-50%, -50%);
                                background: linear-gradient(135deg, #4285F4, #34A853, #FBBC05, #EA4335);
                                border-radius: 8px;
                                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                            ">
                                <div style="
                                    position: absolute;
                                    top: 8px;
                                    left: 8px;
                                    width: 24px;
                                    height: 24px;
                                    background: white;
                                    border-radius: 4px;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-weight: bold;
                                    color: #4285F4;
                                    font-size: 12px;
                                ">GD</div>
                            </div>
                            <div class="drive-loader-ring" style="
                                width: 100%;
                                height: 100%;
                                border: 4px solid #f3f3f3;
                                border-top: 4px solid #4285F4;
                                border-right: 4px solid #34A853;
                                border-bottom: 4px solid #FBBC05;
                                border-radius: 50%;
                                animation: spin 2s linear infinite;
                            "></div>
                        </div>

                        <div class="drive-loader-text" style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #3c4043;
                            font-size: 16px;
                            font-weight: 500;
                            margin-bottom: 8px;
                        ">Uploading to Google Drive</div>

                        <div class="drive-loader-subtext" style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #5f6368;
                            font-size: 14px;
                            text-align: center;
                            max-width: 300px;
                            line-height: 1.4;
                        ">Creating folders and uploading files. This may take a moment...</div>

                        <div class="drive-progress-container" style="
                            width: 300px;
                            margin-top: 20px;
                            background: #f1f3f4;
                            border-radius: 10px;
                            height: 6px;
                            overflow: hidden;
                        ">
                            <div class="drive-progress-bar" style="
                                width: 0%;
                                height: 100%;
                                background: linear-gradient(90deg, #4285F4, #34A853);
                                border-radius: 10px;
                                transition: width 0.3s ease;
                            "></div>
                        </div>

                        <div class="drive-progress-text" style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #5f6368;
                            font-size: 13px;
                            margin-top: 8px;
                        ">Preparing upload...</div>

                        <div class="drive-steps" style="
                            margin-top: 20px;
                            display: flex;
                            flex-direction: column;
                            gap: 10px;
                            width: 300px;
                        ">
                            <div class="drive-step" data-step="1" style="
                                display: flex;
                                align-items: center;
                                gap: 10px;
                                padding: 8px 12px;
                                background: #f8f9fa;
                                border-radius: 8px;
                                border-left: 4px solid #e8eaed;
                            ">
                                <div class="step-icon" style="
                                    width: 20px;
                                    height: 20px;
                                    border-radius: 50%;
                                    background: #e8eaed;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-size: 12px;
                                    color: #5f6368;
                                ">1</div>
                                <div class="step-text" style="
                                    font-size: 14px;
                                    color: #5f6368;
                                ">Creating folder structure</div>
                            </div>
                            <div class="drive-step" data-step="2" style="
                                display: flex;
                                align-items: center;
                                gap: 10px;
                                padding: 8px 12px;
                                background: #f8f9fa;
                                border-radius: 8px;
                                border-left: 4px solid #e8eaed;
                            ">
                                <div class="step-icon" style="
                                    width: 20px;
                                    height: 20px;
                                    border-radius: 50%;
                                    background: #e8eaed;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-size: 12px;
                                    color: #5f6368;
                                ">2</div>
                                <div class="step-text" style="
                                    font-size: 14px;
                                    color: #5f6368;
                                ">Uploading files</div>
                            </div>
                            <div class="drive-step" data-step="3" style="
                                display: flex;
                                align-items: center;
                                gap: 10px;
                                padding: 8px 12px;
                                background: #f8f9fa;
                                border-radius: 8px;
                                border-left: 4px solid #e8eaed;
                            ">
                                <div class="step-icon" style="
                                    width: 20px;
                                    height: 20px;
                                    border-radius: 50%;
                                    background: #e8eaed;
                                    display: flex;
                                    align-items: center;
                                    justify-content: center;
                                    font-size: 12px;
                                    color: #5f6368;
                                ">3</div>
                                <div class="step-text" style="
                                    font-size: 14px;
                                    color: #5f6368;
                                ">Saving journal information</div>
                            </div>
                        </div>
                    </div>
                `);

                // Add CSS animation
                const style = document.createElement('style');
                style.innerHTML = `
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }

                    @keyframes pulse {
                        0% { opacity: 0.6; }
                        50% { opacity: 1; }
                        100% { opacity: 0.6; }
                    }

                    .drive-step.active {
                        background: #e8f0fe !important;
                        border-left-color: #1a73e8 !important;
                    }

                    .drive-step.active .step-icon {
                        background: #1a73e8 !important;
                        color: white !important;
                    }

                    .drive-step.completed {
                        background: #e6f4ea !important;
                        border-left-color: #34a853 !important;
                    }

                    .drive-step.completed .step-icon {
                        background: #34a853 !important;
                        color: white !important;
                    }
                `;
                document.head.appendChild(style);
            }

            $('#drive-loader-overlay').fadeIn(300);

            // Simulate progress updates
            simulateDriveUploadProgress();
        }

        function hideGoogleDriveLoader() {
            $('#drive-loader-overlay').fadeOut(300, function() {
                $(this).remove();
            });
        }

        function showSuccessMessage(message) {
            if (!$('#success-message-overlay').length) {
                $('body').append(`
                    <div id="success-message-overlay" style="
                        position: fixed;
                        top: 0;
                        left: 0;
                        width: 100%;
                        height: 100%;
                        background: rgba(255, 255, 255, 0.95);
                        z-index: 10000;
                        display: flex;
                        flex-direction: column;
                        align-items: center;
                        justify-content: center;
                        backdrop-filter: blur(2px);
                    ">
                        <div style="
                            width: 80px;
                            height: 80px;
                            background: #34a853;
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin-bottom: 20px;
                            animation: scaleIn 0.5s ease;
                        ">
                            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                        </div>

                        <div style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #202124;
                            font-size: 24px;
                            font-weight: 500;
                            margin-bottom: 10px;
                        ">Success!</div>

                        <div style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #5f6368;
                            font-size: 16px;
                            text-align: center;
                            max-width: 400px;
                            line-height: 1.5;
                            margin-bottom: 30px;
                        ">${message}</div>

                        <div style="
                            font-family: 'Google Sans', 'Segoe UI', Arial, sans-serif;
                            color: #5f6368;
                            font-size: 14px;
                            text-align: center;
                            max-width: 400px;
                            line-height: 1.4;
                        ">
                            <div style="display: flex; align-items: center; gap: 8px; justify-content: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="#34a853">
                                    <path d="M19 4H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 16H5V8h14v12z"/>
                                </svg>
                                <span>Files uploaded to Google Drive successfully</span>
                            </div>
                        </div>
                    </div>
                `);

                // Add CSS animation
                const style = document.createElement('style');
                style.innerHTML = `
                    @keyframes scaleIn {
                        0% { transform: scale(0); opacity: 0; }
                        70% { transform: scale(1.1); }
                        100% { transform: scale(1); opacity: 1; }
                    }
                `;
                document.head.appendChild(style);
            }

            $('#success-message-overlay').fadeIn(300);
        }

        function simulateDriveUploadProgress() {
            let progress = 0;
            let currentStep = 1;

            const progressBar = $('#drive-loader-overlay .drive-progress-bar');
            const progressText = $('#drive-loader-overlay .drive-progress-text');
            const steps = $('#drive-loader-overlay .drive-step');

            // Step 1: Creating folder structure (0-30%)
            setTimeout(() => {
                updateStep(1, 'active');
                simulateProgressIncrement(30, 1500, 'Creating customer folder...');

                setTimeout(() => {
                    updateStep(1, 'completed');
                    updateStep(2, 'active');

                    // Step 2: Uploading files (30-80%)
                    setTimeout(() => {
                        simulateProgressIncrement(50, 3000, 'Uploading files to Google Drive...');

                        setTimeout(() => {
                            updateStep(2, 'completed');
                            updateStep(3, 'active');

                            // Step 3: Saving information (80-95%)
                            setTimeout(() => {
                                simulateProgressIncrement(15, 2000,
                                    'Saving journal information...');

                                setTimeout(() => {
                                    updateStep(3, 'completed');

                                    // Final step (95-100%)
                                    setTimeout(() => {
                                        simulateProgressIncrement(5,
                                            1000,
                                            'Finalizing...');
                                    }, 500);
                                }, 500);
                            }, 500);
                        }, 500);
                    }, 500);
                }, 500);
            }, 500);

            function simulateProgressIncrement(increment, duration, message) {
                const startProgress = progress;
                const endProgress = progress + increment;
                const startTime = Date.now();

                progressText.text(message);

                function update() {
                    const elapsed = Date.now() - startTime;
                    const percent = Math.min(elapsed / duration, 1);

                    progress = startProgress + (increment * percent);
                    progressBar.css('width', progress + '%');

                    if (percent < 1) {
                        requestAnimationFrame(update);
                    } else {
                        progress = endProgress;
                    }
                }

                update();
            }

            function updateStep(stepNumber, status) {
                const step = steps.filter(`[data-step="${stepNumber}"]`);
                step.removeClass('active completed').addClass(status);

                const icon = step.find('.step-icon');
                if (status === 'completed') {
                    icon.html(
                        '<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>'
                    );
                } else if (status === 'active') {
                    icon.html(stepNumber);
                }
            }
        }

        // Also update your submit button to call this function
        $(document).ready(function() {
            // Add loading class to submit button
            $('#uploadJournalFilesBtn').on('click', function(e) {
                e.preventDefault();
                uploadFilesJournal();
            });

            // Add CSS for loading button
            const buttonStyle = document.createElement('style');
            buttonStyle.innerHTML = `
                #uploadJournalFilesBtn.loading {
                    position: relative;
                    color: transparent !important;
                }

                #uploadJournalFilesBtn.loading::after {
                    content: '';
                    position: absolute;
                    top: 50%;
                    left: 50%;
                    transform: translate(-50%, -50%);
                    width: 20px;
                    height: 20px;
                    border: 2px solid rgba(255, 255, 255, 0.3);
                    border-top-color: white;
                    border-radius: 50%;
                    animation: button-spin 0.8s linear infinite;
                }

                @keyframes button-spin {
                    to { transform: translate(-50%, -50%) rotate(360deg); }
                }
            `;
            document.head.appendChild(buttonStyle);
        });
    </script>
@endsection
