@extends('layouts/layoutMaster')

@section('title', 'Milestone Mapping')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <!-- Loading Overlay -->
    <div id="pc_assign_loader" class="loading-overlay">
        <div class="loading-content">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <div class="mt-3 text-primary fw-semibold">Loading Milestone Data...</div>
        </div>
    </div>

    <!-- Page Header -->
    <div class="card mb-2">
        @php
            $helper = new \App\Helpers\Helpers();
        @endphp
        <div class="card-header border-bottom pb-1">
            <h5 class="mb-1 text-black" id="brch_fran_tle">Milestone Mapping</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Service</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="card p-4">
        <div class="row">
            <!-- Left Column: Customer & Milestone Info -->
            <div class="col-lg-6">
                <div class="row mb-4">
                    <!-- Customer Details -->
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_cus_name">{{ $data->cus_name }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-info fs-6 fw-bold"
                                id="assign_pc_customer_id">{{ $data->customer_id }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_mobile_num">{{ $data->cus_mobile ?? '-' }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-6">
                            <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_cus_email">{{ $data->cus_email_id ?? '-' }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-6">
                            <label class="col-4 text-dark fs-6 fw-semibold">Domains</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" >{{ is_array($data->domain_names) ? implode(', ', $data->domain_names) : 'No Domain Selected' }}</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <input type="hidden" id="milestone_hide_cus_id" value="{{ $data->cus_sno }}">
                <input type="hidden" id="milestone_hide_proposal_id" value="{{ $id }}">

                <div class="form-group mb-4">
                    <label class="text-black mb-1 fs-6 fw-semibold">Milestone<span
                            class="text-danger">*</span></label>
                    <select class="select3 form-select" id="milestone_id"
                        onchange="fetchMilestoneServices()">
                        <option value="">Select Task</option>
                    </select>
                    <div id="milestone_id_err" class="text-danger mt-1 small"></div>
                </div>

                <div class="form-group mb-4">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                            class="text-danger">*</span></label>
                    <select class="select3 form-select" id="milestone_service_id"
                         multiple>
                    </select>
                    <div id="milestone_service_id_err" class="text-danger mt-1 small"></div>
                </div>

                <!-- Service Summary -->
                {{-- <div class="service-summary" id="service_summary" style="display: none;">
                    <div class="summary-header">
                        <h6 class="summary-title mb-3">Service Overview</h6>
                    </div>
                    <div class="summary-content">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="summary-item">
                                    <div class="summary-label">Total Tasks</div>
                                    <div class="summary-value" id="summary_total_tasks">0</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="summary-item">
                                    <div class="summary-label">Tasks Mapped</div>
                                    <div class="summary-value" id="summary_mapped_tasks">0</div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-success" id="mapping_progress" role="progressbar"
                                        style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> --}}
                    <div class="summary-stats card border-0 bg-light mt-4" id="progress_summary"
                    style="display: none;">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-checkbox-multiple-marked-circle-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Tasks</div>
                                        <div class="stat-value" id="total_tasks">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-file-document-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Pages</div>
                                        <div class="stat-value" id="total_pages">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-percent"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Percentage</div>
                                        <div class="stat-value" id="total_percentage">0%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Task Mapping -->
            <div class="col-lg-12">
                <!-- Task Mapping Card -->
                <div class="border border-light border-1 rounded">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="card-header-title text-black">
                                    <i class="mdi mdi-format-list-checkbox me-2"></i>
                                    Task Mapping
                                </h4>
                                <p class="card-header-subtitle text-muted mb-0" id="task_count_message">Select a service
                                    to start mapping tasks</p>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-primary btn-add-task"  style="display: none;"
                                    id="milestone_add_more_btn">
                                    <i class="mdi mdi-plus-circle-outline me-1"></i>
                                    Add Task
                                </button>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <div class="card-body">
                        {{-- <input type="hidden" id="milestone-hidden-service-id">
                        <input type="hidden" id="product_category_id"> --}}

                        {{-- <div class="row"> --}}
                            {{-- <div class="col-lg-6">
                                <div class="task-containers" id="task_containers">
                                </div>
                            </div> --}}
                            <div id="milestone_mapping_add_container" class="row"></div>
                        {{-- </div> --}}
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end gap-2">
            <a href="{{ url('/manage_service') }}" class="btn btn-outline-secondary btn-cancel">
                <i class="mdi mdi-close me-1"></i>
                Cancel
            </a>
            <button type="button" class="btn btn-primary btn-submit" id="assign_pc_button"
                onclick="milestoneAddValidation()">
                <i class="mdi mdi-check-circle-outline me-1"></i>
                Map Milestone
            </button>
        </div>
    </div>

    <style>
        /* Loading Overlay */
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(4px);
        }

        .loading-content {
            text-align: center;
            animation: fadeIn 0.3s ease;
        }

        .loading-content .spinner-border {
            width: 3rem;
            height: 3rem;
        }

        /* Page Header */
        .page-header {
            padding: 2rem 0;
            border-bottom: 1px solid #e9ecef;
        }

        .page-pretitle {
            color: #6c757d;
            text-transform: uppercase;
            font-size: 0.875rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .page-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: #212529;
            margin-bottom: 0.5rem;
        }

        .page-subtitle {
            font-size: 0.9375rem;
            color: #6c757d;
        }

        /* Card Styles */
        .card-profile {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            overflow: hidden;
        }

        .card-profile::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #007bff, #00d4ff);
        }

        .card-settings,
        .card-mapping,
        .card-tips {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .card-settings .card-header,
        .card-mapping .card-header,
        .card-tips .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-bottom: none;
            padding: 1.25rem 1.5rem;
        }

        .card-header-title {
            color: white;
            font-size: 1.125rem;
            font-weight: 600;
            margin: 0;
        }

        .card-header-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.875rem;
        }

        /* Profile Styles */
        .profile-header {
            padding: 1rem;
            background: linear-gradient(135deg, #f0f7ff 0%, #e3f2fd 100%);
            border-radius: 10px;
            margin: -1rem;
            margin-bottom: 1rem;
        }

        .profile-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 28px;
        }

        .profile-name {
            font-size: 1.25rem;
            font-weight: 700;
            color: #212529;
            margin: 0;
        }

        .profile-id .badge {
            font-size: 0.75rem;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 500;
        }

        /* Detail Items */
        .detail-item {
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 0.75rem;
            transition: all 0.2s ease;
        }

        .detail-item:hover {
            background: #e9ecef;
            transform: translateX(4px);
        }

        .detail-item:last-child {
            margin-bottom: 0;
        }

        .detail-label {
            font-size: 0.8125rem;
            color: #6c757d;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
        }

        .detail-value {
            font-size: 0.9375rem;
            font-weight: 600;
            color: #212529;
            word-break: break-word;
        }

        /* Form Styles */
        .form-group {
            position: relative;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.875rem;
            color: #495057;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }

        .input-group {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            transition: all 0.2s ease;
        }

        .input-group:focus-within {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
        }

        .input-group-text {
            background-color: #f8f9fa;
            border: none;
            color: #6c757d;
        }

        /* .form-select {
                border: none;
                padding: 0.75rem 1rem;
                font-size: 0.9375rem;
                background-color: white;
            }

            .form-select:focus {
                box-shadow: none;
                background-color: white;
            } */

        /* Service Summary */
        .service-summary {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 1.25rem;
            margin-top: 1rem;
            animation: slideIn 0.3s ease;
        }

        .summary-title {
            font-size: 1rem;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #007bff;
            padding-bottom: 0.5rem;
        }

        .summary-item {
            text-align: center;
        }

        .summary-label {
            font-size: 0.75rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .summary-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #007bff;
            line-height: 1.2;
        }

        .progress {
            border-radius: 10px;
            background-color: #e9ecef;
            overflow: hidden;
        }

        .progress-bar {
            border-radius: 10px;
            transition: width 0.6s ease;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
        }

        .empty-state-icon {
            font-size: 4rem;
            color: #dee2e6;
            margin-bottom: 1.5rem;
        }

        .empty-state-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 0.5rem;
        }

        .empty-state-text {
            color: #adb5bd;
            font-size: 0.9375rem;
        }

        /* Task Container Styles */
        .task-container {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            position: relative;
            transition: all 0.3s ease;
            /* border-left: 4px solid #007bff; */
        }

        /* .task-container:hover {
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            transform: translateY(-2px);
            border-left-color: #00d4ff;
        } */

        .task-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .task-number {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            color: white;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.875rem;
            margin-right: 0.75rem;
        }

        .task-title {
            font-size: 1rem;
            font-weight: 600;
            color: #212529;
            margin: 0;
        }

        /* Button Styles */
        .btn-add-task {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border: none;
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.25);
        }

        .btn-add-task:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.3);
        }

        .btn-add-task:disabled {
            opacity: 0.6;
            transform: none !important;
            box-shadow: none !important;
        }

        .btn-cancel {
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            border: 2px solid #dee2e6;
            background: white;
        }

        .btn-submit {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.25);
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.3);
        }

        .btn-submit:disabled {
            opacity: 0.6;
            transform: none !important;
            box-shadow: none !important;
        }

        /* Summary Stats */
        .summary-stats {
            border-radius: 12px;
            animation: fadeIn 0.5s ease;
        }

        .stat-item {
            padding: 1rem;
            position: relative;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-item:nth-child(2) .stat-icon {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-item:nth-child(3) .stat-icon {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .stat-label {
            font-size: 0.8125rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.25rem;
        }

        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: #212529;
            line-height: 1.2;
        }

        /* Tips Card */
        .card-tips .card-header {
            background: linear-gradient(135deg, #ffd166 0%, #ff9e6d 100%);
        }

        .tips-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .tip-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .tip-item:last-child {
            border-bottom: none;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }

            100% {
                transform: scale(1);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .page-title {
                font-size: 1.5rem;
            }

            .profile-icon {
                width: 50px;
                height: 50px;
                font-size: 24px;
            }

            .profile-name {
                font-size: 1.125rem;
            }

            .btn-add-task,
            .btn-cancel,
            .btn-submit {
                padding: 0.5rem 1rem;
                font-size: 0.875rem;
            }
        }

        /* Select2 Custom Styling */
        /* .select2-container--default .select2-selection--single,
            .select2-container--default .select2-selection--multiple {
                border: none !important;
                background: transparent !important;
                min-height: 44px !important;
            }

            .select2-container--default .select2-selection--single .select2-selection__rendered {
                line-height: 44px !important;
                padding-left: 0 !important;
                color: #495057 !important;
                font-size: 0.9375rem;
            }

            .select2-container--default .select2-selection--single .select2-selection__arrow {
                height: 44px !important;
            }

            .select2-container--open .select2-dropdown {
                border-radius: 10px !important;
                border: 1px solid #dee2e6 !important;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08) !important;
                margin-top: 4px;
            }

            .select2-container--default .select2-results__option--highlighted[aria-selected] {
                background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%) !important;
                color: white !important;
            }
             */
        /* Form Text */
        .form-text {
            display: flex;
            align-items: center;
            color: #6c757d;
            font-size: 0.875rem;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #0056b3 0%, #00b3d4 100%);
        }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Custom Toastr Styling */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            // showToast(type, message);
        @endif
    </script>

    <script>
        let selectedServices = []; // Array to store selected service IDs
        let serviceData = {}; // Object to store data for each service

        function resetMilestoneItems() {
            try {
                // Reset service dropdown
                $('#milestone_service_id').val('').trigger('change');
                selectedServices = [];
                serviceData = {};

                // Clear task containers
                $('#milestone_mapping_add_container').empty();

                // Show empty state
                $('#empty_state').show();
                $('#progress_summary').hide();

                // Clear validation errors
                $('.text-danger').text('');
                $('.form-select, .form-control').removeClass('is-invalid');

                // Update messages
                $('#task_count_message').text('Select services to start mapping tasks');

            } catch (error) {
                console.error('Error resetting milestone items:', error);
            }
        }

        function updateProgressSummary() {
            let totalTasks = 0;
            let totalPages = 0;
            let totalPercentage = 0;

            // Calculate totals across all services
            Object.keys(serviceData).forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].tasks) {
                    totalTasks += serviceData[serviceId].tasks.length || 0;
                    // Calculate pages and percentages from task containers
                    if (serviceData[serviceId].taskContainers) {
                        Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                            const task = serviceData[serviceId].taskContainers[containerId];
                            totalPages += task.pages || 0;
                            totalPercentage += task.percentage || 0;
                        });
                    }
                }
            });

            $('#total_tasks').text(totalTasks);
            $('#total_pages').text(totalPages);
            $('#total_percentage').text(totalPercentage + '%');

            if (totalTasks > 0) {
                $('#progress_summary').show();
                $('#empty_state').hide();
            } else {
                $('#progress_summary').hide();
                $('#empty_state').show();
            }
        }

        $(document).ready(function() {
            fetchMilestone();
            $('#task_count_message').text('Select services to start mapping tasks');

            // Initialize select2 for multi-select
            $('#milestone_service_id').select2({
                placeholder: 'Select Services',
                allowClear: true,
                closeOnSelect: false
            });

            // Handle service selection change
            $('#milestone_service_id').on('change', function() {
                const selectedServiceIds = $(this).val() || [];

                console.log('Selected Services:', selectedServiceIds);
                console.log('Current selectedServices:', selectedServices);

                // Remove services that are no longer selected
                const servicesToRemove = selectedServices.filter(serviceId =>
                    !selectedServiceIds.includes(serviceId)
                );

                servicesToRemove.forEach(serviceId => {
                    removeServiceContainer(serviceId, false); // false = don't update dropdown again
                });

                // Add new services
                selectedServiceIds.forEach(serviceId => {
                    if (!selectedServices.includes(serviceId)) {
                        selectedServices.push(serviceId);
                        createServiceContainer(serviceId);
                    }
                });

                updateServiceButtons();
                updateProgressSummary();
            });

            // Initialize milestone dropdown change
            $('#milestone_id').on('change', function() {
                fetchMilestoneServices();
                // Clear existing services when milestone changes
                $('#milestone_service_id').val('').trigger('change');
                resetMilestoneItems();
            });
        });

        function fetchMilestone() {
            $('#pc_assign_loader').show();
            const id = "{{ $id }}";

            $.ajax({
                url: `/get_milestone_data/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const milestoneContainer = $('#milestone_id');
                        milestoneContainer.empty().append(`<option value="">Select Milestone</option>`);

                        response.data.forEach(mile => {
                            milestoneContainer.append(
                                `<option value="${mile.sno}" data-expected="${mile.expected_percentage}">
                                    ${mile.payment_slot_name}
                                </option>`);
                        });

                        // Store totals globally
                        window.totalServices = response.total_services;
                        window.totalMilestones = response.total_milestones;
                        window.expectedPerMilestone = response.expected_per_milestone;
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load milestones');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load milestones');
                },
                complete: function() {
                    $('#pc_assign_loader').hide();
                }
            });
        }

        function fetchMilestoneServices() {
            const milestoneId = $('#milestone_id').val();
            if (!milestoneId) return;

            const proposalId = $('#milestone_hide_proposal_id').val();

            $.ajax({
                url: `/get_milestone_service_data/${proposalId}`,
                type: 'GET',
                data: {
                    milestone_id: milestoneId
                },
                success: function(response) {
                    if (response.status === 200) {
                        const serviceContainer = $('#milestone_service_id');
                        serviceContainer.empty();

                        // Store service options for later reference
                        window.serviceOptions = {};

                        response.data.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.product_name} - ${service.service_id}</option>`
                            );
                            window.serviceOptions[service.sno] = service.product_name + ' - ' + service.service_id;
                        });

                        // Reinitialize select2
                        serviceContainer.select2({
                            placeholder: 'Select Services',
                            allowClear: true,
                            closeOnSelect: false
                        });

                        $('#task_count_message').text('Select services to add tasks');
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load services');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load services');
                }
            });
        }

        function createServiceContainer(serviceId) {
            // Get service name from stored options
            const serviceName = window.serviceOptions && window.serviceOptions[serviceId]
                ? window.serviceOptions[serviceId]
                : `Service ${serviceId}`;

            const serviceContainerId = `service_${serviceId}_container`;

            console.log('Creating container for service:', serviceId, serviceName);

            const containerHtml = `
                <div class="service-task-container col-12 mb-4" id="${serviceContainerId}" data-service-id="${serviceId}">
                    <div class="card border">
                        <div class="card-header bg-light">
                            <div class="d-flex justify-content-between align-items-center">
                                <h6 class="mb-0">${serviceName}</h6>
                                <button type="button" class="btn btn-sm btn-outline-danger" onclick="removeServiceContainer(${serviceId})">
                                    <i class="mdi mdi-close"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="service-tasks-container" id="tasks_${serviceId}">
                                <!-- Tasks will be added here -->
                            </div>
                            <div class="mt-3">
                                <button type="button" class="btn btn-sm btn-outline-primary" onclick="addTaskToService(${serviceId})" id="add_task_btn_${serviceId}">
                                    <i class="mdi mdi-plus-circle-outline me-1"></i> Add Task
                                </button>
                                <span class="text-muted ms-2" id="task_count_display_${serviceId}">0 tasks added</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            $('#milestone_mapping_add_container').append(containerHtml);

            // Initialize service data
            serviceData[serviceId] = {
                maxTasks: 0,
                tasks: [],
                taskContainers: {},
                availableTasks: []
            };

            // Fetch tasks for this service
            fetchTasksForService(serviceId);
        }

        function removeServiceContainer(serviceId, updateDropdown = true) {
            console.log('Removing container for service:', serviceId);

            $(`#service_${serviceId}_container`).remove();

            // Remove from selected services array
            const index = selectedServices.indexOf(serviceId.toString());
            if (index > -1) {
                selectedServices.splice(index, 1);
            }

            // Update dropdown if needed
            if (updateDropdown) {
                $('#milestone_service_id').val(selectedServices).trigger('change');
            }

            // Remove service data
            delete serviceData[serviceId];

            updateServiceButtons();
            updateProgressSummary();
        }

        function fetchTasksForService(serviceId) {
            console.log('Fetching tasks for service:', serviceId);

            $.ajax({
                url: `/get_milestone_product/${serviceId}`,
                type: 'GET',
                success: function(response) {
                    console.log('Tasks response for service', serviceId, ':', response);

                    if (response.status === 200) {
                        if (serviceData[serviceId]) {
                            serviceData[serviceId].maxTasks = response.task_count;
                            serviceData[serviceId].availableTasks = response.data;
                            serviceData[serviceId].productInfo = response.service_info;

                            console.log(`Service ${serviceId}: ${response.task_count} tasks available`);
                        }

                        updateServiceButtons();
                    } else {
                        toastr.error('Failed to load tasks for service');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                    toastr.error('Failed to load tasks for service');
                }
            });
        }

        function addTaskToService(serviceId) {
            if (!serviceData[serviceId]) {
                toastr.error('Service data not loaded');
                return;
            }

            const taskCount = serviceData[serviceId].tasks.length || 0;
            const maxTasks = serviceData[serviceId].maxTasks || 0;

            if (taskCount >= maxTasks) {
                toastr.error(`Maximum ${maxTasks} tasks allowed for this service`);
                return;
            }

            const taskIndex = taskCount;
            const taskElementId = `task_${serviceId}_${Date.now()}_${taskIndex}`;

            console.log(`Adding task ${taskIndex} to service ${serviceId}`);

            const taskHtml = `
                <div class="task-item card border mb-2" id="${taskElementId}">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-lg-9">
                                <div class="form-group">
                                    <label class="form-label">Task<span class="text-danger">*</span></label>
                                    <select class="form-select task-select" id="task_select_${taskElementId}" onchange="onTaskChange(this, '${serviceId}', '${taskElementId}')">
                                        <option value="">Select Task</option>
                                    </select>
                                    <div class="text-danger mt-1 small task_err_${taskElementId}"></div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="form-group">
                                    <label class="form-label">Action</label>
                                    <button type="button" class="btn btn-sm btn-outline-danger w-100" onclick="removeTask('${serviceId}', '${taskElementId}')">
                                        <i class="mdi mdi-delete"></i> Remove
                                    </button>
                                </div>
                            </div>
                            <div class="col-12" id="task_category_${taskElementId}"></div>
                        </div>
                    </div>
                </div>
            `;

            $(`#tasks_${serviceId}`).append(taskHtml);

            // Initialize task data
            serviceData[serviceId].taskContainers[taskElementId] = {
                taskId: '',
                pages: 0
            };

            serviceData[serviceId].tasks.push(taskElementId);

            // Populate task dropdown
            populateTaskDropdown(serviceId, taskElementId);
            updateServiceButtons();
            updateTaskCountDisplay(serviceId);
            updateProgressSummary();
        }

        function updateTaskCountDisplay(serviceId) {
            const taskCount = serviceData[serviceId] ? serviceData[serviceId].tasks.length : 0;
            $(`#task_count_display_${serviceId}`).text(`${taskCount} tasks added`);
        }

        function populateTaskDropdown(serviceId, taskElementId) {
            if (!serviceData[serviceId] || !serviceData[serviceId].availableTasks) {
                console.log('No available tasks for service', serviceId);
                return;
            }

            const selectElement = $(`#task_select_${taskElementId}`);
            selectElement.empty().append(`<option value="">Select Task</option>`);

            // Get already selected task IDs for this service
            const selectedTaskIds = [];
            if (serviceData[serviceId].taskContainers) {
                Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                    if (containerId !== taskElementId && serviceData[serviceId].taskContainers[containerId].taskId) {
                        selectedTaskIds.push(serviceData[serviceId].taskContainers[containerId].taskId);
                    }
                });
            }

            console.log(`Service ${serviceId} - Selected task IDs:`, selectedTaskIds);
            console.log(`Service ${serviceId} - Available tasks:`, serviceData[serviceId].availableTasks.length);

            // Add available tasks
            serviceData[serviceId].availableTasks.forEach(task => {
                if (!selectedTaskIds.includes(task.sno.toString())) {
                    selectElement.append(
                        `<option value="${task.sno}">${task.task_name}</option>`
                    );
                }
            });
        }

        function onTaskChange(selectElement, serviceId, taskElementId) {
            const taskId = selectElement.value;

            console.log(`Task changed for service ${serviceId}:`, taskId);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].taskId = taskId;

                // Fetch task category if needed
                if (taskId) {
                    getTaskCategory(taskId, serviceId, taskElementId);
                }
            }

            // Update all task dropdowns for this service
            updateAllTaskDropdowns(serviceId);
            updateServiceButtons();
            updateProgressSummary();
        }

        function getTaskCategory(taskId, serviceId, taskElementId) {
            console.log(`Fetching category for task ${taskId} in service ${serviceId}`);

            $.ajax({
                url: `/get_task_category/${taskId}`,
                type: 'GET',
                success: function(response) {
                    console.log('Task category response:', response);

                    if (response.status === 200) {
                        const categoryContainer = $(`#task_category_${taskElementId}`);
                        categoryContainer.empty();

                        let html = '';
                        // category_check == 0 means it's a page-based task
                        // category_check == 1 means it's a percentage-based task or other type
                        if (response.data.category_check == 0) {
                            html = `
                            <div class="col-12 mt-3">
                                <div class="form-group">
                                    <label class="form-label">
                                        <i class="mdi mdi-file-document-outline me-1"></i>
                                        Pages <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="mdi mdi-numeric"></i>
                                        </span>
                                        <input type="number" class="form-control product-pages"
                                            placeholder="Enter number of pages"
                                            id="product_pages_${taskElementId}"
                                            min="0"
                                            oninput="updateTaskPages('${serviceId}', '${taskElementId}')"/>
                                    </div>
                                    <div class="text-danger mt-1 small pages_err_${taskElementId}"></div>
                                    <small class="text-muted">Enter the number of pages for this task</small>
                                </div>
                            </div>
                        `;
                        } else if (response.data.category_check == 1) {
                            // Percentage-based task
                            html = ` `;
                        } else {
                            // No category or other type - show nothing or a message
                            html = `
                            <div class="col-12 mt-3">
                                <div class="alert alert-info">
                                    <i class="mdi mdi-information me-1"></i>
                                    This task doesn't require additional input.
                                </div>
                            </div>
                        `;
                        }
                        categoryContainer.html(html);

                        // Update task data with category type
                        if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                            serviceData[serviceId].taskContainers[taskElementId].category = response.data.category_check;
                        }
                    } else {
                        console.error('Failed to get task category:', response);
                    }
                },
                error: function(err) {
                    console.error('AJAX Error fetching task category:', err);
                    toastr.error('Failed to load task category information');
                }
            });
        }

        function updateTaskPercentage(serviceId, taskElementId) {
            const percentageInput = $(`#product_percentage_${taskElementId}`);
            if (!percentageInput.length) return;

            let percentageValue = parseInt(percentageInput.val()) || 0;

            // Ensure value is between 0 and 100
            if (percentageValue < 0) percentageValue = 0;
            if (percentageValue > 100) percentageValue = 100;

            percentageInput.val(percentageValue);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].percentage = percentageValue;
            }

            updateProgressSummary();
        }

        function updateTaskPages(serviceId, taskElementId) {
            const pagesInput = $(`#pages_${taskElementId}`) || $(`#product_pages_${taskElementId}`);
            if (!pagesInput.length) return;

            let pagesValue = parseInt(pagesInput.val()) || 0;

            // Ensure value is not negative
            if (pagesValue < 0) pagesValue = 0;

            pagesInput.val(pagesValue);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].pages = pagesValue;
            }

            updateProgressSummary();
        }

        function removeTask(serviceId, taskElementId) {
            $(`#${taskElementId}`).remove();

            // Remove from service data
            if (serviceData[serviceId]) {
                const taskIndex = serviceData[serviceId].tasks.indexOf(taskElementId);
                if (taskIndex > -1) {
                    serviceData[serviceId].tasks.splice(taskIndex, 1);
                }
                if (serviceData[serviceId].taskContainers) {
                    delete serviceData[serviceId].taskContainers[taskElementId];
                }
            }

            updateAllTaskDropdowns(serviceId);
            updateServiceButtons();
            updateTaskCountDisplay(serviceId);
            updateProgressSummary();
        }

        function updateAllTaskDropdowns(serviceId) {
            if (!serviceData[serviceId] || !serviceData[serviceId].taskContainers) return;

            // Get selected task IDs for this service
            const selectedTaskIds = [];
            Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                if (serviceData[serviceId].taskContainers[containerId].taskId) {
                    selectedTaskIds.push(serviceData[serviceId].taskContainers[containerId].taskId);
                }
            });

            console.log(`Updating dropdowns for service ${serviceId}, selected tasks:`, selectedTaskIds);

            // Update all dropdowns for this service
            $(`#tasks_${serviceId} .task-select`).each(function() {
                const currentValue = $(this).val();

                $(this).find('option').each(function() {
                    const optionValue = $(this).val();
                    if (optionValue && optionValue !== '') {
                        if (selectedTaskIds.includes(optionValue) && optionValue !== currentValue) {
                            $(this).prop('disabled', true);
                        } else {
                            $(this).prop('disabled', false);
                        }
                    }
                });
            });
        }

        function updateServiceButtons() {
            // Enable/disable add task buttons based on available tasks
            selectedServices.forEach(serviceId => {
                const addButton = $(`#add_task_btn_${serviceId}`);
                if (serviceData[serviceId]) {
                    const taskCount = serviceData[serviceId].tasks.length || 0;
                    const maxTasks = serviceData[serviceId].maxTasks || 0;

                    if (taskCount >= maxTasks) {
                        addButton.prop('disabled', true)
                            .html('<i class="mdi mdi-check-all me-1"></i> Max Tasks Added');
                    } else {
                        addButton.prop('disabled', false)
                            .html('<i class="mdi mdi-plus-circle-outline me-1"></i> Add Task');
                    }
                }
            });
        }

        function milestoneAddValidation() {
            let isValid = true;
            const button = $('#assign_pc_button');

            // Reset errors
            $('.text-danger').text('');
            $('.form-select, .form-control').removeClass('is-invalid');

            const milestoneId = $('#milestone_id').val();

            // Validate milestone selection
            if (!milestoneId) {
                $('#milestone_id_err').text('Please select a milestone');
                isValid = false;
                $('#milestone_id').addClass('is-invalid');
                return false;
            }

            // Validate at least one service is selected
            if (selectedServices.length === 0) {
                $('#milestone_service_id_err').text('Please select at least one service');
                isValid = false;
                $('#milestone_service_id').addClass('is-invalid');
                return false;
            }

            // Validate each service has at least one task
            let hasTasks = false;
            let taskCount = 0;

            selectedServices.forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].taskContainers) {
                    Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                        const task = serviceData[serviceId].taskContainers[containerId];

                        // Validate task is selected
                        if (!task.taskId) {
                            $(`#task_select_${containerId}`).addClass('is-invalid');
                            $(`.task_err_${containerId}`).text('Please select a task');
                            isValid = false;
                        }

                        // Check category and validate accordingly
                        const category = task.category || 0; // Default to 0 (pages)

                        if (category == 0) {
                            // Page-based task validation
                            const pagesInput = $(`#pages_${containerId}`) || $(`#product_pages_${containerId}`);
                            if (pagesInput.length && pagesInput.is(':visible')) {
                                const pagesVal = pagesInput.val().trim();
                                if (pagesVal === '' || isNaN(pagesVal)) {
                                    $(`.pages_err_${containerId}`).text('Pages is required');
                                    isValid = false;
                                    pagesInput.addClass('is-invalid');
                                } else if (parseInt(pagesVal) <= 0) {
                                    $(`.pages_err_${containerId}`).text('Pages must be greater than 0');
                                    isValid = false;
                                    pagesInput.addClass('is-invalid');
                                }
                            }
                        }
                    });
                }
            });


            // if (!hasTasks) {
            //     toastr.error('Please add at least one task to the selected services');
            //     isValid = false;
            //     return false;
            // }

            console.log('Total tasks across all services:', taskCount);

            // Validate each task in each service
            selectedServices.forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].taskContainers) {
                    Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                        const task = serviceData[serviceId].taskContainers[containerId];

                        // Validate task is selected
                        if (!task.taskId) {
                            $(`#task_select_${containerId}`).addClass('is-invalid');
                            $(`.task_err_${containerId}`).text('Please select a task');
                            isValid = false;
                        }

                        // Validate pages if there's a pages input
                        const pagesInput = $(`#pages_${containerId}`) || $(`#product_pages_${containerId}`);
                        if (pagesInput.length && pagesInput.is(':visible')) {
                            const pagesVal = pagesInput.val().trim();
                            if (pagesVal === '' || isNaN(pagesVal)) {
                                $(`.pages_err_${containerId}`).text('Pages is required');
                                isValid = false;
                                pagesInput.addClass('is-invalid');
                            } else if (parseInt(pagesVal) <= 0) {
                                $(`.pages_err_${containerId}`).text('Pages must be greater than 0');
                                isValid = false;
                                pagesInput.addClass('is-invalid');
                            }
                        }
                    });
                }
            });

            if (!isValid) {
                toastr.error('Please fix all validation errors before submitting');
                return false;
            }

            // Prepare data for submission
            const finalData = {
                customer_id: $('#milestone_hide_cus_id').val(),
                proposal_id: $('#milestone_hide_proposal_id').val(),
                milestone_id: milestoneId,
                services: []
            };

            // Build services array
            selectedServices.forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].tasks.length > 0) {
                    const serviceObj = {
                        service_id: serviceId,
                        tasks: [],
                        pages: [],
                        percentages: []
                    };

                    Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                        const task = serviceData[serviceId].taskContainers[containerId];
                        if (task.taskId) {
                            serviceObj.tasks.push(task.taskId);
                            serviceObj.pages.push(task.pages || 0);
                            serviceObj.percentages.push(100); // Default percentage
                        }
                    });

                    if (serviceObj.tasks.length > 0) {
                        finalData.services.push(serviceObj);
                    }
                }
            });

            console.log('Submitting data:', finalData);
            submitMultipleServicesMilestone(finalData, button);
            return true;
        }

        function submitMultipleServicesMilestone(data, button) {
            const originalText = button.html();
            button.prop('disabled', true).html('<i class="mdi mdi-loading mdi-spin me-1"></i> Processing...');

            $.ajax({
                url: `/add_multiple_milestone_mapping`,
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    console.log('Submission response:', response);

                    switch (response.status) {
                        case 200:
                            toastr.success(response.message);
                            $('#assign_pc_button').html(
                                '<i class="mdi mdi-check-circle-outline me-1"></i> Success!');
                            $('#assign_pc_button').addClass('btn-success');

                            setTimeout(() => {
                                window.location.href = "/manage_service";
                            }, 1500);
                            break;

                        case 422:
                            toastr.error(response.error_msg || 'Validation failed');
                            break;

                        default:
                            toastr.error(response.message || 'Unknown error occurred');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error Details:', xhr);
                    let errorMessage = 'An error occurred while saving milestone.';
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON?.errors;
                        errorMessage = errors ? Object.values(errors).flat().join('<br>') :
                        'Validation failed.';
                    } else if (xhr.status === 500) {
                        errorMessage = 'Server error. Please contact support.';
                    }
                    toastr.error(errorMessage);
                },
                complete: function() {
                    setTimeout(() => {
                        button.prop('disabled', false).html(originalText);
                        $('#assign_pc_button').removeClass('btn-success');
                    }, 2000);
                }
            });
        }
    </script>

    <!-- Add Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

@endsection
