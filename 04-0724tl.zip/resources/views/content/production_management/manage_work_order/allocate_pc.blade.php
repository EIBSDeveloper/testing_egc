@extends('layouts/layoutMaster')

@section('title', 'Allocate Project Coordinator')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <div id="pc_assign_loader"
        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
        <div class="spinner-border text-primary fs-3" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    <div class="card mb-2">
        @php
            $helper = new \App\Helpers\Helpers();
        @endphp
        <div class="card-header border-bottom pb-1">
            <h5 class="mb-1 text-black" id="brch_fran_tle">Allocate Project Coordinator</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Service</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body mb-2 px-4 pb-2">
            <div class="row mb-4">
                <!-- Customer Details -->
                <div class="col-lg-6">
                    <div class="row mb-4">
                        <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold" id="assign_pc_cus_name">{{ $data->cus_name }}</label>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row mb-4">
                        <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-info fs-6 fw-bold"
                            id="assign_pc_customer_id">{{ $data->customer_id }}</label>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row mb-4">
                        <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold"
                            id="assign_pc_mobile_num">{{ $data->cus_mobile ?? '-' }}</label>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row mb-6">
                        <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                        <label class="col-1 text-black fs-6 fw-bold">:</label>
                        <label class="col-7 text-black fs-6 fw-bold"
                            id="assign_pc_cus_email">{{ $data->cus_email_id ?? '-' }}</label>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="text-black fs-5 fw-semibold">Domains</div>
                    <hr class="mt-1 mb-2">
                    <div class="text-dark text-start mb-4" id="allocate_pc_domains">
                        {{ is_array($data->domain_names) ? implode(', ', $data->domain_names) : 'No Domain Selected' }}
                    </div>
                </div>
                <!-- Service Details -->
                <div class="col-lg-6">
                    <div class="text-black fs-5 fw-semibold">Service Details</div>
                    <hr class="mt-1 mb-2">
                    <div class="row mb-4 scroll-y max-h-150px" id="product-list_staff">
                        @foreach ($data->product_list as $i => $service)
                            <div class="col-12 mb-3 service-item">
                                <div class="service-card border rounded-3 bg-white p-4 position-relative">
                                    <div
                                        class="service-number position-absolute top-0 start-0 bg-primary text-white px-3 py-1 rounded-end fs-7 fw-bold">
                                        Service {{ $i + 1 }}
                                    </div>
                                    <div class="row align-items-center mt-4">
                                        <div class="col-md-6">
                                            <div class="service-info">
                                                <label class="text-muted fs-7 fw-semibold mb-1">Service Name</label>
                                                <p class="text-dark fs-6 fw-bold mb-0">{{ $service->product_name }}</p>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="service-info">
                                                <label class="text-muted fs-7 fw-semibold mb-1">Variant</label>
                                                <p class="text-dark fs-6 mb-0">{{ $service->variant_name ?? '-' }}</p>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="service-info">
                                                <label class="text-muted fs-7 fw-semibold mb-1">Variable</label>
                                                <p class="text-dark fs-6 mb-0">{{ $service->variable_name ?? '-' }}</p>
                                            </div>
                                        </div>
                                        <div class="col-md-6 text-end">
                                            <span class="badge bg-info text-white fs-7">ID:
                                                {{ $service->service_id }}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6 mb-6">
                    <input type="hidden" id="assign_id" value="{{ $id }}">
                    <input type="hidden" id="service_length">
                    <label class="text-black mb-1 fs-6 fw-semibold">Project Coordinator<span
                            class="text-danger">*</span></label>
                    <select class="select3 form-select" id="assign_pc">
                        <option value="">Select Project Coordinator</option>
                    </select>
                    <div id="pc_add_err" class="text-danger fs-7 fw-semibold mt-1"></div> <!-- Fixed duplicate ID -->
                </div>
                <div class="col-lg-6">
                    <input class="form-check-input w-25px h-25px me-2" type="checkbox" id="journal_check" value="1"
                        onclick="journalServiceToggle(this.checked)" style="margin-top: 2rem !important;">
                    <label for="journal_check" class="text-dark fs-5 fw-bold cursor-pointer"
                        style="margin-top: 2rem !important;">Journal Publication</label>
                </div>
                <div class="d-none journal_service_container">
                    <div class="row">
                        <div class="col-lg-5 mb-6">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select pc_service_id" id="pc_service_id_0">
                            </select>
                            <div class="text-danger fs-7 fw-semibold mt-1 pc_service_id_err"></div>
                        </div>
                        <div class="col-lg-5 mb-6">
                            <label class="text-black mb-1 fs-6 fw-semibold">Journal Index<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select pc_journal_index_id" id="pc_journal_index_0"
                                data-placeholder="Select Journal Index" multiple>
                            </select>
                            <div class="text-danger fs-7 fw-semibold mt-1 pc_journal_index_err"></div>
                        </div>
                        <div class="col-lg-2 mb-1 d-none">
                            <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1">
                                <i class="mdi mdi-delete fs-4"></i>
                            </a>
                        </div>
                    </div>
                    <div id="staff_add_more_container"></div>
                    <div class="mb-4 mt-1 d-flex  justify-content-end ">
                        <button type="button" class="btn btn-sm btn-primary fs-8 px-2 py-1"
                            onclick="validateJournalAddMore()" id="journal_service_add">
                            <i class="mdi mdi-plus me-1"></i> Add More
                        </button>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2">
                <a href="{{ url('/manage_service') }}" class="btn fw-bold btn-secondary me-3">Cancel</a>
                <button type="button" class="btn fw-bold btn-primary" id="assign_pc_button" onclick="assignStaffValidation()">
                    Allocate Project Coordinator
                </button>
            </div>
        </div>
        </form>
    </div>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
        $(document).ready(function() {
            $('#pc_assign_loader').show();
            updateAddMoreButtonState();
            $('#journal_service_add').removeClass('d-none');
            resetAssignStaff();
            pcDataFetch();
        });

        function pcDataFetch() {
            $.ajax({
                url: `/get_allocate_pc`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const pcContainer = $('#assign_pc');
                        pcContainer.empty().append(`<option value="">Select Project Coordinator</option>`);

                        response.data.forEach(pc => {
                            pcContainer.append(
                                `<option value="${pc.sno}">${pc.staff_name} - ${pc.job_position_name}</option>`
                            );
                        });
                    } else {
                        console.error('Something Went Wrong.');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error :' + err);
                },
                complete: function() {
                    $('#pc_assign_loader').hide();
                }
            });
        }

        function journalServiceToggle(isChecked) {
            const assignId = $('#assign_id').val();
            if (isChecked) {
                populateServiceDropdown(0, assignId);
                populateJournalIndex(0);
                $('.journal_service_container').removeClass('d-none');
                $('.pc_service_id_err, .pc_journal_index_err').text('');
                
                // Reset to only one container when toggling ON
                $('.journal_service_container:gt(0)').remove();
                journalIndex = 1;
                
                updateAddMoreButtonState(); // Update button state
            } else {
                $('.journal_service_container').addClass('d-none');
            }
        }

        // Function to get currently selected service IDs across all dropdowns
        function getSelectedServiceIds() {
            const selectedIds = [];
            $('.pc_service_id').each(function() {
                const selectedValue = $(this).val();
                if (selectedValue) {
                    selectedIds.push(selectedValue);
                }
            });
            return selectedIds;
        }

        function populateServiceDropdown(rowIndex, id) {
            $.ajax({
                url: `/get_service_data_dropdown/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const serviceLength = response.data.length;
                        $('#service_length').val(serviceLength);

                        updateAddMoreButtonState();

                        const serviceContainer = $(`#pc_service_id_${rowIndex}`);
                        const currentlySelectedIds = getSelectedServiceIds();

                        serviceContainer.empty().append(`<option value="">Select Service</option>`);

                        response.data.forEach(service => {
                            // Only add service if it's not already selected in any dropdown
                            // OR if it's the current dropdown's selected value (to maintain current selection)
                            const currentValue = serviceContainer.val();
                            if (!currentlySelectedIds.includes(service.sno.toString()) ||
                                service.sno.toString() === currentValue) {
                                serviceContainer.append(
                                    `<option value="${service.sno}">${service.product_name} - ${service.variant_name} - ${service.variable_name}</option>`
                                );
                            }
                        });

                        // Re-select the current value if it exists
                        if (serviceContainer.data('current-value')) {
                            serviceContainer.val(serviceContainer.data('current-value')).trigger('change');
                        }

                    } else {
                        console.log('Something Went Wrong');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching data' + err);
                }
            });
        }

        function populateJournalIndex(index) {
            $.ajax({
                url: `/get_journal_indexings`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const indexContainer = $(`#pc_journal_index_${index}`);
                        indexContainer.empty();

                        response.data.forEach(i => {
                            indexContainer.append(`<option value="${i.sno}">${i.index_name}</option>`);
                        });

                    } else {
                        console.error('Error Fetching.');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function validateJournalAddMore() {
            let isValid = true;
            let toastErr = false;

            const journalContainers = $('.journal_service_container:visible');
            const serviceLength = $('#service_length').val();

            journalContainers.each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.pc_service_id');
                const journalSelect = container.find('.pc_journal_index_id');

                container.find('.pc_service_id_err, .pc_journal_index_err').text('');

                if (!serviceSelect.val()) {
                    container.find('.pc_service_id_err').text('Service is required.');
                    isValid = false;
                    toastErr = true;
                }

                if (!journalSelect.val() || journalSelect.val().length === 0) {
                    container.find('.pc_journal_index_err').text('Journal Index is required.');
                    isValid = false;
                    toastErr = true;
                }
            });

            if (toastErr) {
                return false;
            } else {
                if (journalContainers.length >= serviceLength) {
                    // toastr.error(`You cannot add more than ${serviceLength} journal services.`);
                    $('#journal_service_add').addClass('d-none');
                    return false;
                }
            }

            if (isValid) {
                addJournalContainer();
            }

            return isValid;
        }

        let journalIndex = 1;

        function addJournalContainer() {
            $('#staff_add_more_container').removeClass('d-none');
            const id = $('#assign_id').val();

            populateJournalIndex(journalIndex);
            populateServiceDropdown(journalIndex, id);

            var newJournalContainer = `
                <div class="row journal_service_container">
                    <div class="col-lg-5 mb-6">
                        <label class="text-black mb-1 fs-6 fw-semibold ">Service<span class="text-danger">*</span></label>
                        <select class="select3 form-select pc_service_id" id="pc_service_id_${journalIndex}">
                        </select>
                        <div  class="text-danger fs-7 fw-semibold mt-1 pc_service_id_err"></div>
                    </div>
                    <div class="col-lg-5 mb-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Journal Index<span class="text-danger">*</span></label>
                        <select class="select3 form-select pc_journal_index_id" id="pc_journal_index_${journalIndex}"  data-placeholder="Select Journal Index" multiple>
                        </select>
                        <div class="text-danger fs-7 fw-semibold mt-1 pc_journal_index_err"></div>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;"
                            class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 journal_container_remove">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                </div>
            `;

            $('#staff_add_more_container').append(newJournalContainer);

            $('.select3').each(function() {
                $(this).wrap('<div class="position-relative"></div>').select2({
                    dropdownParent: $(this).parent()
                });
            });

            journalIndex++;
            updateAddMoreButtonState();
        }

        function updateAddMoreButtonState() {
            const currentCount = $('.journal_service_container:visible').length;
            const serviceLength = parseInt($('#service_length').val() || 0);
            
            if (serviceLength <= 1) {
                $('#journal_service_add').addClass('d-none');
                return;
            }
            
            if (currentCount >= serviceLength) {
                $('#journal_service_add').addClass('d-none');
            } else {
                $('#journal_service_add').removeClass('d-none');
            }
        }

        $(document).on('click', '.journal_container_remove', function() {
            $(this).closest('.row').remove();
            updateAddMoreButtonState();
            // Refresh all service dropdowns when a container is removed
            // refreshAllServiceDropdowns();
        });

        // Function to refresh all service dropdowns to update available options
        // function refreshAllServiceDropdowns() {
        //     const assignId = $('#assign_id').val();
        //     $('.journal_service_container:visible').each(function(index) {
        //         const serviceSelect = $(this).find('.pc_service_id');
        //         // Store current value before refresh
        //         const currentValue = serviceSelect.val();
        //         serviceSelect.data('current-value', currentValue);
        //         populateServiceDropdown(getRowIndex(serviceSelect.attr('id')), assignId);
        //     });
        // }

        // Helper function to extract row index from element ID
        function getRowIndex(elementId) {
            const match = elementId.match(/pc_service_id_(\d+)/);
            return match ? match[1] : 0;
        }

        // Event handler for service selection change
        // $(document).on('change', '.pc_service_id', function() {
        //     // Refresh all other service dropdowns when a service is selected
        //     refreshAllServiceDropdowns();
        // });

        function assignStaffValidation() {
            const journalContainers = $('.journal_service_container:visible');
            const button = $('#assign_pc_button');
            const pcId = $('#assign_pc').val();
            const jouranlCheck = $('#journal_check').is(':checked');
            let isValid = true;

            $('.pc_service_id_err, .pc_journal_index_err, #pc_add_err').text('');

            if (pcId === '') {
                $('#pc_add_err').text('Project Coordinator is required.');
                isValid = false;
            }

            if (jouranlCheck) {
                journalContainers.each(function(index) {
                    const container = $(this);
                    const serviceSelect = container.find('.pc_service_id');
                    const journalSelect = container.find('.pc_journal_index_id');

                    container.find('.pc_service_id_err, .pc_journal_index_err').text('');

                    if (!serviceSelect.val()) {
                        container.find('.pc_service_id_err').text('Service is required.');
                        isValid = false;
                    }

                    if (!journalSelect.val() || journalSelect.val().length === 0) {
                        container.find('.pc_journal_index_err').text('Journal Index is required.');
                        isValid = false;
                    }
                });
            }

            if (!isValid) {
                return false;
            } else {
                const journalServices = [];
                button.prop('disabled', true).text('Assigning...');

                if (jouranlCheck) {
                    journalContainers.each(function(index) {
                        const container = $(this);
                        const serviceId = container.find('.pc_service_id').val();
                        const journalIndexes = container.find('.pc_journal_index_id').val();

                        journalServices.push({
                            service_id: serviceId,
                            journal_indexes: journalIndexes
                        });
                    });
                }

                const formData = {
                    project_coordinator_id: pcId,
                    journal_check: jouranlCheck ? 1 : 0,
                    journal_services: journalServices,
                    proposal_id: $('#assign_id').val(),
                    _token: $('meta[name="csrf-token"]').attr('content')
                };

                allocateProjectCoordinator(formData, button);
            }
        }

        function allocateProjectCoordinator(data, button) {
            $.ajax({
                url: `/add_assign_staff_work_order`,
                type: 'POST',
                data: data,
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(`${response.data.staff_name} Allocated Successfully!`);
                        resetAssignStaff();
                        assignDates(response.data.proposal_id);
                    } else {
                        toastr.error(response.message || 'Something Went Wrong');
                        button.prop('disabled', false).text('Allocate Project Coordinator');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    let errorMessage = 'Something went wrong';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                    toastr.error(errorMessage);
                    button.prop('disabled', false).text('Allocate Project Coordinator');
                }
            });
        }

        function resetAssignStaff() {
            $('#pc_add_err, .pc_service_id_err, .pc_journal_index_err').text('');
            $('#assign_pc').val('').trigger('change');
            $('#journal_check').prop('checked', false);
            $('.journal_service_container').not(':first').remove();
            const firstContainer = $('.journal_service_container:first');
            firstContainer.find('.pc_service_id').val('').trigger('change');
            firstContainer.find('select[id^="pc_journal_index_"]').val('').trigger('change');
            $('#assign_pc_button').prop('disabled', false).text('Allocate Project Coordinator');
            $('#staff_add_more_container').addClass('d-none');
            $('.journal_service_container').addClass('d-none');
            journalIndex = 1;
        }

        function assignDates(id) {
            $.ajax({
                url: '/ids/encrypt', // Your encryption route
                type: 'POST',
                data: {
                    values: id,
                    _token: "{{  csrf_token()  }}"
                },
                success: function(encrypted_course_id) {
                    window.location.href = "/schedule_dates/" + encrypted_course_id;
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error!',
                        text: xhr.responseJSON.message || 'Encryption failed.',
                        icon: 'error',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                }
            });
        }

        window.addEventListener('popstate', function (event) {
            window.location.href = "/manage_service";
        });
        
        history.pushState(null, null, location.href);
    </script>


@endsection
