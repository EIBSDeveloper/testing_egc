@extends('layouts/layoutMaster')

@section('title', 'Milestone Mapping')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <!-- Loading Overlay -->
    <div id="pc_assign_loader" class="loading-overlay">
        <div class="loading-content">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <div class="mt-3 text-primary fw-semibold">Loading Milestone Data...</div>
        </div>
    </div>

    <!-- Page Header -->
    <div class="card mb-2">
        @php
            $helper = new \App\Helpers\Helpers();
        @endphp
        <div class="card-header border-bottom pb-1">
            <h5 class="mb-1 text-black" id="brch_fran_tle">Milestone Mapping</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Service</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="card p-4">
        <div class="row">
            <!-- Left Column: Customer & Milestone Info -->
            <div class="col-lg-6">
                <div class="row mb-4">
                    <!-- Customer Details -->
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_cus_name">{{ $data->cus_name }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-info fs-6 fw-bold"
                                id="assign_pc_customer_id">{{ $data->customer_id }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-4">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_mobile_num">{{ $data->cus_mobile ?? '-' }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-6">
                            <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold"
                                id="assign_pc_cus_email">{{ $data->cus_email_id ?? '-' }}</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="row mb-6">
                            <label class="col-4 text-dark fs-6 fw-semibold">Domains</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" >{{ is_array($data->domain_names) ? implode(', ', $data->domain_names) : 'No Domain Selected' }}</label>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <input type="hidden" id="milestone_hide_cus_id" value="{{ $data->cus_sno }}">
                <input type="hidden" id="milestone_hide_proposal_id" value="{{ $id }}">

                <div class="form-group mb-4">
                    <label class="text-black mb-1 fs-6 fw-semibold">Milestone<span
                            class="text-danger">*</span></label>
                    <select class="select3 form-select" id="milestone_id"
                        onchange="fetchMilestoneServices()">
                        <option value="">Select Task</option>
                    </select>
                    <div id="milestone_id_err" class="text-danger mt-1 small"></div>
                </div>

                <div class="form-group mb-4">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                            class="text-danger">*</span></label>
                    <select class="select3 form-select" id="milestone_service_id"
                        onchange="fetchMileStoneTasks(this.value, 0)">
                        <option value="">Select Service</option>
                    </select>
                    <div id="milestone_service_id_err" class="text-danger mt-1 small"></div>
                </div>

                <!-- Service Summary -->
                {{-- <div class="service-summary" id="service_summary" style="display: none;">
                    <div class="summary-header">
                        <h6 class="summary-title mb-3">Service Overview</h6>
                    </div>
                    <div class="summary-content">
                        <div class="row g-2">
                            <div class="col-6">
                                <div class="summary-item">
                                    <div class="summary-label">Total Tasks</div>
                                    <div class="summary-value" id="summary_total_tasks">0</div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="summary-item">
                                    <div class="summary-label">Tasks Mapped</div>
                                    <div class="summary-value" id="summary_mapped_tasks">0</div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-success" id="mapping_progress" role="progressbar"
                                        style="width: 0%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> --}}
                    <div class="summary-stats card border-0 bg-light mt-4" id="progress_summary"
                    style="display: none;">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-checkbox-multiple-marked-circle-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Tasks</div>
                                        <div class="stat-value" id="total_tasks">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-file-document-outline"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Pages</div>
                                        <div class="stat-value" id="total_pages">0</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="stat-item text-center">
                                    <div class="stat-icon">
                                        <i class="mdi mdi-percent"></i>
                                    </div>
                                    <div class="stat-content">
                                        <div class="stat-label">Total Percentage</div>
                                        <div class="stat-value" id="total_percentage">0%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Task Mapping -->
            <div class="col-lg-12">
                <!-- Task Mapping Card -->
                <div class="border border-light border-1 rounded">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col">
                                <h4 class="card-header-title text-black">
                                    <i class="mdi mdi-format-list-checkbox me-2"></i>
                                    Task Mapping
                                </h4>
                                <p class="card-header-subtitle text-muted mb-0" id="task_count_message">Select a service
                                    to start mapping tasks</p>
                            </div>
                            <div class="col-auto">
                                <button type="button" class="btn btn-primary btn-add-task" onclick="milestoneAddMore()"
                                    id="milestone_add_more_btn">
                                    <i class="mdi mdi-plus-circle-outline me-1"></i>
                                    Add Task
                                </button>
                            </div>
                        </div>
                    </div>
                    <hr>

                    <div class="card-body">
                        <input type="hidden" id="milestone-hidden-service-id">
                        <input type="hidden" id="product_category_id">

                        <!-- Empty State -->
                        <div class="empty-state" id="empty_state" style="display: none;">
                            <div class="empty-state-icon">
                                <i class="mdi mdi-playlist-plus"></i>
                            </div>
                            <h5 class="empty-state-title">No Tasks Added Yet</h5>
                            <p class="empty-state-text">Click "Add Task" to start mapping tasks to this milestone</p>
                        </div>

                        {{-- <div class="row"> --}}
                            {{-- <div class="col-lg-6">
                                <div class="task-containers" id="task_containers">
                                </div>
                            </div> --}}
                            <div id="milestone_mapping_add_container" class="row"></div>
                        {{-- </div> --}}
                    </div>
                </div>
            </div>
        </div>
        <div class="d-flex justify-content-end gap-2">
            <a href="{{ url('/manage_service') }}" class="btn btn-outline-secondary btn-cancel">
                <i class="mdi mdi-close me-1"></i>
                Cancel
            </a>
            <button type="button" class="btn btn-primary btn-submit" id="assign_pc_button"
                onclick="milestoneAddValidation()">
                <i class="mdi mdi-check-circle-outline me-1"></i>
                Map Milestone
            </button>
        </div>
    </div>

    <style>
        /* Loading Overlay */
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(4px);
        }

        .loading-content {
            text-align: center;
            animation: fadeIn 0.3s ease;
        }

        .loading-content .spinner-border {
            width: 3rem;
            height: 3rem;
        }

        /* Page Header */
        .page-header {
            padding: 2rem 0;
            border-bottom: 1px solid #e9ecef;
        }

        .page-pretitle {
            color: #6c757d;
            text-transform: uppercase;
            font-size: 0.875rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }

        .page-title {
            font-size: 1.75rem;
            font-weight: 700;
            color: #212529;
            margin-bottom: 0.5rem;
        }

        .page-subtitle {
            font-size: 0.9375rem;
            color: #6c757d;
        }

        /* Card Styles */
        .card-profile {
            border: none;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            overflow: hidden;
        }

        .card-profile::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #007bff, #00d4ff);
        }

        .card-settings,
        .card-mapping,
        .card-tips {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            overflow: hidden;
        }

        .card-settings .card-header,
        .card-mapping .card-header,
        .card-tips .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-bottom: none;
            padding: 1.25rem 1.5rem;
        }

        .card-header-title {
            color: white;
            font-size: 1.125rem;
            font-weight: 600;
            margin: 0;
        }

        .card-header-subtitle {
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.875rem;
        }

        /* Profile Styles */
        .profile-header {
            padding: 1rem;
            background: linear-gradient(135deg, #f0f7ff 0%, #e3f2fd 100%);
            border-radius: 10px;
            margin: -1rem;
            margin-bottom: 1rem;
        }

        .profile-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 28px;
        }

        .profile-name {
            font-size: 1.25rem;
            font-weight: 700;
            color: #212529;
            margin: 0;
        }

        .profile-id .badge {
            font-size: 0.75rem;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 500;
        }

        /* Detail Items */
        .detail-item {
            padding: 0.75rem;
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 0.75rem;
            transition: all 0.2s ease;
        }

        .detail-item:hover {
            background: #e9ecef;
            transform: translateX(4px);
        }

        .detail-item:last-child {
            margin-bottom: 0;
        }

        .detail-label {
            font-size: 0.8125rem;
            color: #6c757d;
            margin-bottom: 0.25rem;
            display: flex;
            align-items: center;
        }

        .detail-value {
            font-size: 0.9375rem;
            font-weight: 600;
            color: #212529;
            word-break: break-word;
        }

        /* Form Styles */
        .form-group {
            position: relative;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.875rem;
            color: #495057;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
        }

        .input-group {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            transition: all 0.2s ease;
        }

        .input-group:focus-within {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.15);
        }

        .input-group-text {
            background-color: #f8f9fa;
            border: none;
            color: #6c757d;
        }

        /* .form-select {
                border: none;
                padding: 0.75rem 1rem;
                font-size: 0.9375rem;
                background-color: white;
            }
            
            .form-select:focus {
                box-shadow: none;
                background-color: white;
            } */

        /* Service Summary */
        .service-summary {
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 1.25rem;
            margin-top: 1rem;
            animation: slideIn 0.3s ease;
        }

        .summary-title {
            font-size: 1rem;
            font-weight: 600;
            color: #495057;
            border-bottom: 2px solid #007bff;
            padding-bottom: 0.5rem;
        }

        .summary-item {
            text-align: center;
        }

        .summary-label {
            font-size: 0.75rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .summary-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #007bff;
            line-height: 1.2;
        }

        .progress {
            border-radius: 10px;
            background-color: #e9ecef;
            overflow: hidden;
        }

        .progress-bar {
            border-radius: 10px;
            transition: width 0.6s ease;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
        }

        .empty-state-icon {
            font-size: 4rem;
            color: #dee2e6;
            margin-bottom: 1.5rem;
        }

        .empty-state-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: #6c757d;
            margin-bottom: 0.5rem;
        }

        .empty-state-text {
            color: #adb5bd;
            font-size: 0.9375rem;
        }

        /* Task Container Styles */
        .task-container {
            background: white;
            border: 1px solid #e9ecef;
            border-radius: 10px;
            padding: 1.25rem;
            margin-bottom: 1rem;
            position: relative;
            transition: all 0.3s ease;
            /* border-left: 4px solid #007bff; */
        }

        /* .task-container:hover {
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08);
            transform: translateY(-2px);
            border-left-color: #00d4ff;
        } */

        .task-header {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }

        .task-number {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            color: white;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.875rem;
            margin-right: 0.75rem;
        }

        .task-title {
            font-size: 1rem;
            font-weight: 600;
            color: #212529;
            margin: 0;
        }

        /* Button Styles */
        .btn-add-task {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border: none;
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.25);
        }

        .btn-add-task:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0, 123, 255, 0.3);
        }

        .btn-add-task:disabled {
            opacity: 0.6;
            transform: none !important;
            box-shadow: none !important;
        }

        .btn-cancel {
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            border: 2px solid #dee2e6;
            background: white;
        }

        .btn-submit {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            border-radius: 8px;
            padding: 0.625rem 1.25rem;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.25);
            transition: all 0.3s ease;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(40, 167, 69, 0.3);
        }

        .btn-submit:disabled {
            opacity: 0.6;
            transform: none !important;
            box-shadow: none !important;
        }

        /* Summary Stats */
        .summary-stats {
            border-radius: 12px;
            animation: fadeIn 0.5s ease;
        }

        .stat-item {
            padding: 1rem;
            position: relative;
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            margin: 0 auto 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
        }

        .stat-item:nth-child(2) .stat-icon {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }

        .stat-item:nth-child(3) .stat-icon {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        .stat-label {
            font-size: 0.8125rem;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 0.25rem;
        }

        .stat-value {
            font-size: 1.75rem;
            font-weight: 700;
            color: #212529;
            line-height: 1.2;
        }

        /* Tips Card */
        .card-tips .card-header {
            background: linear-gradient(135deg, #ffd166 0%, #ff9e6d 100%);
        }

        .tips-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }

        .tip-item {
            display: flex;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .tip-item:last-child {
            border-bottom: none;
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }

            100% {
                transform: scale(1);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .page-title {
                font-size: 1.5rem;
            }

            .profile-icon {
                width: 50px;
                height: 50px;
                font-size: 24px;
            }

            .profile-name {
                font-size: 1.125rem;
            }

            .btn-add-task,
            .btn-cancel,
            .btn-submit {
                padding: 0.5rem 1rem;
                font-size: 0.875rem;
            }
        }

        /* Select2 Custom Styling */
        /* .select2-container--default .select2-selection--single,
            .select2-container--default .select2-selection--multiple {
                border: none !important;
                background: transparent !important;
                min-height: 44px !important;
            }
            
            .select2-container--default .select2-selection--single .select2-selection__rendered {
                line-height: 44px !important;
                padding-left: 0 !important;
                color: #495057 !important;
                font-size: 0.9375rem;
            }
            
            .select2-container--default .select2-selection--single .select2-selection__arrow {
                height: 44px !important;
            }
            
            .select2-container--open .select2-dropdown {
                border-radius: 10px !important;
                border: 1px solid #dee2e6 !important;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08) !important;
                margin-top: 4px;
            }
            
            .select2-container--default .select2-results__option--highlighted[aria-selected] {
                background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%) !important;
                color: white !important;
            }
             */
        /* Form Text */
        .form-text {
            display: flex;
            align-items: center;
            color: #6c757d;
            font-size: 0.875rem;
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }

        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #007bff 0%, #00d4ff 100%);
            border-radius: 10px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #0056b3 0%, #00b3d4 100%);
        }
    </style>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Custom Toastr Styling */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            // showToast(type, message);
        @endif
    </script>

    <script>
        let milestoneIndex = 1;
        let maxTaskCount = 0;
        let taskCounter = 1;

        function resetMilestonItems() {
            try {
                // 1. Reset service dropdown
                $('#milestone_service_id').val('').trigger('change');

                // 2. Hide service summary
                $('#service_summary').hide();

                // 3. Clear task containers
                // $('#milestone_mapping_add_container').empty();
                $('#milestone_mapping_add_container').empty();

                // 4. Show empty state
                $('#empty_state').show();
                $('#progress_summary').hide();

                // 5. Reset global variables
                milestoneIndex = 1;
                maxTaskCount = 0;
                taskCounter = 1;

                // 6. Reset hidden fields
                $('#milestone-hidden-service-id').val('');

                // 7. Clear validation errors
                $('.text-danger').text('');
                $('.form-select').removeClass('is-invalid');

                // 8. Reset add more button
                $('#milestone_add_more_btn')
                    .prop('disabled', true)
                    .addClass('disabled')
                    .html('<i class="mdi mdi-plus-circle-outline me-1"></i> Add Task');

                // 9. Update messages
                $('#task_count_message').text('Select a service to start mapping tasks');
                $('#current_instruction').text('Fill all required fields to map milestone');

            } catch (error) {
                console.error('Error resetting milestone items:', error);
            }
        }

        function updateServiceSummary() {
            const selectedCount = getSelectedTaskCount();
            const progressPercentage = maxTaskCount > 0 ? (selectedCount / maxTaskCount) * 100 : 0;

            // $('#summary_total_tasks').text(maxTaskCount);
            // $('#summary_mapped_tasks').text(selectedCount);
            // $('#mapping_progress').css('width', `${progressPercentage}%`);

            if (maxTaskCount > 0) {
                $('#service_summary').show();
            } else {
                $('#service_summary').hide();
            }
        }

        function updateProgressSummary() {
            const totalTasks = $('.milestone_mapping_container').length;
            const totalPages = Array.from($('.product-pages')).reduce((sum, input) => sum + (parseInt(input.value) || 0),
            0);
            const totalPercentage = Array.from($('.product-percentage')).reduce((sum, input) => sum + (parseInt(input
                .value) || 0), 0);

            $('#total_tasks').text(totalTasks);
            $('#total_pages').text(totalPages);
            $('#total_percentage').text(totalPercentage + '%');

            if (totalTasks > 0) {
                $('#progress_summary').show();
                $('#empty_state').hide();
            } else {
                $('#progress_summary').hide();
                $('#empty_state').show();
            }
        }

        $(document).ready(function() {
            fetchMilestone();

            // Initialize select2 fields
            // $('.select2-field').each(function() {
            //     $(this).select2({
            //         theme: 'bootstrap-5',
            //         placeholder: $(this).attr('placeholder') || 'Select an option',
            //         allowClear: true,
            //         width: '100%'
            //     });
            // });

            // Update task count message
            $('#task_count_message').text('Select a service to start mapping tasks');
        });

        function fetchMilestone() {
            $('#pc_assign_loader').show();
            const id = "{{ $id }}";

            $.ajax({
                url: `/get_milestone_data/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const milestoneContainer = $('#milestone_id');
                        milestoneContainer.empty().append(`<option value="">Select Milestone</option>`);
                        
                        // Store expected percentage in data attribute
                        response.data.forEach(mile => {
                            milestoneContainer.append(
                                `<option value="${mile.sno}" data-expected="${mile.expected_percentage}">
                                    ${mile.payment_slot_name}
                                </option>`);
                        });
                        
                        // Store totals globally
                        window.totalServices = response.total_services;
                        window.totalMilestones = response.total_milestones;
                        window.expectedPerMilestone = response.expected_per_milestone;
                        
                        // Update UI to show totals
                        updateMilestoneSummary();
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load milestones');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load milestones');
                },
                complete: function() {
                    $('#pc_assign_loader').hide();
                }
            });
        }

        function updateMilestoneSummary() {
            if (window.totalServices && window.totalMilestones) {
                const summaryHtml = `
                   
                `;
                
                // Add after the milestone dropdown or in a summary section
                if (!$('#milestone_summary').length) {
                    $('#milestone_id').after('<div id="milestone_summary"></div>');
                }
                $('#milestone_summary').html(summaryHtml);
            }
        }

        function updateCurrentMilestoneUsage() {
            const milestoneId = $('#milestone_id').val();
            if (!milestoneId) return;
            
            const selectedMilestone = $(`#milestone_id option[value="${milestoneId}"]`);
            const expectedPercentage = selectedMilestone.data('expected') || window.expectedPerMilestone;
            
            // Fetch current usage for this milestone
            $.ajax({
                url: `/get_milestone_current_usage/${milestoneId}`,
                type: 'GET',
                data: {
                    proposal_id: $('#milestone_hide_proposal_id').val()
                },
                success: function(response) {
                    if (response.status === 200) {
                        const remaining = expectedPercentage - response.current_total;
                        const usageHtml = `
                            <div class="alert ${remaining <= 0 ? 'alert-warning' : 'alert-success'} mt-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <small>
                                        <strong>Milestone Usage:</strong> ${response.current_total}% / ${expectedPercentage}%
                                    </small>
                                    <small>
                                        <strong>Remaining:</strong> ${remaining > 0 ? remaining + '%' : '0%'}
                                    </small>
                                </div>
                                ${remaining <= 0 ? '<small class="text-danger">This milestone has reached its maximum allocation</small>' : ''}
                            </div>
                        `;
                        
                        if (!$('#milestone_usage').length) {
                            $('#milestone_summary').append('<div id="milestone_usage"></div>');
                        }
                        $('#milestone_usage').html(usageHtml);
                    }
                }
            });
        }

        

        // Call this when milestone is selected
        $('#milestone_id').on('change', function() {
            updateCurrentMilestoneUsage();
        });

        function fetchMilestoneServices() {
            const milestoneId = $('#milestone_id').val();
            if (!milestoneId) return;

            // $('#pc_assign_loader').show();
            const proposalId = $('#milestone_hide_proposal_id').val();

            $.ajax({
                url: `/get_milestone_service_data/${proposalId}`,
                type: 'GET',
                data: {
                    milestone_id: milestoneId
                },
                success: function(response) {
                    if (response.status === 200) {
                        const serviceContainer = $('#milestone_service_id');
                        serviceContainer.empty().append(`<option value="">Select Service</option>`);
                        response.data.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.product_name} - ${service.service_id}</option>`
                            );
                        });
                        // Reinitialize select2
                        // serviceContainer.select2({
                        //     theme: 'bootstrap-5',
                        //     width: '100%'
                        // });

                        // Update task count message
                        $('#task_count_message').text('Select a service to add tasks');
                        $('#current_instruction').text('Choose a service from the dropdown');
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load services');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load services');
                },
                complete: function() {
                    // $('#pc_assign_loader').hide();
                }
            });
        }

        function getTaskCategory(id, index) {
            if (!id) {
                $(`#milestone_category_container_${index}`).empty();
                updateProgressSummary();
                return;
            }

            $.ajax({
                url: `/get_task_category/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const categoryContainer = $(`#milestone_category_container_${index}`);
                        categoryContainer.empty();

                        let html = '';
                        if (response.data.category_check == 0) {
                            html = `
                            <div class="col-lg-12 mt-3">
                                <div class="form-group">
                                    <label class="form-label">
                                        <i class="mdi mdi-file-document-outline me-1"></i>
                                        Pages <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-light">
                                            <i class="mdi mdi-numeric"></i>
                                        </span>
                                        <input type="text" class="form-control product-pages" 
                                               placeholder="Enter number of pages" 
                                               id="product_pages_${index}"
                                               oninput="updateProgressSummary()"/>
                                    </div>
                                    <div class="text-danger mt-1 small pages_err"></div>
                                    <small class="text-muted">Enter the number of pages for this task</small>
                                </div>
                            </div>
                        `;
                        } else {
                            html = `
                           
                        `;
                        }
                        categoryContainer.html(html);
                        updateProgressSummary();

                        // Add animation to new input
                        setTimeout(() => {
                            categoryContainer.find('input').addClass(
                                'animate__animated animate__fadeIn');
                        }, 100);
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                    toastr.error('Failed to load task category');
                }
            });
        }

        function createTaskContainer(index, isFirst = false) {
            const taskNumber = isFirst ? taskCounter : taskCounter++;

            return `
            <div class="milestone_mapping_container col-lg-6  task-container animate__animated animate__fadeInUp" id="milestone_container_${index}">
                <div class="row g-3">
                    <div class="col-lg-8">
                        <div class="form-group">
                            <label class="text-black mb-1 fs-6 fw-semibold">Task<span class="text-danger">*</span></label>
                            <select class="select3  form-select milestone-task" id="milestone_task_id_${index}"  onchange="handleTaskSelection(this.value, ${index})">
                                <option value="">Select Task</option>
                            </select>
                            <div class="text-danger mt-1 small milestone_task_id_err"></div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label class="form-label">
                                <i class="mdi mdi-cog-outline me-1"></i>
                                Action
                            </label>
                            <div class="d-grid">
                                <button type="button" class="btn btn-outline-danger btn-sm milestone_container_remove" ${isFirst ? 'disabled style="opacity:0.5"' : ''}>
                                    <i class="mdi mdi-delete me-1"></i> Remove
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-12" id="milestone_category_container_${index}"></div>
                </div>
            </div>
        `;
        }

        function fetchMileStoneTasks(id, index) {
            if (!id) return;

            // $('#pc_assign_loader').show();

            $.ajax({
                url: `/get_milestone_product/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        maxTaskCount = response.task_count;
                        $('#milestone-hidden-service-id').val(id);

                        if (index === 0) {
                            // Create first task container
                            $('#milestone_mapping_add_container').html(createTaskContainer(0, true));
                            $('#empty_state').hide();
                            taskCounter = 1;
                        }

                        const taskContainer = $(`#milestone_task_id_${index}`);
                        taskContainer.empty().append(`<option value="">Select Task</option>`);

                        const selectedTaskIds = getSelectedTaskIds();

                        response.data.forEach(task => {
                            if (!selectedTaskIds.includes(task.sno.toString())) {
                                taskContainer.append(
                                    `<option value="${task.sno}" data-description="${task.description || ''}">${task.task_name}</option>`
                                    );
                            }
                        });

                        const select3 = $('.select3');
                        if (select3.length) {
                            select3.each(function() {
                                const $this = $(this);

                                // Wrap only if not already wrapped
                                if (!$this.parent().hasClass('position-relative')) {
                                    $this.wrap('<div class="position-relative"></div>');
                                }

                                // Call your custom function (ensure it's defined elsewhere)
                                select2Focus($this);

                                // Initialize Select2 with dropdownParent
                                $this.select2({
                                    dropdownParent: $this.parent()
                                });
                            });
                        }


                        // Reinitialize select2
                        // taskContainer.select2({
                        //     theme: 'bootstrap-5',
                        //     width: '100%',
                        //     templateResult: function(data) {
                        //         if (!data.id) return data.text;
                        //         return $('<span>').addClass('task-option').html(`
                    //             <div class="task-option-name">${data.text}</div>
                    //             ${data.element.dataset.description ? `<div class="task-option-desc">${data.element.dataset.description}</div>` : ''}
                    //         `);
                        //     }
                        // });

                        updateAddMoreButtonState();
                        updateServiceSummary();

                        // Update message
                        $('#current_instruction').text('Select tasks and enter required values');

                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load tasks');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                    toastr.error('Failed to load tasks');
                },
                complete: function() {
                    // $('#pc_assign_loader').hide();
                }
            });
        }

        function getSelectedTaskCount() {
            let count = 0;
            $('.milestone-task').each(function() {
                if ($(this).val() && $(this).val() !== '') {
                    count++;
                }
            });
            return count;
        }

        function updateAddMoreButtonState() {
            const selectedCount = getSelectedTaskCount();
            const addMoreButton = $('#milestone_add_more_btn');
            const remainingTasks = maxTaskCount - selectedCount;

            if (selectedCount >= maxTaskCount) {
                addMoreButton.prop('disabled', true);
                addMoreButton.addClass('disabled');
                addMoreButton.html('<i class="mdi mdi-check-all me-1"></i> All Tasks Added');
                $('#task_count_message').html(
                    '<span class="text-success"><i class="mdi mdi-check-circle-outline me-1"></i>All tasks have been mapped</span>'
                    );
            } else {
                addMoreButton.prop('disabled', false);
                addMoreButton.removeClass('disabled');
                addMoreButton.html('<i class="mdi mdi-plus-circle-outline me-1"></i> Add Task');
                $('#task_count_message').text(`${remainingTasks} tasks remaining out of ${maxTaskCount}`);
            }

            updateServiceSummary();
        }

        function getSelectedTaskIds() {
            const selectedIds = [];
            $('.milestone-task').each(function() {
                const selectedValue = $(this).val();
                if (selectedValue && selectedValue !== '') {
                    selectedIds.push(selectedValue);
                }
            });
            return selectedIds;
        }

        function updateAllTaskDropdowns() {
            const selectedIds = getSelectedTaskIds();
            $('.milestone-task').each(function() {
                const currentDropdown = $(this);
                const currentValue = currentDropdown.val();
                const currentSelection = currentValue;
                const allOptions = currentDropdown.find('option');

                allOptions.each(function() {
                    const option = $(this);
                    const optionValue = option.val();
                    if (optionValue && optionValue !== '') {
                        if (selectedIds.includes(optionValue) && optionValue !== currentSelection) {
                            option.prop('disabled', true);
                        } else {
                            option.prop('disabled', false);
                        }
                    }
                });

                if (currentSelection && currentDropdown.find('option:selected').prop('disabled')) {
                    currentDropdown.val('').trigger('change');
                    const index = currentDropdown.attr('id').split('_').pop();
                    $(`#milestone_category_container_${index}`).empty();
                }
            });

            updateProgressSummary();
        }

        function milestoneAddMore() {
            const id = $('#milestone-hidden-service-id').val();
            if (!id) {
                toastr.error('Please select a service first');
                return;
            }

            const selectedCount = getSelectedTaskCount();
            if (selectedCount >= maxTaskCount) {
                toastr.error(`You can only add up to ${maxTaskCount} tasks`);
                return;
            }

            const currentIndex = milestoneIndex;

            // Create new task container
            const newTaskContainer = createTaskContainer(currentIndex);
            $('#milestone_mapping_add_container').append(newTaskContainer);

            // Fetch tasks for this new container
            fetchMileStoneTasks(id, currentIndex);

            milestoneIndex++;
            updateAddMoreButtonState();

            // Add pulse animation to new container
            $(`#milestone_container_${currentIndex}`).addClass('animate__pulse');
            setTimeout(() => {
                $(`#milestone_container_${currentIndex}`).removeClass('animate__pulse');
            }, 1000);

        }

        function handleTaskSelection(taskId, index) {
            updateAllTaskDropdowns();
            updateAddMoreButtonState();
            getTaskCategory(taskId, index);

            // Update current instruction
            $('#current_instruction').text('Enter the required values for each task');
        }

        $(document).on('click', '.milestone_container_remove', function() {
            if ($(this).is(':disabled')) return;

            const container = $(this).closest('.milestone_mapping_container');
            container.addClass('animate__animated animate__fadeOut');

            setTimeout(() => {
                container.remove();
                updateAllTaskDropdowns();
                updateAddMoreButtonState();
                updateProgressSummary();

                // Renumber remaining tasks
                $('.milestone_mapping_container').each(function(index) {
                    $(this).find('.task-number').text(index + 1);
                    $(this).find('.task-title').text(`Task ${index + 1}`);
                });
                taskCounter = $('.milestone_mapping_container').length + 1;

                toastr.success('Task removed');
            }, 300);
        });

        $(document).on('input', '.product-pages', function() {
            this.value = this.value.replace(/[^0-9]/g, '').replace(/^0+/, '');
            updateProgressSummary();
        });

        $(document).on('input', '.product-percentage', function() {
            this.value = this.value.replace(/[^0-9]/g, '').substring(0, 3);
            if (parseInt(this.value) > 100) this.value = '100';
            updateProgressSummary();
        });

        function milestoneAddValidation() {
            let isValid = true;
            const button = $('#assign_pc_button');

            // Reset errors
            $('.text-danger').text('');
            $('.form-select, .form-control').removeClass('is-invalid');

            const milestoneId = $('#milestone_id').val();
            const serviceId = $('#milestone_service_id').val();

            // Validate milestone selection
            if (!milestoneId) {
                $('#milestone_id_err').text('Please select a milestone');
                isValid = false;
                $('#milestone_id').addClass('is-invalid');
                return false;
            }

            // Validate service selection
            if (!serviceId) {
                $('#milestone_service_id_err').text('Please select a service');
                isValid = false;
                $('#milestone_service_id').addClass('is-invalid');
                return false;
            }

            // Check if at least one task is added
            if ($('.milestone_mapping_container').length === 0) {
                toastr.error('Please add at least one task');
                isValid = false;
                return false;
            }

            // Track percentage-based tasks
            let hasPercentageTasks = false;
            let hasPageTasks = false;
            let totalPercentage = 0;
            let totalPages = 0;

            // Validate ALL tasks
            $('.milestone_mapping_container').each(function() {
                const taskSelect = $(this).find('.milestone-task');
                const taskValue = taskSelect.val();

                if (!taskValue) {
                    $(this).find('.milestone_task_id_err').text('Please select a task');
                    isValid = false;
                    taskSelect.addClass('is-invalid');
                }

                // Pages validation
                const pagesInput = $(this).find('.product-pages');
                if (pagesInput.length > 0 && pagesInput.is(':visible')) {
                    hasPageTasks = true;
                    const pagesVal = pagesInput.val().trim();
                    if (pagesVal === '') {
                        $(this).find('.pages_err').text('Pages is required');
                        isValid = false;
                        pagesInput.addClass('is-invalid');
                    } else if (parseInt(pagesVal) <= 0) {
                        $(this).find('.pages_err').text('Pages must be greater than 0');
                        isValid = false;
                        pagesInput.addClass('is-invalid');
                    } else {
                        totalPages += parseInt(pagesVal);
                    }
                }

                // Percentage validation
                const percentageInput = $(this).find('.product-percentage');
                if (percentageInput.length > 0 && percentageInput.is(':visible')) {
                    hasPercentageTasks = true;
                    const percentVal = percentageInput.val().trim();
                    if (percentVal === '') {
                        $(this).find('.percentage_err').text('Percentage is required');
                        isValid = false;
                        percentageInput.addClass('is-invalid');
                    } else if (parseInt(percentVal) <= 0) {
                        $(this).find('.percentage_err').text('Percentage must be greater than 0');
                        isValid = false;
                        percentageInput.addClass('is-invalid');
                    } else if (parseInt(percentVal) > 100) {
                        $(this).find('.percentage_err').text('Percentage cannot exceed 100');
                        isValid = false;
                        percentageInput.addClass('is-invalid');
                    } else {
                        totalPercentage += parseInt(percentVal);
                    }
                }
            });

            // Validate percentage total MUST be exactly 100% if there are percentage tasks
            // if (hasPercentageTasks && totalPercentage !== 100) {
            //     toastr.error(`Total percentage must be exactly 100%. Currently: ${totalPercentage}%`);
            //     isValid = false;
            //     return false;
            // }

            // Validate pages total (if you want pages validation too)
            if (hasPageTasks && totalPages <= 0) {
                toastr.error('Total pages must be greater than 0');
                isValid = false;
                return false;
            }

            // Check if percentage tasks and page tasks are mixed (should not happen)
            // if (hasPercentageTasks && hasPageTasks) {
            //     toastr.error('Cannot mix percentage-based and page-based tasks in the same service');
            //     isValid = false;
            //     return false;
            // }

            // Additional validation: Check milestone usage
            const selectedMilestone = $(`#milestone_id option[value="${milestoneId}"]`);
            const expectedPercentage = selectedMilestone.data('expected') || window.expectedPerMilestone;
            
            // Make AJAX call to check milestone usage
            $.ajax({
                url: `/get_milestone_current_usage/${milestoneId}`,
                type: 'GET',
                async: false, // Synchronous for validation
                data: {
                    proposal_id: $('#milestone_hide_proposal_id').val()
                },
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;
                        
                        // Check if milestone is already completed
                        if (data.is_completed) {
                            toastr.error('This milestone has already reached its maximum allocation and is marked as completed.');
                            isValid = false;
                            return;
                        }
                        
                        // Check if this service is already mapped to this milestone
                        if (data.mapped_services.includes(parseInt(serviceId))) {
                            // This service is already mapped, allow updates but not exceeding 100% per service
                            // This is handled in backend
                        }
                        
                        // Check total milestone allocation
                        const currentMilestoneTotal = data.current_total;
                        const newTotal = currentMilestoneTotal + totalPercentage;
                        
                        if (newTotal > expectedPercentage) {
                            toastr.error(
                                `Milestone cannot exceed ${expectedPercentage}% total. ` +
                                `Current: ${currentMilestoneTotal}%, ` +
                                `Adding: ${totalPercentage}%, ` +
                                `Would be: ${newTotal}%`
                            );
                            isValid = false;
                        }
                    }
                },
                error: function() {
                    toastr.error('Unable to verify milestone usage');
                    isValid = false;
                }
            });

            if (!isValid) {
                toastr.error('Please fix all validation errors before submitting');
                return false;
            }

            // Build form data
            let taskData = [];
            let pagesData = [];
            let percentageData = [];

            $('.milestone_mapping_container').each(function() {
                const taskVal = $(this).find('.milestone-task').val();
                const pagesVal = $(this).find('.product-pages').val() || '';
                const percentVal = $(this).find('.product-percentage').val() || '';

                taskData.push(taskVal);
                pagesData.push(pagesVal);
                percentageData.push(percentVal);
            });

            const finalData = {
                customer_id: $('#milestone_hide_cus_id').val(),
                proposal_id: $('#milestone_hide_proposal_id').val(),
                milestone_id: milestoneId,
                service_id: serviceId,
                tasks: taskData,
                pages: pagesData,
                percentages: percentageData,
                total_percentage: totalPercentage,
                total_pages: totalPages
            };

            submitMilestoneMapping(finalData, button);
            return true;
        }

        function submitMilestoneMapping(data, button) {
            const originalText = button.html();
            button.prop('disabled', true).html('<i class="mdi mdi-loading mdi-spin me-1"></i> Processing...');

            $.ajax({
                url: `/add_milestone_mapping`,
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    switch (response.status) {
                        case 200:
                            toastr.success(response.message);
                            $('#assign_pc_button').html(
                                '<i class="mdi mdi-check-circle-outline me-1"></i> Success!');
                            $('#assign_pc_button').addClass('btn-success');

                            window.location.href = "/manage_service";
                            break;

                        case 422:
                            toastr.error(response.error_msg || 'Validation failed');
                            break;

                        default:
                            toastr.error(response.message || 'Unknown error occurred');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error Details:', xhr);
                    let errorMessage = 'An error occurred while saving milestone.';
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON?.errors;
                        errorMessage = errors ? Object.values(errors).flat().join('<br>') :
                        'Validation failed.';
                    } else if (xhr.status === 500) {
                        errorMessage = 'Server error. Please contact support.';
                    }
                    toastr.error(errorMessage);
                },
                complete: function() {
                    setTimeout(() => {
                        button.prop('disabled', false).html(originalText);
                        $('#assign_pc_button').removeClass('btn-success');
                    }, 2000);
                }
            });
        }
    </script>

    <!-- Add Animate.css for animations -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">

@endsection
