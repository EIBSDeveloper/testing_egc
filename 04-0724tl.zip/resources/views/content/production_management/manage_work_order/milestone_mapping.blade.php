@extends('layouts/layoutMaster')

@section('title', 'Milestone Mapping')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }
</style>
<!-- Task List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">
                Milestone Mapping
            </h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Services</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
        <div class="row mb-6">
            <div class="col-lg-4 d-flex align-items-center justify-content-start gap-2">
                <span class="bg-gray-200 rounded-circle p-2">
                    <i class="mdi mdi-account-outline fs-4"></i>
                </span>
                <div class="d-flex flex-column">
                    <label class="text-black fs-6 fw-semibold">{{ $data->cus_name }}</label>
                    <label class="text-dark fs-8 fw-semibold">{{ $data->customer_id }}5</label>
                </div>
            </div>
            <div class="col-lg-4 d-flex align-items-center justify-content-start gap-2">
                <span class="bg-gray-200 rounded-circle p-2">
                    <i class="mdi mdi-phone-outline fs-4"></i>
                </span>
                <div class="d-flex flex-column">
                    <label class="text-black fs-6 fw-semibold">{{ $data->cus_mobile ?? 'Not provided' }}</label>
                    <label class="text-dark fs-8 fw-semibold">{{ $data->cus_email_id ?? 'Not provided' }}</label>
                </div>
            </div>
            <div class="col-lg-4 d-flex align-items-center justify-content-start gap-2">
                <span class="bg-gray-200 rounded-circle p-2">
                    <i class="mdi mdi-web fs-4"></i>
                </span>
                <div class="d-flex flex-column">
                    @if(is_array($data->domain_names) && count($data->domain_names) > 0)
                        @foreach($data->domain_names as $domain)
                            <label class="text-black fs-6 fw-semibold">{{ $domain }}</label>
                        @endforeach
                    @else
                        <label class="text-black fs-6 fw-semibold">No domains selected</label>
                    @endif
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-lg-4 mb-2">
                <label class="text-black mb-1 fs-6 fw-semibold">Milestone<span class="text-danger">*</span></label>
                <select class="select3 form-select" id="milestone_id">
                    <option value="">Select Milestone</option>
                </select>
                <div id="milestone_id_err" class="text-danger mt-1 small"></div>
            </div>
            <div class="col-lg-4 mb-2">
                <label class="text-black mb-1 fs-6 fw-semibold">Service<span class="text-danger">*</span></label>
                <select class="select3 form-select" multiple id="milestone_service_id" data-placeholder="Select Service">
                </select>
                <div id="milestone_service_id_err" class="text-danger mt-1 small"></div>
            </div>
            <div class="col-lg-4 mb-2">
                <div class="d-flex align-items-center justify-content-around gap-2 bg-gray-100 p-3 rounded">
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <span class="badge bg-white rounded-circle px-3 py-3"><i class="mdi mdi-checkbox-multiple-marked-circle-outline text-black fs-3"></i></span>
                        <div class="d-flex flex-column align-items-center">
                            <span class="fw-semibold text-dark fs-7">Total Task</span>
                            <span class="fw-semibold text-black fs-4" id="total_tasks">0</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center justify-content-center gap-2">
                        <span class="badge bg-white rounded-circle px-3 py-3"><i class="mdi mdi-file-document-outline text-black fs-3"></i></span>
                        <div class="d-flex flex-column align-items-center">
                            <span class="fw-semibold text-dark fs-7">Total Pages</span>
                            <span class="fw-semibold text-black fs-4" id="total_pages">0</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-lg-12 my-4 d-flex flex-column">
                <div class="d-flex align-items-center justify-content-start gap-2">
                    <span><i class="mdi mdi-clipboard-check text-dark fs-3"></i></span>
                    <label class="fw-semibold text-black fs-5">Service & Task Mapping</label>
                </div>
                <span class="text-dark fw-semibold fs-7">
                    Select services to add tasks
                </span>
            </div>
            <div id="milestone_mapping_add_container" class="row"></div>
        </div>
        <div class="d-flex justify-content-end align-items-center mb-4">
            <div class="d-flex gap-2">
                <a href="{{ url('/manage_service') }}" class="btn btn-secondary">Cancel</a>
                <button type="button" class="btn btn-primary" id="assign_pc_button" onclick="milestoneAddValidation()">
                    Map Milestone
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Hidden Inputs -->
<input type="hidden" id="milestone_hide_cus_id" value="{{ $data->cus_sno }}">
<input type="hidden" id="milestone_hide_proposal_id" value="{{ $id }}">


<script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Custom Toastr Styling */
        .toast {
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }

        .toast-success {
            background-color: #28c76f;
        }

        .toast-error {
            background-color: #ea5455;
        }

        .toast-info {
            background-color: #00cfe8;
        }

        .toast-warning {
            background-color: #ff9f43;
        }
    </style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

<script>
        let selectedServices = []; // Array to store selected service IDs
        let serviceData = {}; // Object to store data for each service

        function resetMilestoneItems() {
            try {
                // Reset service dropdown
                $('#milestone_service_id').val('').trigger('change');
                selectedServices = [];
                serviceData = {};

                // Clear task containers
                $('#milestone_mapping_add_container').empty();

                // Show empty state
                $('#empty_state').show();
                $('#progress_summary').hide();

                $('.form-select, .form-control').removeClass('is-invalid');

                // Update messages
                $('#task_count_message').text('Select services to start mapping tasks');

            } catch (error) {
                console.error('Error resetting milestone items:', error);
            }
        }

        $(document).ready(function() {
            fetchMilestone();
            $('#task_count_message').text('Select services to start mapping tasks');

            // Handle service selection change
            $('#milestone_service_id').on('change', function() {
                const selectedServiceIds = $(this).val() || [];

                // Remove services that are no longer selected
                const servicesToRemove = selectedServices.filter(serviceId =>
                    !selectedServiceIds.includes(serviceId)
                );

                servicesToRemove.forEach(serviceId => {
                    removeServiceContainer(serviceId, false);
                });

                // Add new services
                selectedServiceIds.forEach(serviceId => {
                    if (!selectedServices.includes(serviceId)) {
                        selectedServices.push(serviceId);
                        createServiceContainer(serviceId);
                    }
                });

                updateServiceButtons();
                updateProgressSummary();
            });

            $('#milestone_id').on('change', function() {
                fetchMilestoneServices();
                $('#milestone_service_id').val('').trigger('change');
                resetMilestoneItems();
            });
        });

        function fetchMilestone() {
            $('#pc_assign_loader').show();
            const id = $('#milestone_hide_proposal_id').val();

            $.ajax({
                url: `/get_milestone_data/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const milestoneContainer = $('#milestone_id');
                        milestoneContainer.empty().append(`<option value="">Select Milestone</option>`);

                        response.data.forEach(mile => {
                            milestoneContainer.append(
                                `<option value="${mile.sno}" data-expected="${mile.expected_percentage}">
                                    ${mile.payment_slot_name}
                                </option>`);
                        });

                        // Store totals globally
                        window.totalServices = response.total_services;
                        window.totalMilestones = response.total_milestones;
                        window.expectedPerMilestone = response.expected_per_milestone;
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load milestones');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load milestones');
                },
                complete: function() {
                    $('#pc_assign_loader').hide();
                }
            });
        }

        function fetchMilestoneServices() {
            const milestoneId = $('#milestone_id').val();
            if (!milestoneId) return;

            const proposalId = $('#milestone_hide_proposal_id').val();

            $.ajax({
                url: `/get_milestone_service_data/${proposalId}`,
                type: 'GET',
                data: {
                    milestone_id: milestoneId
                },
                success: function(response) {
                    if (response.status === 200) {
                        const serviceContainer = $('#milestone_service_id');
                        serviceContainer.empty();

                        // Store service options for later reference
                        window.serviceOptions = {};

                        response.data.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.product_name} - ${service.service_id}</option>`
                            );
                            window.serviceOptions[service.sno] = service.product_name + ' - ' + service.service_id;
                        });

                        // Reinitialize select2
                        // serviceContainer.select2({
                        //     placeholder: 'Select Services',
                        //     allowClear: true,
                        //     closeOnSelect: false
                        // });

                        $('#task_count_message').text('Select services to add tasks');
                    } else {
                        console.error('AJAX Error');
                        toastr.error('Failed to load services');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                    toastr.error('Failed to load services');
                }
            });
        }

        function createServiceContainer(serviceId) {
            // Get service name from stored options
            const serviceName = window.serviceOptions && window.serviceOptions[serviceId]
                ? window.serviceOptions[serviceId]
                : `Service ${serviceId}`;

            const serviceContainerId = `service_${serviceId}_container`;

            const containerHtml = `
                <div class="col-lg-6 mb-2" id="${serviceContainerId}" data-service-id="${serviceId}">
                    <div class="row" >
                        <div class="service-task-container col-lg-12 mb-4" id="service_${serviceId}_container">
                            <div class="card border">
                                <div class="card-header bg-light">
                                    <div class="d-flex justify-content-between align-items-center gap-5">
                                        <h6 class="mb-0">${serviceName}</h6>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="removeServiceContainer(${serviceId})">
                                            <i class="mdi mdi-close text-white fw-bold"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="service-tasks-container" id="tasks_${serviceId}">
                                        <!-- Tasks will be added here -->
                                    </div>
                                    <div class="mt-3">
                                        <button type="button" class="btn btn-sm btn-primary" onclick="addTaskToService(${serviceId})" id="add_task_btn_${serviceId}"><i class="mdi mdi-plus-circle-outline me-1"></i> Add Task</button>
                                        <span class="text-muted ms-2" id="task_count_display_${serviceId}">0 tasks added</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;

            $('#milestone_mapping_add_container').append(containerHtml);

            // Initialize service data
            serviceData[serviceId] = {
                maxTasks: 0,
                tasks: [],
                taskContainers: {},
                availableTasks: []
            };

            // Fetch tasks for this service
            fetchTasksForService(serviceId);
        }

        function removeServiceContainer(serviceId, updateDropdown = true) {
            console.log('Removing container for service:', serviceId);

            $(`#service_${serviceId}_container`).remove();

            // Remove from selected services array
            const index = selectedServices.indexOf(serviceId.toString());
            if (index > -1) {
                selectedServices.splice(index, 1);
            }

            // Update dropdown if needed
            if (updateDropdown) {
                $('#milestone_service_id').val(selectedServices).trigger('change');
            }

            // Remove service data
            delete serviceData[serviceId];

            updateServiceButtons();
            updateProgressSummary();
        }

        function fetchTasksForService(serviceId) {

            $.ajax({
                url: `/get_milestone_product/${serviceId}`,
                type: 'GET',
                success: function(response) {
                    console.log('Tasks response for service', serviceId, ':', response);

                    if (response.status === 200) {
                        if (serviceData[serviceId]) {
                            serviceData[serviceId].maxTasks = response.task_count;
                            serviceData[serviceId].availableTasks = response.data;
                            serviceData[serviceId].productInfo = response.service_info;

                            console.log(`Service ${serviceId}: ${response.task_count} tasks available`);
                        }

                        updateServiceButtons();
                    } else {
                        toastr.error('Failed to load tasks for service');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                    toastr.error('Failed to load tasks for service');
                }
            });
        }

        function addTaskToService(serviceId) {
            if (!serviceData[serviceId]) {
                toastr.error('Service data not loaded');
                return;
            }

            const taskCount = serviceData[serviceId].tasks.length || 0;
            const maxTasks = serviceData[serviceId].maxTasks || 0;

            if (taskCount >= maxTasks) {
                toastr.error(`Maximum ${maxTasks} tasks allowed for this service`);
                return;
            }

            const taskIndex = taskCount;
            const taskElementId = `task_${serviceId}_${Date.now()}_${taskIndex}`;

            const taskHtml = `
                <div class="task-item card border mb-2" id="${taskElementId}">
                    <div class="card-body">
                        <div class="row g-3">
                            <div class="col-lg-9">
                                <div class="form-group">
                                    <label class="form-label">Task<span class="text-danger">*</span></label>
                                    <select class="select3 form-select task-select" id="task_select_${taskElementId}" onchange="onTaskChange(this, '${serviceId}', '${taskElementId}')">
                                        <option value="">Select Task</option>
                                    </select>
                                    <div class="text-danger mt-1 small task_err_${taskElementId}"></div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="form-group">
                                    <label class="form-label">Action</label>
                                    <button type="button" class="btn btn-sm btn-outline-danger w-100" onclick="removeTask('${serviceId}', '${taskElementId}')">
                                        <i class="mdi mdi-delete"></i> Remove
                                    </button>
                                </div>
                            </div>
                            <div class="col-12" id="task_category_${taskElementId}"></div>
                        </div>
                    </div>
                </div>
            `;

            $(`#tasks_${serviceId}`).append(taskHtml);
            const select2 = $('.select3');
            if (select2.length) {
                select2.each(function() {
                    var $this = $(this);
                    // select2Focus($this);
                    $this.wrap('<div class="position-relative"></div>').select2({
                        // placeholder: 'Select value',
                        dropdownParent: $this.parent()
                    });
                });
            }


            // Initialize task data
            serviceData[serviceId].taskContainers[taskElementId] = {
                taskId: '',
                pages: 0
            };

            serviceData[serviceId].tasks.push(taskElementId);

            // Populate task dropdown
            populateTaskDropdown(serviceId, taskElementId);
            updateServiceButtons();
            updateTaskCountDisplay(serviceId);
            updateProgressSummary();
        }

        function updateTaskCountDisplay(serviceId) {
            const taskCount = serviceData[serviceId] ? serviceData[serviceId].tasks.length : 0;
            $(`#task_count_display_${serviceId}`).text(`${taskCount} tasks added`);
        }

        function populateTaskDropdown(serviceId, taskElementId) {
            if (!serviceData[serviceId] || !serviceData[serviceId].availableTasks) {
                console.log('No available tasks for service', serviceId);
                return;
            }

            const selectElement = $(`#task_select_${taskElementId}`);
            selectElement.empty().append(`<option value="">Select Task</option>`);

            // Get already selected task IDs for this service
            const selectedTaskIds = [];
            if (serviceData[serviceId].taskContainers) {
                Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                    if (containerId !== taskElementId && serviceData[serviceId].taskContainers[containerId].taskId) {
                        selectedTaskIds.push(serviceData[serviceId].taskContainers[containerId].taskId);
                    }
                });
            }

            console.log(`Service ${serviceId} - Selected task IDs:`, selectedTaskIds);
            console.log(`Service ${serviceId} - Available tasks:`, serviceData[serviceId].availableTasks.length);

            // Add available tasks
            serviceData[serviceId].availableTasks.forEach(task => {
                if (!selectedTaskIds.includes(task.sno.toString())) {
                    selectElement.append(
                        `<option value="${task.sno}">${task.task_name}</option>`
                    );
                }
            });
        }

        function onTaskChange(selectElement, serviceId, taskElementId) {
            const taskId = selectElement.value;

            console.log(`Task changed for service ${serviceId}:`, taskId);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].taskId = taskId;

                // Fetch task category if needed
                if (taskId) {
                    getTaskCategory(taskId, serviceId, taskElementId);
                }
            }

            // Update all task dropdowns for this service
            updateAllTaskDropdowns(serviceId);
            updateServiceButtons();
            updateProgressSummary();
        }

        function getTaskCategory(taskId, serviceId, taskElementId) {
            console.log(`Fetching category for task ${taskId} in service ${serviceId}`);

            $.ajax({
                url: `/get_task_category/${taskId}`,
                type: 'GET',
                success: function(response) {
                    console.log('Task category response:', response);

                    if (response.status === 200) {
                        const categoryContainer = $(`#task_category_${taskElementId}`);
                        categoryContainer.empty();

                        let html = '';

                        if (response.data.category_check == 0) {
                            html = `
                                <div class="form-group">
                                    <label class="form-label">
                                        Pages <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <input type="text" class="form-control product-pages"
                                            placeholder="Enter number of pages"
                                            id="product_pages_${taskElementId}"
                                            oninput="allowOnlyNumbers(this); updateTaskPages('${serviceId}', '${taskElementId}')"/>
                                    </div>
                                    <div class="text-danger mt-1 small pages_err_${taskElementId}"></div>
                                </div>
                        `;
                        } else if (response.data.category_check == 1) {
                            html = ` `;
                        } else {
                            html = `
                            <div class="col-12 mt-3">
                                <div class="alert alert-info">
                                    <i class="mdi mdi-information me-1"></i>
                                    This task doesn't require additional input.
                                </div>
                            </div>
                        `;
                        }
                        categoryContainer.html(html);

                        // Update task data with category type
                        if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                            serviceData[serviceId].taskContainers[taskElementId].category = response.data.category_check;
                        }
                    } else {
                        console.error('Failed to get task category:', response);
                    }
                },
                error: function(err) {
                    console.error('AJAX Error fetching task category:', err);
                    toastr.error('Failed to load task category information');
                }
            });
        }

        function updateTaskPercentage(serviceId, taskElementId) {
            const percentageInput = $(`#product_percentage_${taskElementId}`);
            if (!percentageInput.length) return;

            let percentageValue = parseInt(percentageInput.val()) || 0;

            // Ensure value is between 0 and 100
            if (percentageValue < 0) percentageValue = 0;
            if (percentageValue > 100) percentageValue = 100;

            percentageInput.val(percentageValue);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].percentage = percentageValue;
            }

            updateProgressSummary();
        }

        function allowOnlyNumbers(el) {
            el.value = el.value
                .replace(/\D/g, '')      // only numbers
                .replace(/^0+/, '');     // remove leading zeros
        }

        function updateTaskPages(serviceId, taskElementId) {
            let pagesInput = $(`#pages_${taskElementId}`);

            if (!pagesInput.length) {
                pagesInput = $(`#product_pages_${taskElementId}`);
            }

            if (!pagesInput.length) return;

            let pagesValue = parseInt(pagesInput.val()) || 0;

            // Ensure value is not negative
            if (pagesValue < 0) pagesValue = 0;

            pagesInput.val(pagesValue);

            // Update task data
            if (serviceData[serviceId] && serviceData[serviceId].taskContainers[taskElementId]) {
                serviceData[serviceId].taskContainers[taskElementId].pages = pagesValue;
            }

            updateProgressSummary();
        }

        function removeTask(serviceId, taskElementId) {
            $(`#${taskElementId}`).remove();

            // Remove from service data
            if (serviceData[serviceId]) {
                const taskIndex = serviceData[serviceId].tasks.indexOf(taskElementId);
                if (taskIndex > -1) {
                    serviceData[serviceId].tasks.splice(taskIndex, 1);
                }
                if (serviceData[serviceId].taskContainers) {
                    delete serviceData[serviceId].taskContainers[taskElementId];
                }
            }

            updateAllTaskDropdowns(serviceId);
            updateServiceButtons();
            updateTaskCountDisplay(serviceId);
            updateProgressSummary();
        }

        function updateAllTaskDropdowns(serviceId) {
            if (!serviceData[serviceId] || !serviceData[serviceId].taskContainers) return;

            // Get selected task IDs for this service
            const selectedTaskIds = [];
            Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                if (serviceData[serviceId].taskContainers[containerId].taskId) {
                    selectedTaskIds.push(serviceData[serviceId].taskContainers[containerId].taskId);
                }
            });

            console.log(`Updating dropdowns for service ${serviceId}, selected tasks:`, selectedTaskIds);

            // Update all dropdowns for this service
            $(`#tasks_${serviceId} .task-select`).each(function() {
                const currentValue = $(this).val();

                $(this).find('option').each(function() {
                    const optionValue = $(this).val();
                    if (optionValue && optionValue !== '') {
                        if (selectedTaskIds.includes(optionValue) && optionValue !== currentValue) {
                            $(this).prop('disabled', true);
                        } else {
                            $(this).prop('disabled', false);
                        }
                    }
                });
            });
        }

        function updateServiceButtons() {
            // Enable/disable add task buttons based on available tasks
            selectedServices.forEach(serviceId => {
                const addButton = $(`#add_task_btn_${serviceId}`);
                if (serviceData[serviceId]) {
                    const taskCount = serviceData[serviceId].tasks.length || 0;
                    const maxTasks = serviceData[serviceId].maxTasks || 0;

                    if (taskCount >= maxTasks) {
                        addButton.prop('disabled', true)
                            .html('<i class="mdi mdi-check-all me-1"></i> Max Tasks Added');
                    } else {
                        addButton.prop('disabled', false)
                            .html('<i class="mdi mdi-plus-circle-outline me-1"></i> Add Task');
                    }
                }
            });
        }

        function updateProgressSummary() {
            let totalTasks = 0;
            let totalPages = 0;
            let totalPercentage = 0;

            // Calculate totals across all services
            Object.keys(serviceData).forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].tasks) {
                    totalTasks += serviceData[serviceId].tasks.length || 0;
                    // Calculate pages and percentages from task containers
                    if (serviceData[serviceId].taskContainers) {
                        Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                            const task = serviceData[serviceId].taskContainers[containerId];
                            totalPages += task.pages || 0;
                            totalPercentage += task.percentage || 0;
                        });
                    }
                }
            });

            $('#total_tasks').text(totalTasks);
            $('#total_pages').text(totalPages);
            $('#total_percentage').text(totalPercentage + '%');

            if (totalTasks > 0) {
                $('#progress_summary').show();
                $('#empty_state').hide();
            } else {
                $('#progress_summary').hide();
                $('#empty_state').show();
            }
        }

        function milestoneAddValidation() {
            let isValid = true;
            const button = $('#assign_pc_button');

            // Clear previous errors
            $('.form-select, .form-control').removeClass('is-invalid');

            const milestoneId = $('#milestone_id').val();

            // Validate milestone selection
            if (!milestoneId) {
                $('#milestone_id_err').text('Milestone is required.');
                isValid = false;
            }

            // Validate at least one service is selected
            if (selectedServices.length == 0) {
                $('#milestone_service_id_err').text('Service is required.');
                isValid = false;
            }

            let totalTaskCount = 0;
            let hasValidationErrors = false;

            selectedServices.forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].taskContainers) {
                    const taskContainers = Object.keys(serviceData[serviceId].taskContainers);
                    totalTaskCount += taskContainers.length;

                    taskContainers.forEach(containerId => {
                        const task = serviceData[serviceId].taskContainers[containerId];

                        // Validate task selection
                        if (!task.taskId) {
                            $(`#task_select_${containerId}`).addClass('is-invalid');
                            $(`.task_err_${containerId}`).text('Please select a task');
                            isValid = false;
                            hasValidationErrors = true;
                        } else {
                            const category = task.category || 0;

                            if (category == 0) {
                                // Page-based task validation
                                const pagesInput = $(`#product_pages_${containerId}`);

                                if (pagesInput.length && pagesInput.is(':visible')) {
                                    const pagesVal = pagesInput.val().trim();
                                    if (pagesVal === '' || isNaN(pagesVal) || parseInt(pagesVal) <= 0) {
                                        $(`.pages_err_${containerId}`).text('Pages must be greater than 0');
                                        isValid = false;
                                        hasValidationErrors = true;
                                        pagesInput.addClass('is-invalid');
                                    }
                                }
                            }
                        }
                    });
                }
            });

            // Check if any service has tasks
            // if (selectedServices.length > 0 && totalTaskCount === 0 && !hasValidationErrors) {
            //     toastr.error('Please add at least one task to the selected services');
            //     isValid = false;
            // }    

            if (!isValid) {
                if (!hasValidationErrors && totalTaskCount === 0 && selectedServices.length > 0) {
                    // Show specific message for no tasks when services are selected
                    toastr.error('Please add at least one task to the selected services');
                } else {
                    toastr.error('Please fix all validation errors before submitting');
                }
                return false;
            }

            // Prepare data for submission
            const finalData = {
                customer_id: $('#milestone_hide_cus_id').val(),
                proposal_id: $('#milestone_hide_proposal_id').val(),
                milestone_id: milestoneId,
                services: []
            };

            // Build services array
            selectedServices.forEach(serviceId => {
                if (serviceData[serviceId] && serviceData[serviceId].tasks.length > 0) {
                    const serviceObj = {
                        service_id: serviceId,
                        tasks: [],
                        pages: [],
                        percentages: []
                    };

                    Object.keys(serviceData[serviceId].taskContainers).forEach(containerId => {
                        const task = serviceData[serviceId].taskContainers[containerId];
                        if (task.taskId) {
                            serviceObj.tasks.push(task.taskId);
                            serviceObj.pages.push(task.pages || 0);
                            serviceObj.percentages.push(100); // Default percentage
                        }
                    });

                    if (serviceObj.tasks.length > 0) {
                        finalData.services.push(serviceObj);
                    }
                }
            });

            console.log('Submitting data:', finalData);
            submitMultipleServicesMilestone(finalData, button);
            return true;
        }

        function submitMultipleServicesMilestone(data, button) {
            const originalText = button.html();
            button.prop('disabled', true).html('<i class="mdi mdi-loading mdi-spin me-1"></i> Processing...');

            $.ajax({
                url: `/add_multiple_milestone_mapping`,
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    console.log('Submission response:', response);

                    switch (response.status) {
                        case 200:
                            toastr.success(response.message);
                            $('#assign_pc_button').html(
                                '<i class="mdi mdi-check-circle-outline me-1"></i> Success!');
                            $('#assign_pc_button').addClass('btn-success');

                            setTimeout(() => {
                                window.location.href = "/manage_service";
                            }, 1500);
                            break;

                        case 422:
                            toastr.error(response.error_msg || 'Validation failed');
                            break;

                        default:
                            toastr.error(response.message || 'Unknown error occurred');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error Details:', xhr);
                    let errorMessage = 'An error occurred while saving milestone.';
                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON?.errors;
                        errorMessage = errors ? Object.values(errors).flat().join('<br>') :
                        'Validation failed.';
                    } else if (xhr.status === 500) {
                        errorMessage = 'Server error. Please contact support.';
                    }
                    toastr.error(errorMessage);
                },
                complete: function() {
                    setTimeout(() => {
                        button.prop('disabled', false).html(originalText);
                        $('#assign_pc_button').removeClass('btn-success');
                    }, 2000);
                }
            });
        }
    </script>
@endsection
