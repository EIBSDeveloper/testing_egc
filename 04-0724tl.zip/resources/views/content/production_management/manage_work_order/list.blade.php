@extends('layouts/layoutMaster')

@section('title', 'Manage Service')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/js/dropdown-hover.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/clipboard/clipboard.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
    <style>
        .act_bx:hover {
            background-color: #eae1fc;

        }

        .act_bx_selected {
            background-color: #fbecdb !important;
            border: 1px solid #766e6e70 !important;
        }
    </style>
    @php
        $helper = new \App\Helpers\Helpers();
        $module_name = 'Service Management';
        $menu_name = 'Manage Services';
    @endphp
    <!-- Services List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1">
            <div class="card-action-title">
                <h5 class="card-title mb-1">Manage Services</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-1">
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                    class="mdi mdi-home-outline text-body fs-4"></i></a>
                        </li>
                        <span class="text-dark opacity-75 me-1 ms-1">
                            <i class="mdi mdi-arrow-right-thin fs-4"></i>
                        </span>
                        <li class="breadcrumb-item">
                            <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div class="card-action-element">
                <div class="d-flex justify-content-end align-items-center flex-wrap">
                    {{-- <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter" title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                </a> --}}
                </div>
            </div>
        </div>
        <div class="card-body">

            <div class="filter_tbox" style="display: none;">
                <div class="row py-1">
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Writing Products</option>
                            <option value="2">Developement Products</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Thesis Writing</option>
                            <option value="2">Technical Research and Development Services</option>
                            <option value="3">Formatting and Referencing</option>
                        </select>
                    </div>
                    <div class="col-lg-3 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                        <select class="select3 form-select">
                            <option value="" selected>All</option>
                            <option value="1">Call Awaiting</option>
                            <option value="2">Verified Work Order</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                    <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                    <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
                </div>
            </div>
            <div class="col-lg-12 mb-3">
                <div class="d-flex align-items-center gap-2">
                    <div class="card border rounded d-flex align-items-start p-2 bg-success"
                        style="height:73px; width:200px; box-shadow:none; ">
                        <div class="d-flex  align-items-center justify-content-between " style="width: 100%;">
                            <label class="text-white fs-3 fw-semibold" id="total_proposal">0</label>
                            <span class="mdi mdi-list-box text-white fs-3 pe-2"></span>
                        </div>
                        <label class="text-white fs-7 fw-semibold">Proposal</label>
                    </div>
                    <div class="card border rounded d-flex align-items-start p-2 bg-warning"
                        style="height:73px; width:200px; box-shadow:none;">
                        <div class="d-flex  align-items-center justify-content-between " style="width: 100%;">
                            <label class="text-black fs-3 fw-semibold" id="total_awaiting">0</label>
                            <span class="mdi mdi-phone-alert text-dark fs-3 pe-2"></span>
                        </div>
                        <label class="text-black fs-7 fw-semibold">Call Awaiting</label>
                    </div>
                    <div class="card border rounded d-flex align-items-start p-2 bg-danger"
                        style="height:73px; width:200px; box-shadow:none;">
                        <div class="d-flex  align-items-center justify-content-between " style="width: 100%;">
                            <label class="text-white fs-3 fw-semibold" id="total_schedule_date">0</label>
                            <span class="mdi mdi-calendar-alert text-white fs-3 pe-2"></span>
                        </div>
                        <label class="text-white fs-7 fw-semibold">Schedule dates</label>
                    </div>
                    <div class="card border rounded d-flex align-items-start p-2 "
                        style="height:73px; width:200px; box-shadow:none; background:#e3f3cb;">
                        <div class="d-flex  align-items-center justify-content-between " style="width: 100%;">
                            <label class="text-black fs-3 fw-semibold" id="total_work_order">0</label>
                            <span class=" mdi mdi-check-decagram text-dark fs-3 pe-2"></span>
                        </div>
                        <label class="text-black fs-7 fw-semibold">Verified Work Order</label>
                    </div>
                    <div class="card border rounded d-flex align-items-start p-2 bg-primary"
                        style="height:73px; width:200px; box-shadow:none; ">
                        <div class="d-flex  align-items-center justify-content-between " style="width: 100%;">
                            <label class="text-white fs-3 fw-semibold" id="total_permanent">0</label>
                            <span class="mdi mdi-progress-close text-white fs-3 pe-2"></span>
                        </div>
                        <label class="text-white fs-7 fw-semibold">Permanent Close</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="row mb-4">
                    <div class="col-lg-2">
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                        </select>
                    </div>
                    <div class="col-lg-10 d-flex align-items-end justify-content-end">
                        <div id="search_form">
                            <div class="d-flex align-items-center gap-2 mt-2">
                                <div>
                                    <input type="text" class="form-control" id="search_fill" name="search_fill"
                                        placeholder="Enter Search" />
                                </div>
                                <button type="button" class="btn btn-sm btn-primary fw-semibold fs-6"
                                    onclick="handleSearch()">Search</button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1">
                        <thead>
                            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Proposals</th>
                                <th class="min-w-150px">Customers</th>
                                <th class="min-w-100px">Product / Package</th>
                                <th class="min-w-100px">Proposal Link</th>
                                <th class="min-w-100px">Status</th>
                                <th class="min-w-80px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-gray-600 fw-semibold fs-7" id="service_table_tbody">
                            <tr id="skeleton-loader">
                                <td colspan="6" class="text-center">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div id="pagination_container" class="d-flex justify-content-between align-items-center mt-3"></div>
            </div>
        </div>
    </div>

    <!--begin::Modal - Select Date View -->
    <div class="modal fade" id="kt_modal_select_date" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <label class="mb-2">Assign Dates</label><br>
                        </h3>
                    </div>
                    <div id="loaderOverlay"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
                        <div class="spinner-border text-primary fs-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="assign_dates_button"
                            onclick="assignDateValidation()">Assign Dates</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Select Date View-->

    <!--begin::Modal - First Call Confirmation-->
    <div class="modal fade" id="kt_modal_first_call_confirmation" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">First Call Confirmation Checklist</h3>
                    </div>
                    <div id="first_call_loader"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
                        <div class="spinner-border text-primary fs-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <input type="hidden" id="proposal_id">
                    <div class="row mb-4">
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="first_call_cus_name">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-info fs-6 fw-bold" id="first_call_customer_id">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"id="first_call_mobile_num">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-6">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold text-truncate" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="" id="first_call_cus_mail">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="text-black fs-5 fw-semibold">Billable Details</div>
                            <hr class="mt-1 mb-4">
                            <div class="row mb-4">
                                <div class="col-lg-12 mb-3">
                                    <div class="form-check form-check-inline mb-2">
                                        <input class="form-check-input" type="radio" id="service_based_billables"
                                            name="billable_det" value="0" checked>
                                        <label for="service_based_billables"
                                            class="form-check-label text-black fs-6">Service Based Billable</label>
                                    </div>
                                    <div class="form-check form-check-inline mt-2">
                                        <input class="form-check-input" type="radio" id="task_based_billables"
                                            name="billable_det" value="1">
                                        <label for="task_based_billables" class="form-check-label text-black fs-6">Task
                                            Based Billable</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="text-black fs-5 fw-semibold">Domains</div>
                            <hr class="mt-1 mb-2">
                            <div class="row mb-4">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark fs-6 fw-semibold" id="first_call_domains">IEE Domain, Scopus
                                        Q1</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="text-black fs-5 fw-semibold">Service Details</div>
                            <hr class="mt-1 mb-2">
                            <div class="row mb-4" id="first_call_product_list">

                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="text-black fs-4 fw-semibold">Checklist</div>
                            <hr class="mt-1 mb-4">
                            <div class="scroll-y max-h-250px px-3 py-1 mb-4" id="check_list_div">
                                <div class="row" id="first_call_checklist_container">
                                </div>
                            </div>
                            <div class="text-danger fs-7 mt-2 fw-semibold" id="check_list_err"></div>
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold">Update Schedule Date</label>
                            <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Pay Slot</th>
                                        <th class="min-w-150px">Payable Amount</th>
                                        <th class="min-w-100px">Select Date</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7" id="paySlotTableBody">
                                    {{-- AJAX will Populate Here --}}
                                </tbody>
                            </table>
                            <div id="date_err" class="text-danger text-end mt-2 fs-7 fw-semibold"></div>
                        </div>
                        <div class="col-lg-12">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control" rows="3" placeholder="Enter Description" id="order_desc"></textarea>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="confirm_call_button"
                            onclick="firstCallValidation()">Confirm Call</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - First Call Confirmation-->

    <!--begin::Modal - Work Order View -->
    <div class="modal fade" id="kt_modal_work_order_view" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20" id="view_modal_body">

                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Work Order View-->

    <!--begin::Modal - Work Order Permanent -->
    <div class="modal fade" id="kt_modal_permanent_close" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Permanent Close Confirmation</h3>
                    </div>
                    <div id="per_cls_loader"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
                        <div class="spinner-border text-primary fs-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <input type="hidden" id="per_cls_proposal_id">
                    <div class="row mb-4">
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="per_cls_cus_name">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-info fs-6 fw-bold" id="per_cls_customer_id">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold"id="per_cls_mobile_num">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="row mb-6">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold text-truncate" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="" id="per_cls_cus_mail">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mb-4">
                            <div class="text-black fs-5 fw-semibold">Service Details</div>
                            <hr class="mt-1 mb-2">
                            <div class="row mb-4" id="per_cls_product_list">

                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="text-black fs-5 fw-semibold">Domains</div>
                            <hr class="mt-1 mb-2">
                            <div class="row mb-4">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark fs-6 fw-semibold" id="per_cls_domains">IEE Domain, Scopus
                                        Q1</label>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6 mb-4">
                            <div class="text-black fs-4 fw-semibold">Checklist</div>
                            <hr class="mt-1 mb-4">
                            <div class="scroll-y max-h-250px px-3 py-1 mb-4" id="check_list_div">
                                <div class="row" id="per_cls_checklist_container">
                                </div>
                            </div>
                            <div class="text-danger fs-7 mt-2 fw-semibold" id="percls_check_list_err"></div>
                        </div>
                        <div class="col-lg-6">
                            <label class="text-black mb-1 fs-6 fw-semibold">Remark <span
                                    class="text-danger">*</span></label>
                            <textarea class="form-control mt-1" rows="3" placeholder="Enter Remark" id="remark"></textarea>
                            <div class="text-danger fs-7 mt-2 fw-semibold" id="percls_remark_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="per_cls_button"
                            onclick="PerClsValidation()">Permanent Close</a>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Work Order Permanent Close-->


    <!--begin::Modal - Assign Staff View -->
    <div class="modal fade" id="kt_modal_assign_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">
                            <label class="mb-2">Appoint Project Coordinator</label><br>
                        </h3>
                    </div>
                    <div id="pc_assign_loader"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
                        <div class="spinner-border text-primary fs-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <!-- Customer Details -->
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="assign_pc_cus_name">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-info fs-6 fw-bold" id="assign_pc_customer_id">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="assign_pc_mobile_num">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="row mb-6">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold" id="assign_pc_cus_email">-</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="text-black fs-5 fw-semibold">Domains</div>
                            <hr class="mt-1 mb-2">
                            <div class="text-dark text-start mb-4" id="allocate_pc_domains">
                            </div>
                        </div>
                        <!-- Service Details -->
                        <div class="col-lg-6">
                            <div class="text-black fs-5 fw-semibold">Service Details</div>
                            <hr class="mt-1 mb-2">
                            <div class="row mb-4 scroll-y max-h-150px" id="product-list_staff">
                                <!-- Services will be populated here dynamically -->
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mb-6">
                            <input type="hidden" id="assign_id">
                            <input type="hidden" id="service_length">
                            <label class="text-black mb-1 fs-6 fw-semibold">Project Coordinator<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="assign_pc">
                                <option value="">Select Project Coordinator</option>
                            </select>
                            <div id="pc_add_err" class="text-danger fs-7 fw-semibold mt-1"></div>
                            <!-- Fixed duplicate ID -->
                        </div>
                        <div class="col-lg-6">
                            <input class="form-check-input w-25px h-25px me-2" type="checkbox" id="journal_check"
                                value="1" onclick="journalServiceToggle(this.checked)"
                                style="margin-top: 2rem !important;">
                            <label for="journal_check" class="text-dark fs-5 fw-bold cursor-pointer"
                                style="margin-top: 2rem !important;">Journal Publication</label>
                        </div>
                        <div class="d-none journal_service_container">
                            <div class="row">
                                <div class="col-lg-5 mb-6">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select pc_service_id" id="pc_service_id_0">
                                    </select>
                                    <div class="text-danger fs-7 fw-semibold mt-1 pc_service_id_err"></div>
                                </div>
                                <div class="col-lg-5 mb-6">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Journal Index<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select pc_journal_index_id" id="pc_journal_index_0"
                                        data-placeholder="Select Journal Index" multiple>
                                    </select>
                                    <div class="text-danger fs-7 fw-semibold mt-1 pc_journal_index_err"></div>
                                </div>
                                <div class="col-lg-2 mb-1 d-none">
                                    <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1">
                                        <i class="mdi mdi-delete fs-4"></i>
                                    </a>
                                </div>
                            </div>
                            <div id="staff_add_more_container"></div>
                            <div class="mb-4 mt-1 d-flex  justify-content-end ">
                                <button type="button" class="btn btn-sm btn-primary fs-8 px-2 py-1"
                                    onclick="validateJournalAddMore()" id="journal_service_add">
                                    <i class="mdi mdi-plus me-1"></i> Add More
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-6">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="assign_pc_button" onclick="assignStaffValidation()"
                            class="btn btn-primary">Appoint Project Coordinator</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Assign Staff View-->

    <!--begin::Modal - Milestone Mapping-->
    <div class="modal fade" id="kt_modal_milestone_mapping" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div class="modal-header justify-content-end border-0 pb-0">
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Milestone Mapping</h3>
                    </div>
                    <div id="loaderOverlay_select_date"
                        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
                        <div class="spinner-border text-primary fs-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                    </div>
                    <div class="row">
                        <div id="select2-milestone-container"></div>
                        <div class="col-lg-12 mb-1">
                            <input type="hidden" id="milestone_hide_cus_id">
                            <input type="hidden" id="milestone_hide_proposal_id">
                            <div class="row mb-3">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-semibold break-all"
                                    id="milestone_cus_name">-</label>
                            </div>
                            <div class="row mb-3">
                                <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-info fs-6 fw-semibold break-all"
                                    id="milestone_customer_id">-</label>
                            </div>

                        </div>
                        <div class="col-lg-12 mb-1">
                            <div class="row mb-3" id="milestone_mobile_container">
                                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-semibold" id="milestone_customer_mobile">-</label>
                            </div>
                            <div class="row mb-3" id="milestone_mail_container">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-semibold" id="milestone_customer_mail">-</label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Milestone<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="milestone_id" onchange="fetchMilestoneServices()">
                                <option value="">Select Milestone</option>
                            </select>
                            <div id="milestone_id_err" class="text-danger mt-1 fs-7 fw-semibold"></div>
                        </div>
                        <input type="hidden" id="milestone-hidden-service-id">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Service<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="milestone_service_id"
                                onchange="fetchMileStoneTasks(this.value, 0)">
                                <option value="">Select Service</option>
                            </select>
                            <div id="milestone_service_id_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                        </div>
                        <input type="hidden" id="product_category_id">
                        <div class="scroll-y max-h-250px px-3 py-1 mb-4">
                            <div class="milestone_mapping_container row">
                                <div class="col-lg-10 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Task<span
                                            class="text-danger">*</span></label>
                                    <select class="select3 form-select milestone-task" id="milestone_task_id_0"
                                        onchange="handleTaskSelection(this.value, 0)">
                                        <option value="">Select Task</option>
                                    </select>
                                    <div class="text-danger mt-2 fs-7 fw-semibold milestone_task_id_err"></div>
                                </div>
                                <div id="milestone_category_container_0"></div>
                            </div>
                            <div id="milestone_mapping_add_container"></div>
                        </div>
                        <div class="mb-4 mt-1 d-flex  justify-content-end ">
                            <button type="button" class="btn btn-sm btn-primary fs-8 px-2 py-1"
                                onclick="milestoneAddMore()" id="milestone_add_more_btn">
                                <i class="mdi mdi-plus me-1"></i> Add More
                            </button>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" onclick="milestoneAddValidation()" class="btn btn-primary me-3"
                            id="milestone_button">Milestone Mapping</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Milestone Mapping- -->

    {{-- * TOASTR STARTS --}}

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    {{-- * TOASTR ENDS --}}


    <style>
        .max-h-300px {
            max-height: 300px;
        }

        .timeline {
            position: relative;
        }

        .timeline .timeline-item {
            position: relative;
            padding-left: 9px;
        }

        .timeline-item {
            display: flex;
            align-items: flex-start;
            position: relative;
            margin-bottom: 1.5rem;
        }

        .timeline-item:last-child {
            margin-bottom: 0;
        }

        .timeline-line {
            position: absolute;
            left: 15px;
            top: 30px;
            bottom: -20px;
            width: 2px;
            background-color: #d7e7f4;
        }

        .timeline-item:last-child .timeline-line {
            display: none;
        }

        .timeline-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background-color: #f5f8fa;
            z-index: 1;
            flex-shrink: 0;
        }

        .timeline-content {
            margin-left: 1rem;
            flex-grow: 1;
        }

        .bullet {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }

        .bullet-dot {
            width: 12px;
            height: 12px;
        }

        .w-40px {
            width: 40px;
        }

        .h-40px {
            height: 40px;
        }
    </style>

    {{-- * FETCH SERVICE TABLE --}}
    <script>
        let currentPageWork = 1;
        let currentPerPage = 25;
        let currentSearch = '';

        document.addEventListener('DOMContentLoaded', function() {
            initializePerPageDropdown();
            fetchServiceTable();
            initializeSearchEvents();

            const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            const tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

        function initializePerPageDropdown() {
            const perPageSelect = $('#perpage');
            const options = [10, 25, 100, 500];

            perPageSelect.empty();

            options.forEach(option => {
                const isSelected = option === currentPerPage;
                perPageSelect.append(
                    `<option value="${option}" ${isSelected ? 'selected' : ''}>${option}</option>`);
            });

            perPageSelect.off('change').on('change', function() {
                currentPerPage = parseInt($(this).val());
                currentPageWork = 1;
                fetchServiceTable();
            });
        }

        function initializeSearchEvents() {
            $('#search_fill').on('keypress', function(e) {
                if (e.which === 13) {
                    e.preventDefault();
                    handleSearch();
                }
            });

            let searchTimeout;
            $('#search_fill').on('input', function() {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(function() {
                    handleSearch();
                }, 500);
            })
        }

        function handleSearch() {
            currentSearch = $('#search_fill').val().trim();
            currentPageWork = 1;
            fetchServiceTable();
        }

        function fetchServiceTable() {
            const requestData = {
                page: currentPageWork,
                per_page: currentPerPage,
                search: currentSearch
            };

            $.ajax({
                url: `/get_manage_service`,
                type: 'GET',
                data: requestData,
                dataType: 'json',
                beforeSend: function() {
                    $('#skeleton-loader').show();
                },
                success: function(response) {
                    if (response.status === 200) {
                        populateTable(response.data.data);
                        setupPagination(response.data);
                        $('#total_proposal').html(response.data.total);
                        $('#total_awaiting').html(response.data.total_awaiting);
                        $('#total_schedule_date').html(response.data.total_schedule_date);
                        $('#total_work_order').html(response.data.total_work_order);
                        $('#total_permanent').html(response.data.total_permanent);

                        $('#skeleton-loader').hide();

                        resetFirstCall();
                        resetAssignStaff();
                        resetDates();
                    } else {
                        $('#skeleton-loader').hide();
                        toastr.error(response.message || 'Failed to fetch data');
                    }
                },
                error: function(xhr, status, error) {
                    let errorMessage = 'An error occurred while fetching services.';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                    toastr.error(errorMessage);
                    $('#skeleton-loader').hide();
                }
            });
        }

        function changePage(page) {
            currentPageWork = page;
            fetchServiceTable();
        }

        function setupPagination(data) {
            const paginationContainer = $('#pagination_container');
            paginationContainer.empty();

            if (data.total <= data.per_page) {
                return;
            }

            const totalPages = data.last_page;
            const currentPage = data.current_page;

            let paginationHTML = `
                <div class="d-flex align-items-center justify-content-between w-100">
                    <div>
                        <span class="text-muted fs-7">
                            Showing ${data.from} to ${data.to} of ${data.total} entries
                        </span>
                    </div>
                    <div>
                        <nav aria-label="Page navigation">
                            <ul class="pagination pagination-sm mb-0">
            `;

            // Previous button
            if (currentPage > 1) {
                paginationHTML += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0);" onclick="changePage(${currentPage - 1})">Previous</a>
                    </li>
                `;
            } else {
                paginationHTML += `
                    <li class="page-item disabled">
                        <span class="page-link">Previous</span>
                    </li>
                `;
            }

            // Page numbers logic
            const maxVisiblePages = 5;
            let startPage = Math.max(1, currentPage - 2);
            let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

            // Adjust start page if we're near the end
            if (endPage - startPage + 1 < maxVisiblePages) {
                startPage = Math.max(1, endPage - maxVisiblePages + 1);
            }

            // First page with ellipsis if needed
            if (startPage > 1) {
                paginationHTML += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0);" onclick="changePage(1)">1</a>
                    </li>
                `;
                if (startPage > 2) {
                    paginationHTML += `
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    `;
                }
            }

            // Page numbers
            for (let i = startPage; i <= endPage; i++) {
                if (i === currentPage) {
                    paginationHTML += `
                        <li class="page-item active">
                            <span class="page-link">${i}</span>
                        </li>
                    `;
                } else {
                    paginationHTML += `
                        <li class="page-item">
                            <a class="page-link" href="javascript:void(0);" onclick="changePage(${i})">${i}</a>
                        </li>
                    `;
                }
            }

            // Last page with ellipsis if needed
            if (endPage < totalPages) {
                if (endPage < totalPages - 1) {
                    paginationHTML += `
                        <li class="page-item disabled">
                            <span class="page-link">...</span>
                        </li>
                    `;
                }
                paginationHTML += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0);" onclick="changePage(${totalPages})">${totalPages}</a>
                    </li>
                `;
            }

            // Next button
            if (currentPage < totalPages) {
                paginationHTML += `
                    <li class="page-item">
                        <a class="page-link" href="javascript:void(0);" onclick="changePage(${currentPage + 1})">Next</a>
                    </li>
                `;
            } else {
                paginationHTML += `
                    <li class="page-item disabled">
                        <span class="page-link">Next</span>
                    </li>
                `;
            }

            paginationHTML += `
                            </ul>
                        </nav>
                    </div>
                </div>
            `;

            paginationContainer.html(paginationHTML);
        }

        function populateTable(services) {
            const tbody = $('#service_table_tbody');
            tbody.empty();

            if (services.length === 0) {
                tbody.append(`
                <tr>
                    <td colspan="6" class="text-start py-4">
                        <div class="text-black">No Service found</div>
                    </td>
                </tr>
            `);
                return;
            }

            services.forEach(function(service) {
                const countryCode = service.country_code ? service.country_code : 91;
                const mobile = service.cus_mobile;
                const phoneNum = mobile ? `+( ${countryCode} ) ${mobile}` : '-';
                const productPackage = service.product_package;
                const products = service.product_list || [];
                const workOrderStatus = products[0]?.work_order_check;
                let productHTML = '';
                let productListHTML = '';
                let statusHTML = '';
                let actionHTML = '';

                if (productPackage === 1) {
                    productHTML = `
                        <div class="d-block">
                            <div class="text-info fw-semibold fs-6 mb-0 me-2 ms-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Product">Product</div>
                        </div>
                    `;
                } else {
                    productHTML = `
                        <div class="d-block">
                            <div class="text-info fw-semibold fs-6 mb-0 me-2 ms-2" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Package">Package</div>
                        </div>
                    `;
                }

                if (products.length > 0) {
                    let extraCount = products.length;
                    let productItems = "";

                    products.forEach((prd, index) => {
                        let variantHTML = "";
                        variantHTML += `
                            <div class="mb-2">
                                <div class="text-dark fw-semibold fs-8">Variant Details:</div>
                                <div class="text-black">${prd.variant_name ?? "N/A"}</div>
                                <div class="text-dark fw-semibold fs-8 mt-1">Variable Details:</div>
                                <div class="text-black">${prd.variable_name ?? "N/A"}</div>
                            </div>
                        `;

                        productItems += `
                            <div class="mb-1">
                                <div class="text-black fw-semibold fs-7">${prd.product_name}</div>
                                <label class="text-dark fw-semibold fs-8 mt-n1 d-block">
                                    ${prd.product_category_name ?? "Package"}
                                    <div class="position-relative d-inline-block">
                                        <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-2 cursor-pointer"
                                            data-bs-toggle="dropdown" title="Product Variant"></span>
                                        <div class="dropdown-menu dropdown-menu-end w-md-300px w-sm-100 mt-2 p-3"
                                            style="box-shadow: 0px 5px 15px -3px rgba(0,0,0,0.2),0px 8px 15px 1px rgba(0,0,0,0.14),0px 3px 15px 2px rgba(0,0,0,0.12);">
                                            <div class="text-black text-center fw-semibold fs-7 mb-2">
                                                <u>Product Variant Info</u>
                                            </div>
                                            ${variantHTML}
                                        </div>
                                    </div>
                                </label>
                            </div>
                            ${index < products.length - 1 ? '<hr class="mt-2 mb-2">' : ""}
                        `;
                    });

                    productListHTML = `
                        <div class="d-flex align-items-center">
                            <div class="mb-0">
                                <div class="cursor-pointer px-2 bg-primary ms-4 mt-2 rounded fw-semibold fs-4"
                                    data-bs-toggle="dropdown">
                                    <a href="javascript:;" class="cursor-pointer">
                                        <span class="text-white">${extraCount}</span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-start w-300px px-4 py-3">
                                        <div class="text-black fs-6 pb-1 text-center fw-semibold">Services Details</div>
                                        <hr class="mt-0 mb-2">
                                        ${productItems}
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                }

                if (workOrderStatus == 2) {
                    statusHTML =
                        `<div class="badge bg-info text-white fs-7 fw-semibold">Appoint Project Coordinator</div>`;
                } else if (workOrderStatus == 0) {
                    statusHTML = `<div class="badge bg-warning text-black fs-7 fw-semibold">Call Awaiting</div>`;
                } else if (workOrderStatus == 1) {
                    statusHTML = `<div class="badge bg-danger text-white fs-7 fw-semibold">Schedule dates</div>`;
                } else if (workOrderStatus == 4) {
                    statusHTML = `<div class="badge bg-primary text-white fs-7 fw-semibold">Permanent Close 
                                </div> <span 
                                    class="mdi mdi-information fs-4 text-secondary" 
                                    data-bs-toggle="tooltip" 
                                    data-bs-placement="bottom" 
                                    data-bs-html="true"
                                    data-bs-custom-class="tooltip-secondary"
                                    title="
                                        <div>
                                            <strong>Remark :</strong> ${products[0] ? products[0]?.remark : 'N/A'}
                                        </div>
                                    ">
                                </span>`;
                } else {
                    statusHTML =
                        `<div class="badge bg-success text-black fs-7 fw-semibold">Verified Work Order</div>`;
                }

                if (workOrderStatus == 0) {
                    actionHTML = `
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_first_call_confirmation" onclick="firstCallData(${service.proposal_id})">
                            <i class="mdi mdi-phone-outgoing-outline fs-3 text-black me-1"></i>First Call Confirmation
                        </a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_permanent_close" onclick="PermanentData(${service.proposal_id})">
                            <i class="mdi mdi-progress-close fs-3 text-black me-1"></i>Permanent Close 
                        </a>
                    `;
                } else if (workOrderStatus == 2) {
                    actionHTML = `
                        <a href="javascript:;" class="dropdown-item waves-effect" onclick="AssignStaff(${service.proposal_id})">
                            <span class="mdi mdi-account me-1 fs-3 text-black"></span>Appoint Project Coordinator
                        </a>
                    `;
                } else if (workOrderStatus == 1) {
                    actionHTML = `
                        <a href="javascript:;" class="dropdown-item waves-effect" onclick="assignDates(${service.proposal_id})">
                            <span class="mdi mdi-calendar-alert me-1 fs-3 text-black"></span>Schedule Dates
                        </a>
                    `;
                } else if (workOrderStatus === 3) {
                    actionHTML = `
                        <a href="javascript:;" class="dropdown-item" onclick="fetchMileStoneData(${service.proposal_id})">
                            <span> <i class="mdi mdi-cash-sync fs-3 text-black me-1"></i>Milestone Mapping</span>
                        </a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_work_order_view" onclick="view(${service.proposal_id})">
                            <span> <i class="mdi mdi-eye-outline fs-3 text-black me-1"></i>View</span>
                        </a>
                    `;
                }

                const row = `
                <tr>
                    <td>
                        <div class="d-flex flex-column">
                            <label class="text-truncate max-w-250px" data-bs-toggle="tooltip" data-bs-placement="top" title="${service.service_title}">${service.service_title}</label>
                            <label class="fs-8 text-info">${service.proposal_table_id}</label>
                        </div>
                    </td>
                    <td>
                        <label class="text-black fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${service.cus_name}">${service.cus_name}</label>
                        <div class="d-block">
                            <div class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer ID">${service.cus_id}</div>
                        </div>
                        <div class="d-block">
                            <div class="text-danger fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Service Register Date">${service.service_register_date}</div>
                        </div>
                    </td>
                    <td>
                        ${productHTML}
                        ${productListHTML}
                    </td>
                    <td>
                        <div class="d-flex justify-content-center mt-2 align-items-center" style="cursor: pointer;" onclick="proposalLink(${service.proposal_id})">
                            <span class="mdi mdi-link-variant fs-3 p-2 bg-label-danger rounded-circle"></span>
                        </div>
                    </td>
                    <td>${statusHTML}</td>
                    <td>
                        ${workOrderStatus != 4 ?
                        `<span class="text-center">
                                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        ${actionHTML}
                                    </div>
                                </span>` : ''}
                    </td>
                </tr>
            `;

                tbody.append(row);
            });

            // Re-initialize tooltips for new content
            $('[data-bs-toggle="tooltip"]').tooltip();
        }

        function proposalLink(id) {
            $.ajax({
                url: '/ids/encrypt',
                type: 'POST',
                data: {
                    values: id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(encrypted_course_id) {
                    window.location.href = "/customer_management/proposal_view/" + encrypted_course_id;
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error!',
                        text: xhr.responseJSON.message || 'Encryption failed.',
                        icon: 'error',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                }
            });
        }
    </script>
    <script>
        function PermanentData(id) {
            const button = $('#per_cls_button');
            button.prop('disabled', false).text('Permanant Close');
            $('#remark').val('');
            $('#per_cls_loader').show();
            $.ajax({
                url: `/get_first_call/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;

                        $('#per_cls_proposal_id').val(id);
                        $('#per_cls_cus_name').html(data.cus_name);
                        $('#per_cls_customer_id').html(data.customer_id);
                        $('#per_cls_mobile_num').html(data.cus_mobile);
                        $('#per_cls_cus_mail').html(data.cus_email_id).attr('title', data.cus_email_id)
                            .tooltip('dispose').tooltip();

                        const container = $('#per_cls_product_list');
                        container.empty();

                        data.product_list.forEach((product, index) => {
                            const row = `
                            <div class="col-lg-12 mb-3">
                                <label class="text-black fs-6 fw-semibold">
                                    <i class="mdi mdi-star-three-points-outline text-primary fs-3"></i>
                                </label>
                                <label class="text-black fs-6 fw-semibold text-wrap">
                                    <span>${product.product_name ?? 'N/A'}</span>
                                    <span class="text-danger fs-7 ms-1"> ${product.product_category_name ? `(${product.product_category_name})` : ''}</span>
                                </label>

                                <div class="position-relative d-inline-block">
                                    <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-2 cursor-pointer"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-bs-placement="bottom"
                                        title="Product Variant"></span>

                                    <div class="dropdown-menu dropdown-menu-end w-md-300px w-sm-100 mt-2 p-3"
                                        style="box-shadow: 0px 5px 15px -3px rgba(0, 0, 0, 0.2), 0px 8px 15px 1px rgba(0, 0, 0, 0.14), 0px 3px 15px 2px rgba(0, 0, 0, 0.12);">
                                        <div class="text-black text-center fw-semibold fs-7 mb-2">
                                            <u>Product Variant Info</u>
                                        </div>
                                        <div class="mb-2">
                                            <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                            <div class="text-black">${product.variant_name ?? '-'}</div>

                                            <div class="text-dark fw-semibold fs-8 mt-1">Details Variable:</div>
                                            <div class="text-black">${product.variable_name ?? '-'}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;

                            container.append(row);
                        });

                        const domainNames = data.domain_names;

                        if (Array.isArray(domainNames) && domainNames.length > 0) {
                            $('#per_cls_domains').html(domainNames.join(', '));
                        } else {
                            $('#per_cls_domains').html('No Domains Found');
                        }
                        get_per_cls_checklist();
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }
                },
                error: function(err) {
                    console.error('Ajax Error : ' + err);
                },
                complete: function() {
                    $('#per_cls_loader').hide();
                }
            });
        }

        function PerClsValidation() {
            const button = $('#per_cls_button');
            let isValid = true;
            $('#percls_check_list_err').html('');
            $('#percls_remark_err').html('');

            var checkedTaskCounts = $('.per_cls_chk:checked').length;
            if (checkedTaskCounts === 0) {
                $('#percls_check_list_err').html('Select atleast one checklist.');
                isValid = false;
            }
            var remark = $('#remark').val();
            if (remark.trim() == '') {
                $('#percls_remark_err').html('Enter Remark is required.');
                isValid = false;
            }
            if (!isValid) {
                return false;
            } else {
                button.text('Processing...').attr('disabled', true);

                const formData = {
                    proposal_id: $('#per_cls_proposal_id').val(),
                    checklist_items: [],
                    remark: $('#remark').val()
                };

                $('.per_cls_chk:checked').each(function() {
                    formData.checklist_items.push($(this).val());
                });


                $.ajax({
                    url: `/submit_permanent_close`,
                    type: 'POST',
                    data: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Permanant Close Confirmed!');
                            fetchServiceTable();
                            $('#kt_modal_permanent_close').modal('hide');
                        } else {
                            button.prop('disabled', false).text('Permanant Close');
                            toastr.error('Something Went Wrong!');
                        }
                    },
                    error: function(xhr, status, error) {
                        button.prop('disabled', false).text('Permanant Close');

                        let errorMessage = 'Something Went Wrong!';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMessage = xhr.responseJSON.message;
                        }
                        toastr.error(errorMessage);
                    }
                });
            }
        }
    </script>

    {{-- * FIRST CALL CONFIRMATION --}}
    <script>
        function firstCallData(id) {
            $('#first_call_loader').show();
            $.ajax({
                url: `/get_first_call/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const data = response.data;

                        $('#proposal_id').val(id);
                        $('#first_call_cus_name').html(data.cus_name);
                        $('#first_call_customer_id').html(data.customer_id);
                        $('#first_call_mobile_num').html(data.cus_mobile);
                        $('#first_call_cus_mail').html(data.cus_email_id).attr('title', data.cus_email_id)
                            .tooltip('dispose').tooltip();

                        const container = $('#first_call_product_list');
                        container.empty();

                        data.product_list.forEach((product, index) => {
                            const row = `
                            <div class="col-lg-12 mb-3">
                                <label class="text-black fs-6 fw-semibold">
                                    <i class="mdi mdi-star-three-points-outline text-primary fs-3"></i>
                                </label>
                                <label class="text-black fs-6 fw-semibold text-wrap">
                                    <span>${product.product_name ?? 'N/A'}</span>
                                    <span class="text-danger fs-7 ms-1"> ${product.product_category_name ? `(${product.product_category_name})` : ''}</span>
                                </label>

                                <div class="position-relative d-inline-block">
                                    <span class="mdi mdi-package-variant-closed text-primary fs-5 ms-2 cursor-pointer"
                                        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-bs-placement="bottom"
                                        title="Product Variant"></span>

                                    <div class="dropdown-menu dropdown-menu-end w-md-300px w-sm-100 mt-2 p-3"
                                        style="box-shadow: 0px 5px 15px -3px rgba(0, 0, 0, 0.2), 0px 8px 15px 1px rgba(0, 0, 0, 0.14), 0px 3px 15px 2px rgba(0, 0, 0, 0.12);">
                                        <div class="text-black text-center fw-semibold fs-7 mb-2">
                                            <u>Product Variant Info</u>
                                        </div>
                                        <div class="mb-2">
                                            <div class="text-dark fw-semibold fs-8">Variant Name:</div>
                                            <div class="text-black">${product.variant_name ?? '-'}</div>

                                            <div class="text-dark fw-semibold fs-8 mt-1">Details Variable:</div>
                                            <div class="text-black">${product.variable_name ?? '-'}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;

                            container.append(row);
                        });

                        const domainNames = data.domain_names;

                        if (Array.isArray(domainNames) && domainNames.length > 0) {
                            $('#first_call_domains').html(domainNames.join(', '));
                        } else {
                            $('#first_call_domains').html('No Domains Found');
                        }

                        get_workorder_checklist();
                        updateMilestoneTable(id);

                        $('[data-bs-toggle="tooltip"]').tooltip();
                    }
                },
                error: function(err) {
                    console.error('Ajax Error : ' + err);
                },
                complete: function() {
                    $('#first_call_loader').hide();
                }
            })
        }

        function get_workorder_checklist() {
            const container = $('#first_call_checklist_container');
            container.empty();

            $.ajax({
                url: `/get_workorder_checklist`,
                type: 'GET',
                success: function(response) {
                    const checks = response.data;
                    let html = '';

                    checks.forEach((check, index) => {
                        html += `
                        <div class="col-lg-12 mb-1">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input order_chk" type="checkbox" id="work_check_${index}"  value="${check.sno}">
                                <label for="work_check_${index}" class="text-black fs-7 fw-semibold">${check.work_order_checklist}</label>
                            </div>
                        </div>
                    `;
                    });

                    container.html(html);
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function get_per_cls_checklist() {
            const container = $('#per_cls_checklist_container');
            container.empty();

            $.ajax({
                url: `/get_workorder_checklist`,
                type: 'GET',
                success: function(response) {
                    const checks = response.data;
                    let html = '';

                    checks.forEach((check, index) => {
                        html += `
                        <div class="col-lg-12 mb-1">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input per_cls_chk" type="checkbox" id="work_check_${index}"  value="${check.sno}">
                                <label for="work_check_${index}" class="text-black fs-7 fw-semibold">${check.work_order_checklist}</label>
                            </div>
                        </div>
                    `;
                    });

                    container.html(html);
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function updateMilestoneTable(id) {
            $.ajax({
                url: `/get_proposal_pay_slot/${id}`,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 200 && response.data.length > 0) {
                        var tbody = '';

                        $.each(response.data, function(index, item) {
                            tbody += '<tr>';
                            tbody += '<td><label class="text-black fw-semibold fs-7" title="' + item
                                .payment_slot_name + '">' + item.payment_slot_name + '</label></td>';
                            tbody +=
                                `<td><label class="text-black fw-semibold fs-7 text-end">${item.payable_amount}</label></td>`;

                            if (index === 0) {
                                tbody += `<td>
                                        <input type="hidden"  value="${item.sno}" />
                                        <input type="text"  placeholder="Select Date"
                                            class="form-control bg-label-info border border-info" value="${item.initialPayDate}" disabled />
                                    </td>`;
                            } else {
                                tbody += `<td> 
                                        <input type="hidden" class="pay_slot_ids" value="${item.sno}" />
                                        <input type="text" placeholder="Select Date"
                                            class="form-control milestone_date next_pay_date" readonly />
                                    </td>`;
                            }

                            tbody += '</tr>';
                        });

                        $('#paySlotTableBody').html(tbody);

                        var maxPayDate = parseInt(response.maxPayDate.min_payment_days,
                            10); // get max date (20)

                        $(".milestone_date").flatpickr({
                            enableTime: false,
                            dateFormat: 'd-M-Y',
                            defaultDate: new Date(),
                            allowInput: true,
                            clickOpens: true,
                            time_24hr: false,
                            wrap: false,
                            disable: [
                                function(date) {
                                    return date.getDate() > maxPayDate;
                                }
                            ],
                        });


                    } else {
                        $('#paySlotTableBody').html('<tr><td colspan="2">No records found.</td></tr>');
                    }
                },
                error: function(xhr, status, error) {
                    $('#paySlotTableBody').html('<tr><td colspan="2">Error fetching data.</td></tr>');
                    console.error('AJAX Error:', error);
                }
            });
        }

        function firstCallValidation() {
            const button = $('#confirm_call_button');
            let isValid = true;
            $('#check_list_err').html('');
            $('#date_err').html('');

            var checkedTaskCounts = $('.order_chk:checked').length;
            if (checkedTaskCounts === 0) {
                $('#check_list_err').html('Select atleast one checklist.');
                isValid = false;
            }

            $('.milestone_date').each(function() {
                const date = $(this).val();

                if (!date || date.trim() === '') {
                    $('#date_err').text('Milestone Date is required.');
                    isValid = false;
                }
            });

            if (!isValid) {
                return false;
            } else {
                button.text('Processing...').attr('disabled', true);

                const formData = {
                    proposal_id: $('#proposal_id').val(),
                    billable_details: $('input[name="billable_det"]:checked').val(),
                    checklist_items: [],
                    pay_slot_ids: [],
                    next_pay_date: [],
                    description: $('#order_desc').val()
                };

                $('.order_chk:checked').each(function() {
                    formData.checklist_items.push($(this).val());
                });

                $('.pay_slot_ids').each(function() {
                    formData.pay_slot_ids.push($(this).val());
                });

                $('.next_pay_date').each(function() {
                    formData.next_pay_date.push($(this).val());
                });

                submitFirstCall(formData, button);
            }
        }

        function submitFirstCall(data, button) {
            $.ajax({
                url: `/submit_first_call`,
                type: 'POST',
                data: data,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success('First Call Confirmed!');
                        fetchServiceTable();
                        resetFirstCall();
                        $('#kt_modal_first_call_confirmation').modal('hide');
                        AssignStaff(response.data);
                    } else {
                        button.prop('disabled', false).text('Confirm Call');
                        toastr.error('Something Went Wrong!');
                    }
                },
                error: function(xhr, status, error) {
                    button.prop('disabled', false).text('Confirm Call');

                    let errorMessage = 'Something Went Wrong!';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                    toastr.error(errorMessage);
                }
            });
        }

        function resetFirstCall() {
            $('#check_list_err').html('');
            $('#confirm_call_button').prop('disabled', false).text('Confirm Call');
            $('#proposal_id').val('');
            $('#first_call_cus_name').html('-');
            $('#first_call_customer_id').html('-');
            $('#first_call_mobile_num').html('-');
            $('#first_call_cus_mail').html('-').attr('title', '');
            $('#first_call_domains').html('No Domains Found');
            $('#first_call_product_list').empty();
            $('.order_chk').prop('checked', false);
            $('#service_based_billables').prop('checked', true);
            $('.milestone_date').val('');
            $('textarea[name="order_desc"]').val('');
            $('#paySlotTableBody').html('<tr><td colspan="3" class="text-center py-4">No records found.</td></tr>');
        }
    </script>

    {{-- * ALLOCATE PROJECT COORDINATOR --}}
    <script>
        function AssignStaff(id) {
            // $('#pc_assign_loader').show();
            // $('#assign_id').val(id);
            // updateAddMoreButtonState();
            // $('#journal_service_add').removeClass('d-none');
            // resetAssignStaff();

            $.ajax({
                url: '/ids/encrypt', // Your encryption route
                type: 'POST',
                data: {
                    values: id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(encrypted_course_id) {
                    window.location.href = "/allocate_project_coordinator/" + encrypted_course_id;
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error!',
                        text: xhr.responseJSON.message || 'Encryption failed.',
                        icon: 'error',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                }
            });

            // $.ajax({
            //     url: `/get_first_call/${id}`,
            //     method: 'GET',
            //     success: function (response) {
            //         if (response.status === 200) {
            //             const data = response.data;
            //             $('#assign_pc_cus_name').html(data.cus_name);
            //             $('#assign_pc_customer_id').html(data.customer_id);
            //             $('#assign_pc_mobile_num').html(data.cus_mobile);
            //             $('#assign_pc_cus_email').html(data.cus_email_id);

            //             const domainNames = data.domain_names;

            //             if (Array.isArray(domainNames) && domainNames.length > 0) {
            //                 $('#allocate_pc_domains').html(domainNames.join(', '));
            //             } else {
            //                 $('#allocate_pc_domains').html('No Domains Found');
            //             }

            //             // Store the complete service list globally for filtering
            //             window.allServices = data.product_list || [];
            //             populateServiceList(window.allServices);
            //             pcDataFetch();

            //         } else {
            //             console.error('No data received');
            //         }
            //     },
            //     error: function (err) {
            //         console.error('AJAX Error Due To : ' + err);
            //     },
            //     complete: function () {
            //         $('#pc_assign_loader').hide();
            //     }
            // });
        }

        function populateServiceList(services) {
            const productList = $('#product-list_staff');
            productList.empty();

            if (services.length === 0) {
                productList.html(`
                <div class="col-12 text-center py-6">
                    <i class="fas fa-inbox fs-2x text-muted mb-3"></i>
                    <p class="text-muted fs-6">No services found</p>
                </div>
            `);
                return;
            }

            services.forEach((service, index) => {
                if (service) {
                    const product = service;
                    const serviceHtml = `
                    <div class="col-12 mb-3 service-item">
                        <div class="service-card border rounded-3 bg-white p-4 position-relative">
                            <div class="service-number position-absolute top-0 start-0 bg-primary text-white px-3 py-1 rounded-end fs-7 fw-bold">
                                Service ${index + 1}
                            </div>
                            <div class="row align-items-center mt-4">
                                <div class="col-md-6">
                                    <div class="service-info">
                                        <label class="text-muted fs-7 fw-semibold mb-1">Service Name</label>
                                        <p class="text-dark fs-6 fw-bold mb-0">${product.product_name || '-'}</p>
                                    </div>
                                </div>
                                ${product.variant_name ? `
                                                            <div class="col-md-6">
                                                                <div class="service-info">
                                                                    <label class="text-muted fs-7 fw-semibold mb-1">Variant</label>
                                                                    <p class="text-dark fs-6 mb-0">${product.variant_name}</p>
                                                                </div>
                                                            </div>
                                                            ` : '<div class="col-md-6"></div>'}
                                ${product.variable_name ? `
                                                            <div class="col-md-6">
                                                                <div class="service-info">
                                                                    <label class="text-muted fs-7 fw-semibold mb-1">Variable</label>
                                                                    <p class="text-dark fs-6 mb-0">${product.variable_name}</p>
                                                                </div>
                                                            </div>
                                                            ` : '<div class="col-md-6"></div>'}
                                <div class="col-md-6 text-end">
                                    <span class="badge bg-info text-white fs-7">ID: ${service.service_id}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                    productList.append(serviceHtml);
                }
            });
        }

        function pcDataFetch() {
            $.ajax({
                url: `/get_allocate_pc`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const pcContainer = $('#assign_pc');
                        pcContainer.empty().append(`<option value="">Select Project Coordinator</option>`);

                        response.data.forEach(pc => {
                            pcContainer.append(
                                `<option value="${pc.sno}">${pc.staff_name} - ${pc.job_position_name}</option>`
                            );
                        });
                    } else {
                        console.error('Something Went Wrong.');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error :' + err);
                }
            });
        }

        function journalServiceToggle(isChecked) {
            const assignId = $('#assign_id').val();
            if (isChecked) {
                populateServiceDropdown(0, assignId);
                populateJournalIndex(0);
                $('.journal_service_container').removeClass('d-none');
                $('.pc_service_id_err, .pc_journal_index_err').text('');

            } else {
                $('.journal_service_container').addClass('d-none');
            }
        }

        // Function to get currently selected service IDs across all dropdowns
        function getSelectedServiceIds() {
            const selectedIds = [];
            $('.pc_service_id').each(function() {
                const selectedValue = $(this).val();
                if (selectedValue) {
                    selectedIds.push(selectedValue);
                }
            });
            return selectedIds;
        }

        function populateServiceDropdown(rowIndex, id) {
            $.ajax({
                url: `/get_service_data_dropdown/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const serviceLength = response.data.length;
                        $('#service_length').val(serviceLength);

                        if (serviceLength <= 1) {
                            $('#journal_service_add').addClass('d-none');
                        } else {
                            $('#journal_service_add').removeClass('d-none');
                        }

                        const serviceContainer = $(`#pc_service_id_${rowIndex}`);
                        const currentlySelectedIds = getSelectedServiceIds();

                        serviceContainer.empty().append(`<option value="">Select Service</option>`);

                        response.data.forEach(service => {
                            // Only add service if it's not already selected in any dropdown
                            // OR if it's the current dropdown's selected value (to maintain current selection)
                            const currentValue = serviceContainer.val();
                            if (!currentlySelectedIds.includes(service.sno.toString()) ||
                                service.sno.toString() === currentValue) {
                                serviceContainer.append(
                                    `<option value="${service.sno}">${service.product_name} - ${service.variant_name} - ${service.variable_name}</option>`
                                );
                            }
                        });

                        // Re-select the current value if it exists
                        if (serviceContainer.data('current-value')) {
                            serviceContainer.val(serviceContainer.data('current-value')).trigger('change');
                        }

                    } else {
                        console.log('Something Went Wrong');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching data' + err);
                }
            });
        }

        function populateJournalIndex(index) {
            $.ajax({
                url: `/get_journal_indexings`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const indexContainer = $(`#pc_journal_index_${index}`);
                        indexContainer.empty();

                        response.data.forEach(i => {
                            indexContainer.append(`<option value="${i.sno}">${i.index_name}</option>`);
                        });

                    } else {
                        console.error('Error Fetching.');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function validateJournalAddMore() {
            let isValid = true;
            let toastErr = false;

            const journalContainers = $('.journal_service_container:visible');
            const serviceLength = $('#service_length').val();

            journalContainers.each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.pc_service_id');
                const journalSelect = container.find('.pc_journal_index_id');

                container.find('.pc_service_id_err, .pc_journal_index_err').text('');

                if (!serviceSelect.val()) {
                    container.find('.pc_service_id_err').text('Service is required.');
                    isValid = false;
                    toastErr = true;
                }

                if (!journalSelect.val() || journalSelect.val().length === 0) {
                    container.find('.pc_journal_index_err').text('Journal Index is required.');
                    isValid = false;
                    toastErr = true;
                }
            });

            if (toastErr) {
                return false;
            } else {
                if (journalContainers.length >= serviceLength) {
                    toastr.error(`You cannot add more than ${serviceLength} journal services.`);
                    $('#journal_service_add').addClass('d-none');
                    return false;
                }
            }

            if (isValid) {
                addJournalContainer();
            }

            return isValid;
        }

        let journalIndex = 1;

        function addJournalContainer() {
            $('#staff_add_more_container').removeClass('d-none');
            const id = $('#assign_id').val();

            populateJournalIndex(journalIndex);
            populateServiceDropdown(journalIndex, id);

            var newJournalContainer = `
            <div class="row journal_service_container">
                <div class="col-lg-5 mb-6">
                    <label class="text-black mb-1 fs-6 fw-semibold ">Service<span class="text-danger">*</span></label>
                    <select class="select3 form-select pc_service_id" id="pc_service_id_${journalIndex}">
                    </select>
                    <div  class="text-danger fs-7 fw-semibold mt-1 pc_service_id_err"></div>
                </div>
                <div class="col-lg-5 mb-6">
                    <label class="text-black mb-1 fs-6 fw-semibold">Journal Index<span class="text-danger">*</span></label>
                    <select class="select3 form-select pc_journal_index_id" id="pc_journal_index_${journalIndex}"  data-placeholder="Select Journal Index" multiple>
                    </select>
                    <div class="text-danger fs-7 fw-semibold mt-1 pc_journal_index_err"></div>
                </div>
                <div class="col-lg-2 mb-1">
                    <a href="javascript:;"
                        class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 journal_container_remove">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
            </div>
        `;

            $('#staff_add_more_container').append(newJournalContainer);

            $('.select3').each(function() {
                $(this).wrap('<div class="position-relative"></div>').select2({
                    dropdownParent: $(this).parent()
                });
            });

            journalIndex++;
        }

        function updateAddMoreButtonState() {
            const currentCount = $('.journal_service_container:visible').length;
            const serviceLength = parseInt($('#service_length').val() || 0);

            if (serviceLength <= 1) {
                $('#journal_service_add').addClass('d-none');
                return;
            }

            if (currentCount >= serviceLength) {
                $('#journal_service_add').addClass('d-none');
            } else {
                $('#journal_service_add').removeClass('d-none');
            }
        }

        $(document).on('click', '.journal_container_remove', function() {
            $(this).closest('.row').remove();
            updateAddMoreButtonState();
            // Refresh all service dropdowns when a container is removed
            // refreshAllServiceDropdowns();
        });

        // Function to refresh all service dropdowns to update available options
        // function refreshAllServiceDropdowns() {
        //     const assignId = $('#assign_id').val();
        //     $('.journal_service_container:visible').each(function(index) {
        //         const serviceSelect = $(this).find('.pc_service_id');
        //         // Store current value before refresh
        //         const currentValue = serviceSelect.val();
        //         serviceSelect.data('current-value', currentValue);
        //         populateServiceDropdown(getRowIndex(serviceSelect.attr('id')), assignId);
        //     });
        // }

        // Helper function to extract row index from element ID
        function getRowIndex(elementId) {
            const match = elementId.match(/pc_service_id_(\d+)/);
            return match ? match[1] : 0;
        }

        // Event handler for service selection change
        // $(document).on('change', '.pc_service_id', function() {
        //     // Refresh all other service dropdowns when a service is selected
        //     refreshAllServiceDropdowns();
        // });

        function assignStaffValidation() {
            const journalContainers = $('.journal_service_container:visible');
            const button = $('#assign_pc_button');
            const pcId = $('#assign_pc').val();
            const jouranlCheck = $('#journal_check').is(':checked');
            let isValid = true;

            $('.pc_service_id_err, .pc_journal_index_err, #pc_add_err').text('');

            if (pcId === '') {
                $('#pc_add_err').text('Project Coordinator is required.');
                isValid = false;
            }

            if (jouranlCheck) {
                journalContainers.each(function(index) {
                    const container = $(this);
                    const serviceSelect = container.find('.pc_service_id');
                    const journalSelect = container.find('.pc_journal_index_id');

                    container.find('.pc_service_id_err, .pc_journal_index_err').text('');

                    if (!serviceSelect.val()) {
                        container.find('.pc_service_id_err').text('Service is required.');
                        isValid = false;
                    }

                    if (!journalSelect.val() || journalSelect.val().length === 0) {
                        container.find('.pc_journal_index_err').text('Journal Index is required.');
                        isValid = false;
                    }
                });
            }

            if (!isValid) {
                return false;
            } else {
                const journalServices = [];
                button.prop('disabled', true).text('Assigning...');

                if (jouranlCheck) {
                    journalContainers.each(function(index) {
                        const container = $(this);
                        const serviceId = container.find('.pc_service_id').val();
                        const journalIndexes = container.find('.pc_journal_index_id').val();

                        journalServices.push({
                            service_id: serviceId,
                            journal_indexes: journalIndexes
                        });
                    });
                }

                const formData = {
                    project_coordinator_id: pcId,
                    journal_check: jouranlCheck ? 1 : 0,
                    journal_services: journalServices,
                    proposal_id: $('#assign_id').val(),
                    _token: $('meta[name="csrf-token"]').attr('content')
                };

                allocateProjectCoordinator(formData, button);
            }
        }

        function allocateProjectCoordinator(data, button) {
            $.ajax({
                url: `/add_assign_staff_work_order`,
                type: 'POST',
                data: data,
                success: function(response) {
                    if (response.status === 200) {
                        toastr.success(`${response.data.staff_name} Allocated Successfully!`);
                        resetAssignStaff();
                        $('#kt_modal_assign_staff').modal('hide');
                        fetchServiceTable();
                        assignDates(response.data.proposal_id);
                    } else {
                        toastr.error(response.message || 'Something Went Wrong');
                        button.prop('disabled', false).text('Allocate Project Coordinator');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', error);
                    let errorMessage = 'Something went wrong';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }
                    toastr.error(errorMessage);
                    button.prop('disabled', false).text('Allocate Project Coordinator');
                }
            });
        }

        function resetAssignStaff() {
            $('#pc_add_err, .pc_service_id_err, .pc_journal_index_err').text('');
            $('#assign_pc').val('').trigger('change');
            $('#journal_check').prop('checked', false);
            $('.journal_service_container').not(':first').remove();
            const firstContainer = $('.journal_service_container:first');
            firstContainer.find('.pc_service_id').val('').trigger('change');
            firstContainer.find('select[id^="pc_journal_index_"]').val('').trigger('change');
            $('#assign_pc_button').prop('disabled', false).text('Allocate Project Coordinator');
            $('#staff_add_more_container').addClass('d-none');
            $('.journal_service_container').addClass('d-none');
            journalIndex = 1;
        }
    </script>

    {{-- * ASSIGN DATE --}}
    <script>
        function assignDates(id) {
            // resetDateFields();
            // $('#loaderOverlay').show();

            $.ajax({
                url: '/ids/encrypt', // Your encryption route
                type: 'POST',
                data: {
                    values: id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(encrypted_course_id) {
                    window.location.href = "/schedule_dates/" + encrypted_course_id;
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error!',
                        text: xhr.responseJSON.message || 'Encryption failed.',
                        icon: 'error',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                }
            });

            // $.ajax({
            //     url: `/assign_dates/${id}`,
            //     type: 'GET',
            //     dataType: 'json',
            //     success: function(response) {
            //         if(response.status === 200) {
            //             var dates = response.data;

            //             // Fetch Data
            //             $('#date_upd_id').val(dates.proposal_id);
            //             $('#assgn_date_cus_name').html(dates.cus_name);
            //             $('#assgn_date_cus_id').html(dates.customer_id);
            //             $('#assgn_date_cus_mobile').html(dates.cus_mobile ? dates.cus_mobile : '-');
            //             $('#assgn_date_cus_email').html(dates.cus_email_id ? dates.cus_email_id : '-');

            //             datesServiceDropdownFetch(0, id);

            //         } else {
            //             console.error('Data Fetching Failed!');
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         console.error('AJAX Error:', error);
            //     },
            //     complete: function() {
            //         // Hide loader after success/error
            //         $('#loaderOverlay').hide();
            //     }
            // });
        }

        function resetDateFields() {
            // Reset all input fields
            $('#date_upd_id').val('');
            $('#assgn_date_cus_name').html('');
            $('#assgn_date_cus_id').html('');
            $('#assgn_date_cus_mobile').html('');
            $('#assgn_date_cus_email').html('');

            // Reset all date fields
            $('.development_date_select, .deliverable_date_select, .cus_end_date_select').val('');

            // Reset all service dropdowns
            $('.schedule_date_service').val('').trigger('change');

            // Clear all error messages
            $('.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err').text('');

            // Reset datepicker start dates
            $('.development_date_select, .deliverable_date_select, .cus_end_date_select').datepicker('setStartDate', null);

            // Remove all dynamically added date containers
            $('#schedule_date_add_more_container').empty();

            // Reset dateIndex
            dateIndex = 1;

            // Show add more button
            $('#schedule_dates_add').removeClass('d-none');

            // Reset the first container (make remove button hidden again)
            $('.schedule_dates_container:first .schedule_dates_remove').closest('.col-lg-2').addClass('d-none');
        }

        $(document).ready(function() {
            // Common settings for all datepickers
            const commonOptions = {
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: 'auto left'
            };

            // Apply datepicker to initial fields
            $('#sel_dev_date_0, #sel_del_date_0, #sel_cus_end_date_0').datepicker(commonOptions);

            // Event delegation for development date changes (works for both static and dynamic)
            $(document).on('changeDate', '.development_date_select', function(e) {
                let devDate = e.date;
                let container = $(this).closest('.schedule_dates_container');

                if (devDate) {
                    // Set Deliverable date minimum = Dev date
                    container.find('.deliverable_date_select').datepicker('setStartDate', devDate);

                    // Set Customer End date minimum = Dev date  
                    container.find('.cus_end_date_select').datepicker('setStartDate', devDate);

                    // Clear previously selected deliverable and customer end dates
                    container.find('.deliverable_date_select').val('');
                    container.find('.cus_end_date_select').val('');

                    // Clear error messages
                    container.find('.sel_del_date_err, .sel_cus_end_date_err').text('');
                }
            });

            // Event delegation for deliverable date changes
            $(document).on('changeDate', '.deliverable_date_select', function(e) {
                let delDate = e.date;
                let container = $(this).closest('.schedule_dates_container');

                if (delDate) {
                    // Set Customer End date minimum = Deliverable date
                    container.find('.cus_end_date_select').datepicker('setStartDate', delDate);

                    // Clear previously selected customer end date if it's before deliverable date
                    let cusDate = container.find('.cus_end_date_select').datepicker('getDate');
                    if (cusDate && cusDate < delDate) {
                        container.find('.cus_end_date_select').val('');
                    }

                    // Clear error message
                    container.find('.sel_cus_end_date_err').text('');
                }
            });

            // Event delegation for customer end date changes
            $(document).on('changeDate', '.cus_end_date_select', function(e) {
                let cusDate = e.date;
                let container = $(this).closest('.schedule_dates_container');
                let devDate = container.find('.development_date_select').datepicker('getDate');
                let delDate = container.find('.deliverable_date_select').datepicker('getDate');

                // If customer end date is selected without deliverable date
                if (cusDate && !delDate && devDate) {
                    // Auto-set deliverable date to development date
                    container.find('.deliverable_date_select').datepicker('setDate', devDate);
                    container.find('.deliverable_date_select').datepicker('update');
                }
            });
        });

        function selectedDatesService() {
            const selectedIds = [];
            $('.schedule_date_service').each(function() {
                const selectedValue = $(this).val();
                if (selectedValue) {
                    selectedIds.push(selectedValue);
                }
            });
            return selectedIds;
        }

        function datesServiceDropdownFetch(rowIndex, id) {
            $.ajax({
                url: `/get_service_data_dropdown/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const serviceLength = response.data.length;
                        $('#dates_service_length').val(serviceLength);

                        if (serviceLength <= 1) {
                            $('#schedule_dates_add').addClass('d-none');
                        } else {
                            $('#schedule_dates_add').removeClass('d-none');
                        }

                        const serviceContainer = $(`#schedule_date_service_${rowIndex}`);
                        const currentlySelectedIds = selectedDatesService();

                        serviceContainer.empty().append(`<option value="">Select Service</option>`);

                        response.data.forEach(service => {
                            // Only add service if it's not already selected in any dropdown
                            // OR if it's the current dropdown's selected value (to maintain current selection)
                            const currentValue = serviceContainer.val();
                            if (!currentlySelectedIds.includes(service.sno.toString()) ||
                                service.sno.toString() === currentValue) {
                                serviceContainer.append(
                                    `<option value="${service.sno}">${service.product_name} - ${service.variant_name} - ${service.variable_name}</option>`
                                );
                            }
                        });

                        // Re-select the current value if it exists
                        if (serviceContainer.data('current-value')) {
                            serviceContainer.val(serviceContainer.data('current-value')).trigger('change');
                        }

                    } else {
                        console.log('Something Went Wrong');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching data' + err);
                }
            });
        }

        function validateDateAddMore() {
            let isValid = true;
            let toastErr = false;

            const datesContainers = $('.schedule_dates_container:visible');
            const serviceLength = $('#dates_service_length').val() || 0;

            datesContainers.each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.schedule_date_service');
                const developmentDateSelect = container.find('.development_date_select');
                const deliverableDateSelect = container.find('.deliverable_date_select');
                const cusEndDateSelect = container.find('.cus_end_date_select');

                container.find(
                        '.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err')
                    .text('');

                if (!serviceSelect.val()) {
                    container.find('.schedule_date_service_err').text('Select Service.');
                    isValid = false;
                    toastErr = true;
                }

                if (!developmentDateSelect.val()) {
                    container.find('.sel_dev_date_err').text('Select Development Date.');
                    isValid = false;
                    toastErr = true;
                }

                if (!deliverableDateSelect.val()) {
                    container.find('.sel_del_date_err').text('Select Development Date.');
                    isValid = false;
                    toastErr = true;
                }

                if (!cusEndDateSelect.val()) {
                    container.find('.sel_cus_end_date_err').text('Select Customer End Date.');
                    isValid = false;
                    toastErr = true;
                }
            });

            if (toastErr) {
                return false;
            } else {
                if (datesContainers.length >= serviceLength) {
                    toastr.error(`You cannot add more than ${serviceLength} services.`);
                    $('#schedule_dates_add').addClass('d-none');
                    return false;
                }
            }

            if (isValid) {
                addMoreDate();
            }
        }

        let dateIndex = 1;

        function addMoreDate() {

            const id = $('#date_upd_id').val();
            if (!id) return;

            datesServiceDropdownFetch(dateIndex, id);

            var newDateContainer = `
            <div class="row schedule_dates_container mb-2">
                <div class="col-lg-10 mb-6">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service<span class="text-danger">*</span></label>
                    <select class="select3 form-select schedule_date_service" id="schedule_date_service_${dateIndex}" >
                    </select>
                    <div  class="text-danger fs-7 fw-semibold mt-1 schedule_date_service_err"></div>
                </div>
                <div class="col-lg-2 mb-1">
                    <a href="javascript:;"
                        class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 schedule_dates_remove">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Development Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_dev_date_${dateIndex}"
                            class="form-control area_andarkottaram development_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_dev_date_err" id="sel_dev_date_err_${dateIndex}"></div>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Deliverable Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_del_date_${dateIndex}"
                            class="form-control area_andarkottaram deliverable_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_del_date_err" id="sel_del_date_err_${dateIndex}"></div>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer End Date<span class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_cus_end_date_${dateIndex}"
                            class="form-control area_andarkottaram cus_end_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_cus_end_date_err" id="sel_cus_end_date_err_${dateIndex}"></div>
                </div>
            </div>
        `;

            $('#schedule_date_add_more_container').append(newDateContainer);
            $('.select3').each(function() {
                $(this).wrap('<div class="position-relative"></div>').select2({
                    dropdownParent: $(this).parent()
                });
            });

            const commonOptions = {
                todayHighlight: true,
                autoclose: true, // FIXED: Changed 'autoClose' to 'autoclose'
                format: 'd-M-yyyy',
                orientation: 'auto left'
            };

            $(`#sel_dev_date_${dateIndex}, #sel_del_date_${dateIndex}, #sel_cus_end_date_${dateIndex}`).datepicker(
                commonOptions);

            $(`#sel_dev_date_${dateIndex}`).on('changeDate', function(e) {
                let devDate = e.date;
                if (devDate) {
                    $(`#sel_del_date_${dateIndex}`).datepicker('setStartDate', devDate);
                    $(`#sel_cus_end_date_${dateIndex}`).datepicker('setStartDate', devDate);
                    $(`#sel_del_date_${dateIndex}`).val('');
                    $(`#sel_cus_end_date_${dateIndex}`).val('');
                    $(`#sel_del_date_err_${dateIndex}, #sel_cus_end_date_err_${dateIndex}`).text('');
                }
            });

            $(`#sel_del_date_${dateIndex}`).on('changeDate', function(e) {
                let delDate = e.date;
                if (delDate) {
                    $(`#sel_cus_end_date_${dateIndex}`).datepicker('setStartDate', delDate);
                    let cusDate = $(`#sel_cus_end_date_${dateIndex}`).datepicker('getDate');
                    if (cusDate && cusDate < delDate) {
                        $(`#sel_cus_end_date_${dateIndex}`).val('');
                    }
                    $(`#sel_cus_end_date_err_${dateIndex}`).text('');
                }
            });

            $(`#sel_cus_end_date_${dateIndex}`).on('changeDate', function(e) {
                let cusDate = e.date;
                let devDate = $(`#sel_dev_date_${dateIndex}`).datepicker('getDate');
                let delDate = $(`#sel_del_date_${dateIndex}`).datepicker('getDate');

                if (cusDate && !delDate && devDate) {
                    $(`#sel_del_date_${dateIndex}`).datepicker('setDate', devDate);
                    $(`#sel_del_date_${dateIndex}`).datepicker('update');
                }
            });

            updateScheduleDatesAddMore();
            dateIndex++;
        }

        function updateScheduleDatesAddMore() {
            const currentCount = $('.schedule_dates_container:visible').length;
            const serviceLength = parseInt($('#dates_service_length').val() || 0);

            if (serviceLength <= 1) {
                $('#schedule_dates_add').addClass('d-none');
                return;
            }

            if (currentCount >= serviceLength) {
                $('#schedule_dates_add').addClass('d-none');
            } else {
                $('#schedule_dates_add').removeClass('d-none');
            }
        }

        $(document).on('click', '.schedule_dates_remove', function() {
            $(this).closest('.row').remove();
            updateScheduleDatesAddMore();
        })

        function assignDateValidation() {
            var isValid = true;
            const button = $('#assign_dates_button');

            // Clear all error messages first
            $('.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err').text('');

            // Validate all visible date containers
            $('.schedule_dates_container:visible').each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.schedule_date_service');
                const developmentDateSelect = container.find('.development_date_select');
                const deliverableDateSelect = container.find('.deliverable_date_select');
                const cusEndDateSelect = container.find('.cus_end_date_select');

                // Validate Service
                if (!serviceSelect.val()) {
                    container.find('.schedule_date_service_err').text('Select Service.');
                    isValid = false;
                }

                // Validate Development Date
                if (!developmentDateSelect.val()) {
                    container.find('.sel_dev_date_err').text('Select Development Date.');
                    isValid = false;
                }

                // Validate Deliverable Date
                if (!deliverableDateSelect.val()) {
                    container.find('.sel_del_date_err').text('Select Deliverable Date.');
                    isValid = false;
                }

                // Validate Customer End Date
                if (!cusEndDateSelect.val()) {
                    container.find('.sel_cus_end_date_err').text('Select Customer End Date.');
                    isValid = false;
                }

                // Additional validation: Check date order
                if (developmentDateSelect.val() && deliverableDateSelect.val() && cusEndDateSelect.val()) {
                    const devDate = new Date(developmentDateSelect.val());
                    const delDate = new Date(deliverableDateSelect.val());
                    const cusDate = new Date(cusEndDateSelect.val());

                    if (delDate < devDate) {
                        container.find('.sel_del_date_err').text(
                            'Deliverable date cannot be before development date.');
                        isValid = false;
                    }

                    if (cusDate < delDate) {
                        container.find('.sel_cus_end_date_err').text(
                            'Customer end date cannot be before deliverable date.');
                        isValid = false;
                    }
                }
            });

            if (!isValid) {
                toastr.error('Please fill all required fields with valid dates.');
                return false;
            } else {
                button.prop('disabled', true).text('Scheduling...');

                // Prepare data for all containers
                const dateData = [];
                $('.schedule_dates_container:visible').each(function(index) {
                    const container = $(this);
                    dateData.push({
                        service_id: container.find('.schedule_date_service').val(),
                        development_date: container.find('.development_date_select').val(),
                        deliverable_date: container.find('.deliverable_date_select').val(),
                        customer_end_date: container.find('.cus_end_date_select').val()
                    });
                });

                var id = $('#date_upd_id').val();
                $.ajax({
                    url: `/save_date_tool/${id}`,
                    type: 'POST',
                    data: {
                        date_data: dateData,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Dates Updated Successfully!');
                            resetDates();
                            $('#kt_modal_select_date').modal('hide');
                            button.prop('disabled', false).text('Schedule Dates');
                            fetchServiceTable();
                            fetchMileStoneData(response.data);
                        } else {
                            button.prop('disabled', false).text('Schedule Dates');
                            toastr.error('Dates Updation Failed!');
                        }
                    },
                    error: function(xhr, status, error) {
                        button.prop('disabled', false).text('Schedule Dates');
                        console.error('AJAX Error:', error);
                        toastr.error('An error occurred while saving dates.');
                    }
                });
            }
        }

        function resetDates() {
            $('#assign_dates_button').prop('disabled', false).text('Schedule Dates');
            $('#sel_dev_date, #sel_del_date, #sel_cus_end_date').val('');
        }
    </script>

    {{-- * MILESTONE MAPPING * --}}
    <script>
        let milestoneIndex = 1;
        let maxTaskCount = 0;

        function fetchMileStoneData(id) {
            // $('#loaderOverlay_select_date').show();
            // resetMilestonItems();
            // initSelect2('#milestone_task_id_0');


            $.ajax({
                url: '/ids/encrypt', // Your encryption route
                type: 'POST',
                data: {
                    values: id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(encrypted_course_id) {
                    window.location.href = "/milestone_mapping/" + encrypted_course_id;
                },
                error: function(xhr) {
                    Swal.fire({
                        title: 'Error!',
                        text: xhr.responseJSON.message || 'Encryption failed.',
                        icon: 'error',
                        customClass: {
                            confirmButton: 'btn btn-primary waves-effect waves-light'
                        },
                        buttonsStyling: false
                    });
                }
            });

            // $.ajax({
            //     url: `/milestone_mapping_data_fetch/${id}`,
            //     method: 'GET',
            //     success: function (response) {
            //         if(response.status === 200) {
            //             const data = response.data;
            //             $('#milestone_hide_cus_id').val(data.customer_id);
            //             $('#milestone_hide_proposal_id').val(data.proposal_id);
            //             $('#milestone_cus_name').html(data.cus_name);
            //             $('#milestone_customer_id').html(data.cus_id);

            //             if(data.cus_mobile) {
            //                 $('#milestone_mobile_container').removeClass('d-none');
            //                 $('#milestone_mail_container').addClass('d-none');
            //                 $('#milestone_customer_mobile').html(data.cus_mobile);
            //             } else if (data.cus_email_id) {
            //                 $('#milestone_mobile_container').addClass('d-none');
            //                 $('#milestone_mail_container').removeClass('d-none');
            //                 $('#milestone_customer_mail').html(data.cus_email_id);
            //             }

            //             fetchMilestone(data.proposal_id);
            //         } else {
            //             console.error('Something Went Wrong...');
            //         }
            //     },
            //     error: function (err) {
            //         console.error('AJAX Error Due To : ', err);
            //     },
            //     complete: function () {
            //         $('#loaderOverlay_select_date').hide();
            //     }
            // });
        }

        function resetMilestonItems() {
            try {
                // 1. Reset service dropdown
                $('#milestone_service_id').val('').trigger('change');

                // 2. Reset first task dropdown (ID 0)
                $('#milestone_task_id_0').val('').trigger('change');

                // 3. Clear all dynamic milestone containers (except the first one)
                $('#milestone_mapping_add_container').empty();

                // 4. Reset global variables
                milestoneIndex = 1; // MUST START FROM 1 (0 already exists)
                maxTaskCount = 0;

                // 5. Reset hidden fields
                $('#milestone-hidden-service-id').val('');

                // 6. Clear generated input fields (pages/percentage)
                $('.product-pages').val('');
                $('.product-percentage').val('');

                // Also clear category area for index 0
                $('#milestone_category_container_0').empty();

                // 7. Clear validation errors
                $('.milestone_task_id_err').empty();
                $('.pages_err').empty();
                $('.percentage_err').empty();

                // 8. Reset add more button
                $('#milestone_add_more_btn')
                    .prop('disabled', true)
                    .removeClass('btn-disabled')
                    .text('Add More');

                // 9. Reset task count message
                $('#task_count_message').text('Please select a service first');

            } catch (error) {
                console.error('Error resetting milestone items:', error);
            }
        }

        function fetchMilestone(id) {
            $.ajax({
                url: `/get_milestone_data/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const milestoneContainer = $('#milestone_id');
                        milestoneContainer.empty().append(`<option value="">Select Milestone</option>`);
                        response.data.forEach(mile => {
                            milestoneContainer.append(
                                `<option value="${mile.sno}">${mile.payment_slot_name}</option>`);
                        });
                    } else {
                        console.error('AJAX Error');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                }
            });
        }

        function fetchMilestoneServices() {
            const proposalId = $('#milestone_hide_proposal_id').val();

            $.ajax({
                url: `/get_milestone_service_data/${proposalId}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const serviceContainer = $('#milestone_service_id');
                        serviceContainer.empty().append(`<option value="">Select Service</option>`);
                        response.data.forEach(service => {
                            serviceContainer.append(
                                `<option value="${service.sno}">${service.product_name} - ${service.service_id}</option>`
                            );
                        });
                    } else {
                        console.error('AJAX Error');
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To : ', err);
                }
            });
        }

        function getTaskCategory(id, index) {
            if (!id) {
                $('#milestone_category_container_' + index).empty();
                return;
            }

            $.ajax({
                url: `/get_task_category/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const categoryContainer = $('#milestone_category_container_' + index);
                        categoryContainer.empty();

                        let html = '';
                        if (response.data.category_check == 0) {
                            html = `
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pages<span class="text-danger">*</span></label>
                                <input type="text" class="form-control product-pages" placeholder="Enter Pages" id="product_pages_${index}"/>
                                <div class="text-danger mt-2 fs-7 fw-semibold pages_err"></div>
                            </div>
                        `;
                        } else {
                            html = `
                            <div class="col-lg-12 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Percentage<span class="text-danger">*</span></label>
                                <input type="text" class="form-control product-percentage" placeholder="Enter Percentage" id="product_percentage_${index}"/>
                                <div class="text-danger mt-2 fs-7 fw-semibold percentage_err"></div>
                            </div>
                        `;
                        }
                        categoryContainer.html(html);
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function fetchMileStoneTasks(id, index) {
            if (!id) return;

            $.ajax({
                url: `/get_milestone_product/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {

                        maxTaskCount = response.task_count;

                        $('#milestone-hidden-service-id').val(id);
                        const taskContainer = $('#milestone_task_id_' + index);
                        taskContainer.empty().append(`<option value="">Select Task</option>`);

                        const selectedTaskIds = getSelectedTaskIds();

                        response.data.forEach(task => {
                            if (!selectedTaskIds.includes(task.sno.toString())) {
                                taskContainer.append(
                                    `<option value="${task.sno}">${task.task_name}</option>`);
                            }
                        });

                        updateAddMoreButtonState();
                    }
                },
                error: function(err) {
                    console.error('AJAX Error Due To :' + err);
                }
            });
        }

        function getSelectedTaskCount() {
            let count = 0;
            $('.milestone-task').each(function() {
                if ($(this).val() && $(this).val() !== '') {
                    count++;
                }
            });
            return count;
        }

        function updateAddMoreButtonState() {
            const selectedCount = getSelectedTaskCount();
            const addMoreButton = $('#milestone_add_more_btn');

            if (selectedCount >= maxTaskCount) {
                addMoreButton.prop('disabled', true);
                addMoreButton.addClass('btn-disabled');
            } else {
                addMoreButton.prop('disabled', false);
                addMoreButton.removeClass('btn-disabled');
            }
        }

        function getSelectedTaskIds() {
            const selectedIds = [];

            $('.milestone-task').each(function() {
                const selectedValue = $(this).val();

                if (selectedValue && selectedValue !== '') {
                    selectedIds.push(selectedValue);
                }
            });

            return selectedIds;
        }

        function updateAllTaskDropdowns() {
            const selectedIds = getSelectedTaskIds();

            $('.milestone-task').each(function() {
                const currentDropdown = $(this);
                const currentValue = currentDropdown.val();

                // Store current selection
                const currentSelection = currentValue;

                // Get all options in this dropdown
                const allOptions = currentDropdown.find('option');

                // Enable/disable options based on selection in other dropdowns
                allOptions.each(function() {
                    const option = $(this);
                    const optionValue = option.val();

                    if (optionValue && optionValue !== '') {
                        // Disable if selected in another dropdown AND not the current selection
                        if (selectedIds.includes(optionValue) && optionValue !== currentSelection) {
                            option.prop('disabled', true);
                        } else {
                            option.prop('disabled', false);
                        }
                    }
                });

                // If current selection became disabled (shouldn't happen with proper logic), clear it
                if (currentSelection && currentDropdown.find('option:selected').prop('disabled')) {
                    currentDropdown.val('');
                    // Also clear the category container
                    const index = currentDropdown.attr('id').split('_').pop();
                    $('#milestone_category_container_' + index).empty();
                }
            });
        }

        function milestoneAddMore() {
            const id = $('#milestone-hidden-service-id').val();
            if (!id) {
                return;
            }

            fetchMileStoneTasks(id, milestoneIndex);

            const selectedCount = getSelectedTaskCount();

            // Check if user can add more milestones
            if (selectedCount >= maxTaskCount) {
                alert(`You can only add up to ${maxTaskCount} tasks.`);
                return;
            }

            const currentIndex = milestoneIndex;

            var newMilestoneContainer = `
            <div class="milestone_mapping_container row" id="milestone_container_${currentIndex}">
                <div class="col-lg-10 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Task<span class="text-danger">*</span></label>
                    <select class="select3 form-select milestone-task" id="milestone_task_id_${currentIndex}" onchange="handleTaskSelection(this.value, ${currentIndex})">
                        <option value="">Select Task</option>
                    </select>
                    <div class="text-danger mt-2 fs-7 fw-semibold milestone_task_id_err"></div>
                </div>
                <div class="col-lg-2 mb-1">
                    <a href="javascript:;"
                        class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 milestone_container_remove">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
                <div id="milestone_category_container_${currentIndex}"></div>
            </div>
        `;

            $('#milestone_mapping_add_container').append(newMilestoneContainer);

            // Reinitialize select2 for the new element
            initSelect2(`#milestone_task_id_${currentIndex}`);

            milestoneIndex++;
            updateAddMoreButtonState();
        }

        function handleTaskSelection(taskId, index) {
            // Update all dropdowns to reflect the new selection
            updateAllTaskDropdowns();

            updateAddMoreButtonState();

            // Call the original function to handle category display
            getTaskCategory(taskId, index);
        }

        function initSelect2(selector) {
            $(selector).select2({
                dropdownParent: $('#select2-milestone-container'),
                width: '100%',
                minimumResultsForSearch: -1
            });
        }

        $(document).on('click', '.milestone_container_remove', function() {
            $(this).closest('.milestone_mapping_container').remove();
            updateAllTaskDropdowns();
            updateAddMoreButtonState();
        });

        $(document).on('input', '.product-pages', function() {
            this.value = this.value.replace(/[^0-9]/g, '').replace(/^0+/, '');
        });

        // Allow only numbers and limit percentage to 100
        $(document).on('input', '.product-percentage', function() {
            this.value = this.value.replace(/[^0-9]/g, '').substring(0, 3);
            if (parseInt(this.value) > 100) this.value = '100';
        });

        function milestoneAddValidation() {
            let isValid = true;
            const button = $('#milestone_button');

            // Reset errors
            $('.text-danger').text('');

            const milestoneId = $('#milestone_id').val();
            const serviceId = $('#milestone_service_id').val();

            if (milestoneId === '') {
                $('#milestone_id_err').text('Milestone is required.');
                isValid = false;
            }

            if (serviceId === '') {
                $('#milestone_service_id_err').text('Service is required.');
                isValid = false;
            }

            // Check if at least one task is added
            if ($('.milestone_mapping_container').length === 0) {
                alert('Please add at least one task.');
                isValid = false;
            }

            // Validate ALL dynamic rows
            $('.milestone_mapping_container').each(function() {
                const taskSelect = $(this).find('.milestone-task');
                const taskValue = taskSelect.val();

                if (!taskValue) {
                    $(this).find('.milestone_task_id_err').text('Task is required.');
                    isValid = false;
                }

                // Pages validation (only if pages input exists)
                const pagesInput = $(this).find('.product-pages');
                if (pagesInput.length > 0 && pagesInput.is(':visible')) {
                    const pagesVal = pagesInput.val().trim();

                    if (pagesVal === '') {
                        $(this).find('.pages_err').text('Pages is required.');
                        isValid = false;
                    } else if (parseInt(pagesVal) <= 0) {
                        $(this).find('.pages_err').text('Pages must be greater than 0.');
                        isValid = false;
                    }
                }

                // Percentage validation (only if percentage input exists)
                const percentageInput = $(this).find('.product-percentage');
                if (percentageInput.length > 0 && percentageInput.is(':visible')) {
                    const percentVal = percentageInput.val().trim();

                    if (percentVal === '') {
                        $(this).find('.percentage_err').text('Percentage is required.');
                        isValid = false;
                    } else if (parseInt(percentVal) > 100) {
                        $(this).find('.percentage_err').text('Percentage cannot exceed 100.');
                        isValid = false;
                    } else if (parseInt(percentVal) <= 0) {
                        $(this).find('.percentage_err').text('Percentage must be greater than 0.');
                        isValid = false;
                    }
                }

                // Ensure either pages or percentage has value
                const hasPages = pagesInput.length > 0 && pagesInput.is(':visible') && pagesInput.val().trim() !==
                    '';
                const hasPercentage = percentageInput.length > 0 && percentageInput.is(':visible') &&
                    percentageInput.val().trim() !== '';

                if (!hasPages && !hasPercentage) {
                    $(this).find('.pages_err, .percentage_err').text('Either pages or percentage is required.');
                    isValid = false;
                }
            });

            let totalPercentage = 0;
            $('.product-percentage').each(function() {
                const val = $(this).val().trim();
                if (val !== '') {
                    totalPercentage += parseInt(val);
                }
            });

            if ($('.product-percentage').length > 0 && totalPercentage !== 100) {
                Swal.fire({
                    icon: 'error',
                    title: '<strong>Invalid Percentage</strong>',
                    html: `
                    <div style="font-size: 16px; color: #333;">
                        The total percentage of all tasks must be exactly <b>100%</b>.<br>
                        Currently: <b style="color: #d33;">${totalPercentage}%</b>
                    </div>
                `,
                    showCloseButton: true,
                    showCancelButton: false,
                    focusConfirm: true,
                    confirmButtonText: 'Got it!',
                    customClass: {
                        popup: 'shadow-lg rounded-3 border border-danger p-4', // adds shadow, rounded corners, border
                        title: 'fs-4 fw-bold text-danger', // larger, bold, red title
                        htmlContainer: 'fs-6 text-dark mt-2', // body text styling
                        confirmButton: 'btn btn-danger btn-lg' // make button bigger and red
                    },
                    buttonsStyling: false,
                    backdrop: `
                    rgba(0,0,0,0.5)
                    left top
                    no-repeat
                `,
                    timerProgressBar: true
                });
                isValid = false;
            }

            // IF FAIL, STOP SUBMISSION
            if (!isValid) {
                return false;
            }

            // Build form data
            let taskData = [];
            let pagesData = [];
            let percentageData = [];

            $('.milestone_mapping_container').each(function() {
                const taskVal = $(this).find('.milestone-task').val();
                const pagesVal = $(this).find('.product-pages').val() || '';
                const percentVal = $(this).find('.product-percentage').val() || '';

                taskData.push(taskVal);
                pagesData.push(pagesVal);
                percentageData.push(percentVal);
            });

            const finalData = {
                customer_id: $('#milestone_hide_cus_id').val(),
                proposal_id: $('#milestone_hide_proposal_id').val(),
                milestone_id: milestoneId,
                service_id: serviceId,
                tasks: taskData,
                pages: pagesData,
                percentages: percentageData
            };

            console.log('Submitting data:', finalData);
            submitMilestoneMapping(finalData, button);

            return true;
        }

        function submitMilestoneMapping(data, button) {
            // Show loading state
            const originalText = button.text();
            button.prop('disabled', true).html('<i class="fas fa-spinner fa-spin"></i> Processing...');

            $.ajax({
                url: `/add_milestone_mapping`,
                method: 'POST',
                data: JSON.stringify(data),
                contentType: 'application/json',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    'X-Requested-With': 'XMLHttpRequest'
                },
                success: function(response) {
                    switch (response.status) {
                        case 200:
                            toastr.success(response.message, 'Success!', {
                                timeOut: 3000,
                                progressBar: true
                            });

                            location.reload();

                            // Reset form
                            resetMilestonItems();

                            // Optional: Trigger custom event for other components
                            $(document).trigger('milestone:mapped', [response.data]);
                            break;

                        case 422:
                            toastr.error(response.error_msg, 'Validation Error!', {
                                timeOut: 5000
                            });
                            break;

                        default:
                            toastr.error(response.message || 'Unknown error occurred', 'Error!');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error Details:', {
                        status: xhr.status,
                        statusText: xhr.statusText,
                        responseText: xhr.responseText,
                        error: error
                    });

                    let errorMessage = 'An error occurred while saving milestone.';

                    if (xhr.status === 422) {
                        const errors = xhr.responseJSON?.errors;
                        if (errors) {
                            errorMessage = Object.values(errors).flat().join('<br>');
                        } else {
                            errorMessage = xhr.responseJSON?.error_msg || 'Validation failed.';
                        }
                    } else if (xhr.status === 500) {
                        errorMessage = 'Server error. Please contact support.';
                    } else if (xhr.status === 404) {
                        errorMessage = 'Requested resource not found.';
                    } else if (xhr.status === 403) {
                        errorMessage = 'You are not authorized to perform this action.';
                    }

                    toastr.error(errorMessage, 'Error!', {
                        timeOut: 5000,
                        closeButton: true
                    });
                },
                complete: function() {
                    // Always re-enable button
                    button.prop('disabled', false).html(originalText);
                }
            });
        }
    </script>

    {{-- * VIEW --}}
    <script>
        function view(id) {
            if (!id) return;

            $.ajax({
                url: `/work_order_view/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {

                        const data = response.data;
                        html = '';
                        const viewContainer = $('#view_modal_body');

                        let staffImageBaseUrl = "{{ asset('staff_images') }}/";
                        let firstLetter = data.staff_name.charAt(0).toUpperCase();
                        const cusFirstLetter = data.cus_name.charAt(0).toUpperCase();
                        const services = data.product_list;
                        const checkLists = data.checklists;
                        const paySlots = data.pay_slots;
                        let serviceHTML = '';
                        let checkListHTML = '';
                        let paySlotHTML = '';
                        let totalAmount = 0;
                        const serviceCount = services.length || 0;
                        const formattedCount = serviceCount > 0 ? String(serviceCount).padStart(2, '0') : '00';

                        services.forEach(service => {

                            const journalCheck = service.journal_check;

                            serviceHTML += `
                            <div class="card-body pt-0">
                                <div class="d-flex align-items-center mb-3">
                                    <i class="mdi mdi-star-three-points-outline text-primary fs-4 me-2"></i>
                                    <div>
                                        <h5 class="text-dark fw-semibold mb-0">${service.product_name}</h5>
                                        <span class="text-danger fw-semibold fs-7">${service.service_id}</span>
                                    </div>
                                    <div class="position-relative ms-auto">
                                        <span class="mdi mdi-package-variant-closed text-primary fs-5 cursor-pointer" 
                                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" 
                                            data-bs-placement="bottom" title="Product Variant"></span>
                                        <div class="dropdown-menu dropdown-menu-end w-md-300px w-sm-100 mt-2 p-3 shadow-lg">
                                            <div class="text-black text-center fw-semibold fs-7 mb-2 border-bottom pb-2">
                                                Product Variant Info
                                            </div>
                                            <div class="mb-2">
                                                <div class="text-muted fw-semibold fs-8">Variant Name:</div>
                                                <div class="text-black">${service.variant_name}</div>
                                                <div class="text-muted fw-semibold fs-8 mt-2">Details Variable:</div>
                                                <div class="text-black">${service.variable_name}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row mt-4">
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center p-3 bg-light rounded">
                                            <div class="flex-shrink-0 me-1">
                                                <img src="{{ asset('assets/phdizone_images/service_view_check.gif') }}" 
                                                    alt="Service Based Billable" style="width:50px !important;height 50px !important;">
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-0 text-dark fw-semibold">Service Based Billable</h6>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <div class="d-flex align-items-center p-3 bg-light rounded">
                                            <div class="flex-shrink-0 me-1">
                                                <img src="{{ asset('assets/phdizone_images/${journalCheck == 1 ? `service_view_check` : `service_view_cross`}.gif') }}" 
                                                    alt="Journal Publication" style="width:  50px !important;height: 50px !important;">
                                            </div>
                                            <div class="flex-grow-1">
                                                <h6 class="mb-0 text-dark fw-semibold">Journal Publication</h6>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                        });

                        checkLists.forEach((check, index) => {
                            checkListHTML += `
                            <div class="d-flex align-items-center mb-1 p-2 rounded">
                                <div class="form-check form-check-custom form-check-solid me-3">
                                    <input class="form-check-input bg-success border border-success" type="checkbox"  value="" id="check_${index}" disabled checked>
                                </div>
                                <label class="form-check-label text-dark fw-semibold" for="check_${index}">
                                    ${check}
                                </label>
                            </div>
                        `;
                        });

                        paySlots.forEach(pay => {

                            const dateObj = new Date(pay.nextPayDate);
                            const options = {
                                day: '2-digit',
                                month: 'short',
                                year: 'numeric'
                            };
                            const formattedDate = dateObj.toLocaleDateString('en-GB', options)
                                .toUpperCase();

                            totalAmount += parseFloat(pay.payable_amount) || 0;

                            paySlotHTML += `
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <span class="bullet bullet-dot bg-success me-3"></span>
                                        <span class="fw-semibold">${pay.payment_slot_name}</span>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-bold text-dark">₹${parseFloat(pay.payable_amount).toLocaleString()}</span>
                                </td>
                                <td class="pe-4">
                                    <span class="text-muted">${formattedDate}</span>
                                </td>
                            </tr>
                        `;
                        });

                        html += `
                        <div class="mb-8 text-center">
                            <h2 class="text-center mb-3 text-dark fw-bold">Work Order Details</h2>
                            <span class="badge bg-success text-white fw-semibold fs-6 px-3 py-2 rounded-pill">
                                <i class="mdi mdi-check-circle me-1"></i>Verified Work Order
                            </span>
                        </div>
                        <div class="row g-4 mb-6">
                            <!-- Staff Card -->
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center">
                                            <div class="position-relative">
                                                <img src="${staffImageBaseUrl}${data.staff_image}" 
                                                    alt="${data.staff_name}"
                                                    class="rounded-circle border border-3 border-success staff-photo"
                                                    style="width: 80px; height: 80px; object-fit: cover;"
                                                    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">

                                                <!-- Initial avatar fallback -->
                                                <div class="avatar-initial" style="display:none;">
                                                    ${firstLetter}
                                                </div>
                                                <span class="position-absolute bottom-0 end-0 bg-success rounded-circle p-1 border border-2 border-white">
                                                    <i class="mdi mdi-check text-white fs-6"></i>
                                                </span>
                                            </div>
                                            <div class="ps-3">
                                                <h5 class="text-dark fw-bold mb-1">${data.staff_name}</h5>
                                                <span class="badge bg-info text-white px-2 py-1">${data.job_position_name}</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-body p-4">
                                        <div class="d-flex align-items-center">
                                            <div class="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center"
                                                style="width: 80px; height: 80px; font-size: 36px; font-weight: bold;">
                                               ${cusFirstLetter}
                                            </div>
                                            <div class="ps-3">
                                                <div class="d-flex align-items-center gap-2 mb-1">
                                                    <h5 class="text-dark fw-bold mb-0">${data.cus_name}</h5>
                                                    ${data.cus_mobile !== null ? 
                                                       `<span class="mdi mdi-phone text-primary" data-bs-toggle="tooltip" 
                                                                                        data-bs-placement="bottom" title="${data.cus_mobile}"></span>` : ''
                                                    }
                                                </div>
                                                <span class="text-info fw-semibold fs-7">${data.customer_id}</span>
                                                ${data.cus_email_id !== null ? 
                                                    `<div class="mt-2">
                                                                                    <small class="text-muted d-block">
                                                                                        <i class="mdi mdi-email-outline me-1"></i>${data.cus_email_id}
                                                                                    </small>
                                                                                </div>` : ''
                                                }
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row g-4 mb-6">
                            <div class="col-lg-8">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-transparent border-0 py-3 position-relative">
                                        <h4 class="card-title mb-0 text-dark fw-bold">
                                            <i class="mdi mdi-clipboard-text-outline text-primary me-2"></i>
                                            Service Details
                                        </h4>
                                        <!-- Notification Badge -->
                                        <span class="bg-danger text-white rounded-circle d-flex justify-content-center align-items-center 
                                                    position-absolute top-0 start-100 translate-middle 
                                                    animation-blink"
                                            style="width: 30px;height: 30px;font-size: 15px;">
                                            ${formattedCount}
                                        </span>
                                        <hr>
                                    </div>
                                    <div class="scroll-y max-h-200px px-3 py-1 mb-4">
                                        ${serviceHTML}
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h4 class="card-title mb-0 text-dark fw-bold">
                                            <i class="mdi mdi-calendar-clock text-primary me-2"></i>Schedule Dates
                                        </h4>
                                        <hr>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="timeline timeline-dashed">
                                            <div class="timeline-item">
                                                <div class="timeline-line w-20px"></div>
                                                <div class="timeline-icon">
                                                    <i class="mdi mdi-file-document-outline text-primary"></i>
                                                </div>
                                                <div class="timeline-content">
                                                    <div class="text-muted fs-7 mb-1">Development Date</div>
                                                    <div class="fw-bold text-dark">25-JAN-2025</div>
                                                </div>
                                            </div>
                                            <div class="timeline-item">
                                                <div class="timeline-line w-20px"></div>
                                                <div class="timeline-icon">
                                                    <i class="mdi mdi-send-check text-success"></i>
                                                </div>
                                                <div class="timeline-content">
                                                    <div class="text-muted fs-7 mb-1">Deliverables Date</div>
                                                    <div class="fw-bold text-dark">25-FEB-2025</div>
                                                </div>
                                            </div>
                                            <div class="timeline-item">
                                                <div class="timeline-line w-20px"></div>
                                                <div class="timeline-icon">
                                                    <i class="mdi mdi-account-check text-info"></i>
                                                </div>
                                                <div class="timeline-content">
                                                    <div class="text-muted fs-7 mb-1">Customer End Date</div>
                                                    <div class="fw-bold text-dark">25-MAR-2025</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card border-0 shadow-sm mb-6">
                            <div class="card-header bg-transparent border-0 py-3">
                                <h4 class="card-title mb-0 text-dark fw-bold">
                                    <i class="mdi mdi-cash-multiple text-primary me-2"></i>Payment Schedule
                                </h4>
                            </div>
                            <div class="card-body pt-0">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle gy-3">
                                        <thead class="bg-primary text-white">
                                            <tr>
                                                <th class="ps-4 fw-semibold">Pay Slot</th>
                                                <th class="fw-semibold">Payable Amount</th>
                                                <th class="pe-4 fw-semibold">Date</th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-700">
                                            ${paySlotHTML}
                                        </tbody>
                                        <tfoot class="bg-light">
                                            <tr>
                                                <td class="ps-4 fw-bold">Total</td>
                                                <td class="fw-bold text-dark">₹${totalAmount.toLocaleString()}</td>
                                                <td class="pe-4"></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="row g-4">
                            <!-- Checklist -->
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h4 class="card-title mb-0 text-dark fw-bold">
                                            <i class="mdi mdi-format-list-checks text-primary me-2"></i>Checklist
                                        </h4>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="scroll-y max-h-300px px-2 py-1">
                                            <div class="d-flex flex-column" id="check_list_view">
                                                ${checkListHTML}                                        
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card border-0 shadow-sm h-100">
                                    <div class="card-header bg-transparent border-0 py-3">
                                        <h4 class="card-title mb-0 text-dark fw-bold">
                                            <i class="mdi mdi-text-box-outline text-primary me-2"></i>Description
                                        </h4>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="p-3 rounded">
                                            <p class="text-dark mb-0" id="view_desc" style="text-align: justify;">
                                                ${data.desc || 'No Description Given'}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;

                        viewContainer.html(html);
                        $('[data-bs-toggle="tooltip"]').tooltip();

                    } else {
                        console.error('Something went wrong...');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching Due To :', err);
                }
            });
        }
    </script>

@endsection
