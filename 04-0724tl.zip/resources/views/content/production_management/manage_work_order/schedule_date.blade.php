@extends('layouts/layoutMaster')

@section('title', 'Schedule Project Dates')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')

    <div id="pc_assign_loader"
        style="display:none; position:fixed; top:0; left:0; width:100%; height:100%;
                            background:rgba(255,255,255,0.7); z-index:9999; 
                            display:flex; align-items:center; justify-content:center;">
        <div class="spinner-border text-primary fs-3" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    <div class="card mb-2">
        @php
            $helper = new \App\Helpers\Helpers();
        @endphp
        <div class="card-header border-bottom pb-1">
            <h5 class="mb-1 text-black" id="brch_fran_tle">Schedule Project Dates</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Service Management</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Manage Service</a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card">
        <div class="card-body mb-2 px-4 pb-2">
            <input type="hidden" name="date_upd_id" id="date_upd_id" value="{{ $id }}">
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Customer</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <label class="col-7 text-black fs-6 fw-bold" id="assgn_date_cus_name">{{ $data->cus_name }}</label>
            </div>
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Customer ID</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <label class="col-7 text-info fs-6 fw-bold" id="assgn_date_cus_id">{{ $data->customer_id }}</label>
            </div>
            <div class="row mb-4">
                <label class="col-4 text-dark fs-6 fw-semibold">Mobile No</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <label class="col-7 text-black fs-6 fw-bold" id="assgn_date_cus_mobile">{{ $data->cus_mobile }}</label>
            </div>
            <div class="row mb-6">
                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                <label class="col-1 text-black fs-6 fw-bold">:</label>
                <label class="col-7 text-black fs-6 fw-bold" id="assgn_date_cus_email">{{ $data->cus_email_id }}</label>
            </div>
            <input type="hidden" id="dates_service_length">
            <div class="row schedule_dates_container mb-2">
                <div class="col-lg-10 mb-6">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service<span class="text-danger">*</span></label>
                    <select class="select3 form-select schedule_date_service" id="schedule_date_service_0">
                    </select>
                    <div class="text-danger fs-7 fw-semibold mt-1 schedule_date_service_err"></div>
                </div>
                <div class="col-lg-2 mb-1 d-none">
                    <a href="javascript:;" class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 schedule_dates_remove">
                        <i class="mdi mdi-delete fs-4"></i>
                    </a>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Development Date<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_dev_date_0"
                            class="form-control area_andarkottaram development_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_dev_date_err" id="sel_dev_date_err_0">
                    </div>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Deliverable Date<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_del_date_0"
                            class="form-control area_andarkottaram deliverable_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_del_date_err" id="sel_del_date_err_0">
                    </div>
                </div>
                <div class="col-lg-4 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Customer End Date<span
                            class="text-danger">*</span></label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" placeholder="Select Date" readonly id="sel_cus_end_date_0"
                            class="form-control area_andarkottaram cus_end_date_select" />
                    </div>
                    <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_cus_end_date_err"
                        id="sel_cus_end_date_err_0"></div>
                </div>
            </div>
            <div id="schedule_date_add_more_container"></div>
            <div class="mb-4 mt-1 d-flex  justify-content-end ">
                <button type="button" class="btn btn-sm btn-primary fs-8 px-2 py-1" onclick="validateDateAddMore()"
                    id="schedule_dates_add">
                    <i class="mdi mdi-plus me-1"></i> Add More
                </button>
            </div>
            <div class="d-flex justify-content-end align-items-center mb-2">
                <a href="{{ url('/manage_service') }}" class="btn fw-bold btn-secondary me-3">Cancel</a>
                <button type="button" class="btn fw-bold btn-primary" id="assign_pc_button"
                    onclick="assignDateValidation()">
                    Schedule Dates
                </button>
            </div>
        </div>
        </form>
    </div>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .err_msg {
            /* background-color: red; */
            border-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
        function resetDateFields() {
            // Reset all input fields
            $('#date_upd_id').val('');
            $('#assgn_date_cus_name').html('');
            $('#assgn_date_cus_id').html('');
            $('#assgn_date_cus_mobile').html('');
            $('#assgn_date_cus_email').html('');

            // Reset all date fields
            $('.development_date_select, .deliverable_date_select, .cus_end_date_select').val('');

            // Reset all service dropdowns
            $('.schedule_date_service').val('').trigger('change');

            // Clear all error messages
            $('.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err').text('');

            // Reset datepicker start dates
            $('.development_date_select, .deliverable_date_select, .cus_end_date_select').datepicker('setStartDate', null);

            // Remove all dynamically added date containers
            $('#schedule_date_add_more_container').empty();

            // Reset dateIndex
            dateIndex = 1;

            // Reset to only one visible container
            $('.schedule_dates_container:first').show();
            $('.schedule_dates_container:gt(0)').remove();

            // Reset the first container's remove button
            $('.schedule_dates_container:first .schedule_dates_remove').closest('.col-lg-2').addClass('d-none');

            updateScheduleDatesAddMore();
        }

        const id = "{{ $id }}";
        $(document).ready(function() {
            datesServiceDropdownFetch(0, id);
            // Show add more button initially if needed
            updateScheduleDatesAddMore();
        });

        $(document).ready(function() {
            // Common settings for all datepickers
            const commonOptions = {
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: 'auto left'
            };

            // Apply datepicker to initial fields
            $('#sel_dev_date_0, #sel_del_date_0, #sel_cus_end_date_0').datepicker(commonOptions);

            // Event delegation for development date changes (works for both static and dynamic)
            $(document).on('changeDate', '.development_date_select', function(e) {
                let devDate = e.date;
                let container = $(this).closest('.schedule_dates_container');

                if (devDate) {
                    // Set Deliverable date minimum = Dev date
                    container.find('.deliverable_date_select').datepicker('setStartDate', devDate);

                    // Set Customer End date minimum = Dev date  
                    container.find('.cus_end_date_select').datepicker('setStartDate', devDate);

                    // Clear previously selected deliverable and customer end dates
                    container.find('.deliverable_date_select').val('');
                    container.find('.cus_end_date_select').val('');

                    // Clear error messages
                    container.find('.sel_del_date_err, .sel_cus_end_date_err').text('');
                }
            });

            // Event delegation for deliverable date changes
            $(document).on('changeDate', '.deliverable_date_select', function(e) {
                let delDate = e.date;
                let container = $(this).closest('.schedule_dates_container');

                if (delDate) {
                    // Set Customer End date minimum = Deliverable date
                    container.find('.cus_end_date_select').datepicker('setStartDate', delDate);

                    // Clear previously selected customer end date if it's before deliverable date
                    let cusDate = container.find('.cus_end_date_select').datepicker('getDate');
                    if (cusDate && cusDate < delDate) {
                        container.find('.cus_end_date_select').val('');
                    }

                    // Clear error message
                    container.find('.sel_cus_end_date_err').text('');
                }
            });

            // Event delegation for customer end date changes
            $(document).on('changeDate', '.cus_end_date_select', function(e) {
                let cusDate = e.date;
                let container = $(this).closest('.schedule_dates_container');
                let devDate = container.find('.development_date_select').datepicker('getDate');
                let delDate = container.find('.deliverable_date_select').datepicker('getDate');

                // If customer end date is selected without deliverable date
                if (cusDate && !delDate && devDate) {
                    // Auto-set deliverable date to development date
                    container.find('.deliverable_date_select').datepicker('setDate', devDate);
                    container.find('.deliverable_date_select').datepicker('update');
                }
            });
        });

        function selectedDatesService() {
            const selectedIds = [];
            $('.schedule_date_service').each(function() {
                const selectedValue = $(this).val();
                if (selectedValue) {
                    selectedIds.push(selectedValue);
                }
            });
            return selectedIds;
        }

        function datesServiceDropdownFetch(rowIndex, id) {
            $.ajax({
                url: `/get_service_data_dropdown/${id}`,
                type: 'GET',
                success: function(response) {
                    if (response.status === 200) {
                        const serviceLength = response.data.length;
                        $('#dates_service_length').val(serviceLength);

                        updateScheduleDatesAddMore();

                        const serviceContainer = $(`#schedule_date_service_${rowIndex}`);
                        const currentlySelectedIds = selectedDatesService();

                        serviceContainer.empty().append(`<option value="">Select Service</option>`);

                        response.data.forEach(service => {
                            // Only add service if it's not already selected in any dropdown
                            // OR if it's the current dropdown's selected value (to maintain current selection)
                            const currentValue = serviceContainer.val();
                            if (!currentlySelectedIds.includes(service.sno.toString()) ||
                                service.sno.toString() === currentValue) {
                                serviceContainer.append(
                                    `<option value="${service.sno}">${service.product_name} - ${service.variant_name} - ${service.variable_name}</option>`
                                );
                            }
                        });

                        // Re-select the current value if it exists
                        if (serviceContainer.data('current-value')) {
                            serviceContainer.val(serviceContainer.data('current-value')).trigger('change');
                        }

                    } else {
                        console.log('Something Went Wrong');
                    }
                },
                error: function(err) {
                    console.error('Error Fetching data' + err);
                },
                complete: function() {
                    $('#pc_assign_loader').hide();
                }
            });
        }

        function validateDateAddMore() {
            let isValid = true;
            let toastErr = false;

            const datesContainers = $('.schedule_dates_container:visible');
            const serviceLength = parseInt($('#dates_service_length').val() || 0);

            // First validate all existing containers
            datesContainers.each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.schedule_date_service');
                const developmentDateSelect = container.find('.development_date_select');
                const deliverableDateSelect = container.find('.deliverable_date_select');
                const cusEndDateSelect = container.find('.cus_end_date_select');

                container.find(
                        '.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err')
                    .text('');

                if (!serviceSelect.val()) {
                    container.find('.schedule_date_service_err').text('Select Service.');
                    isValid = false;
                    toastErr = true;
                }

                if (!developmentDateSelect.val()) {
                    container.find('.sel_dev_date_err').text('Select Development Date.');
                    isValid = false;
                    toastErr = true;
                }

                if (!deliverableDateSelect.val()) {
                    container.find('.sel_del_date_err').text('Select Deliverable Date.');
                    isValid = false;
                    toastErr = true;
                }

                if (!cusEndDateSelect.val()) {
                    container.find('.sel_cus_end_date_err').text('Select Customer End Date.');
                    isValid = false;
                    toastErr = true;
                }
            });

            if (toastErr) {
                toastr.error('Please fill all fields in existing containers before adding more.');
                return false;
            }

            // Check if we can add more
            if (datesContainers.length >= serviceLength) {
                toastr.error(`You cannot add more than ${serviceLength} services.`);
                updateScheduleDatesAddMore();
                return false;
            }

            if (isValid) {
                addMoreDate();
            }

            return isValid;
        }

        let dateIndex = 1;

        function addMoreDate() {
            const id = $('#date_upd_id').val();
            if (!id) return;

            // Update button state before adding
            updateScheduleDatesAddMore();

            // Show remove button on the first container when adding second one
            if ($('.schedule_dates_container:visible').length === 1) {
                $('.schedule_dates_container:first .schedule_dates_remove').closest('.col-lg-2').removeClass('d-none');
            }

            var newDateContainer = `
                <div class="row schedule_dates_container mb-2">
                    <div class="col-lg-10 mb-6">
                        <label class="text-black mb-1 fs-6 fw-semibold">Service<span class="text-danger">*</span></label>
                        <select class="select3 form-select schedule_date_service" id="schedule_date_service_${dateIndex}" >
                        </select>
                        <div  class="text-danger fs-7 fw-semibold mt-1 schedule_date_service_err"></div>
                    </div>
                    <div class="col-lg-2 mb-1">
                        <a href="javascript:;"
                            class="btn btn-outline-danger mt-6 mx-2 px-2 py-1 schedule_dates_remove">
                            <i class="mdi mdi-delete fs-4"></i>
                        </a>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Development Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" placeholder="Select Date" readonly id="sel_dev_date_${dateIndex}"
                                class="form-control area_andarkottaram development_date_select" />
                        </div>
                        <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_dev_date_err" id="sel_dev_date_err_${dateIndex}"></div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Deliverable Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" placeholder="Select Date" readonly id="sel_del_date_${dateIndex}"
                                class="form-control area_andarkottaram deliverable_date_select" />
                        </div>
                        <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_del_date_err" id="sel_del_date_err_${dateIndex}"></div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <label class="text-black mb-1 fs-6 fw-semibold">Customer End Date<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" placeholder="Select Date" readonly id="sel_cus_end_date_${dateIndex}"
                                class="form-control area_andarkottaram cus_end_date_select" />
                        </div>
                        <div class="error_msg text-danger mt-2 fs-7 fw-semibold sel_cus_end_date_err" id="sel_cus_end_date_err_${dateIndex}"></div>
                    </div>
                </div>
            `;

            $('#schedule_date_add_more_container').append(newDateContainer);

            // Initialize select2 for the new dropdown
            $(`#schedule_date_service_${dateIndex}`).wrap('<div class="position-relative"></div>').select2({
                dropdownParent: $(`#schedule_date_service_${dateIndex}`).parent()
            });

            // Fetch services for the new dropdown
            datesServiceDropdownFetch(dateIndex, id);

            // Initialize datepicker for the new container
            const commonOptions = {
                todayHighlight: true,
                autoclose: true,
                format: 'd-M-yyyy',
                orientation: 'auto left'
            };

            $(`#sel_dev_date_${dateIndex}, #sel_del_date_${dateIndex}, #sel_cus_end_date_${dateIndex}`).datepicker(
                commonOptions);

            // Update button state after adding
            updateScheduleDatesAddMore();

            dateIndex++;
        }

        function updateScheduleDatesAddMore() {
            const currentCount = $('.schedule_dates_container:visible').length;
            const serviceLength = parseInt($('#dates_service_length').val() || 0);

            if (serviceLength <= 1) {
                $('#schedule_dates_add').addClass('d-none');
                return;
            }

            if (currentCount >= serviceLength) {
                $('#schedule_dates_add').addClass('d-none');
            } else {
                $('#schedule_dates_add').removeClass('d-none');
            }
        }

        $(document).on('click', '.schedule_dates_remove', function() {
            const container = $(this).closest('.row');
            const containerCount = $('.schedule_dates_container:visible').length;

            // Don't remove if it's the only container left
            if (containerCount <= 1) {
                toastr.error('At least one service container is required.');
                return;
            }

            container.remove();

            // Hide remove button on first container if only one left
            if ($('.schedule_dates_container:visible').length === 1) {
                $('.schedule_dates_container:first .schedule_dates_remove').closest('.col-lg-2').addClass('d-none');
            }

            updateScheduleDatesAddMore();
        });

        function assignDateValidation() {
            var isValid = true;
            const button = $('#assign_dates_button');
            const serviceLength = parseInt($('#dates_service_length').val() || 0);
            const visibleContainers = $('.schedule_dates_container:visible');
            const containerCount = visibleContainers.length;

            // Clear all error messages first
            $('.sel_cus_end_date_err, .sel_del_date_err, .sel_dev_date_err, .schedule_date_service_err').text('');

            // Check if all services have containers
            if (containerCount < serviceLength) {
                toastr.error(`Please add dates for all ${serviceLength} services.`);
                return false;
            }

            // Validate all visible date containers
            visibleContainers.each(function(index) {
                const container = $(this);
                const serviceSelect = container.find('.schedule_date_service');
                const developmentDateSelect = container.find('.development_date_select');
                const deliverableDateSelect = container.find('.deliverable_date_select');
                const cusEndDateSelect = container.find('.cus_end_date_select');

                // Validate Service
                if (!serviceSelect.val()) {
                    container.find('.schedule_date_service_err').text('Select Service.');
                    isValid = false;
                }

                // Validate Development Date
                if (!developmentDateSelect.val()) {
                    container.find('.sel_dev_date_err').text('Select Development Date.');
                    isValid = false;
                }

                // Validate Deliverable Date
                if (!deliverableDateSelect.val()) {
                    container.find('.sel_del_date_err').text('Select Deliverable Date.');
                    isValid = false;
                }

                // Validate Customer End Date
                if (!cusEndDateSelect.val()) {
                    container.find('.sel_cus_end_date_err').text('Select Customer End Date.');
                    isValid = false;
                }

                // Additional validation: Check date order
                if (developmentDateSelect.val() && deliverableDateSelect.val() && cusEndDateSelect.val()) {
                    const devDate = new Date(developmentDateSelect.val());
                    const delDate = new Date(deliverableDateSelect.val());
                    const cusDate = new Date(cusEndDateSelect.val());

                    if (delDate < devDate) {
                        container.find('.sel_del_date_err').text(
                            'Deliverable date cannot be before development date.');
                        isValid = false;
                    }

                    if (cusDate < delDate) {
                        container.find('.sel_cus_end_date_err').text(
                            'Customer end date cannot be before deliverable date.');
                        isValid = false;
                    }
                }
            });

            // Check for duplicate service selections
            const selectedServices = [];
            let hasDuplicates = false;
            $('.schedule_date_service:visible').each(function() {
                const serviceId = $(this).val();
                if (serviceId) {
                    if (selectedServices.includes(serviceId)) {
                        toastr.error('Each service can only be selected once.');
                        hasDuplicates = true;
                    }
                    selectedServices.push(serviceId);
                }
            });

            if (hasDuplicates) {
                isValid = false;
            }

            if (!isValid) {
                toastr.error('Please fill all required fields with valid dates.');
                return false;
            } else {
                button.prop('disabled', true).text('Scheduling...');

                // Prepare data for all containers
                const dateData = [];
                visibleContainers.each(function(index) {
                    const container = $(this);
                    dateData.push({
                        service_id: container.find('.schedule_date_service').val(),
                        development_date: container.find('.development_date_select').val(),
                        deliverable_date: container.find('.deliverable_date_select').val(),
                        customer_end_date: container.find('.cus_end_date_select').val()
                    });
                });

                var id = $('#date_upd_id').val();
                $.ajax({
                    url: `/save_date_tool/${id}`,
                    type: 'POST',
                    data: {
                        date_data: dateData,
                        _token: $('meta[name="csrf-token"]').attr('content')
                    },
                    success: function(response) {
                        if (response.status === 200) {
                            toastr.success('Dates Updated Successfully!');
                            resetDateFields();
                            button.prop('disabled', false).text('Schedule Dates');
                            fetchMileStoneData(response.data);
                        } else {
                            button.prop('disabled', false).text('Schedule Dates');
                            toastr.error('Dates Updation Failed!');
                        }
                    },
                    error: function(xhr, status, error) {
                        button.prop('disabled', false).text('Schedule Dates');
                        console.error('AJAX Error:', error);
                        toastr.error('An error occurred while saving dates.');
                    }
                });
            }
        }

        function resetDates() {
            $('#assign_dates_button').prop('disabled', false).text('Schedule Dates');
            $('#sel_dev_date, #sel_del_date, #sel_cus_end_date').val('');
        }

        function fetchMileStoneData(id) {
        // $('#loaderOverlay_select_date').show();
        // resetMilestonItems();
        // initSelect2('#milestone_task_id_0');


        $.ajax({
             url: '/ids/encrypt', // Your encryption route
             type: 'POST',
             data: {
                 values: id,
                 _token: "{{  csrf_token()  }}"
             },
             success: function(encrypted_course_id) {
                window.location.href = "/milestone_mapping/" + encrypted_course_id;
             },
             error: function(xhr) {
                 Swal.fire({
                     title: 'Error!',
                     text: xhr.responseJSON.message || 'Encryption failed.',
                     icon: 'error',
                     customClass: {
                         confirmButton: 'btn btn-primary waves-effect waves-light'
                     },
                     buttonsStyling: false
                 });
             }
         });

        // $.ajax({
        //     url: `/milestone_mapping_data_fetch/${id}`,
        //     method: 'GET',
        //     success: function (response) {
        //         if(response.status === 200) {
        //             const data = response.data;
        //             $('#milestone_hide_cus_id').val(data.customer_id);
        //             $('#milestone_hide_proposal_id').val(data.proposal_id);
        //             $('#milestone_cus_name').html(data.cus_name);
        //             $('#milestone_customer_id').html(data.cus_id);

        //             if(data.cus_mobile) {
        //                 $('#milestone_mobile_container').removeClass('d-none');
        //                 $('#milestone_mail_container').addClass('d-none');
        //                 $('#milestone_customer_mobile').html(data.cus_mobile);
        //             } else if (data.cus_email_id) {
        //                 $('#milestone_mobile_container').addClass('d-none');
        //                 $('#milestone_mail_container').removeClass('d-none');
        //                 $('#milestone_customer_mail').html(data.cus_email_id);
        //             }

        //             fetchMilestone(data.proposal_id);
        //         } else {
        //             console.error('Something Went Wrong...');
        //         }
        //     },
        //     error: function (err) {
        //         console.error('AJAX Error Due To : ', err);
        //     },
        //     complete: function () {
        //         $('#loaderOverlay_select_date').hide();
        //     }
        // });
    }

        window.addEventListener('popstate', function (event) {
            window.location.href = "/manage_service";
        });
        
        history.pushState(null, null, location.href);
    </script>

@endsection
