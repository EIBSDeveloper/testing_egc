@extends('layouts/layoutMaster')

@section('title', 'Manage Appointments')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('page-script')
@endsection
@section('content')

    <!-- Lead List Table -->
    <div class="card">
        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Manage Appointments</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboards') }}" class="d-flex align-items-center"><i
                                class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        @php
            $helper = new \App\Helpers\Helpers();
            $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
            $user_id = auth()->user()->user_id;
            $user_data = $helper->get_staff_data($user_id);
            $module_name = 'Production Management';
            $menu_name = 'Manage Appointment';
            $loginstaffDetails = $helper->staff_details(auth()->user()->user_id);
            $IsNotProduction = 0;
            if ($loginstaffDetails->department_id != 2) {
                $IsNotProduction = 1;
            }
        @endphp
        <div class="card-body px-4 py-0">
            <div class="row mt-2">
                <div class="col-xl-12">
                    <div class="card-body px-1 py-1">
                        <div class="row mb-2">
                            <div class=" totalData col-lg-6 border py-2">
                                <h4 class="text-center">Total</h4>
                                <div class="row mb-2 ">
                                    <div class="col-lg-3 border rounded p-2 ">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Total Appointment" style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Total</div>

                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $TotalCounts) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 border rounded p-2 ">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Completed"
                                            style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Completed</div>

                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $completedCounts) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 border rounded p-2 ">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Cancelled"
                                            style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Cancelled</div>

                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $cancelledCounts) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 border rounded p-2 ">
                                        <a href="#" class="text-center  mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Pending" style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Pending</div>

                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $pendingCounts) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="d-flex gap-2 justify-content-center">
                                    <div class="total-success text-center border rounded p-2">
                                        <h5>Success rate</h5>
                                        <div class="badge bg-success text-black rounded fw-bold fs-6">
                                            {{ number_format($successAppointmentRate, 2, '.', '') }}%</div>
                                    </div>
                                    <div class="total-failure text-center border rounded p-2">
                                        <h5>Failure rate</h5>
                                        <div class="badge bg-danger rounded fw-bold fs-6">
                                            {{ number_format($failAppointmentRate, 2, '.', '') }}%</div>
                                    </div>
                                </div>
                            </div>
                            <div class="monthData col-lg-6 border py-2">
                                <h4 class="text-center">This Month (<span
                                        class="text-info">{{ \Carbon\Carbon::create($currentYear, $currentMonth)->format('F') }}
                                        - {{ $currentYear }}</span>)</h4>
                                <div class=" row mb-2">
                                    <div class="col-lg-3 p-2 border rounded">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Total Appointment" style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Total</div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $TotalCountsMonth) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 p-2 border rounded">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Completed"
                                            style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Completed</div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $completedCountsMonth) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 p-2 border rounded">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Cancelled"
                                            style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Cancelled</div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $cancelledCountsMonth) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-lg-3 p-2 border rounded">
                                        <a href="#" class="text-center mb-2" data-bs-toggle="tooltip"
                                            data-bs-placement="bottom" title="Appointment Pending"
                                            style="min-width: 100px">
                                            <div class="fw-semibold fs-5 text-black text-center">Pending</div>
                                            <div class="d-block mt-2">
                                                <div class="badge bg-primary rounded fw-bold fs-6">
                                                    {{ sprintf('%02d', $pendingCountsMonth) }}</div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <div class="d-flex gap-2 justify-content-center">
                                    <div class="total-success text-center border rounded p-2">
                                        <h5>Success rate</h5>
                                        <div class="badge bg-success text-black rounded fw-bold fs-6">
                                            {{ number_format($successAppointmentRateMonth, 2, '.', '') }}%</div>
                                    </div>
                                    <div class="total-failure text-center border rounded p-2">
                                        <h5>Failure rate</h5>
                                        <div class="badge bg-danger rounded fw-bold fs-6">
                                            {{ number_format($failAppointmentRateMonth, 2, '.', '') }}%</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-end align-items-center flex-wrap">
                            <!--{{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" data-bs-toggle="modal" data-bs-target="#kt_modal_add_lead_appointment">-->
                        <!--    <span class="me-1"><i class="mdi mdi-plus mb-2"></i></span>Add Appointment-->
                        <!--</a> --}}-->
                            @if (auth()->user()->hasPermission($module_name, 'Filter', $menu_name))
                                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary me-2 mb-2" id="lead_filter"
                                    title="Filter">
                                    <i class="mdi mdi-filter-outline text-center"></i>
                                </a>
                            @endif

                        </div>
                        <div class="lead_filter" style="display: none;">
                            <form id="filter_form" method="POST" action="/production_management/lead_appointment">
                                @csrf
                                <div class="row py-1">
                                    <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                    <input type="hidden" name="filter_on" value="1">
                                    <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                        id="sorting_filter" value="@php echo $perpage ? $perpage : 10; @endphp" />

                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Status</label>
                                        <select id="lead_status_fill" name="lead_status_fill"
                                            class="select3 form-select">
                                            <option value="">Select Status</option>
                                            <option value="1" @if ($lead_status_fill == 1) selected @endif>
                                                Pending</option>
                                            <option value="2" @if ($lead_status_fill == 2) selected @endif>
                                                Completed</option>
                                            <option value="3" @if ($lead_status_fill == 3) selected @endif>
                                                Cancelled</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-3 mb-2">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Sales Person</label>
                                        <select id="staff_fill" name="staff_fill" class="select3 form-select">
                                            <option value="">Select Sales Person</option>
                                            @if (isset($staff_filter_list))
                                                @foreach ($staff_filter_list as $staff_li)
                                                    <option value="{{ $staff_li->sno }}"
                                                        @if ($staff_li->sno == $staff_fill) selected @endif>
                                                        {{ $staff_li->nick_name }} - {{ $staff_li->staff_name }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <!--<div class="col-lg-3 mb-2">-->
                                    <!--    <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>-->
                                    <!--    <select class="select3 form-select" name="dt_fill_issue_rpt"-->
                                    <!--        id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">-->
                                    <!--        <option value="all" @if ($date_filter == 'all') selected @endif>All</option>-->
                                    <!--        <option value="today"  @if ($date_filter == 'today') selected @endif>Today</option>-->
                                    <!--        <option value="week"  @if ($date_filter == 'week') selected @endif>This Week</option>-->
                                    <!--        <option value="monthly"  @if ($date_filter == 'monthly') selected @endif>This Month</option>-->
                                    <!--        <option value="custom_date"  @if ($date_filter == 'custom_date') selected @endif>Custom Date</option>-->
                                    <!--    </select>-->
                                    <!--</div>-->
                                    <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_today_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_st_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text bg-gray-200"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_week_ed_dt_fill" placeholder="Select Date"
                                                class="form-control" value="<?php echo date(' d-M-Y'); ?>" disabled />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date"
                                                class="form-control this_month_dt_fill" value="<?php echo date(' M-Y'); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" placeholder="Select Date" readonly
                                                name="from_date_fillter_textbox" class="form-control common_date_class"
                                                value="<?php echo date(' d-M-Y'); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                                        <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                            <input type="text" placeholder="Select Date"
                                                class="form-control common_date_class" readonly
                                                name="to_date_fillter_textbox" value="<?php echo date(' d-M-Y'); ?>" />
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-end mb-2">
                                    <a href="/production_management/lead_appointment" type="button"
                                        class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
                                    </a>
                                    <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
                                </div>
                            </form>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="mb-4">
                                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                                <div>
                                    <span>Show</span>
                                    <br>
                                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                        onchange="sort_filter(this.value);">
                                        @php
                                            $options = [10, 25, 100, 500]; // Define available options
                                        @endphp
                                        @foreach ($options as $option)
                                            <option value="{{ $option }}"
                                                @php echo ($perpage_count==$option) ? 'selected' : ''
                                        ; @endphp>
                                                @php echo $option; @endphp
                                            </option>
                                        @endforeach;
                                    </select>
                                </div>
                            </div>
                            <div class="">
                                <form id="search_form" method="POST" action="/production_management/lead_appointment">
                                    @csrf
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="mb-1">
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                id="sorting_filter"
                                                value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input type="text" class="form-control" id="lead_fill" name="lead_fill"
                                                value="{{ $lead_fill ?? '' }}"
                                                placeholder="Enter Lead - Name/ Mob. No/ Email Id" />
                                        </div>

                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 mb-1"
                                            onclick="search_filter_func()">Search</button>
                                        <a href="{{ url('/production_management/lead_appointment') }}" type="button"
                                            class="me-2 btn btn-sm btn-secondary fw-semibold mb-1 "><span
                                                class="mdi mdi-refresh fs-6"></span>
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <table
                                    class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                    <thead>
                                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                            <th class="min-w-100px">Lead</th>
                                            <th class="min-w-100px">Category / Date</th>
                                            <th class="min-w-100px">PC</th>
                                            <th class="min-w-100px">Assigned Staff</th>
                                            <th class="min-w-100px">Appointment Status</th>
                                            <th class="min-w-100px">Lead Status</th>
                                            <th class="min-w-80px">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-gray-600 fw-semibold fs-7">
                                        @if (auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                            @if (count($lead_ap_list) > 0)
                                                @foreach ($lead_ap_list as $list)
                                                    <tr
                                                        style="background-color:{{ $list->end_status == 1 ? 'lightpink' : '' }};">
                                                        <td>
                                                            <div class="mb-0 align-items-center">
                                                                @if ($IsNotProduction)
                                                                    <label>
                                                                        <span
                                                                            class="fs-7 me-2">{{ $list->lead_name }}</span>
                                                                        <span>
                                                                            @if ($list->lead_gender == 1)
                                                                                <i class="mdi mdi-face-man text-info"></i>
                                                                            @elseif($list->lead_gender == 2)
                                                                                <i
                                                                                    class="mdi mdi-face-woman text-danger"></i>
                                                                            @endif
                                                                        </span>
                                                                    </label>
                                                                    <div class="d-block text-dark fs-8" title="Email ID">
                                                                        {{ $list->lead_mobile }}
                                                                    </div>
                                                                    <div class="d-block text-black fs-7" title="Lead ID">
                                                                        {{ $list->lead_id }}
                                                                    </div>
                                                                @else
                                                                    <div class="d-block text-black fs-6" title="Lead ID">
                                                                        {{ $list->lead_id }}
                                                                    </div>
                                                                    @php
                                                                        $list->lead_name = $list->lead_id;
                                                                    @endphp
                                                                @endif
                                                            </div>
                                                        </td>
                                                        <td>
                                                            @php
                                                                if ($list->staff_id != 0) {
                                                                    $list->staffs_name = $list->staffs_name;
                                                                } else {
                                                                    $list->staffs_name = 'Staff Not Assigned';
                                                                }
                                                            @endphp
                                                            <div class="text-black fs-7">{{ $list->app_cat_name }}</div>
                                                            @if ($list->re_appointment_date != null)
                                                                <div class="d-block text-dark fs-8">
                                                                    {{ date('d-M-Y h:i A', strtotime($list->re_appointment_date)) }}
                                                                </div>
                                                            @else
                                                                <div class="d-block text-dark fs-8">
                                                                    {{ date('d-M-Y h:i A', strtotime($list->appointment_date)) }}
                                                                </div>
                                                            @endif
                                                        </td>
                                                        <td>{{ $list->pc_name }}</td>
                                                        @if (auth()->user()->hasPermission($module_name, 'Assign Staff', $menu_name))
                                                            <td>
                                                                @if ($list->staff_id == 0)
                                                                    <a href="javascript:;"
                                                                        class="border border-gray-400 rounded px-1 py-2"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_staff_confirmation"
                                                                        onclick="StaffAssign('{{ $list->sno }}')">
                                                                        <span data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom"
                                                                            title="Assign Staff">
                                                                            <i
                                                                                class="mdi mdi-account-plus fs-4 text-gray"></i>
                                                                        </span>
                                                                    </a>
                                                                @else
                                                                    <label
                                                                        class="text-black fw-semibold fs-7">{{ $list->staffs_name }}</label>
                                                                @endif
                                                            </td>
                                                        @else
                                                            <td class="text-center">
                                                                <label
                                                                    class="text-black fw-semibold fs-7 text-end">-</label>
                                                            </td>
                                                        @endif
                                                        @php
                                                            if ($list->staff_id != 0) {
                                                                $list->staff_name = $list->staffs_name;
                                                            } else {
                                                                $list->staff_name = 'Staff Not Assigned';
                                                            }
                                                        @endphp
                                                        @if (auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                                            <td>
                                                                @if ($list->appointment_status == 1)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-warning text-black fw-bold fs-8"
                                                                        id="" data-bs-toggle="dropdown"
                                                                        aria-haspopup="true" aria-expanded="false">New
                                                                        Appointment Scheduled</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_appointment_completed"
                                                                            onclick="completeAppointment({{ $list }})">Appointment
                                                                            Completed</a>
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_appointment_cancelled"
                                                                            onclick="cancelAppointment({{ $list }})">Appointment
                                                                            Cancelled</a>
                                                                    </div>
                                                                @elseif($list->appointment_status == 2)
                                                                    <div class="badge bg-success text-black fw-bold fs-8">
                                                                        Appointment Completed
                                                                    </div>
                                                                @elseif($list->appointment_status == 3)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-danger text-white fw-bold fs-8"
                                                                        id="" aria-haspopup="true"
                                                                        aria-expanded="false">Appointment Cancelled</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_re_appointment_schedule"
                                                                            onclick="reAppointment({{ $list }})">Re-Appointment
                                                                            Schedule</a>
                                                                    </div>
                                                                @elseif($list->appointment_status == 4)
                                                                    <a href="javascript:;"
                                                                        class="badge bg-info text-white fw-bold fs-8"
                                                                        id="" data-bs-toggle="dropdown"
                                                                        aria-haspopup="true"
                                                                        aria-expanded="false">Re-Appointment Scheduled</a>
                                                                    <div class="dropdown-menu dropdown-menu-end">
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_appointment_completed"
                                                                            onclick="completeAppointment({{ $list }})">Appointment
                                                                            Completed</a>
                                                                        <a href="javascript:;" class="dropdown-item"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#kt_modal_appointment_cancelled"
                                                                            onclick="cancelAppointment({{ $list }})">Appointment
                                                                            Cancelled</a>
                                                                    </div>
                                                                @endif
                                                            </td>
                                                        @else
                                                            <td>
                                                                @if ($list->appointment_status == 1)
                                                                    <div class="badge bg-warning text-black fw-bold fs-8">
                                                                        New Appointment Scheduled</div>
                                                                @elseif($list->appointment_status == 2)
                                                                    <div class="badge bg-success text-black fw-bold fs-8">
                                                                        Appointment Completed
                                                                    </div>
                                                                @elseif($list->appointment_status == 3)
                                                                    <div class="badge bg-danger text-white fw-bold fs-8">
                                                                        Appointment Cancelled</div>
                                                                @elseif($list->appointment_status == 4)
                                                                    <div class="badge bg-info text-white fw-bold fs-8">
                                                                        Re-Appointment Scheduled</div>
                                                                @endif
                                                            </td>
                                                        @endif
                                                        <?php $lead_st = $list->lead_status == 1 ? 'Inactive' : 'Active'; ?>
                                                        <td>
                                                            @if ($list->lead_status == 1)
                                                                <div
                                                                    class="badge bg-warning text-black rounded fw-bold fs-8">
                                                                    {{ $lead_st }}
                                                                </div>
                                                            @else
                                                                <div class="badge bg-info text-white rounded fw-bold fs-8">
                                                                    {{ $lead_st }}
                                                                </div>
                                                            @endif
                                                        </td>
                                                        <td>

                                                            <span class="text-end">
                                                                @if (auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                                    <a href="#" class="btn btn-icon btn-sm me-2"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#kt_modal_view_lead_appointment"
                                                                        onclick="openViewModal({{ $list }})">
                                                                        <span data-bs-toggle="tooltip"
                                                                            data-bs-placement="bottom" title="View">
                                                                            <i
                                                                                class="mdi mdi-eye-outline fs-3 text-black"></i>
                                                                        </span>
                                                                    </a>
                                                                @endif
                                                                {{-- @if ($list->appointment_status != 2)
                                                <!--<a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_lead_appointment" onclick="openEditModal({{ $list }})">-->
                                                <!--    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">-->
                                                <!--        <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>-->
                                                <!--    </span>-->
                                                <!--</a>-->
                                                @endif --}}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                        @else
                                            <tr>
                                                <td>Unauthorized Access</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                            </tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                            <div class="mt-4">
                                {{ $lead_ap_list->appends(request()->except(['page', '_token']))->links() }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--begin::Modal - Add Staff Confirmation-->
        <div class="modal fade" id="kt_modal_staff_confirmation" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-md">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-8 text-center">
                            <h3 class="text-center mb-4 text-black">Assign Staff</h3>
                        </div>
                        <form id="assignStaffForm" action="{{ route('assign_staff_appointment') }}" method="POST"
                            novalidate autocomplete="off">
                            @csrf
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <input type="hidden" name="assign_requirement_id" id="assign_requirement_id">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="assign_staff_id" name="assign_staff_id" class="select3 form-select">
                                        <option value="">Select Staff</option>
                                    </select>
                                    <div class="text-danger" id="assign_staff_id_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-8">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="assignSubmit" class="btn btn-primary"
                                    onclick="assignStaffForm()">Assign Staff</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal Add Staff Confirmation- -->

        <div class="modal fade" id="kt_modal_edit_staff_confirmation" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-md">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-8 text-center">
                            <h3 class="text-center mb-4 text-black">Update Staff</h3>
                        </div>
                        <form id="updateStaffForm" action="{{ route('assign_staff_appointment') }}" method="POST"
                            novalidate autocomplete="off">
                            @csrf
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <input type="hidden" name="assign_requirement_id" id="update_requirement_id">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="update_staff_id" name="assign_staff_id" class="select3 form-select">
                                        <option value="">Select Staff</option>
                                    </select>
                                    <div class="text-danger" id="update_staff_id_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-8">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="updateSubmit" class="btn btn-primary me-3"
                                    onclick="updateStaffForm()">Update Staff</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>

        <!--begin::Modal - Add Lead-->
        <div class="modal fade" id="kt_modal_add_lead_appointment" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-xl">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Create Lead Appointment</h3>
                        </div>
                        <form id="addLeadAppointmentForm" action="{{ route('lead_appointment_add') }}" method="POST"
                            autocomplete="off">
                            @csrf
                            <div class="form-repeater_ld_appmt_add">
                                <div data-repeater-list="group-a_led_question">
                                    <div data-repeater-item>
                                        <div class="row mt-4">
                                            <div class="col-lg-11">
                                                <div class="row">
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Lead (Name / Mobile
                                                            No / Email ID)<span class="text-danger">*</span></label>
                                                        {{-- <input type="text" class="form-control" id=""
                                                        placeholder="Enter Lead (Name/Mobile No/Email ID)" /> --}}
                                                        <div style="position: relative; width: 100%;">
                                                            <input type="text" class="form-control" id="search"
                                                                placeholder="Enter Lead (Name/Mobile No/Email ID)">
                                                            <input type="hidden" name="lead_id_add" id="lead_id_add">
                                                            <span id="result-list"
                                                                style="position: absolute; width: 100%; background-color: white; border: 1px solid #ddd; max-height: 150px; overflow-y: auto; display: none;"></span>
                                                            <div class="text-danger" id="search_err"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Category
                                                            <span class="text-danger">*</span></label>
                                                        <select id="appt_catg_add" class="select3 form-select"
                                                            name="appt_catg_add">
                                                            <option value="">Select Appointment Category</option>
                                                            <option value="Online">Online</option>
                                                            <option value="Offline">Offline</option>
                                                            <option value="Video">Video</option>
                                                        </select>
                                                        <div class="text-danger" id="appt_catg_add_err"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Appointment
                                                            Date<span class="text-danger">*</span></label>
                                                        <input type="text" class="form-control"
                                                            placeholder="Select Appointment Date" id="ld_appt_dt_add"
                                                            name="ld_appt_dt_add" />
                                                        <div class="text-danger" id="ld_appt_dt_add_err"></div>
                                                    </div>
                                                    <div class="col-lg-8 mb-3">
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Appointment
                                                            Reason<span class="text-danger">*</span></label>
                                                        <textarea class="form-control" rows="1" id="appt_reason_add" name="appt_reason_add"
                                                            placeholder="Enter Appointment Reason"></textarea>
                                                        <div class="text-danger" id="appt_reason_add_err"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                                                class="text-danger">*</span></label>
                                                        <select id="assg_staff_add" name="assg_staff_add"
                                                            class="select3 form-select">
                                                        </select>
                                                        <div class="text-danger" id="assg_staff_add_err"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{-- <div class="col-lg-1">
                                            <a href="javascript:;"
                                                class="btn btn-outline-danger mt-6 px-1 py-2 ld_appmt_add_del"
                                                data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"
                                                id="ld_appmt_add_del" style="display: none !important;">
                                                <i class="mdi mdi-delete fs-4"></i>
                                            </a>
                                        </div> --}}
                                        </div>
                                        {{--
                                    <hr class="my-1"> --}}
                                    </div>
                                </div>
                            </div>
                            {{-- <div class="mb-1 mt-1">
                            <button class="btn btn-primary ld_appmt_add" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Add" data-repeater-create id="ld_appmt_add">
                                <i class="mdi mdi-plus me-1"></i>
                            </button>
                        </div> --}}
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" id="addSubmit" onclick="addvalidateForm()"
                                    class="btn btn-primary">Create Lead Appointment</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Add Lead-->

        <!--begin::Modal - Edit Lead-->
        <div class="modal fade" id="kt_modal_edit_lead_appointment" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-xl">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Update Lead Appointment</h3>
                        </div>
                        <form id="editLeadAppointmentForm" action="{{ route('lead_appointment_update') }}"
                            method="POST" autocomplete="off">
                            @csrf
                            <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <input type="hidden" name="ld_appt_id_edit" id="ld_appt_id_edit">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Lead (Name / Mobile No / Email ID)<span
                                            class="text-danger">*</span></label>
                                    {{-- <input type="text" class="form-control" id="ld_name_edit" name="ld_name_edit"
                                    placeholder="Enter Lead (Name/Mobile No/Email ID)" value="" /> --}}
                                    <div style="position: relative; width: 100%;">
                                        <input type="text" class="form-control" id="search_edit"
                                            placeholder="Enter Lead (Name/Mobile No/Email ID)">
                                        <input type="hidden" name="lead_id_edit" id="lead_id_edit">
                                        <span id="result-list_edit"
                                            style="position: absolute; width: 100%; background-color: white; border: 1px solid #ddd; max-height: 150px; overflow-y: auto; display: none;"></span>
                                        <div class="text-danger" id="ld_name_edit_err"></div>
                                    </div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Category<span
                                            class="text-danger">*</span></label>
                                    <select id="appt_category_edit" name="appt_category_edit"
                                        class="select3 form-select">
                                        <option value="">Select Appointment Category</option>
                                        <option value="Online" selected>Online</option>
                                        <option value="Offline">Offline</option>
                                        <option value="Video">Video</option>
                                    </select>
                                    <div class="text-danger" id="appt_category_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Date<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" placeholder="Select Appointment Date"
                                        id="ld_appt_dt_edit" name="ld_appt_dt_edit" value="" />
                                    <div class="text-danger" id="ld_appt_dt_edit_err"></div>
                                </div>
                                <div class="col-lg-8 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Appointment Reason<span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="1" id="reason_msg_edit" name="reason_msg_edit"
                                        placeholder="Enter Appointment Reason"></textarea>
                                    <div class="text-danger" id="reason_msg_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Department<span
                                            class="text-danger">*</span></label>
                                    <select id="assg_dept_edit" name="assg_dept_edit" class="select3 form-select">

                                    </select>
                                    <div class="text-danger" id="assg_dept_edit_err"></div>
                                </div>
                                <div class="col-lg-4 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Assigned Staff<span
                                            class="text-danger">*</span></label>
                                    <select id="assgn_staff_edit" name="assgn_staff_edit" class="select3 form-select">

                                    </select>
                                    <div class="text-danger" id="assgn_staff_edit_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-end align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="button" onclick="editvalidateForm()" id="editSubmit"
                                    class="btn btn-primary">Update Lead Appointment</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Edit Lead-->

        <!--begin::Modal - View Lead-->
        <div class="modal fade" id="kt_modal_view_lead_appointment" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-6">
                            <h3 class="text-center text-black">
                                <label>View Lead - </label>
                                <label class="badge rounded fw-bold fs-5" data-bs-toggle="tooltip"
                                    data-bs-placement="bottom" title="Appointment Status" id="appt_status_view"></label>
                            </h3>
                        </div>
                        <div class="row mt-4 mb-2">
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Lead</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="lead_name_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Category</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="appt_category_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Date</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                    id="appt_date_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Assigned Staff</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="ass_staff_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Reason</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="reason_msg_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Comment</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="comment_msg_view"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Description</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="desc_msg_view"></label>
                            </div>
                        </div>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - View Lead-->

        <!--begin::Modal - Appointment Completed Status-->
        <div class="modal fade" id="kt_modal_appointment_completed" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Appointment Completed</h3>
                        </div>
                        <div class="row mt-4 mb-2">
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Lead</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="lead_name_complete"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Category</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="appt_category_complete"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Date</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                    id="appt_date_complete"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Assigned Staff</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="assg_staff_complete"></label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Reason</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="reason_msg_complete"></label>
                            </div>
                        </div>
                        <form action="{{ route('complete_appointment_update') }}" method="POST"
                            onsubmit="return completeValidateForm()" autocomplete="off">
                            @csrf
                            <div class="row">
                                <input type="hidden" name="lead_id_complete" id="lead_id_complete">
                                <label class="col-lg-12 text-dark mb-1 fs-6 fw-semibold">Conversation Message</label>
                                <div
                                    class="col-lg-12 d-flex align-items-content justify-content-between flex-lg-row flex-column mb-1">
                                    <div class="border border-2 border-gray-300i rounded px-1 pt-2 mb-2">
                                        <div class="form-check form-check-inline me-1">
                                            <input class="form-check-input" type="radio" name="conversation_msg_scr"
                                                id="conv_msg_positive" value="1" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Positive</label>
                                        </div>
                                        <div class="form-check form-check-inline me-1">
                                            <input class="form-check-input" type="radio" name="conversation_msg_scr"
                                                id="conv_msg_negative" value="-1" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Negative</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="conversation_msg_scr"
                                                id="conv_msg_neutral" value="0" />
                                            <label class="text-dark mb-1 fs-6 fw-semibold">Neutral</label>
                                        </div>
                                        <div class="text-danger" id="covo_scr_err"></div>
                                    </div>

                                    {{-- <div class="border border-2 border-gray-300i rounded px-1 pt-2 mb-2">
                                    <div class="form-check form-check-inline me-1">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_hl" value="HL" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Hot Lead">HL</label>
                                    </div>
                                    <div class="form-check form-check-inline me-1">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_dl" value="DL" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Dead Lead">DL</label>
                                    </div>
                                    <div class="form-check form-check-inline me-1">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_ft" value="FT" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Forward this Month">FT</label>
                                    </div>
                                    <div class="form-check form-check-inline me-1">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_fu" value="FU" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Follow Upcoming Month">FU</label>
                                    </div>
                                    <div class="form-check form-check-inline me-1">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_ftl" value="FTL" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Followup Timeless">FTL</label>
                                    </div>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="radio" name="lead_type_cmplt"
                                            id="conv_sht_msg_fp" value="FP" />
                                        <label class="text-dark mb-1 fs-6 fw-semibold" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Forward Potential">FP</label>
                                    </div>
                                    <div class="text-danger" id="lead_type_complt_err"></div>
                                </div> --}}
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <textarea class="form-control" rows="3" id="conver_msg" name="conversion_message"
                                        placeholder="Enter Conversation Message"></textarea>
                                </div>
                                <div class="d-flex justify-content-center align-items-center mt-4">
                                    <button type="reset" class="btn btn-secondary me-3"
                                        data-bs-dismiss="modal">Cancel</button>
                                    <button type="submit" class="btn btn-primary">Appointment Completed</button>
                                </div>
                            </div>
                        </form>

                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Appointment Completed Status-->

        <!--begin::Modal - Appointment Completed Status-->
        <div class="modal fade" id="kt_modal_appointment_cancelled" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Appointment Cancelled</h3>
                        </div>
                        <form id="cancelForm" action="{{ route('cancel_appointment_update') }}" method="POST"
                            onsubmit="return cancelValidateForm()" validate autocomplete="off">
                            @csrf
                            <div class="row mt-4 mb-2">
                                <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Lead</label>
                                <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                                <div class="col-lg-6 col-6 mb-1">
                                    <label class="text-black fs-6 fw-semibold" id="lead_name_cancel"></label>
                                </div>
                                <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Category</label>
                                <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                                <div class="col-lg-6 col-6 mb-1">
                                    <label class="text-black fs-6 fw-semibold" id="appt_category_cancel"></label>
                                </div>
                                <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Date</label>
                                <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                                <div class="col-lg-6 col-6 mb-1">
                                    <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                        id="appt_date_cancel"></label>
                                </div>
                                <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Assigned Staff</label>
                                <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                                <div class="col-lg-6 col-6 mb-1">
                                    <label class="text-black fs-6 fw-semibold" id="assg_staff_cancel"></label>
                                </div>
                                <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Reason</label>
                                <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                                <div class="col-lg-6 col-6 mb-1">
                                    <label class="text-black fs-6 fw-semibold" id="reason_msg_cancel"></label>
                                </div>

                                <div class="col-lg-12 mb-3">
                                    <input type="hidden" name="lead_id_cancel" id="lead_id_cancel">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" id="cancel_reason" name="cancel_reason_msg"
                                        placeholder="Enter Reason"></textarea>
                                    <div class="text-danger" id="cancel_reason_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Appointment Cancelled</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Appointment Completed Status-->

        <!--begin::Modal - Re-Appointment Schedule-->
        <div class="modal fade" id="kt_modal_re_appointment_schedule" tabindex="-1" aria-hidden="true"
            data-bs-keyboard="false" data-bs-backdrop="static">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-lg">
                <!--begin::Modal content-->
                <div class="modal-content rounded">
                    <!--begin::Modal header-->
                    <div class="modal-header justify-content-end border-0 pb-0">
                        <!--begin::Close-->
                        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                        transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                        transform="rotate(45 7.41422 6)" fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                        <!--begin::Heading-->
                        <div class="mb-4 text-center">
                            <h3 class="text-center mb-4 text-black">Re-Appointment Schedule</h3>
                        </div>
                        <div class="row mt-4 mb-2">
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Lead</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="lead_name_re_appt">Priya</label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Category</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="appt_category_re_appt">Online</label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Date</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="badge bg-warning rounded text-black fs-7 fw-semibold"
                                    id="appt_date_re_appt">04-Sep-2024 10.00 AM</label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Assigned Staff</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="assg_staff_re_appt">Vasanth</label>
                            </div>
                            <label class="col-lg-5 col-5 mb-1 text-dark fs-6 fw-smibold">Appointment Reason</label>
                            <label class="col-lg-1 col-1 mb-1 text-dark fs-6 fw-semibold">:</label>
                            <div class="col-lg-6 col-6 mb-1">
                                <label class="text-black fs-6 fw-semibold" id="reason_msg_re_appt">Course
                                    Details</label>
                            </div>
                        </div>
                        <form id="cancelForm" action="{{ route('re_appointment_update') }}" method="POST"
                            onsubmit="return reAppointmentValidateForm()" validate autocomplete="off">
                            @csrf
                            <div class="row mt-4 mb-2">
                                <div class="col-lg-6 mb-3">
                                    <input type="hidden" name="lead_id_re_appt" id="lead_id_re_appt">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Re-Appointment Date<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control"
                                        placeholder="Select Re-Appointment Date" id="ld_appt_reappt_date"
                                        name="re_appt_date" />
                                    <div class="text-danger" id="ld_appt_reappt_date_err"></div>
                                </div>
                                <div class="col-lg-12 mb-3">
                                    <label class="text-dark mb-1 fs-6 fw-semibold">Reason<span
                                            class="text-danger">*</span></label>
                                    <textarea class="form-control" rows="3" id="re_appt_reason" placeholder="Enter Reason"
                                        name="re_appt_reason_msg"></textarea>
                                    <div class="text-danger" id="re_appt_reason_err"></div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center align-items-center mt-4">
                                <button type="reset" class="btn btn-secondary me-3"
                                    data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-primary">Re-Appointment Scheduled</button>
                            </div>
                        </form>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Re-Appointment Schedule-->

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

        <style>
            /* Customize Toastr notification */
            .toast-success {
                background-color: green;
            }

            /* Customize Toastr notification */
            .toast-error {
                background-color: red;
            }

            .error_msg {
                border: solid 2px red !important;
                border-color: red !important;
            }
        </style>
        <script>
            // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
        </script>
        <script>
            $('.ld_appmt_add').on('click', e => {
                var bt = parseFloat($('.form-repeater_ld_appmt_add').length);
                let $clone = $('.form-repeater_ld_appmt_add').first().clone().hide();
                $clone.insertBefore('.form-repeater_ld_appmt_add:first').slideDown();
                if (bt == 1) {
                    $('.ld_appmt_add_del').attr('style', 'display: block !important');
                } else {
                    $('.ld_appmt_add_del').attr('style', 'display: block !important');
                }
            });

            $(document).on('click', '.form-repeater_ld_appmt_add .ld_appmt_add_del', e => {
                var bt = parseFloat($('.ld_appmt_add_del').length);
                // alert(bt);
                $(e.target).closest('.form-repeater_ld_appmt_add').slideUp(400, function() {
                    $(this).remove()
                });
                if (bt == 2) {
                    $('.ld_appmt_add_del').attr('style', 'display: none !important');
                } else {}
            });
        </script>
        <script>
            $(".list_page").DataTable({
                "ordering": false,
                "paging": false,
                // "aaSorting":[],
                "language": {
                    "lengthMenu": "Show _MENU_",
                },
                "dom": "<'row mb-3'" +
                    // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                    // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                    ">" +

                    "<'table-responsive'tr>" +

                    "<'row'" +
                    // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                    // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                    ">"
            });
        </script>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                $.ajax({
                    url: "{{ route('sales_staff') }}",
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            let select = document.getElementById('assg_staff_add');
                            select.innerHTML = ''; // Clear existing options
                            // Add the empty option
                            let defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Select Assigned Staff';
                            select.appendChild(defaultOption);
                            response.data.forEach(staff => {

                                let option = document.createElement('option');
                                option.value = staff.sno;
                                option.textContent = staff.staff_name;
                                select.appendChild(option);
                            });
                        } else {
                            let select = document.getElementById('assg_staff_add');
                            select.innerHTML = ''; // Clear existing options
                            // Add the empty option
                            let defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Select Assigned Staff';
                            select.appendChild(defaultOption);
                            //   console.error('Error fetching staff:', response);
                        }
                    },
                    error: function(error) {
                        //   console.error('Error fetching staff:', error);
                    }
                });
            });
        </script>
        {{-- date and time format script --}}
        <script>
            function formatAppointmentDate(dateString) {
                // Parse the date string
                const date = new Date(dateString);

                // Get the day, month, year, hour, and minute
                const day = String(date.getDate()).padStart(2, '0');
                const month = date.toLocaleString('default', {
                    month: 'short'
                });
                const year = date.getFullYear();
                let hour = date.getHours();
                const minute = String(date.getMinutes()).padStart(2, '0');

                // Determine AM or PM suffix
                const ampm = hour >= 12 ? 'PM' : 'AM';

                // Convert to 12-hour format and ensure two digits
                hour = String(hour % 12 || 12).padStart(2, '0'); // Convert hour 0 to 12 and ensure two digits

                // Format the final string
                return `${day}-${month}-${year} ${hour}.${minute} ${ampm}`;
            }
        </script>

        {{-- view script --}}
        <script>
            function openViewModal(val) {
                var appointment_status = val.appointment_status;
                if (appointment_status == 1) {
                    appointment_status = 'New Appointment Scheduled';
                    document.getElementById('appt_status_view').classList.add('bg-warning', 'text-black');
                    document.getElementById('appt_status_view').textContent = appointment_status;

                } else if (appointment_status == 2) {
                    appointment_status = 'Appointment Completed';
                    document.getElementById('appt_status_view').classList.add('bg-success', 'text-black');
                    document.getElementById('appt_status_view').textContent = appointment_status;
                } else if (appointment_status == 3) {
                    appointment_status = '	Appointment Cancelled';
                    document.getElementById('appt_status_view').classList.add('bg-danger', 'text-white');
                    document.getElementById('appt_status_view').textContent = appointment_status;
                } else {
                    appointment_status = 'Re-Appointment Scheduled';
                    document.getElementById('appt_status_view').classList.add('bg-info', 'text-white');
                    document.getElementById('appt_status_view').textContent = appointment_status;
                }

                // document.getElementById('appt_status_view').textContent = appointment_status;
                document.getElementById('lead_name_view').textContent = val.lead_name;
                document.getElementById('appt_category_view').textContent = val.app_cat_name;
                if (val.re_appointment_date) {
                    document.getElementById('appt_date_view').textContent = formatAppointmentDate(val.re_appointment_date);
                } else {
                    document.getElementById('appt_date_view').textContent = formatAppointmentDate(val.appointment_date);
                }

                document.getElementById('ass_staff_view').textContent = val.staffs_name;
                document.getElementById('reason_msg_view').textContent = val.appointment_reason;
                document.getElementById('comment_msg_view').textContent = val.convo_message ? val.convo_message : "-";
                document.getElementById('desc_msg_view').textContent = val.appt_desc ? val.appt_desc : "-";

            }
        </script>
        {{-- complete Appointment script --}}
        <script>
            function completeAppointment(val) {
                document.getElementById('lead_id_complete').value = val.sno;
                document.getElementById('lead_name_complete').textContent = val.lead_name;
                document.getElementById('appt_category_complete').textContent = val.app_cat_name;
                document.getElementById('appt_date_complete').textContent = formatAppointmentDate(val.appointment_date);
                document.getElementById('assg_staff_complete').textContent = val.staff_name;
                document.getElementById('reason_msg_complete').textContent = val.appointment_reason;
            }

            function completeValidateForm() {
                var err = 0;

                var pst = document.getElementById("conv_msg_positive")
                var negt = document.getElementById("conv_msg_negative")
                var neut = document.getElementById("conv_msg_neutral")

                // var hl=document.getElementById("conv_sht_msg_hl")
                // var dl=document.getElementById("conv_sht_msg_dl")
                // var ft=document.getElementById("conv_sht_msg_ft")
                // var fu=document.getElementById("conv_sht_msg_fu")
                // var fb=document.getElementById("conv_sht_msg_fp")
                // var ftl=document.getElementById("conv_sht_msg_ftl")

                if (!pst.checked && !negt.checked && !neut.checked) {
                    document.getElementById('covo_scr_err').innerHTML = ' Conversation Score(eg.postive..) is required...!';
                    err++;
                } else {
                    document.getElementById('covo_scr_err').innerHTML = '';
                }

                // if(!hl.checked && !dl.checked && !ft.checked && !fu.checked && !fb.checked && !ftl.checked){
                //   document.getElementById('lead_type_complt_err').innerHTML = 'Lead Type(eg.HL..) is required...!';
                //   err++;
                // }
                // else{
                //   document.getElementById('lead_type_complt_err').innerHTML = '';
                // }


                // return err == 0;
                return err == 0;
            }
        </script>
        {{-- cancel Appointment script --}}
        <script>
            function cancelAppointment(val) {
                document.getElementById('lead_id_cancel').value = val.sno;
                document.getElementById('lead_name_cancel').textContent = val.lead_name;
                document.getElementById('appt_category_cancel').textContent = val.app_cat_name;
                document.getElementById('appt_date_cancel').textContent = formatAppointmentDate(val.appointment_date);
                document.getElementById('assg_staff_cancel').textContent = val.staff_name;
                document.getElementById('reason_msg_cancel').textContent = val.appointment_reason;
            }

            function cancelValidateForm() {

                var err = 0;

                // Validate cancel_reason
                var cancel_reason = document.getElementById("cancel_reason").value.trim();
                if (cancel_reason === "") {
                    document.getElementById('cancel_reason_err').innerHTML = 'Cancel Reason is required...!';
                    document.getElementById('cancel_reason').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('cancel_reason').classList.remove('error_msg');
                    document.getElementById('cancel_reason_err').innerHTML = '';
                }
                return err == 0;
            }
        </script>
        {{-- Re-appointment script --}}
        <script>
            function reAppointment(val) {
                document.getElementById('lead_id_re_appt').value = val.sno;
                document.getElementById('lead_name_re_appt').textContent = val.lead_name;
                document.getElementById('appt_category_re_appt').textContent = val.app_cat_name;
                document.getElementById('appt_date_re_appt').textContent = formatAppointmentDate(val.appointment_date);
                document.getElementById('assg_staff_re_appt').textContent = val.staff_name;
                document.getElementById('reason_msg_re_appt').textContent = val.appointment_reason;
            }

            function reAppointmentValidateForm() {
                var err = 0;

                // Validate ReAppointment Date
                var ld_appt_reappt_date = document.getElementById("ld_appt_reappt_date").value.trim();
                if (ld_appt_reappt_date === "") {
                    document.getElementById('ld_appt_reappt_date_err').innerHTML = 'Re_Appointment Date is required...!';
                    document.getElementById('ld_appt_reappt_date').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('ld_appt_reappt_date').classList.remove('error_msg');
                    document.getElementById('ld_appt_reappt_date_err').innerHTML = '';
                }

                // Validate ReAppointment Reason
                var re_appt_reason = document.getElementById("re_appt_reason").value.trim();
                if (re_appt_reason === "") {
                    document.getElementById('re_appt_reason_err').innerHTML = 'Re Appointment Reason is required...!';
                    document.getElementById('re_appt_reason').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('re_appt_reason').classList.remove('error_msg');
                    document.getElementById('re_appt_reason_err').innerHTML = '';
                }
                return err == 0;
            }
        </script>
        {{-- Edit Modal script --}}
        <script>
            function openEditModal(val) {
                $.ajax({
                    url: "{{ route('department') }}",
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var selectDropdown = $('select[name="assg_dept_edit"]');
                            selectDropdown.empty();
                            selectDropdown.append($(
                                '<option value="">Select Department</option>'));
                            response.data.forEach(function(dept) {
                                selectDropdown.append($('<option></option>').attr('value', dept
                                        .sno)
                                    .text(dept.department_name));
                                if (val.department_id == dept.sno) {
                                    $('#assg_dept_edit').val(dept.sno).change();
                                }
                            });
                        }
                    },
                    error: function(error) {
                        selectDropdown.append($(
                            '<option value="">Select Department</option>'));
                        // console.error('Error fetching course Brand:', error);
                    }
                });
                $('#assg_dept_edit').on('change', function() {
                    var depart_id = this.value;

                    $.ajax({
                        url: "{{ route('sales_staff') }}",
                        type: "GET",
                        data: {
                            dept_id: depart_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                var selectDropdown = $('#assgn_staff_edit');
                                selectDropdown.empty();
                                selectDropdown.append('<option value="">Select Staff</option>');

                                response.data.forEach(function(staff) {
                                    var option = $('<option></option>')
                                        .attr('value', staff.sno)
                                        .text(staff.staff_name);

                                    if (val.staff_id === staff.sno) {
                                        option.attr('selected', 'selected');
                                    }

                                    selectDropdown.append(option);
                                });
                            }
                        },
                        error: function(error) {
                            var selectDropdown = $('#assgn_staff_edit');
                            selectDropdown.empty();
                            selectDropdown.append('<option value="">Select Staff</option>');
                            console.error('Error fetching staff:', error);
                        }
                    });

                })


                document.getElementById('ld_appt_id_edit').value = val.sno;
                document.getElementById('lead_id_edit').value = val.ld_name_id;
                document.getElementById('search_edit').value = val.lead_name + ' - ' + val.lead_id;
                document.getElementById('appt_category_edit').value = val.app_cat_name;
                document.getElementById('ld_appt_dt_edit').value = val.appointment_date;
                // document.getElementById('ass_staff_view').textContent = val.staff_name;
                document.getElementById('reason_msg_edit').value = val.appointment_reason;
                var event = new Event('change', {
                    bubbles: true,
                    cancelable: true
                });
                document.getElementById('appt_category_edit').dispatchEvent(event);
                //   console.log('before select name edit',$('#lead_id_edit').val())

            }
        </script>

        {{-- add validate --}}
        <script>
            function addvalidateForm() {
                var err = 0;

                $('#addSubmit').prop('disabled', true);
                // Validate Lead Name
                var ld_name_add = document.getElementById("lead_id_add").value.trim();
                if (ld_name_add === "") {
                    document.getElementById('search_err').innerHTML = 'Lead Name is required...!';
                    document.getElementById('lead_id_add').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('lead_id_add').classList.remove('error_msg');
                    document.getElementById('search_err').innerHTML = '';
                }
                // Validate appointment category
                var appt_catg_add = document.getElementById("appt_catg_add").value.trim();
                if (appt_catg_add === "") {
                    document.getElementById('appt_catg_add_err').innerHTML = 'Appointment Category is required...!';
                    document.getElementById('appt_catg_add').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('appt_catg_add').classList.remove('error_msg');
                    document.getElementById('appt_catg_add_err').innerHTML = '';
                }

                // Validate Appointment date
                var ld_appt_dt_add = document.getElementById("ld_appt_dt_add").value.trim();
                if (ld_appt_dt_add === "") {
                    document.getElementById('ld_appt_dt_add_err').innerHTML = 'Appointment Date is required...!';
                    document.getElementById('ld_appt_dt_add').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('ld_appt_dt_add').classList.remove('error_msg');
                    document.getElementById('ld_appt_dt_add_err').innerHTML = '';
                }

                // Validate Reason message
                var appt_reason_add = document.getElementById("appt_reason_add").value.trim();
                if (appt_reason_add === "") {
                    document.getElementById('appt_reason_add_err').innerHTML = 'Reason is required...!';
                    document.getElementById('appt_reason_add').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('appt_reason_add').classList.remove('error_msg');
                    document.getElementById('appt_reason_add_err').innerHTML = '';
                }

                // Validate Staff
                var assg_staff_add = document.getElementById("assg_staff_add").value.trim();
                if (assg_staff_add === "") {
                    document.getElementById('assg_staff_add_err').innerHTML = 'Staff is required...!';
                    document.getElementById('assg_staff_add').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('assg_staff_add').classList.remove('error_msg');
                    document.getElementById('assg_staff_add_err').innerHTML = '';
                }

                if (err == 0) {
                    $('#addLeadAppointmentForm').submit();
                } else {
                    $('#addSubmit').prop('disabled', false);
                }

            }
        </script>
        <script>
            function editvalidateForm() {
                var err = 0;
                $('#editSubmit').prop('disabled', true);
                // Validate Lead Name
                var ld_id_edit = document.getElementById("lead_id_edit").value.trim();
                var ld_name_edit = document.getElementById("search_edit").value.trim();
                if (ld_name_edit === "" || ld_id_edit === "") {
                    document.getElementById('ld_name_edit_err').innerHTML = 'Lead Name is required...!';
                    document.getElementById('search_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('search_edit').classList.remove('error_msg');
                    document.getElementById('ld_name_edit_err').innerHTML = '';
                }
                // Validate appointment category
                var appt_category_edit = document.getElementById("appt_category_edit").value.trim();
                if (appt_category_edit === "") {
                    document.getElementById('appt_category_edit_err').innerHTML = 'Appointment Category is required...!';
                    document.getElementById('appt_category_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('appt_category_edit').classList.remove('error_msg');
                    document.getElementById('appt_category_edit_err').innerHTML = '';
                }

                // Validate Appointment date
                var ld_appt_dt_edit = document.getElementById("ld_appt_dt_edit").value.trim();
                if (ld_appt_dt_edit === "") {
                    document.getElementById('ld_appt_dt_edit_err').innerHTML = 'Appointment Date is required...!';
                    document.getElementById('ld_appt_dt_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('ld_appt_dt_edit').classList.remove('error_msg');
                    document.getElementById('ld_appt_dt_edit_err').innerHTML = '';
                }

                // Validate Reason message
                var reason_msg_edit = document.getElementById("reason_msg_edit").value.trim();
                if (reason_msg_edit === "") {
                    document.getElementById('reason_msg_edit_err').innerHTML = 'Reason is required...!';
                    document.getElementById('reason_msg_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('reason_msg_edit').classList.remove('error_msg');
                    document.getElementById('reason_msg_edit_err').innerHTML = '';
                }

                // Validate Staff

                var assg_dept_edit = document.getElementById("assg_dept_edit").value.trim();
                if (assg_dept_edit === "") {
                    document.getElementById('assg_dept_edit_err').innerHTML = 'Department is required...!';
                    document.getElementById('assg_dept_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('assg_dept_edit').classList.remove('error_msg');
                    document.getElementById('assg_dept_edit_err').innerHTML = '';
                }

                var assgn_staff_edit = document.getElementById("assgn_staff_edit").value.trim();
                if (assgn_staff_edit === "") {
                    document.getElementById('assgn_staff_edit_err').innerHTML = 'Staff is required...!';
                    document.getElementById('assgn_staff_edit').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('assgn_staff_edit').classList.remove('error_msg');
                    document.getElementById('assgn_staff_edit_err').innerHTML = '';
                }

                if (err == 0) {
                    $('#editLeadAppointmentForm').submit();
                } else {
                    $('#editSubmit').prop('disabled', false);
                }


            }
        </script>
        <script>
            $(document).ready(function() {
                //lead name auto complete for add
                $('#search').on('keyup', function() {
                    var query = $(this).val();
                    // alert(query);
                    if (query.length > 2) {
                        $.ajax({
                            url: "{{ route('autocomplete_lead_name') }}",
                            type: "GET",
                            data: {
                                'term': query
                            },
                            success: function(data) {
                                //   console.log(data)
                                $('#result-list').empty().show();
                                if (data.length > 0) {
                                    $.each(data, function(index, value) {
                                        $('#result-list').append(
                                            '<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' +
                                            value.lead_name + ' - ' + value
                                            .lead_mobile +
                                            '<input type="hidden" value="' + value.sno +
                                            '" ></p>');

                                    });
                                } else {
                                    $('#search_err').html('No Record Found or Leads');
                                }
                            }
                        });
                    } else {
                        $('#result-list').hide();
                    }
                });
                // console.log('before select name',$('#lead_id_add').val())
                // Handle selection from the list
                $(document).on('click', '#result-list p', function() {
                    var selectedText = $(this).text();
                    var leadSno = $(this).find('input[type="hidden"]').val();
                    $('#search').val(selectedText);
                    $('#result-list').hide(); // Hide the list after selection
                    $('#lead_id_add').val(leadSno);
                    // console.log('after select name',$('#lead_id_add').val())

                });

                //lead name auto complete for Edit
                $('#search_edit').on('keyup', function() {
                    var query = $(this).val();
                    // alert(query);
                    if (query.length > 2) {
                        $.ajax({
                            url: "{{ route('autocomplete_lead_name') }}",
                            type: "GET",
                            data: {
                                'term': query
                            },
                            success: function(data) {
                                //   console.log(data)
                                $('#result-list_edit').empty().show();
                                if (data.length > 0) {
                                    $.each(data, function(index, value) {
                                        $('#result-list_edit').append(
                                            '<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' +
                                            value.lead_name + ' - ' + value
                                            .lead_mobile +
                                            '<input type="hidden" value="' + value.sno +
                                            '" ></p>');

                                    });
                                } else {
                                    $('#search_edit_err').html('No Record Found or Leads');
                                }
                            }
                        });
                    } else {
                        $('#result-list_edit').hide();
                    }
                });

                // Handle selection from the list
                $(document).on('click', '#result-list_edit p', function() {
                    var selectedText = $(this).text();
                    var leadSno = $(this).find('input[type="hidden"]').val();
                    $('#search_edit').val(selectedText);
                    $('#result-list_edit').hide(); // Hide the list after selection
                    $('#lead_id_edit').val(leadSno);
                    // console.log('after select name edit',$('#lead_id_edit').val())

                });


            });
        </script>
        <script>
            $('#lead_filter').click(function() {
                $('.lead_filter').slideToggle('slow');
            });

            document.getElementById('filter_form').onsubmit = function() {
                this.querySelector('button[type="submit"]').disabled = true;
            };
        </script>
        <script>
            function sort_filter(val) {
                if (val != "") {
                    $('.sorting_filter_class').val(val);
                    $('#filter_form').submit();
                } else {
                    $('.sorting_filter_class').val(10);
                    $('#filter_form').submit();
                }
            }
        </script>
        <script>
            function date_fill_issue_rpt() {
                var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
                var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
                var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
                var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
                var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
                var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
                var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
                var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
                var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

                if (dt_fill_issue_rpt == "today") {
                    today_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "week") {
                    today_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "block";
                    week_to_dt_iss_rpt.style.display = "block";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";

                    var curr = new Date; // get current date
                    var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
                    var last = first + 6; // last day is the first day + 6

                    var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
                    firstday = firstday.split("-").reverse().join("-");
                    var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
                    lastday = lastday.split("-").reverse().join("-");
                    $('#lead_week_st_dt_fill').val(firstday);
                    $('#lead_week_ed_dt_fill').val(lastday);

                } else if (dt_fill_issue_rpt == "monthly") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "block";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else if (dt_fill_issue_rpt == "custom_date") {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "block";
                    to_dt_iss_rpt.style.display = "block";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                } else {
                    today_dt_iss_rpt.style.display = "none";
                    monthly_dt_iss_rpt.style.display = "none";
                    from_dt_iss_rpt.style.display = "none";
                    to_dt_iss_rpt.style.display = "none";
                    week_from_dt_iss_rpt.style.display = "none";
                    week_to_dt_iss_rpt.style.display = "none";
                }
            }
        </script>

        <script>
            $(document).ready(function() {
                $.ajax({
                    url: "{{ route('requirement_staff_list') }}",
                    type: "GET",
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            var staffDropdown = $('#assign_staff_id');
                            staffDropdown.empty();
                            staffDropdown.append('<option value="">Select Staff</option>');
                            response.data.forEach(function(staff) {
                                if (staff.department_id === 2 && staff.role_id !== 15) {
                                    var staffName = (staff.staff_name + "-" + staff.position_name);
                                    staffDropdown.append($('<option></option>').attr('value', staff
                                        .sno).text(staffName));
                                }
                            });

                        }
                    },
                    error: function(error) {
                        console.error('Error fetching countries:', error);
                    }
                });
            });
        </script>

        <script>
            function StaffAssign(id) {
                $('#assign_requirement_id').val(id);
            }

            function StaffUpdate(id, staff_id) {
                $('#update_requirement_id').val(id);
                $('#update_staff_id').val(staff_id).trigger('change');
            }

            function assignStaffForm() {
                var err = 0;

                var assign_staff_id = document.getElementById("assign_staff_id").value.trim();
                if (assign_staff_id === "") {
                    document.getElementById('assign_staff_id_err').innerHTML = 'Staff is required...!';
                    document.getElementById('assign_staff_id').classList.add('error_msg');
                    err++;
                } else {
                    document.getElementById('assign_staff_id').classList.remove('error_msg');
                    document.getElementById('assign_staff_id_err').innerHTML = '';
                }

                if (err == 0) {
                    $('#assignSubmit').prop('disabled', true);
                    $('#assignStaffForm').submit();
                } else {
                    $('#assignSubmit').prop('disabled', false);
                }

            }
        </script>

    @endsection
