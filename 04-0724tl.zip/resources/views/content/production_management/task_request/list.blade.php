@extends('layouts/layoutMaster')

@section('title', 'Request Task')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/dropzone/dropzone.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/dropzone/dropzone.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/clipboard/clipboard.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@vite('resources/assets/js/forms-file-upload.js')
@vite('resources/assets/js/extended_ui_misc_clipboardjs.js')
@endsection
@section('content')
<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 10px !important;
    }

    .act_bx:hover {
        background-color: #eae1fc;

    }

    .act_bx_selected {
        background-color: #fbecdb !important;
        border: 1px solid #766e6e70 !important;
    }

    .profile-avatar {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        overflow: hidden;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 1rem;
        transition: all 0.25s ease-in-out;
        cursor: pointer;
    }
    .profile-avatar img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    .profile-avatar:hover {
        transform: scale(1.1);
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
    }
</style>
<!-- Task List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1">
        <div class="card-action-title">
            <h5 class="card-title mb-1">Request Task</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-1">
                    <li class="breadcrumb-item">
                        <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home-outline text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-arrow-right-thin fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                    </li>
                </ol>
            </nav>
        </div>
        <div class="card-action-element">
            <div class="d-flex justify-content-end align-items-center flex-wrap">
                <a href="javascript:;" class="btn btn-sm fw-bold text-white btn-primary me-2 mb-2" id="filter" title="Filter">
                    <i class="mdi mdi-filter-outline text-center"></i>
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="filter_tbox" style="display: none;">
            <div class="row py-1">
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Service Category</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Writing Products</option>
                        <option value="2">Developement Products</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Services</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Thesis Writing</option>
                        <option value="2">Technical Research and Development Services</option>
                        <option value="3">Formatting and Referencing</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Task</label>
                    <input type="text" class="form-control" placeholder="Enter Task Name" />
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Assigned To</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Naveen R</option>
                        <option value="2">Iswarya D</option>
                        <option value="3">Guberan J</option>
                        <option value="4">Indhumathi K</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Status</label>
                    <select class="select3 form-select">
                        <option value="" selected>All</option>
                        <option value="1">Task Not Yet Started</option>
                        <option value="2">Task In Progress</option>
                        <option value="3">Task Completed</option>
                        <option value="4">Task Delayed</option>
                        <option value="5">Task Hold</option>
                        <option value="6">Task Not Completed</option>
                        <option value="7">Task Verified</option>
                        <option value="8">Task QC Verified</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2">
                    <label class="text-black mb-1 fs-6 fw-semibold">Date</label>
                    <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                        <option value="all">All</option>
                        <option value="today">Today</option>
                        <option value="week">This Week</option>
                        <option value="monthly">This Month</option>
                        <option value="custom_date">Custom Date</option>
                    </select>
                </div>
                <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Today</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">Start Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">End Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">This Month</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="lead_this_month_dt_fill" placeholder="Select Date" class="form-control this_month_dt_fill" value="<?php echo date("M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">From Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
                <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
                    <label class="text-black mb-1 fs-6 fw-semibold">To Date</label>
                    <div class="input-group input-group-merge">
                        <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                        <input type="text" id="cus_custom_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
                    </div>
                </div>
            </div>
            <div class="d-flex align-items-center justify-content-end mt-2 mb-3">
                <button class="btn btn-secondary btn-sm me-3 waves-effect waves-light">Reset</button>
                <a href="javascript:;" class="btn btn-primary btn-sm waves-effect waves-light">Go</a>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row mb-4">
                @php $perpage_count = $perpage ? $perpage : 10; @endphp
                <div class="col-lg-2">
                    <span>Show</span>
                    <br>
                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                        onchange="sort_filter(this.value);">
                        @php
                        $options = [10, 25, 100, 500]; // Define available options
                        @endphp
                        @foreach ($options as $option)
                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected' : '' ; @endphp>
                            @php echo $option; @endphp
                        </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-lg-10 d-flex align-items-end justify-content-end">
                    <form id="search_form" method="POST" action="/production/task_request">
                        @csrf
                        <div class="d-flex align-items-center gap-2 mt-2">
                            <div>
                                <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                <input type="hidden" name="filter_on" value="0">
                                <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter"
                                    value="@php echo $perpage ? $perpage : 10; @endphp" />
                                <input type="text" class="form-control" id="search_fill" name="search_fill"
                                    value="{{ $search_fill ?? "" }}" placeholder="Enter Search" />
                            </div>
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6"
                                onclick="search_filter_func()">Search</button>
                        </div>
                    </form>
                </div>
            </div>
                <table class="table align-top table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-125px">Task</th>
                            <th class="min-w-125px">From</th>
                            <th class="min-w-80px">Journal / Id</th>
                            <th class="min-w-80px">Requested By</th>
                            <th class="min-w-80px">Assigned To</th>
                            <th class="min-w-100px">Status</th>
                            <th class="min-w-50px">Documents</th>
                            <th class="min-w-50px">Staff Documents</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-600 fw-semibold fs-7">
                        @foreach ($lists as $list)
                            <tr>
                                <td>
                                    <label class="text-black fw-semibold fs-7 text-wrap" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task">{{ $list->request_name }}</label>
                                </td>
                                <td>
                                    @if ($list->from == 0)
                                        <label class="badge bg-secondary text-white fw-semibold fs-7">Journal</label>
                                    @else
                                        <label class="badge bg-info text-white fw-semibold fs-7">Revision</label>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex flex-column">
                                        <label class="fs-7 text-black fw-semibold text-truncate " style="max-width: 200px;" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="{{ $list->paper_name }}">{{ $list->paper_name }} </label>
                                        <label class="text-info fw-semibold fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Journal ID">{{ $list->journal_id }}</label>
                                    </div>
                                </td>
                                <td>
                                    @if($list->je_image)
                                        @if ($list->je_image != '' && file_exists(public_path('staff_images/' .$list->je_image)))
                                            <div class="profile-avatar shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="JE: {{ $list->je_name }}">
                                                <img src="{{ asset('staff_images/' . $list->je_image) }}" alt="{{ $list->je_name }}">
                                            </div>
                                        @else
                                            <div class="profile-avatar bg-primary text-white shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="JE: {{ $list->je_name }}">
                                                <span>{{ strtoupper(substr($list->je_name, 0, 1)) }}</span>
                                            </div>
                                        @endif
                                    @else
                                        <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Coordinator">
                                            <i class="mdi mdi-account-off fs-5"></i>
                                        </div>
                                    @endif
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-4">
                                            <!-- Journal Coordinator -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if($list->pc_image)
                                                    @if ($list->pc_image != '' && file_exists(public_path('staff_images/' .$list->pc_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="PC: {{ $list->pc_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->pc_image) }}" alt="{{ $list->pc_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-primary text-white shadow-sm border border-2 border-primary" data-bs-toggle="tooltip" title="PC: {{ $list->pc_name }}">
                                                            <span>{{ strtoupper(substr($list->pc_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Coordinator">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">PC</small>
                                            </div>

                                            <!-- Journal Staff -->
                                            <div class="d-flex flex-column align-items-center position-relative">
                                                @if($list->pro_image)
                                                    @if ($list->pro_image != '' && file_exists(public_path('staff_images/' .$list->pro_image)))
                                                        <div class="profile-avatar shadow-sm border border-2 border-success" data-bs-toggle="tooltip" title="Staff: {{ $list->pro_name }}">
                                                            <img src="{{ asset('staff_images/' . $list->pro_image) }}" alt="{{ $list->pro_name }}">
                                                        </div>
                                                    @else
                                                        <div class="profile-avatar bg-success text-white shadow-sm border border-2 border-success" data-bs-toggle="tooltip" title="Staff: {{ $list->pro_name }}">
                                                            <span>{{ strtoupper(substr($list->pro_name, 0, 1)) }}</span>
                                                        </div>
                                                    @endif
                                                @else
                                                    <div class="profile-avatar bg-light text-muted border" data-bs-toggle="tooltip" title="No Staff">
                                                        <i class="mdi mdi-account-off fs-5"></i>
                                                    </div>
                                                @endif
                                                <small class="text-muted mt-1 fw-medium">Staff</small>
                                            </div>

                                        </div>
                                </td>
                                <td>
                                    @if ($list->status == 0)
                                        <a class="cursor-pointer badge bg-info text-black fs-7 fw-semibold" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color: #FFA500 !important;">
                                            <span>Task Requested</span>
                                            <span class="ms-2"><i class="mdi mdi-menu-down text-black"></i></span>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-start">
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_task" onclick="taskRequestDataFetch('{{ $list->sno }}', 'Accept')">Approve</a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_task" onclick="taskRequestDataFetch('{{ $list->sno }}', 'Reject')">Reject</a>
                                        </div>
                                    @elseif ($list->status == 1)
                                        <a class="cursor-pointer badge bg-info text-white fs-7 fw-semibold" style="background-color: #7549bd !important;" data-bs-toggle="modal" data-bs-target="#kt_modal_approve_task" onclick="taskRequestDataFetch('{{ $list->sno }}', 'Assign Staff')">
                                            <span>Assign Staff</span>
                                            <span class="ms-2"><i class="mdi mdi-menu-right text-white"></i></span>
                                        </a>
                                    @elseif ($list->status == 3)
                                        <a class="cursor-pointer badge bg-info text-white fs-7 fw-semibold"  style="background-color: #ff0000 !important;">
                                            <span>Rejected</span>
                                        </a>
                                    @elseif ($list->status == 4)
                                        <a class="cursor-pointer badge bg-info text-black fs-7 fw-semibold"  style="background-color: #75e25ae1 !important;">
                                            <span>Staff Assigned</span>
                                        </a>
                                    @elseif ($list->status == 5)
                                        <a href="javascript:;" class="badge bg-warning text-black mb-1 fs-7 fw-semibold">
                                        <span>In Progress</span>
                                        </a>

                                    <!-- Waiting For Documents Upload -->
                                    @elseif ($list->status == 6)
                                        <a href="javascript:;" class="badge text-black mb-1 fs-7 fw-semibold" style="background: #4fcdd1;">
                                            <span>Waiting For Documents</span>
                                        </a>

                                    @elseif ($list->status == 7)
                                        <a href="javascript:;" class="badge text-white mb-1 fs-7 fw-semibold" style="background: #005800;">
                                            <span>Completed</span>
                                        </a>
                                    @endif
                                </td>
                                @php
                                    $isDocuments = false;
                                    $isStaffDocuments = false;

                                    $documents = [];
                                    $visibleDocuments = [];

                                    if (!empty($list->drive_link)) {
                                        $documents = json_decode($list->drive_link, true);

                                        $visibleDocuments = array_filter($documents, function ($doc) {
                                            return !isset($doc['productionStaff']) || $doc['productionStaff'] != 1;
                                        });
                                    }

                                    $isDocuments = !empty($visibleDocuments);

                                    // Parse staff documents
                                    $staffDocuments = [];
                                    if (!empty($list->staff_documents)) {
                                        $staffDocuments = json_decode($list->staff_documents, true);
                                        $isStaffDocuments = !empty($staffDocuments);
                                    }

                                    $helper = new \App\Helpers\Helpers();
                                @endphp
                                <td>
                                    @if($isDocuments && !empty($visibleDocuments))
                                        <div class="dropdown position-relative">
                                            <button class="btn btn-outline-primary btn-sm dropdown-toggle d-flex align-items-center"
                                                    type="button"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="false">
                                                <i class="mdi mdi-tray-arrow-down me-2"></i>
                                            </button>
                                            @if(count($visibleDocuments) > 1)
                                                <span class="badge bg-danger rounded-circle  position-absolute" style="top: -9px;right: 0px;">
                                                    {{ count($visibleDocuments) }}
                                                </span>
                                            @endif
                                            <ul class="dropdown-menu">
                                                @foreach($visibleDocuments as $index => $document)
                                                    @php
                                                        $driveLink = "https://drive.google.com/uc?id=" . $document['drive_file_id'] . "&export=download";
                                                        $fileName = $document['name'] ?? 'document_' . ($index + 1);
                                                        $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
                                                        $iconClass = $helper->getFileIcon($fileExtension); // You'll need to implement this method
                                                    @endphp
                                                    <li>
                                                        <a class="dropdown-item" href="{{ $driveLink }}" target="_blank">
                                                            <i class="{{ $iconClass }} me-2"></i>
                                                            {{ $fileName }}
                                                            <small class="text-muted d-block">Click to download</small>
                                                        </a>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @else
                                        <img src="{{ asset('assets/phdizone_images/newmultiply.png') }}"
                                            alt="avatar"
                                            class="rounded-circle img-fluid"
                                            style="width: 40px; height: 40px; object-fit: cover;"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="No Documents Uploaded">
                                    @endif
                                </td>
                                <td>
                                    @if($isStaffDocuments && !empty($staffDocuments))
                                        <div class="dropdown ms-5">
                                            <button class="btn btn-outline-info btn-sm dropdown-toggle d-flex align-items-center"
                                                    type="button"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="false">
                                                <i class="mdi mdi-tray-arrow-down me-2"></i>
                                                @if(count($staffDocuments) > 1)
                                                    <span class="badge bg-danger ms-2">
                                                        {{ count($staffDocuments) }}
                                                    </span>
                                                @endif
                                            </button>
                                            <ul class="dropdown-menu">
                                                @foreach($staffDocuments as $index => $document)
                                                    @php
                                                        $driveLink = "https://drive.google.com/uc?id=" . $document['drive_file_id'] . "&export=download";
                                                        $fileName = $document['name'] ?? 'document_' . ($index + 1);
                                                        $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);
                                                        $iconClass = $helper->getFileIcon($fileExtension); // You'll need to implement this method
                                                    @endphp
                                                    <li>
                                                        <a class="dropdown-item" href="{{ $driveLink }}" target="_blank">
                                                            <i class="{{ $iconClass }} me-2"></i>
                                                            {{ $fileName }}
                                                            <small class="text-muted d-block">Click to download</small>
                                                        </a>
                                                    </li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    @else
                                        <img src="{{ asset('assets/phdizone_images/newmultiply.png') }}"
                                            alt="avatar"
                                            class="rounded-circle img-fluid ms-5"
                                            style="width: 40px; height: 40px; object-fit: cover;"
                                            data-bs-toggle="tooltip"
                                            data-bs-placement="bottom"
                                            title="No Documents Uploaded">
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                {{ $lists->appends(request()->except(['page', '_token']))->links() }}
            </div>
        </div>
    </div>
</div>


<!--begin::Modal - Task Approve-->
<div class="modal fade" id="kt_modal_approve_task" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black" id="requestHeader">Task Approve</h3>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-4 d-flex flex-column">
                        <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name" id="requestCusName">-</div>
                        <div>
                            <span class="text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Id" id="requestCustomerId">-</span>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 d-flex align-items-center justify-content-start gap-2">
                        <img
                            src="{{ asset('assets/phdizone_images/user_3.png') }}"
                            alt="avatar"
                            class="rounded-circle img-fluid border border-secondary border-2 shadow"
                            style="width: 50px; height: 50px; object-fit: cover;"
                        >
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name" id="requestJEName">-</div>
                            <div class="text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Position">
                                Journal Executive
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <span class="badge bg-secondary text-white fw-semibold fs-6">Journal</span>
                    </div>
                    <div class="col-lg-12 mb-4 d-flex align-items-center justify-content-start gap-2">
                        <span class="badge bg-gray-200 rounded-circle p-2">
                            <i class="mdi mdi-list-status fs-2 text-black"></i>
                        </span>
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task Name" id="requestTaskName">-</div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-4 d-flex align-items-center bg-gray-200 rounded justify-content-start gap-2 p-4">
                        <span class="badge bg-white rounded-circle p-2">
                            <i class="mdi mdi-newspaper-variant-outline fs-1 text-black"></i>
                        </span>
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal Name" id="requestJournalName">-</div>
                            <div class="text-dark fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal Id" id="requestJournalId">
                                -
                            </div>
                        </div>
                    </div>
                    <div id="acceptContainer" class="d-none">
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assign PC<span class="text-danger">*</span></label>
                            <select class="select3 form-select" id="pc_id">
                            </select>
                            <div id="pc_id_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                        </div>
                    </div>
                    <div id="rejectContainer" class="d-none">
                        <div class="col-lg-12 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Reason<span class="text-danger">*</span></label>
                            <textarea class="form-control" rows="4" placeholder="Enter Reason" id="rejectReason"></textarea>
                            <div id="rejectReasonErr" class="text-danger mt-2 fs-7 fw-semibold"></div>
                        </div>
                    </div>
                    <div id="assignStaffContainer" class="d-none">
                        <div class="col-lg-12 mb-4">
                            <label class="text-black mb-1 fs-6 fw-semibold">Assign Staff<span class="text-danger">*</span></label>
                            <select class="select3 form-select" id="staff_id">
                            </select>
                            <div id="staff_id_err" class="text-danger mt-2 fs-7 fw-semibold"></div>
                        </div>
                    </div>
               </div>
                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" onclick="taskValidation()" id="requesttaskBtn" class="btn btn-primary">Yes</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Task Approve-->

<!--begin::Modal - Assign Staff-->
<div class="modal fade" id="kt_modal_assign_staff" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Assign Staff</h3>
                </div>
                <input type="hidden" name="" id="taskRequHidId">
                <input type="hidden" name="" id="taskRequHidStatus">
                <div class="row">
                  <div class="col-lg-4 mb-4 d-flex flex-column">
                        <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Name">Sathish kumar</div>
                        <div>
                            <span class="text-dark fw-semibold fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Customer Id">CUS-00004/06/2025</span>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4 d-flex align-items-center justify-content-start gap-2">
                        <img
                            src="{{ asset('assets/phdizone_images/user_3.png') }}"
                            alt="avatar"
                            class="rounded-circle img-fluid border border-secondary border-2 shadow"
                            style="width: 50px; height: 50px; object-fit: cover;"
                        >
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Name">Ram Chandar</div>
                            <div class="text-dark fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Staff Position">
                                Journal Executive
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-2">
                        <span class="badge bg-secondary text-white fw-semibold fs-6" id="requestBadge">-</span>
                    </div>
                    <div class="col-lg-12 mb-4 d-flex align-items-center justify-content-start gap-2">
                        <span class="badge bg-gray-200 rounded-circle p-2">
                            <i class="mdi mdi-list-status fs-2 text-black"></i>
                        </span>
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task Name">Acknowledge Format Change</div>
                            <div class="text-dark fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Task Id">
                                TSK-0045/26
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-4 d-flex align-items-center bg-gray-200 rounded justify-content-start gap-2 p-4">
                        <span class="badge bg-white rounded-circle p-2">
                            <i class="mdi mdi-newspaper-variant-outline fs-1 text-black"></i>
                        </span>
                        <div class="d-flex flex-column">
                            <div class="text-black fs-6 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal Name">Ssda_aoa: Stacked Sparse Denoising Autoencoder With Archimedes Optimization Algorithm Based Oral Cancer Detection On Histopathological Images</div>
                            <div class="text-dark fs-7 fw-semibold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Journal Id">
                                JOR2178/2025
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-4">
                        <label class="text-black mb-1 fs-6 fw-semibold">Assign Staff<span class="text-danger">*</span></label>
                        <select class="select3 form-select">
                            <option value="">Select Staff</option>
                            <option value="1" >Harini</option>
                            <option value="2">Sesha Anand</option>
                        </select>
                    </div>
               </div>

                <div class="d-flex justify-content-center align-items-center mt-8">
                    <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                    <a href="javascript:;" class="btn btn-primary"  data-bs-dismiss="modal">Assign Staff</a>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Assign Staff-->

{{-- Toastr Starts --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>

    .circular-badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 50px;
        height: 50px;
        border-radius: 50%;
        transition: all 0.3s ease;
        cursor: pointer;
    }

    .circular-badge:hover {
        transform: scale(1.1);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    }

    .bg-purple { background-color: #800080 !important; }

    /* Customize Toastr container */
    .toast {
        background-color: #313f46;
    }

    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .error_msg {
        border: solid 2px red !important;
        border-color: red !important;
    }
</style>
<script>
    // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
</script>
{{-- Toastr Ends --}}


<script>
    $('#filter').click(function() {
        $('.filter_tbox').slideToggle('slow');
    });
</script>
<script>
    function date_fill_issue_rpt() {
        var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
        var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
        var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
        var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
        var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
        var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
        var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
        var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
        var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

        if (dt_fill_issue_rpt == "today") {
            today_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "week") {
            today_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "block";
            week_to_dt_iss_rpt.style.display = "block";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";

            var curr = new Date; // get current date
            var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
            var last = first + 6; // last day is the first day + 6

            var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
            firstday = firstday.split("-").reverse().join("-");
            var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
            lastday = lastday.split("-").reverse().join("-");
            $('#week_from_date_fil').val(firstday);
            $('#week_to_date_fil').val(lastday);

        } else if (dt_fill_issue_rpt == "monthly") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "block";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else if (dt_fill_issue_rpt == "custom_date") {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "block";
            to_dt_iss_rpt.style.display = "block";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        } else {
            today_dt_iss_rpt.style.display = "none";
            monthly_dt_iss_rpt.style.display = "none";
            from_dt_iss_rpt.style.display = "none";
            to_dt_iss_rpt.style.display = "none";
            week_from_dt_iss_rpt.style.display = "none";
            week_to_dt_iss_rpt.style.display = "none";
        }
    }
</script>

{{-- <script>
    $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script> --}}

<!-- Task Request -->
<script>
    function taskRequestDataFetch(sno, status) {
        if (!sno || status === undefined || status === null) return;

        $('#taskRequHidId').val(sno);
        $('#taskRequHidStatus').val(status);

        $.ajax({
            url: `/get_task_request/${sno}`,
            type: 'GET',
            success: function (response) {
                if (response.status === 200) {
                    const data = response.data;

                    if (status == 'Accept') {
                        $('#requestHeader').html('Task Approve');
                        $('#acceptContainer').removeClass('d-none');
                        fetchPC();
                        $('#rejectContainer, #assignStaffContainer').addClass('d-none');
                        $('#requesttaskBtn').html('Accept');
                    } else if (status == 'Reject') {
                        $('#requestHeader').html('Task Reject');
                        $('#acceptContainer, #assignStaffContainer').addClass('d-none');
                        $('#rejectContainer').removeClass('d-none');
                        $('#requesttaskBtn').html('Reject');
                    } else if (status == 'Assign Staff') {
                        $('#requestHeader').html('Assign Staff');
                        $('#acceptContainer, #rejectContainer').addClass('d-none');
                        $('#assignStaffContainer').removeClass('d-none');
                        $('#requesttaskBtn').html('Assign Staff');
                        fetchProductionStaffs();
                    }

                    $('#requestCusName').html(data.cus_name);
                    $('#requestCustomerId').html(data.customer_id);
                    $('#requestJEName').html(data.je_name);
                    $('#requestTaskName').html(data.request_name);
                    $('#requestJournalName').html(data.paper_name);
                    $('#requestJournalId').html(data.journal_id);

                    if (data.from == 0) {
                        $('#requestBadge').html("Journal");
                    } else if (data.from  == 1) {
                        $('#requestBadge').html("Revision");
                    }
                }
            },
            error: function () {
                console.error('Servor Error !');
            }
        });
    }

    function fetchPC() {
        $.ajax({
            url: `/get_allocate_pc`,
            type: 'GET',
            success: function (response) {
                if (response.status === 200) {
                    const container = $('#pc_id');

                    container.empty().append('<option value="">Select PC</option>');

                    response.data.forEach(pc => {
                        container.append(`<option value="${pc.sno}">${pc.staff_name}</option>`);
                    });
                }
            },
            error: function (err) {
                console.error('Servor Error !');
            }
        });
    }

    function fetchProductionStaffs() {
        $.ajax({
            url: `/production_staff_data_fetch`,
            type: 'GET',
            success: function (response) {
                if (response.status === 200) {
                    const container = $('#staff_id');

                    container.empty().append('<option value="">Select Staff</option>');

                    response.data.forEach(pc => {
                        container.append(`<option value="${pc.sno}">${pc.staff_name}</option>`);
                    });
                }
            },
            error: function (err) {
                console.error('Servor Error !');
            }
        });
    }

    function taskValidation() {
        const id = $('#taskRequHidId').val();
        const status = $('#taskRequHidStatus').val();
        const formData = new FormData();

        if (status === 'Accept') {
            const pcId = $('#pc_id').val();

            $('#pc_id_err').text('');

            if (!pcId) {
                $('#pc_id_err').text('PC is required.');
                return false;
            }

            formData.append('pc_id', pcId);
            formData.append('temp_status', 0);
        } else if (status === 'Reject') {
            const reason = $('#rejectReason').val();

            $('#rejectReasonErr').text('');

            if (!reason) {
                $('#rejectReasonErr').text('Reason is required.');
                return false;
            }

            formData.append('reason', reason);
            formData.append('temp_status', 1);
        } else if (status === 'Assign Staff') {
            const staffId = $('#staff_id').val();

            $('#staff_id_err').text('');

            if (!staffId) {
                $('#staff_id_err').text('Staff is required.');
                return false;
            }

            formData.append('staff_id', staffId);
            formData.append('temp_status', 2);
        }

        $.ajax({
            url: `/task_request_add/${id}`,
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                if (response.status == 200) {
                    if (status === 'Accept') {
                        toastr.success('Task Approved Successfully !');
                    }

                    location.reload();
                }
            },
            error: function () {
                console.error('Servor Error !');
            }
        });
    }
</script>

<!-- SORTING FILTER -->
<script>
    function sort_filter(val) {
        if (val != "") {
            $('.sorting_filter_class').val(val);
            $('#search_form').submit();
        } else {
            $('.sorting_filter_class').val(10);
            $('#search_form').submit();
        }
    }
</script>
@endsection
