{{-- resources/views/task-calendar/index.blade.php --}}
@extends('layouts/layoutMaster')

@section('title', 'Task Calendar')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/moment/moment.js'])
@endsection


@section('content')
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay d-none">
        <div class="loading-content">
            <div class="spinner-grow text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-3 text-light">Loading Task calendar...</p>
        </div>
    </div>

    <!-- Main Container -->
    <div class="container-fluid px-0">
        <!-- Header -->
        <div class="header-section py-4 px-4">
            <div
                class="d-flex flex-column flex-lg-row justify-content-between align-items-start align-items-lg-center gap-3">
                <div>
                    <div class="d-flex align-items-center gap-3 mb-2">
                        <div class="header-icon">
                            <i class="mdi mdi-calendar-multiple"></i>
                        </div>
                        <div>
                            <h1 class="header-title mb-0">Task Calendar</h1>
                            <p class="text-muted mb-0">Organize and track your daily workflow</p>
                        </div>
                    </div>
                </div>

                <div class="date-nav-buttons" id="date_filter_header" style="display:block;">
                    <button class="nav-btn secondary" id="prevDay">
                        <i class="mdi mdi-chevron-left"></i>
                        <span>Yesterday</span>
                    </button>
                    <button class="nav-btn primary" id="todayBtn">
                        <i class="mdi mdi-calendar-today"></i>
                        <span>Today</span>
                    </button>
                    <button class="nav-btn secondary" id="nextDay">
                        <span>Tomorrow</span>
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>

                <div class="month-nav" id="month_filter_header" style="display: none;">
                    <button class="nav-btn secondary" id="prevMonth">
                        <i class="mdi mdi-chevron-left"></i>
                        <span>Previous</span>
                    </button>
                    <h2 class="month-title mb-0" id="currentMonthDisplay">
                        {{ \Carbon\Carbon::create($year, $month, 1)->format('F Y') }}
                    </h2>
                    <button class="nav-btn secondary" id="nextMonth">
                        <span>Next</span>
                        <i class="mdi mdi-chevron-right"></i>
                    </button>
                </div>

                <div class="d-flex flex-wrap align-items-center gap-3">
                    <!-- View Toggle -->
                    <div class="view-toggle">
                        <button class="view-btn active" data-view="daily">
                            <i class="mdi mdi-view-day"></i>
                            <span>Daily</span>
                        </button>
                        <button class="view-btn" data-view="monthly">
                            <i class="mdi mdi-view-month"></i>
                            <span>Monthly</span>
                        </button>
                    </div>

                    <!-- Date Controls -->
                    <div class="date-controls d-flex align-items-center gap-2">
                        <div class="date-picker-container" id="datePickerContainer">
                            <div class="date-picker-wrapper">
                                <i class="mdi mdi-calendar"></i>
                                <input type="text" class="date-picker-input" id="taskDatePicker"
                                    value="{{ $date }}">
                            </div>
                        </div>

                        <div class="date-picker-container" id="monthPickerContainer" style="display: none;">
                            <div class="date-picker-wrapper">
                                <i class="mdi mdi-calendar-month"></i>
                                <input type="text" class="date-picker-input" id="taskMonthPicker"
                                    value="{{ $year }}-{{ str_pad($month, 2, '0', STR_PAD_LEFT) }}">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Area -->
        <div class="content-section">
            <!-- Daily View -->
            <div id="dailyViewContainer" class="view-container active" style="display: block;">
                <!-- Date Navigation -->
                {{-- <div class="date-navigation-section mb-5">
                <div class="d-flex flex-column flex-lg-row justify-content-between align-items-center gap-4">
                    
                    
                    <div class="date-display text-center">
                        <h2 class="current-date mb-2" id="currentDateDisplay">
                            {{ \Carbon\Carbon::parse($date)->format('l, F j, Y') }}
                        </h2>
                        <div class="date-meta">
                            <span class="meta-item">
                                <i class="mdi mdi-clock-outline"></i>
                                <span id="totalHoursDay">0</span> hours total
                            </span>
                            <span class="meta-divider">•</span>
                            <span class="meta-item">
                                <i class="mdi mdi-checkbox-multiple-outline"></i>
                                <span id="taskCountDay">0</span> tasks
                            </span>
                        </div>
                    </div>
                </div>
            </div> --}}

                <!-- Stats Cards -->
                <div class="row g-4 mb-5" id="dailyStats">
                    <!-- Stats will be loaded here -->
                </div>

                <!-- Tasks Section -->
                <div class="tasks-section">
                    <div class="section-header mb-4">
                        <h3 class="section-title">
                            <i class="mdi mdi-format-list-checkbox"></i>
                            Today's Schedule
                        </h3>
                    </div>

                    <!-- Tasks Grid -->
                    <div class="tasks-grid" id="dailyTasksContainer">
                        <!-- Tasks will be loaded here -->
                    </div>

                    <!-- Empty State -->
                    <div class="empty-state d-none" id="emptyStateDaily">
                        <div class="empty-state-content">
                            <div class="empty-state-icon">
                                <i class="mdi mdi-calendar-blank"></i>
                            </div>
                            <h4>No tasks scheduled</h4>
                            <p class="text-muted">Add new tasks or check other dates to see your schedule</p>
                            <div class="empty-state-actions">
                                <button class="btn btn-outline" onclick="goToToday()">
                                    <i class="mdi mdi-calendar-today"></i>
                                    Go to Today
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Monthly View -->
            <div id="monthlyViewContainer" class="view-container" style="display: none;">

                <!-- Monthly Stats -->
                <div class="row g-4 mb-5" id="monthlyStats">
                    <!-- Stats will be loaded here -->
                </div>

                <!-- Calendar Grid -->
                <div class="calendar-grid-container">
                    <div class="calendar-grid-header">
                        @php
                            $weekDays = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
                        @endphp
                        @foreach ($weekDays as $day)
                            <div class="weekday-header">{{ $day }}</div>
                        @endforeach
                    </div>

                    <div class="calendar-grid" id="monthlyCalendar">
                        <!-- Calendar will be loaded here -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modern CSS -->
    <style>
        /* Modern Variables */
        :root {
            --primary: #696cff;
            --primary-light: #8592ff;
            --primary-dark: #5459d4;
            --secondary: #6d788d;
            --success: #28c76f;
            --warning: #ff9f43;
            --danger: #ea5455;
            --info: #00cfe8;
            --dark: #283046;
            --light: #f8f9fa;
            --gray: #b4b7bd;
            --border: #d9dee3;
            --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            --glass: rgba(255, 255, 255, 0.9);
            --blur: blur(20px);
        }

        /* Base Styles */
        body {
            background: linear-gradient(135deg, #f5f7ff 0%, #f0f2ff 100%);
            min-height: 100vh;
        }

        /* Header Section */
        .header-section {
            background: #fff;
            backdrop-filter: var(--blur);
            border-bottom: 1px solid rgba(255, 255, 255, 0.8);
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .header-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }

        .header-title {
            font-weight: 700;
            color: #000;
            font-size: 1.75rem;
        }

        /* View Toggle */
        .view-toggle {
            display: flex;
            background: rgba(105, 108, 255, 0.1);
            border-radius: 12px;
            padding: 4px;
        }

        .view-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: transparent;
            border: none;
            border-radius: 8px;
            color: var(--secondary);
            font-weight: 500;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .view-btn.active {
            background: white;
            color: var(--primary);
            box-shadow: 0 2px 8px rgba(105, 108, 255, 0.2);
        }

        .view-btn:hover:not(.active) {
            background: rgba(255, 255, 255, 0.5);
        }

        /* Date Picker */
        .date-picker-container {
            position: relative;
        }

        .date-picker-wrapper {
            background: white;
            border-radius: 12px;
            padding: 10px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
        }

        .date-picker-wrapper:hover {
            border-color: var(--primary);
            box-shadow: 0 4px 12px rgba(105, 108, 255, 0.1);
        }

        .date-picker-wrapper i {
            color: var(--primary);
        }

        .date-picker-input {
            border: none;
            background: transparent;
            color: var(--dark);
            font-weight: 500;
            width: 120px;
            outline: none;
        }

        /* Content Section */
        .content-section {
            padding: 30px;
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Date Navigation */
        .date-navigation-section {
            background: var(--glass);
            backdrop-filter: var(--blur);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
        }

        .nav-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 12px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .nav-btn.primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
            box-shadow: 0 4px 12px rgba(105, 108, 255, 0.3);
        }

        .nav-btn.primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(105, 108, 255, 0.4);
        }

        .nav-btn.secondary {
            background: white;
            color: var(--dark);
            border: 1px solid var(--border);
        }

        .nav-btn.secondary:hover {
            border-color: var(--primary);
            color: var(--primary);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }

        /* Date Display */
        .date-display {
            background: white;
            padding: 20px 40px;
            border-radius: 16px;
            box-shadow: var(--shadow);
        }

        .current-date {
            font-weight: 700;
            color: var(--dark);
            font-size: 1.75rem;
        }

        .date-meta {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--secondary);
        }

        .meta-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.875rem;
        }

        .meta-divider {
            color: var(--gray);
        }

        /* Stats Cards */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin: 20px 0;
        }

        .stat-card {
            padding: 20px;
            border-radius: 12px;
            text-align: center;
            color: white;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .stat-card-total-tasks {
            background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        }

        .stat-card-total-hours {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        }

        .stat-card-pending-tasks {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        }

        .stat-card-completed {
            background: linear-gradient(135deg, #f97316 0%, #ec4899 100%);
        }

        .stat-label {
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.9;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            line-height: 1.2;
        }

        .stat-unit {
            font-size: 0.875rem;
            margin-top: 5px;
            opacity: 0.9;
        }

        /* Tasks Section */
        .tasks-section {
            background: var(--glass);
            backdrop-filter: var(--blur);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .section-title {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.5rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .action-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 10px;
            border: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .action-btn.primary {
            background: linear-gradient(135deg, var(--primary), var(--primary-light));
            color: white;
        }

        .action-btn.outline {
            background: transparent;
            border: 1px solid var(--border);
            color: var(--dark);
        }

        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        /* Task Cards */
        :root {
            --joy-primary: #6366f1;
            --joy-primary-light: #818cf8;
            --joy-primary-lighter: #e0e7ff;
            --joy-secondary: #64748b;
            --joy-secondary-light: #94a3b8;
            --joy-success: #10b981;
            --joy-warning: #f59e0b;
            --joy-danger: #ef4444;
            --joy-bg: #ffffff;
            --joy-surface: #f8fafc;
            --joy-border: #e2e8f0;
            --joy-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
            --joy-shadow-hover: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        }

        /* Card Container */
        .joy-task-card {
            background: var(--joy-bg);
            border-radius: 16px;
            border: 1px solid var(--joy-border);
            box-shadow: var(--joy-shadow);
            transition: all 0.3s ease;
            overflow: hidden;
            max-width: 400px;
        }

        .joy-task-card:hover {
            box-shadow: var(--joy-shadow-hover);
            border-color: var(--joy-primary-light);
            transform: translateY(-2px);
        }

        /* Card Header */
        .card-header {
            padding: 24px 24px 16px;
            background: linear-gradient(135deg, var(--joy-surface) 0%, transparent 100%);
            border-bottom: 1px solid var(--joy-border);
        }

        .staff-section {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .staff-avatar {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .avatar-wrapper {
            position: relative;
            width: 56px;
            height: 56px;
        }

        .avatar-image {
            width: 100%;
            height: 100%;
            border-radius: 12px;
            object-fit: cover;
            border: 3px solid white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .status-indicator {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: var(--joy-success);
            border: 2px solid white;
        }

        .status-indicator.online {
            background: var(--joy-success);
        }

        .status-indicator.offline {
            background: var(--joy-secondary-light);
        }

        .staff-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }

        .staff-name {
            margin: 0;
            font-size: 1.125rem;
            font-weight: 600;
            color: #1e293b;
            line-height: 1.2;
        }

        .staff-role {
            font-size: 0.875rem;
            color: var(--joy-secondary);
            font-weight: 500;
        }

        .task-badge {
            background: var(--joy-primary-lighter);
            color: var(--joy-primary);
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .badge-text {
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .badge-text::before {
            content: '';
            width: 6px;
            height: 6px;
            background: var(--joy-primary);
            border-radius: 50%;
        }

        /* Card Body */
        .card-body {
            padding: 24px;
        }

        .task-details {
            display: flex;
            flex-direction: column;
            gap: 24px;
        }

        /* Detail Items */
        .detail-group {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--joy-border);
        }

        .detail-item:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }

        .detail-label {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--joy-secondary);
            font-size: 0.875rem;
            font-weight: 500;
            min-width: 120px;
        }

        .detail-label i {
            width: 20px;
            text-align: center;
            color: var(--joy-primary);
        }

        .detail-value {
            text-align: right;
            color: #1e293b;
            font-weight: 500;
            font-size: 0.95rem;
            line-height: 1.4;
        }

        .detail-value.task-id {
            background: var(--joy-surface);
            padding: 4px 12px;
            border-radius: 8px;
            font-family: 'SF Mono', Monaco, monospace;
            font-size: 0.85rem;
            color: var(--joy-primary);
            font-weight: 600;
            border: 1px solid var(--joy-primary-lighter);
        }

        .detail-value.customer-id {
            font-family: 'SF Mono', Monaco, monospace;
            font-size: 0.85rem;
            color: var(--joy-secondary);
        }

        /* Metrics Section */
        .metrics-group {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
            background: var(--joy-surface);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid var(--joy-border);
        }

        .metric-card {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: white;
            border-radius: 10px;
            border: 1px solid var(--joy-border);
            transition: all 0.2s ease;
        }

        .metric-card:hover {
            border-color: var(--joy-primary-light);
            transform: translateY(-1px);
        }

        .metric-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            color: white;
        }

        .metric-icon.hours {
            background: linear-gradient(135deg, var(--joy-primary) 0%, var(--joy-primary-light) 100%);
        }

        .metric-icon.pages {
            background: linear-gradient(135deg, var(--joy-success) 0%, #34d399 100%);
        }

        .metric-content {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .metric-value {
            font-size: 1.25rem;
            font-weight: 700;
            color: #1e293b;
            line-height: 1;
        }

        .metric-label {
            font-size: 0.75rem;
            color: var(--joy-secondary);
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* Card Footer - Assigned Staff */
        .card-footer {
            padding: 20px 24px;
            background: var(--joy-surface);
            border-top: 1px solid var(--joy-border);
        }

        .assigned-staff {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .section-title {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--joy-secondary);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .section-title i {
            color: var(--joy-primary);
        }

        .staff-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }

        .staff-tag {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: white;
            border: 1px solid var(--joy-border);
            border-radius: 8px;
            font-size: 0.875rem;
            color: #1e293b;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .staff-tag:hover {
            border-color: var(--joy-primary-light);
            background: var(--joy-primary-lighter);
        }

        .staff-tag.more {
            background: var(--joy-primary-lighter);
            color: var(--joy-primary);
            border: none;
            font-weight: 600;
        }

        .tag-avatar {
            width: 24px;
            height: 24px;
            border-radius: 6px;
            background: linear-gradient(135deg, var(--joy-primary) 0%, var(--joy-primary-light) 100%);
            color: white;
            font-size: 0.75rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Card Actions */
        .card-actions {
            padding: 20px 24px;
            display: flex;
            gap: 12px;
            border-top: 1px solid var(--joy-border);
            background: white;
        }

        .action-btn {
            flex: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 10px 16px;
            border-radius: 10px;
            border: none;
            font-size: 0.875rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .action-btn.view-btn {
            background: var(--joy-surface);
            color: var(--joy-secondary);
            border: 1px solid var(--joy-border);
        }

        .action-btn.edit-btn {
            background: var(--joy-primary);
            color: white;
        }

        .action-btn:hover {
            transform: translateY(-1px);
        }

        .action-btn.view-btn:hover {
            background: white;
            border-color: var(--joy-primary-light);
            color: var(--joy-primary);
        }

        .action-btn.edit-btn:hover {
            background: var(--joy-primary-light);
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.2);
        }

        /* Responsive */
        @media (max-width: 480px) {

            .card-header,
            .card-body,
            .card-footer,
            .card-actions {
                padding: 20px;
            }

            .staff-section {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }

            .metrics-group {
                grid-template-columns: 1fr;
            }

            .detail-item {
                flex-direction: column;
                align-items: flex-start;
                gap: 4px;
            }

            .detail-value {
                text-align: left;
            }
        }

        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .joy-task-card {
            animation: fadeIn 0.3s ease-out;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }

        .empty-state-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, rgba(105, 108, 255, 0.1), rgba(133, 146, 255, 0.1));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 36px;
            color: var(--primary);
        }

        .empty-state h4 {
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 12px;
        }

        .empty-state-actions {
            display: flex;
            gap: 12px;
            justify-content: center;
            margin-top: 24px;
        }

        /* Monthly View */
        .monthly-header {
            background: var(--glass);
            backdrop-filter: var(--blur);
            border-radius: 20px;
            padding: 30px;
            box-shadow: var(--shadow);
        }

        .month-nav {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .month-title {
            font-weight: 700;
            color: var(--dark);
            font-size: 18px;
        }

        .calendar-legend {
            display: flex;
            gap: 20px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--secondary);
            font-size: 0.875rem;
        }

        .legend-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
        }

        .legend-dot.today {
            background: var(--primary);
        }

        .legend-dot.has-tasks {
            background: var(--success);
        }

        .legend-dot.weekend {
            background: var(--warning);
        }

        /* Calendar Grid */
        .calendar-grid-container {
            background: var(--glass);
            backdrop-filter: var(--blur);
            border-radius: 20px;
            padding: 24px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .calendar-grid-header {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 1px;
            margin-bottom: 12px;
        }

        .weekday-header {
            text-align: center;
            padding: 12px;
            color: var(--secondary);
            font-weight: 600;
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .calendar-grid {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 1px;
            background: var(--border);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
        }

        .calendar-day {
            background: white;
            padding: 16px;
            min-height: 120px;
            border: 1px solid var(--border);
            transition: all 0.3s ease;
            position: relative;
            cursor: pointer;
        }

        .calendar-day:hover {
            background: rgba(105, 108, 255, 0.05);
            z-index: 1;
            transform: scale(1.02);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .calendar-day.today {
            background: linear-gradient(135deg, rgba(105, 108, 255, 0.1), rgba(133, 146, 255, 0.05));
            border-color: var(--primary);
        }

        .calendar-day.today::after {
            content: '';
            position: absolute;
            top: 8px;
            right: 8px;
            width: 8px;
            height: 8px;
            background: var(--primary);
            border-radius: 50%;
        }

        .calendar-day.has-tasks {
            background: linear-gradient(135deg, rgba(40, 199, 111, 0.1), rgba(40, 199, 111, 0.05));
            border-color: rgba(40, 199, 111, 0.3);
        }

        .calendar-day.weekend {
            background: rgba(255, 159, 67, 0.05);
        }

        .day-number {
            font-weight: 600;
            color: var(--dark);
            font-size: 1.1rem;
            margin-bottom: 8px;
        }

        .day-name {
            color: var(--secondary);
            font-size: 0.75rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }

        .day-tasks {
            margin-top: 8px;
        }

        .task-indicator {
            display: flex;
            align-items: center;
            gap: 4px;
            padding: 4px 8px;
            background: var(--success);
            color: white;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .task-indicator i {
            font-size: 0.875rem;
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(40, 48, 70, 0.9);
            backdrop-filter: blur(10px);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }

        .loading-content {
            text-align: center;
            color: white;
        }

        .spinner-grow {
            width: 60px;
            height: 60px;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .animate-fadeInUp {
            animation: fadeInUp 0.4s ease-out;
        }

        .tasks-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 20px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header-section {
                padding: 20px;
            }

            .content-section {
                padding: 20px;
            }

            .tasks-grid {
                grid-template-columns: 1fr;
            }

            .calendar-grid {
                overflow-x: auto;
            }

            .calendar-day {
                min-height: 100px;
                padding: 12px;
            }

            .date-nav-buttons {
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
            }

            .nav-btn {
                padding: 10px 16px;
                font-size: 0.875rem;
            }

            .view-toggle {
                width: 100%;
            }

            .view-btn {
                flex: 1;
                justify-content: center;
            }
        }
    </style>

    <!-- Modern JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize
            let currentDate = document.getElementById('taskDatePicker').value;

            const today = new Date();
            const localDate = today.getFullYear() + '-' +
                String(today.getMonth() + 1).padStart(2, '0') + '-' +
                String(today.getDate()).padStart(2, '0');

            if (!currentDate) {
                currentDate = localDate;
            }

            let currentMonth = parseInt("{{ $month }}", 10) || new Date().getMonth() + 1;
            let currentYear = parseInt("{{ $year }}", 10) || new Date().getFullYear();
            let currentView = 'daily';

            // Initialize date pickers
            $('#taskDatePicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
                templates: {
                    leftArrow: '<i class="mdi mdi-chevron-left"></i>',
                    rightArrow: '<i class="mdi mdi-chevron-right"></i>'
                }
            });

            $('#taskMonthPicker').datepicker({
                format: 'yyyy-mm',
                startView: 1,
                minViewMode: 1,
                autoclose: true,
                templates: {
                    leftArrow: '<i class="mdi mdi-chevron-left"></i>',
                    rightArrow: '<i class="mdi mdi-chevron-right"></i>'
                }
            });

            // View toggle
            document.querySelectorAll('.view-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const view = this.dataset.view;

                    // Update active button
                    document.querySelectorAll('.view-btn').forEach(b => b.classList.remove(
                        'active'));
                    this.classList.add('active');

                    // Update view
                    document.querySelectorAll('.view-container').forEach(container => {
                        container.classList.remove('active');
                    });

                    if (view === 'daily') {
                        currentView = 'daily';
                        document.getElementById('dailyViewContainer').classList.add('active');
                        document.getElementById('datePickerContainer').style.display = 'block';
                        document.getElementById('date_filter_header').style.display = 'block';
                        document.getElementById('dailyViewContainer').style.display = 'block';
                        document.getElementById('monthPickerContainer').style.display = 'none';
                        document.getElementById('monthlyViewContainer').style.display = 'none';
                        document.getElementById('month_filter_header').style.display = 'none';
                        loadDailyTasks(currentDate);
                    } else {
                        currentView = 'monthly';
                        document.getElementById('monthlyViewContainer').classList.add('active');
                        document.getElementById('datePickerContainer').style.display = 'none';
                        document.getElementById('dailyViewContainer').style.display = 'none';
                        document.getElementById('date_filter_header').style.display = 'none';
                        document.getElementById('monthPickerContainer').style.display = 'block';
                        document.getElementById('monthlyViewContainer').style.display = 'block';
                        document.getElementById('month_filter_header').style.display = 'flex';
                        loadMonthlyTasks(currentMonth, currentYear);
                    }
                });
            });

            // Date navigation
            document.getElementById('prevDay').addEventListener('click', () => navigateDay(-1));
            document.getElementById('nextDay').addEventListener('click', () => navigateDay(1));
            document.getElementById('todayBtn').addEventListener('click', goToToday);

            document.getElementById('prevMonth').addEventListener('click', () => navigateMonth(-1));
            document.getElementById('nextMonth').addEventListener('click', () => navigateMonth(1));

            // Date picker changes
            $('#taskDatePicker').on('changeDate', function(e) {
                currentDate = $(this).val();
                if (currentView === 'daily') {
                    loadDailyTasks(currentDate);
                }
            });

            $('#taskMonthPicker').on('changeDate', function(e) {
                currentMonth = e.date.getMonth() + 1;
                currentYear = e.date.getFullYear();
                if (currentView === 'monthly') {
                    loadMonthlyTasks(currentMonth, currentYear);
                }
            });

            function parseDate(dateStr) {
                // Parse as local date consistently
                const [year, month, day] = dateStr.split('-').map(Number);
                return new Date(year, month - 1, day, 12, 0, 0);
            }

            function formatLocalDate(date) {
                const year = date.getFullYear();
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const day = String(date.getDate()).padStart(2, '0');
                return `${year}-${month}-${day}`;
            }


            // Functions
            function navigateDay(days) {
                const date = parseDate(currentDate);
                date.setDate(date.getDate() + days);

                currentDate = formatLocalDate(date);

                $('#taskDatePicker').datepicker('update', currentDate);
                loadDailyTasks(currentDate);
            }


            function navigateMonth(months) {
                const date = new Date(currentYear, currentMonth - 1 + months, 1);
                currentMonth = date.getMonth() + 1;
                currentYear = date.getFullYear();

                $('#taskMonthPicker').datepicker('update',
                    `${currentYear}-${currentMonth.toString().padStart(2, '0')}-01`
                );

                const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                    'July', 'August', 'September', 'October', 'November', 'December'
                ];
                document.getElementById('currentMonthDisplay').textContent =
                    `${monthNames[currentMonth - 1]} ${currentYear}`;

                loadMonthlyTasks(currentMonth, currentYear);
            }

            function goToToday() {
                const today = new Date();
                currentDate = formatLocalDate(today);
                $('#taskDatePicker').datepicker('update', currentDate);
                loadDailyTasks(currentDate);
            }

            async function loadDailyTasks(date) {
                showLoading();
                try {
                    const response = await fetch(`/task_calendar/daily_tasks?date=${date}`);
                    const data = await response.json();
                    hideLoading();
                    updateDailyUI(data);
                } catch (error) {
                    hideLoading();
                    console.error('Error loading tasks:', error);
                    showToast('Failed to load tasks', 'error');
                }
            }

            async function loadMonthlyTasks(month, year) {
                showLoading();
                try {
                    const response = await fetch(`/task_calendar/monthly_tasks?month=${month}&year=${year}`);
                    const data = await response.json();
                    hideLoading();
                    updateMonthlyUI(data);
                } catch (error) {
                    hideLoading();
                    console.error('Error loading monthly tasks:', error);
                    showToast('Failed to load calendar', 'error');
                }
            }

            function updateDailyUI(data) {
                // Update date display
                const dateObj = new Date(data.date);

                // Update stats
                const statsHtml = `
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="stat-card stat-card-total-tasks tasks animate-fadeInUp">
                        <div class="stat-value">${data.stats.total_tasks}</div>
                        <div class="stat-label">Total Tasks</div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="stat-card stat-card-total-hours  hours animate-fadeInUp">
                        <div class="stat-value">${data.stats.total_hours}</div>
                        <div class="stat-label">Total Hours</div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="stat-card stat-card-pending-tasks  pending animate-fadeInUp">
                        <div class="stat-value">${data.stats.pending}</div>
                        <div class="stat-label">Pending Tasks</div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-md-6">
                    <div class="stat-card stat-card-completed completed animate-fadeInUp">
                        <div class="stat-value">${data.stats.completed}</div>
                        <div class="stat-label">Completed</div>
                    </div>
                </div>
            `;

                document.getElementById('dailyStats').innerHTML = statsHtml;

                // Update tasks
                const tasksContainer = document.getElementById('dailyTasksContainer');
                const emptyState = document.getElementById('emptyStateDaily');

                if (!data.tasks || data.tasks.length === 0) {
                    tasksContainer.innerHTML = '';
                    emptyState.classList.remove('d-none');
                    return;
                }

                emptyState.classList.add('d-none');

                let tasksHtml = '';
                data.tasks.forEach((task, index) => {
                    const taskDate = new Date(task.task_date);
                    const timeString = taskDate.toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                    });

                    // Determine status and priority
                    let statusClass = 'status-pending';
                    let statusText = 'Pending';
                    let priorityClass = '';

                    if (task.status == 1) {
                        statusClass = 'status-completed';
                        statusText = 'Completed';
                    } else if (task.status == 2) {
                        statusClass = 'status-in-progress';
                        statusText = 'In Progress';
                    }

                    if (task.priority == 1) priorityClass = 'priority-high';
                    else if (task.priority == 2) priorityClass = 'priority-medium';
                    else if (task.priority == 3) priorityClass = 'priority-low';

                    const taskCategory = task.task_category;
                    let pageOrPer = '';

                    if (taskCategory == 0) {
                        if (task.max_page_or_per > 1) {
                            pageOrPer = 'Pages';
                        } else {
                            pageOrPer = 'Page';
                        }
                    } else {
                        pageOrPer = 'Percentage';
                    }

                    var staff = '';
 
                    @if (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'view_self_manage_task'))            
                        staff = 'd-none';
                    @elseif (auth()->user()->hasPermissionradio('Production Management', 'Task Calendar', 'global_manage_task'))
                        staff  = '';
                    @else
                        staff  = '';
                    @endif
                    tasksHtml += `
                    <div class="joy-task-card">
                        <!-- Card Header with Staff Section -->
                        <div class="card-header ${staff}">
                            <div class="staff-section">
                                <div class="staff-avatar">
                                    <div class="avatar-wrapper">
                                        <img src="{{ asset('staff_images/${task.staff_image}') }}" 
                                            alt="Staff Avatar" class="avatar-image">
                                        <div class="status-indicator online"></div>
                                    </div>
                                    <div class="staff-info">
                                        <h4 class="staff-name">${task.staff_name}</h4>
                                        <span class="staff-role">${task.job_position_name}</span>
                                    </div>
                                </div>
                                <div class="task-badge">
                                    <span class="badge-text">Assigned</span>
                                </div>
                            </div>
                        </div>

                        <!-- Task Details Section -->
                        <div class="card-body">
                            <div class="task-details">
                                <!-- Task Info -->
                                <div class="detail-group">
                                    <div class="detail-item">
                                        <span class="detail-label">
                                            <i class="mdi mdi-checkbox-marked-circle-outline"></i>
                                            Task Name
                                        </span>
                                        <span class="detail-value">${task.task_name}</span>
                                    </div>
                                    
                                    <div class="detail-item">
                                        <span class="detail-label">
                                            <i class="mdi mdi-identifier"></i>
                                            Task ID
                                        </span>
                                        <span class="detail-value task-id">${task.task_id}</span>
                                    </div>
                                    
                                    <div class="detail-item">
                                        <span class="detail-label">
                                            <i class="mdi mdi-briefcase-outline"></i>
                                            Service
                                        </span>
                                        <span class="detail-value">${task.service_name}</span>
                                    </div>
                                    
                                    <div class="detail-item">
                                        <span class="detail-label">
                                            <i class="mdi mdi-account-outline"></i>
                                            Customer
                                        </span>
                                        <span class="detail-value">${task.customer_name}</span>
                                    </div>
                                    
                                    <div class="detail-item">
                                        <span class="detail-label">
                                            <i class="mdi mdi-badge-account-horizontal"></i>
                                            Customer ID
                                        </span>
                                        <span class="detail-value customer-id">${task.customer_id}</span>
                                    </div>
                                </div>

                                <!-- Metrics Section -->
                                <div class="metrics-group">
                                    <div class="metric-card">
                                        <div class="metric-icon hours">
                                            <i class="mdi mdi-clock-outline"></i>
                                        </div>
                                        <div class="metric-content">
                                            <span class="metric-value">${task.task_hours}</span>
                                            <span class="metric-label">Hours</span>
                                        </div>
                                    </div>
                                    
                                    <div class="metric-card">
                                        <div class="metric-icon pages">
                                            <i class="mdi mdi-file-document-outline"></i>
                                        </div>
                                        <div class="metric-content">
                                            <span class="metric-value">${task.max_page_or_per}</span>
                                            <span class="metric-label">${pageOrPer}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Assigned Staff Section -->
                        <div class="card-footer">
                            <div class="assigned-staff">
                                <div class="section-title">
                                    <i class="mdi mdi-account-group-outline"></i>
                                    <span>Assigned By</span>
                                </div>
                                <div class="staff-tags">
                                    <span class="staff-tag">
                                        <div class="tag-avatar">${task.pc_name.charAt(0).toUpperCase()}</div>
                                        ${task.pc_name}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                });

                tasksContainer.innerHTML = tasksHtml;
            }

            function updateMonthlyUI(data) {
                // Update month display
                document.getElementById('currentMonthDisplay').textContent = data.month_year;

                // Update stats
                const statsHtml = `
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="stat-card stat-card-total-tasks tasks animate-fadeInUp">
                        <div class="stat-value">${data.stats.total_tasks}</div>
                        <div class="stat-label">Monthly Tasks</div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="stat-card stat-card-total-hours hours animate-fadeInUp">
                        <div class="stat-value">${data.stats.total_hours}</div>
                        <div class="stat-label">Total Hours</div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="stat-card stat-card-pending-tasks  completed animate-fadeInUp">
                        <div class="stat-value">${data.stats.total_days_with_tasks}</div>
                        <div class="stat-label">Active Days</div>
                    </div>
                </div>
            `;

                document.getElementById('monthlyStats').innerHTML = statsHtml;

                // Update calendar
                const calendarContainer = document.getElementById('monthlyCalendar');
                let calendarHtml = '';

                // Get first day of month
                const firstDate = Object.keys(data.calendar)[0];
                const firstDay = firstDate ? new Date(firstDate).getDay() : new Date().getDay();

                // Add empty cells for days before the first day of month
                for (let i = 0; i < firstDay; i++) {
                    calendarHtml += `<div class="calendar-day"></div>`;
                }

                // Add days of the month
                Object.values(data.calendar).forEach((dayData, index) => {
                    const date = new Date(dayData.date);
                    const dayNumber = date.getDate();
                    const dayName = date.toLocaleDateString('en-US', {
                        weekday: 'short'
                    });
                    const isToday = dayData.is_today;
                    const hasTasks = dayData.task_count > 0;
                    const isWeekend = dayData.is_weekend;

                    let dayClass = 'calendar-day';
                    if (isToday) dayClass += ' today';
                    if (hasTasks) dayClass += ' has-tasks';
                    if (isWeekend) dayClass += ' weekend';

                    let tasksHtml = '';
                    if (hasTasks) {
                        const taskText = dayData.task_count === 1 ? 'task' : 'tasks';
                        tasksHtml = `
                        <div class="day-tasks">
                            <div class="task-indicator">
                                <i class="mdi mdi-check-circle"></i>
                                <span>${dayData.task_count} ${taskText}</span>
                            </div>
                        </div>
                    `;
                    }

                    calendarHtml += `
                    <div class="${dayClass} animate-fadeInUp" style="animation-delay: ${index * 0.02}s" 
                        onclick="viewDailyFromMonthly('${dayData.date}')">
                        <div class="day-number">${dayNumber}</div>
                        <div class="day-name">${dayName}</div>
                        ${tasksHtml}
                    </div>
                `;
                });

                calendarContainer.innerHTML = calendarHtml;
            }

            function showLoading() {
                document.getElementById('loadingOverlay').classList.remove('d-none');
            }

            function hideLoading() {
                document.getElementById('loadingOverlay').classList.add('d-none');
            }

            function showToast(message, type = 'info') {
                // Simple toast notification
                const toast = document.createElement('div');
                toast.className = `toast-notification ${type}`;
                toast.textContent = message;
                document.body.appendChild(toast);

                setTimeout(() => {
                    toast.remove();
                }, 3000);
            }

            // Global functions
            window.viewDailyFromMonthly = function(date) {
                document.querySelector('[data-view="daily"]').click();
                currentDate = date;
                $('#taskDatePicker').datepicker('setDate', date);
                loadDailyTasks(date);
            };

            window.viewTask = function(taskId) {
                console.log('View task:', taskId);
                // Implement task detail view
            };

            window.editTask = function(taskId) {
                console.log('Edit task:', taskId);
                // Implement task edit
            };

            window.goToToday = goToToday;

            // Initialize with today's data
            loadDailyTasks(currentDate);
        });
    </script>
@endsection
