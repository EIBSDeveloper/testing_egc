@extends('layouts/layoutMaster')

@section('title', 'Manage Requirements')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
])
@endsection

@section('page-script')
@endsection
@section('content')

<style>
    .list_page thead th,
    .list_page tbody td {
        padding: 7px !important;
    }

    .list_page_1 thead th,
    .list_page_1 tbody td {
        padding: 7px !important;
    }
</style>

@php
    $loginStaff = auth()->user()->user_id;
    $module_name = 'Production Management';
    $menu_name = 'Manage Requirments';
@endphp

<!-- Lead List Table -->
<div class="card">
    <div class="card-header border-bottom pb-1">
        <h5 class="card-title mb-1">Manage Requirements</h5>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i
                            class="mdi mdi-home-outline text-body fs-4"></i></a>
                </li>
                <span class="text-dark opacity-75 me-1 ms-1">
                    <i class="mdi mdi-arrow-right-thin fs-4"></i>
                </span>
                <li class="breadcrumb-item">
                    <a href="javascript:;" class="d-flex align-items-center">Production Management</a>
                </li>
            </ol>
        </nav>
    </div>
    <div class="card-body px-4 py-0">
        <div class="row mt-6">
            <div class="col-xl-12">
                <div class="card-body px-1 py-1">
                    <div class="row">
                        <div class="d-flex justify-content-between align-items-center">
                            <div class="mb-4">
                                @php $perpage_count = $perpage ? $perpage : 25; @endphp
                                <div>
                                    <span>Show</span>
                                    <br>
                                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px"
                                        onchange="sort_filter(this.value);">
                                        @php
                                        $options = [10, 25, 100, 500]; // Define available options
                                        @endphp
                                        @php foreach ($options as $option): @endphp
                                        <option value="{{ $option }}" @php echo ($perpage_count==$option) ? 'selected'
                                            : '' ; @endphp>
                                            @php echo $option; @endphp
                                        </option>
                                        @php endforeach; @endphp
                                    </select>
                                </div>
                            </div>
                            <div class="mb-2">
                                <form id="filter_form" method="POST" action="/manage_requirements">
                                    @csrf
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="mb-1">
                                            <input type="hidden" name="page" value="{{ request('page', 1) }}">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter"
                                                id="sorting_filter"
                                                value="@php echo $perpage ? $perpage : 10; @endphp" />
                                            <input type="text" class="form-control" id="lead_fill" name="lead_fill"
                                                value="{{ $lead_fill ?? "" }}"
                                                placeholder="Enter Lead - Name/ Mob. No/ Email Id" />
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6 "
                                            onclick="search_filter_func()">Search</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-1 gs-2 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-150px">Lead</th>
                                        <th class="min-w-100px">Service</th>
                                        <th class="min-w-50px text-center">Requirements</th>
                                        <th class="min-w-125px">Assigned PC</th>
                                        @if(auth()->user()->hasPermission($module_name, 'Assign Staff', $menu_name))
                                            <th class="min-w-125px">Assigned Staff</th>
                                        @endif
                                        @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                            <th class="min-w-150px">Staff Status</th>
                                            <th class="min-w-150px">PC Status</th>
                                        @endif
                                        <th class="min-w-150px">Delivery Status</th>
                                        <th class="min-w-80px">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="text-gray-600 fw-semibold fs-7">
                                    @if(auth()->user()->hasPermission($module_name, 'List', $menu_name))
                                        @if (isset ($lead_requirements))
                                        @foreach ($lead_requirements as $i=> $category)
                                        <tr>
                                            <td>
                                                <label class="fs-7 me-2">{{$category->lead_name}}</label>
                                                <div class="d-block">
                                                    <label class="text-dark fs-8" data-bs-toggle="tooltip"
                                                        data-bs-placement="bottom" title="Register Date">{{
                                                        isset($category->registered_date) ? date($common_date_format,
                                                        strtotime($category->registered_date)) :''}}</label>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-truncate max-w-200px" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="{{$category->product_category_name ?? '-'}}">
                                                    {{$category->product_category_name ?? '-'}}</div>
                                                <div class="d-block">
                                                    <div class="text-truncate max-w-200px fs-8 text-dark"
                                                        data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                        title="{{$category->product_name ?? '-'}}">{{$category->product_name
                                                        ?? '-'}}</div>
                                                </div>
                                            </td>
                                            <td class="text-center">
                                                <div class="badge bg-secondary text-white fs-8 fw-semibold">
                                                    {{$category->requirement_count ?? '0'}}</div>
                                            </td>
                                            <td>
                                                @if(!empty($category->pc_id))
                                                    <label class="text-black fw-semibold fs-7">
                                                        {{ $category->pc_name }}
                                                    </label>
                                                    <div class="d-block">
                                                        <label class="badge bg-info text-white fw-semibold fs-8">{{ $category->pc_job_name }}</label>
                                                    </div>
                                                @else
                                                    <div class="text-black">-</div>
                                                @endif
                                            </td>
                                            @if(auth()->user()->hasPermission($module_name, 'Assign Staff', $menu_name))
                                                <td>    
                                                    @if($loginStaff == $category->pc_id)
                                                        @if($category->staff_id ==0)
                                                            <a href="javascript:;" class="border border-gray-400 rounded px-1 py-2"
                                                                data-bs-toggle="modal" data-bs-target="#kt_modal_staff_confirmation"
                                                                onclick="StaffAssign('{{$category->sno}}')">
                                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Assign Staff">
                                                                    <i class="mdi mdi-account-plus fs-4 text-gray"></i>
                                                                </span>
                                                            </a>
                                                        @else
                                                            <label class="text-black fw-semibold fs-7">{{$category->assign_staff_name}}</label>
                                                            <div class="d-block">
                                                                <label class="badge bg-info text-white fw-semibold fs-8">{{$category->assign_staff_job_name }}</label>
                                                                 @if($category->staff_approval == 0)
                                                                    <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation" onclick="StaffUpdate('{{$category->sno}}','{{$category->staff_id}}')">
                                                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                                            <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                                        </span>
                                                                    </a>
                                                                @endif
                                                            </div>
                                                        @endif
                                                    @elseif ($category->staff_id)
                                                            <label class="text-black fw-semibold fs-7">{{$category->assign_staff_name}}</label>
                                                            <div class="d-block">
                                                                <label class="badge bg-info text-white fw-semibold fs-8">{{$category->assign_staff_job_name }}</label>
                                                            </div>
                                                    @else
                                                        <div class="text-center">-</div>
                                                    @endif
                                                </td>
                                            @endif
                                            @if(auth()->user()->hasPermission($module_name, 'Status Change', $menu_name))
                                            <td>
                                                @if($loginStaff == $category->staff_id)
                                                    @if($category->staff_id ==0)
                                                        <div class="badge text-black rounded fw-bold fs-8" style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                    @elseif($category->staff_approval ==0)
                                                        <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            Waiting for Approval
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_accepted" onclick="staffApprovalView('{{$category->sno}}','staff')">Accepted</a>
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_rejected" onclick="staffRejectView('{{$category->sno}}','staff','{{$category->lead_name}}','{{$category->lead_mobile}}')">Rejected</a>
                                                        </div>
                                                    @elseif($category->staff_approval ==1)
                                                        <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted</div>
                                                    @elseif($category->staff_approval ==2)
                                                        <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Rejected</div>
                                                    @endif
                                                @else
                                                    @if($category->staff_id == 0)
                                                        <div class="badge text-black rounded fw-bold fs-8" style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                    @elseif ($category->staff_id != 0 && $category->staff_approval == 0)
                                                        <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for
                                                            Staff Approval
                                                        </div>
                                                    @elseif ($category->staff_approval == 1)
                                                        <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted</div>
                                                    @elseif ($category->staff_approval == 2)
                                                        <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Rejected</div>
                                                    @endif
                                                @endif
                                            </td>
                                            <td>
                                                @if($loginStaff == $category->pc_id)
                                                    @if($category->staff_id ==0)
                                                        <div class="badge text-black rounded fw-bold fs-8" style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                    @elseif($category->staff_approval ==0)
                                                        <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for
                                                            Staff Approval
                                                        </div>
                                                    @elseif($category->pc_approval ==0)
                                                        <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            Waiting for PC Approval
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-end">
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_requirements_accepted"
                                                                onclick="staffApprovalView('{{$category->sno}}','pc')">Accepted</a>
                                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                                data-bs-target="#kt_modal_requirements_rejected"
                                                                onclick="staffRejectView('{{$category->sno}}','pc','{{$category->lead_name}}','{{$category->lead_mobile}}')">Rejected</a>
                                                        </div>
                                                    @elseif($category->pc_approval ==1)
                                                        <div class="badge text-white rounded fw-semibold fs-8"
                                                            style="background-color:#2C5530;">Accepted for PC</div>
                                                    @elseif($category->pc_approval ==2)
                                                        <div class="badge text-white rounded fw-bold fs-8"
                                                            style="background-color:#d22513;">Rejected</div>
                                                    @endif
                                                @else
                                                    @if ($category->staff_id == 0)
                                                        <div class="badge text-black rounded fw-bold fs-8" style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                    @elseif ($category->staff_approval == 0)
                                                        <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for Staff Approval</div>
                                                    @elseif ($category->pc_approval == 0)
                                                        <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for PC Approval</div>
                                                    @elseif ($category->pc_approval == 1)
                                                        <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted for PC</div>
                                                    @elseif ($category->pc_approval == 2)
                                                        <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Rejected</div>
                                                    @endif
                                                @endif
                                            </td>
                                            @endif
                                            <td>
                                                @if($category->staff_id == 0)
                                                    <div class="badge text-black rounded fw-bold fs-8" style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                @elseif ($category->staff_approval == 0)
                                                    <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for
                                                        Staff Approval
                                                    </div>
                                                @elseif ($category->pc_approval == 0)
                                                    <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for PC Approval</div>
                                                @elseif ($category->staff_id != 0 && $category->delivery_status == 0)
                                                    <a href="javascript:;" class="badge text-black rounded fw-bold fs-8" style="background-color: #4af3d4 !important;">
                                                        Waiting for Delivery
                                                    </a>
                                                @elseif ($category->staff_id != 0 && $category->delivery_status == 1)
                                                    <div class="badge bg-success text-black rounded fw-semibold fs-8">Delivered</div>
                                                @elseif ($category->staff_id != 0 && $category->delivery_status == 2)
                                                    <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Rejected</div>
                                                @endif
                                            </td>
                                            {{-- <td>
                                                @if($category->staff_id ==0)
                                                <div class="badge text-black rounded fw-bold fs-8"
                                                    style="background-color:#e4bfff;">Staff Not Assigned</div>
                                                @elseif($category->staff_approval ==0)
                                                <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for
                                                    Staff Approval</div>
                                                @elseif($category->pc_approval ==0)
                                                <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for PC
                                                    Approval</div>
                                                @elseif( $category->staff_id !=0 && $category->delivery_status ==0)
                                                <a href="javascript:;" class="badge text-black rounded fw-bold fs-8" id=""
                                                    data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                                    style="background-color: #4af3d4 !important;">
                                                    Waiting for Delivery
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirements_delivered"
                                                        onclick="staffAcceptView('{{$category->sno}}','delivery','{{$category->lead_name}}','{{$category->lead_mobile}}')">Delivered</a>
                                                    <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                        data-bs-target="#kt_modal_requirements_cancelled"
                                                        onclick="staffCancelView('{{$category->sno}}','delivery','{{$category->lead_name}}','{{$category->lead_mobile}}')">Cancelled</a>
                                                </div>
                                                @elseif( $category->staff_id !=0 && $category->delivery_status ==1)
                                                <div class="badge bg-success text-black rounded fw-semibold fs-8">Delivered
                                                </div>
                                                @elseif( $category->staff_id !=0 && $category->delivery_status ==2)
                                                <div class="badge text-white rounded fw-bold fs-8"
                                                    style="background-color:#d22513;">Rejected</div>
                                                @endif
                                            </td> --}}
                                            <td>
                                                <span class="text-end">
                                                    @if(auth()->user()->hasPermission($module_name, 'View', $menu_name))
                                                        <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                                            data-bs-target="#kt_modal_view_requirements"
                                                            onclick="requirement_view('{{$category->sno}}')">
                                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                                title="View">
                                                                <i class="mdi mdi-eye fs-3 text-black"></i>
                                                            </span>
                                                        </a>
                                                    @endif
                                                </span>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    @else
                                        <tr>
                                            <td>Unauthorized Access</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    @endif
                                    <!-- <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Nandhini</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">05-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Java Development">Java Development</div>
                                            <div class="d-block">
                                                <div class="text-truncate max-w-200px fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Development Services">Development Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="badge bg-secondary text-white fs-8 fw-semibold">01</div>
                                        </td>
                                        <td>
                                            <label class="text-black fw-semibold fs-7">Suresh</label>
                                            <div class="d-block">
                                                <label class="badge bg-info text-white fw-semibold fs-8">Developer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff"><i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i></span>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Waiting for Approval
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_accepted">Accepted</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_rejected">Rejected</a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for Staff Approval</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for Staff Approval</div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_requirements">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View">
                                                        <i class="mdi mdi-eye fs-3 text-black"></i>
                                                    </span>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Madhan</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">03-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                            <div class="d-block">
                                                <div class="text-truncate max-w-200px fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Services">Writing Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="badge bg-secondary text-white fs-8 fw-semibold">03</div>
                                        </td>
                                        <td>
                                            <label class="text-black fw-semibold fs-7">Vasanth Kumar</label>
                                            <div class="d-block">
                                                <label class="badge bg-info text-white fw-semibold fs-8">Developer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                        <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted</div>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted for PC</div>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="badge text-black rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="background-color: #4af3d4 !important;">
                                                Waiting for Delivery
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_delivered">Delivered</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_cancelled">Cancelled</a>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_requirements">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View">
                                                        <i class="mdi mdi-eye fs-3 text-black"></i>
                                                    </span>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Karnika K S</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">03-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                            <div class="d-block">
                                                <div class="text-truncate max-w-200px fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Services">Writing Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="badge bg-secondary text-white fs-8 fw-semibold">01</div>
                                        </td>
                                        <td>
                                            <label class="text-black fw-semibold fs-7">Vasanth Kumar</label>
                                            <div class="d-block">
                                                <label class="badge bg-info text-white fw-semibold fs-8">Developer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                        <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted</div>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-semibold fs-8" style="background-color:#2C5530;">Accepted for PC</div>
                                        </td>
                                        <td>
                                            <div class="badge bg-success text-black rounded fw-semibold fs-8">Delivered</div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_requirements">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View">
                                                        <i class="mdi mdi-eye fs-3 text-black"></i>
                                                    </span>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fs-7 text-black fw-semibold">Praveen</label>
                                            <div class="d-block">
                                                <label class="text-dark fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Registered Date">03-Mar-2025</label>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="text-truncate max-w-200px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Thesis Writing">Thesis Writing</div>
                                            <div class="d-block">
                                                <div class="text-truncate max-w-200px fs-8 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Writing Services">Writing Services</div>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <div class="badge bg-secondary text-white fs-8 fw-semibold">03</div>
                                        </td>
                                        <td>
                                            <label class="text-black fw-semibold fs-7">Shyamala Devi</label>
                                            <div class="d-block">
                                                <label class="badge bg-info text-white fw-semibold fs-8">Content Writer</label>
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_staff_confirmation">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Update Staff">
                                                        <i class="mdi mdi-tooltip-edit-outline fs-3 text-gray"></i>
                                                    </span>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="badge text-white rounded fw-bold fs-8" style="background-color:#d22513;">Rejected</div>
                                        </td>
                                        <td>
                                            <a href="javascript:;" class="badge bg-warning text-black rounded fw-bold fs-8" id="" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                Waiting for PC Approval
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_accepted">Accepted</a>
                                                <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_requirements_rejected">Rejected</a>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="badge bg-warning text-black rounded fw-bold fs-8">Waiting for PC Approval</div>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_view_requirements">
                                                    <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="View">
                                                        <i class="mdi mdi-eye fs-3 text-black"></i>
                                                    </span>
                                                </a>
                                            </span>
                                        </td>
                                    </tr> -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Add Staff Confirmation-->
<div class="modal fade" id="kt_modal_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Assign Staff</h3>
                </div>
                <form id="assignStaffForm" action="{{ route('assign_staff_requirement') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <input type="hidden" name="assign_requirement_id" id="assign_requirement_id">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                    class="text-danger">*</span></label>
                            <select id="assign_staff_id" name="assign_staff_id" class="select3 form-select">
                                <option value="">Select Staff</option>
                            </select>
                            <div class="text-danger" id="assign_staff_id_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="assignSubmit" class="btn btn-primary"
                            onclick="assignStaffForm()">Assign Staff</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Add Staff Confirmation- -->

<!--begin::Modal - Add Staff Confirmation-->
<div class="modal fade" id="kt_modal_edit_staff_confirmation" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-md">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Update Staff</h3>
                </div>
                <form id="updateStaffForm" action="{{ route('assign_staff_requirement') }}" method="POST" novalidate
                    autocomplete="off">
                    @csrf
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <input type="hidden" name="assign_requirement_id" id="update_requirement_id">
                            <label class="text-black mb-1 fs-6 fw-semibold">Staff<span
                                    class="text-danger">*</span></label>
                            <select id="update_staff_id" name="assign_staff_id" class="select3 form-select">
                                <option value="">Select Staff</option>
                            </select>
                            <div class="text-danger" id="update_staff_id_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center align-items-center mt-8">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="updateSubmit" class="btn btn-primary me-3"
                            onclick="updateStaffForm()">Update Staff</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal Add Staff Confirmation- -->

<!--begin::Modal - Requirements Accepted-->
<div class="modal fade" id="kt_modal_requirements_accepted" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">Requirements Accepted</h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="approval_lead_name"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="approval_lead_mobile"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Job Role</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <label class="badge bg-info fw-semibold fs-7" id="approval_position_name"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="approval_service_category"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Services</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="approval_service"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Staff</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="approval_staff_name"></label>
                        </div>
                    </div>
                </div>
                <form id="approveForm" method="POST" action="{{ url('/approve_requirement') }}">
                    @csrf
                    <div class="row mb-3">
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1"
                                id="approval_table">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">
                                            <!-- <input class="form-check-input border border-gray-300 me-1" type="checkbox" name="all"> -->
                                            <span class="fs-7">All</span>
                                        </th>
                                        <th class="min-w-250px">Requirements</th>
                                        <th class="min-w-80px text-center">Attachments</th>
                                        <th class="min-w-175px">Reason</th>
                                    </tr>
                                </thead>
                                <tbody class="text-black fw-semibold fs-7">

                                </tbody>
                            </table>
                        </div>
                    </div>
                    <input type="hidden" name="requirement_id_reject" id="requirement_id_approve">
                    <input type="hidden" name="requirement_approval_type" id="requirement_approval_type">
                    <div class="d-flex justify-content-end align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" id="approveBtn" class="btn btn-primary">Submit Reports</button>
                    </div>
                </form>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Requirements Accepted -->

<!--begin::Modal - Requirements Rejected-->
<div class="modal fade" id="kt_modal_requirements_rejected" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Rejected Requirements ?
                <div class="d-block fw-bold fs-5 text-danger py-2">
                    <label id="reject_lead">Priya</label>
                    <span class="ms-2 me-2">-</span>
                    <label id="reject_mobile"></label>
                </div>
            </div>
            <form id="rejectForm" method="POST" action="{{ url('/update_requirement_reject_reason') }}">
                @csrf
                <div class="row px-10">
                    <div class="col-lg-12 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold required">Reason <span
                                class="text-danger">*</span></label>
                        <select id="reason_reject_select" name="reason_reject_select" class="select3 form-select"
                            onchange="toggleInputField_reject(this.value)">
                            <option value="">Select Reason</option>
                            @if (isset($reasonList_reject) && count($reasonList_reject) > 0)
                            @foreach ($reasonList_reject as $i_reason)
                            <option value="{{ $i_reason->reason_name }}"
                                data-comments-check="{{ $i_reason->comments_check }}">
                                {{ $i_reason->reason_name }}
                                @endforeach
                                @endif
                            <option value="1">Others</option>
                        </select>
                        <div class="text-danger" id="reason_reject_select_err"></div>
                    </div>
                    <div class="col-lg-12 mb-3" id="reject_reason_div" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold required">Other Reason <span
                                class="text-danger">*</span></label>
                        <textarea class="form-control" name="reject_reason_text" rows="3" id="reject_reason_text"
                            oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });"
                            placeholder="Enter Others Reason"></textarea>
                    </div>
                    <div class="col-lg-12 mb-3" id="reject_comments_div" style="display: none;">
                        <label class="text-black mb-1 fs-6 fw-semibold required">Comments <span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="reject_comments_text" id="reject_comments_text"
                            value="" placeholder="Enter Comments"
                            oninput="this.value = this.value.replace(/[&quot;&#39;*]/g, '').replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                    </div>
                    <div class="text-danger" id="reject_reason_text_err"></div>
                    <div class="text-danger" id="reject_comments_text_err"></div>
                </div>
                <input type="hidden" name="requirement_id_reject" id="requirement_id_reject">
                <input type="hidden" name="requirement_approval_type" id="requirement_reject_approval_type">
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="button" id="rejectBtn" class="btn btn-primary me-3"
                        onclick="requirementReject()">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Requirements Rejected-->


<!--begin::Modal - Requirements Delivered-->
<div class="modal fade" id="kt_modal_requirements_delivered" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Deliver Requirements ?
                <div class="d-block fw-bold fs-5 text-success py-2">
                    <label id="accept_lead"></label>
                    <span class="ms-2 me-2">-</span>
                    <label id="accept_mobile"></label>
                </div>
            </div>
            <form id="rejectForm" method="POST" action="{{ url('/approve_requirement') }}">
                @csrf
                <input type="hidden" name="requirement_id_reject" id="requirement_id_accept">
                <input type="hidden" name="requirement_approval_type" id="requirement_accept_type">
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" id="rejectBtn" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Requirements Delivered-->

<!--begin::Modal - Requirements Cancelled-->
<div class="modal fade" id="kt_modal_requirements_cancelled" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                Cancel Requirements ?
                <div class="d-block fw-bold fs-5 text-danger py-2">
                    <label id="cancel_lead"></label>
                    <span class="ms-2 me-2">-</span>
                    <label id="cancel_mobile"></label>
                </div>
            </div>
            <form id="cancelForm" method="POST" action="{{ url('/update_requirement_reject_reason') }}">
                @csrf
                <input type="hidden" name="requirement_id_reject" id="requirement_id_cancelled">
                <input type="hidden" name="requirement_approval_type" id="requirement_cancelled_type">
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <button type="submit" id="" class="btn btn-primary me-3">Yes</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </form>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Requirements Cancelled-->


<!--begin::Modal - View Requirements-->
<div class="modal fade" id="kt_modal_view_requirements" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static" data-bs-focus="false">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-8 text-center">
                    <h3 class="text-center mb-4 text-black">
                        <span>View Requirements</span>
                        <span class="ms-1 me-1">-</span>
                        <span class="badge rounded text-black fw-semibold fs-5" style="background-color: #e4bfff;"
                            id="view_staff_assigned">Staff Not Assigned</span>
                        <!-- <span class="badge bg-warning rounded text-black fw-semibold fs-5">Waiting for Approval</span> -->
                        <!-- <span class="badge rounded text-white fw-semibold fs-5" style="background-color: #2C5530 !important;">Accepted</span> -->
                        <!-- <span class="badge bg-danger rounded text-white fw-semibold fs-5">Rejected</span> -->
                    </h3>
                </div>
                <div class="row">
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Lead</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="view_lead_name"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Mobile</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="view_lead_mobile"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Job Role</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <div class="col-7">
                                <label class="badge bg-info fw-semibold fs-7" id="view_position_name"></span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-1">
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Service Category</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="view_service_category"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Services</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="view_service"></label>
                        </div>
                        <div class="row mb-3">
                            <label class="col-4 text-dark fs-6 fw-semibold">Staff</label>
                            <label class="col-1 text-black fs-6 fw-bold">:</label>
                            <label class="col-7 text-black fs-6 fw-bold" id="view_staff_name"></label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">

                    <div class="col-lg-12">
                        <table
                            class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page_1"
                            id="view_table">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px"></th>
                                    <th class="min-w-250px">Requirements</th>
                                    <th class="min-w-80px text-center">Attachments</th>
                                    <th class="min-w-175px">Reason</th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Requirements Accepted -->


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
    /* Customize Toastr notification */
    .toast-success {
        background-color: green;
    }

    /* Customize Toastr notification */
    .toast-error {
        background-color: red;
    }

    .tags-inline.tagify__dropdown {
        z-index: 9999 !important;
        /* Ensure it is higher than the modal's z-index */
    }
</style>

<script>
    // Display Toastr messages
            @if (Session::has('toastr'))
                var type = "{{ Session::get('toastr')['type'] }}";
                var message = "{{ Session::get('toastr')['message'] }}";
                toastr[type](message);
            @endif
</script>

<script>
    function sort_filter(val) {
        if (val != "") {
          $('.sorting_filter_class').val(val);
          $('#filter_form').submit();
        } else {
          $('.sorting_filter_class').val(10);
          $('#filter_form').submit();
        }
      }
</script>



<script>
    function req_reject_reason_func() {
        var req_rej_rea = document.getElementById("req_rej_rea").value;
        if (req_rej_rea == 'others') {
            document.getElementById("other_tbox").style.display = "block";
        } else {
            document.getElementById("other_tbox").style.display = "none";
        }
    }
</script>

<!-- assign and Update Staff Dropdown -->

<script>
    function StaffAssign(id){
        $('#assign_requirement_id').val(id);
    }
    function StaffUpdate(id,staff_id){
        $('#update_requirement_id').val(id);
        $('#update_staff_id').val(staff_id).trigger('change');
    }

    $(document).ready(function() {
        $.ajax({
            url: "{{ route('requirement_staff_list') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var staffDropdown = $('#assign_staff_id');
                    staffDropdown.empty();
                    staffDropdown.append('<option value="">Select Staff</option>');
                    response.data.forEach(function(staff) {
                        var staffName = (staff.staff_name + "-" + staff.position_name).charAt(0).toUpperCase() +(staff.staff_name + "-" + staff.position_name).slice(1).toLowerCase();
                        staffDropdown.append($('<option></option>').attr('value', staff.sno).text(staffName));
                    });
                    // staffDropdown.val(staff_id).trigger('change'); // Set the selected staff and trigger change

                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });
        var update_staff_id=$('#update_staff_id').val();
        $.ajax({
            url: "{{ route('requirement_staff_list') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var staffDropdown = $('#update_staff_id');
                    staffDropdown.empty();
                    staffDropdown.append('<option value="">Select Staff</option>');
                    response.data.forEach(function(staff) {
                        var staffName = (staff.staff_name + "-" + staff.position_name).charAt(0).toUpperCase() +(staff.staff_name + "-" + staff.position_name).slice(1).toLowerCase();
                        staffDropdown.append($('<option></option>').attr('value', staff.sno).text(staffName));
                    });
                    if(update_staff_id){
                        staffDropdown.val(update_staff_id).trigger('change'); // Set the selected staff and trigger change
                    }
                  

                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });
    });

    function assignStaffForm() {
            var err = 0;

            var assign_staff_id = document.getElementById("assign_staff_id").value.trim();
            if (assign_staff_id === "") {
                document.getElementById('assign_staff_id_err').innerHTML = 'Staff is required...!';
                document.getElementById('assign_staff_id').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('assign_staff_id').classList.remove('error_msg');
                document.getElementById('assign_staff_id_err').innerHTML = '';
            }

            if(err==0){
                $('#assignSubmit').prop('disabled', true);
                $('#assignStaffForm').submit();
            }else{
                $('#assignSubmit').prop('disabled', false);
            }

    }
    function updateStaffForm() {
            var err = 0;

            var update_staff_id = document.getElementById("update_staff_id").value.trim();
            if (update_staff_id === "") {
                document.getElementById('update_staff_id_err').innerHTML = 'Staff is required...!';
                document.getElementById('update_staff_id').classList.add('error_msg');
                err++;
            } else {
                document.getElementById('update_staff_id').classList.remove('error_msg');
                document.getElementById('update_staff_id_err').innerHTML = '';
            }

            if(err==0){
                $('#updateSubmit').prop('disabled', true);
                $('#updateStaffForm').submit();
            }else{
                $('#updateSubmit').prop('disabled', false);
            }

    }
</script>

<script>
    function requirement_view(id) {

            let studentTableBody = $('#kt_modal_view_requirements').find('#view_table tbody');
            studentTableBody.empty();
        
            $.ajax({
                url: '/requirement_view/' + id, // Adjust with your route
                type: 'GET',
                success: function(response) {
                    $('#view_lead_name').text(response.lead.lead_name);
                    $('#view_lead_mobile').text(response.lead.lead_mobile);
                    $('#view_service_category').text(response.lead.product_category_name || '-');
                    $('#view_service').text(response.lead.product_name || '-');
                    $('#view_staff_name').text(response.lead.staff_name || '-');
                    $('#view_position_name').text(response.lead.position_name || '-');
                    if(response.lead.staff_id == 0) $('#view_staff_assigned').text('Staff Not Assigned')
                    else if(response.lead.staff_approval == 0) $('#view_staff_assigned').text('Waiting For Staff Approval').addClass('bg-warning')
                    else if(response.lead.staff_approval == 2) $('#view_staff_assigned').text('Rejected By Staff').addClass('bg-danger text-white')
                    else if(response.lead.pc_approval == 0) $('#view_staff_assigned').text('Waiting For PC Approval').addClass('bg-warning')
                    else if(response.lead.pc_approval == 2) $('#view_staff_assigned').text('Rejected By PC').addClass('bg-danger text-white')
                    else if(response.lead.delivery_status == 0) $('#view_staff_assigned').text('Waiting for Delivery').css({'background-color':' #4af3d4'})
                    else if(response.lead.delivery_status == 1) $('#view_staff_assigned').text('Delivered').addClass('bg-success')
                    else if(response.lead.delivery_status == 2) $('#view_staff_assigned').text('Delivery Cancelled').addClass('bg-danger text-white')
                    if (response.data.length > 0) {
                        response.data.forEach(function(requirement) {
                            let document_url=``;

                            if(requirement.document_url) {
                                document_url = `{{ asset('requirement_documents/') }}/${requirement.document_url}`; 
                            }
                                let studentRow = `

                                <tr>
                                    <td>
                                        ${requirement.requirement_doc_status == 1 ? 
                                            `<div class="badge bg-success rounded-circle border border-gray-500i fw-semibold">
                                                <i class="mdi mdi-check-all text-black fw-bold fs-5"></i>
                                            </div>`
                                        :
                                        `<div class="badge bg-danger rounded-circle border border-gray-500i fw-semibold fs-4">x</div>`
                                        }
                                    </td>
                                    <td>
                                        <div class="text-wrap max-w-100" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${requirement.requirement_name}">${requirement.requirement_name}</div>
                                    </td>
                                    <td class="text-center">
                                    ${document_url ?
                                    ` <a href="${document_url}" class="mb-0" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View Attachments" download>
                                            <span><i class="mdi mdi-download-circle-outline text-success fs-2"></i></span>
                                        </a>`
                                        : '-'}
                                    </td>
                                    <td>
                                    ${requirement.requirement_doc_status == 1 ? 
                                    ` <div class="badge bg-success fw-semibold fs-7 text-black">Requirement Accepted</div>`
                                        :
                                        ` <div class="text-black fw-semibold fs-7">${requirement.reason || '-'}</div>`
                                    } 
                                    </td>
                                </tr>
                                `;
                                studentTableBody.append(studentRow);
                            });
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Error fetching requirements.');
                }
            });
    }
</script>

<script>
    function staffApprovalView(id,type) {

            $('#requirement_id_approve').val(id);
            $('#requirement_approval_type').val(type);

            let studentTableBody = $('#kt_modal_requirements_accepted').find('#approval_table tbody');
            studentTableBody.empty();
        
            $.ajax({
                url: '/requirement_view/' + id, // Adjust with your route
                type: 'GET',
                success: function(response) {
                    $('#approval_lead_name').text(response.lead.lead_name);
                    $('#approval_lead_mobile').text(response.lead.lead_mobile);
                    $('#approval_service_category').text(response.lead.product_category_name || '-');
                    $('#approval_service').text(response.lead.product_name || '-');
                    $('#approval_staff_name').text(response.lead.staff_name || '-');
                    $('#approval_position_name').text(response.lead.position_name || '-');

                    if (response.data.length > 0) {
                        response.data.forEach(function(requirement) {
                            let document_url = requirement.document_url ? `{{ asset('requirement_documents/') }}/${requirement.document_url}` : '';
                            let isChecked = requirement.requirement_doc_status == '1' ? 'checked' : '';
                            let showTextarea = requirement.requirement_doc_status != '1';

                            let studentRow = `
                            <tr>
                                <input type="hidden" name="require_doc_id[]" value="${requirement.sno}" />
                                <td>
                                    <input 
                                        class="form-check-input bulk_chk" 
                                        type="checkbox" 
                                        name="chck_req_${requirement.sno}" 
                                        id="chck_req_${requirement.sno}" 
                                        data-sno="${requirement.sno}"
                                        ${isChecked}
                                    >
                                </td>
                                <td>
                                    <div class="text-wrap max-w-100" data-bs-toggle="tooltip" title="${requirement.requirement_name}">
                                        ${requirement.requirement_name}
                                    </div>
                                </td>
                                <td class="text-center">
                                    ${document_url ?
                                        `<a href="${document_url}" title="View Attachments" download>
                                            <i class="mdi mdi-download-circle-outline text-success fs-2"></i>
                                        </a>` : '-'}
                                </td>
                                <td>
                                   <div class="badge bg-success fw-semibold fs-7 text-black " id="accept_req_${requirement.sno}"   style="${!showTextarea ? '' : 'display:none;'}">Requirement Accepted</div>
                                    <textarea 
                                        class="form-control reason_textarea" 
                                        name="reason_req_${requirement.sno}" 
                                        id="reason_req_${requirement.sno}" 
                                        rows="2" 
                                        placeholder="Enter Reason"
                                        style="${showTextarea ? '' : 'display:none;'}"
                                    >${requirement.reason || ''}</textarea>
                                </td>
                            </tr>
                            `;
                            studentTableBody.append(studentRow);
                        });

                        // Attach checkbox change handler
                        $('.bulk_chk').on('change', function () {
                            let sno = $(this).data('sno');
                            let reasonField = $(`#reason_req_${sno}`);
                            let acceptField = $(`#accept_req_${sno}`);
                            if ($(this).is(':checked')) {
                                reasonField.hide().val('');
                                acceptField.show();
                            } else {
                                reasonField.show();
                                acceptField.hide();
                            }
                        });
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Error fetching requirements.');
                }
            });
    }

    function staffRejectView(id,type,name,mobile){
        $('#requirement_id_reject').val(id);
        $('#requirement_reject_approval_type').val(type);
        $('#reject_lead').text(name);
        $('#reject_mobile').text(mobile);
        $('#reject_approval_type').val(type);
    }

    function staffCancelView(id,type,name,mobile){
        $('#requirement_id_cancelled').val(id);
        $('#requirement_cancelled_type').val(type);
        $('#cancel_lead').text(name);
        $('#cancel_mobile').text(mobile);
    }

    
    function staffAcceptView(id,type,name,mobile){
        $('#requirement_id_accept').val(id);
        $('#requirement_accept_type').val(type);
        $('#accept_lead').text(name);
        $('#accept_mobile').text(mobile);
    }

    
    function toggleInputField_reject(value) {
      var rejectReasonDiv = document.getElementById('reject_reason_div');
      var rejectReasonText = document.getElementById('reject_reason_text');
      var rejectCommentsDiv = document.getElementById('reject_comments_div');
      var selectedOption = document.querySelector('#reason_reject_select option:nth-child(' + (document.getElementById('reason_reject_select').selectedIndex + 1) + ')');
      var commentsCheck = selectedOption ? selectedOption.getAttribute('data-comments-check') : null;

      if (value == '1') {
          rejectReasonDiv.style.display = 'block';
          rejectReasonText.setAttribute('required', 'required');
      } else {
          rejectReasonDiv.style.display = 'none';
          rejectReasonText.removeAttribute('required');
      }

      if (commentsCheck == '1') {
          rejectCommentsDiv.style.display = 'block';
      } else {
          rejectCommentsDiv.style.display = 'none';
      }
   }

   function requirementReject() {
        var err=0;
          // Validate the reason selection
          const reason = $('#reason_reject_select').val();
          const otherReason = $('#reject_reason_text').val();
          const comments = $('#reject_comments_text').val();

          if (!reason) {
              $('#reason_reject_select_err').text('Reason is Required');
               err++;
          }else {
              $('#reason_reject_select_err').text('');
          }
          // Check if the selected reason's comments_check is 1 before validating comments
          const selectedReasonOption = $('#reason_reject_select option:selected');
          const commentsCheck = selectedReasonOption.data('comments-check');

          if (commentsCheck == 1 && (!comments || comments.trim() === "")) {
              $('#reject_comments_text_err').text('Comments are required');
             err++;
          }else {
              $('#reject_comments_text_err').text('');
          }

          if (reason == '1' && !otherReason.trim()) {
              $('#reject_reason_text_err').text('Other Reason is required');
             err++;
          }else {
              $('#reject_reason_text_err').text('');
          }

          if(err==0){
                $('#rejectBtn').prop('disabled', true);
                $('#rejectForm').submit();
            }else{
                $('#rejectBtn').prop('disabled', false);
            }

      
  }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "paging":false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    $(".list_page_1").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-12 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

<script>
    document.querySelectorAll('[data-bs-dismiss="modal"]').forEach(function(el) {
    el.addEventListener('click', function () {
      setTimeout(() => {
        location.reload();
      }, 150);
    });
  });
</script>
@endsection