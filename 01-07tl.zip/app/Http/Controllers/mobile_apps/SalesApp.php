<?php

namespace App\Http\Controllers\mobile_apps;

use App\Http\Controllers\Controller;
use App\Mail\ETPLMail;
use App\Models\ChatModel;
use App\Models\CustomerModel;
use App\Models\EmailTemplateModel;
use App\Models\ManageTickickModel;
use App\Models\CugManagementModel;
use App\Models\OtpModel;
use App\Models\SmsTemplateModel;
use App\Models\StaffModel;
use App\Models\LeadModel;
use App\Models\LeadSourceModel;
use App\Models\ProductModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\AppointmentModel;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Laravel\Sanctum\PersonalAccessToken;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;
use App\Models\FollowupReasonModel;

class SalesApp extends Controller
{
    public function StaffLogin(Request $request)
    {

        $mobile_no = $request->mobile_no;
        $key      = $request->key ? $request->key : 'null';

        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required|max:255',
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => 422, 'message' => 'Validation Error', 'error_msg' => $validator->errors(), 'data' => null], 422);
        } else {

            // $user = StaffModel::where('mobile_no', $mobile_no)->where('status', 0)->first();
            $staffuser = CugManagementModel::where('staff_mobile', $mobile_no)->where('status', 0)->first();
            
            // return $staffuser;
            if ($staffuser) {
                $user = StaffModel::where('sno', $staffuser->staff_id)->where('status', 0)->first();
                // return $user;

                if( $mobile_no == "9790464324"){
                    $otp_value  = 123456; // Random 6-digit OTP
                }else{
                    $otp_value  = rand(100000, 999999); // Random 6-digit OTP
                } // Random 6-digit OTP

                // Save OTP to Database
                
                $otp = new OtpModel();

                $otp->user_id                  = $user->sno;
                $otp->user_from                =  $mobile_no;
                $otp->otp_number               = $otp_value;
                $otp->otp_check               = 0;
                $otp->created_by               = $user->sno;
                $otp->updated_by               = $user->sno;
                $otp->save();
                // sms otp 
                 if( $mobile_no != "9790464324"){
                    // if ($otp_value) {

                    //     $result_sms      = SmsTemplateModel::where('status', 0)->where('template_name', '009_ClassmateLoginOTP')->first();
                    //     $authkey         = $result_sms ? $result_sms->authkey : '';
                    //     $sender_id       = $result_sms ? $result_sms->sender_id : '';
                    //     $template_id     = $result_sms ? $result_sms->template_id : '';
                    //     $country_code    = $result_sms ? $result_sms->country_code : '';
                    //     $message_content = $result_sms ? $result_sms->sms_template_messagecontent : '';
                    //     $mobile_number   = $country_code . $mobile_no;

                    //     $app_name = "Sales App";
                    //     // $app_link = 'https://elysiumacademy.org/';
                    //     $app_code = "8dc%2BJrcYXcg";
                    //     // Replace placeholders with actual values
                    //     $replacement_values = [$user->cus_name, $app_name, $otp_value,$app_code];
                    //     $message_content    = preg_replace_callback(
                    //         '/\{#var#\}/',
                    //         function () use (&$replacement_values) {
                    //             return array_shift($replacement_values);
                    //         },
                    //         $message_content
                    //     );

                    //     $route    = "default";
                    //     $postData = [
                    //         'authkey' => $authkey,
                    //         'mobiles' => $mobile_number,
                    //         'message' => $message_content,
                    //         'sender'  => $sender_id,
                    //         'route'   => $route,
                    //     ];

                    //     // API URL
                    //     $url = "https://api.msg91.com/api/sendhttp.php?authkey=$authkey&sender=$sender_id&route=$route&message=" . urlencode($message_content) . "&mobiles=$mobile_number&DLT_TE_ID=$template_id";

                    //     // Initialize the resource
                    //     $ch = curl_init();
                    //     curl_setopt_array($ch, [
                    //         CURLOPT_URL            => $url,
                    //         CURLOPT_RETURNTRANSFER => true,
                    //         CURLOPT_POST           => true,
                    //         CURLOPT_POSTFIELDS     => $postData,
                    //         CURLOPT_SSL_VERIFYHOST => 0,
                    //         CURLOPT_SSL_VERIFYPEER => 0,
                    //     ]);

                    //     // Get response
                    //     $response = curl_exec($ch);
                    //     // return $response;
                    //     $err = curl_error($ch);
                    //     curl_close($ch);
                    // }
                 }
                $usertable = User::where('user_id', $user->sno)->first();
                $token     = $usertable->createToken('authToken')->accessToken;
                $roleId    = UserRoleModel::where('status', 0)->where('sno', $user->role_id)->first();
                $check     = UserRoleModel::where('status', 0)->get();
                // $underRole = $check->contains('user_role_id', $roleId->sno) ? 'Yes' : 'No';
                $underRole =  'Yes';
                // $check = UserRoleModel::where('status', 0)->first();
                // $underRole = $check && $check->sno == $roleId->sno ? 'Yes' : 'No';
                $baseUrl = 'https://erp.elysium.academy/staff_images/';
                // return $roleId;
                return response()->json([
                    'otp'        => $otp_value,
                    'status'     => strval($user->status),
                    'staff_id'   => $user->sno,
                    'Gender'   => $user->gender,
                    'UnderRole'  => $underRole,
                    'staff_name'   => $user->staff_name,
                    'staff_image'       => $user->staff_image ?  url('/staff_images').'/'. $user->staff_image : null,
                    'message'    => 'Successfully',
                    "error_msg"  => null,
                    'data'       => null,
                ], 200);
            } else {
                $response = [
                    'status' => "2",
                    'message' => 'User does not exist',
                    "error_msg" => null,
                    'data' => null
                ];
                return response($response, 200);
            }
        }
    }

    public function verifyOtp(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'mobile_no' => 'required',
            'otp'       => 'required',
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'status'  => false,
                'message' => 'Validation Error',
                'errors'  => $validator->errors()
            ], 422);
        }
    
        $mobile_no = $request->mobile_no;
        $otpInput  = $request->otp;
    
        // Get latest OTP for this user
        $otpRecord = OtpModel::where('user_from', $mobile_no)->where('otp_number', $otpInput)
                    ->latest()
                    ->first();
                    // return $otpRecord;
    
        if (!$otpRecord) {
            return response()->json([
                'status'  => false,
                'message' => 'No OTP found for this number.'
            ], 404);
        }
       // Ensure both times are in UTC and properly compare
        $createdAt = Carbon::parse($otpRecord->created_at)->setTimezone('UTC');
        $expiryTime = $createdAt->copy()->addMinutes(2);
        $currentTime = Carbon::now('UTC');
    
        if ($currentTime->greaterThan($expiryTime)) {
            return response()->json([
                'status'  => false,
                'message' => 'OTP expired. Please request a new one.'
            ], 410);
        }

    
        // Match OTP
        if ($otpRecord->otp_number != $otpInput) {
            return response()->json([
                'status'  => false,
                'message' => 'Invalid OTP.'
            ], 401);
        }

        $staff_id = $otpRecord->user_id;

        $user = User::select('users.*', 'et_staff.status as staff_status')
            ->where('users.user_id', $staff_id)
            ->leftJoin('et_staff', 'users.user_id', '=', 'et_staff.sno')
            ->where('et_staff.status', 0)
            ->first();

        if ($user->staff_status == 1) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is inactive. Please contact the administrator.',
                'error_msg'=>'This user is inactive. Please contact the administrator.',
                'data' => NULL
            ]);
        } elseif ($user->staff_status == 2) {
            return response()->json([
                'status' => 403,
                'message' => 'This user is deactivated. Please contact the administrator.',
                'error_msg'=>'This user is deactivated. Please contact the administrator.',
                'data' => NULL
            ]);
        }

          $secret_key = env('JWT_SECRET', 'ETPL_PhDIzone_SalesApp_2026'); // Add JWT_SECRET in .env
            $issuer_claim = "Sales App"; // this can be your app name
            $audience_claim = "Sales-app";
            $issued_at = time();
            $expiry_time_jwt = $issued_at + (60*60*168); // 7 day expiry, 
            

            $payload = [
                "iss" => $issuer_claim,
                "aud" => $audience_claim,
                "iat" => $issued_at,
                "exp" => $expiry_time_jwt,
                "staff_sno" => $staff_id
            ];

            $jwt_token = JWT::encode($payload, $secret_key, 'HS256');

            

          

            $token = new PersonalAccessToken();
            $token->forceFill([
                'tokenable_type' => \App\Models\User::class,
                'tokenable_id'   => $user->id,
                'name'           => 'jwt_token',
                'token'          => hash('sha256', $jwt_token),
                'abilities'      => ['*'],
                'expires_at'     => Carbon::createFromTimestamp($expiry_time_jwt),
            ])->save();
    
        return response()->json([
            'status'  => true,
            'message' => 'OTP verified successfully!',
            'user_id' => $otpRecord->user_id,
            'jwt_token' => $jwt_token
        ], 200);
    }

   

    public function staffDetails(Request $request)
    {
        $user = $request->user();
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

            $data =  StaffModel::where('et_staff.status', '!=', 2)
            ->select('et_staff.*',
            'et_department.department_name',
            'et_division.division_name',
            'et_job_position.job_position_name as job_role_name',
            )
            ->join('et_department', 'et_staff.department_id', 'et_department.sno')
            ->join('et_division', 'et_staff.sub_department_id', 'et_division.sno')
            ->join('et_job_position', 'et_staff.position_role', 'et_job_position.sno')
            ->where('et_staff.sno', $user->user_id)
            ->first();
          
                if ($data->gender == 1) {
                    $defaultPath = asset('assets/phdizone_images/auth/user_2.png');
                } else {
                    $defaultPath = asset('assets/phdizone_images/auth/user_7.png');
                }
                if ($data->staff_image) {
                    $relativePath = 'staff_images/' . $data->staff_image;
                } 
                //  Correct physical path
                $fullPath = public_path($relativePath);
                //  Correct URL
                $filePath = asset($relativePath);
                //  Proper check
                $isStaffImage = ($data->staff_image && file_exists($fullPath)) ? 1 : 0;

            $staffImageUrl = $isStaffImage ? $filePath : $defaultPath;
            
            $staffData =[
                "id"=>$data->sno,
                "staff_name"=>$data->staff_name,
                "nick_name"=>$data->nick_name ?? '',
                "staff_image"=>$staffImageUrl ?? '',
                "mobile_no"=>$data->mobile_no ?? '',
                "email_id"=>$data->email_id ?? '',
                "department_name"=>$data->department_name ?? '',
                "division_name"=>$data->division_name ?? '',
                "job_role_name"=>$data->job_role_name ?? '', 
                
            ];

        return response()->json([
            'status' => 200,
            'message' => 'Staff data fetched successfully',
            'error_msg' => null,
            'data' => $staffData
        ]);
    }
    
     public function LeadList(Request $request)
    {
        $user = $request->user();
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

            $page = max((int)$request->page, 1);
            $limit = min(max((int)$request->limit, 10), 100);

            $leads = LeadModel::select(
                'et_lead.sno',
                'et_lead.lead_id',
                'et_lead.is_hot_lead',
                'et_lead.created_at',
                'et_lead.created_by',
                'et_lead.registered_date',
                'et_lead.lead_mobile',
                'et_lead.spam_verified',
                'et_lead.drop_verified',
                'et_lead.spam_tl_verified',
                'et_lead.drop_tl_verified',
                'et_lead.lead_email_id',
                'et_staff.staff_name',
                'et_lead.status',
                'et_lead.lead_name',
                'et_lead_source.lead_source_name'
            )
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.created_by', $user->user_id)
            ->whereIn('et_lead.status', [0,1,4,5,7,10]);

            if ($request->filled('search')) {
                $search = $request->search;
                $leads->where(function ($query) use ($search) {
                    $query->where('et_lead.lead_name', 'like', "%{$search}%")
                        ->orWhere('et_lead.lead_mobile', 'like', "%{$search}%")
                        ->orWhere('et_lead.lead_email_id', 'like', "%{$search}%")
                        ->orWhere('et_lead.lead_id', 'like', "%{$search}%");
                });
            }

            if ($request->filled('status')) {
                $leads->where('et_lead.status', $request->status);
            }

            if ($request->filled('lead_source_id')) {
                $leads->where('et_lead.lead_source_id', $request->lead_source_id);
            }
            if ($request->filled('product_id')) {
                $leads->whereJsonContains('et_lead.service_id', $request->product_id);
            }

            if ($request->filled('from_date') && $request->filled('to_date')) {
                $leads->whereBetween('et_lead.created_at', [$request->from_date . ' 00:00:00', $request->to_date . ' 23:59:59']);
            } elseif ($request->filled('from_date')) {
                $leads->where('et_lead.created_at', '>=', $request->from_date . ' 00:00:00');
            } elseif ($request->filled('to_date')) {
                $leads->where('et_lead.created_at', '<=', $request->to_date . ' 23:59:59');
            }

            if ($request->filled('is_hot_lead')) {
                $leads->where('et_lead.is_hot_lead', $request->is_hot_lead);
            }

            $leads = $leads->paginate($limit, ['*'], 'page', $page);

            $leadItems = collect($leads->items());

                $phones = [];

                foreach ($leadItems as $lead) {

                    $mobile = ltrim($lead->lead_mobile, '0');

                    $phones[] = $lead->lead_mobile;
                    $phones[] = '+91' . $mobile;
                }

            $callData = DB::table('et_call_tracker')
            ->select(
                'customer_phone_no',
                DB::raw('MAX(call_start_date) as last_call_date')
            )
            ->whereIn('customer_phone_no', $phones)
            ->groupBy('customer_phone_no')
            ->get()
            ->keyBy('customer_phone_no');
               $data = $leadItems->map(function ($item) use ($callData) {

                    $mobile = $item->lead_mobile;
                    $mobile91 = '+91' . ltrim($mobile, '0');

                    $lastCallDate = null;

                    if(isset($callData[$mobile])) {
                        $lastCallDate = $callData[$mobile]->last_call_date;
                    } elseif(isset($callData[$mobile91])) {
                        $lastCallDate = $callData[$mobile91]->last_call_date;
                    }

                    $lead_status = 'Active';
                    $status_color = 'Active';
                    if( $item->status == 0){
                         $lead_status = 'Active';
                        $status_color = 'bg-info';
                    }
                    elseif($item->status == 1){
                        $lead_status = 'In Active';
                        $status_color = 'bg-warning';
                    }
                    elseif( $item->status == 4){
                        $lead_status = 'Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($item->status == 10){
                        $lead_status = 'Old Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($item->status == 5 && ($item->drop_verified == 0 || $item->drop_tl_verified == 0)){
                        $lead_status = 'Dead Lead Awaiting';
                        $status_color = 'bg-danger';
                    }
                    elseif($item->status == 7 && ($item->spam_verified == 0 || $item->spam_tl_verified == 0)){
                        $lead_status = 'Spam Awaiting';
                        $status_color = 'bg-primary';
                    }

                    return [
                        'lead_id'         => $item->sno,
                        'status_code'          => $item->status,
                        'lead_name'       => $item->lead_name,
                        'lead_mobile'     => $item->lead_mobile,
                        'lead_email_id'   => $item->lead_email_id,
                        'is_hot_lead'     => $item->is_hot_lead,
                        'last_call_date'  => $lastCallDate,
                        'created_at'      => $item->created_at,
                        'sales_staff'     => $item->staff_name,
                        'source_name'     => $item->lead_source_name,
                        'registered_date' => $item->registered_date,
                        'status_color' => $status_color,
                        'lead_status' => $lead_status,
                    ];
                });

            

        return response()->json([
            'status' => 200,
            'message' => 'Staff data fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $leads->currentPage(),
                'per_page' => $leads->perPage(),
                'total' => $leads->total(),
                'last_page' => $leads->lastPage(),
                'has_more' => $leads->hasMorePages()
            ]
        ]);
    }

    public function LeadDetail(Request $request)
    {
        $user = $request->user();
        $lead_id = $request->lead_id;
          
        $staff = StaffModel::where('sno', $user->user_id)->first();
      
        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }
        if (!$lead_id) {
            return response()->json([
                'status' => 404,
                'message' => 'Lead Id is required',
                'error_msg' => 'Lead Id is required',
                'data' => null
            ]);
        }
            $leadData = LeadModel::select(
                'et_lead.sno',
                'et_lead.lead_id',
                'et_lead.is_hot_lead',
                'et_lead.created_at',
                'et_lead.created_by',
                'et_lead.registered_date',
                'et_lead.lead_mobile',
                'et_lead.spam_verified',
                'et_lead.drop_verified',
                'et_lead.spam_tl_verified',
                'et_lead.drop_tl_verified',
                'et_lead.lead_email_id',
                'et_staff.staff_name',
                'et_lead.status',
                'et_lead.lead_name',
                'et_lead.lead_comments',
                'et_lead.pincode',
                'et_lead.address',
                'et_lead.door_no',
                'et_lead.service_id',
                'et_lead_source.lead_source_name',
                'et_cities.name as city_name', 
                'et_countries.name as country_name', 
                'et_states.name as state_name'
            )
            ->leftJoin('et_staff', 'et_lead.created_by', '=', 'et_staff.sno')
            ->leftJoin('et_lead_source', 'et_lead.lead_source_id', '=', 'et_lead_source.sno')
            ->leftJoin('et_cities', 'et_cities.id', '=', 'et_lead.city')
            ->leftJoin('et_states', 'et_states.id', '=', 'et_lead.state')
            ->leftJoin('et_countries', 'et_lead.country', '=', 'et_countries.id')
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_lead.sno', $lead_id)
            ->first();

            if (!$leadData) {
                return response()->json([
                    'status' => 404,
                    'message' => 'Lead Not Found',
                    'error_msg' => 'Lead Not Found',
                    'data' => null
                ]);
            }


        

                $phones = [];

                    $mobile = ltrim($leadData->lead_mobile, '0');

                    $phones[] = $leadData->lead_mobile;
                    $phones[] = '+91' . $mobile;
              

                    $callData = DB::table('et_call_tracker')
                        ->select(
                            'customer_phone_no',
                            DB::raw('MAX(call_start_date) as last_call_date')
                        )
                        ->whereIn('customer_phone_no', $phones)
                        ->groupBy('customer_phone_no')
                        ->get()
                        ->keyBy('customer_phone_no');
              

                    $mobile = $leadData->lead_mobile;
                    $mobile91 = '+91' . ltrim($mobile, '0');

                    $lastCallDate = null;

                    if(isset($callData[$mobile])) {
                        $lastCallDate = $callData[$mobile]->last_call_date;
                    } elseif(isset($callData[$mobile91])) {
                        $lastCallDate = $callData[$mobile91]->last_call_date;
                    }

                    $lead_status = 'Active';
                    $status_color = 'Active';
                    if( $leadData->status == 0){
                         $lead_status = 'Active';
                        $status_color = 'bg-info';
                    }
                    elseif($leadData->status == 1){
                        $lead_status = 'In Active';
                        $status_color = 'bg-warning';
                    }
                    elseif( $leadData->status == 4){
                        $lead_status = 'Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($leadData->status == 10){
                        $lead_status = 'Old Customer';
                        $status_color = 'bg-success';
                    }
                    elseif($leadData->status == 5 && ($leadData->drop_verified == 0 || $leadData->drop_tl_verified == 0)){
                        $lead_status = 'Dead Lead Awaiting';
                        $status_color = 'bg-danger';
                    }
                    elseif($leadData->status == 7 && ($leadData->spam_verified == 0 || $leadData->spam_tl_verified == 0)){
                        $lead_status = 'Spam Awaiting';
                        $status_color = 'bg-primary';
                    }
                  
                    $service_ids =$leadData->service_id ? json_decode($leadData->service_id ) : [];
            $address = ( $leadData->door_no ? $leadData->door_no.", ":"" ).''.( $leadData->area_street ? $leadData->area_street.", ":"" ).''.( $leadData->city_name ? $leadData->city_name.", ":"" ).''.($leadData->state_name ? $leadData->state_name:"" ).''.( $leadData->pincode ? " - ".$leadData->pincode:"" );
            $product_tags = DB::table('et_product')->whereIn('sno',$service_ids)->pluck('product_name');
            $data =[
                'lead_id'         => $leadData->sno,
                'status_code'          => $leadData->status,
                'lead_name'       => $leadData->lead_name,
                'lead_mobile'     => $leadData->lead_mobile,
                'lead_email_id'   => $leadData->lead_email_id,
                'is_hot_lead'     => $leadData->is_hot_lead,
                'last_call_date'  => $lastCallDate,
                'created_at'      => $leadData->created_at,
                'sales_staff'     => $leadData->staff_name,
                'source_name'     => $leadData->lead_source_name,
                'registered_date' => $leadData->registered_date,
                'status_color' => $status_color,
                'lead_status' => $lead_status,
                'notes' => $leadData->lead_comments,
                'address' => $address,
                'product_tags' => $product_tags,
                
            ];

        return response()->json([
            'status' => 200,
            'message' => 'Lead data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function leadSourceList(Request $request)
    {
        $leadSource = LeadSourceModel::select('sno', 'lead_source_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Lead source list fetched successfully',
            'error_msg' => null,
            'data' => $leadSource
        ], 200);
    }

    public function productList(Request $request)
    {
        $products = ProductModel::select('sno', 'product_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Product list fetched successfully',
            'error_msg' => null,
            'data' => $products
        ], 200);
    }

    public function FollowupList(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $page = max((int)$request->page, 1);
        $limit = min(max((int)$request->limit, 10), 100);

        $followups = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.lead_id as ld_name_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_appointment.created_at',
                'et_lead.lead_name',
                'et_lead.lead_mobile',
                'et_lead.lead_email_id',
                'et_lead.lead_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1);

        if ($request->filled('search')) {
            $search = $request->search;
            $followups->where(function ($query) use ($search) {
                $query->where('et_lead.lead_name', 'like', "%{$search}%")
                    ->orWhere('et_lead.lead_mobile', 'like', "%{$search}%")
                    ->orWhere('et_lead.lead_email_id', 'like', "%{$search}%")
                    ->orWhere('et_staff.staff_name', 'like', "%{$search}%")
                    ->orWhere('et_staff.nick_name', 'like', "%{$search}%");
            });
        }

        if ($request->filled('from_date') && $request->filled('to_date')) {
            $followups->whereBetween('et_appointment.appointment_date', [$request->from_date, $request->to_date]);
        } elseif ($request->filled('from_date')) {
            $followups->where('et_appointment.appointment_date', '>=', $request->from_date);
        } elseif ($request->filled('to_date')) {
            $followups->where('et_appointment.appointment_date', '<=', $request->to_date);
        }

        if ($request->filled('status')) {
            $followups->where('et_appointment.status', $request->status);
        }

        $followups = $followups->orderBy('et_appointment.sno', 'desc')->paginate($limit, ['*'], 'page', $page);

        $followupItems = collect($followups->items());

        $data = $followupItems->map(function ($item) {
            $followup_status = 'Followup Pending';
            $followup_status_color = 'bg-warning';
            if ($item->appointment_status == 1) {
                $followup_status = 'Followup Pending';
                $followup_status_color = 'bg-warning';
            } elseif ($item->appointment_status == 4) {
                $followup_status = 'Completed';
                $followup_status_color = 'bg-success';
            } elseif ($item->appointment_status == 3) {
                $followup_status = 'Cancelled';
                $followup_status_color = 'bg-danger';
            }

            $lead_status = 'Active';
            $lead_status_color = 'Active';
            if ($item->lead_status == 0) {
                $lead_status = 'Active';
                $lead_status_color = 'bg-info';
            } elseif ($item->lead_status == 1) {
                $lead_status = 'In Active';
                $lead_status_color = 'bg-warning';
            } elseif ($item->lead_status == 4) {
                $lead_status = 'Customer';
                $lead_status_color = 'bg-success';
            } elseif ($item->lead_status == 10) {
                $lead_status = 'Old Customer';
                $lead_status_color = 'bg-success';
            }

            return [
                'followup_id'         => $item->sno,
                'lead_id'             => $item->ld_name_id,
                'lead_name'           => $item->lead_name,
                'lead_mobile'         => $item->lead_mobile,
                'lead_email_id'       => $item->lead_email_id,
                'lead_status_code'    => $item->lead_status,
                'lead_status'         => $lead_status,
                'lead_status_color'   => $lead_status_color,
                'appointment_date'    => $item->appointment_date,
                'appointment_time'    => $item->appointment_time,
                'followup_status'     => $followup_status,
                'followup_status_color' => $followup_status_color,
                'appointment_status'  => $item->appointment_status,
                'appointment_reason'  => $item->appointment_reason,
                'sales_staff'         => $item->staff_name,
                'created_at'          => $item->created_at,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => 'Followup list fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $followups->currentPage(),
                'per_page' => $followups->perPage(),
                'total' => $followups->total(),
                'last_page' => $followups->lastPage(),
                'has_more' => $followups->hasMorePages()
            ]
        ]);
    }

    public function FollowupAdd(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'lead_id' => 'required',
            'appointment_date' => 'required|date',
            'appointment_time' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $lead_id = $request->lead_id;
        $appointment_date = $request->appointment_date;
        $appointment_time = $request->appointment_time;
        $reason = $request->reason ?? '';

        $followupPending = AppointmentModel::where('lead_id',$lead_id)
            ->where('appointment_date',$appointment_date)
            ->where('appointment_time',$appointment_time)
            ->where('status',1)
            ->first();
        if($followupPending){
            return response()->json([
                'status' => 404,
                'message' => 'Followup already exists',
                'error_msg' => 'Followup already exists',
                'data' => null
            ]);
        }

        $lead = LeadModel::where('sno', $lead_id)->where('internal_status', '!=', 1)->first();
        if (!$lead) {
            return response()->json([
                'status' => 404,
                'message' => 'Lead not found',
                'error_msg' => 'Lead not found',
                'data' => null
            ]);
        }

        $followup = new AppointmentModel();
        $followup->lead_id = $lead_id;
        $followup->appointment_date = $appointment_date;
        $followup->appointment_time = $appointment_time;
        // $followup->reason = $reason;
        $followup->created_by = $user->user_id;
        $followup->updated_by = $user->user_id;
        $followup->branch_id = $staff->branch_id ?? 1;
        $followup->status = 1;
        $followup->save();

        return response()->json([
            'status' => 200,
            'message' => 'Followup added successfully',
            'error_msg' => null,
                'data' => [
                    'followup_id' => $followup->sno,
                    'lead_id' => $followup->lead_id,
                    'appointment_date' => $followup->appointment_date,
                    'appointment_time' => $followup->appointment_time,
                    // 'reason' => $followup->reason,
                ]
            ], 200);
    }

    public function followupReasonList(Request $request)
    {
        $reasonList = FollowupReasonModel::select('sno', 'reason_name')
            ->where('status', 0)
            ->orderBy('sno', 'desc')
            ->get();

        return response()->json([
            'status' => 200,
            'message' => 'Followup reason list fetched successfully',
            'error_msg' => null,
            'data' => $reasonList
        ], 200);
    }

    public function FollowupDetail(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'followup_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $followup_id = $request->followup_id;

        $followupData = DB::table('et_appointment')
            ->select(
                'et_appointment.sno',
                'et_appointment.lead_id',
                'et_appointment.appointment_date',
                'et_appointment.appointment_time',
                'et_appointment.status as appointment_status',
                'et_appointment.reason as appointment_reason',
                'et_appointment.created_by as staff_id',
                'et_appointment.created_at',
                'et_lead.lead_name',
                'et_lead.lead_mobile',
                'et_lead.lead_email_id',
                'et_lead.lead_id as lead_unique_id',
                'et_lead.status as lead_status',
                'et_staff.staff_name'
            )
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->join('et_staff', 'et_appointment.created_by', '=', 'et_staff.sno')
            ->where('et_appointment.sno', $followup_id)
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->first();

        if (!$followupData) {
            return response()->json([
                'status' => 404,
                'message' => 'Followup not found',
                'error_msg' => 'Followup not found',
                'data' => null
            ]);
        }

        $followup_status = 'Followup Pending';
        $followup_status_color = 'bg-warning';
        if ($followupData->appointment_status == 1) {
            $followup_status = 'Followup Pending';
            $followup_status_color = 'bg-warning';
        } elseif ($followupData->appointment_status == 4) {
            $followup_status = 'Completed';
            $followup_status_color = 'bg-success';
        } elseif ($followupData->appointment_status == 3) {
            $followup_status = 'Cancelled';
            $followup_status_color = 'bg-danger';
        }

        $lead_status = 'Active';
        $lead_status_color = 'Active';
        if ($followupData->lead_status == 0) {
            $lead_status = 'Active';
            $lead_status_color = 'bg-info';
        } elseif ($followupData->lead_status == 1) {
            $lead_status = 'In Active';
            $lead_status_color = 'bg-warning';
        } elseif ($followupData->lead_status == 4) {
            $lead_status = 'Customer';
            $lead_status_color = 'bg-success';
        } elseif ($followupData->lead_status == 10) {
            $lead_status = 'Old Customer';
            $lead_status_color = 'bg-success';
        }

        $data = [
            'followup_id' => $followupData->sno,
            'lead_id' => $followupData->lead_id,
            'lead_unique_id' => $followupData->lead_unique_id,
            'lead_name' => $followupData->lead_name,
            'lead_mobile' => $followupData->lead_mobile,
            'lead_email_id' => $followupData->lead_email_id,
            'lead_status_code' => $followupData->lead_status,
            'lead_status' => $lead_status,
            'lead_status_color' => $lead_status_color,
            'appointment_date' => $followupData->appointment_date,
            'appointment_time' => $followupData->appointment_time,
            'followup_status' => $followup_status,
            'followup_status_color' => $followup_status_color,
            'appointment_status' => $followupData->appointment_status,
            'appointment_reason' => $followupData->appointment_reason,
            'sales_staff' => $followupData->staff_name,
            'created_at' => $followupData->created_at,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Followup data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

   
    public function FollowupCloseOld(Request $request)
  {
    
    $user = $request->user();

    $staff = StaffModel::where('sno', $user->user_id)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ]);
    }

    $validator = Validator::make($request->all(), [
        'followup_id' => 'required|integer',
        'progressed' => 'required|max:255',
        'reason' => 'nullable|string',
        'convo_message' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status' => 422,
            'message' => 'Validation Error',
            'error_msg' => $validator->errors(),
            'data' => null
        ], 422);
    }else {

      //   return $request;
      $followup_id       = $request->followup_id;
      $progressed       = $request->progressed;
      $reason_appt      = $request->reason;
      $appointment_time       = $request->appointment_time;
      $app_score          = $request->app_score ?? 0;
      $follow_through            = $request->follow_through ?? 0;

      $hot_lead            = $request->hot_lead;
      $pb            = $request->pb ?? 0;
      $user_id            = $request->user()->user_id;
      $branch_id            = $request->user()->branch_id;
      $appointment_date = DateTime::createFromFormat('d-M-Y', $request->appointment_date);
      if ($progressed == 1) {
        $upd_followup = AppointmentModel::where('sno', $followup_id)->first();

        if (!$followup) {
            return response()->json([
                'status' => 404,
                'message' => 'Followup not found',
                'error_msg' => 'Followup not found',
                'data' => null
            ]);
        }

        $upd_followup->progressed                 = $progressed;
        // $upd_followup->app_score                  = $request->app_score;
        $upd_followup->follow_through                  = $request->follow_through;
        $upd_followup->convo_message              = $request->convo_message;
        $upd_followup->status                     = 4;
        // return $upd_followup;
        $upd_followup->update();
      } else {
        $category_check = AppointmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
        if (!$category_check) {

          $year = substr(date("y"), -2);
          $appointment_id = "AP-0001/" . $year;
        } else {

          $data = $category_check->appointment_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("AP-%04d", $next_number);

          $year = substr(date("y"), -2);
          $appointment_id = $request . '/' . $year;
        }

         $upd_followup = AppointmentModel::where('sno', $followup_id)
                        ->where('status', 1)
                        ->where(function ($query) {
                            $query->where('progressed', 0)
                            ->orWhere('progressed', 2);
                        })
                        ->orderBy('sno', 'desc')
                        ->first();
        if ($upd_followup) {
          $upd_followup->status = 5;
          $upd_followup->reason = $reason_appt;
          $upd_followup->update();
        }



        $upd_lead = new AppointmentModel();
        $upd_lead->appointment_id           = $appointment_id;
        $upd_lead->lead_id                  = $id;
        $upd_lead->branch_id                = $branch_id;
        $upd_lead->progressed               = $progressed;
        $upd_lead->app_score                = $app_score;
        $upd_lead->follow_through                = $follow_through;
        $upd_lead->appointment_date         = $appointment_date;
        $upd_lead->appointment_time         = $appointment_time;
        $upd_lead->status                   = 1;
        $upd_lead->created_by               = $user_id;
        $upd_lead->updated_by               = $user_id;
        //  return $upd_lead;
        $upd_lead->save();
      }
      
      return response()->json([
            'status' => 200,
            'message' => 'Followup Updated successfully',
            'error_msg' => null,
        ]);
    }
  }

  public function FollowupClose(Request $request)
{
    $user = $request->user();

    $staff = StaffModel::find($user->user_id);
    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found',
            'error_msg' => 'Staff not found',
            'data' => null
        ],404);
    }
    $validator = Validator::make($request->all(), [

        'followup_id'      => 'required|integer|exists:appointment,sno',
        'progressed'       => 'required|in:0,1',

        // required only while rescheduling
        'appointment_date' => 'required_if:progressed,0|date_format:d-M-Y',
        'appointment_time' => 'required_if:progressed,0',

        'reason'           => 'nullable|string|max:500',
        'convo_message'    => 'nullable|string',
        // 'app_score'        => 'nullable|numeric',
        // 'follow_through'   => 'nullable|numeric',
        // 'hot_lead'         => 'nullable',
        // 'pb'               => 'nullable'
    ]);

    if ($validator->fails()) {

        return response()->json([
            'status'=>422,
            'message'=>'Validation Error',
            'error_msg'=>$validator->errors(),
            'data'=>null
        ],422);

    }

    DB::beginTransaction();

    try {
        $followup = AppointmentModel::where('sno',$request->followup_id)
            ->where('branch_id',$user->branch_id)
            ->lockForUpdate()
            ->first();
        if(!$followup){
            DB::rollBack();
            return response()->json([
                'status'=>404,
                'message'=>'Follow-up not found',
                'error_msg'=>'Follow-up not found',
                'data'=>null
            ],404);
        }

    
        if($request->progressed == 1){
            $followup->progressed      = 1;
            $followup->follow_through  = $request->follow_through ?? 0;
            $followup->convo_message   = $request->convo_message;
            $followup->status          = 4;
            $followup->updated_by      = $user->user_id;
            $followup->save();

        }else{
            $followup->status      = 5;
            $followup->reason      = $request->reason;
            $followup->updated_by  = $user->user_id;
            $followup->save();

            $last = AppointmentModel::lockForUpdate()
                ->orderByDesc('sno')
                ->first();

            if(!$last){
                $appointmentId = 'AP-0001/'.date('y');
            }else{
                preg_match('/AP-(\d+)/',$last->appointment_id,$match);
                $next = isset($match[1]) ? ((int)$match[1])+1: 1;
                $appointmentId = sprintf('AP-%04d/%s', $next,date('y'));
            }

            $appointmentDate = Carbon::createFromFormat('d-M-Y',$request->appointment_date)->format('Y-m-d');

            AppointmentModel::create([
                'appointment_id'   => $appointmentId,
                'lead_id'          => $followup->lead_id,
                'branch_id'        => $followup->branch_id,
                'progressed'       => 0,
                'app_score'        => $request->app_score ?? 0,
                'follow_through'   => $request->follow_through ?? 0,
                'appointment_date' => $appointmentDate,
                'appointment_time' => $request->appointment_time,
                'status'           => 1,
                'created_by'       => $user->user_id,
                'updated_by'       => $user->user_id
            ]);

        }
        DB::commit();
        return response()->json([
            'status'=>200,
            'message'=>'Follow-up updated successfully.',
            'error_msg'=>null,
            'data'=>null
        ]);
    } catch (\Exception $e){
        DB::rollBack();
        return response()->json([
            'status'=>500,
            'message'=>'Something went wrong.',
            'error_msg'=>$e->getMessage(),
            'data'=>null
        ],500);
    }
}

    public function TeamCallList(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $page = max((int)$request->page, 1);
        $limit = min(max((int)$request->limit, 10), 100);

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $search = $request->filled('search') ? $request->search : '';

        $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('et_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('et_staff.status', [4, 5, 6, 7]);
                    });
            });

        if ($search != '') {
            $salesStaff->where(function ($query) use ($search) {
                $query->where('et_staff.staff_name', 'LIKE', "%{$search}%")
                    ->orWhere('et_staff.nick_name', 'LIKE', "%{$search}%")
                    ->orWhere('et_staff.mobile_no', 'LIKE', "%{$search}%")
                    ->orWhere('et_cug_management.staff_mobile', 'LIKE', "%{$search}%");
            });
        }

        $totalStaff = $salesStaff->count();
        $salesStaff = $salesStaff->orderBy('et_staff.sno', 'desc')->paginate($limit, ['*'], 'page', $page);

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $callData = DB::table('et_call_tracker')
            ->select(
                'branch_staff_id',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count")
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->whereIn('branch_staff_id', $salesStaff->pluck('sno')->toArray())
            ->groupBy('branch_staff_id')
            ->get()
            ->keyBy('branch_staff_id');

        $staffItems = collect($salesStaff->items());

        $data = $staffItems->map(function ($item) use ($callData, $dayCount) {
            $callStats = $callData[$item->sno] ?? (object) [
                'incoming_call_count' => 0,
                'outgoingcall_count' => 0,
                'missedcall_count' => 0,
                'rejected_call_count' => 0,
                'dialedcall_count' => 0,
            ];

            $total_calls = $callStats->incoming_call_count + $callStats->missedcall_count + $callStats->rejected_call_count;
            $missed_call_ratio = $total_calls > 0 ? ($callStats->missedcall_count / $total_calls) * 100 : 0;

            $defaultPath = $item->gender == 1
                ? asset('assets/phdizone_images/auth/user_2.png')
                : asset('assets/phdizone_images/auth/user_7.png');

            $staffImageUrl = $item->staff_image
                ? url('/staff_images') . '/' . $item->staff_image
                : $defaultPath;

            return [
                'staff_id' => $item->sno,
                'staff_name' => $item->staff_name,
                'staff_image' => $staffImageUrl,
                'mobile_no' => $item->mobile_no,
                'cug_mobile' => $item->cug_mobile,
                'incoming_call_count' => $callStats->incoming_call_count,
                'outgoingcall_count' => $callStats->outgoingcall_count,
                'missedcall_count' => $callStats->missedcall_count,
                'rejected_call_count' => $callStats->rejected_call_count,
                'dialedcall_count' => $callStats->dialedcall_count,
                'outgoing_call_ratio' => $dayCount > 0 ? round($callStats->outgoingcall_count / $dayCount) : 0,
                'incoming_call_ratio' => $dayCount > 0 ? round($callStats->incoming_call_count / $dayCount) : 0,
                'missed_call_rate' => $dayCount > 0 ? round($callStats->missedcall_count / $dayCount) : 0,
                'missed_call_ratio' => round($missed_call_ratio, 2),
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => 'Team call list fetched successfully',
            'error_msg' => null,
            'data' => $data,
            'pagination' => [
                'current_page' => $salesStaff->currentPage(),
                'per_page' => $salesStaff->perPage(),
                'total' => $salesStaff->total(),
                'last_page' => $salesStaff->lastPage(),
                'has_more' => $salesStaff->hasMorePages()
            ]
        ]);
    }

    public function teamCallByStaffId(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $validator = Validator::make($request->all(), [
            'staff_id' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'status' => 422,
                'message' => 'Validation Error',
                'error_msg' => $validator->errors(),
                'data' => null
            ], 422);
        }

        $staff_id = $request->staff_id;

        $salesStaff = DB::table('et_staff')
            ->select(
                'et_staff.sno',
                'et_staff.staff_name',
                'et_staff.staff_image',
                'et_staff.gender',
                'et_staff.mobile_no',
                'et_cug_management.staff_mobile as cug_mobile'
            )
            ->leftJoin('et_cug_management', 'et_staff.sno', '=', 'et_cug_management.staff_id')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('et_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('et_staff.status', [4, 5, 6, 7]);
                    });
            })
            ->where('et_staff.sno', $staff_id)
            ->first();

        if (!$salesStaff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $year = $request->get('year', date('Y'));
        $month = $request->get('month', date('m'));

        $startDate = Carbon::create($year, $month, 1);
        $currentDate = Carbon::now();
        $endDate = ($currentDate->year == $year && $currentDate->month == $month)
            ? $currentDate
            : $startDate->copy()->endOfMonth();
        $dayCount = $startDate->diffInDays($endDate) + 1;

        $callData = DB::table('et_call_tracker')
            ->select(
                'branch_staff_id',
                DB::raw("SUM(CASE WHEN call_status = 1 THEN 1 ELSE 0 END) AS incoming_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 0 AND call_duration != '00:00:00' THEN 1 ELSE 0 END) AS outgoingcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 2 THEN 1 ELSE 0 END) AS missedcall_count"),
                DB::raw("SUM(CASE WHEN call_status = 3 THEN 1 ELSE 0 END) AS rejected_call_count"),
                DB::raw("SUM(CASE WHEN call_status = 4 THEN 1 ELSE 0 END) AS dialedcall_count")
            )
            ->whereYear('call_start_date', $year)
            ->whereMonth('call_start_date', $month)
            ->where('branch_staff_id', $staff_id)
            ->groupBy('branch_staff_id')
            ->first();

        $callStats = $callData ?: (object) [
            'incoming_call_count' => 0,
            'outgoingcall_count' => 0,
            'missedcall_count' => 0,
            'rejected_call_count' => 0,
            'dialedcall_count' => 0,
        ];

        $total_calls = $callStats->incoming_call_count + $callStats->missedcall_count + $callStats->rejected_call_count;
        $missed_call_ratio = $total_calls > 0 ? ($callStats->missedcall_count / $total_calls) * 100 : 0;

        $defaultPath = $salesStaff->gender == 1
            ? asset('assets/phdizone_images/auth/user_2.png')
            : asset('assets/phdizone_images/auth/user_7.png');

        $staffImageUrl = $salesStaff->staff_image
            ? url('/staff_images') . '/' . $salesStaff->staff_image
            : $defaultPath;

        $data = [
            'staff_id' => $salesStaff->sno,
            'staff_name' => $salesStaff->staff_name,
            'staff_image' => $staffImageUrl,
            'mobile_no' => $salesStaff->mobile_no,
            'cug_mobile' => $salesStaff->cug_mobile,
            'incoming_call_count' => $callStats->incoming_call_count,
            'outgoingcall_count' => $callStats->outgoingcall_count,
            'missedcall_count' => $callStats->missedcall_count,
            'rejected_call_count' => $callStats->rejected_call_count,
            'dialedcall_count' => $callStats->dialedcall_count,
            'outgoing_call_ratio' => $dayCount > 0 ? round($callStats->outgoingcall_count / $dayCount) : 0,
            'incoming_call_ratio' => $dayCount > 0 ? round($callStats->incoming_call_count / $dayCount) : 0,
            'missed_call_rate' => $dayCount > 0 ? round($callStats->missedcall_count / $dayCount) : 0,
            'missed_call_ratio' => round($missed_call_ratio, 2),
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Team call data fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function LeadDashboardCard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $monthStart = Carbon::now()->startOfMonth()->toDateString();

        $totalLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->count();

        $activeLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->where('status', 0)
            ->count();

        $inactiveLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->where('status', 1)
            ->count();

        $customerLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->where('status', 4)
            ->count();

        $oldCustomerLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->where('status', 10)
            ->count();

        $hotLeads = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->where('is_hot_lead', 1)
            ->count();

        $newLeadsToday = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->whereDate('created_at', $today)
            ->count();

        $newLeadsMonth = LeadModel::where('created_by', $user->user_id)
            ->where('internal_status', '!=', 1)
            ->whereDate('created_at', '>=', $monthStart)
            ->count();

        $data = [
            'total_leads' => $totalLeads,
            'active_leads' => $activeLeads,
            'inactive_leads' => $inactiveLeads,
            'customer_leads' => $customerLeads,
            'old_customer_leads' => $oldCustomerLeads,
            'hot_leads' => $hotLeads,
            'new_leads_today' => $newLeadsToday,
            'new_leads_month' => $newLeadsMonth,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Lead dashboard card fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function FollowupDashboard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $weekStart = Carbon::now()->startOfWeek(Carbon::MONDAY)->toDateString();

        $totalFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->count();

        $pendingFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_appointment.status', 1)
            ->count();

        $completedFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_appointment.status', 4)
            ->count();

        $cancelledFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->where('et_appointment.status', 3)
            ->count();

        $todayFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->whereDate('et_appointment.appointment_date', $today)
            ->count();

        $thisWeekFollowups = DB::table('et_appointment')
            ->join('et_lead', 'et_appointment.lead_id', '=', 'et_lead.sno')
            ->where('et_appointment.created_by', $user->user_id)
            ->where('et_lead.internal_status', '!=', 1)
            ->whereBetween('et_appointment.appointment_date', [$weekStart, $today])
            ->count();

        $data = [
            'total_followups' => $totalFollowups,
            'pending_followups' => $pendingFollowups,
            'completed_followups' => $completedFollowups,
            'cancelled_followups' => $cancelledFollowups,
            'today_followups' => $todayFollowups,
            'this_week_followups' => $thisWeekFollowups,
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Followup dashboard fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }

    public function TeamCallDashboard(Request $request)
    {
        $user = $request->user();

        $staff = StaffModel::where('sno', $user->user_id)->first();

        if (!$staff) {
            return response()->json([
                'status' => 404,
                'message' => 'Staff not found',
                'error_msg' => 'Staff not found',
                'data' => null
            ]);
        }

        $today = Carbon::today()->toDateString();
        $monthStart = Carbon::now()->startOfMonth()->toDateString();

        $salesStaffIds = DB::table('et_staff')
            ->where('et_staff.department_id', 1)
            ->where('et_staff.branch_id', $user->branch_id)
            ->where(function ($query) {
                $query->where('et_staff.status', 0)
                    ->orWhere(function ($query) {
                        $query->whereIn('et_staff.status', [4, 5, 6, 7]);
                    });
            })
            ->pluck('et_staff.sno')
            ->toArray();

        $todayCalls = DB::table('et_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->whereIn('branch_staff_id', $salesStaffIds)
            ->whereDate('call_start_date', $today)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $monthCalls = DB::table('et_call_tracker')
            ->select(
                'call_status',
                DB::raw('COUNT(*) as count')
            )
            ->whereIn('branch_staff_id', $salesStaffIds)
            ->whereDate('call_start_date', '>=', $monthStart)
            ->groupBy('call_status')
            ->get()
            ->keyBy('call_status');

        $getCount = function ($calls, $status) {
            return isset($calls[$status]) ? $calls[$status]->count : 0;
        };

        $data = [
            'today' => [
                'incoming_calls' => $getCount($todayCalls, 1),
                'outgoing_calls' => $getCount($todayCalls, 0),
                'missed_calls' => $getCount($todayCalls, 2),
                'rejected_calls' => $getCount($todayCalls, 3),
                'dialed_calls' => $getCount($todayCalls, 4),
            ],
            'this_month' => [
                'incoming_calls' => $getCount($monthCalls, 1),
                'outgoing_calls' => $getCount($monthCalls, 0),
                'missed_calls' => $getCount($monthCalls, 2),
                'rejected_calls' => $getCount($monthCalls, 3),
                'dialed_calls' => $getCount($monthCalls, 4),
            ],
            'team_members_count' => count($salesStaffIds),
        ];

        return response()->json([
            'status' => 200,
            'message' => 'Team call dashboard fetched successfully',
            'error_msg' => null,
            'data' => $data
        ]);
    }
    
}