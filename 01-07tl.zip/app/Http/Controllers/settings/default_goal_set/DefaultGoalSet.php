<?php

namespace App\Http\Controllers\settings\default_goal_set;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GoalSetStaffModel;
use App\Models\GoalSetTeamModel;
use App\Models\DepartmentModel;
use App\Models\DefaultGoalSetModel;
use App\Models\StaffModel;
use App\Models\BranchModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use App\Helpers\Helpers;

class DefaultGoalSet extends Controller
{

    public function index()
    {
        $branches = DB::table('et_branch')->where('status', 0)->get();

        return view('content.settings.default_goal_set.team_goalset', compact('branches'));
    }

    public function getDepartmentsByBranch($branch_id)
    {
        $departments = DB::table('et_department')
            // ->where('branch_id', $branch_id)
            ->where('status', 0)
            // ->orderBy('department_name','ASC')
            ->get();

        return response()->json($departments);
    }

    // Save or update default goals
    public function updateDefaultGoals(Request $request)
    {
        $validatedData = $request->validate([
            'branch_id' => 'required|integer',
            'department_id' => 'required|integer',

            'conversion' => 'nullable|numeric',
            'conversion_check' => 'nullable|boolean',

            'CR' => 'nullable|numeric',
            'CR_check' => 'nullable|boolean',

            'ABV' => 'nullable|numeric',
            'ABV_check' => 'nullable|boolean',

            'ACV' => 'nullable|numeric',
            'ACV_check' => 'nullable|boolean',

            'avg_call_out' => 'nullable|numeric',
            'avg_call_out_check' => 'nullable|boolean',

            'no_of_walk' => 'nullable|numeric',
            'no_of_walk_check' => 'nullable|boolean',

            'no_of_followup' => 'nullable|numeric',
            'no_of_followup_check' => 'nullable|boolean',

            'working_hours' => 'nullable|numeric',
            'working_hours_check' => 'nullable|boolean',

            'rework' => 'nullable|numeric',
            'rework_check' => 'nullable|boolean',

            'no_of_papers' => 'nullable|numeric',
            'no_of_papers_check' => 'nullable|boolean',
            'no_of_reviews' => 'nullable|numeric',
            'no_of_reviews_check' => 'nullable|boolean',

            'harvesting_percentage' => 'nullable|numeric',
            'harvesting_percentage_check' => 'nullable|boolean',
        ]);

        // Set unchecked checkboxes to 0 explicitly
        foreach ($validatedData as $key => $value) {
            if (strpos($key, '_check') !== false && $value === null) {
                $validatedData[$key] = 0;
            }
        }

        // Check if record exists to determine created_by
        $existingRecord = DefaultGoalSetModel::where('branch_id', $validatedData['branch_id'])
            ->where('department_id', $validatedData['department_id'])
            ->first();

        $goal = DefaultGoalSetModel::updateOrCreate(
            [
                'branch_id' => $validatedData['branch_id'],
                'department_id' => $validatedData['department_id']
            ],
            array_merge(
                $validatedData,
                [
                    'updated_by' => auth()->id(),
                    'created_by' => $existingRecord ? $existingRecord->created_by : auth()->id(),
                ]
            )
        );

        return redirect()->route('settings-default-goal-set')->with('success', 'Default goals updated successfully');
    }


    public function getDefaultGoals($branch_id, $department_id)
    {
        $goal = DefaultGoalSetModel::where('branch_id', $branch_id)
            ->where('department_id', $department_id)
            ->first();

        if ($goal) {
            return response()->json($goal);
        } else {
            return response()->json(null);
        }
    }
}
