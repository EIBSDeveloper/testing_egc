<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebHookHandler\WebhookReceiverController;
use App\Http\Controllers\mobile_apps\CustomerAppController;
use App\Http\Controllers\mobile_apps\SalesApp;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

//Post
Route::post('/webhooks/add_broadcast', [WebhookReceiverController::class, 'broadcastMessage']);
Route::post('/webhooks/new_department', [WebhookReceiverController::class, 'DepartmentHook']);
Route::post('/webhooks/new_division', [WebhookReceiverController::class, 'DivisionHook']);
Route::post('/webhooks/new_job_position', [WebhookReceiverController::class, 'JobPositionHook']);
Route::post('/webhooks/new_staff_add', [WebhookReceiverController::class, 'StaffAddHook']);
Route::post('/webhooks/update_department_uuid', [WebhookReceiverController::class, 'UpdateDepartmentUUID']);
Route::post('/webhooks/update_division_uuid', [WebhookReceiverController::class, 'UpdateDivisionUUID']);
Route::post('/webhooks/update_jobrole_uuid', [WebhookReceiverController::class, 'UpdateJobPositionUUID']);
Route::post('/webhooks/update_staff_uuid', [WebhookReceiverController::class, 'UpdateStaffUUID']);
Route::post('/webhooks/update_userrole_uuid', [WebhookReceiverController::class, 'UpdateUserRoleUUID']);
Route::post('/webhooks/staff_attendance_update', [WebhookReceiverController::class, 'StaffAddAttendanceHook']);
Route::post('/webhooks/staff_attendance_update_essl', [WebhookReceiverController::class, 'StaffAddAttendanceHookEssl']);


Route::post('/webhooks/update_exist_staff', [WebhookReceiverController::class, 'UpdateExistStaff']);
Route::get('/exist-staff-count', [WebhookReceiverController::class, 'existStaffCount']);
Route::get('/exist-staff-list', [WebhookReceiverController::class, 'existStaffList']);

Route::post('/webhooks/update_branch_target', [WebhookReceiverController::class, 'updateTargets']);
Route::post('/webhooks/add_transfer_staff', [WebhookReceiverController::class, 'AddTransferStaff']);

// Get
Route::get('/staff_data_get', [WebhookReceiverController::class, 'StaffData']);
Route::get('/department_data_get', [WebhookReceiverController::class, 'DepartmentList']);
Route::get('/division_data_get', [WebhookReceiverController::class, 'DivisionList']);
Route::get('/job_role_data_get', [WebhookReceiverController::class, 'JobPostionList']);
Route::get('/get_user_role_egc', [WebhookReceiverController::class, 'UserRoleList']);
Route::get('/erp_user_credential_check', [WebhookReceiverController::class, 'userCrendentialCheck']);
Route::post('/get_achieve_values', [WebhookReceiverController::class, 'getAchieveData']);
Route::get('/get_incentive_by_role', [WebhookReceiverController::class, 'GetIncentive']);

// Customer Mobile App

Route::prefix('customer_app')->group(function () {
    Route::post('/login', [CustomerAppController::class, 'customerLogin']);
    Route::post('/verify_otp', [CustomerAppController::class, 'verifyOtp']);
    Route::post('/customer_details', [CustomerAppController::class, 'customerDetails']);
    Route::post('/proposal_data', [CustomerAppController::class, 'proposalData']);
    // Payments
    Route::post('/payment_data', [CustomerAppController::class, 'PaymentData']);
    Route::post('/payment_details', [CustomerAppController::class, 'PaymentDetails']);
    Route::post('/payment_slot_details', [CustomerAppController::class, 'PaymentSlotDetails']);
    // Journal
    Route::post('/service_data', [CustomerAppController::class, 'serviceData']);
    Route::post('/milestone_data', [CustomerAppController::class, 'milestoneData']);
    Route::post('/journal_services', [CustomerAppController::class, 'getJournalServices']);
    Route::post('/journal_list', [CustomerAppController::class, 'getJournalList']);
    Route::post('/journal_history_list', [CustomerAppController::class, 'getJournalHistory']);
    // Chat
    Route::post('/chat_proposal_publication_list', [CustomerAppController::class, 'ChatProposalPublicationList']);
    Route::post('/chat_list', [CustomerAppController::class, 'getChatList']);
    Route::post('/chat_add', [CustomerAppController::class, 'CreateChat']);
    Route::post('/chat_mark_all_read', [CustomerAppController::class, 'markSeen']);

    // Ticket
    Route::post('/ticket_proposal_list', [CustomerAppController::class, 'TicketproposalData']);
    Route::post('/ticket_proposal_services_list', [CustomerAppController::class, 'TicketproposalServicesData']);
    Route::post('/ticket_relavant_list', [CustomerAppController::class, 'TicketRelavantList']);
    Route::post('/ticket_department_list', [CustomerAppController::class, 'TicketDepartmentList']);
    Route::post('/create_ticket', [CustomerAppController::class, 'CreateTicket']);
    Route::post('/ticket_list', [CustomerAppController::class, 'TicketList']);
    Route::post('/ticket_status_update', [CustomerAppController::class, 'updateticket']);
    Route::post('/ticket_history', [CustomerAppController::class, 'getTicketHistory']);
    
    // Milestone Documents
    Route::post('/milestone_documents', [CustomerAppController::class, 'MilestoneDocuments']);
    Route::post('/generate_documents', [CustomerAppController::class, 'GenerateDocuments']);
    
    // Dropdowns
    Route::post('/CountryList', [CustomerAppController::class, 'CountryList']);
    Route::post('/StateList', [CustomerAppController::class, 'StateList']);
    Route::post('/CityList', [CustomerAppController::class, 'CityList']);
    
    // Profile Update
    Route::post('/Profile_update', [CustomerAppController::class, 'ProfileUpload']);
    // Dashboard
    Route::post('/dashboard_data', [CustomerAppController::class, 'DashboardData']);
    // Notification
    Route::post('/notification_details', [CustomerAppController::class, 'CustomerNotification']);
    Route::post('/notification_count', [CustomerAppController::class, 'CustomerNotificationCount']);
    Route::post('/notification_read_all', [CustomerAppController::class, 'CustomerNotificationReadAll']);
    Route::post('/notification_delete', [CustomerAppController::class, 'CustomerNotificationDelete']);
    
});



// sales App 
Route::prefix('sales_app')->group(function () {
    Route::post('/staff_login', [SalesApp::class, 'StaffLogin']);
    Route::post('/verify_otp_staff', [SalesApp::class, 'verifyOtp']);

    Route::middleware(['salesauth.jwt'])->group(function () {
        Route::get('/staff_details', [SalesApp::class, 'staffDetails']);
        Route::get('/lead_list', [SalesApp::class, 'LeadList']);
        Route::get('/lead_detail_by_id', [SalesApp::class, 'LeadDetail']);
        Route::get('/lead_source_list', [SalesApp::class, 'leadSourceList']);
        Route::get('/product_list', [SalesApp::class, 'productList']);
        Route::get('/followup_list', [SalesApp::class, 'FollowupList']);
        Route::post('/followup_add', [SalesApp::class, 'FollowupAdd']);
        Route::post('/followup_detail', [SalesApp::class, 'FollowupDetail']);
        Route::post('/followup_reschedule', [SalesApp::class, 'FollowupReschedule']);
        Route::post('/followup_close', [SalesApp::class, 'FollowupClose']);
        Route::get('/team_call_list', [SalesApp::class, 'TeamCallList']);
        Route::get('/team_call_by_staff_id', [SalesApp::class, 'TeamCallByStaffId']);
        Route::get('/lead_dashboard_card', [SalesApp::class, 'LeadDashboardCard']);
        Route::get('/followup_dashboard', [SalesApp::class, 'FollowupDashboard']);
        Route::get('/team_call_dashboard', [SalesApp::class, 'TeamCallDashboard']);
        Route::get('/followup_reason_list', [SalesApp::class, 'followupReasonList']);
    });

});

